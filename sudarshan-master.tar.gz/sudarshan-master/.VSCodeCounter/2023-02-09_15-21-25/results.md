# Summary

Date : 2023-02-09 15:21:25

Directory /home/sanket/Downloads/data/SUDARSHAN1.0/src

Total : 391 files,  64687 codes, 4591 comments, 9280 blanks, all 78558 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Java | 389 | 64,538 | 4,528 | 9,224 | 78,290 |
| Properties | 1 | 139 | 63 | 53 | 255 |
| SQL | 1 | 10 | 0 | 3 | 13 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 391 | 64,687 | 4,591 | 9,280 | 78,558 |
| main | 391 | 64,687 | 4,591 | 9,280 | 78,558 |
| main/java | 389 | 64,538 | 4,528 | 9,224 | 78,290 |
| main/java/com | 389 | 64,538 | 4,528 | 9,224 | 78,290 |
| main/java/com/cdac | 389 | 64,538 | 4,528 | 9,224 | 78,290 |
| main/java/com/cdac/sudarshan | 389 | 64,538 | 4,528 | 9,224 | 78,290 |
| main/java/com/cdac/sudarshan (Files) | 11 | 546 | 81 | 162 | 789 |
| main/java/com/cdac/sudarshan/alerts | 8 | 1,970 | 175 | 238 | 2,383 |
| main/java/com/cdac/sudarshan/alerts/controller | 1 | 88 | 17 | 30 | 135 |
| main/java/com/cdac/sudarshan/alerts/model | 4 | 1,193 | 14 | 43 | 1,250 |
| main/java/com/cdac/sudarshan/alerts/repository | 1 | 9 | 0 | 6 | 15 |
| main/java/com/cdac/sudarshan/alerts/service | 2 | 680 | 144 | 159 | 983 |
| main/java/com/cdac/sudarshan/aspect | 1 | 0 | 35 | 1 | 36 |
| main/java/com/cdac/sudarshan/authentication | 9 | 450 | 165 | 183 | 798 |
| main/java/com/cdac/sudarshan/authentication/controller | 1 | 73 | 132 | 50 | 255 |
| main/java/com/cdac/sudarshan/authentication/dto | 1 | 21 | 0 | 6 | 27 |
| main/java/com/cdac/sudarshan/authentication/model | 2 | 93 | 2 | 30 | 125 |
| main/java/com/cdac/sudarshan/authentication/repository | 1 | 11 | 0 | 8 | 19 |
| main/java/com/cdac/sudarshan/authentication/service | 4 | 252 | 31 | 89 | 372 |
| main/java/com/cdac/sudarshan/code | 4 | 109 | 0 | 48 | 157 |
| main/java/com/cdac/sudarshan/code/model | 1 | 56 | 0 | 18 | 74 |
| main/java/com/cdac/sudarshan/code/repository | 1 | 10 | 0 | 9 | 19 |
| main/java/com/cdac/sudarshan/code/service | 2 | 43 | 0 | 21 | 64 |
| main/java/com/cdac/sudarshan/collection | 6 | 138 | 0 | 56 | 194 |
| main/java/com/cdac/sudarshan/collection/trackgeolocation | 3 | 58 | 0 | 24 | 82 |
| main/java/com/cdac/sudarshan/collection/trackgeolocation/controller | 1 | 22 | 0 | 6 | 28 |
| main/java/com/cdac/sudarshan/collection/trackgeolocation/service | 2 | 36 | 0 | 18 | 54 |
| main/java/com/cdac/sudarshan/collection/tracklocation | 3 | 80 | 0 | 32 | 112 |
| main/java/com/cdac/sudarshan/collection/tracklocation/controller | 1 | 22 | 0 | 6 | 28 |
| main/java/com/cdac/sudarshan/collection/tracklocation/service | 2 | 58 | 0 | 26 | 84 |
| main/java/com/cdac/sudarshan/db | 5 | 339 | 148 | 109 | 596 |
| main/java/com/cdac/sudarshan/db (Files) | 3 | 57 | 43 | 28 | 128 |
| main/java/com/cdac/sudarshan/db/tables | 2 | 282 | 105 | 81 | 468 |
| main/java/com/cdac/sudarshan/db/tables (Files) | 1 | 96 | 48 | 30 | 174 |
| main/java/com/cdac/sudarshan/db/tables/records | 1 | 186 | 57 | 51 | 294 |
| main/java/com/cdac/sudarshan/discover | 214 | 55,411 | 3,091 | 6,568 | 65,070 |
| main/java/com/cdac/sudarshan/discover/common | 73 | 39,079 | 2,073 | 4,672 | 45,824 |
| main/java/com/cdac/sudarshan/discover/controller | 7 | 608 | 306 | 221 | 1,135 |
| main/java/com/cdac/sudarshan/discover/dto | 7 | 100 | 28 | 39 | 167 |
| main/java/com/cdac/sudarshan/discover/model | 110 | 12,019 | 84 | 883 | 12,986 |
| main/java/com/cdac/sudarshan/discover/projection | 2 | 10 | 0 | 6 | 16 |
| main/java/com/cdac/sudarshan/discover/repository | 4 | 38 | 3 | 20 | 61 |
| main/java/com/cdac/sudarshan/discover/service | 10 | 3,531 | 596 | 720 | 4,847 |
| main/java/com/cdac/sudarshan/discover/utils | 1 | 26 | 1 | 7 | 34 |
| main/java/com/cdac/sudarshan/dto | 10 | 215 | 1 | 97 | 313 |
| main/java/com/cdac/sudarshan/entityprofiles | 6 | 159 | 1 | 49 | 209 |
| main/java/com/cdac/sudarshan/entityprofiles/controller | 1 | 29 | 1 | 5 | 35 |
| main/java/com/cdac/sudarshan/entityprofiles/dto | 1 | 20 | 0 | 8 | 28 |
| main/java/com/cdac/sudarshan/entityprofiles/model | 1 | 48 | 0 | 6 | 54 |
| main/java/com/cdac/sudarshan/entityprofiles/repository | 1 | 5 | 0 | 5 | 10 |
| main/java/com/cdac/sudarshan/entityprofiles/service | 2 | 57 | 0 | 25 | 82 |
| main/java/com/cdac/sudarshan/exception | 11 | 201 | 26 | 69 | 296 |
| main/java/com/cdac/sudarshan/folder | 27 | 2,021 | 409 | 699 | 3,129 |
| main/java/com/cdac/sudarshan/folder/controller | 3 | 244 | 40 | 86 | 370 |
| main/java/com/cdac/sudarshan/folder/dto | 7 | 95 | 0 | 40 | 135 |
| main/java/com/cdac/sudarshan/folder/model | 7 | 159 | 9 | 63 | 231 |
| main/java/com/cdac/sudarshan/folder/repository | 4 | 102 | 23 | 74 | 199 |
| main/java/com/cdac/sudarshan/folder/service | 6 | 1,421 | 337 | 436 | 2,194 |
| main/java/com/cdac/sudarshan/folderManagement | 10 | 514 | 18 | 124 | 656 |
| main/java/com/cdac/sudarshan/folderManagement/controller | 2 | 104 | 0 | 35 | 139 |
| main/java/com/cdac/sudarshan/folderManagement/dto | 5 | 100 | 5 | 28 | 133 |
| main/java/com/cdac/sudarshan/folderManagement/service | 3 | 310 | 13 | 61 | 384 |
| main/java/com/cdac/sudarshan/mysearches | 6 | 183 | 11 | 53 | 247 |
| main/java/com/cdac/sudarshan/mysearches/controller | 1 | 41 | 2 | 9 | 52 |
| main/java/com/cdac/sudarshan/mysearches/dto | 1 | 13 | 0 | 3 | 16 |
| main/java/com/cdac/sudarshan/mysearches/model | 1 | 43 | 0 | 10 | 53 |
| main/java/com/cdac/sudarshan/mysearches/repository | 1 | 15 | 0 | 8 | 23 |
| main/java/com/cdac/sudarshan/mysearches/service | 2 | 71 | 9 | 23 | 103 |
| main/java/com/cdac/sudarshan/profile | 3 | 63 | 0 | 24 | 87 |
| main/java/com/cdac/sudarshan/profile/controller | 1 | 21 | 0 | 10 | 31 |
| main/java/com/cdac/sudarshan/profile/service | 2 | 42 | 0 | 14 | 56 |
| main/java/com/cdac/sudarshan/signup | 4 | 229 | 79 | 65 | 373 |
| main/java/com/cdac/sudarshan/signup/controller | 1 | 31 | 71 | 14 | 116 |
| main/java/com/cdac/sudarshan/signup/services | 2 | 193 | 8 | 47 | 248 |
| main/java/com/cdac/sudarshan/signup/utils | 1 | 5 | 0 | 4 | 9 |
| main/java/com/cdac/sudarshan/speech | 5 | 251 | 50 | 92 | 393 |
| main/java/com/cdac/sudarshan/speech/constants | 1 | 3 | 0 | 4 | 7 |
| main/java/com/cdac/sudarshan/speech/controller | 1 | 51 | 0 | 15 | 66 |
| main/java/com/cdac/sudarshan/speech/service | 3 | 197 | 50 | 73 | 320 |
| main/java/com/cdac/sudarshan/theme | 20 | 785 | 140 | 297 | 1,222 |
| main/java/com/cdac/sudarshan/theme/controller | 3 | 110 | 5 | 54 | 169 |
| main/java/com/cdac/sudarshan/theme/dto | 5 | 101 | 0 | 36 | 137 |
| main/java/com/cdac/sudarshan/theme/model | 3 | 104 | 1 | 22 | 127 |
| main/java/com/cdac/sudarshan/theme/repository | 3 | 47 | 1 | 27 | 75 |
| main/java/com/cdac/sudarshan/theme/service | 6 | 423 | 133 | 158 | 714 |
| main/java/com/cdac/sudarshan/utils | 4 | 67 | 3 | 24 | 94 |
| main/java/com/cdac/sudarshan/watchlist | 25 | 887 | 95 | 266 | 1,248 |
| main/java/com/cdac/sudarshan/watchlist/configuration | 1 | 14 | 0 | 5 | 19 |
| main/java/com/cdac/sudarshan/watchlist/controller | 3 | 165 | 7 | 46 | 218 |
| main/java/com/cdac/sudarshan/watchlist/dto | 8 | 134 | 2 | 50 | 186 |
| main/java/com/cdac/sudarshan/watchlist/model | 4 | 86 | 5 | 25 | 116 |
| main/java/com/cdac/sudarshan/watchlist/repository | 3 | 29 | 1 | 18 | 48 |
| main/java/com/cdac/sudarshan/watchlist/service | 6 | 459 | 80 | 122 | 661 |
| main/resources | 2 | 149 | 63 | 56 | 268 |
| main/resources (Files) | 1 | 139 | 63 | 53 | 255 |
| main/resources/db | 1 | 10 | 0 | 3 | 13 |
| main/resources/db/migration | 1 | 10 | 0 | 3 | 13 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)