package com.cdac.sudarshan.discover.model;

import java.io.Serializable;
import java.util.ArrayList;

public class Insta_Post implements Serializable 
{
	private static final long serialVersionUID = 1L;
	private String instaPostId;
	private String instaPostLink;
	private String instaPostThumbnailLink;
	private String instaPostUserId;
	private String instaPostUserName;
	private String instaPostUserFullName;
	private String instaPostUserImgUrl;
	private String instaPostType;
	private String instaPostCountry;
	private String instaPostLocation;
	private String instaPostLanguage;
	private String instaPostCaption;
	private long instaCreatedAt;
	private int instaPostLikeCount;
	private int instaPostCommentCount;
	private ArrayList<String> entityId;	
	private ArrayList<String> instaHashTag=new ArrayList<String>();
	private ArrayList<String>instaMention=new ArrayList<String>();
	private ArrayList<Articel_Comment> instaComment=new ArrayList<Articel_Comment>();
	private ArrayList<Article_Insta_User> instaLikeUser=new ArrayList<Article_Insta_User>();

	public String getInstaPostLocation() {
		return instaPostLocation;
	}
	public void setInstaPostLocation(String instaPostLocation) {
		this.instaPostLocation = instaPostLocation;
	}
	public String getInstaPostUserFullName() {
		return instaPostUserFullName;
	}
	public void setInstaPostUserFullName(String instaPostUserFullName) {
		this.instaPostUserFullName = instaPostUserFullName;
	}
	public String getInstaPostLanguage() {
		return instaPostLanguage;
	}
	public void setInstaPostLanguage(String instaPostLanguage) {
		this.instaPostLanguage = instaPostLanguage;
	}
	public String getInstaPostUserName() {
		return instaPostUserName;
	}
	public void setInstaPostUserName(String instaPostUserName) {
		this.instaPostUserName = instaPostUserName;
	}
	public String getInstaPostCountry() {
		return instaPostCountry;
	}
	public void setInstaPostCountry(String instaPostCountry) {
		this.instaPostCountry = instaPostCountry;
	}
	public String getInstaPostCaption() {
		return instaPostCaption;
	}
	public void setInstaPostCaption(String instaPostCaption) {
		this.instaPostCaption = instaPostCaption;
	}
	public String getInstaPostThumbnailLink() {
		return instaPostThumbnailLink;
	}
	public void setInstaPostThumbnailLink(String instaPostThumbnailLink) {
		this.instaPostThumbnailLink = instaPostThumbnailLink;
	}
	public String getInstaPostType() {
		return instaPostType;
	}
	public void setInstaPostType(String instaPostType) {
		this.instaPostType = instaPostType;
	}
	public ArrayList<String> getEntityId() {
		return entityId;
	}
	public void setEntityId(ArrayList<String> entityId) {
		this.entityId = entityId;
	}
	public ArrayList<String> getInstaHashTag() {
		return instaHashTag;
	}
	public void setInstaHashTag(ArrayList<String> instaHashTag) {
		this.instaHashTag = instaHashTag;
	}
	public ArrayList<String> getInstaMention() {
		return instaMention;
	}
	public void setInstaMention(ArrayList<String> instaMention) {
		this.instaMention = instaMention;
	}
	public long getInstaCreatedAt() {
		return instaCreatedAt;
	}
	public void setInstaCreatedAt(long instaCreatedAt) {
		this.instaCreatedAt = instaCreatedAt;
	}
	public String getInstaPostId() {
		return instaPostId;
	}
	public void setInstaPostId(String instaPostId) {
		this.instaPostId = instaPostId;
	}
	public String getInstaPostLink() {
		return instaPostLink;
	}
	public void setInstaPostLink(String instaPostLink) {
		this.instaPostLink = instaPostLink;
	}
	public String getInstaPostUserId() {
		return instaPostUserId;
	}
	public void setInstaPostUserId(String instaPostUserId) {
		this.instaPostUserId = instaPostUserId;
	}
	public String getInstaPostUserImgUrl() {
		return instaPostUserImgUrl;
	}
	public void setInstaPostUserImgUrl(String instaPostUserImgUrl) {
		this.instaPostUserImgUrl = instaPostUserImgUrl;
	}



	public ArrayList<Articel_Comment> getInstaComment() {
		return instaComment;
	}
	public void setInstaComment(ArrayList<Articel_Comment> instaComment) {
		this.instaComment = instaComment;
	}
	public int getInstaPostLikeCount() {
		return instaPostLikeCount;
	}
	public void setInstaPostLikeCount(int instaPostLikeCount) {
		this.instaPostLikeCount = instaPostLikeCount;
	}
	public int getInstaPostCommentCount() {
		return instaPostCommentCount;
	}
	public void setInstaPostCommentCount(int instaPostCommentCount) {
		this.instaPostCommentCount = instaPostCommentCount;
	}
	public ArrayList<Article_Insta_User> getInstaLikeUser() {
		return instaLikeUser;
	}
	public void setInstaLikeUser(ArrayList<Article_Insta_User> instaLikeUser) {
		this.instaLikeUser = instaLikeUser;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "Insta_Post [entityId=" + entityId + ", instaCreatedAt=" + instaCreatedAt + ", instaPostId="
				+ instaPostId + ", instaPostLink=" + instaPostLink + ", instaPostThumbnailLink="
				+ instaPostThumbnailLink + ", instaPostUserId=" + instaPostUserId + ", instaPostUserName="
				+ instaPostUserName + ", instaPostUserFullName=" + instaPostUserFullName + ", instaPostUserImgUrl="
				+ instaPostUserImgUrl + ", instaHashTag=" + instaHashTag + ", instaMention=" + instaMention
				+ ", instaPostLikeCount=" + instaPostLikeCount + ", instaPostCommentCount=" + instaPostCommentCount
				+ ", instaPostType=" + instaPostType + ", instaPostCountry=" + instaPostCountry + ", instaPostLocation="
				+ instaPostLocation + ", instaPostLanguage=" + instaPostLanguage + ", instaComment=" + instaComment
				+ ", instaPostCaption=" + instaPostCaption + ", instaLikeUser=" + instaLikeUser + "]";
	}
	
}
