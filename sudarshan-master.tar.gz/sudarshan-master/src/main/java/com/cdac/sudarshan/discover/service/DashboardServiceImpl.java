package com.cdac.sudarshan.discover.service;

import java.util.Arrays;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

@Service
public class DashboardServiceImpl implements IDashboardService{

	@Autowired
	private RestTemplate restTemplate;
	
	@Value("${localInnefuUrl}")
	private String innefuUrl;
	
	@Override
	public ResponseEntity<?> getClassification(HashMap<String, Object> data) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<>(data, headers);

		return restTemplate.exchange(innefuUrl + "/getClassification", HttpMethod.POST, entity, Object.class);
	}

	@Override
	public ResponseEntity<?> getSentiment(HashMap<String, Object> data) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<>(data, headers);

		return restTemplate.exchange(innefuUrl + "/getSentiment", HttpMethod.POST, entity, Object.class);
	}

//	@Override
//	public ResponseEntity<?> getWordCloud(HashMap<String, Object> data) {
//		HttpHeaders headers = new HttpHeaders();
//		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
//		headers.setContentType(MediaType.APPLICATION_JSON);
//		HttpEntity<Object> entity = new HttpEntity<>(data, headers);
//
//		return restTemplate.exchange(innefuUrl + "getThemeWordCloud", HttpMethod.POST, entity, Object.class);
//	}

	@Override
	public ResponseEntity<?> getWordCloud(HashMap<String, Object> data) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<>(data, headers);		
		ResponseEntity<Object> result = restTemplate.exchange(innefuUrl + "/getThemeWordCloud", HttpMethod.POST, entity, Object.class); 	
		
		//Change keys of existing json (word to text and frequency to  weight)
		String bodyData= result.getBody().toString();
		bodyData=bodyData.replace("word","text");
		bodyData=bodyData.replace("frequency","weight");		 
	//	Gson gson = new Gson();  
		Gson gson = new GsonBuilder().serializeNulls().create();
		Object body  =  gson.fromJson(bodyData, Object.class); 	
		ResponseEntity<Object> changedJsonData = new ResponseEntity<Object>(body,result.getHeaders(),HttpStatus.OK);
		return changedJsonData;
	}

	
}
