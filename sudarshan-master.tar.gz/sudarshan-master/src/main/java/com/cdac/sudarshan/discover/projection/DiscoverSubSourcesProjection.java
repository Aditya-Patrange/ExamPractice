package com.cdac.sudarshan.discover.projection;

public interface DiscoverSubSourcesProjection {
	String getSubSource();

	Integer getId(); 
	
	String getAlias();
}
