package com.cdac.sudarshan.discover.repository;


import com.cdac.sudarshan.discover.model.Trends;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ITrendsRepository extends JpaRepository<Trends, Integer> {
}
