package com.cdac.sudarshan.discover.model;

import java.io.Serializable;

public class Article_Fb_User implements Serializable
{
	private static final long serialVersionUID = 1L;
	private String fbFbUserId;
	private String fbFbUserName;
	private String emotionType;
	
	public String getFbFbUserId() {
		return fbFbUserId;
	}
	public void setFbFbUserId(String fbFbUserId) {
		this.fbFbUserId = fbFbUserId;
	}
	public String getFbFbUserName() {
		return fbFbUserName;
	}
	public void setFbFbUserName(String fbFbUserName) {
		this.fbFbUserName = fbFbUserName;
	}
	public String getEmotionType() {
		return emotionType;
	}
	public void setEmotionType(String emotionType) {
		this.emotionType = emotionType;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "Article_Fb_User [fbFbUserId=" + fbFbUserId + ", fbFbUserName=" + fbFbUserName + ", emotionType="
				+ emotionType + "]";
	}

}
