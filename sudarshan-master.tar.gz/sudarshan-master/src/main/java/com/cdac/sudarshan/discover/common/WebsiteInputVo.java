package com.cdac.sudarshan.discover.common;

import java.util.ArrayList;

public class WebsiteInputVo 
{
	private	int rowNum;
	private	String source;
	private	String sourceNot;
	private	String author;
	private	String authorNot;
	private	String org;
	private	String orgNot;
	private	String location;
	private	String locationNot;
	private	String person;
	private	String personNot;
	private	String country;
	private	String countryNot;
	private	String countryCode;
	private	String dateFrom;
	private	String dateTo;
	private	String dateFromGr;
	private	String dateToGr;
	private	String advFilter;
	private	String sortFilter;
	private String articleId;
    private String isDashBord;
    private String sentimentFilter;
    private String priorityFilter;
    private	String priority;
    private String isMarked;
    private String keywordFilter2;
    private String keywordFilter;
    private	String type;
    private String caseId;
    private	String entityId;
    private String isRpt;
    private String id;
    private String noArt;
    private String noSrc;
    private String noAthr;
    private String noPer;
    private String noPlace;
    private String noOrg;
    private String entityKeyword;
    private ArrayList<String> entityIds;
    private String sourceType;
    private String stateName;
    private String cityName;
    private String countryFilter;
    private String stateFilter;
    private String cityFilter;
    private String languageFilter;
    private String newsModeFilter;
    private String caseName;
    private String dateOfCreation;
    private String caseType;
    private String analysisType;
    private String mark;
    private String isAnalysis;
    private String userId;
    
    
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getCaseName() {
		return caseName;
	}
	public void setCaseName(String caseName) {
		this.caseName = caseName;
	}
	public String getDateOfCreation() {
		return dateOfCreation;
	}
	public void setDateOfCreation(String dateOfCreation) {
		this.dateOfCreation = dateOfCreation;
	}
	public String getCaseType() {
		return caseType;
	}
	public void setCaseType(String caseType) {
		this.caseType = caseType;
	}
	public String getAnalysisType() {
		return analysisType;
	}
	public void setAnalysisType(String analysisType) {
		this.analysisType = analysisType;
	}
	public String getMark() {
		return mark;
	}
	public void setMark(String mark) {
		this.mark = mark;
	}
	public String getIsAnalysis() {
		return isAnalysis;
	}
	public void setIsAnalysis(String isAnalysis) {
		this.isAnalysis = isAnalysis;
	}
	public String getLanguageFilter() {
		return languageFilter;
	}
	public void setLanguageFilter(String languageFilter) {
		this.languageFilter = languageFilter;
	}
	public String getNewsModeFilter() {
		return newsModeFilter;
	}
	public void setNewsModeFilter(String newsModeFilter) {
		this.newsModeFilter = newsModeFilter;
	}
	public String getCountryFilter() {
		return countryFilter;
	}
	public void setCountryFilter(String countryFilter) {
		this.countryFilter = countryFilter;
	}
	public String getStateFilter() {
		return stateFilter;
	}
	public void setStateFilter(String stateFilter) {
		this.stateFilter = stateFilter;
	}
	public String getCityFilter() {
		return cityFilter;
	}
	public void setCityFilter(String cityFilter) {
		this.cityFilter = cityFilter;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getStateName() {
		return stateName;
	}
	public void setStateName(String stateName) {
		this.stateName = stateName;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public String getSourceType() {
		return sourceType;
	}
	public void setSourceType(String sourceType) {
		this.sourceType = sourceType;
	}
	public ArrayList<String> getEntityIds() {
		return entityIds;
	}
	public void setEntityIds(ArrayList<String> entityIds) {
		this.entityIds = entityIds;
	}
	public String getEntityKeyword() {
		return entityKeyword;
	}
	public void setEntityKeyword(String entityKeyword) {
		this.entityKeyword = entityKeyword;
	}
	public String getNoArt() {
		return noArt;
	}
	public void setNoArt(String noArt) {
		this.noArt = noArt;
	}
	public String getNoSrc() {
		return noSrc;
	}
	public void setNoSrc(String noSrc) {
		this.noSrc = noSrc;
	}
	public String getNoAthr() {
		return noAthr;
	}
	public void setNoAthr(String noAthr) {
		this.noAthr = noAthr;
	}
	public String getNoPer() {
		return noPer;
	}
	public void setNoPer(String noPer) {
		this.noPer = noPer;
	}
	public String getNoPlace() {
		return noPlace;
	}
	public void setNoPlace(String noPlace) {
		this.noPlace = noPlace;
	}
	public String getNoOrg() {
		return noOrg;
	}
	public void setNoOrg(String noOrg) {
		this.noOrg = noOrg;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getIsRpt() {
		return isRpt;
	}
	public void setIsRpt(String isRpt) {
		this.isRpt = isRpt;
	}
	public String getEntityId() {
		return entityId;
	}
	public void setEntityId(String entityId) {
		this.entityId = entityId;
	}
	public String getCaseId() {
		return caseId;
	}
	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	public String getPriorityFilter() {
		return priorityFilter;
	}
	public void setPriorityFilter(String priorityFilter) {
		this.priorityFilter = priorityFilter;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getCountryNot() {
		return countryNot;
	}
	public void setCountryNot(String countryNot) {
		this.countryNot = countryNot;
	}
	public String getKeywordFilter() {
		return keywordFilter;
	}
	public void setKeywordFilter(String keywordFilter) {
		this.keywordFilter = keywordFilter;
	}
	public int getRowNum() {
		return rowNum;
	}
	public void setRowNum(int rowNum) {
		this.rowNum = rowNum;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getSourceNot() {
		return sourceNot;
	}
	public void setSourceNot(String sourceNot) {
		this.sourceNot = sourceNot;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getAuthorNot() {
		return authorNot;
	}
	public void setAuthorNot(String authorNot) {
		this.authorNot = authorNot;
	}
	public String getOrg() {
		return org;
	}
	public void setOrg(String org) {
		this.org = org;
	}
	public String getOrgNot() {
		return orgNot;
	}
	public void setOrgNot(String orgNot) {
		this.orgNot = orgNot;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getLocationNot() {
		return locationNot;
	}
	public void setLocationNot(String locationNot) {
		this.locationNot = locationNot;
	}
	public String getPerson() {
		return person;
	}
	public void setPerson(String person) {
		this.person = person;
	}
	public String getPersonNot() {
		return personNot;
	}
	public void setPersonNot(String personNot) {
		this.personNot = personNot;
	}
	public String getDateFrom() {
		return dateFrom;
	}
	public void setDateFrom(String dateFrom) {
		this.dateFrom = dateFrom;
	}
	public String getDateTo() {
		return dateTo;
	}
	public void setDateTo(String dateTo) {
		this.dateTo = dateTo;
	}
	public String getDateFromGr() {
		return dateFromGr;
	}
	public void setDateFromGr(String dateFromGr) {
		this.dateFromGr = dateFromGr;
	}
	public String getDateToGr() {
		return dateToGr;
	}
	public void setDateToGr(String dateToGr) {
		this.dateToGr = dateToGr;
	}
	public String getAdvFilter() {
		return advFilter;
	}
	public void setAdvFilter(String advFilter) {
		this.advFilter = advFilter;
	}
	public String getSortFilter() {
		return sortFilter;
	}
	public void setSortFilter(String sortFilter) {
		this.sortFilter = sortFilter;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getArticleId() {
		return articleId;
	}
	public void setArticleId(String articleId) {
		this.articleId = articleId;
	}
	public String getIsDashBord() {
		return isDashBord;
	}
	public void setIsDashBord(String isDashBord) {
		this.isDashBord = isDashBord;
	}
	public String getSentimentFilter() {
		return sentimentFilter;
	}
	public void setSentimentFilter(String sentimentFilter) {
		this.sentimentFilter = sentimentFilter;
	}
	public String getIsMarked() {
		return isMarked;
	}
	public void setIsMarked(String isMarked) {
		this.isMarked = isMarked;
	}
	public String getKeywordFilter2() {
		return keywordFilter2;
	}
	public void setKeywordFilter2(String keywordFilter2) {
		this.keywordFilter2 = keywordFilter2;
	}
	@Override
	public String toString() {
		return "WebsiteInputVo [rowNum=" + rowNum + ", source=" + source + ", sourceNot=" + sourceNot + ", author="
				+ author + ", authorNot=" + authorNot + ", org=" + org + ", orgNot=" + orgNot + ", location=" + location
				+ ", locationNot=" + locationNot + ", person=" + person + ", personNot=" + personNot + ", country="
				+ country + ", countryNot=" + countryNot + ", countryCode=" + countryCode + ", dateFrom=" + dateFrom
				+ ", dateTo=" + dateTo + ", dateFromGr=" + dateFromGr + ", dateToGr=" + dateToGr + ", advFilter="
				+ advFilter + ", sortFilter=" + sortFilter + ", articleId=" + articleId + ", isDashBord=" + isDashBord
				+ ", sentimentFilter=" + sentimentFilter + ", priorityFilter=" + priorityFilter + ", priority="
				+ priority + ", isMarked=" + isMarked + ", keywordFilter2=" + keywordFilter2 + ", keywordFilter="
				+ keywordFilter + ", type=" + type + ", caseId=" + caseId + ", entityId=" + entityId + ", isRpt="
				+ isRpt + ", id=" + id + ", noArt=" + noArt + ", noSrc=" + noSrc + ", noAthr=" + noAthr + ", noPer="
				+ noPer + ", noPlace=" + noPlace + ", noOrg=" + noOrg + ", entityKeyword=" + entityKeyword
				+ ", entityIds=" + entityIds + ", sourceType=" + sourceType + ", stateName=" + stateName + ", cityName="
				+ cityName + ", countryFilter=" + countryFilter + ", stateFilter=" + stateFilter + ", cityFilter="
				+ cityFilter + ", languageFilter=" + languageFilter + ", newsModeFilter=" + newsModeFilter
				+ ", caseName=" + caseName + ", dateOfCreation=" + dateOfCreation + ", caseType=" + caseType
				+ ", analysisType=" + analysisType + ", mark=" + mark + ", isAnalysis=" + isAnalysis + ", userId="
				+ userId + "]";
	}
}

