package com.cdac.sudarshan.folder.repository;

import com.cdac.sudarshan.folder.model.SubFolderPaths;
import com.cdac.sudarshan.folder.model.UrlsPath;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public interface UrlsPathRepo extends JpaRepository<UrlsPath, Long> {
	@Query(value = "select u.url from UrlsPath u where u.subFolderPaths.id = :subFolderId")
	List<String> findUrlBySubFolerPathId(Long subFolderId);

//	@Query(value = "select u.url from UrlsPath u where u.subFolderPaths.id = :subFolderId and u.tag = :tag")
//	List<String> findUrlBySubFolderPathIdAndTag(@Param("subFolderId") Long subFolderId,@Param("tag") String tag);
	
	@Query(value = "select u from UrlsPath u where u.subFolderPaths.id = :subFolderId and u.tag = :tag")
	List<UrlsPath> findUrlBySubFolderPathIdAndTag(@Param("subFolderId") Long subFolderId,@Param("tag") String tag);
	
//	@Query(value = "select u.url from UrlsPath u where u.subFolderPaths.id = :subFolderId and u.tag = :tag and u.profileId = :profileId")
//	List<String> findUrlBySubFolderPathIdAndTagAndProfileId(@Param("subFolderId") Long subFolderId,@Param("tag") String tag,@Param("profileId") String profileId);
	
	@Query(value = "select u.url from UrlsPath u where u.rootFolderId = :rootFolderId and u.tag = :tag and u.profileId = :profileId")
	List<String> findUrlByRootFolderIdAndTagAndProfileId(@Param("rootFolderId") Long rootFolderId,@Param("tag") String tag,@Param("profileId") String profileId);
	
	@Query(value = "select u.url from UrlsPath u where u.rootFolderId = :rootFolderId")
	List<String> findByRootFolderId(@Param("rootFolderId") Long rootFolderId);

//	@Query(value = "select u.url from UrlsPath u where u.rootFolderId = :rootFolderId and u.tag = :tag")
//	List<String> findByRootFolderIdAndTag(@Param("rootFolderId") Long rootFolderId,@Param("tag") String tag);
	
	@Query(value = "select u from UrlsPath u where u.rootFolderId = :rootFolderId and u.tag = :tag")
	List<UrlsPath> findByRootFolderIdAndTag(@Param("rootFolderId") Long rootFolderId,@Param("tag") String tag);

	List<UrlsPath> findBySubFolderPaths(SubFolderPaths paths);
	
	@Query(value = "select u from UrlsPath u where u.subFolderPaths.id = :subFolderId and u.url = :url")
	UrlsPath findBySubFolderIdAndUrl(@Param("subFolderId") Long subFolderId, @Param("url") String url);
	
//	@Query(value = "select u from UrlsPath u where u.rootFolderid = :rootFolderId and u.url = :url")
//	UrlsPath findByRootFolderIdAndUrl(@Param("rootFolderId") Long rootFolderId, @Param("url") String url);
	UrlsPath findByRootFolderIdAndUrl(Long rootFolderId, String url);
	//@Query(value = "select u from UrlsPath u where u.subFolderPaths.id = :subFolderIdand u.url = :url")
	@Query(value = "select * from urls_paths u where u.sub_folder_id=:subFolderId and u.url=:url",nativeQuery = true)
	UrlsPath findByUrlAndSubFolderPathsId(Long subFolderId,String url);
	
	UrlsPath findByUrl(String url);

	UrlsPath findByRootFolderIdAndProfileId(Long rootFolderId,String profileId);

	@Query(value = "select u from UrlsPath u where u.subFolderPaths.id = :subFolderId and u.profileId = :profileId")
	UrlsPath findBySubFolderIdAndProfileId(@Param("subFolderId") Long subFolderId, @Param("profileId") String profileId);

//	@Query(value = "select u.id from UrlsPath u where u.rootFolderId = :rootFolderId")
//	ArrayList<Long> findUrlsByRootFolderId(@Param("rootFolderId") Long rootFolderId);

	@Query(value = "select u from UrlsPath u where u.rootFolderId = :rootFolderId")
	ArrayList<UrlsPath> findUrlsByRootFolderId(@Param("rootFolderId") Long rootFolderId);


//	@Query(value = "select u.id from UrlsPath u where u.subFolderPaths.id = :subFolderId")
//	ArrayList<Long> findUrlsBySubFolerPathId(Long subFolderId);

	@Query(value = "select u from UrlsPath u where u.subFolderPaths.id = :subFolderId")
	ArrayList<UrlsPath> findUrlsBySubFolderPathId(Long subFolderId);


	@Query("delete from UrlsPath u where u.id in(:urlsPathIds)")
	void deleteByIdIn(List<Long> urlsPathIds);

	@Query(value = "select u from UrlsPath u where u.subFolderPaths.id = :subFolderId and u.url in(:urls)")
	List<UrlsPath> findByUrlsAndSubFolderId(@Param("urls") List<String> urlList,@Param("subFolderId") Long SubFolderId);

	@Query(value = "select u from UrlsPath u where u.rootFolderId = :rootFolderId and u.url in(:urls)")
	List<UrlsPath> findByUrlsAndRooFolderId(@Param("urls") List<String> urlList,@Param("rootFolderId") Long rootFolderId);

	@Query(value = "select u from UrlsPath u where u.subFolderPaths.id = :subFolderId and u.profileId in(:profileIdList)")
	List<UrlsPath> findByProfileIdAndSubFolderId(@Param("profileIdList") List<String> profileIdList,@Param("subFolderId") Long SubFolderId);

	@Query(value = "select u from UrlsPath u where u.rootFolderId = :rootFolderId and u.profileId in(:profileIdList)")
	List<UrlsPath> findByProfileAndRooFolderId(@Param("profileIdList") List<String> profileIdList,@Param("rootFolderId") Long rootFolderId);





}
