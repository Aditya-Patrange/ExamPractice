package com.cdac.sudarshan.discover.model;

import java.io.Serializable;
import java.util.ArrayList;

public class Fb_Page implements Serializable 
{
	private static final long serialVersionUID = 1L;
	private String pageId;
	private String pageName;
	private String pageUserName;
	private String pageCountry;
	private String pageCity;
	private String pageZip;
	private String pageCoverSource;
	private String pageAbout;
	private String pageLink;
	private String pagePhone;
	private String pageDescription;
	private String pageWebsite;
	private String pageCategory;
	private int pageCheckins;
	private int pageLikeCount;
	private int pageWereHereCount;
	private ArrayList<Fb_User> pageLikeUser=new ArrayList<Fb_User>();
	
	public ArrayList<Fb_User> getPageLikeUser() {
		return pageLikeUser;
	}
	public void setPageLikeUser(ArrayList<Fb_User> pageLikeUser) {
		this.pageLikeUser = pageLikeUser;
	}
	public String getPageId() {
		return pageId;
	}
	public void setPageId(String pageId) {
		this.pageId = pageId;
	}
	public String getPageName() {
		return pageName;
	}
	public void setPageName(String pageName) {
		this.pageName = pageName;
	}
	public String getPageUserName() {
		return pageUserName;
	}
	public void setPageUserName(String pageUserName) {
		this.pageUserName = pageUserName;
	}
	public String getPageCountry() {
		return pageCountry;
	}
	public void setPageCountry(String pageCountry) {
		this.pageCountry = pageCountry;
	}
	public String getPageCity() {
		return pageCity;
	}
	public void setPageCity(String pageCity) {
		this.pageCity = pageCity;
	}
	public String getPageZip() {
		return pageZip;
	}
	public void setPageZip(String pageZip) {
		this.pageZip = pageZip;
	}
	public String getPageCoverSource() {
		return pageCoverSource;
	}
	public void setPageCoverSource(String pageCoverSource) {
		this.pageCoverSource = pageCoverSource;
	}
	public String getPageAbout() {
		return pageAbout;
	}
	public void setPageAbout(String pageAbout) {
		this.pageAbout = pageAbout;
	}
	public String getPageLink() {
		return pageLink;
	}
	public void setPageLink(String pageLink) {
		this.pageLink = pageLink;
	}
	public String getPagePhone() {
		return pagePhone;
	}
	public void setPagePhone(String pagePhone) {
		this.pagePhone = pagePhone;
	}
	public String getPageDescription() {
		return pageDescription;
	}
	public void setPageDescription(String pageDescription) {
		this.pageDescription = pageDescription;
	}
	public String getPageWebsite() {
		return pageWebsite;
	}
	public void setPageWebsite(String pageWebsite) {
		this.pageWebsite = pageWebsite;
	}
	public String getPageCategory() {
		return pageCategory;
	}
	public void setPageCategory(String pageCategory) {
		this.pageCategory = pageCategory;
	}
	public int getPageCheckins() {
		return pageCheckins;
	}
	public void setPageCheckins(int pageCheckins) {
		this.pageCheckins = pageCheckins;
	}
	public int getPageLikeCount() {
		return pageLikeCount;
	}
	public void setPageLikeCount(int pageLikeCount) {
		this.pageLikeCount = pageLikeCount;
	}
	public int getPageWereHereCount() {
		return pageWereHereCount;
	}
	public void setPageWereHereCount(int pageWereHereCount) {
		this.pageWereHereCount = pageWereHereCount;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "Fb_Page [pageId=" + pageId + ", pageName=" + pageName + ", pageUserName=" + pageUserName
				+ ", pageCountry=" + pageCountry + ", pageCity=" + pageCity + ", pageZip=" + pageZip
				+ ", pageCoverSource=" + pageCoverSource + ", pageAbout=" + pageAbout + ", pageLink=" + pageLink
				+ ", pagePhone=" + pagePhone + ", pageDescription=" + pageDescription + ", pageWebsite=" + pageWebsite
				+ ", pageCategory=" + pageCategory + ", pageCheckins=" + pageCheckins + ", pageLikeCount="
				+ pageLikeCount + ", pageWereHereCount=" + pageWereHereCount + ", pageLikeUser=" + pageLikeUser + "]";
	}
	
}
