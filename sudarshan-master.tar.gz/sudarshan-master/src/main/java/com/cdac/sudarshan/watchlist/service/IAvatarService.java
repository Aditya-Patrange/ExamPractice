package com.cdac.sudarshan.watchlist.service;

import java.util.HashMap;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public interface IAvatarService {

	public ResponseEntity<?> getAvatarList(HashMap<String, Object> data);

	public ResponseEntity<?> addNewAvatar(HashMap<String, Object> data);

	public ResponseEntity<?> selectAllProxy(HashMap<String, Object> data);

	public ResponseEntity<?> selectProxyById(HashMap<String, Object> data);

	public ResponseEntity<?> addNewProxy(HashMap<String, Object> data);

	public ResponseEntity<?> selectAllMaster(HashMap<String, Object> data);

	public ResponseEntity<?> updateAvatar(HashMap<String, Object> data);

	public ResponseEntity<?> selectAvatarById( String id , HashMap<String, Object> data);

	public ResponseEntity<?> deleteAvatarById(String id);
	
	public ResponseEntity<?> updateProxy(HashMap<String, Object> data);

	public ResponseEntity<?> deleteProxyById(String id);

	
}
