package com.cdac.sudarshan.discover.common;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.Proxy;
import java.net.URL;
import java.security.MessageDigest;
import java.text.DateFormat;
import java.text.Format;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.io.output.ByteArrayOutputStream;
import org.apache.commons.lang3.time.DateUtils;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.cdac.sudarshan.discover.model.LocationPoints;
import com.cdac.sudarshan.discover.model.TweeterActionVo;
import com.cdac.sudarshan.discover.model.TwitterVo;
//import com.innefu.innsight.cases.manager.CaseManagerInn;
//import com.innefu.innsight.facebook.vo.FbInputVo;
//import com.innefu.innsight.insta.vo.InstaInputVo;
//import com.innefu.innsight.twitter.vo.EdgeVo;
//import com.innefu.innsight.twitter.vo.LinkAnalysisVo;
//import com.innefu.innsight.twitter.vo.LocationPoints;
//import com.innefu.innsight.twitter.vo.NodeVo;
//import com.innefu.innsight.twitter.vo.TweeterActionVo;
//import com.innefu.innsight.twitter.vo.TwitterVo;
//import com.innefu.innsight.website.vo.WebsiteInputVo;
//import com.innefu.innsight.youtube.vo.YoutubeInputVo;
import com.restfb.DefaultFacebookClient;
import com.restfb.FacebookClient.AccessToken;
import com.restfb.Version;

import io.searchbox.client.JestClient;
import io.searchbox.client.JestResult;
import io.searchbox.core.Search;
import io.searchbox.core.SearchResult;
import io.searchbox.core.SearchScroll;
import io.searchbox.params.Parameters;
import twitter4j.RateLimitStatus;
import twitter4j.Twitter;
import twitter4j.TwitterFactory;
import twitter4j.conf.ConfigurationBuilder;

@Component
@SuppressWarnings("unused")
public class TwitterConstant 
{
	@Autowired
	HttpSession httpSession;
	
	@Autowired
	CaseManagerInn caseManagerInn;
	
	private static String oauth_consumerKey;
	private static String oauth_consumerSecret;
	private static String oauth_accessToken;
	private static String oauth_accessTokenSecret;
	private static String debug;
	private static String prettyDebug;
	private static String fbOAuthAppId;
	private static String fbOAuthAppSecret;
	private static String db;
	private static String pwd;
	private static String twuid;
	private static String twapikey;
	private static String youtubeLevel;
	private static String activeCaseCount;
	private static String client;
	private static String fbhour;
	private static String twitterFollowerCursor;
	private static String twStart;
	private static String twStop;
	private static String mca;
	private static String kloutApiKey;
	private static String instaDay;
	private static String ytApiKey;
	private static String ytChannelReturn;
	private static String elsserver;
	private static String dbname,typename;
	private static String gpDay;
	private static String newsDay;
	private static String selenium;
	private static String gpkey,tmkey,gbkey,instakey,gcx,ytDay;
	private static String batchJobServerIp, batchJobServerUsername, batchJobServerPassword;
	private static String instauserid,instauserpass,fbuserid,fbuserpass;
	private static String wtsdbname;
	private static String wtstypename;
	private static String innsightImageFlag;
	private static String innsightLocalImageUrl;
	private static String facebookLocalImageUrl; 
	private static String linkAnalysisImageUrl;
	private static String telegramImageUrl;
	private static String whatsappImageUrl;
	private static String whatsappImageWriteAbsUrl;
	private static String prophecyDataUrl;
	private static String hideWhatsappSenderFlag;
	private static String ngServiceUrl;
	private static String ftpFileUrl;
	private static String userTemplate;
	private static String defaultDaysOfDataLoad;
	private static String articlePriorityFlag;
	private static String twoPageReportFlag;
	private static String personProfile;
	private static String suspectPhotos;
	private static String jasperFilePath;
	private static String suspectPhotosRender;
	private static String frsServerURL;
	private static String imageDbName;
	private static String imageDbType;
	private static String dynamicHost;
	private static String userCreationLimit;
	private static String clientName;
	private static String globalClientId;
	private static String cloudURL;
	private static String centralCrawlingServerURL;
	private static String twoFA;
	private static String twoFAHostname;
	private static String twoFAAppId;
	private static String twoFAIP;	
	private static String ldap;
	private static String ldapHostname;
	private static String ldapDomainName;
	private static String telegramGroupUpdate;
	private static String caseFileAttachmentPath;
	private static String caseFileAttachmentUrl;
	private static String exportReportFolderPath;
	private static String exportReportFolderUrl;
	private static String baseUrl;
	private static String nextcloudDataPath;
	private static String googleApiKey;
	private static String threatKeywordUrl;
	private static String threatClassificationFlag;
	private static String odsServerUrl;
	//private static String profileFinderSources;

	@Value("${newsDay}")
	private String newsDay1;

	@Value("${batchJobServerIp}")
	private String batchJobServerIp1;

	@Value("${batchJobServerUsername}")
	private String batchJobServerUsername1;

	@Value("${batchJobServerPassword}")
	private String batchJobServerPassword1;

	@Value("${ytDay}")
	private String ytDay1;
	
	@Value("${typename}")
	private String typename1;
	
	@Value("${gcx}")
	private String gcx1;
	
	@Value("${gpkey}")
	private String gpkey1;
	
	@Value("${tmkey}")
	private String tmkey1;
	
	@Value("${gbkey}")
	private String gbkey1;
	
	@Value("${instakey}")
	private String instakey1;

	@Value("${selenium}")
	private String selenium1;

	@Value("${instauserid}")
	private String instauserid1;

	@Value("${instauserpass}")
	private String instauserpass1;

	@Value("${gpDay}")
	private String gpDay1;

	@Value("${dbname}")
	private String dbname1;

	@Value("${elsserver}")
	private String elsserver1;

	@Value("${ytchannelreturn}")
	private String ytChannelReturn1;

	@Value("${youtube.apikey}")
	private String ytApiKey1;

	@Value("${instaDay}")
	private String instaDay1;

	@Value("${kloutApiKey}")
	private String kloutApiKey1;

	@Value("${oauth.consumerKey}")
	private String oauth_consumerKey1;
	
	@Value("${oauth.consumerSecret}")
	private String oauth_consumerSecret1;
	
	@Value("${oauth.accessToken}")
	private String oauth_accessToken1;
	
	@Value("${oauth.accessTokenSecret}")
	private String oauth_accessTokenSecret1;
	
	@Value("${debug}")
	private String debug1;
	
	@Value("${http.prettyDebug}")
	private String prettyDebug1;
	
	@Value("${fbOAuthAppId}")
	private String fbOAuthAppId1;
	
	@Value("${fbOAuthAppSecret}")
	private String fbOAuthAppSecret1;

	@Value("${db}")
	private String db1;

	@Value("${pwd}")
	private String pwd1;

	@Value("${twuid}")
	private String twuid1;

	@Value("${twapikey}")
	private String twapikey1;

	@Value("${youtubeLevel}")
	private String youtubeLevel1;

	@Value("${activeCaseCount}")
	private String activeCaseCount1;

	@Value("${client}")
	private String client1;

	@Value("${fbhour}")
	private String fbhour1;

	@Value("${twitterFollowerCursor}")
	private String twitterFollowerCursor1;

	@Value("${twStart}")
	private String twStart1;

	@Value("${twStop}")
	private String twStop1;

	@Value("${mca}")
	private String mca1;

	@Value("${fbuserid}")
	private String fbuserid1;
	
	@Value("${fbuserpass}")
	private String fbuserpass1;
					
	@Value("${suspectPhotosRender}")
	private String suspectPhotosRender1;
	
	@Value("${frsServerURL}")
	private String frsServerURL1;
	
	@Value("${imageDbName}")
	private String imageDbName1;
	
	@Value("${imageDbType}")
	private String imageDbType1;
	
	@Value("${dynamicHost}")
	private String dynamicHost1;
	
	@Value("${userCreationLimit}")
	private String userCreationLimit1;
		
	@Value("${wtsdbname}")
	private String wtsdbname1;

	@Value("${wtstypename}")
	private String wtstypename1;

	@Value("${innsightImageFlag}")
	private String innsightImageFlag1;
	
	@Value("${ngServiceUrl}")
	private String ngServiceUrl1;
	
	@Value("${ftpFileUrl}")
	private String ftpFileUrl1;
	
	@Value("${innsightLocalImageUrl}")
	private String innsightLocalImageUrl1;
	
	@Value("${facebookLocalImageUrl}")
	private String facebookLocalImageUrl1;
	
	@Value("${linkAnalysisImageUrl}")
	private String linkAnalysisImageUrl1;
	
	@Value("${telegramImageUrl}")
	private String telegramImageUrl1;
	
	@Value("${whatsappImageUrl}")
	private String whatsappImageUrl1;
	
	@Value("${whatsappImageWriteAbsUrl}")
	private String whatsappImageWriteAbsUrl1;
	
	@Value("${prophecyDataUrl}")
	private String prophecyDataUrl1;
	
	@Value("${hideWhatsappSenderFlag}")
	private String hideWhatsappSenderFlag1;
	
	@Value("${defaultDaysOfDataLoad}")
	private String defaultDaysOfDataLoad1;
		
	@Value("${articlePriorityFlag}")
	private String articlePriorityFlag1;
	
	@Value("${twoPageReportFlag}")
	private String twoPageReportFlag1;
	
	@Value("${personProfile}")
	private String personProfile1;
	
	@Value("${suspectPhotos}")
	private String suspectPhotos1;
	
	@Value("${jasperFilePath}")
	private String jasperFilePath1;
	
	@Value("${clientName}")
	private String clientName1;
	
	@Value("${globalClientId}")
	private String globalClientId1;
	
	@Value("${cloudURL}")
	private String cloudURL1;
	
	@Value("${centralCrawlingServerURL}")
	private String centralCrawlingServerURL1;
	
	@Value("${twoFA}")
	private String twoFA1;
	
	@Value("${twoFAHostname}")
	private String twoFAHostname1;
	
	@Value("${twoFAAppId}")
	private String twoFAAppId1;
	
	@Value("${twoFAIP}")
	private String twoFAIP1;
	
	@Value("${ldap}")
	private String ldap1;
	
	@Value("${ldapHostname}")
	private String ldapHostname1;
	
	@Value("${ldapDomainName}")
	private String ldapDomainName1;
	
	@Value("${telegramGroupUpdate}")
	private String telegramGroupUpdate1;
	
	@Value("${caseFileAttachmentPath}")
	private String caseFileAttachmentPath1;
	
	@Value("${caseFileAttachmentUrl}")
	private String caseFileAttachmentUrl1;
	
	@Value("${exportReportFolderPath}")
	private String exportReportFolderPath1;
	
	@Value("${exportReportFolderUrl}")
	private String exportReportFolderUrl1;
	
	@Value("${baseUrl}")
	private String baseUrl1;
	
	@Value("${nextcloudDataPath}")
	private String nextcloudDataPath1;
	
	@Value("${googleApiKey}")
	private String googleApiKey1;
	
	@Value("${threatKeywordUrl}")
	private String threatKeywordUrl1;
	
	@Value("${threatClassificationFlag}")
	private String threatClassificationFlag1;
	
	@Value("${odsServerUrl}")
	private String odsServerUrl1;
	
	//@Value("${profileFinderSources}")
	//private String profileFinderSources1;
	
	@PostConstruct
	public void init()
	{		
		oauth_consumerKey = oauth_consumerKey1;
		oauth_consumerSecret=oauth_consumerSecret1;
		oauth_accessToken=oauth_accessToken1;
		oauth_accessTokenSecret=oauth_accessTokenSecret1;
		debug=debug1;
		prettyDebug=prettyDebug1;
		fbOAuthAppId=fbOAuthAppId1;
		fbOAuthAppSecret=fbOAuthAppSecret1;
		db=db1;
		pwd=pwd1;
		twuid=twuid1;
		twapikey=twapikey1;
		youtubeLevel=youtubeLevel1;
		activeCaseCount=activeCaseCount1;
		client=client1;
		fbhour=fbhour1;
		twitterFollowerCursor=twitterFollowerCursor1;
		twStart=twStart1;
		twStop=twStop1;
		mca=mca1;
		kloutApiKey=kloutApiKey1;
		instaDay=instaDay1;
		ytApiKey=ytApiKey1;
		ytChannelReturn=ytChannelReturn1;
		elsserver=elsserver1;
		dbname=dbname1;
		gpDay=gpDay1;
		selenium=selenium1;
		instauserid=instauserid1;
		instauserpass=instauserpass1;
		gpkey=gpkey1;
		tmkey=tmkey1;
		gbkey=gbkey1;
		instakey=instakey1;
		gcx=gcx1;
		typename=typename1;
		ytDay=ytDay1;
		batchJobServerIp = batchJobServerIp1;
		batchJobServerUsername = batchJobServerUsername1;
		batchJobServerPassword= batchJobServerPassword1;
		newsDay=newsDay1;
		fbuserid=fbuserid1;
		fbuserpass=fbuserpass1;
		wtsdbname=wtsdbname1;
		wtstypename=wtstypename1;
		innsightImageFlag=innsightImageFlag1;
		ngServiceUrl=ngServiceUrl1;
		ftpFileUrl=ftpFileUrl1;
		innsightLocalImageUrl=innsightLocalImageUrl1;
		facebookLocalImageUrl=facebookLocalImageUrl1; 
		linkAnalysisImageUrl=linkAnalysisImageUrl1; 
		telegramImageUrl=telegramImageUrl1;
		whatsappImageUrl=whatsappImageUrl1;
		whatsappImageWriteAbsUrl=whatsappImageWriteAbsUrl1;
		prophecyDataUrl=prophecyDataUrl1;
		hideWhatsappSenderFlag=hideWhatsappSenderFlag1;
		
		defaultDaysOfDataLoad=defaultDaysOfDataLoad1;
		articlePriorityFlag=articlePriorityFlag1;
		twoPageReportFlag=twoPageReportFlag1;
		personProfile=personProfile1;
		suspectPhotos=suspectPhotos1;
		jasperFilePath=jasperFilePath1;
		suspectPhotosRender=suspectPhotosRender1;
		frsServerURL=frsServerURL1;
		imageDbName=imageDbName1;
		imageDbType=imageDbType1;
		dynamicHost=dynamicHost1;
		userCreationLimit=userCreationLimit1;
		clientName=clientName1;
		globalClientId=globalClientId1;
		cloudURL=cloudURL1;
		centralCrawlingServerURL=centralCrawlingServerURL1;
		twoFA=twoFA1;
		twoFAHostname=twoFAHostname1;
		twoFAAppId=twoFAAppId1;
		twoFAIP=twoFAIP1;
		ldap=ldap1;
		ldapHostname=ldapHostname1;
		ldapDomainName=ldapDomainName1;
		telegramGroupUpdate=telegramGroupUpdate1;
		caseFileAttachmentPath=caseFileAttachmentPath1;
		caseFileAttachmentUrl=caseFileAttachmentUrl1;
		exportReportFolderPath=exportReportFolderPath1;
		exportReportFolderUrl=exportReportFolderUrl1;
		baseUrl=baseUrl1;
		nextcloudDataPath=nextcloudDataPath1;
		googleApiKey=googleApiKey1;
		threatKeywordUrl=threatKeywordUrl1;
		threatClassificationFlag=threatClassificationFlag1;
		odsServerUrl=odsServerUrl1;
		
		//profileFinderSources=profileFinderSources1;
	} 

	
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
	//static final String DB_URL = "jdbc:mysql://192.168.1.100/twitter";

	//  Database credentials
	public  static final String USER = "root";
	//static final String PASS = "123456789";
	
	public static String escapeString(String val) {
		if(val !=null && !val.equals("")) {
			val=val.replace("'", "\\'");
		}
		return val;
	}
	
	public static String dateFormat(Date date)
	{
		Format formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return formatter.format(date);
	}

	public static String getSqlCurrentDateTime()
	{
		java.util.Date dt = new java.util.Date();
		java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return sdf.format(dt);
	}

	public static DateTime dateTwitterFormat(String date)
	{
		/*
		          DateTimeFormatter format = 
		          DateTimeFormat.forPattern("EEE, dd MMM yyyy HH:mm:ss Z").withLocale(Locale.ENGLISH);
		          DateTime dateTime = format.parseDateTime(date);
		          return dateTime;
		 */
		date=date.replace("IST","").replace("  "," ");
		DateTimeFormatter format = 
				DateTimeFormat.forPattern("EEE MMM dd HH:mm:ss YYYY").withLocale(Locale.ENGLISH);
		DateTime dateTime = format.parseDateTime(date);
		return dateTime;
	}

	public static int getInstaDay()
	{
		return Integer.parseInt(instaDay); 
	} 
	
	public static int getYouTubeDay()
	{
		return Integer.parseInt(ytDay); 
	}

	public static String getWhatsAppDatabase()
	{
		return wtsdbname;
	}
	
	public static String getWhatsAppType()
	{
		return wtstypename;
	}
	
	public static String getkloutApi()
	{
		return   kloutApiKey;
	} 
	
	public static String getTwitterUid()
	{
		return   twuid;
	} 

	public static String getTwitterClient()
	{
		return client;
	} 

	public static String getTotalNoOfCase()
	{
		return activeCaseCount;
	} 

	public static String getTwitterApiKey()
	{
		return twapikey ;
	} 

	public static String getDBURL()
	{
		return db; 
	}

	public static String getDBPwd()
	{
		return pwd; 
	}

	public static int getFbHour()
	{
		return Integer.parseInt(fbhour); 
	}

	public static String getFbOAuthAppId()
	{
		return fbOAuthAppId;
	} 

	public static String getFbOAuthAppSecret()
	{
		return fbOAuthAppSecret;
	}

	public static String getTwitterConsumerKey()
	{
		return oauth_consumerKey;
	}
	
	public static String getTwitterConsumerSecret()
	{
		return oauth_consumerSecret;
	}

	public static String getTwitterAccessToken()
	{
		return oauth_accessToken;
	}

	public static String getTwitterAccessTokenSecret()
	{
		return oauth_accessTokenSecret;
	}

	public static String getTwitterFollowerCursor()
	{

		return twitterFollowerCursor;
	}

	public static String getTwitterStartCommand()
	{
		return twStart;
	}

	public static String getYoutubeApiKey()
	{
		return ytApiKey;
	}

	public static String getYtChannelReturn()
	{
		return ytChannelReturn;
	}

	public static void executeLinuxCommand(String[] command) 
	{
		StringBuffer output = new StringBuffer();
		try 
		{
			final Process p = Runtime.getRuntime().exec(command);
			p.waitFor();
			BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
			String line = "";			
			while ((line = reader.readLine())!= null) 
			{
				output.append(line + "\n");
			}  
		} 
		catch (Exception e) {
			e.printStackTrace();
		}
		//return output.toString();
	}

	public static String executeShellCommand(String[] command)
	{
		StringBuffer output = new StringBuffer();
		try 
		{
			final Process  p = Runtime.getRuntime().exec(command);
			//p.waitFor();
			/*BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
			String line = "";			
			while ((line = reader.readLine())!= null) {
				output.append(line + "\n");
			} 
			 */
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return output.toString();
	}

	public static String getTwitterStopCommand()
	{
		return twStop;
	}

	public static String getMcaCommand()
	{
		return mca;
	}

	public static String getTwitterSource(String src)
	{
		String source=src; 
		try
		{
			Document doc = Jsoup.parse(src);
			Element link = doc.select("a").first();
			source = link.attr("href") +" , "+  link.text(); // "example"
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		}
		return source;
	}

	public static Long convertDateToTimeStamp(String date)
	{
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		Date d1 = new Date();
		try 
		{
			d1 = df.parse(date);
		}
		catch(ParseException e) 
		{
			e.printStackTrace();
		}
		return d1.getTime();
	}
	
	public static Long convertDateToTimeStampFormat(String date)
	{
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date d1 = new Date();
		try 
		{
			d1 = df.parse(date);
		}
		catch(ParseException e) 
		{
			e.printStackTrace();
		}
		return d1.getTime();
	}
	
	
	public static String convertTimeStampToDate(long dateLong)
	{
		String strDate = "";
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		try 
		{
			//Date d = new Date((long)1481723817*1000);
			Date d = new Date(dateLong);
		    strDate = df.format(d);
		} 
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return strDate;
	}
	
	

	public static Date convertStrToDate(String date)
	{
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		Date d1 = new  Date();
		try 
		{
			d1 = df.parse(date);
		} 
		catch (ParseException e) 
		{
			e.printStackTrace();
		}
		return d1;
	}


	public static String getCurrentDate()
	{
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		Date dateobj = new Date();
		return df.format(dateobj);
	}

	public static String getYoutubeBeforeDateYYYYMMDD()
	{
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		Date dateobj = new Date();
		return df.format(dateobj);
	}

	public static String getYouTubeAfterDateYYYYMMDD()
	{
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		Date dateAfter = DateUtils.addDays(new Date(),-(getYouTubeDay()));
		return df.format(dateAfter);
	}

	public static Set<String> loadStopWords() 
	{
		try 
		{
			final List<String> lines = IOUtils.readLines(getInputStream("text/stop_words.txt"));
			return new HashSet<>(lines);
		} 
		catch(IOException e) 
		{
			e.printStackTrace();
		}
		return Collections.emptySet();
	}

	private static InputStream getInputStream(String path) 
	{
		return Thread.currentThread().getContextClassLoader().getResourceAsStream(path);
	}

	public static String splitCommonValues(String inputData)
	{
		String[] dataArr=inputData.split(",");
		String dataToFilter="";
		for(String data : dataArr) 
		{
			dataToFilter+="'"+data+"',";
		}
		dataToFilter=dataToFilter.substring(0, dataToFilter.length()-1);
		return dataToFilter;
	}

	public static boolean searchValueInArray(String inputData, String[] dataArr)
	{
		if(Arrays.asList(dataArr).contains(inputData))
		{
			return true;
		}
		else 
		{
			return false;
		}
	}

	public static int searchValueIndexInArray(String inputData,String[] dataArr)
	{
		return Arrays.asList(dataArr).indexOf(inputData);
	}

	public static ConfigurationBuilder createTwitterConfiguration()
	{
		ConfigurationBuilder cb = new ConfigurationBuilder();
		cb.setDebugEnabled(true)
		.setOAuthConsumerKey(getTwitterConsumerKey())
		.setOAuthConsumerSecret(getTwitterConsumerSecret())
		.setOAuthAccessToken(getTwitterAccessToken())
		.setOAuthAccessTokenSecret(getTwitterAccessTokenSecret());
		return cb;
	}

	public static facebook4j.conf.Configuration createFbConfiguration() 
	{
		facebook4j.conf.ConfigurationBuilder confBuilder = new facebook4j.conf.ConfigurationBuilder();
		confBuilder.setDebugEnabled(true);
		confBuilder.setOAuthAppId(getFbOAuthAppId());
		confBuilder.setOAuthAppSecret(getFbOAuthAppSecret());
		confBuilder.setUseSSL(true);
		confBuilder.setJSONStoreEnabled(true);
		facebook4j.conf.Configuration configuration = confBuilder.build();
		return configuration;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static String parseFollowersDataToJson(ArrayList<TwitterVo> follower_FollowingVos)
	{
		String finJson = "";
		List outd = new ArrayList();
		try 
		{
			StringBuilder json2 = new StringBuilder();
			StringBuilder json1 = new StringBuilder();
			int i =0;
//			System.out.println("Starting create json");
			for(TwitterVo follower_FollowingVo : follower_FollowingVos)
			{
				i+=1;
				if(i%1000==0)
				{
				}
				if(outd.indexOf(follower_FollowingVo.getUserId()) == -1)
				{    
					outd.add(follower_FollowingVo.getUserId());
					//json1+="{\"name\":\""+follower_FollowingVo.getFollwed()+"\",\"c\":\"0\",\"s\":\"0\"},";
					//json1.append("{\"name\":\""+follower_FollowingVo.getFollwed()+"\",\"c\":\"0\",\"s\":\"0\"},");
					json1.append("{\"name\":\""+follower_FollowingVo.getUserId()+"\",\"c\":\"0\",\"s\":\"0\",\"screenName\":\""+follower_FollowingVo.getUserId()+"\"},");
				}
				if(outd.indexOf(follower_FollowingVo.getUserName()) == -1)
				{    
					outd.add(follower_FollowingVo.getUserName());
					// json1.append("{\"name\":\""+follower_FollowingVo.getFollower()+"\",\"c\":\"0\",\"s\":\"0\"},");
					json1.append("{\"name\":\""+follower_FollowingVo.getUserName()+"\",\"c\":\"0\",\"s\":\"0\",\"screenName\":\""+follower_FollowingVo.getUserName()+"\"},");
				}
				String ss = "{\"source\":\""+follower_FollowingVo.getUserId()+"\",\"target\":\""+follower_FollowingVo.getUserName()+"\",\"value\":10},";
				//String ss2 ="{\"source\":\""+follower_FollowingVo.getFollower()+"\",\"target\":\""+follower_FollowingVo.getFollwed()+"\",\"value\":10},";
				//removing duplicates
				//if ((json2.indexOf(ss) == -1) & (json2.indexOf(ss2) == -1))
				{
					json2.append(ss);
				}
			}
			finJson = "{\"nodes\":["+json1.substring(0, json1.length()-1)+"],\"links\":["+json2.substring(0, json2.length()-1)+"]}";
			/**********************************************************/
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		}
		return finJson;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static LinkAnalysisVo parseFollowersDataToJsonObject(ArrayList<TwitterVo> follower_FollowingVos)
	{
		LinkAnalysisVo linkAnalysisVo=new LinkAnalysisVo();
		ArrayList<NodeVo> lstNode=new ArrayList<NodeVo>();
		ArrayList<EdgeVo> lstEdgeVo=new ArrayList<EdgeVo>();
		
		List outd = new ArrayList();
		try 
		{
			for(TwitterVo follower_FollowingVo : follower_FollowingVos) 
			{
				if(outd.indexOf(follower_FollowingVo.getNodeId1()) == -1)
				{    
					outd.add(follower_FollowingVo.getNodeId1());
					NodeVo nodeVo=new NodeVo();
					nodeVo.setId(follower_FollowingVo.getNodeId1());
					nodeVo.setName(follower_FollowingVo.getNodeName1());
					nodeVo.setScreenName(follower_FollowingVo.getNodeScreenName1());
					nodeVo.setImg(follower_FollowingVo.getNodeImg1());
					nodeVo.setP("0");
					lstNode.add(nodeVo);
					//json1.append("{\"name\":\""+follower_FollowingVo.getUserId()+"\",\"c\":\"0\",\"s\":\"0\",\"screenName\":\""+follower_FollowingVo.getUserId()+"\"},");
				}
				if(outd.indexOf(follower_FollowingVo.getNodeId2()) == -1)
				{    
					outd.add(follower_FollowingVo.getNodeId2());
					NodeVo nodeVo=new NodeVo();
					nodeVo.setId(follower_FollowingVo.getNodeId2());
					nodeVo.setName(follower_FollowingVo.getNodeName2());
					nodeVo.setScreenName(follower_FollowingVo.getNodeScreenName2());
					nodeVo.setImg(follower_FollowingVo.getNodeImg2());
					nodeVo.setP("1");
					lstNode.add(nodeVo);
				}

				EdgeVo edgeVo=new EdgeVo();
				edgeVo.setSource(follower_FollowingVo.getNodeScreenName1());
				edgeVo.setTarget(follower_FollowingVo.getNodeScreenName2());
				edgeVo.setValue(follower_FollowingVo.getNodeType());
				lstEdgeVo.add(edgeVo);
			}
			linkAnalysisVo.setNodes(lstNode);
			linkAnalysisVo.setLinks(lstEdgeVo);
			/**********************************************************/
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return linkAnalysisVo;
	}

	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static LinkAnalysisVo parseFBFriendsDataToJsonObject(ArrayList<TwitterVo> follower_FollowingVos)
	{
		LinkAnalysisVo linkAnalysisVo=new LinkAnalysisVo();
		ArrayList<NodeVo> lstNode=new ArrayList<NodeVo>();
		ArrayList<EdgeVo> lstEdgeVo=new ArrayList<EdgeVo>();
		
		List outd = new ArrayList();
		try 
		{
			for(TwitterVo follower_FollowingVo : follower_FollowingVos) 
			{
				if(outd.indexOf(follower_FollowingVo.getNodeId1()) == -1)
				{    
					outd.add(follower_FollowingVo.getNodeId1());
					NodeVo nodeVo=new NodeVo();
					nodeVo.setId(follower_FollowingVo.getNodeId1());
					nodeVo.setName(follower_FollowingVo.getNodeName1());
					nodeVo.setScreenName(follower_FollowingVo.getNodeScreenName1());
					nodeVo.setImg(follower_FollowingVo.getNodeImg1());
					nodeVo.setP("0");
					lstNode.add(nodeVo);
					
					//json1.append("{\"name\":\""+follower_FollowingVo.getUserId()+"\",\"c\":\"0\",\"s\":\"0\",\"screenName\":\""+follower_FollowingVo.getUserId()+"\"},");
				}
				if(outd.indexOf(follower_FollowingVo.getNodeId2()) == -1)
				{    
					outd.add(follower_FollowingVo.getNodeId2());
					NodeVo nodeVo=new NodeVo();
					nodeVo.setId(follower_FollowingVo.getNodeId2());
					nodeVo.setName(follower_FollowingVo.getNodeName2());
					nodeVo.setScreenName(follower_FollowingVo.getNodeScreenName2());
					nodeVo.setImg(follower_FollowingVo.getNodeImg2());
					nodeVo.setP("1");
					lstNode.add(nodeVo);
				}

				EdgeVo edgeVo=new EdgeVo();
				edgeVo.setSource(follower_FollowingVo.getNodeId1());
				edgeVo.setTarget(follower_FollowingVo.getNodeId2());
				edgeVo.setValue(follower_FollowingVo.getNodeType());
				lstEdgeVo.add(edgeVo);				
			}
			linkAnalysisVo.setNodes(lstNode);
			linkAnalysisVo.setLinks(lstEdgeVo);
			/**********************************************************/
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return linkAnalysisVo;
	}
	
	
	public static String dateFormatMMDDYY(Date date)
	{
		SimpleDateFormat format = new SimpleDateFormat();
		format = new SimpleDateFormat("MMMM dd, yyyy");
		return format.format(date);
	}

	public static int getNoOfDaysBetweenDates(Date dateFrom, Date dateTo)
	{
		float dTo = dateTo.getTime();
		float dFrom = dateFrom.getTime();
		float diff = dTo-dFrom;
		int dd = (Math.round(diff/(1000*60*60*24)));
		
		//System.out.println("dd========== "+dd);
		//return (Math.round((dateTo.getTime()-dateFrom.getTime())/(1000*60*60*24)));
		return dd;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static List getTwitterConfigObject(String apiKeys, String apiType)
	{
		List lst=new ArrayList<>();
		try
		{
			String[] apiKeyArray= apiKeys.split(",");
			ConfigurationBuilder cb = new ConfigurationBuilder();
			cb.setDebugEnabled(true)
			.setOAuthConsumerKey(apiKeyArray[0])
			.setOAuthConsumerSecret(apiKeyArray[1])
			.setOAuthAccessToken(apiKeyArray[2])
			.setOAuthAccessTokenSecret(apiKeyArray[3]);
			TwitterFactory tf = new TwitterFactory(cb.build());
			Twitter twitter= tf.getInstance();
			RateLimitStatus status = twitter.getRateLimitStatus().get(apiType);
			int remCalls = status.getRemaining();
			
			if(remCalls > 0)
			{
				lst.add(twitter);
				lst.add(remCalls);
			}
			else
			{
				lst.add(null);
				lst.add(0);
			}
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			lst.add(null);
			lst.add(0);
		}
		return lst;
	}

	public static String getStringDay(String day)
	{
		Map<String,String> mp=new HashMap <String,String> ();
		mp.put("0","Sunday");
		mp.put("1","Monday");
		mp.put("2","Tuesday");
		mp.put("3","Wednesday");
		mp.put("4","Thrusday");
		mp.put("5","Friday");
		mp.put("6","Saturday");
		return mp.get(day);
	}

	public static String getStringDayOfWeek(String day)
	{
		Map<String,String> mp=new HashMap <String,String> ();
		mp.put("0","12am");
		mp.put("1","1am");
		mp.put("2","2am");
		mp.put("3","3am");
		mp.put("4","4am");
		mp.put("5","5am");
		mp.put("6","6am");
		mp.put("7","7am");
		mp.put("8","8am");
		mp.put("9","9am");
		mp.put("10","10am");
		mp.put("11","11am");
		mp.put("12","12pm");
		mp.put("13","1pm");
		mp.put("14","2pm");
		mp.put("15","3pm");
		mp.put("16","4pm");
		mp.put("17","5pm");
		mp.put("18","6pm");
		mp.put("19","7pm");
		mp.put("20","8pm");
		mp.put("21","9pm");
		mp.put("22","10pm");
		mp.put("23","11pm");
		return mp.get(day);
	}

	public static DefaultFacebookClient defaultFacebookClientProvider()
	{
		DefaultFacebookClient facebookClient=null;
		try
		{
//			AccessToken accessToken =
//					new DefaultFacebookClient().obtainAppAccessToken(getFbOAuthAppId(), getFbOAuthAppSecret());
//			facebookClient = new DefaultFacebookClient(accessToken.getAccessToken(),Version.VERSION_2_5);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}	
	    return facebookClient;
	}

	public static String GetFbPageToCrawleDate()
	{
		Date dateBefore30Days = DateUtils.addDays(new Date(),-(getFbHour()));
		return Long.toString(dateBefore30Days.getTime()/1000);
		/*		
		Date today=new Date();
		long ltime=(System.currentTimeMillis()/1000)-getFbHour()*24*60*60*1000;
		return Long.toString(ltime/1000);
		 */	
	}

	public static String GetYotubeToCrawleDate()
	{
		Date dateBefore30Days = DateUtils.addDays(new Date(),-(getInstaDay()));
		return Long.toString(dateBefore30Days.getTime()/1000);
	}

	public static String GetInstaToCrawleDate()
	{
		Date dateBefore30Days = DateUtils.addDays(new Date(),-(getInstaDay()));
		return Long.toString(dateBefore30Days.getTime()/1000);
	}

	public static String GetGpToCrawleDate()
	{
		Date dateBefore30Days = DateUtils.addDays(new Date(),-(Integer.parseInt(getGpDay())));
		return Long.toString(dateBefore30Days.getTime()/1000);
	}

	public static String GetNewsToCrawleDate()
	{
		Date dateBefore30Days = DateUtils.addDays(new Date(),-(Integer.parseInt(getNewsDay())));
		return Long.toString(dateBefore30Days.getTime());
	}

	public static int checkCommandExcecution_old(String arg)
	{
		String s = "1";
		String cmd="ps -aux | grep innsight_batch-0.0.1.jar | grep -w "+arg +" | wc -l";
		try
		{
			Process p = Runtime.getRuntime().exec(new String[]{"bash","-c",cmd});
			p.waitFor();
			BufferedReader in = new BufferedReader(new InputStreamReader(p.getInputStream()));
			s = in.readLine();
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return Integer.parseInt(s);
	}

	public static void killProcesss_old(String arg)
	{
		String  cmd="kill -9 $(ps -aux |grep java|  grep \"innsight_batch-0.0.1.jar "+arg+"\"| awk '{ print $2 }')";
		try
		{
			Process p = Runtime.getRuntime().exec(new String[]{"bash","-c",cmd});
			p.waitFor();
			//Runtime.getRuntime().exec(cmd);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}

	public static int checkCommandExcecution(String arg)
	{
		int s = 1;
		String cmd="ps -aux | grep innsight_batch-0.0.1.jar | grep -w "+arg +" | wc -l";
		try
		{
			//Process p = Runtime.getRuntime().exec(new String[]{"bash","-c",cmd});
			//p.waitFor();
			//BufferedReader in = new BufferedReader(new InputStreamReader(p.getInputStream()));
			//s = in.readLine();
			String serverIp = TwitterConstant.getBatchJobServerIp();
			String usernameString = TwitterConstant.getBatchJobServerUsername();
			String password = TwitterConstant.getBatchJobServerPassword();

			String temp = SSHUtil.SSHClient(serverIp, cmd, usernameString, password);
			s = Integer.parseInt(temp);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return s;
	}

	public static void killProcesss(String arg)
	{
		String cmd="kill -9 $(ps -aux |grep java|  grep \"innsight_batch-0.0.1.jar "+arg+"\"| awk '{ print $2 }')";
		try
		{
			//Process p = Runtime.getRuntime().exec(new String[]{"bash","-c",cmd});
			//p.waitFor();
			//Runtime.getRuntime().exec(cmd);
			String serverIp = TwitterConstant.getBatchJobServerIp();
			String usernameString = TwitterConstant.getBatchJobServerUsername();
			String password = TwitterConstant.getBatchJobServerPassword();			
			SSHUtil.SSHClient(serverIp, cmd, usernameString, password);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}

	public static String getJsonForEs(String fieldName, String value)
	{
		String rtnJson= ",{\n"+
				"\"terms\": {\n"+
				"\""+fieldName+"\": [\n"+
				value+"\n"+
				"]\n"+
				"}\n"+
				"}\n";
		return rtnJson;
	}

	public static String getJsonForEsMatchPhrase(String value)
	{
		String rtnJson= ",{\n"+
				"\"match_phrase\": {\n"+
				"\"articleTitle\": \""+value+"\"\n"+		
				"}\n"+
				"}\n";		
		return rtnJson;
	}
	
	public static String getJsonForEsForExist(String fieldName)
	{
		String rtnJson= ",{\n"+
				"\"constant_score\": {\n"+
				"\"filter\": {\n"+
				"\"exists\": {\n"+
				"\"field\": \""+fieldName+"\"\n"+
				"}\n"+
				"}\n"+
				"}\n"+
				"}\n";
		return rtnJson;
	}

	public static String getJsonForEsForMissing(String fieldName,String value)
	{
		String	rtnJson= ",{\n"+
				"\"constant_score\": {\n"+
				"\"filter\": {\n"+
				"\"missing\": {\n"+
				"\"field\": \""+fieldName+"\"\n"+
				"}\n"+
				"}\n"+
				"}\n"+
				"}\n";
		return rtnJson;
	}

	public static String getJsonForEsQueryString(String fieldName, String value)
	{
		String rtnJson="";
		rtnJson= ",{\n"+
					"\"query\": {\n"+
					"\"query_string\": {\n"+
					//"\"default_field\": \""+fieldName+"\",\n"+
					"\"fields\": [\"articleTitle\",\"articleSubTitle\",\"articleBigContent\",\"metaData\",\"articleMediaCaption\",\"articleAuthor\",\"articleAuthorId\",\"facebook.fbPostPageName\",\"facebook.fbPage.pageId\",\"facebook.fbPage.pageName\",\"facebook.fbPage.pageUserName\",\"tweet.tweetUser.tweetUserDescription\"],\n"+
					"\"query\": \""+value+"\"\n"+
					"}\n"+
					"}\n"+
					"}\n";
		return rtnJson;
	}
	
	public static String getJsonForEsQueryStringCustomType(String fieldName, String value, String type)
	{
		//System.out.println("fieldName: "+fieldName);
		//System.out.println("value: "+value);
		//System.out.println("type: "+type);
		
		String rtnJson="";		
		if(type.equals("bool"))
		{
			rtnJson= ",{\n"+
					"\"query\": {\n"+
					"\"query_string\": {\n"+
					//"\"default_field\": \""+fieldName+"\",\n"+
					//"\"fields\": [\"articleTitle\",\"articleSubTitle\",\"articleBigContent\",\"articleMediaCaption\",\"articleAuthor\",\"articleAuthorId\",\"facebook.fbPostPageName\",\"facebook.fbPage.pageId\",\"facebook.fbPage.pageName\",\"facebook.fbPage.pageUserName\",\"tweet.tweetUser.tweetUserDescription\"],\n"+
					"\"fields\": [\"articleTitle\",\"articleSubTitle\",\"articleBigContent\",\"metaData\"],\n"+
					"\"query\": \""+value+"\"\n"+
					"}\n"+
					"}\n"+
					"}\n";
		}
		else if(type.equals("fuzzy"))
		{
			rtnJson=  ",{\n"+
					"\"query\": {\n"+
					"\"fuzzy\": {\n"+
					"\"articleTitle\": \""+value+"\"\n"+
					"}\n"+
					"}\n"+
					"}\n";
		}		
		else if(type.equals("proxy"))
		{
			String[] arr=value.split(",");
			String val=arr[0];
			String slop="2";
			if(arr.length==2)
			{
				slop=arr[1];
			}
			rtnJson=  ",{\n"+
					"\"query\": {\n"+
					"\"match_phrase\": {\n"+
					//"\"default_field\": \""+fieldName+"\",\n"+
					"\"articleTitle\":{\n"+
					"\"query\": \""+val+"\",\n"+
					"\"slop\": "+slop+"\n"+
					"}\n"+
					"}\n"+
					"}}\n";
		}
		return rtnJson;
	}
	
	

	public static String getJsonForEsQueryStringWithOutField(String value)
	{
		String rtnJson= ",{\n"+
				"\"query\": {\n"+
				"\"query_string\": {\n"+
				"\"lowercase_expanded_terms\": false,\n"+
				"\"query\": \""+value+"\"\n"+
				"}\n"+
				"}\n"+
				"}\n";
		return rtnJson;
	}

	public static String getESValueCountAggs(String fieldName)
	{
		String	rtnJson=",\"aggs\": {\n"+
				"\"types_count\": {\n"+
				"\"value_count\": {\n"+
				"\"field\": \""+fieldName+"\"\n"+
				"}\n"+
				"}\n"+
				"}\n";
		return rtnJson;
	}

	public static String getJsonForEsTerm(String fieldName, String value)
	{
		String rtnJson= ",{\n"+
				"\"term\": {\n"+
				"\""+fieldName+"\": \n"+
				value+"\n"+
				"\n"+
				"}\n"+
				"}\n";
		return rtnJson;
	}

	public static String getJsonForEsWildSearchTerm(String fieldName,String value)
	{
		String rtnJson= ",{\n"+
				"\"query\": {\n"+
				"\"wildcard\": {\n"+
				"\""+fieldName+"\": {\n"+
				"\"value\": \"*"+value+"*\"\n"+
				"}\n"+
				"}\n"+
				"}\n"+
				"}\n";
		return rtnJson;
	}

	public static String getJsonForEsTermLatLong(String lat,String longi)
	{
		String	rtnJson=  ",{\n"+
				"\"term\": {\n"+
				"\"latitude\": \n"+
				lat+"\n"+
				"\n"+
				"}\n"+
				",\"term\": {\n"+
				"\"longitude\": \n"+
				longi+"\n"+
				"\n"+
				"}\n"+
				"}\n";
		return rtnJson;
	}

	public static String getSortForEsTermAgg(String value) 
	{
		String sortQuery="";
		switch(value) 
		{
		case "cntasc":
			sortQuery="\"order\":{\"_count\":\"asc\"}\n";
			break;
		case "cntdesc":
			sortQuery="\"order\":{\"_count\":\"desc\"}\n";
			break;
		case "nameasc":
			sortQuery="\"order\":{\"_term\":\"asc\"}\n";
			break;
		case "namedesc":
			sortQuery="\"order\":{\"_term\":\"desc\"}\n";
			break;
		}
		return sortQuery;
	}

	public static int getSizeForEsTermAgg(TweeterActionVo tweeterActionVo, String rptCount) 
	{
		int size = 50;
		if(CommonUtils.stringNotEmpty(tweeterActionVo.getIsRpt())) 
		{
			if(CommonUtils.stringNotEmpty(rptCount))
			{
				size=Integer.parseInt(rptCount);
			}
		}
		else 
		{
			if(tweeterActionVo.getIsDashBord() != null && !tweeterActionVo.getIsDashBord().toLowerCase().trim().equals("y")) 
			{
				size=Integer.parseInt(tweeterActionVo.getRowNum())*50;
			} 
			else if(tweeterActionVo.getZRptFlag().equals("no"))
			{
				size=20;
			}
			else
			{
				size=5;
			}
		}
		return size;
	}

	public static int getSizeForEsTermAggInsta(InstaInputVo instaInputVo,String rptCount)
	{
		int size=50;	
		if(CommonUtils.stringNotEmpty(instaInputVo.getIsRpt()))
		{
			if(CommonUtils.stringNotEmpty(rptCount))
			{
				size=Integer.parseInt(rptCount);
			}
		}
		else
		{
			if(!instaInputVo.getIsDashBord().toLowerCase().trim().equals("y"))
			{
				size=Integer.parseInt(instaInputVo.getRowNum())*50;
			}
			else
			{
				size=6;
			}
		}
		return size;
	}

	public static int getSizeForEsTermAggYt(YoutubeInputVo youtubeInputVo,String rptCount)
	{
		int size=50;	
		if(CommonUtils.stringNotEmpty(youtubeInputVo.getIsRpt()))
		{
			if(CommonUtils.stringNotEmpty(rptCount))
			{
				size=Integer.parseInt(rptCount);
			}
		}
		else
		{
			if(!youtubeInputVo.getIsDashBord().toLowerCase().trim().equals("y"))
			{
				size=Integer.parseInt(youtubeInputVo.getRowNum())*50;
			}
			else
			{
				size=6;
			}
		}
		return size;
	}

	public static int getSizeForEsTermAggWebSite(WebsiteInputVo websiteInputVo,String rptCount)
	{
		int size=50;	
		if(CommonUtils.stringNotEmpty(websiteInputVo.getIsRpt()))
		{
			if(CommonUtils.stringNotEmpty(rptCount))
			{
				size=Integer.parseInt(rptCount);
			}
		}
		else
		{
			if(!websiteInputVo.getIsDashBord().toLowerCase().trim().equals("y"))
			{
				size=(websiteInputVo.getRowNum())*50;
			}
			else
			{
				size=6;
			}
		}
		return size;
	}

	public static int getSizeForEsTermAggFb(FbInputVo fbInputVo,String rptCount)
	{
		int size=50;	
		if(CommonUtils.stringNotEmpty(fbInputVo.getIsRpt()))
		{
			if(CommonUtils.stringNotEmpty(rptCount))
			{
				size=Integer.parseInt(rptCount);
			}
		}
		else
		{
			if(!fbInputVo.getIsDashBord().toLowerCase().trim().equals("y"))
			{
				size=Integer.parseInt(fbInputVo.getRowNum())*50;
			}
			else
			{
				size=6;
			}
		}
		return size;
	}

	public static String getElsserver()
	{
		return elsserver;
	}
	
	public static String getDbname() 
	{
		return dbname;
	}

	public static String getGpDay()
	{
		return gpDay;
	}

	public static String getNewsDay() 
	{
		return newsDay;
	}

	public static String getSelenium()
	{
		return selenium;
	}
	
	public static String getInstaUserId()
	{
		return instauserid;
	}
	
	public static String getInstaUserPass()
	{
		return instauserpass;
	}

	public static String getGpkey() 
	{
		return gpkey;
	}
	
	public static String getTmkey() 
	{
		return tmkey;
	}
	
	public static String getGbkey() 
	{
		return gbkey;
	}
	
	public static String getInstakey() 
	{
		return instakey;
	}

	public static String getGcx() 
	{
		return gcx;
	}
	
	public static String getTypeName() 
	{
		return typename;
	}
	
	public static String getBatchJobServerIp() 
	{
		return batchJobServerIp;
	}
	
	public static String getBatchJobServerUsername() 
	{
		return batchJobServerUsername;
	}
	
	public static String getBatchJobServerPassword()
	{
		return batchJobServerPassword;
	}
	
	public static String getFbUserId()
	{
		return fbuserid;
	}
	
	public static String getFbUserPass()
	{
		return fbuserpass;
	}
	
	public static String getInnsightImageFlag()
	{
		return innsightImageFlag;
	}
	
	public static String getNgServiceUrl()
	{
		return ngServiceUrl;
	}
	
	public static String getFtpFileUrl()
	{
		return ftpFileUrl;
	}
	
	public static String getInnsightLocalImageUrl()
	{
		return innsightLocalImageUrl;
	}
	
	public static String getFacebookLocalImageUrl()
	{
		return facebookLocalImageUrl;
	}
	
	public static String getLinkAnalysisImageUrl()
	{
		return linkAnalysisImageUrl;
	}
	
	public static String getTelegramImageUrl()
	{
		return telegramImageUrl;
	}
	
	public static String getWhatsappImageUrl()
	{
		return whatsappImageUrl;
	}
	
	public static String getWhatsappImageWriteAbsUrl()
	{
		return whatsappImageWriteAbsUrl;
	}
	
	public static String getProphecyDataUrl()
	{
		return prophecyDataUrl;
	}
	
	public static String getHideWhatsappSenderFlag()
	{
		return hideWhatsappSenderFlag;
	}
	
	public static String getDefaultDaysOfDataLoad()
	{
		return defaultDaysOfDataLoad;
	}
	
	public static String getArticlePriorityFlag()
	{
		return articlePriorityFlag;
	}
	
	public static String getTwoPageReportFlag()
	{
		return twoPageReportFlag;
	}
	
	public static String getPersonProfile() 
	{
		return personProfile;
	}
	
	public static String getSuspectPhotos() 
	{
		return suspectPhotos;
	}
	
	public static String getJasperFilePath() 
	{
		return jasperFilePath;
	}

	public static String getSuspectPhotosRender() 
	{
		return suspectPhotosRender;
	}
	
	public static String getFrsServerURL() 
	{
		return frsServerURL;
	}
	
	public static String getImageDbName() 
	{
		return imageDbName;
	}
	
	public static String getImageDbType()
	{
		return imageDbType;
	}
	
	public static String getDynamicHost() 
	{
		return dynamicHost;
	}
	
	public static String getUserCreationLimit() 
	{
		return userCreationLimit;
	}
	
	public static String getClientName() 
	{
		return clientName;
	}
	
	public static String getGlobalClientId() 
	{
		return globalClientId;
	}
	
	public static String getCloudURL() 
	{
		return cloudURL;
	}
	
	public static String getCentralCrawlingServerURL() 
	{
		return centralCrawlingServerURL;
	}
	
	public static String getTwoFA() {
		return twoFA;
	}
	
	public static String getTwoFAHostname() {
		return twoFAHostname;
	}
	
	public static String getTwoFAAppId() {
		return twoFAAppId;
	}
	
	public static String getTwoFAIP() {
		return twoFAIP;
	}
	
	public static String getLdap() {
		return ldap;
	}
	
	public static String getLdapHostname() {
		return ldapHostname;
	}
	
	public static String getLdapDomainName() {
		return ldapDomainName;
	}
	
	public static String getTelegramGroupUpdate() {
		return telegramGroupUpdate;
	}
	
	public static String getCaseFileAttachmentPath() {
		return caseFileAttachmentPath;
	}
	
	public static String getCaseFileAttachmentUrl() {
		return caseFileAttachmentUrl;
	}
	
	public static String getExportReportFolderPath() {
		return exportReportFolderPath;
	}
	
	public static String getExportReportFolderUrl() {
		return exportReportFolderUrl;
	}
	public static String getBaseUrl() {
		return baseUrl;
	}
	public static String getNextcloudDataPath() {
		return nextcloudDataPath;
	}
	public static String getGoogleApiKey() {
		return googleApiKey;
	}
		
	public static String getThreatKeywordUrl() {
		return threatKeywordUrl;
	}
	
	public static String getThreatClassificationFlag() {
		return threatClassificationFlag;
	}
	
	public static String getOdsServerUrl() {
		return odsServerUrl;
	}
	
	/*public static String getProfileFinderSources() {
		return profileFinderSources;
	}*/
	
	public static String convertStrToDate_yyyy_MM_dd(String date) 
	{
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		Date d1=new  Date();
		try 
		{
			d1 = df.parse(date);
			date = format.format(d1);
		} 
		catch(ParseException e) 
		{
			e.printStackTrace();
		}
		return date;
	}

	public static String getJsonForEsNested(String path, String fieldName, String value)
	{
		 String rtnJson=  ",{\n"+
				"\"nested\": {\n"+
				"\"path\": \""+path+"\"\n,"+
				"\"query\": {\n"+
				"\"terms\": {\n"+
				"\""+fieldName+"\": [\n"+
				value+"\n"+
				"]\n"+
				"}\n"+
				"}\n"+
				"}\n"+
				"}\n";
		return rtnJson;
	}

	public static String getSortForEsTermAggNested(String value,String name)
	{
		String sortQuery="";
		switch(value) 
		{
		case "cntasc":
			sortQuery="\"order\":{\""+name+"\":\"asc\"}\n";
			break;
		case "cntdesc":
			sortQuery="\"order\":{\""+name+"\":\"desc\"}\n";
			break;
		case "nameasc":
			sortQuery="\"order\":{\""+name+"\":\"asc\"}\n";
			break;
		case "namedesc":
			sortQuery="\"order\":{\""+name+"\":\"desc\"}\n";
			break;
		}
		return sortQuery;
	}
	
	public static String getAvg(String field)
	{
		String query=""+
		",\"aggs\":\n"+
		"{\n"+
		"\"avg\":{\n"+
		"\"avg\":{\n"+
		"\"field\":\""+field+"\"\n"+
		"}\n"+
		"}\n"+
		"}\n";
		return query;
	}
	

	public SearchResult startScrollSearch(JestClient client,String query) throws IOException 
	{
		Search search = new Search.Builder(query)
				// multiple index or types can be added.
				.addIndex("innsight")
				.addType("data_collection")
				.setParameter(Parameters.SIZE,1000)
				.setParameter(Parameters.SCROLL, "1m")
				.build();
		SearchResult searchResult = client.execute(search);
		return searchResult;
	}

	public JestResult readMoreFromSearch(String scrollId, Long size,JestClient client) throws IOException 
	{
		SearchScroll scroll = new SearchScroll.Builder(scrollId, "1m").build();
		JestResult searchResult = client.execute(scroll);
		//System.out.println(searchResult.getJsonString());
		// System.out.println(searchResult.getJsonObject().get("_scroll_id").getAsString());
		return searchResult;
	}

	public static String getJsonForEsPolygon(ArrayList<ArrayList<LocationPoints>> lst, String fieldName)      
	{
		String orInput="";
		for(ArrayList<LocationPoints> lstLocationPoints:lst)
		{
			String input="[\n";
			for(LocationPoints locationPoints:lstLocationPoints)
			{
				input+= "{\"lat\":"+locationPoints.getLat()+",\n";
				input+= "\"lon\":"+locationPoints.getLng()+"},\n";
			}
			input=input.substring(0, input.trim().length()-1);
			input+="]\n";
			orInput+= ",{\n"+
					"\"geo_polygon\": {\n\""+
					fieldName+"\":{\n"+
					"\"points\":"+input+
					"}\n"+
					"}\n"+
					"}\n";
		}
		String boolStr="\n,{\n\"bool\":\n{"+
				"\"should\":[\n{}\n" +orInput +"\n"
				+ "]\n}\n}\n";
		return boolStr;
	}

	public static String getJsonForEsGeoDistance(String distance, String fieldName,String lat,String lon)      
	{
		String query=",{" +
				"      \"bool\": {\r\n" + 
				"         \"filter\" : {\r\n" + 
				"                \"geo_distance\" : {\r\n" + 
				"                    \"distance\" : \""+distance+"km\",\r\n" + 
				"                    \""+fieldName+"\" : {\r\n" + 
				"                        \"lat\" : "+lat+",\r\n" + 
				"                        \"lon\" : "+lon+"\r\n" + 
				"                    }\r\n" + 
				"                }\r\n" + 
				"            }}}";
		return query;
	}

	public String expandUrl(String shortenedUrl) throws IOException 
	{
		try
		{
			URL url = new URL(shortenedUrl);    
			// open connection
			HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection(Proxy.NO_PROXY); 
			// stop following browser redirect
			httpURLConnection.setInstanceFollowRedirects(false);
			// extract location header containing the actual destination URL
			shortenedUrl = httpURLConnection.getHeaderField("Location");
			httpURLConnection.disconnect();
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return shortenedUrl;
	}


	public static String convertStrToDate_yyyy_MM_dd1(String date)
	{
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		Date d1 = new  Date();
		try
		{
			d1 = df.parse(date);
			date = format.format(d1);
		} 
		catch(ParseException e) 
		{
			e.printStackTrace();
		}
		return date;
	}

	public static Long convertDateToTimeStamp1(String date)
	{
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		Date d1=new  Date();
		try 
		{
			d1 = df.parse(date);
		}
		catch(ParseException e) 
		{
			e.printStackTrace();
		}
		return d1.getTime();
	}


	public static String getGlobalKeywordFilter(ArrayList<String> keywordList)
	{
		String sb="";
		for (String string : keywordList) 
		{
			String[] key2=string.trim().split(" ");
			if(key2.length==1)
			{
				if(!key2[0].trim().isEmpty())
				{
					//sb.append("*"+key2[0].trim().toLowerCase()+"*"+" OR ");
					sb += key2[0].trim().toLowerCase()+" OR ";
				}
			}
			else if(key2.length > 1)
			{
				String astr="";
				for(String string2 : key2) 
				{
					if(!string2.trim().isEmpty())
					{
						//astr.append("*"+string2.trim().toLowerCase()+"*"+" AND ");
						//astr.append(string2.trim().toLowerCase()+" AND ");
						astr+=string2.trim().toLowerCase()+" AND ";
					}
				}
				sb+="( "+astr.toString().trim().substring(0,astr.toString().trim().length()-3)+") OR ";
			}
			//sb.append(string+" OR ");
		}
		return sb.trim().substring(0,sb.toString().trim().length()-2).trim();
	}

	public static String getGlobalProfileFilterString(ArrayList<String> keywordList)
	{
		String sb="";
		for(String string : keywordList)
		{
			if(!string.trim().isEmpty())
			{
				string=string.replace(":","\\\\:");
				String[] keyArr=string.trim().split(",");
				string=keyArr[0];
				sb+="articleAuthor:"+string.trim()+" OR "+
					"articleAuthorId:"+string.trim()+" OR ";

				if(keyArr[1].trim().equals("tw"))
				{
					sb+="articleMention:"+string.trim()+" OR "+
						"tweet.tweetInReplyToScreenName:"+string.trim()+" OR "+
						"tweet.tweetInReplyToUserId:"+string.trim()+" OR "+
						"tweet.tweetRetweetUserId:"+string.trim()+" OR "+
						"tweet.tweetRetweetUserScreenName:"+string.trim()+" OR ";
				}
				else if(keyArr[1].trim().equals("fb"))
				{
					sb+="facebook.fbPage.pageId:"+string.trim()+" OR "+
						"facebook.fbPage.pageUserName:"+string.trim()+" OR ";
				}
				
				//"articleTitle:"+string.trim().toLowerCase()+" OR "+
				//"articleSubTitle:"+string.trim().toLowerCase()+" OR "+
				//"articleBigContent:"+string.trim().toLowerCase()+" OR ";
				//System.out.println(string.trim());
			}
		}
		//System.out.println("12244::::::::"+sb);
		return sb.trim().substring(0,sb.trim().length()-2).trim();
	}


	public static String getGlobalProfileFilter(ArrayList<LinkedHashMap<String, String>> keywordList)
	{
		String sb="";
		for(Map<String, String> map : keywordList) 
		{
			String string=map.values().toArray()[0].toString();
			String type=map.values().toArray()[1].toString();			
			//System.out.println("string:  "+string);
			//System.out.println("type:  "+type);
			
			if(!string.trim().isEmpty())
			{
				string=string.replace(":","\\\\:");
				sb+="articleAuthor:"+string.trim()+" OR "+
					"articleAuthorId:"+string.trim()+" OR ";

				if(type.trim().equals("tw"))
				{
					sb+="articleMention:"+string.trim()+" OR "+
							"tweet.tweetInReplyToScreenName:"+string.trim()+" OR "+
							"tweet.tweetInReplyToUserId:"+string.trim()+" OR "+
							"tweet.tweetRetweetUserId:"+string.trim()+" OR "+
							"tweet.tweetRetweetUserScreenName:"+string.trim()+" OR ";
				}
				else if(type.trim().equals("fb"))
				{
					sb+="facebook.fbPage.pageId:"+string.trim()+" OR "+
						"facebook.fbPage.pageUserName:"+string.trim()+" OR ";
				}				
				else if(type.toLowerCase().trim().equals("tg"))
				{
					sb+="telegram.groupChannelId:"+string.trim()+" OR "+
						"telegram.groupChannelName:"+string.trim()+" OR ";
				}
				
				//"articleTitle:"+string.trim().toLowerCase()+" OR "+
				//"articleSubTitle:"+string.trim().toLowerCase()+" OR "+
				//"articleBigContent:"+string.trim().toLowerCase()+" OR ";
				//System.out.println(string.trim());
			}
		}
		//System.out.println("12244::::::::"+sb);
		return sb.trim().substring(0,sb.trim().length()-2).trim();
	}

	
	public static String getGlobalProfileFilterForLinkAnalysis(ArrayList<LinkedHashMap<String, String>> keywordList)
	{
		String sb="";
		for(Map<String, String> map : keywordList) 
		{
			String string=map.values().toArray()[0].toString();
			String type=map.values().toArray()[1].toString();
			if(!string.trim().isEmpty())
			{
				string=string.replace(":","\\\\:");
				sb+="articleAuthor:"+string.trim()+" OR "+
					"articleAuthorId:"+string.trim()+" OR ";
			}
		}
		return sb.trim().substring(0,sb.trim().length()-2).trim();
	}


	public static String searchUserByKeyword(String keyword)
	{
		String sb="articleAuthor:"+"*"+keyword.trim()+"*"+" OR "+
				"articleAuthorId:"+"*"+keyword.trim()+"*";
		
/*		String sb="articleAuthor:"+keyword.trim()+" OR "+
				"articleAuthorId:"+keyword.trim();
*/
		return sb;
	}
	

	public static void replaceWith()
	{
		String s1="http://subirbhowmikscolumn.blogspot.in";
		String replaceString=s1.replace(":","\\\\:");
		System.out.println(replaceString);
	}
	
	public static String removeWhiteSpaces(String str)
	{
        String s = "";
        char[] arr = str.toCharArray();
        for(int i = 0; i < arr.length; i++) 
        {
            int temp = arr[i];
            if(temp!=32 && temp!=9 && temp!=43 && temp!=64) //32 ASCII for space, 9 is for Tab, 64 for @ and 43 for +
            {             	
                s+=arr[i];
            }
        }       
        return s;
    }

	public static String removeWhiteSpacesForContact(String str)
	{
        String s="";
        String whatsappNo="";
        char[] arr = str.toCharArray();
        for(int i = 0; i < arr.length; i++) 
        {
            int temp = arr[i];
            if(temp!=32 && temp!=9 && temp!=43 && temp!=64) //32 ASCII for space, 9 is for Tab, 64 for @ and 43 for +
            {             	
                s+=arr[i];
            }
        }
        whatsappNo = s;
        
        /*if(s.length() >= 10)
        {
        	 whatsappNo = s.substring(s.length()-10);
        } 
        else
        {
        	whatsappNo = s;
        }*/
        return whatsappNo;
    }
	
	public static String getLastTenDigitNo(String str)
	{
        String s="";
        String whatsappNo="";
        char[] arr = str.toCharArray();
        for(int i = 0; i < arr.length; i++) 
        {
            int temp = arr[i];
            if(temp!=32 && temp!=9) //32 ASCII for space, 9 is for Tab
            {             	
                s+=arr[i];
            }
        }        
        if(s.length() > 10)
        {
        	 whatsappNo = s.substring(s.length()-10);
        } 
        else
        {
        	whatsappNo = s;
        }
        return whatsappNo;
    }
	
	public static String removeWhiteSpacesForGroup(String str)
	{
        String s = "";
        String groupId="";
        char[] arr = str.toCharArray();
        for(int i = 0; i < arr.length; i++) 
        {
            int temp = arr[i];
            if(temp!=32 && temp!=9 && temp!=43 && temp!=64) //32 ASCII for space, 9 is for Tab, 64 for @ and 43 for +
            {             	
                s+=arr[i];
            }
        }
        groupId = s;
        
        /*if(s.length() >= 21)
        {
        	groupId = s.substring(s.length()-21);
        } 
        else
        {
        	groupId = s;
        }*/
        return groupId;       
    }
	
	public static String convertStringToMd5Image(String txt) 
	{		
		if(txt != null)
		{
			StringBuffer sb = new StringBuffer();
			try 
			{
				MessageDigest md = MessageDigest.getInstance("MD5");
				md.update(txt.getBytes());
				byte byteData[] = md.digest();
				//convert the byte to hex format method 1
				for (int i = 0; i < byteData.length; i++) 
				{
					sb.append(Integer.toString((byteData[i] & 0xff) + 0x100, 16).substring(1));
				}
			} 
			catch(Exception ex) 
			{
				System.out.println("txt::::"+txt);
				ex.printStackTrace();
			}
			return sb.toString()+".jpg";
		}	
		else
		{
			return "";
		}
	}
	
	public static String convertStringToMd5(String txt) 
	{
		if(txt != null)
		{
			StringBuffer sb = new StringBuffer();
			try 
			{
				MessageDigest md = MessageDigest.getInstance("MD5");
				md.update(txt.getBytes());
				byte byteData[] = md.digest();
				//convert the byte to hex format method 1
				for (int i = 0; i < byteData.length; i++) 
				{
					sb.append(Integer.toString((byteData[i] & 0xff) + 0x100, 16).substring(1));
				}
			} 
			catch(Exception ex) 
			{
				System.out.println("txt::::"+txt);
				ex.printStackTrace();
			}
			return sb.toString();
		}
		else
		{
			return "";
		}
	}
	
	public static String convertStringToMd5AuthorId(String txt)
	{
		if(txt != null)
		{
			StringBuffer sb = new StringBuffer();
			try
			{
				MessageDigest md = MessageDigest.getInstance("MD5");
				md.update(txt.getBytes());
				byte byteData[] = md.digest();
				//convert the byte to hex format method 1
				for (int i = 0; i < byteData.length; i++) 
				{
					sb.append(Integer.toString((byteData[i] & 0xff) + 0x100, 16).substring(1));
				}
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
			}
			return sb.toString();
		}
		else
		{
			return "";
		}
	}
	
	public static String imageToBase64(String filePath) throws IOException
	{
		byte[] fileContent = FileUtils.readFileToByteArray(new File(filePath));
		String encodedString = Base64.getEncoder().encodeToString(fileContent);
		return encodedString;
	}
	
	public static String remoteImageToBase64(String filePath) throws IOException
	{
		URL url = new URL(filePath);
		InputStream is = url.openStream();
		ByteArrayOutputStream os = new ByteArrayOutputStream();                 
        byte[] buf = new byte[4096];
        int n;
        while ((n = is.read(buf)) >= 0) 
            os.write(buf, 0, n);
        os.close();
        is.close();                     
        byte[] data = os.toByteArray();
        String encodedString = Base64.getEncoder().encodeToString(data);
		return encodedString;
	}
	
	/*public static void main(String[] args) 
	{
		try
		{
			LinkedHashMap<String,String> map = new LinkedHashMap<>();
			map.put("key","india");
			map.put("val","tw");
			ArrayList<LinkedHashMap<String,String>> keywordList=new ArrayList<>();
			keywordList.add(map);

			map = new LinkedHashMap<>();
			map.put("key","indiafb");
			map.put("val","fb");
			keywordList.add(map);

			map = new LinkedHashMap<>();
			map.put("key","indiatw");
			map.put("val","tw");
			keywordList.add(map);			
			System.out.println(getGlobalProfileFilter(keywordList));
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}*/
	
	
	
	/*public static void main(String[] args) {
		runRemotePythonScript("You're right on both counts. I actually knew that Jython is still updated, \r\n" + 
				" I just didn't really clarify. On the second note, what I'm really trying to do is parse a string using regular expressions, however, the expression \r\n" + 
				" I'm using are not supported in Java. Yes, there are ways I could do this using only Java with simpler expressions, but that would mean more logic coding to parse the string, \r\n" + 
				" while this method (that is, the current regular expression I'm using) gives me pretty much exactly what I need.");
	}*/
	
	public boolean checkBlacklistKeyword(String key) 
	{
		ArrayList<String> blacklistKeywords = (ArrayList<String>)httpSession.getAttribute(ApplicationConstants.BLACKLISTKEYWORDS)
				==null ?caseManagerInn.blacklistKeywords(): (ArrayList<String>)httpSession.getAttribute(ApplicationConstants.BLACKLISTKEYWORDS);
		//System.out.println("checking for blacklist keyword : "+(blacklistKeywords.contains(key) ? key : ""));
		if(blacklistKeywords.stream().noneMatch(s -> s.equalsIgnoreCase(key)))
		{
			return true;
		}
		return false;
	}
	
	public HashMap<String, ArrayList<String>> getNerIgnoreKeywordsFromSession() 
	{
		HashMap<String, ArrayList<String>> nerIgnoreKeywords = (HashMap<String, ArrayList<String>>)httpSession.getAttribute(ApplicationConstants.NERIGNOREKEYWORDS)
				==null ?caseManagerInn.nerIgnoreKeywords():(HashMap<String, ArrayList<String>>)httpSession.getAttribute(ApplicationConstants.NERIGNOREKEYWORDS);
		return nerIgnoreKeywords;
	}
	
	public static Long convertDateToTimeStampData(String date)
	{
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		Date d1 = new Date();
		try 
		{
			d1 = df.parse(date);
		}
		catch(ParseException ex) 
		{
			ex.printStackTrace();
		}
		return d1.getTime();
	}
	
	public static String getFullSourceName(String name) throws Exception
	{
		String sourceType="";
		switch(name)
		{
		case "tw":
			sourceType="Twitter";
			break;
		case "fb":
			sourceType="Facebook";
			break;
		case "yt":
			sourceType="Youtube";
			break;
		case "insta":
			sourceType="Instagram";
			break;
		case "dm":
			sourceType="Dailymotion";
			break;
		case "tm":
			sourceType="Tumblr";
			break;
		case "wp":
			sourceType="WordPress";
			break;
		case "gb":
			sourceType="Blogger";
			break;
		
		case "linkedin":
			sourceType="Linkedin";
			break;

		case "website":
			sourceType="Website";
			break;
		case "google":
			sourceType="Google";
			break;
		case "bing":
			sourceType="Bing";
			break;
		case "duckduckgo":
			sourceType="DuckDuckGo";
			break;
		case "reddit":
			sourceType="Reddit";
			break;
		case "flickr":
			sourceType="Flickr";
			break;
		case "ThinkTank":
			sourceType="ThinkTank";
			break;
	
		
		case "article":
			sourceType="News";
			break;
		case "ftp":
			sourceType="FTP";
			break;
		}
		return sourceType;
	}
	

	
}