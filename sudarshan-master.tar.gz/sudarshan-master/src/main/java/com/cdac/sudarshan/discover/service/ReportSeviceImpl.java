package com.cdac.sudarshan.discover.service;

import java.io.File;
import java.util.Arrays;
import java.util.HashMap;

import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

@Service
public class ReportSeviceImpl implements IReportSevice {

	@Autowired
	private RestTemplate restTemplate;

	@Value("${localInnefuUrl}")
	private String innefuUrl;

	@Override
	public ResponseEntity<?> trendingOrganization(HashMap<String, Object> data) {	

		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		
		HttpEntity<Object> entity = new HttpEntity<>(data, headers);
		ResponseEntity<Object> result = restTemplate.exchange(innefuUrl + "/getOrganizationWordCloud", HttpMethod.POST,
				entity, Object.class);

		// Change keys of existing json (word to text and frequency to weight)
		Gson gson = new GsonBuilder().serializeNulls().create();
		String bodyData = gson.toJson(result.getBody());
		bodyData = bodyData.replace("word", "text");
		bodyData = bodyData.replace("frequency", "weight");

		JSONParser parser = new JSONParser();

		JSONArray jsonArray;
		try {
			jsonArray = (JSONArray) parser.parse(bodyData);
			ResponseEntity<Object> changedJsonData = new ResponseEntity<Object>(jsonArray, result.getHeaders(), HttpStatus.OK);
			return changedJsonData;
		} catch (ParseException e) {
			// TODO Auto-generated catch block			
			e.printStackTrace();
		}
		
		return null;		

	}
	
	@Override
	public ResponseEntity<?> getUserWordCloud(HashMap<String, Object> data) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<>(data, headers);
		ResponseEntity<Object> result = restTemplate.exchange(innefuUrl + "/getUserWordCloud", HttpMethod.POST,
				entity, Object.class);

		// Change keys of existing json (word to text and frequency to weight)
		Gson gson = new GsonBuilder().serializeNulls().create();
		String bodyData = gson.toJson(result.getBody());
		bodyData = bodyData.replace("word", "text");
		bodyData = bodyData.replace("frequency", "weight");

		JSONParser parser = new JSONParser();

		JSONArray jsonArray;
		try {
			jsonArray = (JSONArray) parser.parse(bodyData);
			ResponseEntity<Object> changedJsonData = new ResponseEntity<Object>(jsonArray, result.getHeaders(), HttpStatus.OK);
			return changedJsonData;
		} catch (ParseException e) {
			// TODO Auto-generated catch block			
			e.printStackTrace();
		}
		
		return null;

		
	}

	@Override
	public ResponseEntity<?> getThemeWordCloud(HashMap<String, Object> data) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<>(data, headers);
		ResponseEntity<Object> result = restTemplate.exchange(innefuUrl + "/getThemeWordCloud", HttpMethod.POST,
				entity, Object.class);

		// Change keys of existing json (word to text and frequency to weight)
		Gson gson = new GsonBuilder().serializeNulls().create();
		String bodyData = gson.toJson(result.getBody());
		bodyData = bodyData.replace("word", "text");
		bodyData = bodyData.replace("frequency", "weight");

		JSONParser parser = new JSONParser();

		JSONArray jsonArray;
		try {
			jsonArray = (JSONArray) parser.parse(bodyData);
			ResponseEntity<Object> changedJsonData = new ResponseEntity<Object>(jsonArray, result.getHeaders(), HttpStatus.OK);
			return changedJsonData;
		} catch (ParseException e) {
			// TODO Auto-generated catch block			
			e.printStackTrace();
		}
		
		return null;
	}	

	@Override
	public ResponseEntity<?> getTweetsRpt(HashMap<String, Object> data) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<>(data, headers);

		return restTemplate.exchange(innefuUrl + "/getTweetsRpt", HttpMethod.POST, entity, Object.class);
		
	}

	
}
