package com.cdac.sudarshan.discover.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Entity
@Setter
@Getter
@AllArgsConstructor
public class DiscoverSubSources extends BaseEntity{

	private String subSource;
	@ManyToOne(targetEntity = DiscoverSources.class, cascade = CascadeType.ALL)
	@JoinColumn(name = "source_subsource_fk", referencedColumnName = "id")
	private DiscoverSources discoverSources;
	private String alias;
	
	
	public DiscoverSubSources(int id, String subSource) {
		super(id);
		this.subSource = subSource;
	}


	public DiscoverSubSources(int id, String subSource, String alias) {
		super(id);
		this.subSource = subSource;
		this.alias = alias;
	}
	
}
