package com.cdac.sudarshan.discover.model;

import java.io.Serializable;

public class Fb_Tag_Profile implements Serializable 
{
	private static final long serialVersionUID = 1L;
	private String hashtag;
	private String tagType;
	private String tagId;

	public String getHashtag() {
		return hashtag;
	}

	public void setHashtag(String hashtag) {
		this.hashtag = hashtag;
	}

	public String getTagType() {
		return tagType;
	}

	public void setTagType(String tagType) {
		this.tagType = tagType;
	}

	public String getTagId() {
		return tagId;
	}

	public void setTagId(String tagId) {
		this.tagId = tagId;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "Fb_Tag_Profile [hashtag=" + hashtag + ", tagType=" + tagType + ", tagId=" + tagId + "]";
	}
}
