package com.cdac.sudarshan.discover.service;

import java.awt.Color;
import java.io.IOException;
import java.net.URL;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.TreeSet;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import java.util.Map;
import java.util.Set;

import com.cdac.sudarshan.authentication.model.User;
import com.cdac.sudarshan.authentication.service.IUserService;
import com.cdac.sudarshan.exception.ResourceNotFoundException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.flywaydb.core.internal.util.DateUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpRequest;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.client.RequestCallback;
import org.springframework.web.client.ResponseExtractor;
import org.springframework.web.client.RestTemplate;

import com.cdac.sudarshan.discover.common.ApplicationConstants;
import com.cdac.sudarshan.discover.common.CommonUtils;
import com.cdac.sudarshan.discover.common.DashBoardController;
import com.cdac.sudarshan.discover.common.Helper;
import com.cdac.sudarshan.discover.common.TwitterConstant;
import com.cdac.sudarshan.discover.model.Article_Datacollection_New;
import com.cdac.sudarshan.discover.model.Article_Media;
import com.cdac.sudarshan.discover.model.TweeterActionVo;
import com.cdac.sudarshan.discover.model.TwitterChartVo;
import com.cdac.sudarshan.discover.model.TwitterVo;
import com.cdac.sudarshan.discover.utils.ArrayIndexComparator;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;

import io.searchbox.client.JestClient;
import io.searchbox.core.Search;
import io.searchbox.core.SearchResult;
import io.swagger.v3.oas.annotations.parameters.RequestBody;

import org.springframework.jdbc.core.JdbcTemplate;

@Service
@CrossOrigin("*")
public class KSourceServiceImpl implements KISourceService {
	@Value("${localInnefuUrl}")
	private String innefuUrl;

	@Value("${loginUser}")
	private String user;

	@Value("${password}")
	private String password;

	@Value("${InnefuUrlRestClient}")
	private String innefuUrlRestClient;

	@Autowired
	private RestTemplate template;

	@Autowired
	private HttpHeaders httpHeaders;

	@Autowired
	private JdbcTemplate jdbcTemplateTwo;

	@Autowired
	private CommonUtils commonUtils;

	@Autowired
	private DataSource dataSource;

	@Autowired
	private HttpSession httpSession;

	@Autowired
	JestClient client;

	@Autowired
	private TwitterConstant twitterConstant;

	@Autowired
	private DashBoardController dashboardController;

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Autowired
	private IUserService userService;

	@Override
	public HttpHeaders getHttpHeadersAfterLogin() {
		ClientHttpResponse response = template.execute(innefuUrl + "/login_validateCredential", HttpMethod.POST,
				new RequestCallback() {
					public void doWithRequest(ClientHttpRequest request) throws IOException {
						request.getBody().write(("userName=" + user + "&password=" + password).getBytes());
					}
				}, new ResponseExtractor<ClientHttpResponse>() {

					@Override
					public ClientHttpResponse extractData(ClientHttpResponse response) throws IOException {
						return response;
					}
				});

		HttpHeaders headers = new HttpHeaders();
		List<String> cookies = response.getHeaders().get("Set-Cookie");
		headers.set("Cookie", cookies.get(0));
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		return headers;
	}

	@Override
	public ResponseEntity<?> getTweets(HashMap<String, Object> data) {
		System.out.println("innefy url "+innefuUrl);
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<>(data, headers);
		return template.exchange(innefuUrl + "/getTweets", HttpMethod.POST, entity, Object.class);
	}

	@Override
	public ResponseEntity<?> getHashTags(HashMap<String, Object> data) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<>(data, headers);
		return template.exchange(innefuUrl + "/getHashTags", HttpMethod.POST, entity, Object.class);
	}

	@Override
	public ResponseEntity<?> getLanguage(HashMap<String, Object> data) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<>(data, headers);
		return template.exchange(innefuUrl + "/getLanguage", HttpMethod.POST, entity, Object.class);
	}

	@Override
	public ResponseEntity<?> getCountry(HashMap<String, Object> data) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<>(data, headers);
		return template.exchange(innefuUrl + "/getCountry", HttpMethod.POST, entity, Object.class);
	}

	@Override
	public ResponseEntity<?> getAuthorCountry(HashMap<String, Object> data) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<>(data, headers);
		return template.exchange(innefuUrl + "/getAuthorCountry", HttpMethod.POST, entity, Object.class);
	}

	@Override
	public ResponseEntity<?> getMetaTagsNer(HashMap<String, Object> data) {
//		HttpHeaders headers = getHttpHeadersAfterLogin();
		HttpHeaders headers = new HttpHeaders();
//		HttpHeaders headers = httpHeaders;
		HttpEntity<Object> entity = new HttpEntity<>(data, headers);
		return template.exchange(innefuUrl + "/getThemeWordCloud", HttpMethod.POST, entity, Object.class);
	}

	@Override
	public ResponseEntity<?> getUsers(HashMap<String, Object> data) {

		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<>(data, headers);
		return template.exchange(innefuUrl + "/getUsers", HttpMethod.POST, entity, Object.class);
	}

	@Override
	public ResponseEntity<?> getAllAttriubuteCount(HashMap<String, Object> data) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<>(data, headers);
		return template.exchange(innefuUrl + "/getAllAttriubuteCount", HttpMethod.POST, entity, Object.class);
	}

	@Override
	public ResponseEntity<?> getAlertCounts(HashMap<String, Object> data) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<>(data, headers);
		return template.exchange(innefuUrl + "/getAlertCounts", HttpMethod.POST, entity, Object.class);
	}

	@Override
	public ResponseEntity<?> getMedia(HashMap<String, Object> data) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<>(data, headers);
		return template.exchange(innefuUrl + "/getMedia", HttpMethod.POST, entity, Object.class);
	}

	@Override
	public ResponseEntity<?> geoTweetsLatLong(HashMap<String, Object> data) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<>(data, headers);
		return template.exchange(innefuUrl + "/geoTweetsLatLong", HttpMethod.POST, entity, Object.class);
	}

	@Override
	public ResponseEntity<?> getPlaceWordCloud(HashMap<String, Object> data) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<>(data, headers);
		return template.exchange(innefuUrl + "/getPlaceWordCloud", HttpMethod.POST, entity, Object.class);
	}

	@Override
	public ResponseEntity<?> getOrganizationWordCloud(HashMap<String, Object> data) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<>(data, headers);
		return template.exchange(innefuUrl + "/getOrganizationWordCloud", HttpMethod.POST, entity, Object.class);
	}

	@Override
	public ResponseEntity<?> getUserWordCloud(HashMap<String, Object> data) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<>(data, headers);
		return template.exchange(innefuUrl + "/getUserWordCloud", HttpMethod.POST, entity, Object.class);
	}

	@Override
	public ResponseEntity<?> getThemeWordCloud(HashMap<String, Object> data) {
//		HttpHeaders headers = getHttpHeadersAfterLogin();
		HttpHeaders headers = new HttpHeaders();
//		HttpHeaders headers = httpHeaders;
		HttpEntity<Object> entity = new HttpEntity<>(data, headers);
		ResponseEntity<Object> result = template.exchange(innefuUrl + "/getThemeWordCloud", HttpMethod.POST, entity,
				Object.class);

		// Change keys of existing json (word to text and frequency to weight)
		Gson gson = new GsonBuilder().serializeNulls().create();
		String stringJson = gson.toJson(result.getBody());
		stringJson = stringJson.replace("word", "text");
		stringJson = stringJson.replace("frequency", "weight");

		JSONParser parser = new JSONParser();
		try {
			JSONArray jsonArray = (JSONArray) parser.parse(stringJson);
			ResponseEntity<Object> changedJsonData = new ResponseEntity<Object>(jsonArray, result.getHeaders(),
					HttpStatus.OK);
			return changedJsonData;
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	// facebook flow start

	@Override
	public ResponseEntity<?> getAllDashboard(HashMap<String, Object> data) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<>(data, headers);
		return template.exchange(innefuUrl + "/getAllDashboard", HttpMethod.POST, entity, Object.class);
	}

	@Override
	public ResponseEntity<?> getUserCurrentDashboard(String caseId, HashMap<String, Object> data) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<>(data, headers);
		return template.exchange(innefuUrl + "/getUserCurrentDashboard?caseId=", HttpMethod.POST, entity, Object.class);
	}

	@Override
	public ResponseEntity<?> getWidgetsByDashboardId(String dashboardId, HashMap<String, Object> data) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<>(data, headers);
		return template.exchange(innefuUrl + "/getWidgetsByDashboardId?dashboardId=" + dashboardId, HttpMethod.POST,
				entity, Object.class);
	}

	@Override
	public ResponseEntity<?> dashActiveMedia(TweeterActionVo tweeterActionVo) {
		ArrayList<TwitterVo> list = new ArrayList<TwitterVo>();

		try {
			String subAggs = ",\n" + "\"aggs\": {\n" + "\"myaggs\": {\n" + "\"top_hits\": {\n" + "\"_source\": {\n"
					+ "\"include\": [\n" + "\"articleMedia\"\n" + "]" + "}," + "\"size\": 1\n" + "}" + "}" + "}";

			String fieldName = "articleMedia.mediaUrl";
			switch (tweeterActionVo.getType()) {
			case "image":
				fieldName = "articleMedia.mediaThumbnail";
				break;
			case "video":
				fieldName = "articleMedia.mediaThumbnail";
				break;
			case "url":
				fieldName = "articleMedia.mediaUrl";
				break;
			case "domain":
				fieldName = "articleMedia.mediaUrl";
				break;

			default:
				break;
			}

			String subQuery = rtnFilterQuery(tweeterActionVo, -1);
			String query = "{\n" + "\"size\": 0,\n" + subQuery + ",\"aggs\": {\n" + "\"sourceType\": {\n"
					+ "\"terms\": {\n" + "\"field\": \"articleSource\"\n" + "}\n" + ",\"aggs\":\n" + "{\n"
					+ "\"termaggs\":{\n" + "\"terms\":{\n" + "\"field\":\"" + fieldName + "\",\n" + "\"size\": \"10\"\n"
					+ "}\n" + subAggs + "}\n" + "}\n" + "}\n" + "}\n" + "}\n";

//			System.out.println(tweeterActionVo.getType() + " dashActiveMedia()==== " + query);
			Search search = new Search.Builder(query).addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName()).build();

			SearchResult result = client.execute(search);
			JsonObject mainObj = result.getJsonObject();
			if (mainObj.has("aggregations")) {
				JsonObject aggObj = mainObj.getAsJsonObject("aggregations");
				if (aggObj.has("sourceType")) {
					JsonObject sourceTypeObj = aggObj.getAsJsonObject("sourceType");
					if (sourceTypeObj.has("buckets")) {
						JsonArray bucketsArry = sourceTypeObj.getAsJsonArray("buckets");
						for (JsonElement jsonElement : bucketsArry) {
							TwitterVo twitterVo = new TwitterVo();
							twitterVo.setType(jsonElement.getAsJsonObject().get("key").getAsString());
							twitterVo.setCount(jsonElement.getAsJsonObject().get("doc_count").getAsString());
//							ArrayList<TwitterChartVo> chartVoLst = new ArrayList<TwitterChartVo>();
							Set<TwitterChartVo> chartVoLstSet = new HashSet<TwitterChartVo>();

							if (jsonElement.getAsJsonObject().has("termaggs")) {
								JsonObject dthistogramObj = jsonElement.getAsJsonObject().getAsJsonObject("termaggs");
								if (dthistogramObj.has("buckets")) {
									JsonArray innerBucketsArry = dthistogramObj.getAsJsonArray("buckets");
									for (JsonElement jsonElement2 : innerBucketsArry) {
										String key = (jsonElement2.getAsJsonObject().get("key").getAsString());
										String count = jsonElement2.getAsJsonObject().get("doc_count").getAsString();

										TwitterChartVo chartVo5 = new TwitterChartVo();
										chartVo5.setMediaKey(key);
										chartVo5.setKey1(
												TwitterConstant.convertStringToMd5Image(chartVo5.getMediaKey()));
										chartVo5.setMediaCount(count);

//										chartVoLst.add(chartVo5);
										chartVoLstSet.add(chartVo5);

										if (jsonElement2.getAsJsonObject().has("myaggs")) {
											if (jsonElement2.getAsJsonObject().getAsJsonObject("myaggs").has("hits")) {
												if (jsonElement2.getAsJsonObject().getAsJsonObject("myaggs")
														.getAsJsonObject("hits").has("hits")) {
													JsonArray hits = jsonElement2.getAsJsonObject()
															.getAsJsonObject("myaggs").getAsJsonObject("hits")
															.getAsJsonArray("hits");
													for (JsonElement jsonElement3 : hits) {
														if (jsonElement3.getAsJsonObject().has("_source")) {
															if (jsonElement3.getAsJsonObject()
																	.getAsJsonObject("_source").has("articleMedia")) {
																JsonArray articleMedia = jsonElement3.getAsJsonObject()
																		.getAsJsonObject("_source")
																		.getAsJsonArray("articleMedia");

																for (JsonElement jsonElement4 : articleMedia) {
																	if (jsonElement4.getAsJsonObject().get("mediaType")
																			.getAsString()
																			.equals(tweeterActionVo.getType())) {
																		TwitterChartVo chartVo2 = new TwitterChartVo();
																		// twitterVo.setArticleAuthorImageUrlLocal(jsonElement4.getAsJsonObject().get("mediaThumbnailLocal").isJsonNull()?"":
																		// jsonElement4.getAsJsonObject().get("mediaThumbnailLocal").getAsString());
																		chartVo5.setLocalMediaKey(jsonElement4
																				.getAsJsonObject()
																				.get("mediaThumbnailLocal").isJsonNull()
																						? ""
																						: jsonElement4.getAsJsonObject()
																								.get("mediaThumbnailLocal")
																								.getAsString());
																		/*
																		 * chartVo2.setKey(key);
																		 * chartVo2.setCount(count);
																		 * chartVo2.setKey1(jsonElement4.getAsJsonObject
																		 * ().get("mediaUrl").isJsonNull()?key:
																		 * jsonElement4.getAsJsonObject().get("mediaUrl"
																		 * ).getAsString());
																		 * chartVo2.setKey2(jsonElement4.getAsJsonObject
																		 * ().get("mediaThumbnailLocal").isJsonNull()?
																		 * "": jsonElement4.getAsJsonObject().get(
																		 * "mediaThumbnailLocal").getAsString());
																		 * chartVoLst.add(chartVo2);
																		 */
																	}
																}

															}
														}
													}
												}
											}
										}

//										chartVoLst.add(chartVo5);
										chartVoLstSet.add(chartVo5);
									}
								}
							}

							ArrayList<TwitterChartVo> chartVoLst = new ArrayList<>(chartVoLstSet);
							twitterVo.setTwitterChartVo(chartVoLst);
							list.add(twitterVo);
						}
					}
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return new ResponseEntity<>(list, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<?> dashArticles(HashMap<String, Object> data) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<>(data, headers);
		return template.exchange(innefuUrl + "/dashArticles", HttpMethod.POST, entity, Object.class);
	}

	@Override
	public ResponseEntity<?> getAllWidget(HashMap<String, Object> data) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<>(data, headers);
		return template.exchange(innefuUrl + "/getAllWidget", HttpMethod.POST, entity, Object.class);
	}

	@Override
	public ResponseEntity<?> getTweetDetailById(HashMap<String, Object> data) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<>(data, headers);
		return template.exchange(innefuUrl + "/getTweetDetailById", HttpMethod.POST, entity, Object.class);
	}
	// facebook flow end

	@Override
	public ResponseEntity<?> updateCollectionDateBySourceAndKeywordMatch(HashMap<String, Object> data) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		data = setUserId(data);
		try {

			String query = "";

			switch ((String) data.get("collectionType")) {

			case "keyword":
				@SuppressWarnings("unchecked")
				HashMap<String, Object> keywordAndSource = (HashMap<String, Object>) data.get("keyword");
				@SuppressWarnings("unchecked")
				ArrayList<String> keywords = (ArrayList<String>) keywordAndSource.get("keyword");
				@SuppressWarnings("unchecked")
				ArrayList<String> sources = (ArrayList<String>) keywordAndSource.get("sources");
				query = "SELECT cd.collection_id, cd.client_id, cd.created_by, cd.has_analysis, cd.analysis_name, cd.priority, cd.collection_name, cd.collection_type, "
						+ "CAST(cd.activation_date AS CHAR) AS activation_date, CAST(cd.deactivation_date AS CHAR) AS deactivation_date FROM collection_detail cd "
						+ "LEFT OUTER JOIN collection_keyword ck ON cd.collection_id = ck.collection_id WHERE cd.created_by='"
						+ data.get("userId")
						+ "' AND cd.activation_date <= NOW() AND cd.deactivation_date >= NOW() AND cd.action NOT IN ('delete') AND ck.keyword_name IN  (";
				for (String keyword : keywords)
					query = query + "'" + keyword + "', ";
				query = query.substring(0, query.length() - 2);
				query += ") AND ck.source IN (";
				for (String source : sources)
					query = query + "'" + source + "', ";
				query = query.substring(0, query.length() - 2);
				query += ") GROUP BY cd.collection_id HAVING COUNT(DISTINCT ck.keyword_name) = " + keywords.size()
						+ " AND COUNT(DISTINCT ck.source) = " + sources.size() + ";";

				Gson gson = new GsonBuilder().serializeNulls().create();
				String stringJson = gson.toJson(jdbcTemplateTwo.queryForList(query));
				JSONParser parser = new JSONParser();
				JSONArray jsonArray = (JSONArray) parser.parse(stringJson);
				if (!jsonArray.isEmpty()) {
					// update end date

					JSONObject jsonObj = (JSONObject) jsonArray.get(0);
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
					Calendar cal = Calendar.getInstance();
					cal.setTime(cal.getTime());
					cal.add(Calendar.DAY_OF_MONTH, 3);
					String dateAfter = sdf.format(cal.getTime());
					data.put("collectionId", jsonObj.get("collection_id"));
					data.put("collectionName", jsonObj.get("collection_name"));
					data.put("deactivationDate", dateAfter);
					data.put("activationDate", jsonObj.get("activation_date"));
					data.put("clientId", jsonObj.get("client_id"));
					data.put("userId", jsonObj.get("created_by"));
					data.put("hasAnalysis", jsonObj.get("has_analysis"));
					data.put("analysisName", jsonObj.get("analysis_name"));
					data.put("priority", jsonObj.get("priority"));

					HttpEntity<Object> entity = new HttpEntity<>(data, headers);
					return template.exchange(innefuUrlRestClient + "/collectionmanager/updateNewCollectionById",
							HttpMethod.POST, entity, Object.class);

				} else {
					// add new collection

//					data.put("collectionName", "test" + "_".concat(new Timestamp(System.currentTimeMillis()).toString()));
					HttpEntity<Object> entity = new HttpEntity<>(data, headers);
					return template.exchange(innefuUrlRestClient + "/collectionmanager/addNewCollection",
							HttpMethod.POST, entity, Object.class);
				}

			case "profile":
				@SuppressWarnings("unchecked")
				List<Map<String, Object>> profile = (List<Map<String, Object>>) data.get("profile");
				HashMap<String, Object> profileData = (HashMap<String, Object>) profile.get(0);
//				System.out.println(profileData);
				query = "SELECT cd.collection_id, cd.client_id, cd.created_by, cd.has_analysis, cd.analysis_name, cd.priority, cd.collection_name, cd.collection_type, CAST(cd.activation_date AS CHAR) AS activation_date, CAST(cd.deactivation_date AS CHAR) AS deactivation_date  FROM collection_detail AS cd LEFT OUTER JOIN collection_profile cp ON cd.collection_id=cp.collection_id "
						+ "WHERE cd.activation_date <= NOW() AND cd.deactivation_date >= NOW()";

				query += "AND cp.profile_category='" + profileData.get("classification") + "' AND cp.profile_country ='"
						+ profileData.get("country") + "' AND cp.profile_image_url='" + profileData.get("imageUrl")
						+ "' AND cp.profile_name='" + profileData.get("name") + "' AND cp.profile_type='"
						+ profileData.get("type") + "' AND cp.profile_id='" + profileData.get("profileId")
						+ "' AND cp.profile_user_name='" + profileData.get("screenName") + "' AND cp.source='"
						+ profileData.get("source") + "' AND cp.profile_url='" + profileData.get("url")
						+ "' AND cp.is_valid='" + profileData.get("bookmark") + "' AND cp.threat_score='"
						+ profileData.get("threatScore") + "' AND cp.avatar_user_name='" + profileData.get("avatar")
						+ "' AND cp.delta_interval='" + profileData.get("collection_delta") + "' AND cd.created_by='"
						+ profileData.get("userId") + "'";

				gson = new GsonBuilder().serializeNulls().create();
				stringJson = gson.toJson(jdbcTemplateTwo.queryForList(query));
				parser = new JSONParser();
				jsonArray = (JSONArray) parser.parse(stringJson);
				if (!jsonArray.isEmpty()) {
					JSONObject jsonObj = (JSONObject) jsonArray.get(0);
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
					Calendar cal = Calendar.getInstance();
					cal.setTime(cal.getTime());
					cal.add(Calendar.DAY_OF_MONTH, 3);
					String dateAfter = sdf.format(cal.getTime());
					data.put("collectionId", jsonObj.get("collection_id"));
					data.put("collectionName", jsonObj.get("collection_name"));
					data.put("deactivationDate", dateAfter);
					data.put("activationDate", jsonObj.get("activation_date"));
					data.put("clientId", jsonObj.get("client_id"));
					data.put("userId", jsonObj.get("created_by"));
					data.put("hasAnalysis", jsonObj.get("has_analysis"));
					data.put("analysisName", jsonObj.get("analysis_name"));
					data.put("priority", jsonObj.get("priority"));

					HttpEntity<Object> entity = new HttpEntity<>(data, headers);
					return template.exchange(innefuUrlRestClient + "/collectionmanager/updateNewCollectionById",
							HttpMethod.POST, entity, Object.class);
				} else {
//					data.put("collectionName", "test" + "_".concat(new Timestamp(System.currentTimeMillis()).toString()));
					HttpEntity<Object> entity = new HttpEntity<>(data, headers);
					return template.exchange(innefuUrlRestClient + "/collectionmanager/addNewCollection",
							HttpMethod.POST, entity, Object.class);
				}

			case "location":

				query = "SELECT cd.collection_id, cd.client_id, cd.created_by, cd.has_analysis, cd.analysis_name, cd.priority, cd.collection_name, cd.collection_type, CAST(cd.activation_date AS CHAR) AS activation_date,"
						+ " CAST(cd.deactivation_date AS CHAR) AS deactivation_date FROM collection_detail cd LEFT OUTER JOIN collection_location cl ON cd.collection_id = cl.collection_id"
						+ " WHERE cd.created_by='" + data.get("userId")
						+ "' AND cd.activation_date <= NOW() AND cd.deactivation_date >= NOW() ";

				HashMap<String, Object> location = (HashMap<String, Object>) data.get("location");
				query += "AND cl.location_name='" + location.get("locationName") + "' AND cl.source IN (";
				ArrayList<String> locationSources = (ArrayList<String>) location.get("sources");
				for (String source : locationSources) {
					query += "'" + source + "',";
				}
				query = query.substring(0, query.length() - 1);
				query += ") GROUP BY cd.collection_id HAVING COUNT(DISTINCT cl.source)=" + locationSources.size() + ";";
				gson = new GsonBuilder().serializeNulls().create();
				stringJson = gson.toJson(jdbcTemplateTwo.queryForList(query));
				parser = new JSONParser();
				jsonArray = (JSONArray) parser.parse(stringJson);
				if (!jsonArray.isEmpty()) {
					JSONObject jsonObj = (JSONObject) jsonArray.get(0);
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
					Calendar cal = Calendar.getInstance();
					cal.setTime(cal.getTime());
					cal.add(Calendar.DAY_OF_MONTH, 3);
					String dateAfter = sdf.format(cal.getTime());
					data.put("collectionId", jsonObj.get("collection_id"));
					data.put("collectionName", jsonObj.get("collection_name"));
					data.put("deactivationDate", dateAfter);
					data.put("activationDate", jsonObj.get("activation_date"));
					data.put("clientId", jsonObj.get("client_id"));
					data.put("userId", jsonObj.get("created_by"));
					data.put("hasAnalysis", jsonObj.get("has_analysis"));
					data.put("analysisName", jsonObj.get("analysis_name"));
					data.put("priority", jsonObj.get("priority"));

					HttpEntity<Object> entity = new HttpEntity<>(data, headers);
					return template.exchange(innefuUrlRestClient + "/collectionmanager/updateNewCollectionById",
							HttpMethod.POST, entity, Object.class);
				} else {
//					data.put("collectionName", "test" + "_".concat(new Timestamp(System.currentTimeMillis()).toString()));
					HttpEntity<Object> entity = new HttpEntity<>(data, headers);
					return template.exchange(innefuUrlRestClient + "/collectionmanager/addNewCollection",
							HttpMethod.POST, entity, Object.class);
				}

			case "website":

				break;
			case "federated":
				query = "SELECT cd.collection_id, cd.client_id, cd.created_by, cd.has_analysis, cd.analysis_name, cd.priority, cd.collection_name, cd.collection_type, "
						+ "CAST(cd.activation_date AS CHAR) AS activation_date, CAST(cd.deactivation_date AS CHAR) AS deactivation_date  FROM collection_detail AS cd LEFT OUTER JOIN collection_federated cf"
						+ " ON cd.collection_id=cf.collection_id WHERE cd.activation_date <= NOW() AND cd.deactivation_date >= NOW() AND cf.all_these_words='";
				@SuppressWarnings("unchecked")
				HashMap<String, Object> federated = (HashMap<String, Object>) data.get("federated");

				query += federated.get("allTheseWords") + "' AND cf.any_these_words='" + federated.get("anyTheseWords")
						+ "' AND cf.exact_word_phrases='" + federated.get("exactWordPhrases")
						+ "' AND cf.none_these_words='" + federated.get("noneTheseWords") + "' AND cf.region='"
						+ federated.get("region") + "' AND cf.file_type='" + federated.get("fileType") + "'";
				gson = new GsonBuilder().serializeNulls().create();
				stringJson = gson.toJson(jdbcTemplateTwo.queryForList(query));
				parser = new JSONParser();
				jsonArray = (JSONArray) parser.parse(stringJson);
				if (!jsonArray.isEmpty()) {
					JSONObject jsonObj = (JSONObject) jsonArray.get(0);
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
					Calendar cal = Calendar.getInstance();
					cal.setTime(cal.getTime());
					cal.add(Calendar.DAY_OF_MONTH, 3);
					String dateAfter = sdf.format(cal.getTime());
					data.put("collectionId", jsonObj.get("collection_id"));
					data.put("collectionName", jsonObj.get("collection_name"));
					data.put("deactivationDate", dateAfter);
					data.put("activationDate", jsonObj.get("activation_date"));
					data.put("clientId", jsonObj.get("client_id"));
					data.put("userId", jsonObj.get("created_by"));
					data.put("hasAnalysis", jsonObj.get("has_analysis"));
					data.put("analysisName", jsonObj.get("analysis_name"));
					data.put("priority", jsonObj.get("priority"));

					HttpEntity<Object> entity = new HttpEntity<>(data, headers);
					return template.exchange(innefuUrlRestClient + "/collectionmanager/updateNewCollectionById",
							HttpMethod.POST, entity, Object.class);
				} else {
//					data.put("collectionName", "test" + "_".concat(new Timestamp(System.currentTimeMillis()).toString()));
					HttpEntity<Object> entity = new HttpEntity<>(data, headers);
					return template.exchange(innefuUrlRestClient + "/collectionmanager/addNewCollection",
							HttpMethod.POST, entity, Object.class);
				}
			case "ftp":
				break;
			}
//			}
		} catch (Exception e) {

			e.printStackTrace();
		}

		return null;
	}

	@Override
	public ResponseEntity<?> getSentimentTimeline(HashMap<String, Object> data) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<>(data, headers);
		return template.exchange(innefuUrl + "/dashTimeLine", HttpMethod.POST, entity, Object.class);
	}

	// document timeline, source based document count
	@Override
	public ResponseEntity<?> getDashEntityCount(HashMap<String, Object> data) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<>(data, headers);
		return template.exchange(innefuUrl + "/dashEntityCount", HttpMethod.POST, entity, Object.class);
	}

	// top hashtags, places talked about, person talked about, top events, top
	// themes, top email ids, top mentions, org talked about, top mobile no
	@Override
	public ResponseEntity<?> getDashActiveEntity(HashMap<String, Object> data) {
//		HttpHeaders headers = getHttpHeadersAfterLogin();
		HttpHeaders headers = new HttpHeaders();
//		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<>(data, headers);
		return template.exchange(innefuUrl + "/dashActiveEntity", HttpMethod.POST, entity, Object.class);
	}

	// top languages , author location, article location, gender distribution
	@Override
	public ResponseEntity<?> getFieldTypeData(HashMap<String, Object> data) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<>(data, headers);
		return template.exchange(innefuUrl + "/getFieldTypeData", HttpMethod.POST, entity, Object.class);
	}

	@Override
	public ResponseEntity<?> dashActiveUser(HashMap<String, Object> data) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<>(data, headers);
		return template.exchange(innefuUrl + "/dashActiveUser", HttpMethod.POST, entity, Object.class);
	}

//	total_no_sents = len(obj['sentences'])
//		    
//		    if ratio != None:
//		        # Computing number of sentences as per Ratio given 
//		        num_sents = math.ceil(ratio * total_no_sents)
//		        
//		    elif num_sents != None:
//		        # Num_sents should be minimum 1
//		        num_sents = max(1, num_sents)
//		        
//		    else:
//		        num_sents = total_no_sents  # Returning whole text as summary
//		    
//		    # Choosen sentences for summary
//		    choosen_sents = []
//		    if first_sent:
//		        num_sents -= 1 # first sent is chosen for summary
//		        choosen_sents.append(obj['sentences'][0])
//		        sents = obj['sentences'][1:]  # Removing first sentences
//		        scores = obj['sentences_score'][1:]  # Removing first sentence score
//		        
//		    else:
//		        sents = obj['sentences']
//		        scores = obj['sentences_score']

//	   # Indexes sorted on the basis of scores
//	    sorted_indexes = np.argsort(scores)[::-1]  # Decreasing order
//	    
//	    # Choosing indexes as per no_sents
//	    choosen_indexes = sorted_indexes[:num_sents]
//	    choosen_indexes.sort()
//	    
//	    # Appending sentences 
//	    for idx in choosen_indexes:
//	        choosen_sents.append(sents[idx])
//	    
//	    summ = ' '.join(choosen_sents)
//	    
//	    return summ

	public static Integer[] sortIndices(List<Double> input) {

		Integer[] indices = new Integer[input.size()];

		for (int i = 0; i < input.size(); i++)
			indices[i] = i;

		Arrays.sort(indices, new Comparator<Integer>() {
			@Override
			public int compare(Integer o1, Integer o2) {
				return Double.compare(input.get(o2), input.get(o1));
//                return (int)(input[o1]-input[o2]);
			}
		});

		return indices;
//        System.out.println("Sorted indices as per input array: " + Arrays.toString(indices));
	}

	@SuppressWarnings("unused")
	@Override
	public ResponseEntity<?> getSummary(HashMap<String, Object> data) {
		String rawString = (String) data.get("text");

		JSONParser parser = new JSONParser();

		try {
			JSONObject jsonObject = (JSONObject) parser.parse(rawString);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

//		List<String> sentences = (ArrayList<String>) data.get("sentences");
//		List<Double> sentenceScore = (ArrayList<Double>) data.get("sentences_score");
//		Double ratio = 0.5;
//		Integer numSents = 5;
//		Boolean firstSent = true;
//
//		int totalNoSents = sentences.size();
//		if (ratio != null) {
//			numSents = (int) Math.ceil(ratio * totalNoSents);
//		} else if (numSents != null) {
//			numSents = Math.max(1, numSents);
//		} else {
//			numSents = totalNoSents;
//		}
//
//		List<String> choosensents = new ArrayList<>();
//		List<String> sents = new ArrayList<>();
//		List<Double> scores = new ArrayList<Double>();
//		String finalSentence = "";
//
//		if (firstSent) {
//			finalSentence = finalSentence.concat(sentences.get(0));
//			sents = sentences.subList(1, sentences.size());
//			scores = sentenceScore.subList(1, sentenceScore.size());
//			numSents -= 1;
//		} else {	List<String> sentences = (ArrayList<String>) data.get("sentences");
//		List<Double> sentenceScore = (ArrayList<Double>) data.get("sentences_score");
//		Double ratio = 0.5;
//		Integer numSents = 5;
//		Boolean firstSent = true;
//
//		int totalNoSents = sentences.size();
//		if (ratio != null) {
//			numSents = (int) Math.ceil(ratio * totalNoSents);
//		} else if (numSents != null) {
//			numSents = Math.max(1, numSents);
//		} else {
//			numSents = totalNoSents;
//		}
//
//		List<String> choosensents = new ArrayList<>();
//		List<String> sents = new ArrayList<>();
//		List<Double> scores = new ArrayList<Double>();
//		String finalSentence = "";
//
//		if (firstSent) {
//			finalSentence = finalSentence.concat(sentences.get(0));
//			sents = sentences.subList(1, sentences.size());
//			scores = sentenceScore.subList(1, sentenceScore.size());
//			numSents -= 1;
//		} else {
//			sents = sentences;
//			scores = sentenceScore;
//		}
//
//		Integer[] indices = sortIndices(scores);
//		int[] sliceIndices = new int[numSents];
//
//		for (int i = 0; i < numSents; i++)
//			sliceIndices[i] = indices[i];
//		
//		Arrays.sort(sliceIndices);
//
//		for (int index : sliceIndices)
//			finalSentence = finalSentence.concat(" ".concat(sents.get(index)));
//
//		Map<String, Object> finalResult = new HashMap<String, Object>();
//		finalResult.put("text", finalSentence);
//		HttpHeaders headers = new HttpHeaders();
//		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
//		headers.setContentType(MediaType.APPLICATION_JSON);
//		HttpEntity<Object> entity = new HttpEntity<>(finalResult, headers);
//		return new ResponseEntity<>(finalResult, headers, HttpStatus.OK);

//			sents = sentences;
//			scores = sentenceScore;
//		}
//
//		Integer[] indices = sortIndices(scores);
//		int[] sliceIndices = new int[numSents];
//
//		for (int i = 0; i < numSents; i++)
//			sliceIndices[i] = indices[i];
//		
//		Arrays.sort(sliceIndices);
//
//		for (int index : sliceIndices)
//			finalSentence = finalSentence.concat(" ".concat(sents.get(index)));
//
//		Map<String, Object> finalResult = new HashMap<String, Object>();
//		finalResult.put("text", finalSentence);
//		HttpHeaders headers = new HttpHeaders();
//		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
//		headers.setContentType(MediaType.APPLICATION_JSON);
//		HttpEntity<Object> entity = new HttpEntity<>(finalResult, headers);
//		return new ResponseEntity<>(finalResult, headers, HttpStatus.OK);
		return null;
	}

	@Override
	public ResponseEntity<?> fbScrapyBasicInfo(HashMap<String, Object> data) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<>(data, headers);
		return template.exchange(innefuUrl + "/fb_scrapy_basic_info", HttpMethod.POST, entity, Object.class);
	}

	@Override
	public ResponseEntity<?> fbScrapyUserMedia(HashMap<String, Object> data) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<>(data, headers);
		return template.exchange(innefuUrl + "/fb_scrapy_user_media", HttpMethod.POST, entity, Object.class);
	}

	@Override
	public ResponseEntity<?> fbScrapyUserCheckIns(HashMap<String, Object> data) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<>(data, headers);
		return template.exchange(innefuUrl + "/fb_scrapy_user_check_ins", HttpMethod.POST, entity, Object.class);
	}

	@Override
	public ResponseEntity<?> fbScrapyUserLikes(HashMap<String, Object> data) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<>(data, headers);
		return template.exchange(innefuUrl + "/fb_scrapy_user_likes", HttpMethod.POST, entity, Object.class);
	}

	@Override
	public ResponseEntity<?> fbTopMostUserStrongConnection(HashMap<String, Object> data) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<>(data, headers);
		return template.exchange(innefuUrl + "/fbTopMostUserStrongConnection", HttpMethod.POST, entity, Object.class);
	}

	@Override
	public ResponseEntity<?> fbScrapyUserFriends(HashMap<String, Object> data) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<>(data, headers);
		return template.exchange(innefuUrl + "/fb_scrapy_user_friends", HttpMethod.POST, entity, Object.class);
	}

	@Override
	public ResponseEntity<?> getFBPeopleProfileWithSameGroup(HashMap<String, Object> data) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<>(data, headers);
		return template.exchange(innefuUrl + "/getFBPeopleProfileWithSameGroup", HttpMethod.POST, entity, Object.class);
	}

	@Override
	public ResponseEntity<?> getFBPeopleProfileWithSameLikes(HashMap<String, Object> data) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<>(data, headers);
		return template.exchange(innefuUrl + "/getFBPeopleProfileWithSameLikes", HttpMethod.POST, entity, Object.class);
	}

	@Override
	public ResponseEntity<?> getFBPeopleProfileWithSameCheckIn(HashMap<String, Object> data) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<>(data, headers);
		return template.exchange(innefuUrl + "/getFBPeopleProfileWithSameCheckIn", HttpMethod.POST, entity,
				Object.class);
	}

	@Override
	public ResponseEntity<?> getFBPeopleProfileWithSameLocation(HashMap<String, Object> data) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<>(data, headers);
		return template.exchange(innefuUrl + "/getFBPeopleProfileWithSameLocation", HttpMethod.POST, entity,
				Object.class);
	}

	@Override
	public ResponseEntity<?> getSentiment(HashMap<String, Object> data) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<>(data, headers);
		return template.exchange(innefuUrl + "/getSentiment", HttpMethod.POST, entity, Object.class);
	}

	@Override
	public ResponseEntity<?> checkRetweetStatus(HashMap<String, Object> data) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<>(data, headers);
		return template.exchange(innefuUrl + "/checkRetweetStatus", HttpMethod.POST, entity, Object.class);
	}

//	@Override
	public ResponseEntity<ArrayList<TwitterVo>> getTweetsPostCount(TweeterActionVo tweeterActionVo) {
		long t1 = System.currentTimeMillis();

		ArrayList<TwitterVo> list = new ArrayList<TwitterVo>();
		HashSet set = new HashSet();

		// Getting the current date
		Date date = new Date();
		// This method returns the time in millis
		long timeMilli = date.getTime();

		try {
			int from = 0;
			int size = 50;
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getIsRpt())) {
				if (CommonUtils.stringNotEmpty(tweeterActionVo.getNoTweet())) {
					from = 0;
					size = Integer.parseInt(tweeterActionVo.getNoTweet());
				}
			} else {
				from = Integer.parseInt(tweeterActionVo.getRowNum());
				size = 50;
			}

			String subQuery = rtnFilterQuery(tweeterActionVo, -1);
			String query = "{\n" + "      \"from\":" + from + ",\n" + "      \"size\":" + size + ",\n" + subQuery
					+ getTweetsSortOrder(tweeterActionVo);

			if (!CommonUtils.stringNotEmpty(tweeterActionVo.getIsRpt())) {
				query += getHighlightFields();
			}

			query += "}\n";
			Search search = new Search.Builder(query).addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName()).build();

			SearchResult result = client.execute(search);
			long t2 = System.currentTimeMillis();

			List<Article_Datacollection_New> testLst = result.getSourceAsObjectList(Article_Datacollection_New.class);
			JsonArray arry = null;
			if (testLst.size() > 0) {

				arry = result.getJsonObject().get("hits").getAsJsonObject().get("hits").getAsJsonArray();
			}

			int i = 0;
			for (Article_Datacollection_New article_Datacollection_New : testLst) {
				String articleId = article_Datacollection_New.getArticleId();
				// System.out.println("articleId: "+articleId);

				if (set.add(articleId)) {
					TwitterVo twitterVo = new TwitterVo();
					String link = article_Datacollection_New.getArticleLinkUrl();
					switch (article_Datacollection_New.getArticleSource()) {
					case "tw":
						link = "https://twitter.com/" + article_Datacollection_New.getArticleAuthor() + "/status/"
								+ article_Datacollection_New.getArticleId();
						break;
					case "yt":
						link = article_Datacollection_New.getArticleLinkUrl();
						break;
					case "fb":
						break;
					case "insta":
						break;
					case "dm":
						break;

					case "wp":
						break;
					case "tm":
						break;
					case "wb":
						break;
					case "article":
						link = article_Datacollection_New.getArticleLinkUrl();
						break;

					default:
						link = article_Datacollection_New.getArticleLinkUrl();
						break;
					}

					String fileName = article_Datacollection_New.getArticleMediaCaption() == null ? ""
							: article_Datacollection_New.getArticleMediaCaption().trim();
					twitterVo.setLink(link);
					// twitterVo.setTotalTweetCount(Integer.toString(result.getTotal()));
					twitterVo.setTotalTweetCount(Long.toString(result.getTotal()));
					twitterVo.setArticleId(article_Datacollection_New.getArticleId());
					twitterVo.setArticleAuthor(article_Datacollection_New.getArticleAuthor());
					twitterVo.setArticleAuthorId(article_Datacollection_New.getArticleAuthorId());
					twitterVo.setArticleAuthorImage(article_Datacollection_New.getArticleAuthorImage());
					twitterVo.setArticleAuthorImageUrlLocal(article_Datacollection_New.getArticleAuthorImageUrlLocal());
					twitterVo.setArticlePublishDate(CommonUtils
							.convertUnixTimeToDateDisplayFormat((article_Datacollection_New.getArticlePublishDate())));
					twitterVo.setCreationDate(CommonUtils.convertUnixTimeToDateDisplayFormat(timeMilli));
					twitterVo.setArticleTitle(article_Datacollection_New.getArticleTitle());
					twitterVo.setArticleSubTitle(article_Datacollection_New.getArticleSubTitle());
					twitterVo.setArticleBigContent(article_Datacollection_New.getArticleBigContent());
					twitterVo.setArticleSentiment(article_Datacollection_New.getArticleSentiment());
					twitterVo.setArticleNewsSource(article_Datacollection_New.getArticleNewsSource());
					twitterVo.setArticleNewsCategory(article_Datacollection_New.getArticleNewsCategory());
					twitterVo.setArticleLinkUrl(article_Datacollection_New.getArticleLinkUrl());
					twitterVo.setPriority("0");
					twitterVo.setArticlePriority(article_Datacollection_New.getArticlePriority() == null ? "2"
							: article_Datacollection_New.getArticlePriority());
					twitterVo.setRssCountry(article_Datacollection_New.getRssCountry());
					twitterVo.setRssCountryCode(article_Datacollection_New.getRssCountryCode());
					twitterVo.setArticleAuthorScreenName(article_Datacollection_New.getArticleAuthorScreenName());
					twitterVo.setArticleSource(article_Datacollection_New.getArticleSource());
					twitterVo.setArticleType(article_Datacollection_New.getArticleType());
					twitterVo.setArticleMedia(article_Datacollection_New.getArticleMedia());
					twitterVo.setArticleMediaCaption(article_Datacollection_New.getArticleMediaCaption());
					twitterVo.setArticleEmotion(article_Datacollection_New.getArticleEmotion());
					twitterVo.setArticleEmotionScore(article_Datacollection_New.getArticleEmotionScore());
					twitterVo.setArticleSummary(article_Datacollection_New.getArticleSummary());
					twitterVo.setArticleClassification(article_Datacollection_New.getArticleClassification());
					twitterVo.setFtpFileUrl(TwitterConstant.getFtpFileUrl() + "ftp/" + fileName);
					twitterVo.setFederateFileUrl(TwitterConstant.getFtpFileUrl() + "federated/" + fileName);
					twitterVo.setName(fileName);

					// ArrayList<Articel_Ner> peronNerList =
					// article_Datacollection_New.getArticlePersonNer();
					twitterVo.setArticlePersonNer(article_Datacollection_New.getArticlePersonNer());
					twitterVo.setArticleLocationNer(article_Datacollection_New.getArticleLocationNer());
					twitterVo.setArticleOrganizationNer(article_Datacollection_New.getArticleOrganizationNer());
					// twitterVo.setArticleLocationNer(article_Datacollection_New.getArticleLocationNer());

					if (article_Datacollection_New.getArticleMarked() != null) {
						if (article_Datacollection_New.getArticleMarked().size() > 0) {
							String user = (String) httpSession.getAttribute(ApplicationConstants.LOGINUSERID);
							if (article_Datacollection_New.getArticleMarked().indexOf(Integer.parseInt(user)) > -1) {
								twitterVo.setPriority("1");
							}
						}
					}

					twitterVo.setTweet(article_Datacollection_New.getTweet());
					twitterVo.setYoutube(article_Datacollection_New.getYoutube());
					twitterVo.setDailymotion(article_Datacollection_New.getDailymotion());
					twitterVo.setInstagram(article_Datacollection_New.getInstagram());
					twitterVo.setFacebook(article_Datacollection_New.getFacebook());
					twitterVo.setWordpress(article_Datacollection_New.getWordpress());
					twitterVo.setBlogger(article_Datacollection_New.getBlogger());

					// Innsight Local Image and ODS, FRS
					twitterVo.setArticleImage(article_Datacollection_New.getArticleImage());
					String profileImgName = article_Datacollection_New.getArticleAuthorImageUrlLocal();
					twitterVo.setProfileLocalImage(profileImgName);
					twitterVo.setInnsightImageFlag(TwitterConstant.getInnsightImageFlag());
					twitterVo.setInnsightLocalImageUrl(TwitterConstant.getInnsightLocalImageUrl());
					twitterVo.setFacebookLocalImageUrl(TwitterConstant.getFacebookLocalImageUrl());

					if (arry.get(i).getAsJsonObject().has("highlight")) {
						JsonObject highlightObj = arry.get(i).getAsJsonObject().get("highlight").getAsJsonObject();
						if (highlightObj.has("articleTitle")) {
							try {
								twitterVo.setArticleTitle(
										highlightObj.get("articleTitle").getAsJsonArray().getAsString());
							} catch (Exception ex) {
								ex.printStackTrace();
							}
						}
						if (highlightObj.has("articleBigContent")) {
							try {
								twitterVo.setArticleBigContent(
										highlightObj.get("articleBigContent").getAsJsonArray().getAsString());
							} catch (Exception ex) {
								ex.printStackTrace();
							}
						}
					}

					list.add(twitterVo);
					i++;
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return new ResponseEntity<>(list, HttpStatus.OK);
	}

	public String rtnFilterQuery(TweeterActionVo tweeterActionVo, int type) {
		Long dateFrom = 0L;
		Long dateTo = 0L;
		String entityId = "";
		String dateFilter = "";
		String dateTypeFilter = "";
		String userFilter = "";
		String userNotFilter = "";
		String userIdFilter = "";
		String joinQuery = "";
		String timeZoneFilter = "";
		String timeZoneNotFilter = "";
		String hashTagFilter = "";
		String hashTagNotFilter = "";
		String themeFilter = "";
		String themeNotFilter = "";
		String mentionFilter = "";
		String mentionNotFilter = "";
		String domainFilter = "";
		String domainNotFilter = "";
		String urlFilter = "";
		String urlNotFilter = "";
		String advFilter = "";
		String keywordFilter = "";
		String keywordFilter1 = "";
		String tweetFlagFilter = "";
		String mediaTypeFilter = "";
		String sentimentFilter = "";
		String sentimentNotFilter = "";
		String latitudeFilter = "";
		String priorityFilter = "";
		String countryCodeFilter = "";
		String tweetIdFilter = "";
		String sourceFilter = "";
		String placeFilter = "";
		String placeNotFilter = "";
		String personFilter = "";
		String personNotFilter = "";
		String orgFilter = "";
		String orgNotFilter = "";
		String mediaFilter = "";
		String imgFilter = "";
		String imgNotFilter = "";
		String videoFilter = "";
		String videoNotFilter = "";
		String audioFilter = "";
		String audioNotFilter = "";
		String groupFilter = "";
		String groupNotFilter = "";
		String viralTextFilter = "";
		String viralTextNotFilter = "";
		String docTypeFilter = "";
		String docTypeNotFilter = "";

		String phoneNo = "";
		String wtGroupNo = "";
		String contactNo = "";
		String msgwtReceiver = "";
		String twUserCountryCode = "";
		String geoSearch = "";
		String geoPolygonFilter = "";
		String geoPolygonNotFilter = "";
		String geoUserPolygonFilter = "";
		String geoUserPolygonNotFilter = "";
		String componentFilter = "";
		String componentTweetFilter = "";
		String isComponentFilter = "";
		String classificationFilter = "";
		String classificationNotFilter = "";
		String threatClassificationFilter = "";
		String threatClassificationNotFilter = "";
		String emotionFilter = "";
		String emotionNotFilter = "";
		String langFilter = "";
		String langNotFilter = "";
		String cityFilter = "";
		String cityNotFilter = "";
		String countryFilter = "";
		String countryNotFilter = "";
		String nerDateFilter = "";
		String nerDateNotFilter = "";
		String mobileFilter = "";
		String mobileNotFilter = "";
		String emailFilter = "";
		String emailNotFilter = "";
		String userCreatedDate = "";
		String globalProfileFilter = "";
		String globalProfileFilterLinkAnalysis = "";
		String globalKeywordFilter = "";
		String globalLocationFilter = "";
		String globalFilter = "";
		String userSearch = "";
		String rssCountryCodeFilter = "";
		String eventFilter = "";
		String eventNotFilter = "";
		String taxonomyFilter = "";
		String taxonomyNotFilter = "";
		String authorCountryFilter = "";
		String authorCountryNotFilter = "";
		String authorCityFilter = "";
		String authorCityNotFilter = "";
		String articleNewsSource = "";
		String articleNewsWebsite = "";
		String articleNewsFTP = "";
		String articleNewsFederated = "";
		String wordCloudNotFilter = "";
		String articleIdFilter = "";
		String articleTitleHashFilter = "";
		String articlePriority = "";

		String retweetedUserFilter = "";
		String retweetedUserNotFilter = "";
		String articleNewsCategory = "";
		String articleNewsOtherCategory = "";
		String twUserTypeFilter = "";
		String fbUserProfileFilter = "";
		String exactMatchKeyword = "";

		try {
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getExactKeywordFilter())) {
				exactMatchKeyword = TwitterConstant.getJsonForEsMatchPhrase(tweeterActionVo.getExactKeywordFilter());
			}

			if (CommonUtils.stringNotEmpty(tweeterActionVo.getUserSearchKeyword())) {
				userSearch = TwitterConstant.getJsonForEsQueryStringWithOutField(
						TwitterConstant.searchUserByKeyword(tweeterActionVo.getUserSearchKeyword()));
			}

			if (tweeterActionVo.getProfileGlobalFilter() != null
					&& tweeterActionVo.getProfileGlobalFilter().size() > 0) {
				globalProfileFilter = TwitterConstant.getJsonForEsQueryStringWithOutField(
						TwitterConstant.getGlobalProfileFilter(tweeterActionVo.getProfileGlobalFilter()));
			}

			if (tweeterActionVo.getProfileGlobalFilterLinkAnalysis() != null
					&& tweeterActionVo.getProfileGlobalFilterLinkAnalysis().size() > 0) {
				globalProfileFilterLinkAnalysis = TwitterConstant.getJsonForEsQueryStringWithOutField(TwitterConstant
						.getGlobalProfileFilterForLinkAnalysis(tweeterActionVo.getProfileGlobalFilterLinkAnalysis()));
			}

			/*
			 * if(tweeterActionVo.getKeywordGlobalFilter().size()>0) { globalKeywordFilter=
			 * TwitterConstant.getJsonForEsQueryString("",TwitterConstant.
			 * getGlobalKeywordFilter(tweeterActionVo.getKeywordGlobalFilter())); }
			 */
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getKeywordFilter())) // Search By Keyword
			{
				keywordFilter = TwitterConstant.getJsonForEsQueryStringCustomType("articleTitle",
						tweeterActionVo.getKeywordFilter().trim(), tweeterActionVo.getSearchType().trim());
			}

			if (CommonUtils.stringNotEmpty(tweeterActionVo.getGeoDistance())
					&& CommonUtils.stringNotEmpty(tweeterActionVo.getGeoPoint())) // Geo Circle Query
			{
				/*
				 * ArrayList<ArrayList<LocationPoints>> lst = new ArrayList<>(); for(String
				 * string : tweeterActionVo.getLocationGlobalFilter()) {
				 * ArrayList<LocationPoints> lstLocationPoints = new ArrayList<>();
				 * 
				 * String[] arr = string.split(","); LocationPoints locationPoints = new
				 * LocationPoints(); locationPoints.setLat( Double.parseDouble(arr[2]));
				 * locationPoints.setLng(Double.parseDouble(arr[1]));
				 * lstLocationPoints.add(locationPoints);
				 * 
				 * locationPoints=new LocationPoints();
				 * locationPoints.setLat(Double.parseDouble(arr[2]));
				 * locationPoints.setLng(Double.parseDouble(arr[3]));
				 * lstLocationPoints.add(locationPoints);
				 * 
				 * locationPoints=new LocationPoints();
				 * locationPoints.setLat(Double.parseDouble(arr[0]));
				 * locationPoints.setLng(Double.parseDouble(arr[3]));
				 * lstLocationPoints.add(locationPoints);
				 * 
				 * locationPoints=new LocationPoints();
				 * locationPoints.setLat(Double.parseDouble(arr[0]));
				 * locationPoints.setLng(Double.parseDouble(arr[1]));
				 * lstLocationPoints.add(locationPoints); lst.add(lstLocationPoints); }
				 */
				// globalLocationFilter = TwitterConstant.getJsonForEsPolygon(lst,
				// "articleLocation");
				String[] cordinates = tweeterActionVo.getGeoPoint().split(",");
				String lat = cordinates[0];
				String lon = cordinates[1];

				globalLocationFilter = TwitterConstant.getJsonForEsGeoDistance(tweeterActionVo.getGeoDistance(),
						"articleLocation", lat, lon);

			}

			// ARTICLE SOURCE FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getRssCountryCode())) // Multiple RssCountryCode
			{
				String[] userArr = tweeterActionVo.getRssCountryCode().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				rssCountryCodeFilter = TwitterConstant.getJsonForEs("rssCountryCode", userToFilter);
			}

			// ARTICLE News Catyegory
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getArticleNewsCategory())) // Multiple News Source
			{
				String[] userArr = tweeterActionVo.getArticleNewsCategory().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);

				if (tweeterActionVo.getArticleNewsCategory().equals("main_news")) {
					articleNewsCategory = TwitterConstant.getJsonForEs("articleNewsCategory", userToFilter);
				} else {
					articleNewsOtherCategory = TwitterConstant.getJsonForEs("articleNewsCategory", "\"main_news\"");
				}
			}

			// ARTICLE News Source
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getArticleNewsSource())) // Multiple News Source
			{
				String[] userArr = tweeterActionVo.getArticleNewsSource().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				articleNewsSource = TwitterConstant.getJsonForEs("articleNewsSource", userToFilter);
			}

			// ARTICLE News Website
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getArticleNewsWebsite())) // Multiple News Website
			{
				String[] userArr = tweeterActionVo.getArticleNewsWebsite().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				articleNewsWebsite = TwitterConstant.getJsonForEs("articleNewsSource", userToFilter);
			}

			// ARTICLE News FTP
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getArticleNewsFTP())) // Multiple News FTP
			{
				String[] userArr = tweeterActionVo.getArticleNewsFTP().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				articleNewsFTP = TwitterConstant.getJsonForEs("articleNewsSource", userToFilter);
			}

			// ARTICLE News FEDERATED
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getArticleNewsFederated())) // Multiple News FEDERATED
			{
				String[] userArr = tweeterActionVo.getArticleNewsFederated().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				articleNewsFederated = TwitterConstant.getJsonForEs("keywordIds", userToFilter);
			}

			// ARTICLE SOURCE
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getSourceFilter())) // Multiple Source Filter
			{
				ArrayList<String> lstSource = new ArrayList<>();
				if (tweeterActionVo.getProfileGlobalFilter() != null
						&& tweeterActionVo.getProfileGlobalFilter().size() > 0) {
					for (Map<String, String> map : tweeterActionVo.getProfileGlobalFilter()) {
						String sourceType = map.values().toArray()[1].toString();
						if (!lstSource.contains(sourceType.toLowerCase())) {
							lstSource.add(sourceType.toLowerCase().trim());
						}
					}
					String userToFilter = "";
					for (String user : lstSource) {
						userToFilter += "\"" + user.trim() + "\",";
					}
					if (userToFilter.length() > 0) {
						userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
						sourceFilter = TwitterConstant.getJsonForEs("articleSource", userToFilter);
					}
				} else {

					String[] userArr = tweeterActionVo.getSourceFilter().split(",");
					String userToFilter = "";
					for (String user : userArr) {
						/*
						 * if(lstSource.size()>0) { if(lstSource.contains(user)) {
						 * userToFilter+="\""+user.trim()+"\","; } } else {
						 */
						userToFilter += "\"" + user.trim() + "\",";
						// }
					}

					System.out.println("userToFilter:------------ " + userToFilter);
					if (userToFilter.length() > 0) {
						userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
						sourceFilter = TwitterConstant.getJsonForEs("articleSource", userToFilter);
					}
				}
			}

			// if(!globalProfileFilter.isEmpty() || !keywordFilter.isEmpty() ||
			// !globalLocationFilter.isEmpty())
			{
				switch (tweeterActionVo.getProfileBool().toLowerCase()) {
				case "and":
					globalFilter = "\n,{\n\"bool\":\n{" + "\"must\":[\n{}\n" + globalProfileFilter
							+ globalLocationFilter + rssCountryCodeFilter + "\n]\n" + "}\n}\n";
					break;

				case "or":
					globalFilter = "\n,{\n\"bool\":\n{" + "\"should\":[\n{}\n";

					// globalLocationFilter ;
					if (!globalProfileFilter.trim().isEmpty()) {
						globalFilter += "\n,{\n\"bool\":\n{" + "\"must\":[\n{}" + globalProfileFilter
								+ globalLocationFilter + sourceFilter + "\n]}}";

					} else {
						if (!globalLocationFilter.trim().isEmpty()) {
							globalFilter += "\n,{\n\"bool\":\n{" + "\"must\":[\n{}" + globalLocationFilter
									+ sourceFilter + "\n]}}";
						} else {
							globalFilter += sourceFilter;
						}
					}

					globalFilter += rssCountryCodeFilter + articleNewsSource + articleNewsWebsite + articleNewsFTP
							+ articleNewsFederated + "\n]\n" + "}\n}\n";
					break;
				}
			}

			// *************Only For Target Views**********
			String targetView = "";
			if (tweeterActionVo.getIsView().equals("y")) {
				globalFilter = "";
				targetView = "\n,{\n\"bool\":\n{" + "\"should\":[\n{}\n" + keywordFilter + globalProfileFilter + "\n]\n"
						+ "}\n}\n";

				keywordFilter = "";
				globalProfileFilter = "";
			}

			if (type != 5) // TimeLineGraph
			{

				boolean dateFlag = false;
				if (CommonUtils.stringNotEmpty(tweeterActionVo.getDateFromGrph())
						&& CommonUtils.stringNotEmpty(tweeterActionVo.getDateToGrph())) {
					dateFlag = true;
					dateFrom = TwitterConstant.convertDateToTimeStamp(tweeterActionVo.getDateFromGrph());
					dateTo = TwitterConstant.convertDateToTimeStamp(tweeterActionVo.getDateToGrph());
				} else if (CommonUtils.stringNotEmpty(tweeterActionVo.getDateFrom())
						&& CommonUtils.stringNotEmpty(tweeterActionVo.getDateTo())) {
					dateFlag = true;
					dateFrom = TwitterConstant.convertDateToTimeStamp(tweeterActionVo.getDateFrom());
					dateTo = TwitterConstant.convertDateToTimeStamp(tweeterActionVo.getDateTo());
				}

				if (dateFlag) {
					// dateFrom = dateFrom + 19800000l;
					if (CommonUtils.stringNotEmpty(tweeterActionVo.getDateTypeFilter())) {
						dateTypeFilter = tweeterActionVo.getDateTypeFilter();
						if (dateTypeFilter.equalsIgnoreCase("publishedDate")) {
							dateFilter = ",{\n" + "\"range\": {\n" + "\"articlePublishDate\": {\n" + "\"gte\": "
									+ dateFrom + ",\n" + "\"lte\": " + dateTo + "\n" + "}\n" + "}\n" + "}\n";
						} else if (dateTypeFilter.equalsIgnoreCase("insertDate")) {
							dateFilter = ",{\n" + "\"range\": {\n" + "\"articleInsertedDate\": {\n" + "\"gte\": "
									+ dateFrom + ",\n" + "\"lte\": " + dateTo + "\n" + "}\n" + "}\n" + "}\n";
						}
					} else {
						dateFilter = ",{\n" + "\"range\": {\n" + "\"articlePublishDate\": {\n" + "\"gte\": " + dateFrom
								+ ",\n" + "\"lte\": " + dateTo + "\n" + "}\n" + "}\n" + "}\n";
					}
				}
			}

			if (CommonUtils.stringNotEmpty(tweeterActionVo.getUserFilter1())) // Multiple UserName Report
			{
				String[] userArr = tweeterActionVo.getUserFilter1().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				userIdFilter = TwitterConstant.getJsonForEs("articleAuthorId", userToFilter);
			}

			if (CommonUtils.stringNotEmpty(tweeterActionVo.getUserIdFilter())) // Multiple UserName Id Report
			{
				String[] userArr = tweeterActionVo.getUserIdFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				userIdFilter = TwitterConstant.getJsonForEs("articleAuthorId", userToFilter);
			}

			if (CommonUtils.stringNotEmpty(tweeterActionVo.getFbUserProfileFilter())) // Facebook Profile Report
			{

				String[] userArr = tweeterActionVo.getFbUserProfileFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				// fbUserProfileFilter = TwitterConstant.getJsonForEs("facebook.fbPostPageId",
				// userToFilter);
				fbUserProfileFilter = TwitterConstant.getJsonForEs("articleAuthorId", userToFilter);
			}

			if (CommonUtils.stringNotEmpty(tweeterActionVo.getUserFilter())) // Multiple UserName
			{
				String[] userArr = tweeterActionVo.getUserFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += " articleAuthor:" + user.trim() + " OR articleAuthorId:" + user.trim() + " OR";
				}

				userToFilter = userToFilter.substring(0, userToFilter.length() - 2);
				// userToFilter=userToFilter+"";
				// userFilter= TwitterConstant.getJsonForEs("articleAuthor",userToFilter);
				userFilter = TwitterConstant.getJsonForEsQueryStringWithOutField(userToFilter);
			}

			if (CommonUtils.stringNotEmpty(tweeterActionVo.getUserNotFilter())) // Multiple UserName Not
			{
				String[] userArr = tweeterActionVo.getUserNotFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += " articleAuthor:" + user.trim() + " OR articleAuthorId:" + user.trim() + " OR";
				}

				userToFilter = userToFilter.substring(0, userToFilter.length() - 2);
				userNotFilter = TwitterConstant.getJsonForEsQueryStringWithOutField(userToFilter);

			}

			if (CommonUtils.stringNotEmpty(tweeterActionVo.getRetweetUserFilter())) // Multiple Retweeted User UserName
			{
				String[] userArr = tweeterActionVo.getRetweetUserFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				retweetedUserFilter = TwitterConstant.getJsonForEs("tweet.tweetRetweetUserScreenName", userToFilter);
			}

			if (CommonUtils.stringNotEmpty(tweeterActionVo.getRetweetUserNotFilter())) // Multiple Retweeted User Not
			{
				String[] userArr = tweeterActionVo.getRetweetUserNotFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				retweetedUserNotFilter = TwitterConstant.getJsonForEs("tweet.tweetRetweetUserScreenName", userToFilter);
			}

			if (CommonUtils.stringNotEmpty(tweeterActionVo.getTimeZoneFilter())) // Multiple TimeZone Filter
			{
				String[] userArr = tweeterActionVo.getTimeZoneFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				timeZoneFilter = TwitterConstant.getJsonForEs("user.timeZone", userToFilter);
			}

			if (CommonUtils.stringNotEmpty(tweeterActionVo.getTimeZoneNotFilter())) // Multiple TimeZone Not Filter
			{
				String[] userArr = tweeterActionVo.getTimeZoneNotFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				timeZoneNotFilter = TwitterConstant.getJsonForEs("user.timeZone", userToFilter);
			}

			// HASHTAG FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getHashTagFilter())) // Multiple Hashtag
			{
				String[] userArr = tweeterActionVo.getHashTagFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim().substring(1) + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				hashTagFilter = TwitterConstant.getJsonForEs("articleHashTag", userToFilter);
			}

			// HASHTAG NOT FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getHashTagNotFilter())) // Multiple Hashtag Not
			{
				String[] userArr = tweeterActionVo.getHashTagNotFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim().substring(1) + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				hashTagNotFilter = TwitterConstant.getJsonForEs("articleHashTag", userToFilter);
			}

			// PHONE FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getMobileFilter())) // Multiple Phone
			{
				String[] userArr = tweeterActionVo.getMobileFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				mobileFilter = TwitterConstant.getJsonForEs("articleMobile", userToFilter);
			}

			// PHONE NOT FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getMobileNotFilter())) // Multiple Phone Not
			{
				String[] userArr = tweeterActionVo.getMobileNotFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				mobileNotFilter = TwitterConstant.getJsonForEs("articleMobile", userToFilter);
			}

			// EVENT FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getEventFilter())) // Multiple Event
			{
				String[] userArr = tweeterActionVo.getEventFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				eventFilter = TwitterConstant.getJsonForEs("articleEvent.keyword", userToFilter);
			}

			// EVENT NOT FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getEventNotFilter())) // Multiple Event Not
			{
				String[] userArr = tweeterActionVo.getEventNotFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				eventNotFilter = TwitterConstant.getJsonForEs("articleEvent.keyword", userToFilter);
			}

			// TAXONOMY FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getTaxonomyFilter())) // Multiple Taxonomy
			{
				String[] userArr = tweeterActionVo.getTaxonomyFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				taxonomyFilter = TwitterConstant.getJsonForEs("taxonomy", userToFilter);
			}

			// TAXONOMY NOT FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getTaxonomyNotFilter())) // Multiple Taxonomy Not
			{
				String[] userArr = tweeterActionVo.getTaxonomyNotFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				taxonomyNotFilter = TwitterConstant.getJsonForEs("taxonomy", userToFilter);
			}

			// AUTHOR COUNTRY FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getAuthorCountryFilter())) // Multiple Author Country
			{
				String[] userArr = tweeterActionVo.getAuthorCountryFilter().split("&&&");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				authorCountryFilter = TwitterConstant.getJsonForEs("tweet.tweetUser.tweetUserLocation", userToFilter);
			}

			// AUTHOR COUNTRY NOT FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getAuthorCountryNotFilter())) // Multiple Author Country Not
			{
				String[] userArr = tweeterActionVo.getAuthorCountryNotFilter().split("&&&");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				authorCountryNotFilter = TwitterConstant.getJsonForEs("tweet.tweetUser.tweetUserLocation",
						userToFilter);
			}

			// AUTHOR CITY FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getAuthorCityFilter())) // Multiple Author City
			{
				String[] userArr = tweeterActionVo.getAuthorCityFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				authorCityFilter = TwitterConstant.getJsonForEs("tweet.tweetUser.tweetUserLocation", userToFilter);
			}

			// AUTHOR CITY NOT FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getAuthorCityNotFilter())) // Multiple Author City Not
			{
				String[] userArr = tweeterActionVo.getAuthorCityNotFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				authorCityNotFilter = TwitterConstant.getJsonForEs("tweet.tweetUser.tweetUserLocation", userToFilter);
			}

			// EMAIL FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getEmailFilter())) // Multiple Email
			{
				String[] userArr = tweeterActionVo.getEmailFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				emailFilter = TwitterConstant.getJsonForEs("articleEmail", userToFilter);
			}

			// EMAIL NOT FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getEmailNotFilter())) // Multiple Email Not
			{
				String[] userArr = tweeterActionVo.getEmailNotFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				emailNotFilter = TwitterConstant.getJsonForEs("articleEmail", userToFilter);
			}

			// THEMES FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getThemeFilter())) // Multiple Theme
			{
				String[] userArr = tweeterActionVo.getThemeFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				themeFilter = TwitterConstant.getJsonForEs("articleThemes", userToFilter);
			}

			// THEMES NOT FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getThemeNotFilter())) // Multiple Theme Not
			{
				String[] userArr = tweeterActionVo.getThemeNotFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				themeNotFilter = TwitterConstant.getJsonForEs("articleThemes", userToFilter);
			}

			// IMAGE FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getImgFilter())) // Multiple Image
			{
				String[] userArr = tweeterActionVo.getImgFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				// imgFilter =
				// TwitterConstant.getJsonForEs("articleMedia.mediaUrl",userToFilter);
				imgFilter = TwitterConstant.getJsonForEs("articleMedia.mediaThumbnail", userToFilter);
			}

			// IMAGE NOT FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getImgNotFilter())) // Multiple Image not
			{
				String[] userArr = tweeterActionVo.getImgNotFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				// imgNotFilter =
				// TwitterConstant.getJsonForEs("articleMedia.mediaUrl",userToFilter);
				imgNotFilter = TwitterConstant.getJsonForEs("articleMedia.mediaThumbnail", userToFilter);
			}

			// VIDEO FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getVideoFilter())) // Multiple Video
			{
				String[] userArr = tweeterActionVo.getVideoFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				// videoFilter =
				// TwitterConstant.getJsonForEs("articleMedia.mediaUrl",userToFilter);
				videoFilter = TwitterConstant.getJsonForEs("articleMedia.mediaThumbnail", userToFilter);
			}

			// VIDEO NOT FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getVideoNotFilter())) // Multiple Video not
			{
				String[] userArr = tweeterActionVo.getVideoNotFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				// videoNotFilter =
				// TwitterConstant.getJsonForEs("articleMedia.mediaUrl",userToFilter);
				videoNotFilter = TwitterConstant.getJsonForEs("articleMedia.mediaThumbnail", userToFilter);
			}

			// PERSON FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getPersonFilter())) // Multiple Person
			{
				String[] userArr = tweeterActionVo.getPersonFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				if (userToFilter.length() > 0)
					userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				personFilter = TwitterConstant.getJsonForEsNested("articlePersonNer", "articlePersonNer.keyword",
						userToFilter);
			}

			// PERSON NOT FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getPersonNotFilter())) // Multiple Person Not
			{
				String[] userArr = tweeterActionVo.getPersonNotFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				personNotFilter = TwitterConstant.getJsonForEsNested("articlePersonNer", "articlePersonNer.keyword",
						userToFilter);
			}

			// DATE FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getNerDateFilter())) // Multiple NerDate calender
			{
				String[] userArr = tweeterActionVo.getNerDateFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				// nerDateFilter= TwitterConstant.getJsonForEsNested("articleDateNer",
				// "articleDateNer.keyword", userToFilter);
				nerDateFilter = TwitterConstant.getJsonForEs("articleDateNer.keyword", userToFilter);

			}

			// DATE NOT FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getNerDateNotFilter())) // Multiple NerDate calender Not
			{
				String[] userArr = tweeterActionVo.getNerDateNotFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				// nerDateNotFilter= TwitterConstant.getJsonForEsNested("articleDateNer",
				// "articleDateNer.keyword", userToFilter);
				nerDateNotFilter = TwitterConstant.getJsonForEs("articleDateNer.keyword", userToFilter);
			}

			// PLACE FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getLocationFilter())) // Multiple Place
			{
				String[] userArr = tweeterActionVo.getLocationFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				placeFilter = TwitterConstant.getJsonForEsNested("articleLocationNer", "articleLocationNer.keyword",
						userToFilter);
			}

			// PLACE NOT FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getLocationNotFilter())) // Multiple Place Not
			{
				String[] userArr = tweeterActionVo.getLocationNotFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				placeNotFilter = TwitterConstant.getJsonForEsNested("articleLocationNer", "articleLocationNer.keyword",
						userToFilter);
			}

			// ORGANIZATION FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getOrgFilter())) // Multiple Organization
			{
				String[] userArr = tweeterActionVo.getOrgFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				orgFilter = TwitterConstant.getJsonForEsNested("articleOrganizationNer",
						"articleOrganizationNer.keyword", userToFilter);
			}

			// ORGANIZATION NOT FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getOrgNotFilter())) // Multiple Organization Not
			{
				String[] userArr = tweeterActionVo.getOrgNotFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				orgNotFilter = TwitterConstant.getJsonForEsNested("articleOrganizationNer",
						"articleOrganizationNer.keyword", userToFilter);
			}

			// MENTIONS FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getMentionFilter())) // Multiple Mentions
			{
				String[] userArr = tweeterActionVo.getMentionFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim().substring(1) + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				mentionFilter = TwitterConstant.getJsonForEs("articleMention", userToFilter);
			}

			// MENTIONS NOT FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getMentionNotFilter())) // Multiple Mentions Not
			{
				String[] userArr = tweeterActionVo.getMentionNotFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim().substring(1) + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				mentionNotFilter = TwitterConstant.getJsonForEs("articleMention", userToFilter);
			}

			// LANGUAGE FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getLangFilter())) // Multiple Language
			{
				String[] userArr = tweeterActionVo.getLangFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				langFilter = TwitterConstant.getJsonForEs("articleLanguage", userToFilter);
			}

			// LANGUAGE NOT FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getLangNotFilter())) // Multiple Language Not
			{
				String[] userArr = tweeterActionVo.getLangNotFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				langNotFilter = TwitterConstant.getJsonForEs("articleLanguage", userToFilter);
			}

			// COUNTRY FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getCountryFilter())) // Multiple Country
			{
				String[] userArr = tweeterActionVo.getCountryFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				countryFilter = TwitterConstant.getJsonForEs("articleLocationCountry", userToFilter);
			}

			// COUNTRY NOT FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getCountryNotFilter())) // Multiple Country Not
			{
				String[] userArr = tweeterActionVo.getCountryNotFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				countryNotFilter = TwitterConstant.getJsonForEs("articleLocationCountry", userToFilter);
			}

			// CITY FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getCityFilter())) // Multiple City
			{
				String[] userArr = tweeterActionVo.getCityFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				cityFilter = TwitterConstant.getJsonForEs("articleLocationCity", userToFilter);
			}

			// CITY NOT FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getCityNotFilter())) // Multiple City Not
			{
				String[] userArr = tweeterActionVo.getCityNotFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				cityNotFilter = TwitterConstant.getJsonForEs("articleLocationCity", userToFilter);
			}

			// DOMAINS FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getDomainFilter())) // Multiple Domain
			{
				String[] userArr = tweeterActionVo.getDomainFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				domainFilter = TwitterConstant.getJsonForEs("articleMedia.mediaUrl", userToFilter);
			}

			// DOMAINS NOT FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getDomainNotFilter())) // Multiple Domain Not
			{
				String[] userArr = tweeterActionVo.getDomainNotFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				domainNotFilter = TwitterConstant.getJsonForEs("articleMedia.mediaUrl", userToFilter);
			}

			// URL LINK FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getLinkFilter())) // Multiple URL
			{
				String[] userArr = tweeterActionVo.getLinkFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				urlFilter = TwitterConstant.getJsonForEs("articleMedia.mediaUrl", userToFilter);
			}

			// URL LINK NOT FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getLinkNotFilter())) // Multiple URL Not
			{
				String[] userArr = tweeterActionVo.getLinkNotFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				urlNotFilter = TwitterConstant.getJsonForEs("articleMedia.mediaUrl", userToFilter);
			}

			// ADVANCE FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getAdvFilter())) // Advance Filter
			{
				advFilter = TwitterConstant.getJsonForEsQueryStringWithOutField(tweeterActionVo.getAdvFilter().trim());
			}

			/*
			 * if(CommonUtils.stringNotEmpty(tweeterActionVo.getKeywordFilter())) //Search
			 * By Keyword { keywordFilter=
			 * TwitterConstant.getJsonForEsQueryString("articleTitle",tweeterActionVo.
			 * getKeywordFilter().trim()); }
			 */

			// REPORT KEYWORD FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getKeywordFilter1())) // Search By Report Keyword
			{
				keywordFilter1 = TwitterConstant.getJsonForEsQueryString("articleTitle",
						tweeterActionVo.getKeywordFilter1().trim());
			}

			// ALL TWEET FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getAllTweetFilter())) {
				if (tweeterActionVo.getAllTweetFilter().equals("0")
						|| tweeterActionVo.getAllTweetFilter().equals("1")) {
					tweetFlagFilter = TwitterConstant.getJsonForEsTerm("tweet.tweetIsRetweetFlag",
							"\"" + tweeterActionVo.getAllTweetFilter() + "\"");
				} else {
					mediaTypeFilter = TwitterConstant.getJsonForEsTerm("articleMedia.mediaType",
							"\"" + tweeterActionVo.getAllTweetFilter() + "\"");
				}
			}

			// Tweet PRIORITY FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getArticlePriority())) {
				/*
				 * switch (tweeterActionVo.getArticlePriority()) { case "0": articlePriority=
				 * ",{\n"+ "\"range\": {\n"+ "\"articlePriority\": {\n"+ "\"lte\":0\n"+ "}\n"+
				 * "}\n"+ "}\n"; break; case "0.5": articlePriority= ",{\n"+ "\"range\": {\n"+
				 * "\"articlePriority\": {\n"+ "\"gt\":0,\n"+ "\"lt\":1\n"+ "}\n"+ "}\n"+ "}\n";
				 * break; case "1": articlePriority= ",{\n"+ "\"range\": {\n"+
				 * "\"articlePriority\": {\n"+ "\"gte\":1\n"+ "}\n"+ "}\n"+ "}\n"; break;
				 * 
				 * default: break; }
				 */

				// 0= not important ,1=most important ,3= less important
				articlePriority = TwitterConstant.getJsonForEsTerm("articlePriority",
						"" + tweeterActionVo.getArticlePriority() + "");
			}

			// SENTIMENT FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getSentimentFilter())) // -2,-1,0,1,2
			{
				String[] userArr = tweeterActionVo.getSentimentFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				sentimentFilter = TwitterConstant.getJsonForEs("articleSentiment", userToFilter);

				// sentimentFilter=
				// TwitterConstant.getJsonForEsTerm("articleSentiment","\""+tweeterActionVo.getSentimentFilter()+"\"");
			}

			// EMOTION FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getEmotionFilter())) // Emotion Filter
			{
				String[] userArr = tweeterActionVo.getEmotionFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				emotionFilter = TwitterConstant.getJsonForEs("articleEmotion", userToFilter);
				// emotionFilter=
				// TwitterConstant.getJsonForEsTerm("articleEmotion","\""+tweeterActionVo.getEmotionFilter()+"\"");
			}

			// TWITTER USER VERIFIED FILTER
			String userType = tweeterActionVo.getTwUserType();
			if (userType != null) {
				if (userType.equals("verified")) {
					twUserTypeFilter = TwitterConstant.getJsonForEs("tweet.tweetUser.tweetUserVerified", "true");
				} else if (userType.equals("notVerified")) {
					twUserTypeFilter = TwitterConstant.getJsonForEs("tweet.tweetUser.tweetUserVerified", "false");
				}
			}

			/*
			 * if(CommonUtils.stringNotEmpty(tweeterActionVo.getTwUserType())) { String[]
			 * userArr=tweeterActionVo.getClassificationFilter().split(","); String
			 * userToFilter=""; for(String user : userArr) { userToFilter+="\""+user+"\",";
			 * } userToFilter=userToFilter.substring(0, userToFilter.length()-1);
			 * 
			 * classificationFilter=
			 * TwitterConstant.getJsonForEs("articleClassification",userToFilter); }
			 */

			// MEDIA FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getMediaType())) // image,video,url,domain
			{
				mediaFilter = TwitterConstant.getJsonForEsTerm("articleMedia.mediaType",
						"\"" + tweeterActionVo.getMediaType() + "\"");
			}

			// USER CREATION DATE FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getUserCreatedDateFrom())
					&& CommonUtils.stringNotEmpty(tweeterActionVo.getUserCreatedDateTo())) // User Creation Date
			{
				long dateUserFrom = TwitterConstant.convertDateToTimeStamp(tweeterActionVo.getUserCreatedDateFrom());
				long dateUserTo = TwitterConstant.convertDateToTimeStamp(tweeterActionVo.getUserCreatedDateTo());
				userCreatedDate = ",{\n" + "\"range\": {\n" + "\"tweet.tweetUser.tweetUserCreatedTime\": {\n"
						+ "\"from\": " + dateUserFrom + ",\n" + "\"to\": " + dateUserTo + "\n" + "}\n" + "}\n" + "}\n";
			}

			// PRIORITY FILTER
			/*
			 * String
			 * loginUserId=(String)httpSession.getAttribute(ApplicationConstants.LOGINUSERID
			 * ); if(CommonUtils.stringNotEmpty(tweeterActionVo.getPriorityFilter()) &&
			 * tweeterActionVo.getPriorityFilter().equals("1")) //0,1 {
			 * priorityFilter=TwitterConstant.getJsonForEsTerm("articleMarked",
			 * "\""+loginUserId+"\""); }
			 */

			// LATITUDE FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getLatitude())
					&& CommonUtils.stringNotEmpty(tweeterActionVo.getLongitude())) // tweet latitute and longitud
			{
				latitudeFilter = TwitterConstant.getJsonForEsTermLatLong("\"" + tweeterActionVo.getLatitude() + "\"",
						"\"" + tweeterActionVo.getLongitude() + "\"");
			}

			// COUNTRY CODE FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getCountryCode())) {
				countryCodeFilter = TwitterConstant.getJsonForEsTerm("articleLocationCountryCode",
						"\"" + tweeterActionVo.getCountryCode() + "\"");
			}

			// TWITTER USER COUNTRY FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getTwUserCountryCode())) {
				twUserCountryCode = TwitterConstant.getJsonForEsTerm("tweet.tweetUser.tweetUserCountryCode",
						"\"" + tweeterActionVo.getTwUserCountryCode() + "\"");
			}

			// GEO SEARCH FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getIsMap())) {
				geoSearch = TwitterConstant.getJsonForEsForExist("articleLocation");
			}

			// GEO SEARCH USER FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getIsUserMap())) {
				geoSearch = TwitterConstant.getJsonForEsForExist("articleUserLocation");
			}

			// COMPONENT TYPE FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getIsComponent())
					&& CommonUtils.stringNotEmpty(tweeterActionVo.getComponentType())) {
				switch (tweeterActionVo.getComponentType().trim().toLowerCase()) {
				case "hashtag":
					isComponentFilter = TwitterConstant.getJsonForEsForExist("articleHashTag");
					break;
				case "mention":
					isComponentFilter = TwitterConstant.getJsonForEsForExist("articleMention");
					break;
				case "user":
					isComponentFilter = TwitterConstant.getJsonForEsForExist("articleAuthor");
					break;
				case "place":
					isComponentFilter = TwitterConstant.getJsonForEsForExist("articleLocationNer");
					break;
				case "person":
					isComponentFilter = TwitterConstant.getJsonForEsForExist("articlePersonNer");
					break;
				case "org":
					isComponentFilter = TwitterConstant.getJsonForEsForExist("articleOrganizationNer");
					break;
				case "date":
					isComponentFilter = TwitterConstant.getJsonForEsForExist("articleDateNer");
					break;
				case "language":
					isComponentFilter = TwitterConstant.getJsonForEsForExist("articleLanguage");
					break;
				case "country":
					isComponentFilter = TwitterConstant.getJsonForEsForExist("articleLocationCountry");
					break;
				case "themes":
					isComponentFilter = TwitterConstant.getJsonForEsForExist("articleThemes");
					break;
				case "city":
					isComponentFilter = TwitterConstant.getJsonForEsForExist("articleLocationCity");
					break;
				case "phone":
					isComponentFilter = TwitterConstant.getJsonForEsForExist("articleMobile");
					break;
				case "email":
					isComponentFilter = TwitterConstant.getJsonForEsForExist("articleEmail");
					break;
				case "event":
					isComponentFilter = TwitterConstant.getJsonForEsForExist("articleEvent.keyword");
					break;
				case "taxonomy":
					isComponentFilter = TwitterConstant.getJsonForEsForExist("taxonomy");
					break;
				case "authorCountry":
					isComponentFilter = TwitterConstant.getJsonForEsForExist("tweet.tweetUser.tweetUserCountry");
					break;
				case "authorCity":
					isComponentFilter = TwitterConstant.getJsonForEsForExist("tweet.tweetUser.tweetUserLocation");
					break;
				default:
					break;
				}
			}

			// REPORT FILTER*************
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getIsRpt())) {
				if (CommonUtils.stringNotEmpty(tweeterActionVo.getTweetId())) {
					String[] userArr = tweeterActionVo.getTweetId().split(",");
					String userToFilter = "";
					for (String user : userArr) {
						userToFilter += "\"" + user + "\",";
					}
					userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
					tweetIdFilter = TwitterConstant.getJsonForEs("articleId", userToFilter);
				}
			}

			// GEO POLYGON FILTER
			if (tweeterActionVo.getGeoPolygon() != null && tweeterActionVo.getGeoPolygon().size() > 0) {
				geoPolygonFilter = TwitterConstant.getJsonForEsPolygon(tweeterActionVo.getGeoPolygon(),
						"articleLocation");
			}

			// GEO POLYGON NOT FILTER
			if (tweeterActionVo.getGeoPolygonNot() != null) {
				geoPolygonNotFilter = TwitterConstant.getJsonForEsPolygon(tweeterActionVo.getGeoPolygonNot(),
						"articleLocation");
			}

			// GEO USER POLYGON FILTER
			if (tweeterActionVo.getGeoUserPolygon() != null && tweeterActionVo.getGeoUserPolygon().size() > 0) {
				geoUserPolygonFilter = TwitterConstant.getJsonForEsPolygon(tweeterActionVo.getGeoUserPolygon(),
						"articleUserLocation");
			}

			// GEO USER POLYGON NOT FILTER
			if (tweeterActionVo.getGeoUserPolygonNot() != null && tweeterActionVo.getGeoUserPolygonNot().size() > 0) {
				geoUserPolygonNotFilter = TwitterConstant.getJsonForEsPolygon(tweeterActionVo.getGeoUserPolygonNot(),
						"articleUserLocation");
			}

			// COMPONENT KEYWORD FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getComponentKeyword())
					&& CommonUtils.stringNotEmpty(tweeterActionVo.getComponentType())) {
				/*
				 * If User Filter Tweet & Retweet only then it Wont Work.
				 */
				/*
				 * if(!CommonUtils.stringNotEmpty(tweeterActionVo.getAllTweetFilter())) {
				 * if(CommonUtils.stringNotEmpty(tweeterActionVo.getSourceFilter())) //Multiple
				 * Source Filter { String[]
				 * userArr=tweeterActionVo.getSourceFilter().split(","); boolean found =
				 * Arrays.stream(userArr).anyMatch(x -> "tw".equals(x)); if(found) { String
				 * val="0"; componentTweetFilter=
				 * TwitterConstant.getJsonForEsTerm("tweet.tweetIsRetweetFlag","\""+val+"\""); }
				 * } }
				 */

				String keyword = "\"" + tweeterActionVo.getComponentKeyword() + "\"";
				switch (tweeterActionVo.getComponentType().trim().toLowerCase()) {
				case "hashtag":
					componentFilter = TwitterConstant.getJsonForEs("articleHashTag", keyword);
					break;
				case "mention":
					componentFilter = TwitterConstant.getJsonForEs("articleMention", keyword);
					break;
				case "user":
					componentFilter = TwitterConstant.getJsonForEs("articleAuthor", keyword);
					break;
				case "place":
					componentFilter = TwitterConstant.getJsonForEsNested("articleLocationNer",
							"articleLocationNer.keyword", keyword);
					break;
				case "person":
					componentFilter = TwitterConstant.getJsonForEsNested("articlePersonNer", "articlePersonNer.keyword",
							keyword);
					break;
				case "org":
					componentFilter = TwitterConstant.getJsonForEsNested("articleOrganizationNer",
							"articleOrganizationNer.keyword", keyword);
					break;
				case "date":
					componentFilter = TwitterConstant.getJsonForEsNested("articleDateNer", "articleDateNer.keyword",
							keyword);
					break;
				case "language":
					componentFilter = TwitterConstant.getJsonForEs("articleLanguage", keyword);
					break;
				case "country":
					componentFilter = TwitterConstant.getJsonForEs("articleLocationCountry", keyword);
					break;
				case "themes":
					componentFilter = TwitterConstant.getJsonForEs("articleThemes", keyword);
					break;
				case "city":
					componentFilter = TwitterConstant.getJsonForEs("articleLocationCity", keyword);
					break;
				case "phone":
					componentFilter = TwitterConstant.getJsonForEs("articleMobile", keyword);
					break;
				case "email":
					componentFilter = TwitterConstant.getJsonForEs("articleEmail", keyword);
					break;
				case "event":
					componentFilter = TwitterConstant.getJsonForEs("articleEvent.keyword", keyword);
					break;
				case "taxonomy":
					componentFilter = TwitterConstant.getJsonForEs("taxonomy", keyword);
					break;
				case "authorCountry":
					componentFilter = TwitterConstant.getJsonForEs("tweet.tweetUser.tweetUserCountry", keyword);
					break;
				case "authorCity":
					componentFilter = TwitterConstant.getJsonForEs("tweet.tweetUser.tweetUserLocation", keyword);
					break;
				default:
					break;
				}
			}

			// CLASSIFICATION FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getClassificationFilter())) {
				String[] userArr = tweeterActionVo.getClassificationFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				classificationFilter = TwitterConstant.getJsonForEs("articleClassification", userToFilter);
			}

			// CLASSIFICATION NOT FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getClassificationNotFilter())) {
				String[] userArr = tweeterActionVo.getClassificationNotFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				classificationNotFilter = TwitterConstant.getJsonForEs("articleClassification", userToFilter);
			}

			// THREAT CLASSIFICATION FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getThreatClassificationFilter())) {
				System.out.println("ThreatClassificationFilter: " + tweeterActionVo.getThreatClassificationFilter());
				String[] userArr = tweeterActionVo.getThreatClassificationFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				threatClassificationFilter = TwitterConstant.getJsonForEs("articleThreatClassification", userToFilter);
			}

			// THREAT CLASSIFICATION NOT FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getThreatClassificationNotFilter())) {
				String[] userArr = tweeterActionVo.getThreatClassificationNotFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				threatClassificationNotFilter = TwitterConstant.getJsonForEs("articleThreatClassification",
						userToFilter);
			}

			// ARTICLE ID FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getArticleIdFilter())) {
				String[] userArr = tweeterActionVo.getArticleIdFilter().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				articleIdFilter = TwitterConstant.getJsonForEs("articleId", userToFilter);
			}

			// ARTICLE TITLE HASH FILTER
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getArticleTitleHash())) {
				String[] userArr = tweeterActionVo.getArticleTitleHash().split(",");
				String userToFilter = "";
				for (String user : userArr) {
					userToFilter += "\"" + user.trim() + "\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				articleTitleHashFilter = TwitterConstant.getJsonForEs("articleTitleHash", userToFilter);
			}

			// only for whats up word cloud
			if (type == 91) {
				String selectQuery = " SELECT keyword FROM tbl_wordcloud ";
				System.out.println("selectQuery: " + selectQuery);
				List<Map<String, Object>> rows = jdbcTemplateTwo.queryForList(selectQuery);
				String userToFilter = "";
				for (Map<String, Object> rs : rows) {
					userToFilter += "\"" + rs.get("keyword").toString().trim() + "\",";
				}

				userToFilter = userToFilter.substring(0, userToFilter.length() - 1);
				wordCloudNotFilter = TwitterConstant.getJsonForEs("articleTitle", userToFilter);
			}

			/* Avoid Sentiment value 9 */
			if (type == 19) {
				sentimentNotFilter = TwitterConstant.getJsonForEsTerm("articleSentiment", "9");
			}

			joinQuery = "" + "\"query\":{\n" + "\"bool\":{\n" + "\"filter\": {\n" + "\"bool\": {\n" + "\"must\": [\n"
					+ "{}" + fbUserProfileFilter + targetView + articleNewsCategory +
					// globalProfileFilter+
					globalProfileFilterLinkAnalysis +
					// globalLocationFilter+
					retweetedUserFilter +

					articlePriority + dateFilter + threatClassificationFilter + entityId + userIdFilter + userFilter
					+ timeZoneFilter + hashTagFilter + themeFilter + mentionFilter + domainFilter + urlFilter
					+ advFilter + twUserTypeFilter + keywordFilter + keywordFilter1 + exactMatchKeyword
					+ tweetFlagFilter + mediaTypeFilter + sentimentFilter + latitudeFilter +
					// priorityFilter+
					countryCodeFilter + tweetIdFilter + personFilter + orgFilter + placeFilter + mediaFilter + imgFilter
					+ videoFilter + audioFilter + groupFilter + viralTextFilter + docTypeFilter +

					geoSearch + geoPolygonFilter + geoUserPolygonFilter + componentFilter + componentTweetFilter
					+ isComponentFilter + classificationFilter +

					// emotionFilter+
					langFilter + countryFilter + cityFilter + nerDateFilter + mobileFilter + eventFilter
					+ taxonomyFilter + authorCountryFilter + authorCityFilter + emailFilter + userCreatedDate
					+ userSearch + globalFilter + articleIdFilter + articleTitleHashFilter + phoneNo + wtGroupNo
					+ contactNo + "],\n" + "\"must_not\": [\n" + "{}" + articleNewsOtherCategory
					+ retweetedUserNotFilter +

					userNotFilter + timeZoneNotFilter + hashTagNotFilter + themeNotFilter + mentionNotFilter
					+ domainNotFilter + urlNotFilter + personNotFilter + orgNotFilter + placeNotFilter + imgNotFilter
					+ videoNotFilter + audioNotFilter + groupNotFilter + viralTextNotFilter + docTypeNotFilter +

					sentimentNotFilter + geoPolygonNotFilter + geoUserPolygonNotFilter + classificationNotFilter
					+ threatClassificationNotFilter + langNotFilter + cityNotFilter + countryNotFilter
					+ nerDateNotFilter + mobileNotFilter + emailNotFilter + eventNotFilter + taxonomyNotFilter
					+ authorCountryNotFilter + authorCityNotFilter + wordCloudNotFilter + "]\n" + "}\n" + "}\n" + "}\n"
					+ "}\n";

		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return joinQuery;
	}

	public String getTweetsSortOrder(TweeterActionVo tweeterActionVo) {
		String sortQuery = "";
		try {
			switch (tweeterActionVo.getTwSortFilter().toLowerCase().trim()) {
			case "ne":
				sortQuery = "{\n" + "\"articlePublishDate\": {\n" + "\"order\": \"desc\"" + "}\n" + "}\n";
				break;

			case "ol":
				sortQuery = "{\n" + "\"articlePublishDate\": {\n" + "\"order\": \"asc\"" + "}\n" + "}\n";
				break;

			case "inne":
				sortQuery = "{\n" + "\"articleInsertedDate\": {\n" + "\"order\": \"desc\"" + "}\n" + "}\n";
				break;

			case "inol":
				sortQuery = "{\n" + "\"articleInsertedDate\": {\n" + "\"order\": \"asc\"" + "}\n" + "}\n";
				break;

			/**** Twitter **************/
			case "twde":
				sortQuery = "{\n" + "\"tweet.tweetRetweetCount\": {\n" + "\"order\": \"desc\"" + "}\n" + "}\n";
				break;

			case "twas":
				sortQuery = "{\n" + "\"tweet.tweetRetweetCount\": {\n" + "\"order\": \"asc\"" + "}\n" + "}\n";
				break;

			case "twlikedesc":
				sortQuery = "{\n" + "\"tweet.tweetFavouriteCount\": {\n" + "\"order\": \"desc\"" + "}\n" + "}\n";
				break;

			case "twlikeasc":
				sortQuery = "{\n" + "\"tweet.tweetFavouriteCount\": {\n" + "\"order\": \"asc\"" + "}\n" + "}\n";
				break;

			case "twimpressiondesc":
				sortQuery = "{\n" + "\"tweet.tweetImpressionCount\": {\n" + "\"order\": \"desc\"" + "}\n" + "}\n";
				break;

			case "twimpressionasc":
				sortQuery = "{\n" + "\"tweet.tweetImpressionCount\": {\n" + "\"order\": \"asc\"" + "}\n" + "}\n";
				break;

			/************** Instagram **********/
			case "cmins":
				sortQuery = "{\n" + "\"instagram.instaPostCommentCount\": {\n" + "\"order\": \"desc\"" + "}\n" + "}\n";
				break;

			case "clins":
				sortQuery = "{\n" + "\"instagram.instaPostCommentCount\": {\n" + "\"order\": \"asc\"" + "}\n" + "}\n";
				break;

			case "lmins":
				sortQuery = "{\n" + "\"instagram.instaPostLikeCount\": {\n" + "\"order\": \"desc\"" + "}\n" + "}\n";
				break;

			case "llins":
				sortQuery = "{\n" + "\"instagram.instaPostLikeCount\": {\n" + "\"order\": \"asc\"" + "}\n" + "}\n";
				break;

			/************** Youtube **********/
			case "cmyt":
				sortQuery = "{\n" + "\"youtube.ytCommentCount\": {\n" + "\"order\": \"desc\"" + "}\n" + "}\n";
				break;

			case "clyt":
				sortQuery = "{\n" + "\"youtube.ytCommentCount\": {\n" + "\"order\": \"asc\"" + "}\n" + "}\n";
				break;

			case "lmyt":
				sortQuery = "{\n" + "\"youtube.ytLikeCount\": {\n" + "\"order\": \"desc\"" + "}\n" + "}\n";
				break;

			case "llyt":
				sortQuery = "{\n" + "\"youtube.ytLikeCount\": {\n" + "\"order\": \"asc\"" + "}\n" + "}\n";
				break;

			case "vmyt":
				sortQuery = "{\n" + "\"youtube.ytViewCount\": {\n" + "\"order\": \"desc\"" + "}\n" + "}\n";
				break;

			case "vlyt":
				sortQuery = "{\n" + "\"youtube.ytViewCount\": {\n" + "\"order\": \"asc\"" + "}\n" + "}\n";
				break;

			case "dmyt":
				sortQuery = "{\n" + "\"youtube.ytDisLikeCount\": {\n" + "\"order\": \"desc\"" + "}\n" + "}\n";
				break;

			case "dlyt":
				sortQuery = "{\n" + "\"youtube.ytDisLikeCount\": {\n" + "\"order\": \"asc\"" + "}\n" + "}\n";
				break;

			case "smfb":
				sortQuery = "{\n" + "\"facebook.fbPostShareCount\": {\n" + "\"order\": \"desc\"" + "}\n" + "}\n";
				break;

			case "lmfb":
				sortQuery = "{\n" + "\"facebook.fbPostLikeCount\": {\n" + "\"order\": \"desc\"" + "}\n" + "}\n";
				break;

			case "cmfb":
				sortQuery = "{\n" + "\"facebook.fbPostCommentCount\": {\n" + "\"order\": \"desc\"" + "}\n" + "}\n";
				break;

			}

			String sort = ",\"sort\": [\n" + sortQuery + "]\n";
			return sort;
		} catch (Exception ex) {
			ex.printStackTrace();
			return "";
		} finally {
			sortQuery = null;
		}
	}

	public String getHighlightFields() {
		String query = "," + "\"highlight\" : {\n" + "\"fields\" : {\n"
				+ "\"articleTitle\" : { \"number_of_fragments\": 0 ,\"pre_tags\" : [\"<b>\"], \"post_tags\" : [\"</b>\"]  },\n"
				+ "\"articleBigContent\" : { \"number_of_fragments\": 0,\"pre_tags\" : [\"<b>\"], \"post_tags\" : [\"</b>\"] }\n"
				+ "}\n" + "}\n";
		return query;
		// return "";
	}

	@Override
	public ResponseEntity<?> getTweetsPostCountOnly(TweeterActionVo tweeterActionVo) {
		System.out.println(tweeterActionVo);
		long t1 = System.currentTimeMillis();

		ArrayList<TwitterVo> list = new ArrayList<TwitterVo>();
		HashSet set = new HashSet();

		// Getting the current date
		Date date = new Date();
		// This method returns the time in millis
		long timeMilli = date.getTime();

		try {
			int from = 0;
			int size = 50;
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getIsRpt())) {
				if (CommonUtils.stringNotEmpty(tweeterActionVo.getNoTweet())) {
					from = 0;
					size = Integer.parseInt(tweeterActionVo.getNoTweet());
				}
			} else {
				from = Integer.parseInt(tweeterActionVo.getRowNum());
				size = 50;
			}

			String subQuery = rtnFilterQuery(tweeterActionVo, -1);
			System.out.println("subQuery:------  " + subQuery);
			String query = "{\n" + "      \"from\":" + from + ",\n" + "      \"size\":" + size + ",\n" + subQuery
					+ getTweetsSortOrder(tweeterActionVo);

			if (!CommonUtils.stringNotEmpty(tweeterActionVo.getIsRpt())) {
				query += getHighlightFields();
			}

			query += "}\n";

			System.out.println("******getTweets****** " + query);
			Search search = new Search.Builder(query).addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName()).build();

			SearchResult result = client.execute(search);
			long t2 = System.currentTimeMillis();

			List<Article_Datacollection_New> testLst = result.getSourceAsObjectList(Article_Datacollection_New.class);
			JsonArray arry = null;
			HashMap<String, Object> counts = new HashMap<>();
			counts.put("postCount", result.getJsonObject().get("hits").getAsJsonObject().get("total").getAsString());

			return new ResponseEntity<>(counts, HttpStatus.OK);
		} catch (Exception e) {
			// TODO: handle exception
		}
		return null;

	}

	public boolean linkAlreadyExist(ArrayList<TwitterVo> twitterVoList, String link) {
		boolean alreadyExist = false;
		for (TwitterVo twitterVo : twitterVoList) {
			if (link.equalsIgnoreCase(twitterVo.getLink())) {
				alreadyExist = true;
				break;
			}
		}
		return alreadyExist;
	}

	@Override
	public ResponseEntity<?> dashActiveMediaCount(TweeterActionVo tweeterActionVo) {

		ArrayList<TwitterVo> list = new ArrayList<TwitterVo>();
		try {
			int from = 0, finalSize = 100;
			try {
				if (tweeterActionVo.getNoMedia() != null) {
					finalSize = Integer.parseInt(tweeterActionVo.getNoMedia());
				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}

			int size = 100;
			if (CommonUtils.stringNotEmpty(tweeterActionVo.getIsRpt())) {
				if (CommonUtils.stringNotEmpty(tweeterActionVo.getNoLinks())) {
					from = 0;
					size = Integer.parseInt(tweeterActionVo.getNoLinks());
				}
			} else {
				from = Integer.parseInt(tweeterActionVo.getRowNum()) * 100;
				size = 100;
			}

			String subQuery = rtnFilterQuery(tweeterActionVo, -1);
			String query = "{\n" + "    \"from\":" + from + ",\n" + "    \"size\":" + size + ",\n" + subQuery
					+ getTweetsSortOrder(tweeterActionVo) + "}\n";

			System.out.println("**getMedia()**  " + tweeterActionVo.getMediaType() + "***  " + query);
			Search search = new Search.Builder(query).addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName()).build();

			SearchResult result = client.execute(search);
			List<Article_Datacollection_New> testLst = result.getSourceAsObjectList(Article_Datacollection_New.class);
			System.out.println("Retrun Size : " + testLst.size());

			// String absMediaPath = TwitterConstant.getInnsightImageLocal();
			for (Article_Datacollection_New article_Datacollection_New : testLst) {
				ArrayList<Article_Media> lstMedia = article_Datacollection_New.getArticleMedia();
				for (Article_Media article_Media : lstMedia) {
					if (tweeterActionVo.getMediaType().equals(article_Media.getMediaType())) {
						TwitterVo twitterVo = new TwitterVo();
						// String mediaLocalImgName = article_Media.getMediaThumbnailLocal();
						twitterVo.setInnsightImageFlag(TwitterConstant.getInnsightImageFlag());
						twitterVo.setLink(article_Media.getMediaThumbnail());
						// twitterVo.setMediaImageLocal(absMediaPath+mediaLocalImgName);
						twitterVo.setUrl(article_Media.getMediaUrl());
						twitterVo.setMediaLocalImage(article_Media.getMediaThumbnailLocal());
						twitterVo.setTweeterId(article_Datacollection_New.getArticleId());
						twitterVo.setType(article_Datacollection_New.getArticleSource());
						if (list.size() < finalSize && !linkAlreadyExist(list, article_Media.getMediaThumbnail())) {
							list.add(twitterVo);
						}
					}
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		HashMap<String, Object> counts = new HashMap<>();
		int size = 0;

		counts.put("mediaCount", list.size());
		return new ResponseEntity<>(counts, HttpStatus.OK);
	}

	@Override
	public HttpEntity<?> exportExcelDashboardWidgetData(TweeterActionVo tweeterActionVo, HttpServletResponse response)
			throws Exception {
		return dashboardController.exportExcelDashboardWidgetData(tweeterActionVo, response);
	}

	@Override
	public HttpEntity<?> exportSlideTweetWord(HashMap<String, Object> data) {
		return getTweets(data);
	}

	@Override
	public HttpEntity<?> ExportITextMediasRpt(TweeterActionVo tweeterActionVo) {
		return dashActiveMedia(tweeterActionVo);
	}

	@Override
	public HttpEntity<?> collectionCountUserWise(HashMap<String, Object> input) {

//		{"search":"","searchType":"collection","activationStatus":"","priority":"","collectionType":"","sort":"newest","pageNumber":0,"limit":150,"userId":"35","role":"U"}
		Map<String, Object> dataCount = new HashMap<>();
		List<Map<String, Object>> lst = new ArrayList<Map<String, Object>>();
		input = setUserId(input);
		try {
			if (Helper.keyContainsHashMap(input, "userId") == null
					|| (Helper.keyContainsHashMap(input, "userId") != null
							&& Helper.emptyNullCheckString(input.get("userId").toString()) == false)) {
				return new ResponseEntity<>("userId is null", HttpStatus.OK);
			}
			String subQuery = " and action!='delete'";
			subQuery += " and collection_name like '%" + input.get("search").toString() + "%'";
			String role = input.get("role").toString();
			if (!role.toLowerCase().equals("a")) {
				subQuery += " and collection_detail.created_by='" + input.get("userId").toString() + "'";
			}

			if ((Helper.keyContainsHashMap(input, "collectionType") != null
					&& Helper.emptyNullCheckString(input.get("collectionType").toString()) == true)) {
				subQuery += " and collection_type='" + input.get("collectionType").toString() + "'";
			}

			String sorting = "";
			if (input.get("sort") != null && input.get("sort") != "") {
				switch (input.get("sort").toString()) {
				case "newest":
					sorting = " order by collection_detail.created_at desc ";
					break;
				case "oldest":
					sorting = " order by collection_detail.created_at asc ";
					break;
				}
			}

			String query = "Select count(*) from collection_detail INNER JOIN login_detail ON login_detail.id = collection_detail.created_by where 1=1 "
					+ subQuery;
			int count = jdbcTemplate.queryForObject(query, Integer.class);
			if (count > 0) {
				query = "Select collection_id, collection_name, collection_type,"
						+ " COALESCE(DATE_FORMAT((created_at),'%b %d, %Y %r'),'') as created_at,"
						+ " collection_detail.created_by AS created_by_id, login_detail.user_logon_id AS created_by,"
						+ " COALESCE(DATE_FORMAT((activation_date),'%d/%m/%Y'),'') as activation_date,"
						+ " COALESCE(DATE_FORMAT((deactivation_date),'%d/%m/%Y'),'') as deactivation_date,"
						+ " has_analysis, analysis_name, priority, paused_status,"
						+ " (CASE WHEN NOW() > deactivation_date THEN 'Inactive' ELSE 'active' END) AS activationStatus"
						+ " from collection_detail INNER JOIN login_detail ON login_detail.id=collection_detail.created_by where 1=1 "
						+ subQuery + sorting;

				lst = jdbcTemplate.queryForList(query);
				dataCount.put("count", lst.size());
				lst.get(0).put("count", count);
			} else {
				dataCount.put("count", lst.size());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<>(dataCount, HttpStatus.OK);
	}

	private HashMap<String,Object> setUserId(HashMap<String,Object> map){

		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

		User loggedInUser = userService.getUserByUserName(authentication.getName());

		if (loggedInUser == null) {
			throw new ResourceNotFoundException("Please Login first For adding add url");
		}

		map.put("userId",loggedInUser.getId());

		return map;
	}

	@Override
	public HttpEntity<?> collectionInactiveStatusCountUserWise(HashMap<String, Object> input) {
//		{"search":"","searchType":"collection","activationStatus":"","priority":"","collectionType":"","sort":"newest","pageNumber":0,"limit":150,"userId":"35","role":"U"}
		Map<String, Object> dataCount = new HashMap<>();
		List<Map<String, Object>> lst = new ArrayList<Map<String, Object>>();

		input = setUserId(input);
		try {
			if (Helper.keyContainsHashMap(input, "userId") == null
					|| (Helper.keyContainsHashMap(input, "userId") != null
							&& Helper.emptyNullCheckString(input.get("userId").toString()) == false)) {
				return new ResponseEntity<>("userId is null", HttpStatus.OK);
			}
			String subQuery = " and action!='delete'";
			subQuery += " and collection_name like '%" + input.get("search").toString() + "%'";
			String role = input.get("role").toString();
			if (!role.toLowerCase().equals("a")) {
				subQuery += " and collection_detail.created_by='" + input.get("userId").toString() + "'";
			}

			if ((Helper.keyContainsHashMap(input, "collectionType") != null
					&& Helper.emptyNullCheckString(input.get("collectionType").toString()) == true)) {
				subQuery += " and collection_type='" + input.get("collectionType").toString() + "'";
			}

			String sorting = "";
			if (input.get("sort") != null && input.get("sort") != "") {
				switch (input.get("sort").toString()) {
				case "newest":
					sorting = " order by collection_detail.created_at desc ";
					break;
				case "oldest":
					sorting = " order by collection_detail.created_at asc ";
					break;
				}
			}

			String query = "Select count(*) from collection_detail INNER JOIN login_detail ON login_detail.id = collection_detail.created_by where 1=1 "
					+ subQuery;
			int count = jdbcTemplate.queryForObject(query, Integer.class);
			if (count > 0) {
				query = "Select collection_id, collection_name, collection_type,"
						+ " COALESCE(DATE_FORMAT((created_at),'%b %d, %Y %r'),'') as created_at,"
						+ " collection_detail.created_by AS created_by_id, login_detail.user_logon_id AS created_by,"
						+ " COALESCE(DATE_FORMAT((activation_date),'%d/%m/%Y'),'') as activation_date,"
						+ " COALESCE(DATE_FORMAT((deactivation_date),'%d/%m/%Y'),'') as deactivation_date,"
						+ " has_analysis, analysis_name, priority, paused_status,"
						+ " (CASE WHEN NOW() > deactivation_date THEN 'Inactive' ELSE 'active' END) AS activationStatus"
						+ " from collection_detail INNER JOIN login_detail ON login_detail.id=collection_detail.created_by where 1=1 AND now() > collection_detail.deactivation_date"
						+ subQuery + sorting;

				lst = jdbcTemplate.queryForList(query);
				dataCount.put("count", lst.size());
				lst.get(0).put("count", count);
			} else {
				dataCount.put("count", lst.size());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		int counter = 0;
		for (int i = 0; i < lst.size(); i++) {
			if (lst.get(i).get("activationStatus").equals("Inactive")) {
				counter++;
			}
		}

		dataCount.put("count", counter);

		return new ResponseEntity<>(dataCount, HttpStatus.OK);
	}

	@Override
	public HttpEntity<?> collectionActiveStatusCountUserWise(HashMap<String, Object> input) {
//		{"search":"","searchType":"collection","activationStatus":"","priority":"","collectionType":"","sort":"newest","pageNumber":0,"limit":150,"userId":"35","role":"U"}
		Map<String, Object> dataCount = new HashMap<>();
		List<Map<String, Object>> lst = new ArrayList<Map<String, Object>>();

		input = setUserId(input);
		try {
			if (Helper.keyContainsHashMap(input, "userId") == null
					|| (Helper.keyContainsHashMap(input, "userId") != null
							&& Helper.emptyNullCheckString(input.get("userId").toString()) == false)) {
				return new ResponseEntity<>("userId is null", HttpStatus.OK);
			}
			String subQuery = " and action!='delete'";
			subQuery += " and collection_name like '%" + input.get("search").toString() + "%'";
			String role = input.get("role").toString();
			if (!role.toLowerCase().equals("a")) {
				subQuery += " and collection_detail.created_by='" + input.get("userId").toString() + "'";
			}

			if ((Helper.keyContainsHashMap(input, "collectionType") != null
					&& Helper.emptyNullCheckString(input.get("collectionType").toString()) == true)) {
				subQuery += " and collection_type='" + input.get("collectionType").toString() + "'";
			}

			String sorting = "";
			if (input.get("sort") != null && input.get("sort") != "") {
				switch (input.get("sort").toString()) {
				case "newest":
					sorting = " order by collection_detail.created_at desc ";
					break;
				case "oldest":
					sorting = " order by collection_detail.created_at asc ";
					break;
				}
			}

			String query = "Select count(*) from collection_detail INNER JOIN login_detail ON login_detail.id = collection_detail.created_by where 1=1 "
					+ subQuery;
			int count = jdbcTemplate.queryForObject(query, Integer.class);
			if (count > 0) {
				query = "Select collection_id, collection_name, collection_type,"
						+ " COALESCE(DATE_FORMAT((created_at),'%b %d, %Y %r'),'') as created_at,"
						+ " collection_detail.created_by AS created_by_id, login_detail.user_logon_id AS created_by,"
						+ " COALESCE(DATE_FORMAT((activation_date),'%d/%m/%Y'),'') as activation_date,"
						+ " COALESCE(DATE_FORMAT((deactivation_date),'%d/%m/%Y'),'') as deactivation_date,"
						+ " has_analysis, analysis_name, priority, paused_status,"
						+ " (CASE WHEN NOW() > deactivation_date THEN 'Inactive' ELSE 'active' END) AS activationStatus"
						+ " from collection_detail INNER JOIN login_detail ON login_detail.id=collection_detail.created_by where 1=1"
						+ subQuery + sorting;

				lst = jdbcTemplate.queryForList(query);
				lst.get(0).put("count", count);
			} else {
				dataCount.put("count", lst.size());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		int counter = 0;
		for (int i = 0; i < lst.size(); i++) {
			if (lst.get(i).get("activationStatus").equals("active")) {
				counter++;
			}
		}

		dataCount.put("count", counter);

		return new ResponseEntity<>(dataCount, HttpStatus.OK);
	}

	@Override
	public HttpEntity<?> getProxyCountry(HashMap<String, Object> data) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<>(data, headers);
		return template.exchange(innefuUrl + "/getProxyCountry", HttpMethod.POST, entity, Object.class);
	}

	@Override
	public HttpEntity<?> getNewsPaperSourceValues(HashMap<String, Object> data) {
		try {
			Gson gson = new GsonBuilder().serializeNulls().create();
			JSONParser parser = new JSONParser();
			String stringJson = "";
			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<Object> entity = new HttpEntity<>(new HashMap<String, Object>(), headers);
			ResponseEntity<Object> countryDataResponse = template.exchange(innefuUrl + "/getProxyCountry",
					HttpMethod.POST, entity, Object.class);
			Map<String, String> countryCodeMapping = new HashMap<>();
			stringJson = gson.toJson(countryDataResponse.getBody());		
			JSONArray countryDataArray = (JSONArray) parser.parse(stringJson);
			for (Object obj : countryDataArray) {
				JSONObject element = (JSONObject) obj;
				countryCodeMapping.put((String)element.get("key2"), (String)element.get("key1"));
			}
			
//			System.out.println(countryCodeMapping.toString());
				
			entity = new HttpEntity<>(data, headers);
			stringJson = gson.toJson(template.exchange(innefuUrl + "/getNewsPaperSourceValues", HttpMethod.POST, entity, Object.class).getBody());
			JSONArray newsPaperSourceValuesDataArray = (JSONArray) parser.parse(stringJson);
			for (Object obj : newsPaperSourceValuesDataArray) {
				JSONObject element = (JSONObject) obj;
				System.out.println(countryCodeMapping.get(element.get("country")));
				element.put("country", countryCodeMapping.get((String)element.get("country")));
			}
			
			return new ResponseEntity<>(newsPaperSourceValuesDataArray, HttpStatus.OK);

//			return new ResponseEntity<>(template.exchange(innefuUrl + "/getNewsPaperSourceValues", HttpMethod.POST, entity, Object.class).getBody(), HttpStatus.OK);
//			return new ResponseEntity<>(countryCodeMapping, HttpStatus.OK);
			
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Autowired
	ISourceService sourceService;

//	{
//	    "collectionName": "sdfdsfdsfererer",
//	    "collectionType": "keyword",
//	    "clientId": "1",
//	    "userId": "35",
//	    "activationDate": "2022-10-31 00:00:01",
//	    "deactivationDate": "2022-11-03 23:59:59",
//	    "hasAnalysis": false,
//	    "analysisName": "",
//	    "priority": "normal",
//	    "keyword": {
//	        "keyword": [
//	            "modi",
//	            "amit",
//	            "shah",
//	            "narendra"
//	        ],
//	        "sources": [
//	            "facebook",
//	            "twitter",
//	            "youtube",
//	            "dailymotion",
//	            "instagram",
//	            "reddit",
//	            "tumblr",
//	            "wordpress"
//	        ]
//	    }
//	}
	@Override
	public HttpEntity<?> getAllTagsFromThemeUserWise() {
		HashMap<String, Object> input = sourceService.addThemeCollection();
		HashMap<String, Object> payload = new HashMap<>();
		try {
			HashMap<String, ArrayList<String>> keywords = (HashMap<String, ArrayList<String>>) input.get("data");
			String userId = (String) input.get("userId");
			payload.put("collectionType", "keyword");
			payload.put("clientId", "1");
			payload.put("userId", userId);
			payload.put("activationDate", "2022-10-31 00:00:01");
			payload.put("deactivationDate", "2022-11-03 23:59:59");
			payload.put("hasAnalysis", "false");
			payload.put("analysisName", "");
			payload.put("priority", "normal");
			HashMap<String, Object> tags = new HashMap<>();
			tags.put("sources", new ArrayList<>(
					Arrays.asList("facebook", "twitter", "youtube", "dailymotion", "instagram", "reddit", "tumblr")));
			keywords.forEach((key, value) -> {
				payload.put("collectionName", key);
				tags.put("keyword", value);
				payload.put("keyword", tags);
				new ResponseEntity<>(updateCollectionDateBySourceAndKeywordMatch(payload), HttpStatus.OK);
			});

		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

}
