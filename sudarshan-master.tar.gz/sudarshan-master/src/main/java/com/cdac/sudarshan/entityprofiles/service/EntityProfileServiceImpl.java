package com.cdac.sudarshan.entityprofiles.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.cdac.sudarshan.authentication.model.User;
import com.cdac.sudarshan.authentication.service.IUserService;
import com.cdac.sudarshan.entityprofiles.dto.EntityProfileDto;
import com.cdac.sudarshan.entityprofiles.model.EntityProfile;
import com.cdac.sudarshan.entityprofiles.repository.EntityProfileRepository;
import com.cdac.sudarshan.exception.ResourceNotFoundException;

@Service
public class EntityProfileServiceImpl implements IEntityProfileService {

	@Autowired
	private ModelMapper mapper;

	@Autowired
	private IUserService userService;
	@Autowired
	private EntityProfileRepository entityProfileRepository;

	@Override
	public ResponseEntity<?> createEntityProfile(EntityProfileDto entityProfileDto) {

		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

		if (authentication.getName() == null) {
			throw new ResourceNotFoundException("Please Login first To Get Search Records");
		}

		User loggedInUser = userService.getUserByUserName(authentication.getName());
		
		EntityProfile entityProfile = mapper.map(entityProfileDto, EntityProfile.class);
		entityProfile.setUser(loggedInUser);
		return new ResponseEntity<>(entityProfileRepository.save(entityProfile), HttpStatus.OK);
	}
	
	@Override
	public ResponseEntity<?> getAllEntityProfile() {
		
		List<EntityProfile> allEntityprofile=this.entityProfileRepository.findAll();
		List<Map<String, Object>> response  = new ArrayList<>();
		for(EntityProfile en : allEntityprofile){
			Map<String, Object> map = new HashMap<>();
			map.put("name", en.getName());
			map.put("createdBy", en.getUser().getUsername());
			response.add(map);
		}
		return ResponseEntity.ok(response);
		
	}

	
	

}
