package com.cdac.sudarshan.discover.common;

import java.io.Serializable;
import java.util.ArrayList;

public class LoginDetails implements Serializable 
{
	private static final long serialVersionUID = 1L;
	private String userName;
	private String password;
	private String role;
	private String userTemplate;
	private String id;
	private String templateId;
	private String dateOfCreation;
	private String dateOfUpdation;
	private String sort;
	private String cnt;
	private String mode;
	private String keyword;
	private String isActive;
	private String filter;
	private String proStatus;
	private String avatarStatus;
	private ArrayList<String> lst1;
	private ArrayList<String> lst2;
	private String id1;
	private String id2;
	private String msg;
    private String mappedFilter;
    private String crawlFilter;
    private String typeFilter;
    private String comment;
    private int createdBy;
    private int currentConnection;
    private int maximumConnection;
    private String product;
    private String innsightUserLimitFlag;
    
    
    //Constructor
    public LoginDetails()
    {
	}
	
    /*public LoginDetails(String userName, String password, String role, String id)
	{
		super();
		this.userName = userName;
		this.password = password;
		this.role = role;
		//this.userTemplate = userTemplate;
		this.id = id;
	}*/
    
	public LoginDetails(String userName, String password, String role, String userTemplate, String id)
	{
		super();
		this.userName = userName;
		this.password = password;
		this.role = role;
		this.userTemplate = userTemplate;
		this.id = id;
	}
    
    
	public String getUserTemplate() {
		return userTemplate;
	}

	public void setUserTemplate(String userTemplate) {
		this.userTemplate = userTemplate;
	}

	public String getTemplateId() {
		return templateId;
	}
	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}
	public String getInnsightUserLimitFlag() {
		return innsightUserLimitFlag;
	}
	public void setInnsightUserLimitFlag(String innsightUserLimitFlag) {
		this.innsightUserLimitFlag = innsightUserLimitFlag;
	}
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public int getCurrentConnection() {
		return currentConnection;
	}
	public void setCurrentConnection(int currentConnection) {
		this.currentConnection = currentConnection;
	}
	public int getMaximumConnection() {
		return maximumConnection;
	}
	public void setMaximumConnection(int maximumConnection) {
		this.maximumConnection = maximumConnection;
	}
	public int getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getTypeFilter() {
		return typeFilter;
	}
	public void setTypeFilter(String typeFilter) {
		this.typeFilter = typeFilter;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public String getId1() {
		return id1;
	}
	public void setId1(String id1) {
		this.id1 = id1;
	}
	public String getId2() {
		return id2;
	}
	public void setId2(String id2) {
		this.id2 = id2;
	}
	public ArrayList<String> getLst1() {
		return lst1;
	}
	public void setLst1(ArrayList<String> lst1) {
		this.lst1 = lst1;
	}
	public ArrayList<String> getLst2() {
		return lst2;
	}
	public void setLst2(ArrayList<String> lst2) {
		this.lst2 = lst2;
	}
	public String getProStatus() {
		return proStatus;
	}
	public void setProStatus(String proStatus) {
		this.proStatus = proStatus;
	}
	public String getAvatarStatus() {
		return avatarStatus;
	}
	public void setAvatarStatus(String avatarStatus) {
		this.avatarStatus = avatarStatus;
	}
	public String getFilter() {
		return filter;
	}
	public void setFilter(String filter) {
		this.filter = filter;
	}

	public String getIsActive() {
		return isActive;
	}
	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}
	public String getKeyword() {
		return keyword;
	}
	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}
	public String getMode() {
		return mode;
	}
	public void setMode(String mode) {
		this.mode = mode;
	}
	public String getCnt() {
		return cnt;
	}
	public void setCnt(String cnt) {
		this.cnt = cnt;
	}
	public String getSort() {
		return sort;
	}
	public void setSort(String sort) {
		this.sort = sort;
	}
	public String getDateOfCreation() {
		return dateOfCreation;
	}
	public void setDateOfCreation(String dateOfCreation) {
		this.dateOfCreation = dateOfCreation;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getMappedFilter() {
		return mappedFilter;
	}
	public void setMappedFilter(String mappedFilter) {
		this.mappedFilter = mappedFilter;
	}
	public String getCrawlFilter() {
		return crawlFilter;
	}
	public void setCrawlFilter(String crawlFilter) {
		this.crawlFilter = crawlFilter;
	}
	public String getDateOfUpdation() {
		return dateOfUpdation;
	}
	public void setDateOfUpdation(String dateOfUpdation) {
		this.dateOfUpdation = dateOfUpdation;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "LoginDetails [userName=" + userName + ", password=" + password + ", role=" + role + ", userTemplate="
				+ userTemplate + ", id=" + id + ", templateId=" + templateId + ", dateOfCreation=" + dateOfCreation
				+ ", dateOfUpdation=" + dateOfUpdation + ", sort=" + sort + ", cnt=" + cnt + ", mode=" + mode
				+ ", keyword=" + keyword + ", isActive=" + isActive + ", filter=" + filter + ", proStatus=" + proStatus
				+ ", avatarStatus=" + avatarStatus + ", lst1=" + lst1 + ", lst2=" + lst2 + ", id1=" + id1 + ", id2="
				+ id2 + ", msg=" + msg + ", mappedFilter=" + mappedFilter + ", crawlFilter=" + crawlFilter
				+ ", typeFilter=" + typeFilter + ", comment=" + comment + ", createdBy=" + createdBy
				+ ", currentConnection=" + currentConnection + ", maximumConnection=" + maximumConnection + ", product="
				+ product + ", innsightUserLimitFlag=" + innsightUserLimitFlag + "]";
	}

}
