package com.cdac.sudarshan.discover.model;

import java.io.Serializable;

public class Article_WhatsApp implements Serializable
{
	private static final long serialVersionUID = 1L;
	private String deviceId; 
	private String devicePhoneNo; 
	private String mediaType; 
	private String mediaPath; 
	private String mediaCaption; 
	private String msgType;           // message type: ’0’=text, ’1’=image, ’2’=audio, ’3’=video, ’4’=contact card, ’5’=geo position 
	private String wtsapMessageType;  //0=original, 1=forwarded, 2=quoted
	private String wtsapMsgKeyId;
	private String wtsapQuotedMsgKeyId;	
	private String isAdded;           //0=delete, 1=add
	private String actionPerformBy;
	private String actionPerformOn;
	private String msg; 
	private String msgTimeStamp; 	
	private String location; 
	private String msgStatus;
	private String contact;
    private String document;
    private MsgSender msgSender;
    private MsgReceiver msgReceiver;
    
    public String getDeviceId() {
		return deviceId;
	}
	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}
	public String getDevicePhoneNo() {
		return devicePhoneNo;
	}
	public void setDevicePhoneNo(String devicePhoneNo) {
		this.devicePhoneNo = devicePhoneNo;
	}
	public String getWtsapMessageType() {
		return wtsapMessageType;
	}
	public void setWtsapMessageType(String wtsapMessageType) {
		this.wtsapMessageType = wtsapMessageType;
	}
	public String getWtsapMsgKeyId() {
		return wtsapMsgKeyId;
	}
	public void setWtsapMsgKeyId(String wtsapMsgKeyId) {
		this.wtsapMsgKeyId = wtsapMsgKeyId;
	}
	public String getWtsapQuotedMsgKeyId() {
		return wtsapQuotedMsgKeyId;
	}
	public void setWtsapQuotedMsgKeyId(String wtsapQuotedMsgKeyId) {
		this.wtsapQuotedMsgKeyId = wtsapQuotedMsgKeyId;
	}
	public String getIsAdded() {
		return isAdded;
	}
	public void setIsAdded(String isAdded) {
		this.isAdded = isAdded;
	}
	public String getActionPerformBy() {
		return actionPerformBy;
	}
	public void setActionPerformBy(String actionPerformBy) {
		this.actionPerformBy = actionPerformBy;
	}
	public String getActionPerformOn() {
		return actionPerformOn;
	}
	public void setActionPerformOn(String actionPerformOn) {
		this.actionPerformOn = actionPerformOn;
	}
	public String getMediaType() {
		return mediaType;
	}
	public void setMediaType(String mediaType) {
		this.mediaType = mediaType;
	}
	public String getMediaPath() {
		return mediaPath;
	}
	public void setMediaPath(String mediaPath) {
		this.mediaPath = mediaPath;
	}
	public String getMediaCaption() {
		return mediaCaption;
	}
	public void setMediaCaption(String mediaCaption) {
		this.mediaCaption = mediaCaption;
	}
	public String getMsgType() {
		return msgType;
	}
	public void setMsgType(String msgType) {
		this.msgType = msgType;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public String getMsgTimeStamp() {
		return msgTimeStamp;
	}
	public void setMsgTimeStamp(String msgTimeStamp) {
		this.msgTimeStamp = msgTimeStamp;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getDocument() {
		return document;
	}
	public void setDocument(String document) {
		this.document = document;
	}	
	public MsgSender getMsgSender() {
		return msgSender;
	}
	public void setMsgSender(MsgSender msgSender) {
		this.msgSender = msgSender;
	}
	public MsgReceiver getMsgReceiver() {
		return msgReceiver;
	}
	public void setMsgReceiver(MsgReceiver msgReceiver) {
		this.msgReceiver = msgReceiver;
	}
	
	public String getMsgStatus() {
		return msgStatus;
	}
	public void setMsgStatus(String msgStatus) {
		this.msgStatus = msgStatus;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString()
	{
		return "Article_WhatsApp [deviceId=" + deviceId + ", devicePhoneNo=" + devicePhoneNo + ", mediaType="
				+ mediaType + ", mediaPath=" + mediaPath + ", mediaCaption=" + mediaCaption + ", msgType=" + msgType
				+ ", wtsapMessageType=" + wtsapMessageType + ", wtsapMsgKeyId=" + wtsapMsgKeyId
				+ ", wtsapQuotedMsgKeyId=" + wtsapQuotedMsgKeyId + ", isAdded=" + isAdded + ", actionPerformBy="
				+ actionPerformBy + ", actionPerformOn=" + actionPerformOn + ", msg=" + msg + ", msgTimeStamp="
				+ msgTimeStamp + ", location=" + location + ", msgStatus=" + msgStatus + ", contact=" + contact
				+ ", document=" + document + ", msgSender=" + msgSender + ", msgReceiver=" + msgReceiver + "]";
	}
}
