package com.cdac.sudarshan.alerts.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@ToString
@RequiredArgsConstructor
//@Table(name = "alert",uniqueConstraints = @UniqueConstraint(name="articleid_unique", columnNames = "article_id"))
public class Alert {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long alertId;
	
//	@Column(name = "article_id", nullable = false)
	private String articleId;

	private String articleTitle;

	private String articleSource;

	private String articleLinkUrl;

	private String articleNewsSource;
	
	private String articleAuthor;
	
//	private String articleInsertedDate;
	
	private Date creationDate;

	private boolean isRead;

//	@Fetch(FetchMode.JOIN)
//	@ManyToOne(fetch = FetchType.LAZY)
//	@JoinColumn(name = "user_id")
//	@Expose
//	private User user;
	
	private Long userId;

//	public Alert(String message, Date createdAt, User user) {
//		this.message = message;
//		this.createdAt = createdAt;
//		this.user = user;
//		this.isRead = false;
//	}

}
