package com.cdac.sudarshan.discover.common;

import java.io.Serializable;
import java.util.Arrays;

public class OrganizationPhotoVo implements Serializable {
	
    private static final long serialVersionUID = 1L;
	
	private int photoId;
	private byte[] photo;
	private String photoPath;
	private String photoType;
	private int status;
	private int orgId;
	
	public int getPhotoId() 
	{
		return photoId;
	}
	public void setPhotoId(int photoId) 
	{
		this.photoId = photoId;
	}
	
	public byte[] getPhoto() 
	{
		return photo;
	}
	public void setPhoto(byte[] photo) 
	{
		this.photo = photo;
	}
	
	public String getPhotoPath() {
		return photoPath;
	}
	public void setPhotoPath(String photoPath) {
		this.photoPath = photoPath;
	}
	public String getPhotoType() 
	{
		return photoType;
	}
	public void setPhotoType(String photoType)
	{
		this.photoType = photoType;
	}
	
	public int getStatus()
	{
		return status;
	}
	public void setStatus(int status)
	{
		this.status = status;
	}
	
	public int getOrgId() 
	{
		return orgId;
	}
	public void setOrgId(int orgId)
	{
		this.orgId = orgId;
	}
	
	public static long getSerialversionuid()
	{
		return serialVersionUID;
	}
	
	@Override
	public String toString() {
		return "OrganizationPhotoVo [photoId=" + photoId + ", photo=" + Arrays.toString(photo) + ", photoPath="+photoPath+", photoType="
				+ photoType + ", status=" + status + ", orgId=" + orgId + "]";
	}
}