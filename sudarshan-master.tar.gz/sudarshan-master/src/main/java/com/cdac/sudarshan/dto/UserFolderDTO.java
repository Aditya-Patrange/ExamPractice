package com.cdac.sudarshan.dto;

import com.cdac.sudarshan.folder.dto.RootFolderDto;
import com.cdac.sudarshan.folder.dto.UserDto;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Getter
@Setter
@ToString
public class UserFolderDTO {


    private List<RootFolderDto> rootFolderDtos;
    private UserDto user;


}
