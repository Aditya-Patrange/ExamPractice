package com.cdac.sudarshan.mysearches.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class MySearchesDto {
private int pageNo;
private int limit;
private String keyword;
private Long keywordCount;
}
