package com.cdac.sudarshan.discover.model;

public class CountryCode {
private String timeZone,country,code,lat,lon;

public String getTimeZone() {
	return timeZone;
}

public void setTimeZone(String timeZone) {
	this.timeZone = timeZone;
}

public String getCountry() {
	return country;
}

public void setCountry(String country) {
	this.country = country;
}

public String getCode() {
	return code;
}

public void setCode(String code) {
	this.code = code;
}

public String getLat() {
	return lat;
}

public void setLat(String lat) {
	this.lat = lat;
}

public String getLon() {
	return lon;
}

public void setLon(String lon) {
	this.lon = lon;
}


}
