package com.cdac.sudarshan.folder.service;

import com.cdac.sudarshan.exception.DataNotFoundException;
import com.cdac.sudarshan.folder.model.SubFolderPaths;
import org.springframework.http.ResponseEntity;

import java.io.IOException;
import java.util.List;
import java.util.Map;

public interface ISubFolderPathsService {

	List<SubFolderPaths> addSubFolderToRootFolder(String path) ;

	ResponseEntity<?> getAllSubFolderOfRootFolder(String rootFolderName);
	
	
	String getUrlAndSourceFromEs(Map<String,Object> data) throws DataNotFoundException;

	//ResponseEntity<?> getAllSubFolderOfRootFolder_1(String rootFolderName);
	
	ResponseEntity<?>  getSubFolderOfParentFolder(String parentFolderName);

	ResponseEntity<?> getMediaSourceData(Map<String, Object> data) throws IOException;

	ResponseEntity<?> renameSubFolder(Map<String,String> data);
}
