package com.cdac.sudarshan.discover.model;

public class TwitterUserListVo {
private String slug,name,created_at,uri,subscriber_count,id_str,member_count,id,description,full_name,mode,userName;

public String getUserName() {
	return userName;
}

public void setUserName(String userName) {
	this.userName = userName;
}

public String getMode() {
	return mode;
}

public void setMode(String mode) {
	this.mode = mode;
}
public TwitterUserListVo(){}
public TwitterUserListVo(String slug, String name, String created_at,
	String uri, String subscriber_count, String id_str,
	String member_count, String id, String description, String full_name) {
    this.slug = slug;
    this.name = name;
    this.created_at = created_at;
    this.uri = uri;
    this.subscriber_count = subscriber_count;
    this.id_str = id_str;
    this.member_count = member_count;
    this.id = id;
    this.description = description;
    this.full_name = full_name;
}

public String getSlug() {
    return slug;
}

public void setSlug(String slug) {
    this.slug = slug;
}

public String getName() {
    return name;
}

public void setName(String name) {
    this.name = name;
}

public String getCreated_at() {
    return created_at;
}

public void setCreated_at(String created_at) {
    this.created_at = created_at;
}

public String getUri() {
    return uri;
}

public void setUri(String uri) {
    this.uri = uri;
}

public String getSubscriber_count() {
    return subscriber_count;
}

public void setSubscriber_count(String subscriber_count) {
    this.subscriber_count = subscriber_count;
}

public String getId_str() {
    return id_str;
}

public void setId_str(String id_str) {
    this.id_str = id_str;
}

public String getMember_count() {
    return member_count;
}

public void setMember_count(String member_count) {
    this.member_count = member_count;
}

public String getId() {
    return id;
}

public void setId(String id) {
    this.id = id;
}

public String getDescription() {
    return description;
}

public void setDescription(String description) {
    this.description = description;
}

public String getFull_name() {
    return full_name;
}

public void setFull_name(String full_name) {
    this.full_name = full_name;
}

}
