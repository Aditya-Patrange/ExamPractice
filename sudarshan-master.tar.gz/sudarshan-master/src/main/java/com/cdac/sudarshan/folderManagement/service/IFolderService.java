package com.cdac.sudarshan.folderManagement.service;

import com.cdac.sudarshan.folderManagement.dto.ApiResponse;
import com.cdac.sudarshan.folderManagement.dto.FolderRequestDto;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.springframework.http.ResponseEntity;

import java.util.List;
import java.util.Map;

public interface IFolderService {

    ApiResponse<?> saveFolder(FolderRequestDto data) throws JsonProcessingException;

    ApiResponse<?> getFolder(FolderRequestDto data) throws JsonProcessingException;

    ApiResponse<?> getStatusReference();

    ApiResponse<?> moveFolder(List<FolderRequestDto> data);

    ApiResponse<?> renameFolder(List<FolderRequestDto> data);

    ApiResponse<?> restoreFolder(FolderRequestDto data);

    ApiResponse<?> softRemoveFolder(FolderRequestDto data);

    ApiResponse<?> copyFolder(List<FolderRequestDto> data) throws JsonProcessingException;

    ApiResponse<?> getFolderList(FolderRequestDto data);

    ApiResponse<?> permanentRemoveFolder(FolderRequestDto data);

    ApiResponse<?> getItemCount(List<FolderRequestDto> data);
}

