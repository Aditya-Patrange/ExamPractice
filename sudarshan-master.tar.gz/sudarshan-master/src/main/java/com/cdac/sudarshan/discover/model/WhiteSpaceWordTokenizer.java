package com.cdac.sudarshan.discover.model;


import java.util.Arrays;
import java.util.List;

public class WhiteSpaceWordTokenizer implements WordTokenizer {

	@Override
	public List<String> tokenize(String sentence) {
		return Arrays.asList(sentence.split(" "));
	}

}
