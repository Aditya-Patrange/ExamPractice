package com.cdac.sudarshan.folder.dto;

import com.cdac.sudarshan.folder.model.UrlsPath;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public class SubFolderPathDto {

	private Long subFolderPathId;
	private String SubFolderPathName;
	private List<UrlsPath> urlsPathList = new ArrayList<>();

}
