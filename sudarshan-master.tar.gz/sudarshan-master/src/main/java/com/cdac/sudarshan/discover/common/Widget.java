package com.cdac.sudarshan.discover.common;



public class Widget
{
	private int widgetId;
	private String widgetName;
	private String widgetDescription;
	//private Date creationDate;
	private String creationDate;
	private String widgetCategory;
	private String widgetImagePath;
	public Widget()
	{  }
	public Widget(int widgetId, String widgetName, String widgetDescription, 
			String creationDate, String widgetCategory, String widgetImagePath)         
	{
		super();
		this.widgetId = widgetId;
		this.widgetName = widgetName;
		this.widgetDescription = widgetDescription;
		this.creationDate = creationDate;
		this.widgetCategory = widgetCategory;
		this.widgetImagePath = widgetImagePath;
	}
	
	
	
	public int getWidgetId()
	{
		return widgetId;
	}

	public void setWidgetId(int widgetId)
	{
		this.widgetId = widgetId;
	}

	public String getWidgetName()
	{
		return widgetName;
	}
	public void setWidgetName(String widgetName)
	{
		this.widgetName = widgetName;
	}
	
	public String getWidgetDescription() 
	{
		return widgetDescription;
	}
	public void setWidgetDescription(String widgetDescription) 
	{
		this.widgetDescription = widgetDescription;
	}
	
	public String getCreationDate()
	{
		return creationDate;
	}
	public void setCreationDate(String creationDate)
	{
		this.creationDate = creationDate;
	}
	
	public String getWidgetCategory()
	{
		return widgetCategory;
	}
	public void setWidgetCategory(String widgetCategory)
	{
		this.widgetCategory = widgetCategory;
	}

	public String getWidgetImagePath()
	{
		return widgetImagePath;
	}
	public void setWidgetImagePath(String widgetImagePath) 
	{
		this.widgetImagePath = widgetImagePath;
	}


	@Override
	public String toString() 
	{
		return "Widget [widgetId====>" + widgetId + ", widgetName====>" + widgetName + ", widgetDescription====>"
				+ widgetDescription + ", creationDate====>" + creationDate + ", widgetCategory====>" + widgetCategory
				+ ", widgetImagePath====>" + widgetImagePath + "]";
	}
	
	
	private String sort;
	private int dashId;
	private String isAdd;
	
	public String getIsAdd() {
		return isAdd;
	}
	public void setIsAdd(String isAdd) {
		this.isAdd = isAdd;
	}
	public String getSort() {
		return sort;
	}
	public void setSort(String sort) {
		this.sort = sort;
	}
	public int getDashId() {
		return dashId;
	}
	public void setDashId(int dashId) {
		this.dashId = dashId;
	}
	
	

}
