package com.cdac.sudarshan.discover.model;

import java.io.Serializable;

public class Weibo implements Serializable
{
	private static final long serialVersionUID = 1L;
	private long repostsCount;
	private long commentsCount;
	private long attitudesCount;
    private WeiboUser weiboUser;

	public long getRepostsCount() {
		return repostsCount;
	}
	public void setRepostsCount(long repostsCount) {
		this.repostsCount = repostsCount;
	}
	public long getCommentsCount() {
		return commentsCount;
	}
	public void setCommentsCount(long commentsCount) {
		this.commentsCount = commentsCount;
	}
	public long getAttitudesCount() {
		return attitudesCount;
	}
	public void setAttitudesCount(long attitudesCount) {
		this.attitudesCount = attitudesCount;
	}
	public WeiboUser getWeiboUser() {
		return weiboUser;
	}
	public void setWeiboUser(WeiboUser weiboUser) {
		this.weiboUser = weiboUser;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "Weibo [repostsCount=" + repostsCount + ", commentsCount=" + commentsCount + ", attitudesCount="
				+ attitudesCount + ", weiboUser=" + weiboUser + "]";
	}
}
