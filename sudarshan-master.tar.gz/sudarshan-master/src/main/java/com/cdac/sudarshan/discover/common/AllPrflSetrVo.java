package com.cdac.sudarshan.discover.common;

public class AllPrflSetrVo 
{
	private String id;
	private String name;
	private String image;
	private String fullName;
	private String url;
	
	public String getId() {
		return id;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	@Override
	public String toString() {
		return "AllPrflSetrVo [id=" + id + ", name=" + name + ", image=" + image + ", fullName=" + fullName + ", url="
				+ url + "]";
	}
}
