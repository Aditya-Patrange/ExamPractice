package com.cdac.sudarshan.discover.model;

import java.io.Serializable;

public class TweetMentionTblVo implements  Serializable {
	private static final long serialVersionUID = 1L;
	String userId,userName,tweetId;
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getTweetId() {
		return tweetId;
	}

	public void setTweetId(String tweetId) {
		this.tweetId = tweetId;
	}

}
