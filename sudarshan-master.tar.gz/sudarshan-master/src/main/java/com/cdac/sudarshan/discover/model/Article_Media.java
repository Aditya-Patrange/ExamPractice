package com.cdac.sudarshan.discover.model;

import java.io.Serializable;
import java.util.ArrayList;

public class Article_Media implements Serializable
{
	private static final long serialVersionUID = 1L;
	private String mediaType;
	private String mediaThumbnail;
	private String mediaUrl;
	private String mediaContent;
	private String mediaUrlLocal;
	private String mediaClassification;
	private String mediaClassificationScore;
	private String mediaThumbnailLocal;
	private ArrayList<String> imageObjects;

	public String getMediaType() {
		return mediaType;
	}

	public void setMediaType(String mediaType) {
		this.mediaType = mediaType;
	}

	public String getMediaThumbnail() {
		return mediaThumbnail;
	}

	public void setMediaThumbnail(String mediaThumbnail) {
		this.mediaThumbnail = mediaThumbnail;
	}

	public String getMediaUrl() {
		return mediaUrl;
	}

	public void setMediaUrl(String mediaUrl) {
		this.mediaUrl = mediaUrl;
	}

	public String getMediaContent() {
		return mediaContent;
	}

	public void setMediaContent(String mediaContent) {
		this.mediaContent = mediaContent;
	}

	public String getMediaUrlLocal() {
		return mediaUrlLocal;
	}

	public void setMediaUrlLocal(String mediaUrlLocal) {
		this.mediaUrlLocal = mediaUrlLocal;
	}

	public String getMediaClassification() {
		return mediaClassification;
	}

	public void setMediaClassification(String mediaClassification) {
		this.mediaClassification = mediaClassification;
	}

	public String getMediaClassificationScore() {
		return mediaClassificationScore;
	}

	public void setMediaClassificationScore(String mediaClassificationScore) {
		this.mediaClassificationScore = mediaClassificationScore;
	}

	public String getMediaThumbnailLocal() {
		return mediaThumbnailLocal;
	}

	public void setMediaThumbnailLocal(String mediaThumbnailLocal) {
		this.mediaThumbnailLocal = mediaThumbnailLocal;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public ArrayList<String> getImageObjects() {
		return imageObjects;
	}

	public void setImageObjects(ArrayList<String> imageObjects) {
		this.imageObjects = imageObjects;
	}

	@Override
	public String toString() 
	{
		return "Article_Media [mediaType=" + mediaType + ", mediaThumbnail=" + mediaThumbnail + ", mediaUrl=" + mediaUrl
				+ ", mediaContent=" + mediaContent + ", mediaUrlLocal=" + mediaUrlLocal + ", mediaClassification="
				+ mediaClassification + ", mediaClassificationScore=" + mediaClassificationScore
				+ ", mediaThumbnailLocal=" + mediaThumbnailLocal + "]";
	} 
	
}
