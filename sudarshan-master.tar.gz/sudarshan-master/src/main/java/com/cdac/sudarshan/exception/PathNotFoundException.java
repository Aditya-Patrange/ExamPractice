package com.cdac.sudarshan.exception;

import lombok.Data;

@Data
public class PathNotFoundException extends RuntimeException{

	private String message;

	public PathNotFoundException(String message) {
		super(message);
		this.message=message;
	}

}
