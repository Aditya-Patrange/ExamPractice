package com.cdac.sudarshan.watchlist.service;

import java.io.IOException;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.cdac.sudarshan.authentication.controller.AuthController;
import com.cdac.sudarshan.authentication.model.User;
import com.cdac.sudarshan.watchlist.configuration.ApplicationConfiguration;
import com.cdac.sudarshan.watchlist.dto.CollectionDto;
import com.cdac.sudarshan.watchlist.dto.ResponseDto;
import com.cdac.sudarshan.watchlist.dto.WatchlistDashboardDto;
import com.cdac.sudarshan.watchlist.dto.WatchlistDto;
import com.cdac.sudarshan.watchlist.dto.Watchlist_CollectionDto;
import com.cdac.sudarshan.watchlist.model.Frequency;
import com.cdac.sudarshan.watchlist.model.Source;
import com.cdac.sudarshan.watchlist.model.Watchlist;
import com.cdac.sudarshan.watchlist.repository.FrequencyRepository;
import com.cdac.sudarshan.watchlist.repository.SourceRepository;
import com.cdac.sudarshan.watchlist.repository.WatchlistRepository;

@Service
@Transactional
public class WatchlistService implements IWatchlistService {
	@Autowired
	private WatchlistRepository watchlistRepository;
	@Autowired
	private CollectionDto collectionDto;
	@Autowired
	private SourceRepository sourceRepository;
	@Autowired
	private FrequencyRepository frequencyRepository;
	@Autowired
	private ApplicationConfiguration appConfig;
	@Autowired
	private RestTemplate template;
	@Autowired
	private AuthController authController;

	public Watchlist saveWatchlist(WatchlistDto watchlistDto) throws RuntimeException {

		Watchlist watchlist = new Watchlist();
		watchlist.setWatchlistName(watchlistDto.getWatchlistName());
		watchlist.setAttributes(watchlistDto.getEntityAttribute());

//		List<BaseEntityDto> sourceIdList = watchlistDto.getSourceIdList();
//		List<Source> sources = new ArrayList<>();
////		for (BaseEntityDto baseEntityDto : sourceIdList) {
////			sources.add(sourceRepository.findById(baseEntityDto.getId()).get());
////			System.out.println("sources : "+sources);
////		}
//		for(int i=0; i<sourceIdList.size();i++) {
//			sources.add(sourceRepository.getById(sourceIdList.get(i).getId()));
//			System.out.println("sources : "+sources);
//		}
		User usr = AuthController.mainUser;
//		System.out.println("User Details : " + usr.getUsername());

		watchlist.setSource(sourceRepository.findById(watchlistDto.getSourceIdList())
				.orElseThrow(() -> new RuntimeException("Id not found")));
		watchlist.setFrequency(frequencyRepository.findById(watchlistDto.getFrequencyId()).get());
		watchlist.setCreatedOn(Instant.now());
		watchlist.setFromDate(watchlistDto.getFromDate());
		watchlist.setToDate(watchlistDto.getToDate());
		watchlist.setPriority(watchlistDto.getPriority());
		watchlist.setRemarks(watchlistDto.getRemarks());
		watchlist.setEnabled(true);
		watchlist.setUser(usr);
		return watchlistRepository.save(watchlist);
	}

	@Override
	public List<Watchlist> getAllWatchlist() {
//		return watchlistRepository.findAll();
		List<Watchlist> allWatchlists = watchlistRepository.getAllWatchlists();
//		List<Watchlist> allWatchlists  = watchlistRepository.findAll();
		return allWatchlists;
	}

	@Override
	public List<Source> getSources() {
		List<Source> a = sourceRepository.findAll();
		return a;
	}

	@Override
	public ResponseDto deleteWatchlistById(Integer id) {
		Watchlist watchlist = watchlistRepository.getById(id);
		watchlist.setEnabled(false);

		watchlistRepository.save(watchlist);
		ResponseDto responseDto = new ResponseDto();
		responseDto.setMsg("Watchlist " + watchlist.getWatchlistName() + " deleted Succesfully !!!");
//		watchlistRepository.deactivateWatchlist(id);
		// watchlistRepository.deleteById(id);
		return responseDto;
	}

	@Override
	public List<Frequency> getFrequencyList() {
		return frequencyRepository.findAll();
	}

	@Override
	public List<WatchlistDashboardDto> updateWatchlistStatus() throws IOException {

		List<Watchlist> watchlist = getAllWatchlist();
		List<WatchlistDashboardDto> dashboardDtos = new ArrayList<WatchlistDashboardDto>();

		for (int i = 0; i < watchlist.size(); i++) {
//			System.out.println(watchlist.get(i).toString());
			WatchlistDashboardDto watchlistDashboardDto = new WatchlistDashboardDto();
			watchlistDashboardDto.setEntityAttribute(watchlist.get(i).getAttributes());
			watchlistDashboardDto.setEndDate(watchlist.get(i).getToDate());
			watchlistDashboardDto.setPriority(watchlist.get(i).getPriority());
			Instant endDate = watchlist.get(i).getToDate();

			Instant today = Instant.now();
			long diffInDays = ChronoUnit.DAYS.between(today, endDate);
//			System.out.println("diffInDays : " + diffInDays);
			if (diffInDays >= 0) {
				if (diffInDays < Long.parseLong(appConfig.getProperty("dayRangeForWatchlist"))) {
					watchlistDashboardDto.setStatus("About to expire in " + diffInDays + " days");
				} else {
					watchlistDashboardDto.setStatus("Active");
				}
			} else {
				watchlistDashboardDto.setStatus("Expired");
			}
			dashboardDtos.add(watchlistDashboardDto);
		}
		return dashboardDtos;

	}

	@Override
	public Watchlist updateWatchlist(Integer id, @Valid WatchlistDto watchlistDto) {
		Watchlist watchlist = watchlistRepository.getById(id);
		watchlist.setFromDate(watchlistDto.getFromDate());
		watchlist.setAttributes(watchlistDto.getEntityAttribute());
		watchlist.setToDate(watchlistDto.getToDate());
		watchlist.setPriority(watchlistDto.getPriority());
		watchlist.setFrequency(frequencyRepository.getById(watchlistDto.getFrequencyId()));
		watchlist.setRemarks(watchlistDto.getRemarks());
		watchlist.setSource(sourceRepository.getById(watchlistDto.getSourceIdList()));
		watchlist.setWatchlistName(watchlistDto.getWatchlistName());
		watchlist.setEnabled(true);

		return watchlistRepository.save(watchlist);

//		System.out.println(watchlist);
//		return null;
	}

	@Override
	public List<Watchlist> deActivateWatchlistByDate() {
		List<Watchlist> watchlist = getAllWatchlist();
		long diffInDays = 0;
		for (int i = 0; i < watchlist.size(); i++) {
			Instant endDate = watchlist.get(i).getToDate();
			Instant today = Instant.now();
			diffInDays = ChronoUnit.DAYS.between(endDate, today);
			if (diffInDays >= Long.parseLong(appConfig.getProperty("dayRangeForWatchlistExpiry"))) {
				watchlist.get(i).setEnabled(false);
				watchlistRepository.save(watchlist.get(i));
			}
		}
		return watchlist;
	}

	@Override
	public ResponseEntity<?> checkCollectionId(HashMap<String, Object> data) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<Object>(data, headers);
		return template.exchange(appConfig.getProperty("kishanURL") + "updateCollectionById", HttpMethod.POST, entity,
				Object.class);
	}

	@Override
	public List<Watchlist> getWatchlistsByUserId(Long id) {
		return watchlistRepository.findByUser_Id(id);
	}

	@Override
	public ResponseEntity<?> addWatchlist_Collection(Watchlist_CollectionDto wCDto) {
		// Adding the Watchlist to DB
		Watchlist watchlist = new Watchlist();
		watchlist.setWatchlistName(wCDto.getWatchlist().getWatchlistName());
		watchlist.setAttributes(wCDto.getWatchlist().getEntityAttribute());
		User usr = AuthController.mainUser;
		watchlist.setSource(sourceRepository.findById(wCDto.getWatchlist().getSourceIdList())
				.orElseThrow(() -> new RuntimeException("Id not found")));
		watchlist.setFrequency(frequencyRepository.findById(wCDto.getWatchlist().getFrequencyId()).get());
		watchlist.setCreatedOn(Instant.now());
		watchlist.setFromDate(wCDto.getWatchlist().getFromDate());
		watchlist.setToDate(wCDto.getWatchlist().getToDate());
		watchlist.setPriority(wCDto.getWatchlist().getPriority());
		watchlist.setRemarks(wCDto.getWatchlist().getRemarks());
		watchlist.setEnabled(true);
		watchlist.setUser(usr);

		CollectionDto collection = wCDto.getCollection();
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<Object>(collection, headers);
		ResponseEntity<Object> exchangeData = template.exchange(
				appConfig.getProperty("URL") + "updateCollectionById", HttpMethod.POST, entity, Object.class);
		return new ResponseEntity<>(watchlistRepository.save(watchlist), HttpStatus.OK);
	}

}
