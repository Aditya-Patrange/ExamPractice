package com.cdac.sudarshan.entityprofiles.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cdac.sudarshan.entityprofiles.dto.EntityProfileDto;
import com.cdac.sudarshan.entityprofiles.service.IEntityProfileService;

@RestController
@RequestMapping("/entityProfile")
@CrossOrigin("*")
public class EntityProfileController {
	@Autowired
	IEntityProfileService entityProfileService;
	@PostMapping("/addProfile")
	private ResponseEntity<?> addEntityProfile(@RequestBody EntityProfileDto entityProfileDto) {
		//System.out.println(userId);
		System.out.println(entityProfileDto);
		return new ResponseEntity<>(entityProfileService.createEntityProfile(entityProfileDto), HttpStatus.OK);
	}
	@GetMapping("/getprofiles")
	public ResponseEntity<?>getAllEntityProfile()
	{
		return new ResponseEntity<>(entityProfileService.getAllEntityProfile(),HttpStatus.OK);
	}
	
}
