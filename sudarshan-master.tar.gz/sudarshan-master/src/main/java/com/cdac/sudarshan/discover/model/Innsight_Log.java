package com.cdac.sudarshan.discover.model;

public class Innsight_Log 
{
	private String loginId;
	private String loginUserName;
	private long logDate;
	private String activity;
	
	public String getLoginId() 
	{
		return loginId;
	}
	public void setLoginId(String loginId)
	{
		this.loginId = loginId;
	}
	public String getLoginUserName() 
	{
		return loginUserName;
	}
	public void setLoginUserName(String loginUserName) 
	{
		this.loginUserName = loginUserName;
	}
	public long getLogDate() 
	{
		return logDate;
	}
	public void setLogDate(long logDate) 
	{
		this.logDate = logDate;
	}
	public String getActivity()
	{
		return activity;
	}
	public void setActivity(String activity)
	{
		this.activity = activity;
	}
	@Override
	public String toString() 
	{
		return "Innsight_Log [loginId=" + loginId + ", loginUserName=" + loginUserName + ", logDate=" + logDate
				+ ", activity=" + activity + "]";
	}
}
