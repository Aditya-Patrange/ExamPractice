package com.cdac.sudarshan.entityprofiles.dto;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.cdac.sudarshan.authentication.model.User;
import com.cdac.sudarshan.folder.model.UrlsPath;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class EntityProfileDto {
	private String name;
	
	private LocalDate dateOfBirth;
	
	private User user;
	
	private List<UrlsPath> urlsPaths = new ArrayList<>();
}
