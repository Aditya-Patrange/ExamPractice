package com.cdac.sudarshan.mysearches.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cdac.sudarshan.mysearches.dto.MySearchesDto;
import com.cdac.sudarshan.mysearches.model.MySearches;
import com.cdac.sudarshan.mysearches.service.MySearchesService;

@RestController
@RequestMapping("/mysearches")
@CrossOrigin("*")
public class MySearchesController {
	@Autowired
	MySearchesService searchService;

	@PostMapping("/results")
	private ResponseEntity<?> getAllSearchResult(@RequestBody MySearchesDto searchDto) {
		//System.out.println(userId);
		return new ResponseEntity<>(searchService.findByUserId(searchDto), HttpStatus.OK);
	}

	@PostMapping("/insertion")
	private ResponseEntity<?> saveSearch(@RequestBody MySearches search) {
		searchService.saveOrUpdate(search);
		return new ResponseEntity<>(search.getId(),HttpStatus.OK);
	}

	@DeleteMapping("/delete")
	private void deleteSearch(@RequestBody List<Integer> ids) {
		ids.forEach(System.out::println);
		searchService.delete(ids);
	}

	@GetMapping("/toDiscover/{id}")
	private ResponseEntity<?> getSearchDataById(@PathVariable Integer id) {
		//System.out.println(userId);
		return new ResponseEntity<>(searchService.getSearchDataById(id), HttpStatus.OK);
	}
	
	@GetMapping("/getMostSearchedHistory")
	private ResponseEntity<?> getMostSearchedKeyword() {
		
		return new ResponseEntity<>(searchService.getMostSearchedHistory(), HttpStatus.OK);
	}
}
