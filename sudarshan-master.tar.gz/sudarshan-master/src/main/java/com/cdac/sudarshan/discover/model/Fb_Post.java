package com.cdac.sudarshan.discover.model;

import java.io.Serializable;
import java.util.ArrayList;

public class Fb_Post implements Serializable 
{
	private static final long serialVersionUID = 1L;
	private int entityId;
	private String postId;
	private String postUserId;
	private String postUserName;
	private String postUserPhoto;
	private String postSource;
	private String postObjectId;
	private String postStatusType;
	private String postCaption;
	private String postMessage;
	private String postLink;
	private String pageId;
	private String pageName;
	private String postType;
	private String postPicture;
	private String postLatitude;
	private String postLongitude;
	private String postLatLongLocation;
	private String postCountry;
	private String postState;
	private String postCity;
	private String postZip;
	private String postLinkName;
	private String postDescription;
	private String postViewerCount;
	private String postLikeUrl;
	private String postShareUserId;
	private String postShareUserName;
	private String postUserFullName;
	private String postWithUserId;
	private String postWithUserName;
	private int postShareCount;
	private int postSentiment=9;
    private int likeUrlStatus;
	private int postLikeCount;
	private int postCommentCount;
	private long postCreatedTime;
	private long postUpdatedTime;
	private ArrayList<String> postHashtag;
	private ArrayList<String> postMentionArray;
	private ArrayList<Fb_User> postMention;
	private ArrayList<Fb_Comment> postComment;
	private ArrayList<Fb_Media> postMedia;
	private ArrayList<Fb_User> postLike;
	private String postImgMd5;
	private ArrayList<String> priority;
	
	public ArrayList<String> getPostMentionArray() {
		return postMentionArray;
	}
	public void setPostMentionArray(ArrayList<String> postMentionArray) {
		this.postMentionArray = postMentionArray;
	}
	public String getPostImgMd5() {
		return postImgMd5;
	}
	public void setPostImgMd5(String postImgMd5) {
		this.postImgMd5 = postImgMd5;
	}
	public int getEntityId() {
		return entityId;
	}
	public void setEntityId(int entityId) {
		this.entityId = entityId;
	}
	public String getPostId() {
		return postId;
	}
	public void setPostId(String postId) {
		this.postId = postId;
	}
	public String getPostUserId() {
		return postUserId;
	}
	public void setPostUserId(String postUserId) {
		this.postUserId = postUserId;
	}
	public String getPostUserName() {
		return postUserName;
	}
	public void setPostUserName(String postUserName) {
		this.postUserName = postUserName;
	}
	public String getPostUserPhoto() {
		return postUserPhoto;
	}
	public void setPostUserPhoto(String postUserPhoto) {
		this.postUserPhoto = postUserPhoto;
	}
	public String getPostSource() {
		return postSource;
	}
	public void setPostSource(String postSource) {
		this.postSource = postSource;
	}
	public String getPostObjectId() {
		return postObjectId;
	}
	public void setPostObjectId(String postObjectId) {
		this.postObjectId = postObjectId;
	}
	public String getPostStatusType() {
		return postStatusType;
	}
	public void setPostStatusType(String postStatusType) {
		this.postStatusType = postStatusType;
	}
	public String getPostCaption() {
		return postCaption;
	}
	public void setPostCaption(String postCaption) {
		this.postCaption = postCaption;
	}
	public String getPostMessage() {
		return postMessage;
	}
	public void setPostMessage(String postMessage) {
		this.postMessage = postMessage;
	}
	public String getPostLink() {
		return postLink;
	}
	public void setPostLink(String postLink) {
		this.postLink = postLink;
	}
	public String getPageId() {
		return pageId;
	}
	public void setPageId(String pageId) {
		this.pageId = pageId;
	}
	public String getPageName() {
		return pageName;
	}
	public void setPageName(String pageName) {
		this.pageName = pageName;
	}
	public String getPostType() {
		return postType;
	}
	public void setPostType(String postType) {
		this.postType = postType;
	}
	public String getPostPicture() {
		return postPicture;
	}
	public void setPostPicture(String postPicture) {
		this.postPicture = postPicture;
	}
	public String getPostLatitude() {
		return postLatitude;
	}
	public void setPostLatitude(String postLatitude) {
		this.postLatitude = postLatitude;
	}
	public String getPostLongitude() {
		return postLongitude;
	}
	public void setPostLongitude(String postLongitude) {
		this.postLongitude = postLongitude;
	}
	public String getPostLatLongLocation() {
		return postLatLongLocation;
	}
	public void setPostLatLongLocation(String postLatLongLocation) {
		this.postLatLongLocation = postLatLongLocation;
	}
	public String getPostCountry() {
		return postCountry;
	}
	public void setPostCountry(String postCountry) {
		this.postCountry = postCountry;
	}
	public String getPostState() {
		return postState;
	}
	public void setPostState(String postState) {
		this.postState = postState;
	}
	public String getPostCity() {
		return postCity;
	}
	public void setPostCity(String postCity) {
		this.postCity = postCity;
	}
	public String getPostZip() {
		return postZip;
	}
	public void setPostZip(String postZip) {
		this.postZip = postZip;
	}
	public String getPostLinkName() {
		return postLinkName;
	}
	public void setPostLinkName(String postLinkName) {
		this.postLinkName = postLinkName;
	}
	public String getPostDescription() {
		return postDescription;
	}
	public void setPostDescription(String postDescription) {
		this.postDescription = postDescription;
	}
	public String getPostViewerCount() {
		return postViewerCount;
	}
	public void setPostViewerCount(String postViewerCount) {
		this.postViewerCount = postViewerCount;
	}
	public String getPostLikeUrl() {
		return postLikeUrl;
	}
	public void setPostLikeUrl(String postLikeUrl) {
		this.postLikeUrl = postLikeUrl;
	}
	public String getPostShareUserId() {
		return postShareUserId;
	}
	public void setPostShareUserId(String postShareUserId) {
		this.postShareUserId = postShareUserId;
	}
	public String getPostShareUserName() {
		return postShareUserName;
	}
	public void setPostShareUserName(String postShareUserName) {
		this.postShareUserName = postShareUserName;
	}
	public String getPostUserFullName() {
		return postUserFullName;
	}
	public void setPostUserFullName(String postUserFullName) {
		this.postUserFullName = postUserFullName;
	}
	public String getPostWithUserId() {
		return postWithUserId;
	}
	public void setPostWithUserId(String postWithUserId) {
		this.postWithUserId = postWithUserId;
	}
	public String getPostWithUserName() {
		return postWithUserName;
	}
	public void setPostWithUserName(String postWithUserName) {
		this.postWithUserName = postWithUserName;
	}
	public int getPostShareCount() {
		return postShareCount;
	}
	public void setPostShareCount(int postShareCount) {
		this.postShareCount = postShareCount;
	}
	public int getPostSentiment() {
		return postSentiment;
	}
	public void setPostSentiment(int postSentiment) {
		this.postSentiment = postSentiment;
	}
	public int getLikeUrlStatus() {
		return likeUrlStatus;
	}
	public void setLikeUrlStatus(int likeUrlStatus) {
		this.likeUrlStatus = likeUrlStatus;
	}
	public long getPostCreatedTime() {
		return postCreatedTime;
	}
	public void setPostCreatedTime(long postCreatedTime) {
		this.postCreatedTime = postCreatedTime;
	}
	public long getPostUpdatedTime() {
		return postUpdatedTime;
	}
	public void setPostUpdatedTime(long postUpdatedTime) {
		this.postUpdatedTime = postUpdatedTime;
	}
	public ArrayList<String> getPostHashtag() {
		return postHashtag;
	}
	public void setPostHashtag(ArrayList<String> postHashtag) {
		this.postHashtag = postHashtag;
	}
	public ArrayList<Fb_User> getPostMention() {
		return postMention;
	}
	public void setPostMention(ArrayList<Fb_User> postMention) {
		this.postMention = postMention;
	}
	public ArrayList<Fb_Comment> getPostComment() {
		return postComment;
	}
	public void setPostComment(ArrayList<Fb_Comment> postComment) {
		this.postComment = postComment;
	}
	public ArrayList<Fb_Media> getPostMedia() {
		return postMedia;
	}
	public void setPostMedia(ArrayList<Fb_Media> postMedia) {
		this.postMedia = postMedia;
	}
	public ArrayList<Fb_User> getPostLike() {
		return postLike;
	}
	public void setPostLike(ArrayList<Fb_User> postLike) {
		this.postLike = postLike;
	}
	public int getPostLikeCount() {
		return postLikeCount;
	}
	public void setPostLikeCount(int postLikeCount) {
		this.postLikeCount = postLikeCount;
	}
	public int getPostCommentCount() {
		return postCommentCount;
	}
	public void setPostCommentCount(int postCommentCount) {
		this.postCommentCount = postCommentCount;
	}
	public ArrayList<String> getPriority() {
		return priority;
	}
	public void setPriority(ArrayList<String> priority) {
		this.priority = priority;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "Fb_Post [entityId=" + entityId + ", postId=" + postId + ", postUserId=" + postUserId + ", postUserName="
				+ postUserName + ", postUserPhoto=" + postUserPhoto + ", postSource=" + postSource + ", postObjectId="
				+ postObjectId + ", postStatusType=" + postStatusType + ", postCaption=" + postCaption
				+ ", postMessage=" + postMessage + ", postLink=" + postLink + ", pageId=" + pageId + ", pageName="
				+ pageName + ", postType=" + postType + ", postPicture=" + postPicture + ", postLatitude="
				+ postLatitude + ", postLongitude=" + postLongitude + ", postLatLongLocation=" + postLatLongLocation
				+ ", postCountry=" + postCountry + ", postState=" + postState + ", postCity=" + postCity + ", postZip="
				+ postZip + ", postLinkName=" + postLinkName + ", postDescription=" + postDescription
				+ ", postViewerCount=" + postViewerCount + ", postLikeUrl=" + postLikeUrl + ", postShareUserId="
				+ postShareUserId + ", postShareUserName=" + postShareUserName + ", postUserFullName="
				+ postUserFullName + ", postWithUserId=" + postWithUserId + ", postWithUserName=" + postWithUserName
				+ ", postShareCount=" + postShareCount + ", postSentiment=" + postSentiment + ", likeUrlStatus="
				+ likeUrlStatus + ", postLikeCount=" + postLikeCount + ", postCommentCount=" + postCommentCount
				+ ", postCreatedTime=" + postCreatedTime + ", postUpdatedTime=" + postUpdatedTime + ", postHashtag="
				+ postHashtag + ", postMentionArray=" + postMentionArray + ", postMention=" + postMention
				+ ", postComment=" + postComment + ", postMedia=" + postMedia + ", postLike=" + postLike
				+ ", postImgMd5=" + postImgMd5 + ", priority=" + priority + "]";
	}

}
