package com.cdac.sudarshan.theme.dto;

import com.cdac.sudarshan.theme.model.SubTheme;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class ThemeDto {

    private Long id;
    private String themePath;
    @JsonIgnore
    private List<SubTheme> subThemes = new ArrayList<>();

    private int subThemeCount;

    private int keywordsCount;
    @JsonIgnore
    private LocalDateTime creationDate;

    private Object lastUpdatedDate;

    private List<String> keywords;
    private Long docCount;

}
