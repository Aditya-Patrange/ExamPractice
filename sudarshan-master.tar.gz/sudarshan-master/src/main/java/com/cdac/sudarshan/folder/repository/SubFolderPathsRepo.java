package com.cdac.sudarshan.folder.repository;

import com.cdac.sudarshan.folder.model.RootFolder;
import com.cdac.sudarshan.folder.model.SubFolderPaths;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SubFolderPathsRepo extends JpaRepository<SubFolderPaths, Long> {

	List<SubFolderPaths> findByFolderPath(RootFolder rootFolder);

	SubFolderPaths findBySubFolderPathAndFolderPath(String folderPath, RootFolder rootFolder);

	List<SubFolderPaths> findAllByFolderPath_Id(Long rootFolderId);

	List<SubFolderPaths> findAllByFolderPath_RootFolderName(String rootFolderName);
	
	List<SubFolderPaths> findAllBySubFolderPath(String subFolderName);

	@Query(value = "select s from SubFolderPaths s where s.subFolderPath =:subFolder")
	SubFolderPaths findBySubFolderPathName(@Param(value = "subFolder") String subFolderPath);

//	@Query(nativeQuery = true,value = "select * from sub_folder_paths where sub_folder_path =:subFolderPath")
//	SubFolderPaths findBySubFolder(@Param("subFolderPath") String subFolderPath);

	@Query("select s from SubFolderPaths s where s.subFolderPath = :subFolder and s.status = true")
	SubFolderPaths findBySubFolderPath(@Param("subFolder") String subFolder);

//	@Query(nativeQuery = true, value="select * from sub_folder_paths as a where a.sub_folder_path=:sub_folder_path and a.root_folder_id=:root_folder_id;")
//	SubFolderPaths findBySubFolderPathAndRootFolderId(@Param("sub_folder_path") String sub_folder_path, @Param("root_folder_id")Long root_folder_id);
	
	@Query(nativeQuery = true, value="select * from sub_folder_paths as a where a.sub_folder_path= ?1 and a.root_folder_id= ?2 and a.status= true")
	SubFolderPaths findBySubFolderPathAndRootFolderId(String sub_folder_path, Long root_folder_id);
	
	
	List<SubFolderPaths> findByParentSubFolderId(Long subFolderId);

	//Ajay
	@Query(nativeQuery = true, value="select * from sub_folder_paths as a where a.root_folder_id= ?1")
	List<SubFolderPaths> findBySubFoldersByRootFolderId(Long root_folder_id);

	@Query(nativeQuery = true, value="select * from sub_folder_paths as a where a.parent_sub_folder_id= ?1")
	SubFolderPaths findBySubFoldersByParentSubFolderId(Long parent_sub_folder_id);

	@Query(nativeQuery = true, value="select * from sub_folder_paths as a where a.parent_sub_folder_id= ?1")
	List<SubFolderPaths> fetchBySubFoldersByParentSubFolderId(Long parent_sub_folder_id);

	@Query("delete from SubFolderPaths u where u.id in(:subFolderIds)")
	void deleteByIdIn(List<Long> subFolderIds);

//	@Query("Select s from SubFolderPaths s where s.subFolderPath = :subFolderPath and s.folderPath = :folderPath and s.status = :status")
	SubFolderPaths findBySubFolderPathAndFolderPathAndStatus(String subFolderPath,RootFolder rootFolder,boolean status);

}
