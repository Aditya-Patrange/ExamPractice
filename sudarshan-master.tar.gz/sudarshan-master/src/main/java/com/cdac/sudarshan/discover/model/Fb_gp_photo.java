package com.cdac.sudarshan.discover.model;

public class Fb_gp_photo {

	String gp_id,gp_photo;

	public String getGp_id() {
		return gp_id;
	}

	public void setGp_id(String gp_id) {
		this.gp_id = gp_id;
	}

	public String getGp_photo() {
		return gp_photo;
	}

	public void setGp_photo(String gp_photo) {
		this.gp_photo = gp_photo;
	}
	
	
}
