package com.cdac.sudarshan.discover.controller;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cdac.sudarshan.discover.service.SReportService;

@RestController
@CrossOrigin("*")
@RequestMapping("/word")
public class SReportController {
	@Autowired
	private SReportService ReportService;
	
	@PostMapping("/getHashtagWordCloud")
	public ResponseEntity<?> getHashtagWordCloud(@RequestBody HashMap<String, Object> data) {
		return new ResponseEntity<>(ReportService.getHashtagWordCloud(data), HttpStatus.OK);
	}

	@PostMapping("/getMentionWordCloud")
	public ResponseEntity<?> getMentionWordCloud(@RequestBody HashMap<String, Object> data) {
		return new ResponseEntity<>(ReportService.getMentionWordCloud(data), HttpStatus.OK);
	}
	@PostMapping("/getPersonWordCloud")
	public ResponseEntity<?> getPersonWordCloud(@RequestBody HashMap<String, Object> data) {
		return new ResponseEntity<>(ReportService.getPersonWordCloud(data), HttpStatus.OK);
	}
	
	@PostMapping("/getPlaceWordCloud")
	public ResponseEntity<?> getPlaceWordCloud(@RequestBody HashMap<String, Object> data) {
		return new ResponseEntity<>(ReportService.getPlaceWordCloud(data), HttpStatus.OK);
	}

	

}
