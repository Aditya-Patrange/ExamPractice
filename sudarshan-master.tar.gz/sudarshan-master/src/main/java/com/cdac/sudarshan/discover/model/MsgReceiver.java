package com.cdac.sudarshan.discover.model;

import java.io.Serializable;

public class MsgReceiver  implements Serializable
{
	private static final long serialVersionUID = 1L;
	private String receiverType ; //0=phone,1=group 
    private String phoneno;
    private String status; 
    private String photo; 
    private String createdAt; 
    private String name;

	public String getReceiverType() {
		return receiverType;
	}
	public void setReceiverType(String receiverType) {
		this.receiverType = receiverType;
	}
	public String getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getPhoto() {
		return photo;
	}
	public void setPhoto(String photo) {
		this.photo = photo;
	}
	public String getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString()
	{
		return "MsgReceiver [receiverType=" + receiverType + ", phoneno=" + phoneno + ", status=" + status + ", photo="
				+ photo + ", createdAt=" + createdAt + ", name=" + name + "]";
	}	
}