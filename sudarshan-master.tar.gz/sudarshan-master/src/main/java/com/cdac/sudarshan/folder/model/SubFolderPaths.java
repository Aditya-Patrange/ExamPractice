package com.cdac.sudarshan.folder.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "sub_folder_paths")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@SequenceGenerator(name="seq", initialValue=10001,allocationSize=1000)
public class SubFolderPaths {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="seq")
	private Long id;
	
	private String subFolderPath;
	
	private Long parentSubFolderId;
	
	@ManyToOne
	@JoinColumn(name = "root_folder_id")
	@JsonIgnore
	private RootFolder folderPath;
	
	@OneToMany(mappedBy = "subFolderPaths")	
	@JsonIgnore
	private List<UrlsPath> urlsPaths;
	
	@CreationTimestamp
	private  LocalDateTime creationDate;
	
	@UpdateTimestamp
	private LocalDateTime lastUpdatedDate;

	private boolean status;
	
	
}			
