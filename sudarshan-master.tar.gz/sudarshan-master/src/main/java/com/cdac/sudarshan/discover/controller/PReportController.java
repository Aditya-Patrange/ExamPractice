package com.cdac.sudarshan.discover.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.cdac.sudarshan.discover.service.IReportSevice;

import java.util.HashMap;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin("*")
@RequestMapping("/reports")
public class PReportController {
	
	@Autowired
	private IReportSevice iReportService;

    @PostMapping("/trendingOrganization")
    public ResponseEntity<?> getTrendingOrganization(@RequestBody HashMap<String, Object> data)
    {
        return new ResponseEntity<>(iReportService.trendingOrganization(data), HttpStatus.OK);
    }
    
    @PostMapping("/tweetsReport")
    public ResponseEntity<?> getTweetsReport(@RequestBody HashMap<String, Object> data)
    {
        return new ResponseEntity<>(iReportService.getTweetsRpt(data), HttpStatus.OK);
    }
    
    @PostMapping("/userWordCloud")
    public ResponseEntity<?> getUserWordCloud(@RequestBody HashMap<String, Object> data)
    {
        return new ResponseEntity<>(iReportService.getUserWordCloud(data), HttpStatus.OK);
    }
    
    @PostMapping("/themeWordCloud")
    public ResponseEntity<?> getThemeWordCloud(@RequestBody HashMap<String, Object> data)
    {
        return new ResponseEntity<>(iReportService.getThemeWordCloud(data), HttpStatus.OK);
    }
    
}
