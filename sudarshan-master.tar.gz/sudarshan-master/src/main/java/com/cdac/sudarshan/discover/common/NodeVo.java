package com.cdac.sudarshan.discover.common;

public class NodeVo 
{
	private String name;
	private String screenName; 
	private String c="0";
	private String s="0"; 
    private String img; 
	private String p="0"; 
	private String id;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getScreenName() {
		return screenName;
	}

	public void setScreenName(String screenName) {
		this.screenName = screenName;
	}

	public String getC() {
		return c;
	}

	public void setC(String c) {
		this.c = c;
	}

	public String getS() {
		return s;
	}

	public void setS(String s) {
		this.s = s;
	}

	public String getImg() {
		return img;
	}

	public void setImg(String img) {
		this.img = img;
	}

	public String getP() {
		return p;
	}

	public void setP(String p) {
		this.p = p;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	@Override
	public String toString() 
	{
		return "NodeVo [name=" + name + ", screenName=" + screenName + ", c=" + c + ", s=" + s + ", img=" + img + ", p="
				+ p + ", id=" + id + "]";
	}
}

