package com.cdac.sudarshan.exception;

public class JwtTokenExpired extends RuntimeException {

    private String message;

    public JwtTokenExpired(String message) {
        super(message);
        this.message = message;
    }
}

