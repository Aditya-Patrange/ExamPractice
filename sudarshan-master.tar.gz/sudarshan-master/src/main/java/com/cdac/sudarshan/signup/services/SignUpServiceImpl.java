package com.cdac.sudarshan.signup.services;

import com.cdac.sudarshan.authentication.dto.UserDto;
import com.cdac.sudarshan.authentication.model.User;
import com.cdac.sudarshan.authentication.service.IUserService;
import com.cdac.sudarshan.code.model.Code;
import com.cdac.sudarshan.code.service.ICodeService;
import com.cdac.sudarshan.dto.SignupResponseDto;
import com.cdac.sudarshan.exception.UserNameFoundException;
import com.cdac.sudarshan.signup.utils.Constant;
import com.cdac.sudarshan.utils.GenerateRandomOTP;
import com.codahale.passpol.PasswordPolicy;
import com.codahale.passpol.Status;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonParser;
import org.jboss.aerogear.security.otp.Totp;
import org.jboss.aerogear.security.otp.api.Base32;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.http.client.ClientHttpRequest;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RequestCallback;
import org.springframework.web.client.ResponseExtractor;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.*;

@Service
public class SignUpServiceImpl implements ISignUpService {

    @Autowired
    private RestTemplate template;
    @Autowired
    private PasswordEncoder passwordEncoder;

    @Value("${innerInnefuUrl}")
    private String innefuUrl;
    @Value("${loginUser}")
    private String user;
    @Value("${password}")
    private String password;
    private char[] CHARACTERS;

    private final PasswordPolicy passwordPolicy;
    @Autowired
    private IUserService userService;
    @Autowired
    private ICodeService codeService;

    public static List<String> codes = new ArrayList<>();

    public SignUpServiceImpl(PasswordPolicy passwordPolicy) {
        this.passwordPolicy = passwordPolicy;
    }


    @Override
    public SignupResponseDto signup(UserDto userDto) {

        Optional<User> dbUser = userService.fetchUserByUserName(userDto.getUserName());

        if (dbUser.isPresent()) {
            throw new UserNameFoundException("User " + userDto.getUserName() + " already exist...!!!");
        }

        Status status = this.passwordPolicy.check(userDto.getPassword());

        if (status != Status.OK) {
            return new SignupResponseDto(SignupResponseDto.Status.WEAK_PASSWORD);
        }

        // For 2FA Enabled then generate secret code
        if (userDto.isTotp()) {
            String secret = Base32.random();
            CHARACTERS = (secret + "1234567890").toCharArray();
            if (codes.size() != 9) {
                for (String code : GenerateRandomOTP.generateCodes(9, CHARACTERS, Constant.CODE_LENGTH, Constant.GROUPS_NBR)) {
                    codes.add(code);
                }
            } else {
                codes = new ArrayList<>();
                for (String code : GenerateRandomOTP.generateCodes(9, CHARACTERS, Constant.CODE_LENGTH, Constant.GROUPS_NBR)) {
                    codes.add(code);
                }
            }

            // Save user in innefu login_details tables
            Long userId = getUserIdFromInnefu(userDto);

            // Save user in CDAC user table
            User newUser = new User();
            newUser.setId(userId);
            newUser.setUsername(userDto.getUserName());
            newUser.setPasswordHash(this.passwordEncoder.encode(userDto.getPassword()));
            newUser.setSecret(secret);
            newUser.setEnabled(true);
            newUser.setAdditionalSecurity(false);
            User saveUser = userService.saveUser(newUser);

            // For 9 code generation + mapping
            List<Code> secretCodes = new ArrayList<>();
            for (String str : codes) {
                secretCodes.add(new Code(str, saveUser));
            }
            saveUser.setCodes(secretCodes);
            codeService.saveCode(secretCodes);

            Map<Integer, Object> codesMap = new HashMap<>();
            int i = 0;
            for (String s : codes) {
                codesMap.put(i, s);
                i++;
            }

            SignupResponseDto signUpResponse = new SignupResponseDto(SignupResponseDto.Status.OK, userDto.getUserName(),
                    secret, codesMap);
            return signUpResponse;

            // For 2FA Disabled then register user without 9 code & seceret code
        } else {

            // Save user in innefu login_details tables
            Long userId = getUserIdFromInnefu(userDto);

            User newUser = new User();
            newUser.setId(userId);
            newUser.setUsername(userDto.getUserName());
            newUser.setPasswordHash(this.passwordEncoder.encode(userDto.getPassword()));
            newUser.setSecret(null);
            newUser.setEnabled(true);
            newUser.setAdditionalSecurity(false);
            User saveUser = userService.saveUser(newUser);

            return new SignupResponseDto(SignupResponseDto.Status.OK, saveUser.getUsername());
        }
    }

    @Override
    public ResponseEntity<?> signupConfirmSecret(Map<String, String> loggedInUser) {
        try {
            User existingUser = userService.getUserByUserName(loggedInUser.get("username"));
/// error occurs
            List<Code> newCodes = codeService.getSecurityCode(existingUser);
            List<String> backCode = new ArrayList<>();

            if (existingUser != null) {
                String secret = existingUser.getSecret();
                Totp totp = new Totp(secret);

                for (Code c : newCodes) {
                    backCode.add(c.getSecurityCode());
                }

                if (backCode.contains(loggedInUser.get("code"))) {
                    existingUser.setEnabled(true);
                    return ResponseEntity.ok(true);
                }

                if (!loggedInUser.get("code").toLowerCase().matches("[a-z]")) {
                    Thread.sleep(10500);
                    if (totp.verify(loggedInUser.get("code"))) {
                        existingUser.setEnabled(true);
                        return ResponseEntity.ok(true);
                    }
                }
            }
        } catch (Exception e) {
            return new ResponseEntity<>("Invalid OTP please try with another OTP", HttpStatus.INTERNAL_SERVER_ERROR);
        }

        return ResponseEntity.ok(false);

    }

    private Long getUserIdFromInnefu(UserDto userDto) {
        HashMap<String, Object> data = new HashMap<>();
        data.put("mode", "a");
        data.put("userName", userDto.getUserName());
        data.put("password", userDto.getPassword());
        data.put("role", userDto.getRole());
        data.put("comment", userDto.getComment());
        data.put("id", 0);
        data.put("sort", "dd");
        data.put("keyword", "");
        data.put("createdBy", userDto.getCreatedBy());
        data.put("templateId", userDto.getTemplateId());

        HttpHeaders headers = getHttpHeadersAfterLogin();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<>(data, headers);
        ResponseEntity<Object> result = template.exchange(innefuUrl + "innsight/createAccount", HttpMethod.POST, entity, Object.class);

        // convert into jasonArray
        Gson gson = new GsonBuilder().serializeNulls().create();
        String stringJson = gson.toJson(result.getBody());

        JsonArray jsonArray = (JsonArray) new JsonParser().parse(stringJson);

        int userId = jsonArray.get(0).getAsJsonObject().get("id").getAsInt();

        return Long.valueOf(userId);
    }

    public HttpHeaders getHttpHeadersAfterLogin() {
        ClientHttpResponse response = template.execute(innefuUrl + "innsight/login_validateCredential", HttpMethod.POST,
                new RequestCallback() {
                    public void doWithRequest(ClientHttpRequest request) throws IOException {
                        request.getBody().write(("userName=" + user + "&password=" + password).getBytes());
                    }
                }, new ResponseExtractor<ClientHttpResponse>() {

                    @Override
                    public ClientHttpResponse extractData(ClientHttpResponse response) throws IOException {
                        return response;
                    }
                });

        HttpHeaders headers = new HttpHeaders();
        List<String> cookies = response.getHeaders().get("Set-Cookie");
        headers.set("Cookie", cookies.get(0));
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        return headers;
    }

}
