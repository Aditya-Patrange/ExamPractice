package com.cdac.sudarshan.discover.common;

public class CrawlerSourceVo {
private String hostName;

public String getHostName() {
	return hostName;
}

public void setHostName(String hostName) {
	this.hostName = hostName;
}

}
