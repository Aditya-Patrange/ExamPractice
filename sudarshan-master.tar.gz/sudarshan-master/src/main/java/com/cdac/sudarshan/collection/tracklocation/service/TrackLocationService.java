package com.cdac.sudarshan.collection.tracklocation.service;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.cdac.sudarshan.authentication.model.User;
import com.cdac.sudarshan.authentication.service.IUserService;
import com.cdac.sudarshan.exception.ResourceNotFoundException;
@Service
public class TrackLocationService implements ITrackLocationService{
	private RestTemplate template;
	
	@Value("${innefuUrl}")
	private String innefuUrl;
	
	@Autowired
    private IUserService userService;

	
	
	
	public TrackLocationService() {
		template = new RestTemplate();
	}
	@SuppressWarnings("unchecked")
	@Override
	public ResponseEntity<?> trackLocation(HashMap<String, Object> data) {
		Map<String, Object> map = (Map<String, Object>)data.get("addNewCollection"); 
		
		List<Object> str = Arrays.asList(map);
		HttpHeaders header = new HttpHeaders();
		header.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		header.setContentType(MediaType.APPLICATION_JSON);
		
		HashMap<String, Object> pauseSearch = (HashMap<String,Object>)data.get("addNewCollection");
		

		HttpEntity<Object> pauseEntity = new HttpEntity<>(setUserId(pauseSearch),header);
		HttpEntity<Object> entity = new HttpEntity<>(pauseEntity);
		
		return template.exchange(innefuUrl +"/collectionmanager/addNewCollection", HttpMethod.POST,pauseEntity,Object.class);
		
	}
	
	private HashMap<String,Object> setUserId(HashMap<String,Object> map){

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        User loggedInUser = userService.getUserByUserName(authentication.getName());

        if (loggedInUser == null) {
            throw new ResourceNotFoundException("Please Login first For adding add url");
        }

        map.put("userId",loggedInUser.getId());

        return map;
    }
}
