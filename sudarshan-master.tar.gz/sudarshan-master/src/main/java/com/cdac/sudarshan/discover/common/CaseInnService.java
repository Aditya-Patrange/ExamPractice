package com.cdac.sudarshan.discover.common;

public interface CaseInnService {
	
	public boolean validateOTP(String username, String otp);
	public boolean validateLDAP(String username, String password, String ldapHostname, String ldapDomainName);

}