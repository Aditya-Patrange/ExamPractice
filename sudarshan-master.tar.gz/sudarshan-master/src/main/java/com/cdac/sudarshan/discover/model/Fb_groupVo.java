package com.cdac.sudarshan.discover.model;

import java.util.List;

public class Fb_groupVo 
{
	private String user_id;
	private String user_name;
	private String gp_name;
	private String gp_Id;
	private String gp_memebers;
	private String gp_memebers_image;
	private String gp_text;
	private String gp_photo;
	private String gp_url;
	private String creationDate;
	private String localImgName;
	private String localLargeImgName;
	private String absPathLocal;
	List<Fb_gp_photo> gp_phpto_lst;
    private int count;	
	
    
	public String getGp_memebers_image() {
		return gp_memebers_image;
	}
	public void setGp_memebers_image(String gp_memebers_image) {
		this.gp_memebers_image = gp_memebers_image;
	}
	public String getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}
	public String getLocalLargeImgName() {
		return localLargeImgName;
	}
	public void setLocalLargeImgName(String localLargeImgName) {
		this.localLargeImgName = localLargeImgName;
	}
	public String getAbsPathLocal() {
		return absPathLocal;
	}
	public void setAbsPathLocal(String absPathLocal) {
		this.absPathLocal = absPathLocal;
	}
	public String getGp_url() {
		return gp_url;
	}
	public void setGp_url(String gp_url) {
		this.gp_url = gp_url;
	}
	public String getGp_photo() {
		return gp_photo;
	}
	public void setGp_photo(String gp_photo) {
		this.gp_photo = gp_photo;
	}
	public List<Fb_gp_photo> getGp_phpto_lst() {
		return gp_phpto_lst;
	}
	public void setGp_phpto_lst(List<Fb_gp_photo> gp_phpto_lst) {
		this.gp_phpto_lst = gp_phpto_lst;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getGp_name() {
		return gp_name;
	}
	public void setGp_name(String gp_name) {
		this.gp_name = gp_name;
	}
	public String getGp_Id() {
		return gp_Id;
	}
	public void setGp_Id(String gp_Id) {
		this.gp_Id = gp_Id;
	}
	public String getGp_memebers() {
		return gp_memebers;
	}
	public void setGp_memebers(String gp_memebers) {
		this.gp_memebers = gp_memebers;
	}
	public String getGp_text() {
		return gp_text;
	}
	public void setGp_text(String gp_text) {
		this.gp_text = gp_text;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public String getLocalImgName() {
		return localImgName;
	}
	public void setLocalImgName(String localImgName) {
		this.localImgName = localImgName;
	}
	@Override
	public String toString() {
		return "Fb_groupVo [user_id=" + user_id + ", user_name=" + user_name + ", gp_name=" + gp_name + ", gp_Id="
				+ gp_Id + ", gp_memebers=" + gp_memebers + ", gp_memebers_image=" + gp_memebers_image + ", gp_text="
				+ gp_text + ", gp_photo=" + gp_photo + ", gp_url=" + gp_url + ", creationDate=" + creationDate
				+ ", localImgName=" + localImgName + ", localLargeImgName=" + localLargeImgName + ", absPathLocal="
				+ absPathLocal + ", gp_phpto_lst=" + gp_phpto_lst + ", count=" + count + "]";
	}
	
}
