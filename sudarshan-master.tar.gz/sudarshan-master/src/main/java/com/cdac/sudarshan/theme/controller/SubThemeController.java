package com.cdac.sudarshan.theme.controller;

import com.cdac.sudarshan.theme.dto.SubThemeDto;
import com.cdac.sudarshan.theme.model.SubTheme;
import com.cdac.sudarshan.theme.service.ISubThemeService;
import com.cdac.sudarshan.theme.service.IThemeService;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("sub-themes")
public class SubThemeController {

    @Autowired
    private ISubThemeService subThemeService;

    @Autowired
    private IThemeService themeService;

    @Autowired
    private ModelMapper modelMapper;

    @PostMapping("saveSubTheme")
    public ResponseEntity<?> addSubThemeToRootTheme(@RequestBody Map<String, String> map) {

        Map<String, Object> response = new HashMap<>();

        List<SubThemeDto> subThemeDtos = subThemeService.addSubThemeToRootTheme(map.get("path"));

        response.put("Message", "Theme added SuccessFully");
        response.put("statusCode", String.valueOf(HttpStatus.CREATED.value()));
        response.put("ThemeName", subThemeDtos.get(0).getSubThemePath());
        response.put("Creation_Date_And_Time", String.valueOf(subThemeDtos.get(0).getCreationDate()));

        return ResponseEntity.ok(response);

    }

    @PostMapping("/getSubThemes")
    public ResponseEntity<?> getSubThemesOfRootTheme(@RequestBody Map<String, String> map) {
        List<SubTheme> subThemes = subThemeService.getAllSubThemeOfRootTheme(map.get("path"));

        List<SubThemeDto> subThemeDtos = subThemes.stream().map(subTheme -> modelMapper.map(subTheme, SubThemeDto.class)).collect(Collectors.toList());
        return ResponseEntity.ok(subThemeDtos);

    }


}
