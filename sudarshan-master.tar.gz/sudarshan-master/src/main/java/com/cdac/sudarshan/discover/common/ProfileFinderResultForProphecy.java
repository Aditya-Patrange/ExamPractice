package com.cdac.sudarshan.discover.common;

public class ProfileFinderResultForProphecy 
{
	private String keyword;
	private String countryCode;
	private String searchStatus;
	private String profileImage;
	private String profileDescription;
	private String sourceType;
	private String searchDate;
	
	public String getKeyword() {
		return keyword;
	}
	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getSearchStatus() {
		return searchStatus;
	}
	public void setSearchStatus(String searchStatus) {
		this.searchStatus = searchStatus;
	}
	public String getProfileImage() {
		return profileImage;
	}
	public void setProfileImage(String profileImage) {
		this.profileImage = profileImage;
	}
	public String getProfileDescription() {
		return profileDescription;
	}
	public void setProfileDescription(String profileDescription) {
		this.profileDescription = profileDescription;
	}
	public String getSourceType() {
		return sourceType;
	}
	public void setSourceType(String sourceType) {
		this.sourceType = sourceType;
	}
	public String getSearchDate() {
		return searchDate;
	}
	public void setSearchDate(String searchDate) {
		this.searchDate = searchDate;
	}
	@Override
	public String toString() {
		return "ProfileFinderResultForProphecy [keyword=" + keyword + ", countryCode=" + countryCode + ", searchStatus="
				+ searchStatus + ", profileImage=" + profileImage + ", profileDescription=" + profileDescription
				+ ", sourceType=" + sourceType + ", searchDate=" + searchDate + "]";
	}
}
