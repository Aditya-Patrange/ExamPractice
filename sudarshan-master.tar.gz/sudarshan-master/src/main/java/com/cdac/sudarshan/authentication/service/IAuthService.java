package com.cdac.sudarshan.authentication.service;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.Map;

public interface IAuthService {

    ResponseEntity<?> signIn(Map<String,String> user);
    ResponseEntity<?> verifyOTP(@RequestBody Map<String, String> secretCode);
    ResponseEntity<?> getCodesOfUser(String username);
   // ResponseEntity<?> getCaptcha();

    ResponseEntity<?> getLoggedInUserDetails();

}
