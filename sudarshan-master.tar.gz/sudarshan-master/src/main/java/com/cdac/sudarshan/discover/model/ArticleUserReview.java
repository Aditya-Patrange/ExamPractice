package com.cdac.sudarshan.discover.model;

import java.io.Serializable;

public class ArticleUserReview implements Serializable 
{
	private static final long serialVersionUID = 1L;
	private int loginId;
	private long userReviewDate;
	private String userReview;
	
	public int getLoginId() {
		return loginId;
	}
	public void setLoginId(int loginId) {
		this.loginId = loginId;
	}
	public long getUserReviewDate() {
		return userReviewDate;
	}
	public void setUserReviewDate(long userReviewDate) {
		this.userReviewDate = userReviewDate;
	}
	public String getUserReview() {
		return userReview;
	}
	public void setUserReview(String userReview) {
		this.userReview = userReview;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "ArticleUserReview [loginId=" + loginId + ", userReviewDate=" + userReviewDate + ", userReview="
				+ userReview + "]";
	}
	
}
