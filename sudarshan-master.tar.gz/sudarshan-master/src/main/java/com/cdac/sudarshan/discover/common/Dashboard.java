package com.cdac.sudarshan.discover.common;

import java.util.ArrayList;

public class Dashboard
{
	private int dashboardId;
	private String dashboardName;
	private String createdBy;
	private int isPublic;
	//private Date creationDate;
	private String creationDate;
	
	public int getDashboardId()
	{
		return dashboardId;
	}
	public void setDashboardId(int dashboardId)
	{
		this.dashboardId = dashboardId;
	}
	
	public String getDashboardName()
	{
		return dashboardName;
	}
	public void setDashboardName(String dashboardName)
	{
		this.dashboardName = dashboardName;
	}
	
	public String getCreatedBy()
	{
		return createdBy;
	}	
	public void setCreatedBy(String createdBy)
	{
		this.createdBy = createdBy;
	}
		
	public int getIsPublic()
	{
		return isPublic;
	}
	public void setIsPublic(int isPublic)
	{
		this.isPublic = isPublic;
	}
	
	public String getCreationDate()
	{
		return creationDate;
	}
	public void setCreationDate(String creationDate)
	{
		this.creationDate = creationDate;
	}
	@Override
	public String toString()
	{
		return "Dashboard [dashboardId===>" + dashboardId + ", dashboardName===>"
				+ dashboardName + ", createdBy===>" + createdBy + ", isPublic===>"
				+ isPublic + ", creationDate===>" + creationDate + "]";
	}
	private String sort;
	private String createdByName;
	private ArrayList<String> widgetIds;
	private int widgetId;
	public String getSort() {
		return sort;
	}
	public void setSort(String sort) {
		this.sort = sort;
	}
	public String getCreatedByName() {
		return createdByName;
	}
	public void setCreatedByName(String createdByName) {
		this.createdByName = createdByName;
	}
	public int getWidgetId() {
		return widgetId;
	}
	public void setWidgetId(int widgetId) {
		this.widgetId = widgetId;
	}
	public ArrayList<String> getWidgetIds() {
		return widgetIds;
	}
	public void setWidgetIds(ArrayList<String> widgetIds) {
		this.widgetIds = widgetIds;
	}
	
	

}
