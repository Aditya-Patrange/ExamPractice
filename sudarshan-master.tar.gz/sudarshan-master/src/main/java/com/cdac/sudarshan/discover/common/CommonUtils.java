package com.cdac.sudarshan.discover.common;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.security.MessageDigest;
import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpSession;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.output.ByteArrayOutputStream;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

//import com.innefu.innsight.modal.Innsight_Log;

import io.searchbox.action.Action;
import io.searchbox.client.JestClient;
import io.searchbox.core.Bulk;
import io.searchbox.core.BulkResult;
import io.searchbox.core.BulkResult.BulkResultItem;
import io.searchbox.core.Index;

@Component
public class CommonUtils {
	@Autowired
	JestClient client;
	
	@Autowired 
	private HttpSession httpSession;
	
	Logger log = Logger.getRootLogger();
	
	public static String executeShellCommand(String[] command) {
		StringBuffer output = new StringBuffer();
		try {
			final Process p = Runtime.getRuntime().exec(command);
			p.waitFor();
			BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
			String line = "";
			while ((line = reader.readLine()) != null) {
				output.append(line + "\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return output.toString();
	}

	public static int compareDate(String strDate1, String strDate2) {
		int i = 2;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		try {
			i = sdf.parse(strDate1).compareTo(sdf.parse(strDate2));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return i;
	}


	public static String formatedString(String str) {
		String strReturn = str;
		try {
			strReturn = String.format("%.2f", Double.parseDouble(strReturn));
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return strReturn;
	}


	public static String convertDateFormat(String input) {
		String dateReceivedFromUser = input;
		DateFormat userDateFormat = new SimpleDateFormat("dd/MM/yyyy");
		DateFormat dateFormatNeeded = new SimpleDateFormat("yyyy-MM-dd");
		Date date = null;
		try {
			date = userDateFormat.parse(dateReceivedFromUser);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String convertedDate = dateFormatNeeded.format(date);
		return convertedDate;
	}

	public static String escapeSingeQoute(String str) {
		return str.replace("'", "\\'");
	}

	public static String getSqlCurrentDateTime()
	{
		java.util.Date dt = new java.util.Date();
		java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return sdf.format(dt);
	}

	public static boolean stringNotEmpty(String str) {
		if (StringUtils.isEmpty(str)) {
			return false;
		} else {
			return true;
		}
	}

	public static String removeSpaceFromTxt(String str) {
		return str.trim().replaceAll("( +)", " ").trim();
		// return str1.trim();
	}

	public static String splitSring(String str) {
		try {
			if (str.indexOf("site:") < 0) {
				return str;
			} else {
				return str.split("site:")[1];
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			return str;
		}
	}

	public static String splitSring1(String str) {
		try {
			if (str.indexOf("site:") < 0) {
				return str;
			} else {
				return str.split("site:")[0];
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			return str;
		}
	}

	public static String makeStringFullTextSrch(String str) {
		String outString = "";
		try {
			str = str.replace(" and ", " ");
			String strArry[] = str.split(" ");
			for (String string : strArry) {
				if (stringNotEmpty(string) && !string.equals("*")) {
					outString += "  dc.subtitle like '%" + string.trim() + "%' ";
					outString += " or dc.title like '%" + string.trim() + "%' ";
					outString += " or dc.content like '%" + string.trim() + "%' or";
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return outString;
	}

	public static String formatedString1(String str) {
		String strReturn = str;
		try {

			String str3 = strReturn.substring(0, strReturn.length() - 3);
			String str1 = strReturn.substring(strReturn.length() - 3, strReturn.length());
			// System.out.println(str1);
			// System.out.println(str3);
			String regex = "(\\d)(?=(\\d{3})+$)";
			strReturn = str3.replaceAll(regex, "$1,") + str1;

		} catch (Exception ex) {
			// ex.printStackTrace();
		}
		return strReturn;
	}

	public static String formatedString2(String str) {
		String strReturn = str;
		try {
			NumberFormat numberFormat = NumberFormat.getNumberInstance(Locale.US);
			strReturn = numberFormat.format(Integer.parseInt(str));
		} catch (NumberFormatException ex) {
			ex.printStackTrace();
		}
		return strReturn;
	}

	public static String changeAdvFilter(String INPUT, String type) {
		ArrayList<String> lst = new ArrayList<String>();
		lst.add(")");
		lst.add("(");
		lst.add("AND");
		lst.add("OR");
		String outPut = "";
		INPUT = INPUT.replace("(", " ( ").replace(")", " ) ");
		String[] arr = INPUT.split(" ");
		for (int i = 0; i < arr.length; i++) {
			if (arr[i].trim().isEmpty()) {
				continue;
			}
			if (lst.contains(arr[i].trim().toUpperCase())) {
				outPut += " " + arr[i].trim() + " ";
			} else {
				outPut += " " + type + " like '%" + arr[i].trim() + "%' ";
			}
		}
		return outPut;
	}

	public static String readFile(String filePath, String imgFolderPath) {
		String downloadFile = null;
		try {
			String path = imgFolderPath.replace("innsight/", "");
			String finalPath = path + "/" + filePath + ".jpg";
			downloadFile = new File(finalPath).toString();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return downloadFile;
	}

	public static String convertStringToMd5(String txt) {
		StringBuffer sb = new StringBuffer();
		try {
			MessageDigest md = MessageDigest.getInstance("MD5");
			md.update(txt.getBytes());
			byte byteData[] = md.digest();
			// convert the byte to hex format method 1
			for (int i = 0; i < byteData.length; i++) {
				sb.append(Integer.toString((byteData[i] & 0xff) + 0x100, 16).substring(1));
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return sb.toString();
	}
	
	
	public static String convertUnixTimeToDateDisplayFormat(Long dt) {
		String dateRtn = Long.toString(dt);
		try {
			// Date date = new Date(dt*1000);
			Date date = new Date(dt);
			dateRtn = DateFormat.getDateTimeInstance().format(date);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return dateRtn;
	}
	
	
	public static String convertUnixTimeToDate_yyyy_mm_dd(Long dt) {
		String dateRtn = Long.toString(dt);
		try {
			Date date = new Date(dt);
			DateFormat df81 = new SimpleDateFormat("yyyy-MM-dd");
			dateRtn = df81.format(date);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return dateRtn;
	}

	public static String convertUnixTimeToDate_dd_mm_yyyy(Long dt) {
		String dateRtn = Long.toString(dt);
		try {
			Date date = new Date(dt);
			DateFormat df81 = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
			dateRtn = df81.format(date);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return dateRtn;
	}
	
	public static String convertUnixTimeToDate_yyyy_mm_dd_HH_mm_ss(long dt) {
		String dateRtn = Long.toString(dt);
		try {
			Date date = new Date(dt);
			DateFormat df81 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			dateRtn = df81.format(date);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return dateRtn;
	}
	
	public static String formatedString2(Integer ytViewCount) {
		String strReturn = ytViewCount.toString();
		try {
			NumberFormat numberFormat = NumberFormat.getNumberInstance(Locale.US);
			strReturn = numberFormat.format(ytViewCount);
		} catch (NumberFormatException e) {
			e.printStackTrace();
		}
		return strReturn;
	}
	
	public static int isNegative(double d) {
		return Double.compare(d, 0.0);
	}

	
	public static java.sql.Date string2Date(String str) {
		if (str != "") {
			java.sql.Date d2 = null;
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
			try {
				java.util.Date d = sdf.parse(str);
				d2 = new java.sql.Date(d.getTime());
			} catch (ParseException e) {
				e.printStackTrace();
			}
			return d2;
		} else {
			java.sql.Date d3 = null;
			return d3;
		}
	}

	public static String date2String(java.sql.Date d) {
		if (d != null) {
			String d2 = null;
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
			try {
				d2 = sdf.format(d);
			} catch (Exception e) {
				e.printStackTrace();
			}
			return d2;
		} else {
			return "";
		}
	}
	
	public static void main1(String[] args) {
		Date date = new Date();
		java.sql.Date date1 = new java.sql.Date(date.getTime());
		String str = date2String(date1);
	}

	public static String object2String(Object d) {
		if (d != null) {
			String d2 = null;
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
			try {
				d2 = sdf.format(d);
			} catch (Exception e) {
				e.printStackTrace();
			}
			return d2;
		} else {
			return "";
		}
	}
	
	public static java.sql.Date string2Date12(String str) {
		if (str != "") {
			java.sql.Date d2 = null;
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
			try {
				java.util.Date d = sdf.parse(str);
				d2 = new java.sql.Date(d.getTime());
			} catch (ParseException e) {
				e.printStackTrace();
			}
			return d2;
		} else {
			java.sql.Date d3 = null;
			return d3;
		}
	}
	
	public static String stringToStringDate(Date str) {
		if (str != null) {
			String d2 = null;
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			try {
				d2 = sdf.format(str);
			} catch (Exception e) {
				e.printStackTrace();
			}
			return d2;
		} else {
			return "";
		}
	}
	
	
//	public static void main(String[] args) {
//		// System.out.println(object2String(2018-02-20));
//		/*
//		 * Date date = new Date(); Calendar cal = Calendar.getInstance();
//		 * //cal.add(Calendar.MONTH, -6); java.util.Date dt = cal.getTime(); int
//		 * x=dt.get(Calendar.YEAR); int y=dt.getMonth()+1; int z=dt.getDate();
//		 * 
//		 * System.out.println("x:------------------> "+x);
//		 * System.out.println("y:------------------> "+y);
//		 * System.out.println("z:------------------> "+z);
//		 * 
//		 * System.out.println("date:======> "+date);
//		 * System.out.println("dt:======> "+dt);
//		 */
//
//		Calendar cal = Calendar.getInstance();
//
//		System.out.println("Current date : " + (cal.get(Calendar.MONTH) + 1) + "-" + cal.get(Calendar.DATE) + "-"
//				+ cal.get(Calendar.YEAR));
//
//		// String s1 = stringToStringDate(04/18/2018");
//		// System.out.println("s1:----- "+s1);
//
//		System.out.println(convertUnixTimeToDateDisplayFormat(1560151382000l));
//		System.out.println("date: " + convertUnixTimeToDate_yyyy_mm_dd_HH_mm_ss(1565184168000L));
//		System.out.println("date1: " + convertUnixTimeToDateDisplayFormat(1565184168000L));
//
//	}
	
	public static String imageToBase64(String filePath) throws IOException {
		byte[] fileContent = FileUtils.readFileToByteArray(new File(filePath));
		String encodedString = Base64.getEncoder().encodeToString(fileContent);
		return encodedString;
	}
	
	public static String remoteImageToBase64(String filePath) throws IOException {
		URL url = new URL(filePath);
		InputStream is = url.openStream();
		ByteArrayOutputStream os = new ByteArrayOutputStream();
		byte[] buf = new byte[4096];
		int n;
		while ((n = is.read(buf)) >= 0)
			os.write(buf, 0, n);
		os.close();
		is.close();
		byte[] data = os.toByteArray();
		String encodedString = Base64.getEncoder().encodeToString(data);
		return encodedString;
	}
	
	public void insertUserActivityLogs(String textMesage) {
		String userId = (String) httpSession.getAttribute(ApplicationConstants.LOGINUSERID);
		String userName = (String) httpSession.getAttribute(ApplicationConstants.LOGIN_USER);

		Long currentTime = Calendar.getInstance().getTimeInMillis();
		Innsight_Log innsightLog = new Innsight_Log();
		innsightLog.setLoginId(userId);
		innsightLog.setLoginUserName(userName);
		innsightLog.setLogDate(currentTime);
		innsightLog.setActivity(textMesage);

		ArrayList<Index> logLst = new ArrayList<Index>();
		try {
			logLst.add(new Index.Builder(innsightLog).index("innsight_log").type("log").build());

			if (logLst.size() > 0) {
				Action<BulkResult> bulk = new Bulk.Builder().addAction(logLst).build();
				BulkResult result = client.execute(bulk);
				List<BulkResultItem> bulkResultItems = result.getItems();
				@SuppressWarnings("unused")
				int artiCount = 0;
				for (BulkResultItem bulkResultItem : bulkResultItems) {
					if (!StringUtils.isBlank(bulkResultItem.error)) {
						artiCount++;
						//System.out.println(bulkResultItem.error);
					}
				}
			}
		} catch (Exception exception) {
			log.error(CommonUtils.getCurrentTime()+ " Inside CommonUtils Class insertUserActivityLogs() :: EXCEPTION :: "+ exception);
		}
	}
	
	public static String getFullSourceName(String type) {
		String sourceName = "";
		switch (type) {
		case "tw":
			sourceName = "Twitter";
			break;
		case "fb":
			sourceName = "Facebook";
			break;
		case "yt":
			sourceName = "Youtube";
			break;
		case "insta":
			sourceName = "Instagram";
			break;
		case "dm":
			sourceName = "Daily Motion";
			break;
		case "article":
			sourceName = "Article";
			break;
		
		case "tm":
			sourceName = "Tumblr";
			break;
		default:
			break;
		}
		return sourceName;
	}
	
	public static String getCurrentTime() {
        String timeStamp = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss").format(Calendar.getInstance().getTime());
        return timeStamp;
    }
}