package com.cdac.sudarshan.discover.model;

import java.io.Serializable;
import java.util.ArrayList;

public class Yt_Videos implements Serializable 
{
	private static final long serialVersionUID = 1L;
	private String channelId;
	private String videoId;
	private String playListId;
	private String videoUrl;
	private String title;
	private String description;
	private String thumbnailsMediumUrl;
	private String thumbnailsHighUrl;
	private String channelTitle;
	private String countryCode;
	private String webArticleType;
	private long publishedAt;
	private int viewCount;
	private int likeCount;
	private int dislikeCount;
	private int favoriteCount;
	private int commentCount;
	private int sentiment=9;
	private int commentFlag=0;
	private ArrayList<Integer> entityId;
	private ArrayList<String> tags;
	private ArrayList<Yt_Video_Comment> comment;
	private ArrayList<String> priority;
	
	public String getWebArticleType() {
		return webArticleType;
	}
	public void setWebArticleType(String webArticleType) {
		this.webArticleType = webArticleType;
	}
	public ArrayList<String> getPriority() {
		return priority;
	}
	public void setPriority(ArrayList<String> priority) {
		this.priority = priority;
	}
	public ArrayList<Integer> getEntityId() {
		return entityId;
	}
	public void setEntityId(ArrayList<Integer> entityId) {
		this.entityId = entityId;
	}
	public long getPublishedAt() {
		return publishedAt;
	}
	public void setPublishedAt(long publishedAt) {
		this.publishedAt = publishedAt;
	}
	public ArrayList<String> getTags() {
		return tags;
	}
	public void setTags(ArrayList<String> tags) {
		this.tags = tags;
	}
	public String getChannelId() {
		return channelId;
	}
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
	public String getVideoId() {
		return videoId;
	}
	public void setVideoId(String videoId) {
		this.videoId = videoId;
	}
	public String getPlayListId() {
		return playListId;
	}
	public void setPlayListId(String playListId) {
		this.playListId = playListId;
	}
	public String getVideoUrl() {
		return videoUrl;
	}
	public void setVideoUrl(String videoUrl) {
		this.videoUrl = videoUrl;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getThumbnailsMediumUrl() {
		return thumbnailsMediumUrl;
	}
	public void setThumbnailsMediumUrl(String thumbnailsMediumUrl) {
		this.thumbnailsMediumUrl = thumbnailsMediumUrl;
	}
	public String getThumbnailsHighUrl() {
		return thumbnailsHighUrl;
	}
	public void setThumbnailsHighUrl(String thumbnailsHighUrl) {
		this.thumbnailsHighUrl = thumbnailsHighUrl;
	}
	public String getChannelTitle() {
		return channelTitle;
	}
	public void setChannelTitle(String channelTitle) {
		this.channelTitle = channelTitle;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public int getViewCount() {
		return viewCount;
	}
	public void setViewCount(int viewCount) {
		this.viewCount = viewCount;
	}
	public int getLikeCount() {
		return likeCount;
	}
	public void setLikeCount(int likeCount) {
		this.likeCount = likeCount;
	}
	public int getDislikeCount() {
		return dislikeCount;
	}
	public void setDislikeCount(int dislikeCount) {
		this.dislikeCount = dislikeCount;
	}
	public int getFavoriteCount() {
		return favoriteCount;
	}
	public void setFavoriteCount(int favoriteCount) {
		this.favoriteCount = favoriteCount;
	}
	public int getCommentCount() {
		return commentCount;
	}
	public void setCommentCount(int commentCount) {
		this.commentCount = commentCount;
	}
	public int getSentiment() {
		return sentiment;
	}
	public void setSentiment(int sentiment) {
		this.sentiment = sentiment;
	}
	public int getCommentFlag() {
		return commentFlag;
	}
	public void setCommentFlag(int commentFlag) {
		this.commentFlag = commentFlag;
	}
	public ArrayList<Yt_Video_Comment> getComment() {
		return comment;
	}
	public void setComment(ArrayList<Yt_Video_Comment> comment) {
		this.comment = comment;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "Yt_Videos [entityId=" + entityId + ", publishedAt=" + publishedAt + ", tags=" + tags + ", channelId="
				+ channelId + ", videoId=" + videoId + ", playListId=" + playListId + ", videoUrl=" + videoUrl
				+ ", title=" + title + ", description=" + description + ", thumbnailsMediumUrl=" + thumbnailsMediumUrl
				+ ", thumbnailsHighUrl=" + thumbnailsHighUrl + ", channelTitle=" + channelTitle + ", countryCode="
				+ countryCode + ", viewCount=" + viewCount + ", likeCount=" + likeCount + ", dislikeCount="
				+ dislikeCount + ", favoriteCount=" + favoriteCount + ", commentCount=" + commentCount + ", sentiment="
				+ sentiment + ", commentFlag=" + commentFlag + ", comment=" + comment + ", priority=" + priority
				+ ", webArticleType=" + webArticleType + "]";
	}
	
}
