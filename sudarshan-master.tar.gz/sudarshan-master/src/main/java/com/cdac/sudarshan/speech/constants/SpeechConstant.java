package com.cdac.sudarshan.speech.constants;

public class SpeechConstant {

	
}
