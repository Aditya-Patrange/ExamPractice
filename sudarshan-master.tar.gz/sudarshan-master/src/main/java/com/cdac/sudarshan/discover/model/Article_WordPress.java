package com.cdac.sudarshan.discover.model;

import java.io.Serializable;

public class Article_WordPress implements Serializable 
{
	private static final long serialVersionUID = 1L;
	private String wpPostImage;
	private String wpPostOriUser;

	public String getWpPostImage() {
		return wpPostImage;
	}

	public void setWpPostImage(String wpPostImage) {
		this.wpPostImage = wpPostImage;
	}

	public String getWpPostOriUser() {
		return wpPostOriUser;
	}

	public void setWpPostOriUser(String wpPostOriUser) {
		this.wpPostOriUser = wpPostOriUser;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "Article_WordPress [wpPostImage=" + wpPostImage + ", wpPostOriUser=" + wpPostOriUser + "]";
	}
}
