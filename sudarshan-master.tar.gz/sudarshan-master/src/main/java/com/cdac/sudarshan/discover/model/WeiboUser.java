package com.cdac.sudarshan.discover.model;

import java.io.Serializable;
import java.sql.Date;

public class WeiboUser implements Serializable
{
	private static final long serialVersionUID = 1L;
	private String screenName;
	private String name;
	private String city;
	private String location;
	private String description;
	private String url;
	private String gender;
	private String bannerImage;
	private String bannerImageLocal;
	private long followersCount;
	private long friendsCount;
	private long pagefriendsCount;
	private long statusesCount;
	private long videoStatusCount;
	private long favouritesCount;
	private long userCreatedAt;
	private boolean verified;
	
	
	public String getScreenName() {
		return screenName;
	}
	public void setScreenName(String screenName) {
		this.screenName = screenName;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getBannerImage() {
		return bannerImage;
	}
	public void setBannerImage(String bannerImage) {
		this.bannerImage = bannerImage;
	}
	public String getBannerImageLocal() {
		return bannerImageLocal;
	}
	public void setBannerImageLocal(String bannerImageLocal) {
		this.bannerImageLocal = bannerImageLocal;
	}
	public long getFollowersCount() {
		return followersCount;
	}
	public void setFollowersCount(long followersCount) {
		this.followersCount = followersCount;
	}
	public long getFriendsCount() {
		return friendsCount;
	}
	public void setFriendsCount(long friendsCount) {
		this.friendsCount = friendsCount;
	}
	public long getPagefriendsCount() {
		return pagefriendsCount;
	}
	public void setPagefriendsCount(long pagefriendsCount) {
		this.pagefriendsCount = pagefriendsCount;
	}
	public long getStatusesCount() {
		return statusesCount;
	}
	public void setStatusesCount(long statusesCount) {
		this.statusesCount = statusesCount;
	}
	public long getVideoStatusCount() {
		return videoStatusCount;
	}
	public void setVideoStatusCount(long videoStatusCount) {
		this.videoStatusCount = videoStatusCount;
	}
	public long getFavouritesCount() {
		return favouritesCount;
	}
	public void setFavouritesCount(long favouritesCount) {
		this.favouritesCount = favouritesCount;
	}
	public boolean isVerified() {
		return verified;
	}
	public void setVerified(boolean verified) {
		this.verified = verified;
	}
	public long getUserCreatedAt() {
		return userCreatedAt;
	}
	public void setUserCreatedAt(long userCreatedAt) {
		this.userCreatedAt = userCreatedAt;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "WeiboUser [screenName=" + screenName + ", name=" + name + ", city=" + city + ", location=" + location
				+ ", description=" + description + ", url=" + url + ", gender=" + gender + ", bannerImage="
				+ bannerImage + ", bannerImageLocal=" + bannerImageLocal + ", followersCount=" + followersCount
				+ ", friendsCount=" + friendsCount + ", pagefriendsCount=" + pagefriendsCount + ", statusesCount="
				+ statusesCount + ", videoStatusCount=" + videoStatusCount + ", favouritesCount=" + favouritesCount
				+ ", verified=" + verified + ", userCreatedAt=" + userCreatedAt + "]";
	}
}
