package com.cdac.sudarshan.discover.model;

/**
 * Created by kenny on 7/1/14.
 */
public interface Normalizer {
    String normalize(String text);
}
