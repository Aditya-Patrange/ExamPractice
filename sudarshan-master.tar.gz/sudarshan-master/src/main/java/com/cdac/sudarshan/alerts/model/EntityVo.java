package com.cdac.sudarshan.alerts.model;

import java.util.ArrayList;

public class EntityVo
{
    private String entityName;
    private String entitySocialId;
    private String entityScreenName;
    private String entityStats;
    private String entityType;
    private String entitySourceType;
    private String entityUrl;
    private String varifiedUserFlag;
    private String id;
    private String dateFrom;
    private String dateTo;
    private String dateOfCreation;
    private String entityImg;
    private String entityLocalImg;
    private String activationFlag;
    private String suspendedFlag;
    private String snapshotId;
    private String caseName;
    private String caseId;
    private String caseType;
    private String twId;
    private String ytType;
    private String fbType;
    private String twType;
    private ArrayList<String> lstEntityId;
    private String actType;
    private String pro;
    private String proFlag;
    private String searchText;
    private int targetProfileId;
    private int targetOrganizationId;
    private int socialAccountId;
    private String profileCategoryId;
    private String profileCountryId;
    private String countryCode;
    private String filter;
    private String latitude;
    private String longitude;
    private String radius;
    private String deactivateKeywordAfter;
    private ArrayList<String> lstsocialMediaAccount;
    private int fbDelta;
    private String placeName;
    private String keyword;

    public String getEntityScreenName() {
        return entityScreenName;
    }
    public void setEntityScreenName(String entityScreenName) {
        this.entityScreenName = entityScreenName;
    }
    public String getEntityLocalImg() {
        return entityLocalImg;
    }
    public void setEntityLocalImg(String entityLocalImg) {
        this.entityLocalImg = entityLocalImg;
    }
    public String getDeactivateKeywordAfter() {
        return deactivateKeywordAfter;
    }
    public void setDeactivateKeywordAfter(String deactivateKeywordAfter) {
        this.deactivateKeywordAfter = deactivateKeywordAfter;
    }
    public String getCountryCode() {
        return countryCode;
    }
    public String getDateFrom() {
        return dateFrom;
    }
    public void setDateFrom(String dateFrom) {
        this.dateFrom = dateFrom;
    }
    public String getDateTo() {
        return dateTo;
    }
    public void setDateTo(String dateTo) {
        this.dateTo = dateTo;
    }
    public String getKeyword() {
        return keyword;
    }
    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }
    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }
    public String getFilter() {
        return filter;
    }
    public void setFilter(String filter) {
        this.filter = filter;
    }
    public String getLatitude() {
        return latitude;
    }
    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }
    public String getLongitude() {
        return longitude;
    }
    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }
    public String getRadius() {
        return radius;
    }
    public void setRadius(String radius) {
        this.radius = radius;
    }
    public String getProfileCountryId() {
        return profileCountryId;
    }
    public void setProfileCountryId(String profileCountryId) {
        this.profileCountryId = profileCountryId;
    }
    public String getProfileCategoryId() {
        return profileCategoryId;
    }
    public void setProfileCategoryId(String profileCategoryId) {
        this.profileCategoryId = profileCategoryId;
    }
    public String getSnapshotId() {
        return snapshotId;
    }
    public void setSnapshotId(String snapshotId) {
        this.snapshotId = snapshotId;
    }
    public String getSearchText() {
        return searchText;
    }
    public void setSearchText(String searchText) {
        this.searchText = searchText;
    }
    public String getProFlag() {
        return proFlag;
    }
    public void setProFlag(String proFlag) {
        this.proFlag = proFlag;
    }
    public String getPro() {
        return pro;
    }
    public void setPro(String pro) {
        this.pro = pro;
    }
    public String getActType() {
        return actType;
    }
    public void setActType(String actType) {
        this.actType = actType;
    }
    public ArrayList<String> getLstEntityId() {
        return lstEntityId;
    }
    public void setLstEntityId(ArrayList<String> lstEntityId) {
        this.lstEntityId = lstEntityId;
    }
    public String getFbType() {
        return fbType;
    }
    public void setFbType(String fbType) {
        this.fbType = fbType;
    }
    public String getTwType() {
        return twType;
    }
    public void setTwType(String twType) {
        this.twType = twType;
    }
    public String getYtType() {
        return ytType;
    }
    public void setYtType(String ytType) {
        this.ytType = ytType;
    }
    public String getActivationFlag() {
        return activationFlag;
    }
    public void setActivationFlag(String activationFlag) {
        this.activationFlag = activationFlag;
    }
    public String getSuspendedFlag() {
        return suspendedFlag;
    }
    public void setSuspendedFlag(String suspendedFlag) {
        this.suspendedFlag = suspendedFlag;
    }
    public String getTwId() {
        return twId;
    }
    public void setTwId(String twId) {
        this.twId = twId;
    }
    public String getEntityImg() {
        return entityImg;
    }
    public void setEntityImg(String entityImg) {
        this.entityImg = entityImg;
    }
    public String getCaseName() {
        return caseName;
    }
    public void setCaseName(String caseName) {
        this.caseName = caseName;
    }
    public String getCaseId() {
        return caseId;
    }
    public void setCaseId(String caseId) {
        this.caseId = caseId;
    }
    public String getCaseType() {
        return caseType;
    }
    public void setCaseType(String caseType) {
        this.caseType = caseType;
    }
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getDateOfCreation() {
        return dateOfCreation;
    }
    public void setDateOfCreation(String dateOfCreation) {
        this.dateOfCreation = dateOfCreation;
    }
    public String getEntityName() {
        return entityName;
    }
    public void setEntityName(String entityName) {
        this.entityName = entityName;
    }
    public String getEntitySocialId() {
        return entitySocialId;
    }
    public void setEntitySocialId(String entitySocialId) {
        this.entitySocialId = entitySocialId;
    }
    public String getEntityStats() {
        return entityStats;
    }
    public void setEntityStats(String entityStats) {
        this.entityStats = entityStats;
    }
    public String getEntityType() {
        return entityType;
    }
    public void setEntityType(String entityType) {
        this.entityType = entityType;
    }
    public String getEntitySourceType() {
        return entitySourceType;
    }
    public void setEntitySourceType(String entitySourceType) {
        this.entitySourceType = entitySourceType;
    }
    public String getEntityUrl() {
        return entityUrl;
    }
    public void setEntityUrl(String entityUrl) {
        this.entityUrl = entityUrl;
    }
    public String getVarifiedUserFlag() {
        return varifiedUserFlag;
    }
    public void setVarifiedUserFlag(String varifiedUserFlag) {
        this.varifiedUserFlag = varifiedUserFlag;
    }
    public int getTargetProfileId() {
        return targetProfileId;
    }
    public void setTargetProfileId(int targetProfileId) {
        this.targetProfileId = targetProfileId;
    }
    public int getTargetOrganizationId() {
        return targetOrganizationId;
    }
    public void setTargetOrganizationId(int targetOrganizationId) {
        this.targetOrganizationId = targetOrganizationId;
    }
    public int getSocialAccountId() {
        return socialAccountId;
    }
    public void setSocialAccountId(int socialAccountId) {
        this.socialAccountId = socialAccountId;
    }
    public ArrayList<String> getLstsocialMediaAccount() {
        return lstsocialMediaAccount;
    }
    public void setLstsocialMediaAccount(ArrayList<String> lstsocialMediaAccount) {
        this.lstsocialMediaAccount = lstsocialMediaAccount;
    }
    public int getFbDelta() {
        return fbDelta;
    }
    public void setFbDelta(int fbDelta) {
        this.fbDelta = fbDelta;
    }
    public String getPlaceName() {
        return placeName;
    }
    public void setPlaceName(String placeName) {
        this.placeName = placeName;
    }

    public EntityVo()
    {}

    public EntityVo(String entityName, String entitySocialId, String entityStats, String entityType,
                    String entitySourceType, String entityUrl, String id, String dateOfCreation, String entityImg,
                    String twId, String fbType, String activationFlag, String suspendedFlag, String proFlag,
                    int fbDelta, String placeName, String twType, String varifiedUserFlag)
    {
        super();
        this.entityName = entityName;
        this.entitySocialId = entitySocialId;
        this.entityStats = entityStats;
        this.entityType = entityType;
        this.entitySourceType = entitySourceType;
        this.entityUrl = entityUrl;
        this.id = id;
        this.dateOfCreation = dateOfCreation;
        this.entityImg = entityImg;
        this.twId=twId;
        this.fbType=fbType;
        this.activationFlag = activationFlag;
        this.suspendedFlag = suspendedFlag;
        this.proFlag = proFlag;
        this.fbDelta = fbDelta;
        this.placeName = placeName;
        this.twType = twType;
        this.varifiedUserFlag = varifiedUserFlag;
    }
}