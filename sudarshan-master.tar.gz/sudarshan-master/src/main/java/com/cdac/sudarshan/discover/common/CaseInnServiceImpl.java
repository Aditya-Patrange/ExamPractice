package com.cdac.sudarshan.discover.common;

import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.NamingException;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

//import com.innefu.innsight.cases.service.CaseInnService;
//import com.innefu.innsight.common.CommonUtils;
//import com.innefu.innsight.common.SoftToken_services;
//import com.innefu.innsight.common.TwitterConstant;

@Service
public class CaseInnServiceImpl implements CaseInnService {
	
	Logger logger = Logger.getRootLogger();

	@Override
	public boolean validateOTP(String username, String otp) {
		boolean status = false;
		try {
			String hostname = TwitterConstant.getTwoFAHostname(); 
			String appId = TwitterConstant.getTwoFAAppId(); 
			String ip = TwitterConstant.getTwoFAIP(); 
//			String tokenType = SoftToken_services.checkAuth(username, appId, hostname, ip); 
						
//			if(tokenType!=null && (tokenType.equalsIgnoreCase("mobileToken") || tokenType.contains("Username does not exist"))) {
//				String validate = SoftToken_services.authenticate(username, appId, otp, hostname, ip);
//				if(validate.equals("true")) {
//					status = true;
//				} else {
//					status = false;
//				}
//			} else {
//				status = false;
//			}
		} catch (Exception exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnServiceImpl Class validateOTP() :: EXCEPTION :: UserId  :: "+ username  +":: "+ exception);
		}
		return status;
	}

	@Override
	public boolean validateLDAP(String username, String password, String ldapHostname, String ldapDomainName) {
		boolean status = false;
		try {
			status = authenticateLdapUser(username, password, ldapHostname, ldapDomainName);
		} catch (Exception exception) {
			status = false;
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnServiceImpl Class validateLDAP() :: EXCEPTION :: UserId  :: "+ username  +":: "+ exception);
		}
		return status;
	}	
		
	/**
	 * @author Chandan
	 * Commented by Chandan Singh for as properties moved to database
	 */
	
	@SuppressWarnings("unused")
	public boolean authenticateLdapUser(String username, String password, String url, String domain) {
		//String secureLoginSslFlag=new PropertyFileUtility().fetchPropertyFileAttribute("secure.login.ssl.flag");
		//DataBaseUtility.getPropertiesValues().getSecureLoginSslFlag();
		String secureLoginSslFlag="0";
		StringBuffer buffer=new StringBuffer();
		
		String usersContainer = "";
		if(domain.contains(".")&&(domain.indexOf(".")!=-1)) {
			String userContainerArray[]=domain.split("\\.");
			for(int i=0;i<userContainerArray.length;i++) {
			buffer.append("dc=");
				buffer.append(userContainerArray[i]);
				buffer.append(",");
			}
			usersContainer=buffer.toString().substring(0, buffer.toString().length()-1);
		} else {
			usersContainer=domain;
		}
		
		Hashtable<String, String> env = new Hashtable<String, String>();
		env.put(Context.INITIAL_CONTEXT_FACTORY,"com.sun.jndi.ldap.LdapCtxFactory");
		env.put(Context.PROVIDER_URL, "ldap://"+url);

		if(secureLoginSslFlag != null && secureLoginSslFlag.equalsIgnoreCase("1")) {
			env.put(Context.SECURITY_PROTOCOL, "ssl");
	        env.put("java.naming.ldap.factory.socket", "test.DummySSLSocketFactory");
	        env.put(Context.REFERRAL, "follow");
		}
		
		env.put(Context.SECURITY_AUTHENTICATION, "simple");
		env.put(Context.SECURITY_PRINCIPAL,username + "@"+domain);
		env.put(Context.SECURITY_CREDENTIALS, password);
		DirContext ctx = null;
		try {
			ctx = new InitialDirContext(env);
			SearchControls ctls = new SearchControls();
			String[] attrIDs = {"user"};
			ctls.setReturningAttributes(attrIDs);
			ctls.setSearchScope(SearchControls.SUBTREE_SCOPE);
			return true;
		} catch (NamingException exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnServiceImpl Class authenticateLdapUser() :: EXCEPTION :: UserId  :: "+ username  +":: "+ exception);
			return false;
		} finally {
			try {
				ctx.close();
			} catch (Exception exception) {
				logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnServiceImpl Class authenticateLdapUser() :: EXCEPTION :: UserId  :: "+ username  +":: "+ exception);
			}
		}
	}
}