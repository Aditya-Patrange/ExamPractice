package com.cdac.sudarshan.alerts.controller;

import java.util.HashMap;
import java.util.Map;

import com.cdac.sudarshan.alerts.model.CaseVo;
// import com.cdac.sudarshan.watchlist.service.IAvatarService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cdac.sudarshan.alerts.service.IAlertService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

@CrossOrigin("*")
@RestController
@RequestMapping(value = "/alerts", produces = "application/json")
public class AlertsController {

    @Autowired
    private IAlertService alertService;


    @PostMapping("/getAlertsData")
    public ResponseEntity<?> getUrlAndSourceFromEs(@RequestBody Map<String, String> data) throws Exception {
        return ResponseEntity.ok(alertService.getAlertsDataFromEs(data.get("path"), data.get("size")));
//		return null;
    }

    @GetMapping("getAlerts")
    public ResponseEntity<?> getAlerts() {
        //System.out.println("getAlerts...");
        return new ResponseEntity<>(alertService.getAlerts(), HttpStatus.OK);
    }

    @PostMapping("getAlertsByUserId/{id}")
    public ResponseEntity<?> getWatchlistByUser(@PathVariable Long id) {
        return new ResponseEntity<>(alertService.getAlertsByUserID(id), HttpStatus.OK);
    }

    @PostMapping("getAlertsDataFromCollections")
    public ResponseEntity<?> getAlertsDataFromCollections(@RequestBody HashMap<String, Object> data) throws JsonMappingException, JsonProcessingException {
        //System.out.println("getAlertsDataFromCollections called....");
        return new ResponseEntity<>(alertService.getAlertsDataFromCollections(data), HttpStatus.OK);
    }

    @PostMapping("saveAlertsToDB")
    public ResponseEntity<?> saveAlertsToDB(@RequestBody HashMap<String, Object> data) throws Exception {
        //System.out.println("saveAlertsToDB called....");
        return new ResponseEntity<>(alertService.saveAlertsToDB(data), HttpStatus.OK);
    }

    @PostMapping("addUserAlerts")
    public ResponseEntity<?> addUserAlerts(@RequestBody CaseVo data) throws Exception {
        //System.out.println("addUserAlerts called....");
        return new ResponseEntity<>(alertService.addUserAlerts(data), HttpStatus.OK);
    }


    @PostMapping("getAlertDetails")
    public ResponseEntity<?> getAlertDetails(@RequestBody CaseVo data) throws Exception {
        //System.out.println("getAlertDetails called....");
        return new ResponseEntity<>(alertService.getAlertDetails(data), HttpStatus.OK);
    }

    @PostMapping("getAlertCounts")
    public ResponseEntity<?> getAlertCounts(@RequestBody CaseVo data) throws Exception {
        //System.out.println("getAlertCounts called....");
        return new ResponseEntity<>(alertService.getAlertCounts(data), HttpStatus.OK);
    }

    @PostMapping("getAlertByUsersId")
    public ResponseEntity<?> getAlertByUsersId(@RequestBody HashMap<String, Integer> data) throws Exception {
        //System.out.println("getAlertByUsersId called....");
        return new ResponseEntity<>(alertService.getAlertByUsersId(data), HttpStatus.OK);
    }

    @PostMapping("getAlertWorkDaysById")
    public ResponseEntity<?> getAlertWorkDaysById(@RequestBody HashMap<String, Integer> data) throws Exception {
       // System.out.println("getAlertWorkDaysById called....");
        return new ResponseEntity<>(alertService.getAlertWorkDaysById(data), HttpStatus.OK);
    }

    @PostMapping("dltUserAlerts")
    public ResponseEntity<?> dltUserAlerts(@RequestBody HashMap<String, Integer> data) throws Exception {

        return new ResponseEntity<>(alertService.dltUserAlerts(data), HttpStatus.OK);
    }

    //	getAlertByStatusType
    @PostMapping("getAlertByStatusType")
    public ResponseEntity<?> getAlertByStatusType(@RequestBody HashMap<String, String> data) throws Exception {
        //System.out.println("getAlertByStatusType called....");
        return new ResponseEntity<>(alertService.getAlertByStatusType(data), HttpStatus.OK);
    }

//    updateAlertStatusReadByID

    @PostMapping("updateAlertStatusReadByID")
    public ResponseEntity<?> updateAlertStatusReadByID(@RequestBody HashMap<String, Integer> data) throws Exception {
        //System.out.println("updateAlertStatusReadByID called....");
        return new ResponseEntity<>(alertService.updateAlertStatusReadByID(data), HttpStatus.OK);
    }

//    updateAllAlertReadStatus

    @PostMapping("updateAllAlertReadStatus")
    public ResponseEntity<?> updateAllAlertReadStatus() throws Exception {
       // System.out.println("updateAlertStatusReadByID called....");
        return new ResponseEntity<>(alertService.updateAllAlertReadStatus(), HttpStatus.OK);
    }

//    getAlertByUsers
    @PostMapping("getAlertByUsers")
    public ResponseEntity<?> getAlertByUsers(@RequestBody CaseVo data) throws Exception {

        return new ResponseEntity<>(alertService.getAlertByUsers(data), HttpStatus.OK);
    }


    @PostMapping("actDactAlertValue")
    public ResponseEntity<?> actDactAlertValue(@RequestBody CaseVo data) throws Exception {

        return new ResponseEntity<>(alertService.actDactAlertValue(data), HttpStatus.OK);
    }

}