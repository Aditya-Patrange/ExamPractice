package com.cdac.sudarshan.exception;

public class DataAlreadyFoundException extends RuntimeException{


	private String message;

	public DataAlreadyFoundException(String message) {
		super(message);
		this.message=message;
	}

}
