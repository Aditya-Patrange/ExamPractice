package com.cdac.sudarshan.theme.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "sub_themes")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@SequenceGenerator(name="sub_theme_seq", initialValue=10000,allocationSize=1000000)
public class SubTheme {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator="sub_theme_seq")
    private Long id;
    private String subThemePath;
    private Long parentSubThemeId;
    @CreationTimestamp
    private LocalDateTime creationDate;
    @UpdateTimestamp
    private LocalDateTime lastUpdatedDate;
    
    @ManyToOne
    @JoinColumn(name = "theme_id")
    @JsonIgnore
    private Theme theme;

    @OneToMany(mappedBy = "subTheme",cascade = CascadeType.ALL,fetch = FetchType.LAZY)
    @JsonIgnore
    private List<Keyword> dataList = new ArrayList<>();

}
