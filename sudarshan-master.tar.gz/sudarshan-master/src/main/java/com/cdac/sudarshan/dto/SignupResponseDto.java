package com.cdac.sudarshan.dto;

import java.util.HashMap;
import java.util.Map;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Getter
@Setter
public class SignupResponseDto {

    public enum Status {
        OK, USERNAME_TAKEN, WEAK_PASSWORD
    }

    private Status status;

    private String username;

    private String secret;

    private Map<Integer, Object> backUpCode = new HashMap<>();

    public SignupResponseDto(Status status) {
        this(status, null, null, null);
    }


    @Override
    public String toString() {
        return "SignupResponse{" +
                "status=" + status +
                ", username='" + username + '\'' +
                ", secret='" + secret + '\'' +
                ", backUpCode=" + backUpCode +
                '}';
    }


    public SignupResponseDto(Status status, String username, String secret) {
        this.status = status;
        this.username = username;
        this.secret = secret;
    }

    public SignupResponseDto(Status status, String username) {
        this.status = status;
        this.username = username;
    }


    public SignupResponseDto(Status status, String username, String secret, Map<Integer, Object> backUpCode) {

        this.status = status;
        this.username = username;
        this.secret = secret;
        this.backUpCode = backUpCode;
    }


}
