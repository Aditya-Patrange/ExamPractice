package com.cdac.sudarshan.collection.trackgeolocation.service;

import java.util.Arrays;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
@Service
public class TrackGeoLocationService implements ITrackGeoLocation{
	private RestTemplate template;
	
	@Value("${innefuGeoLocation}")
	private String innefuGeoLocation;

	
	
	
	public TrackGeoLocationService() {
		template = new RestTemplate();
	}
	@SuppressWarnings("unchecked")
	@Override
	public ResponseEntity<?> trackGeoLocation(HashMap<String, Object> data) {
		
		HttpHeaders header = new HttpHeaders();
		header.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		header.setContentType(MediaType.APPLICATION_JSON);
		
		HashMap<String, Object> pauseSearch = (HashMap<String,Object>)data.get("geoTweetsLatLong");
		

		HttpEntity<Object> pauseEntity = new HttpEntity<>(pauseSearch,header);
		
		return template.exchange(innefuGeoLocation +"geoTweetsLatLong", HttpMethod.POST,pauseEntity,Object.class);
		
	}
}
