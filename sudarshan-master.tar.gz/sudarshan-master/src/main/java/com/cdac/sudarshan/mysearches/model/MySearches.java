package com.cdac.sudarshan.mysearches.model;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "mysearches")
@Getter
@Setter
@AllArgsConstructor
@ToString
@NoArgsConstructor
public class MySearches {
	@Id
	@GeneratedValue
	private int id;
	@Column
	private Long userId;
	@Column
	private String keyword;
	@Column
	private String source;
	@Column
	@CreationTimestamp
	private LocalDateTime creationDate;

	private LocalDate startDate;
	
	private LocalDate endDate;
	@Column
	private String searchType;
	@Column
	private String sentiment;
	@Column
	private String sourceTypeSearch;
	@Column
	@JsonIgnore
	private boolean deleteFlag = true;

}
