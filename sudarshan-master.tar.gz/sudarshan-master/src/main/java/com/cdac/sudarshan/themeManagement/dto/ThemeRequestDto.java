package com.cdac.sudarshan.themeManagement.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ThemeRequestDto {
    @NotBlank(message = "Theme name can not be empty.")
    private String themeName;
    @JsonProperty("parentThemeId")
    @NotNull(message = "Theme ID can not be empty.")
    private String parentThemeId;
    private Long userId;
}
