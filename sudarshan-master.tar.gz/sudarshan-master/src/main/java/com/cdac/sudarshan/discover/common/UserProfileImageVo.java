package com.cdac.sudarshan.discover.common;

import java.io.Serializable;
import java.util.Arrays;

public class UserProfileImageVo implements Serializable
{
	private static final long serialVersionUID = 1L;
	
	private int imageId;
	private byte[] profileImage;
	private int status;
	
	public int getImageId() 
	{
		return imageId;
	}
	public void setImageId(int imageId) 
	{
		this.imageId = imageId;
	}
	public byte[] getProfileImage() 
	{
		return profileImage;
	}
	public void setProfileImage(byte[] profileImage)
	{
		this.profileImage = profileImage;
	}
	public int getStatus() 
	{
		return status;
	}
	public void setStatus(int status) 
	{
		this.status = status;
	}
	public static long getSerialversionuid()
	{
		return serialVersionUID;
	}
	
	@Override
	public String toString() 
	{
		return "UserProfileImageVo [imageId=" + imageId + ", profileImage=" + Arrays.toString(profileImage)
				+ ", status=" + status + "]";
	}
	
}
