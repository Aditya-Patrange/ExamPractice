package com.cdac.sudarshan.discover.model;

import java.io.Serializable;
import java.util.ArrayList;

public class Article_Instagram implements Serializable 
{
	private static final long serialVersionUID = 1L;
	private int instaPostCommentCount;
	private int instaPostLikeCount;
	private String instaThumbnailLink;
	private ArrayList<Article_Insta_User> instaLikeUser;

	public String getInstaThumbnailLink() {
		return instaThumbnailLink;
	}

	public void setInstaThumbnailLink(String instaThumbnailLink) {
		this.instaThumbnailLink = instaThumbnailLink;
	}

	public ArrayList<Article_Insta_User> getInstaLikeUser() {
		return instaLikeUser;
	}

	public void setInstaLikeUser(ArrayList<Article_Insta_User> instaLikeUser) {
		this.instaLikeUser = instaLikeUser;
	}

	public int getInstaPostCommentCount() {
		return instaPostCommentCount;
	}

	public void setInstaPostCommentCount(int instaPostCommentCount) {
		this.instaPostCommentCount = instaPostCommentCount;
	}

	public int getInstaPostLikeCount() {
		return instaPostLikeCount;
	}

	public void setInstaPostLikeCount(int instaPostLikeCount) {
		this.instaPostLikeCount = instaPostLikeCount;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "Article_Instagram [instaPostCommentCount=" + instaPostCommentCount + ", instaPostLikeCount="
				+ instaPostLikeCount + ", instaThumbnailLink=" + instaThumbnailLink + ", instaLikeUser=" + instaLikeUser
				+ "]";
	}

}
