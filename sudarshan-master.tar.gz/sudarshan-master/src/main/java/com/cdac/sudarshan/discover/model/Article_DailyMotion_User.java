package com.cdac.sudarshan.discover.model;

import java.io.Serializable;

public class Article_DailyMotion_User implements Serializable 
{
	private static final long serialVersionUID = 1L;
	private String ownerId;
	private String ownerActive;
	private String ownerAvatarUrl;
	private String ownerCity;
	private String ownerCountry;
	private String ownerCover;
	private String ownerDescription;
	private String ownerFacebookUrl;
	private String ownerGooglePlusUrl;
	private String ownerInstagramUrl;
	private String ownerLinkdenUrl;
	private String ownerLanguage;
	private String ownerScreenName;
	private String ownerTwitterUrl;
	private String ownerUrl;
	private String ownerUserName;
	private String ownerWebsiteUrl;
	private String ownerGender;
	private long ownerCreatedTime;
	private long ownerFollowersTotal;
	private long ownerFollowingTotal;
	private long ownerVideosTotal;
	private long ownerViewsTotal;
	
	public String getOwnerActive() {
		return ownerActive;
	}
	public void setOwnerActive(String ownerActive) {
		this.ownerActive = ownerActive;
	}
	public String getOwnerAvatarUrl() {
		return ownerAvatarUrl;
	}
	public void setOwnerAvatarUrl(String ownerAvatarUrl) {
		this.ownerAvatarUrl = ownerAvatarUrl;
	}
	public String getOwnerCity() {
		return ownerCity;
	}
	public void setOwnerCity(String ownerCity) {
		this.ownerCity = ownerCity;
	}
	public String getOwnerCountry() {
		return ownerCountry;
	}
	public void setOwnerCountry(String ownerCountry) {
		this.ownerCountry = ownerCountry;
	}
	public String getOwnerCover() {
		return ownerCover;
	}
	public void setOwnerCover(String ownerCover) {
		this.ownerCover = ownerCover;
	}
	public String getOwnerDescription() {
		return ownerDescription;
	}
	public void setOwnerDescription(String ownerDescription) {
		this.ownerDescription = ownerDescription;
	}
	public String getOwnerFacebookUrl() {
		return ownerFacebookUrl;
	}
	public void setOwnerFacebookUrl(String ownerFacebookUrl) {
		this.ownerFacebookUrl = ownerFacebookUrl;
	}
	public String getOwnerGooglePlusUrl() {
		return ownerGooglePlusUrl;
	}
	public void setOwnerGooglePlusUrl(String ownerGooglePlusUrl) {
		this.ownerGooglePlusUrl = ownerGooglePlusUrl;
	}
	public String getOwnerInstagramUrl() {
		return ownerInstagramUrl;
	}
	public void setOwnerInstagramUrl(String ownerInstagramUrl) {
		this.ownerInstagramUrl = ownerInstagramUrl;
	}
	public String getOwnerLinkdenUrl() {
		return ownerLinkdenUrl;
	}
	public void setOwnerLinkdenUrl(String ownerLinkdenUrl) {
		this.ownerLinkdenUrl = ownerLinkdenUrl;
	}
	public String getOwnerLanguage() {
		return ownerLanguage;
	}
	public void setOwnerLanguage(String ownerLanguage) {
		this.ownerLanguage = ownerLanguage;
	}
	public String getOwnerScreenName() {
		return ownerScreenName;
	}
	public void setOwnerScreenName(String ownerScreenName) {
		this.ownerScreenName = ownerScreenName;
	}
	public String getOwnerTwitterUrl() {
		return ownerTwitterUrl;
	}
	public void setOwnerTwitterUrl(String ownerTwitterUrl) {
		this.ownerTwitterUrl = ownerTwitterUrl;
	}
	public String getOwnerUrl() {
		return ownerUrl;
	}
	public void setOwnerUrl(String ownerUrl) {
		this.ownerUrl = ownerUrl;
	}
	public String getOwnerUserName() {
		return ownerUserName;
	}
	public void setOwnerUserName(String ownerUserName) {
		this.ownerUserName = ownerUserName;
	}
	public String getOwnerWebsiteUrl() {
		return ownerWebsiteUrl;
	}
	public void setOwnerWebsiteUrl(String ownerWebsiteUrl) {
		this.ownerWebsiteUrl = ownerWebsiteUrl;
	}
	public String getOwnerGender() {
		return ownerGender;
	}
	public void setOwnerGender(String ownerGender) {
		this.ownerGender = ownerGender;
	}
	public long getOwnerCreatedTime() {
		return ownerCreatedTime;
	}
	public void setOwnerCreatedTime(long ownerCreatedTime) {
		this.ownerCreatedTime = ownerCreatedTime;
	}
	public long getOwnerFollowersTotal() {
		return ownerFollowersTotal;
	}
	public void setOwnerFollowersTotal(long ownerFollowersTotal) {
		this.ownerFollowersTotal = ownerFollowersTotal;
	}
	public long getOwnerFollowingTotal() {
		return ownerFollowingTotal;
	}
	public void setOwnerFollowingTotal(long ownerFollowingTotal) {
		this.ownerFollowingTotal = ownerFollowingTotal;
	}
	public long getOwnerVideosTotal() {
		return ownerVideosTotal;
	}
	public void setOwnerVideosTotal(long ownerVideosTotal) {
		this.ownerVideosTotal = ownerVideosTotal;
	}
	public long getOwnerViewsTotal() {
		return ownerViewsTotal;
	}
	public void setOwnerViewsTotal(long ownerViewsTotal) {
		this.ownerViewsTotal = ownerViewsTotal;
	}
	public String getOwnerId() {
		return ownerId;
	}
	public void setOwnerId(String ownerId) {
		this.ownerId = ownerId;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "Article_DailyMotion_User [ownerId=" + ownerId + ", ownerActive=" + ownerActive + ", ownerAvatarUrl="
				+ ownerAvatarUrl + ", ownerCity=" + ownerCity + ", ownerCountry=" + ownerCountry + ", ownerCover="
				+ ownerCover + ", ownerDescription=" + ownerDescription + ", ownerFacebookUrl=" + ownerFacebookUrl
				+ ", ownerGooglePlusUrl=" + ownerGooglePlusUrl + ", ownerInstagramUrl=" + ownerInstagramUrl
				+ ", ownerLinkdenUrl=" + ownerLinkdenUrl + ", ownerLanguage=" + ownerLanguage + ", ownerScreenName="
				+ ownerScreenName + ", ownerTwitterUrl=" + ownerTwitterUrl + ", ownerUrl=" + ownerUrl
				+ ", ownerUserName=" + ownerUserName + ", ownerWebsiteUrl=" + ownerWebsiteUrl + ", ownerGender="
				+ ownerGender + ", ownerCreatedTime=" + ownerCreatedTime + ", ownerFollowersTotal="
				+ ownerFollowersTotal + ", ownerFollowingTotal=" + ownerFollowingTotal + ", ownerVideosTotal="
				+ ownerVideosTotal + ", ownerViewsTotal=" + ownerViewsTotal + "]";
	}
}
