package com.cdac.sudarshan.discover.common;

import java.io.Serializable;

public class UserProfileAssociatedFriendsVo implements Serializable
{
	private static final long serialVersionUID = 1L;
	
	private int friendsId;
	private int profileId;
	private String friendUserId;
	private String userName;
	private String userScreenName;
	private String classification;
	private String friendPhoto;
	private String socialMediaType;
	
	public int getFriendsId() 
	{
		return friendsId;
	}
	public void setFriendsId(int friendsId) 
	{
		this.friendsId = friendsId;
	}
	public int getProfileId() 
	{
		return profileId;
	}
	public void setProfileId(int profileId) 
	{
		this.profileId = profileId;
	}
	public String getFriendUserId() 
	{
		return friendUserId;
	}
	public void setFriendUserId(String friendUserId) 
	{
		this.friendUserId = friendUserId;
	}
	public String getUserName() 
	{
		return userName;
	}
	public void setUserName(String userName) 
	{
		this.userName = userName;
	}
	public String getUserScreenName() 
	{
		return userScreenName;
	}
	public void setUserScreenName(String userScreenName) 
	{
		this.userScreenName = userScreenName;
	}
	public String getClassification()
	{
		return classification;
	}
	public void setClassification(String classification) 
	{
		this.classification = classification;
	}
	public String getFriendPhoto() 
	{
		return friendPhoto;
	}
	public void setFriendPhoto(String friendPhoto) 
	{
		this.friendPhoto = friendPhoto;
	}
	public String getSocialMediaType() 
	{
		return socialMediaType;
	}
	public void setSocialMediaType(String socialMediaType) 
	{
		this.socialMediaType = socialMediaType;
	}
	public static long getSerialversionuid() 
	{
		return serialVersionUID;
	}
	
	@Override
	public String toString() 
	{
		return "UserProfileAssociatedFriendsVo [friendsId=" + friendsId + ", profileId=" + profileId + ", friendUserId="
				+ friendUserId + ", userName=" + userName + ", userScreenName=" + userScreenName + ", classification="
				+ classification + ", friendPhoto=" + friendPhoto + ", socialMediaType=" + socialMediaType + "]";
	}
	
}
