package com.cdac.sudarshan.discover.common;

public class DashboardExportVo {
	private String element;
	private String html;
	private String image;

	public String getElement() {
		return element;
	}
	public void setElement(String element) {
		this.element = element;
	}
	public String getHtml() {
		return html;
	}
	public void setHtml(String html) {
		this.html = html;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	
	@Override
	public String toString() {
		return "DashboardExportVo [element=" + element + ", html=" + html + ", image=" + image + "]";
	}	
}
