package com.cdac.sudarshan.utils;

import javax.persistence.Embeddable;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.ToString;

@lombok.Data
@Embeddable
@ToString
public class Data {

	private String url;
	private String source;
	private String tag;
	private String profileId;
	private String resourcePath;
	private String imageName;
	private String link;

}
