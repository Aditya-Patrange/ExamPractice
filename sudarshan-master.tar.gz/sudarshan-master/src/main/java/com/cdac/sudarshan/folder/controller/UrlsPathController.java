package com.cdac.sudarshan.folder.controller;

import com.cdac.sudarshan.dto.UrlPathDTO;
import com.cdac.sudarshan.folder.dto.RequestDto;
import com.cdac.sudarshan.folder.dto.UrlResponseDto;
import com.cdac.sudarshan.folder.model.UrlsPath;
import com.cdac.sudarshan.folder.service.IUrlsPathService;
import com.cdac.sudarshan.utils.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@CrossOrigin("*")
@RestController
@RequestMapping("/urlspath")
public class UrlsPathController {

	@Autowired
	private IUrlsPathService urlsPathServiceImpl;

	@PostMapping("/save")
	public ResponseEntity<?> addUrls(@RequestBody UrlPathDTO urlPathDTO) throws Exception {

		Map<Object, Object> response = new HashMap<>();

		List<UrlResponseDto> addUrls = urlsPathServiceImpl.addUrls(urlPathDTO.getPath(), urlPathDTO.getUrlAndSource());
		response.put("List_Of_Url", addUrls);

		if (addUrls.get(0).getDuplicateUrlCount() == addUrls.get(0).getTotalUrlCount()) {
			response.put("statusCode", String.valueOf(HttpStatus.CONFLICT.value()));
			response.put("message", " ALl duplicate urls are found, Please add new Urls");
			return new ResponseEntity<>(response, HttpStatus.CONFLICT);
		} else {
			response.put("statusCode", String.valueOf(HttpStatus.CREATED.value()));
		}

		return new ResponseEntity<>(response, HttpStatus.CREATED);
	}

	@PostMapping("/save-profile")
	public ResponseEntity<?> addProfileUrls(@RequestBody UrlPathDTO urlPathDTO) throws Exception {

		Map<Object, Object> response = new HashMap<>();

		List<UrlResponseDto> addUrls = urlsPathServiceImpl.addProfileUrls(urlPathDTO.getPath(), urlPathDTO.getUrlAndSource());

		response.put("List_Of_Url", addUrls);

		if (addUrls.get(0).getDuplicateUrlCount() == addUrls.get(0).getTotalUrlCount()) {
			response.put("statusCode", String.valueOf(HttpStatus.CONFLICT.value()));
			response.put("message", " ALl duplicate urls are found, Please add new profile");
			return new ResponseEntity<>(response, HttpStatus.CONFLICT);
		} else {
			response.put("statusCode", String.valueOf(HttpStatus.CREATED.value()));
		}

		return new ResponseEntity<>(response, HttpStatus.CREATED);
	}

	@PostMapping("/saveMedia")
	public ResponseEntity<?> addMediaUrls(@RequestBody UrlPathDTO urlPathDTO) throws Exception {

		Map<Object, Object> response = new HashMap<>();
		List<Data> urlAndSource = urlPathDTO.getUrlAndSource();

		List<UrlResponseDto> addUrls = urlsPathServiceImpl.addMediaUrls(urlPathDTO.getPath(), urlAndSource);

		response.put("List_Of_Url", addUrls);

		if (addUrls.get(0).getDuplicateUrlCount() == addUrls.get(0).getTotalUrlCount()) {
			response.put("statusCode", String.valueOf(HttpStatus.CONFLICT.value()));
			response.put("message", " ALl duplicate urls are found, Please add new media");
			return new ResponseEntity<>(response, HttpStatus.CONFLICT);
		} else {
			response.put("statusCode", String.valueOf(HttpStatus.CREATED.value()));
		}

		return new ResponseEntity<>(response, HttpStatus.CREATED);
	}

	@GetMapping("/getBySubfolder/{subFolderId}")
	public ResponseEntity<?> getUrlsBySubfolder(@PathVariable("subFolderId") Long subFolderId) {
		Map<Object, Object> response = new HashMap<>();

		List<UrlsPath> list = urlsPathServiceImpl.getBySubfolderId(subFolderId);
		response.put("List_Of_Url", list);
		response.put("Status Code", HttpStatus.OK.value());
		
		return ResponseEntity.ok(response);
	}

	@DeleteMapping("/deleteUrlData")
	public ResponseEntity<?> deleteUrlsPathData(@RequestBody RequestDto requestDto) {
		Map<Object, Object> response = new HashMap<>();
		return urlsPathServiceImpl.deleteUrlsData(requestDto);
	}



}
