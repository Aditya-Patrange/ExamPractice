package com.cdac.sudarshan.discover.common;

import java.io.Serializable;

public class CaseOutputVo implements Serializable {
	private static final long serialVersionUID = 1L;

}
