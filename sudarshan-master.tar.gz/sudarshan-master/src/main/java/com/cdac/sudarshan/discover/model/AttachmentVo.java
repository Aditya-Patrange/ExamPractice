package com.cdac.sudarshan.discover.model;

import java.io.Serializable;

public class AttachmentVo implements Serializable 
{
	private static final long serialVersionUID = 1L;
	private String attachmentType;
	private String attachmentDisplayName;
	private String attachmentUrl;
	private String attachmentImage;
	private String attachmentContent;

	public String getAttachmentType() {
		return attachmentType;
	}

	public void setAttachmentType(String attachmentType) {
		this.attachmentType = attachmentType;
	}

	public String getAttachmentDisplayName() {
		return attachmentDisplayName;
	}

	public void setAttachmentDisplayName(String attachmentDisplayName) {
		this.attachmentDisplayName = attachmentDisplayName;
	}

	public String getAttachmentUrl() {
		return attachmentUrl;
	}

	public void setAttachmentUrl(String attachmentUrl) {
		this.attachmentUrl = attachmentUrl;
	}

	public String getAttachmentImage() {
		return attachmentImage;
	}

	public void setAttachmentImage(String attachmentImage) {
		this.attachmentImage = attachmentImage;
	}

	public String getAttachmentContent() {
		return attachmentContent;
	}

	public void setAttachmentContent(String attachmentContent) {
		this.attachmentContent = attachmentContent;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "AttachmentVo [attachmentType=" + attachmentType + ", attachmentDisplayName=" + attachmentDisplayName
				+ ", attachmentUrl=" + attachmentUrl + ", attachmentImage=" + attachmentImage + ", attachmentContent="
				+ attachmentContent + "]";
	}
	
}
