package com.cdac.sudarshan.mysearches.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cdac.sudarshan.mysearches.dto.MySearchesProjection;
import com.cdac.sudarshan.mysearches.model.MySearches;


@Repository
public interface MySearchesRepository extends JpaRepository<MySearches, Integer>,PagingAndSortingRepository<MySearches,Integer>{

	List<MySearches> findByUserIdAndDeleteFlag(Long userId,boolean deleteFlag,Pageable pageable);
	@Query("select count(*) from MySearches s where s.userId = :userId")
	public Long sizeCount(@Param(value = "userId")Long userId);
	
	@Query(value = "SELECT \n"
			+ "    keyword \n"
			+ "FROM\n"
			+ "    mysearches\n"
			+ "    WHERE\n"
			+ "    source_type_search= ?1 \n"
			+ "GROUP BY keyword\n"
			+ "ORDER BY count(keyword) DESC\n"
			+ "LIMIT 10\n"
			+ ";", nativeQuery = true)
	public List<MySearchesProjection> mostSearchedKeyword(String sourceTypeSearch);

}
