package com.cdac.sudarshan.discover.common;

import java.io.Serializable;

public class UserProfileSocialAccountVo implements Serializable
{
	private static final long serialVersionUID = 1L;
	
	private int accountId;
	private int profileId;
	private String entityName;
	private String entitySocialId;
	private String entitySourceType;
	private String entityUrl;
	private String entityImg;
	private String twId;
	
	public int getAccountId() 
	{
		return accountId;
	}
	public void setAccountId(int accountId)
	{
		this.accountId = accountId;
	}
	public int getProfileId() 
	{
		return profileId;
	}
	public void setProfileId(int profileId) 
	{
		this.profileId = profileId;
	}
	public String getEntityName()
	{
		return entityName;
	}
	public void setEntityName(String entityName) 
	{
		this.entityName = entityName;
	}
	public String getEntitySocialId() 
	{
		return entitySocialId;
	}
	public void setEntitySocialId(String entitySocialId) 
	{
		this.entitySocialId = entitySocialId;
	}
	public String getEntitySourceType() 
	{
		return entitySourceType;
	}
	public void setEntitySourceType(String entitySourceType)
	{
		this.entitySourceType = entitySourceType;
	}
	public String getEntityUrl() 
	{
		return entityUrl;
	}
	public void setEntityUrl(String entityUrl) 
	{
		this.entityUrl = entityUrl;
	}
	public String getEntityImg()
	{
		return entityImg;
	}
	public void setEntityImg(String entityImg) 
	{
		this.entityImg = entityImg;
	}
	public String getTwId()
	{
		return twId;
	}
	public void setTwId(String twId)
	{
		this.twId = twId;
	}
	public static long getSerialversionuid() 
	{
		return serialVersionUID;
	}
	
	@Override
	public String toString() 
	{
		return "UserProfileSocialAccountVo [accountId=" + accountId + ", profileId=" + profileId + ", entityName="
				+ entityName + ", entitySocialId=" + entitySocialId + ", entitySourceType=" + entitySourceType
				+ ", entityUrl=" + entityUrl + ", entityImg=" + entityImg + ", twId=" + twId + "]";
	}
	
}
