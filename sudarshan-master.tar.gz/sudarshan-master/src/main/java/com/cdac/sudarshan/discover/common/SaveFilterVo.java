package com.cdac.sudarshan.discover.common;

import java.util.ArrayList;

import com.cdac.sudarshan.discover.model.TweeterActionVo;

public class SaveFilterVo
{
	private int id; 
	private int caseId; 
	private int loginId; 
	private int snapShotId;
	private String snapId;
	private String searchName;
	private String globalSearch;
	private String dateSearch;
	private String advanceSearch;
	private String hashtagInclude; 
	private String hashtagExclude;
	private String mentionInclude; 
	private String mentionExclude;
	private String userInclude; 
	private String userExclude;
	private String linkInclude; 
	private String linkExclude;
	private String domainInclude; 
	private String domainExclude;
	private String mapInclude; 
	private String mapExclude;
	private String mapUserInclude; 
	private String mapUserExclude;
	private String videoInclude; 
	private String videoExclude;
	private String imgInclude;
	private String imgExclude;
	private String prsnInclude; 
	private String prsnExclude;
	private String placeInclude; 
	private String placeExclude;
	private String orgInclude; 
	private String orgExclude;
	private String themeInclude; 
	private String themeExclude;
	private String calenderInclude; 
	private String calenderExclude;
	private String articleLocationInclude;
	private String articleLocationExclude;
	private String authorLocationInclude;
	private String authorLocationExclude;
	private String doe;
	private String caseName;
	private String caseType;
	private String mode;
	private boolean isOverWrite;
	private String snapshotName;
	private String description;
	private String dateSorting;
	private String sentimentFilter;
	private String classificationFilter;
	private String threatClassificationFilter;
	private String emotionFilter;
	private String dateFrom;
	private String dateTo;
	private String newsRssCountryFilter;
	private String socialMediaFilter;
	private String hasNewsFeed;
	private String hasWebsite;
	private String hasFTP;
	private String hasSocialMedia;
	private String hasDarkWeb;
	private String darkwebFilter;
	private String threatMatrixFilter;
	private String userStatusFilter;
	private String dateTypeFilter;
	private String hasCustomCrawler;
	private String boolOper;
	private String newsFeedCountrySpecific;
	private ArrayList<EntityVo> lstEntityVos;
	private ArrayList<String> newsSourceList;
	private ArrayList<String> newsWebsiteList;
	private ArrayList<String> newsFTPList;
	private String langInclude; 
	private String langExclude;
	private String odsProfileInclude;
	private String odsProfileExclude;
	private String odsPostInclude; 
	private String odsPostExclude;
	private String ocrPostInclude; 
	private String ocrPostExclude;
	private String retweetUserInclude;
	private String retweetUserExclude;
	private String analysisType;
	private String trackTwKeyword;
	private String locationName;
	private String latitude;
	private String longitude;
	private String radiusInKM;
	private String esQuery;
	private String keywordIds;
	private String filterQuery;
	private ArrayList<String> whatsGroupList;
	private TweeterActionVo tweeterActionVo;
		
	public String getThreatClassificationFilter() {
		return threatClassificationFilter;
	}
	public void setThreatClassificationFilter(String threatClassificationFilter) {
		this.threatClassificationFilter = threatClassificationFilter;
	}
	public TweeterActionVo getTweeterActionVo() {
		return tweeterActionVo;
	}
	public void setTweeterActionVo(TweeterActionVo tweeterActionVo) {
		this.tweeterActionVo = tweeterActionVo;
	}
	public String getFilterQuery() {
		return filterQuery;
	}
	public void setFilterQuery(String filterQuery) {
		this.filterQuery = filterQuery;
	}
	public String getEsQuery() {
		return esQuery;
	}
	public void setEsQuery(String esQuery) {
		this.esQuery = esQuery;
	}
	public String getKeywordIds() {
		return keywordIds;
	}
	public void setKeywordIds(String keywordIds) {
		this.keywordIds = keywordIds;
	}
	public String getSnapId() {
		return snapId;
	}
	public void setSnapId(String snapId) {
		this.snapId = snapId;
	}
	public String getHasWebsite() {
		return hasWebsite;
	}
	public void setHasWebsite(String hasWebsite) {
		this.hasWebsite = hasWebsite;
	}
	public String getHasFTP() {
		return hasFTP;
	}
	public void setHasFTP(String hasFTP) {
		this.hasFTP = hasFTP;
	}
	public ArrayList<String> getNewsFTPList() {
		return newsFTPList;
	}
	public void setNewsFTPList(ArrayList<String> newsFTPList) {
		this.newsFTPList = newsFTPList;
	}
	public ArrayList<String> getNewsWebsiteList() {
		return newsWebsiteList;
	}
	public void setNewsWebsiteList(ArrayList<String> newsWebsiteList) {
		this.newsWebsiteList = newsWebsiteList;
	}
	public String getCalenderInclude() {
		return calenderInclude;
	}
	public void setCalenderInclude(String calenderInclude) {
		this.calenderInclude = calenderInclude;
	}
	public String getCalenderExclude() {
		return calenderExclude;
	}
	public void setCalenderExclude(String calenderExclude) {
		this.calenderExclude = calenderExclude;
	}
	public String getDateTypeFilter() {
		return dateTypeFilter;
	}
	public void setDateTypeFilter(String dateTypeFilter) {
		this.dateTypeFilter = dateTypeFilter;
	}
	public String getThemeInclude() {
		return themeInclude;
	}
	public void setThemeInclude(String themeInclude) {
		this.themeInclude = themeInclude;
	}
	public String getThemeExclude() {
		return themeExclude;
	}
	public void setThemeExclude(String themeExclude) {
		this.themeExclude = themeExclude;
	}
	public String getArticleLocationInclude() {
		return articleLocationInclude;
	}
	public void setArticleLocationInclude(String articleLocationInclude) {
		this.articleLocationInclude = articleLocationInclude;
	}
	public String getArticleLocationExclude() {
		return articleLocationExclude;
	}
	public void setArticleLocationExclude(String articleLocationExclude) {
		this.articleLocationExclude = articleLocationExclude;
	}
	public String getAuthorLocationInclude() {
		return authorLocationInclude;
	}
	public void setAuthorLocationInclude(String authorLocationInclude) {
		this.authorLocationInclude = authorLocationInclude;
	}
	public String getAuthorLocationExclude() {
		return authorLocationExclude;
	}
	public void setAuthorLocationExclude(String authorLocationExclude) {
		this.authorLocationExclude = authorLocationExclude;
	}
	public String getDomainInclude() {
		return domainInclude;
	}
	public void setDomainInclude(String domainInclude) {
		this.domainInclude = domainInclude;
	}
	public String getDomainExclude() {
		return domainExclude;
	}
	public void setDomainExclude(String domainExclude) {
		this.domainExclude = domainExclude;
	}
	public String getRetweetUserInclude() {
		return retweetUserInclude;
	}
	public void setRetweetUserInclude(String retweetUserInclude) {
		this.retweetUserInclude = retweetUserInclude;
	}
	public String getRetweetUserExclude() {
		return retweetUserExclude;
	}
	public void setRetweetUserExclude(String retweetUserExclude) {
		this.retweetUserExclude = retweetUserExclude;
	}
	public String getAnalysisType() {
		return analysisType;
	}
	public void setAnalysisType(String analysisType) {
		this.analysisType = analysisType;
	}
	public String getTrackTwKeyword() {
		return trackTwKeyword;
	}
	public void setTrackTwKeyword(String trackTwKeyword) {
		this.trackTwKeyword = trackTwKeyword;
	}
	public String getLocationName() {
		return locationName;
	}
	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}
	public String getLatitude() {
		return latitude;
	}
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}
	public String getLongitude() {
		return longitude;
	}
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}
	public String getRadiusInKM() {
		return radiusInKM;
	}
	public void setRadiusInKM(String radiusInKM) {
		this.radiusInKM = radiusInKM;
	}
	public String getOdsProfileInclude() {
		return odsProfileInclude;
	}
	public void setOdsProfileInclude(String odsProfileInclude) {
		this.odsProfileInclude = odsProfileInclude;
	}
	public String getOdsProfileExclude() {
		return odsProfileExclude;
	}
	public void setOdsProfileExclude(String odsProfileExclude) {
		this.odsProfileExclude = odsProfileExclude;
	}
	public String getOdsPostInclude() {
		return odsPostInclude;
	}
	public void setOdsPostInclude(String odsPostInclude) {
		this.odsPostInclude = odsPostInclude;
	}
	public String getOdsPostExclude() {
		return odsPostExclude;
	}
	public void setOdsPostExclude(String odsPostExclude) {
		this.odsPostExclude = odsPostExclude;
	}
	public String getOcrPostInclude() {
		return ocrPostInclude;
	}
	public void setOcrPostInclude(String ocrPostInclude) {
		this.ocrPostInclude = ocrPostInclude;
	}
	public String getOcrPostExclude() {
		return ocrPostExclude;
	}
	public void setOcrPostExclude(String ocrPostExclude) {
		this.ocrPostExclude = ocrPostExclude;
	}
	public String getLangInclude() {
		return langInclude;
	}
	public void setLangInclude(String langInclude) {
		this.langInclude = langInclude;
	}
	public String getLangExclude() {
		return langExclude;
	}
	public void setLangExclude(String langExclude) {
		this.langExclude = langExclude;
	}
	public String getCaseName() {
		return caseName;
	}
	public void setCaseName(String caseName) {
		this.caseName = caseName;
	}
	public String getCaseType() {
		return caseType;
	}
	public void setCaseType(String caseType) {
		this.caseType = caseType;
	}
	public String getOrgInclude() {
		return orgInclude;
	}
	public void setOrgInclude(String orgInclude) {
		this.orgInclude = orgInclude;
	}
	public String getOrgExclude() {
		return orgExclude;
	}
	public void setOrgExclude(String orgExclude) {
		this.orgExclude = orgExclude;
	}
	public String getPrsnInclude() {
		return prsnInclude;
	}
	public void setPrsnInclude(String prsnInclude) {
		this.prsnInclude = prsnInclude;
	}
	public String getPrsnExclude() {
		return prsnExclude;
	}
	public void setPrsnExclude(String prsnExclude) {
		this.prsnExclude = prsnExclude;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getCaseId() {
		return caseId;
	}
	public void setCaseId(int caseId) {
		this.caseId = caseId;
	}
	public int getLoginId() {
		return loginId;
	}
	public void setLoginId(int loginId) {
		this.loginId = loginId;
	}
	public String getSearchName() {
		return searchName;
	}
	public void setSearchName(String searchName) {
		this.searchName = searchName;
	}
	public String getGlobalSearch() {
		return globalSearch;
	}
	public void setGlobalSearch(String globalSearch) {
		this.globalSearch = globalSearch;
	}
	public String getDateSearch() {
		return dateSearch;
	}
	public void setDateSearch(String dateSearch) {
		this.dateSearch = dateSearch;
	}
	public String getAdvanceSearch() {
		return advanceSearch;
	}
	public void setAdvanceSearch(String advanceSearch) {
		this.advanceSearch = advanceSearch;
	}
	public String getHashtagInclude() {
		return hashtagInclude;
	}
	public void setHashtagInclude(String hashtagInclude) {
		this.hashtagInclude = hashtagInclude;
	}
	public String getHashtagExclude() {
		return hashtagExclude;
	}
	public void setHashtagExclude(String hashtagExclude) {
		this.hashtagExclude = hashtagExclude;
	}
	public String getUserInclude() {
		return userInclude;
	}
	public void setUserInclude(String userInclude) {
		this.userInclude = userInclude;
	}
	public String getUserExclude() {
		return userExclude;
	}
	public void setUserExclude(String userExclude) {
		this.userExclude = userExclude;
	}
	public String getMentionInclude() {
		return mentionInclude;
	}
	public void setMentionInclude(String mentionInclude) {
		this.mentionInclude = mentionInclude;
	}
	public String getMentionExclude() {
		return mentionExclude;
	}
	public void setMentionExclude(String mentionExclude) {
		this.mentionExclude = mentionExclude;
	}
	public String getLinkInclude() {
		return linkInclude;
	}
	public void setLinkInclude(String linkInclude) {
		this.linkInclude = linkInclude;
	}
	public String getLinkExclude() {
		return linkExclude;
	}
	public void setLinkExclude(String linkExclude) {
		this.linkExclude = linkExclude;
	}
	public String getPlaceInclude() {
		return placeInclude;
	}
	public void setPlaceInclude(String placeInclude) {
		this.placeInclude = placeInclude;
	}
	public String getPlaceExclude() {
		return placeExclude;
	}
	public void setPlaceExclude(String placeExclude) {
		this.placeExclude = placeExclude;
	}
	public String getMapInclude() {
		return mapInclude;
	}
	public void setMapInclude(String mapInclude) {
		this.mapInclude = mapInclude;
	}
	public String getMapUserInclude() {
		return mapUserInclude;
	}
	public void setMapUserInclude(String mapUserInclude) {
		this.mapUserInclude = mapUserInclude;
	}
	public String getMapUserExclude() {
		return mapUserExclude;
	}
	public void setMapUserExclude(String mapUserExclude) {
		this.mapUserExclude = mapUserExclude;
	}
	public String getMapExclude() {
		return mapExclude;
	}
	public void setMapExclude(String mapExclude) {
		this.mapExclude = mapExclude;
	}
	public String getVideoInclude() {
		return videoInclude;
	}
	public void setVideoInclude(String videoInclude) {
		this.videoInclude = videoInclude;
	}
	public String getVideoExclude() {
		return videoExclude;
	}
	public void setVideoExclude(String videoExclude) {
		this.videoExclude = videoExclude;
	}
	public String getImgInclude() {
		return imgInclude;
	}
	public void setImgInclude(String imgInclude) {
		this.imgInclude = imgInclude;
	}
	public String getImgExclude() {
		return imgExclude;
	}
	public void setImgExclude(String imgExclude) {
		this.imgExclude = imgExclude;
	}
	public String getDoe() {
		return doe;
	}
	public void setDoe(String doe) {
		this.doe = doe;
	}
	public boolean isOverWrite() {
		return isOverWrite;
	}
	public void setOverWrite(boolean isOverWrite) {
		this.isOverWrite = isOverWrite;
	}
	public String getMode() {
		return mode;
	}
	public void setMode(String mode) {
		this.mode = mode;
	}
	public String getSnapshotName() {
		return snapshotName;
	}
	public void setSnapshotName(String snapshotName) {
		this.snapshotName = snapshotName;
	}
	public int getSnapShotId() {
		return snapShotId;
	}
	public void setSnapShotId(int snapShotId) {
		this.snapShotId = snapShotId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getDateSorting() {
		return dateSorting;
	}
	public void setDateSorting(String dateSorting) {
		this.dateSorting = dateSorting;
	}
	public String getSentimentFilter() {
		return sentimentFilter;
	}
	public void setSentimentFilter(String sentimentFilter) {
		this.sentimentFilter = sentimentFilter;
	}
	public String getClassificationFilter() {
		return classificationFilter;
	}
	public void setClassificationFilter(String classificationFilter) {
		this.classificationFilter = classificationFilter;
	}
	public String getEmotionFilter() {
		return emotionFilter;
	}
	public void setEmotionFilter(String emotionFilter) {
		this.emotionFilter = emotionFilter;
	}
	public String getDateFrom() {
		return dateFrom;
	}
	public void setDateFrom(String dateFrom) {
		this.dateFrom = dateFrom;
	}
	public String getDateTo() {
		return dateTo;
	}
	public void setDateTo(String dateTo) {
		this.dateTo = dateTo;
	}
	public String getNewsRssCountryFilter() {
		return newsRssCountryFilter;
	}
	public void setNewsRssCountryFilter(String newsRssCountryFilter) {
		this.newsRssCountryFilter = newsRssCountryFilter;
	}
	public String getHasNewsFeed() {
		return hasNewsFeed;
	}
	public void setHasNewsFeed(String hasNewsFeed) {
		this.hasNewsFeed = hasNewsFeed;
	}
	public String getHasSocialMedia() {
		return hasSocialMedia;
	}
	public void setHasSocialMedia(String hasSocialMedia) {
		this.hasSocialMedia = hasSocialMedia;
	}
	public String getHasDarkWeb() {
		return hasDarkWeb;
	}
	public void setHasDarkWeb(String hasDarkWeb) {
		this.hasDarkWeb = hasDarkWeb;
	}
	public String getDarkwebFilter() {
		return darkwebFilter;
	}
	public void setDarkwebFilter(String darkwebFilter) {
		this.darkwebFilter = darkwebFilter;
	}
	public String getThreatMatrixFilter() {
		return threatMatrixFilter;
	}
	public void setThreatMatrixFilter(String threatMatrixFilter) {
		this.threatMatrixFilter = threatMatrixFilter;
	}
	public String getUserStatusFilter() {
		return userStatusFilter;
	}
	public void setUserStatusFilter(String userStatusFilter) {
		this.userStatusFilter = userStatusFilter;
	}
	public String getHasCustomCrawler() {
		return hasCustomCrawler;
	}
	public void setHasCustomCrawler(String hasCustomCrawler) {
		this.hasCustomCrawler = hasCustomCrawler;
	}
	public String getBoolOper() {
		return boolOper;
	}
	public void setBoolOper(String boolOper) {
		this.boolOper = boolOper;
	}
	public String getSocialMediaFilter() {
		return socialMediaFilter;
	}
	public void setSocialMediaFilter(String socialMediaFilter) {
		this.socialMediaFilter = socialMediaFilter;
	}
	public ArrayList<EntityVo> getLstEntityVos() {
		return lstEntityVos;
	}
	public void setLstEntityVos(ArrayList<EntityVo> lstEntityVos) {
		this.lstEntityVos = lstEntityVos;
	}
	public String getNewsFeedCountrySpecific() {
		return newsFeedCountrySpecific;
	}
	public void setNewsFeedCountrySpecific(String newsFeedCountrySpecific) {
		this.newsFeedCountrySpecific = newsFeedCountrySpecific;
	}
	public ArrayList<String> getNewsSourceList() {
		return newsSourceList;
	}
	public void setNewsSourceList(ArrayList<String> newsSourceList) {
		this.newsSourceList = newsSourceList;
	}
	
	public ArrayList<String> getWhatsGroupList() {
		return whatsGroupList;
	}
	public void setWhatsGroupList(ArrayList<String> whatsGroupList) {
		this.whatsGroupList = whatsGroupList;
	}
	@Override
	public String toString() {
		return "SaveFilterVo [id=" + id + ", caseId=" + caseId + ", loginId=" + loginId + ", snapShotId=" + snapShotId
				+ ", snapId=" + snapId + ", searchName=" + searchName + ", globalSearch=" + globalSearch
				+ ", dateSearch=" + dateSearch + ", advanceSearch=" + advanceSearch + ", hashtagInclude="
				+ hashtagInclude + ", hashtagExclude=" + hashtagExclude + ", mentionInclude=" + mentionInclude
				+ ", mentionExclude=" + mentionExclude + ", userInclude=" + userInclude + ", userExclude=" + userExclude
				+ ", linkInclude=" + linkInclude + ", linkExclude=" + linkExclude + ", domainInclude=" + domainInclude
				+ ", domainExclude=" + domainExclude + ", mapInclude=" + mapInclude + ", mapExclude=" + mapExclude
				+ ", mapUserInclude=" + mapUserInclude + ", mapUserExclude=" + mapUserExclude + ", videoInclude="
				+ videoInclude + ", videoExclude=" + videoExclude + ", imgInclude=" + imgInclude + ", imgExclude="
				+ imgExclude + ", prsnInclude=" + prsnInclude + ", prsnExclude=" + prsnExclude + ", placeInclude="
				+ placeInclude + ", placeExclude=" + placeExclude + ", orgInclude=" + orgInclude + ", orgExclude="
				+ orgExclude + ", themeInclude=" + themeInclude + ", themeExclude=" + themeExclude
				+ ", calenderInclude=" + calenderInclude + ", calenderExclude=" + calenderExclude
				+ ", articleLocationInclude=" + articleLocationInclude + ", articleLocationExclude="
				+ articleLocationExclude + ", authorLocationInclude=" + authorLocationInclude
				+ ", authorLocationExclude=" + authorLocationExclude + ", doe=" + doe + ", caseName=" + caseName
				+ ", caseType=" + caseType + ", mode=" + mode + ", isOverWrite=" + isOverWrite + ", snapshotName="
				+ snapshotName + ", description=" + description + ", dateSorting=" + dateSorting + ", sentimentFilter="
				+ sentimentFilter + ", classificationFilter=" + classificationFilter + ", threatClassificationFilter="
				+ threatClassificationFilter + ", emotionFilter=" + emotionFilter + ", dateFrom=" + dateFrom
				+ ", dateTo=" + dateTo + ", newsRssCountryFilter=" + newsRssCountryFilter + ", socialMediaFilter="
				+ socialMediaFilter + ", hasNewsFeed=" + hasNewsFeed + ", hasWebsite=" + hasWebsite + ", hasFTP="
				+ hasFTP + ", hasSocialMedia=" + hasSocialMedia + ", hasDarkWeb=" + hasDarkWeb + ", darkwebFilter="
				+ darkwebFilter + ", threatMatrixFilter=" + threatMatrixFilter + ", userStatusFilter="
				+ userStatusFilter + ", dateTypeFilter=" + dateTypeFilter + ", hasCustomCrawler=" + hasCustomCrawler
				+ ", boolOper=" + boolOper + ", newsFeedCountrySpecific=" + newsFeedCountrySpecific + ", lstEntityVos="
				+ lstEntityVos + ", newsSourceList=" + newsSourceList + ", newsWebsiteList=" + newsWebsiteList
				+ ", newsFTPList=" + newsFTPList + ", langInclude=" + langInclude + ", langExclude=" + langExclude
				+ ", odsProfileInclude=" + odsProfileInclude + ", odsProfileExclude=" + odsProfileExclude
				+ ", odsPostInclude=" + odsPostInclude + ", odsPostExclude=" + odsPostExclude + ", ocrPostInclude="
				+ ocrPostInclude + ", ocrPostExclude=" + ocrPostExclude + ", retweetUserInclude=" + retweetUserInclude
				+ ", retweetUserExclude=" + retweetUserExclude + ", analysisType=" + analysisType + ", trackTwKeyword="
				+ trackTwKeyword + ", locationName=" + locationName + ", latitude=" + latitude + ", longitude="
				+ longitude + ", radiusInKM=" + radiusInKM + ", esQuery=" + esQuery + ", keywordIds=" + keywordIds
				+ ", filterQuery=" + filterQuery + ", whatsGroupList=" + whatsGroupList + ", tweeterActionVo="
				+ tweeterActionVo + "]";
	}
	
}
