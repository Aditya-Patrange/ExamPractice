package com.cdac.sudarshan.discover.model;

import java.io.Serializable;

public class Yt_Video_Comment implements Serializable 
{
	private static final long serialVersionUID = 1L;
	private String commentId;
	private String authorDisplayName;
	private String authorProfileImageUrl;
	private String authorChannelUrl;
	private String authorChannelId;
	private String textDisplay;
	private long publishedAt;
	private long updatedAt;
	private int likeCount;
	private int totalReplyCount;
	
	public String getCommentId() {
		return commentId;
	}
	public void setCommentId(String commentId) {
		this.commentId = commentId;
	}
	public String getAuthorDisplayName() {
		return authorDisplayName;
	}
	public void setAuthorDisplayName(String authorDisplayName) {
		this.authorDisplayName = authorDisplayName;
	}
	public String getAuthorProfileImageUrl() {
		return authorProfileImageUrl;
	}
	public void setAuthorProfileImageUrl(String authorProfileImageUrl) {
		this.authorProfileImageUrl = authorProfileImageUrl;
	}
	public String getAuthorChannelUrl() {
		return authorChannelUrl;
	}
	public void setAuthorChannelUrl(String authorChannelUrl) {
		this.authorChannelUrl = authorChannelUrl;
	}
	public String getAuthorChannelId() {
		return authorChannelId;
	}
	public void setAuthorChannelId(String authorChannelId) {
		this.authorChannelId = authorChannelId;
	}
	public String getTextDisplay() {
		return textDisplay;
	}
	public void setTextDisplay(String textDisplay) {
		this.textDisplay = textDisplay;
	}
	public long getPublishedAt() {
		return publishedAt;
	}
	public void setPublishedAt(long publishedAt) {
		this.publishedAt = publishedAt;
	}
	public long getUpdatedAt() {
		return updatedAt;
	}
	public void setUpdatedAt(long updatedAt) {
		this.updatedAt = updatedAt;
	}
	public int getLikeCount() {
		return likeCount;
	}
	public void setLikeCount(int likeCount) {
		this.likeCount = likeCount;
	}
	public int getTotalReplyCount() {
		return totalReplyCount;
	}
	public void setTotalReplyCount(int totalReplyCount) {
		this.totalReplyCount = totalReplyCount;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "Yt_Video_Comment [commentId=" + commentId + ", authorDisplayName=" + authorDisplayName
				+ ", authorProfileImageUrl=" + authorProfileImageUrl + ", authorChannelUrl=" + authorChannelUrl
				+ ", authorChannelId=" + authorChannelId + ", textDisplay=" + textDisplay + ", publishedAt="
				+ publishedAt + ", updatedAt=" + updatedAt + ", likeCount=" + likeCount + ", totalReplyCount="
				+ totalReplyCount + "]";
	}
	
}
