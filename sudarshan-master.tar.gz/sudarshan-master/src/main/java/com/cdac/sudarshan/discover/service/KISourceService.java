package com.cdac.sudarshan.discover.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.cdac.sudarshan.discover.model.TweeterActionVo;
import com.cdac.sudarshan.discover.model.TwitterVo;


@CrossOrigin("*")
public interface KISourceService {

	public ResponseEntity<?> getTweets(HashMap<String, Object> data);

	public ResponseEntity<?> getHashTags(HashMap<String, Object> data);

	public ResponseEntity<?> getLanguage(HashMap<String, Object> data);

	public ResponseEntity<?> getCountry(HashMap<String, Object> data);

	public ResponseEntity<?> getAuthorCountry(HashMap<String, Object> data);

	public ResponseEntity<?> getMetaTagsNer(HashMap<String, Object> data);

	public ResponseEntity<?> getUsers(HashMap<String, Object> data);

	public ResponseEntity<?> getAllAttriubuteCount(HashMap<String, Object> data);

	public ResponseEntity<?> getAlertCounts(HashMap<String, Object> data);

	public ResponseEntity<?> getMedia(HashMap<String, Object> data);

	public ResponseEntity<?> geoTweetsLatLong(HashMap<String, Object> data);

	public ResponseEntity<?> getPlaceWordCloud(HashMap<String, Object> data);

	public ResponseEntity<?> getOrganizationWordCloud(HashMap<String, Object> data);

	public ResponseEntity<?> getUserWordCloud(HashMap<String, Object> data);

	public ResponseEntity<?> getThemeWordCloud(HashMap<String, Object> data);
	
	
	
	
	// facebook flow start
	public ResponseEntity<?> getAllDashboard(HashMap<String, Object> data);

	public ResponseEntity<?> getUserCurrentDashboard(String caseId, HashMap<String, Object> data);

	public ResponseEntity<?> getWidgetsByDashboardId(String dashboardId, HashMap<String, Object> data);
	
	public ResponseEntity<?> dashActiveMedia(TweeterActionVo tweeterActionVo);
	
	public ResponseEntity<?> dashArticles(HashMap<String, Object> data);

	public ResponseEntity<?> getAllWidget(HashMap<String, Object> data);
	// facebook flow end

	public ResponseEntity<?> getTweetDetailById(HashMap<String, Object> data);
	
	public HttpHeaders getHttpHeadersAfterLogin();

	public ResponseEntity<?> updateCollectionDateBySourceAndKeywordMatch(HashMap<String, Object> data);

	public ResponseEntity<?> getSentimentTimeline(HashMap<String, Object> data);

	public ResponseEntity<?> getDashEntityCount(HashMap<String, Object> data);
	
	public ResponseEntity<?> getDashActiveEntity(HashMap<String, Object> data);

	public ResponseEntity<?> getFieldTypeData(HashMap<String, Object> data);

	public ResponseEntity<?> dashActiveUser(HashMap<String, Object> data);

	public ResponseEntity<?> getSummary(HashMap<String, Object> data);

	public ResponseEntity<?> fbScrapyBasicInfo(HashMap<String, Object> data);

	public ResponseEntity<?> fbScrapyUserMedia(HashMap<String, Object> data);

	public  ResponseEntity<?> fbScrapyUserCheckIns(HashMap<String, Object> data);

	public ResponseEntity<?> fbScrapyUserLikes(HashMap<String, Object> data);

	public ResponseEntity<?> fbTopMostUserStrongConnection(HashMap<String, Object> data);

	public ResponseEntity<?> fbScrapyUserFriends(HashMap<String, Object> data);

	public ResponseEntity<?> getFBPeopleProfileWithSameGroup(HashMap<String, Object> data);

	public ResponseEntity<?> getFBPeopleProfileWithSameLikes(HashMap<String, Object> data);

	public ResponseEntity<?> getFBPeopleProfileWithSameCheckIn(HashMap<String, Object> data);

	public ResponseEntity<?> getFBPeopleProfileWithSameLocation(HashMap<String, Object> data);

	public ResponseEntity<?> getSentiment(HashMap<String, Object> data);

	public ResponseEntity<?> checkRetweetStatus(HashMap<String, Object> data);

	public ResponseEntity<ArrayList<TwitterVo>> getTweetsPostCount(TweeterActionVo tweeterActionVo);

	public ResponseEntity<?> getTweetsPostCountOnly(TweeterActionVo tweeterActionVo);

	public ResponseEntity<?> dashActiveMediaCount(TweeterActionVo tweeterActionVo);

	public HttpEntity<?> exportExcelDashboardWidgetData(TweeterActionVo tweeterActionVo, HttpServletResponse response) throws Exception;

	public HttpEntity<?> exportSlideTweetWord(HashMap<String, Object> data);

	public HttpEntity<?> ExportITextMediasRpt(TweeterActionVo tweeterActionVo);

	public HttpEntity<?> collectionCountUserWise(HashMap<String, Object> data);

	public HttpEntity<?> collectionActiveStatusCountUserWise(HashMap<String, Object> data);

	public HttpEntity<?> collectionInactiveStatusCountUserWise(HashMap<String, Object> data);

	public HttpEntity<?> getProxyCountry(HashMap<String, Object> data);

	public HttpEntity<?> getNewsPaperSourceValues(HashMap<String, Object> data);

	public HttpEntity<?> getAllTagsFromThemeUserWise();

}
