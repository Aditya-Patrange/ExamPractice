package com.cdac.sudarshan.folder.controller;

import com.cdac.sudarshan.authentication.model.User;
import com.cdac.sudarshan.dto.DTO;
import com.cdac.sudarshan.dto.UserFolderDTO;
import com.cdac.sudarshan.folder.dto.RootFolderDto;
import com.cdac.sudarshan.folder.model.RootFolder;
import com.cdac.sudarshan.folder.service.IRootFolderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@CrossOrigin("*")
@RestController
@RequestMapping("/rootfolder")
public class RootFolderController {

    @Autowired
    private IRootFolderService rootFolderServiceImpl;

    @PostMapping("/save")
    public ResponseEntity<?> saveRootFolder(@RequestBody Map<String, String> map) {

        Map<String, String> response = new HashMap<>();

        String path = map.get("path");

        String[] split = path.split("/");
        List<String> list = new ArrayList<>();
        for (String s : split) {
            if (!s.equals(""))
                list.add(s);
        }
        RootFolder rootFolder = new RootFolder();
        rootFolder = rootFolderServiceImpl.saveRootFolder(list);
        response.put("Message", "Root Folder Added SuccessFully");
        response.put("Status_Code", String.valueOf(HttpStatus.CREATED.value()));
        response.put("Root_Folder_Name", rootFolder.getRootFolderName());
        response.put("Creation_Date_And_Time", String.valueOf(rootFolder.getCreationTimeAndDate()));
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @GetMapping("/")
    public ResponseEntity<?> getAllRootFolders() {
        Map<String, Object> response = new HashMap<>();
        List<RootFolder> listOfRootFolders = rootFolderServiceImpl.listOfRootFolders();

        List<RootFolder> newRootFolderList = new ArrayList<>();

        for (RootFolder r : listOfRootFolders) {

            RootFolder rootFolder = new RootFolder();

            rootFolder.setId(r.getId());
            rootFolder.setRootFolderName(r.getRootFolderName());
            // rootFolder.setRootFolderUrls(r.getRootFolderUrls());
            rootFolder.setCreationTimeAndDate(r.getCreationTimeAndDate());

            User user = new User();
            user.setId(r.getUser().getId());

            rootFolder.setUser(user);

            newRootFolderList.add(rootFolder);

        }

        response.put("List Of Folder : ", newRootFolderList);
        response.put("Status_Code", HttpStatus.OK.value());
        return ResponseEntity.ok(response);
    }

    @GetMapping("/getAllFolder")
    public ResponseEntity<?> getAllRootFolderOfLoggedInUser() {

        UserFolderDTO allSubFolderAndUrlPathsOfRootFolderOfUser = null;

        allSubFolderAndUrlPathsOfRootFolderOfUser = rootFolderServiceImpl
                .getAllSubFolderAndUrlPathsOfRootFolderOfUser();

        return ResponseEntity.ok(allSubFolderAndUrlPathsOfRootFolderOfUser);
    }

    @GetMapping("/getrootfolderofuser")
    public ResponseEntity<?> getRootOfUser() {

        Map<Object, Object> response = new HashMap<>();
        List<RootFolderDto> list = new ArrayList<RootFolderDto>();

        DTO dto = new DTO();
        list = rootFolderServiceImpl.getRootFolderOfUser();

        response.put("FolderList: ", list);
        response.put("statusCode", HttpStatus.OK.value());
        dto.setDtos(list);
        return ResponseEntity.ok(dto);

    }

    /**
     * This method return all urls count w.r.t input path including their sub paths
     *
     * @param map
     * @return
     */
    @PostMapping("/getUrlCount")
    public ResponseEntity<?> getUrlCount(@RequestBody Map<String, String> map) {
        return new ResponseEntity<>(rootFolderServiceImpl.getUrlCount(map.get("path")), HttpStatus.OK);
    }

    /**
     * This method return total item count = folder consider as single item + urls
     *
     * @param map
     * @return
     */
    @PostMapping("/getItemCount")
    public ResponseEntity<?> getItemCount(@RequestBody Map<String, String> map) {
        return new ResponseEntity<>(rootFolderServiceImpl.getItemCount(map.get("path")), HttpStatus.OK);
    }

    /**
     * Delete all data from folder
     *
     * @param map
     * @return
     */
//    @DeleteMapping("/deleteRootFolder")
//    public ResponseEntity<?> deleteRootFolder(@RequestBody Map<String, String> map) {
//        return rootFolderServiceImpl.deleteFolderAllData2(map.get("path"));
//    }

    @PutMapping("/deleteRootFolder")
    public ResponseEntity<?> deleteRootFolder(@RequestBody Map<String, List<String>> map) {
        return rootFolderServiceImpl.deleteFolderAllData2(map);
    }

    @PatchMapping("/renameFolder")
    public ResponseEntity<?> renameRootFolderName(@RequestBody Map<String,String> map){
        return rootFolderServiceImpl.renameFolderName(map);
    }

    @PostMapping("/copyRootFolder")
    public ResponseEntity<?> copyRootFolderAndData(@RequestBody Map<String, Object> map) {
        return new ResponseEntity<>(rootFolderServiceImpl.copyRootFolderAndData((List<String>) map.get("paths"), (String) map.get("destination")), HttpStatus.OK);
    }
}
