package com.cdac.sudarshan.discover.dto;

import com.cdac.sudarshan.discover.model.BaseEntity;
import com.cdac.sudarshan.discover.model.DiscoverSources;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@RequiredArgsConstructor
public class DiscoverSourceDto extends BaseEntity{

	private DiscoverSources discoverSources;
}
