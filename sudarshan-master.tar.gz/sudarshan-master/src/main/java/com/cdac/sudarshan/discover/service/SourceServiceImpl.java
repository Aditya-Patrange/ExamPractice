package com.cdac.sudarshan.discover.service;

import com.cdac.sudarshan.authentication.model.User;
import com.cdac.sudarshan.authentication.service.IUserService;
import com.cdac.sudarshan.discover.dto.BaseEntityDto;
import com.cdac.sudarshan.discover.model.Country;
import com.cdac.sudarshan.discover.model.DiscoverSources;
import com.cdac.sudarshan.discover.model.Trends;
import com.cdac.sudarshan.discover.projection.DiscoverSubSourcesProjection;
import com.cdac.sudarshan.discover.repository.ICountryRepository;
import com.cdac.sudarshan.discover.repository.ISourceRepository;
import com.cdac.sudarshan.discover.repository.ISubSourceRepository;
import com.cdac.sudarshan.discover.repository.ITrendsRepository;
import com.cdac.sudarshan.dto.DocumentCountDto;
import com.cdac.sudarshan.exception.DataNotFoundException;
import com.cdac.sudarshan.exception.ResourceNotFoundException;
import com.cdac.sudarshan.theme.dto.ThemeDto;
import com.cdac.sudarshan.theme.dto.ThemesDto;
import com.cdac.sudarshan.theme.model.Keyword;
import com.cdac.sudarshan.theme.model.SubTheme;
import com.cdac.sudarshan.theme.model.Theme;
import com.cdac.sudarshan.theme.repository.IKeywordRepository;
import com.cdac.sudarshan.theme.repository.ISubThemeRepository;
import com.cdac.sudarshan.theme.repository.IThemeRepository;
import com.cdac.sudarshan.theme.service.IThemeService;
import com.google.gson.*;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import javax.transaction.Transactional;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Transactional
public class SourceServiceImpl implements ISourceService {

    /* Synchronus rest client class to invoke backend API */
    private RestTemplate template;

    @Value("${innerInnefuUrlSearchByName}")
    private String innerInnefuUrlSearchByName;
    
    @Value("${innerInnefuUrl}")
    private String innefuUrl;


    @Value("${System_UserId}")
    private String systemUserId;

    @Value("${NumberOfDays}")
    private int days;

    @Value("${Theme_Docs_Count}")
    private String themeDocCountUrl;

//	@Value("#{${collectionData}}")
//	HashMap<String, Object> map;


    @Autowired
    private ISourceRepository resourceRepository;

    @Autowired
    private ISubSourceRepository subSourceRepository;

    @Autowired
    private ICountryRepository countryRepository;

    @Autowired
    private ITrendsRepository trendsRepository;

    @Autowired
    private IThemeService themeService;

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private IThemeRepository themeRepository;

    @Autowired
    private IKeywordRepository keywordRepository;

    @Autowired
    private ISubThemeRepository subThemeRepository;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private IUserService userService;


    @Autowired
    public SourceServiceImpl(RestTemplateBuilder builder) {
        template = builder.build();
    }

    @Override
    public List<DiscoverSources> getSourceList() {
        return resourceRepository.findAll();
    }

    @Override
    public List<DiscoverSubSourcesProjection> getSubSourceList(BaseEntityDto baseEntityDto) {
        if (baseEntityDto.getId() == 1 || baseEntityDto.getId() == 2 || baseEntityDto.getId() == 3)
            return subSourceRepository.getSubSourceNameAndId(1);
        return subSourceRepository.getSubSourceNameAndId(baseEntityDto.getId());
    }

    @Override
    public ResponseEntity<?> searchEntity(HashMap<String, Object> data) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<>(addCollectionJasonDataFormat(setUserId(data)), headers);
        return template.exchange(innefuUrl + "InnsightRestServicesNewUi/collectionmanager/addNewCollection",
                HttpMethod.POST, entity, Object.class);
    }

    /**
     * This Method is used to get i/p data & replace
     * activationDate,deactivationDate,collectionName this fields
     *
     * @param HashMap<String, Object> data
     * @return HashMap<String, Object> data
     */
    private HashMap<String, Object> addCollectionJasonDataFormat(HashMap<String, Object> data) {
        HashMap<String, Object> keywords = (HashMap<String, Object>) data.get("keyword");
        List<String> keyword = (List<String>) keywords.get("keyword");
        data.put("collectionType", "keyword");
        data.put("activationDate", new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(new Date()));
        data.put("deactivationDate", DateFormatSet(days));
        data.put("collectionName", (keyword.get(0) + "_").concat(new Timestamp(System.currentTimeMillis()).toString()));
        return data;
    }

    /**
     * This Method is used to calculate deactivation date from current date
     *
     * @param int days
     * @return deactivationdate:dd-M-yyyy hh:mm:ss
     */
    private String DateFormatSet(int days) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        calendar.add(Calendar.DATE, days);
        return new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(calendar.getTime());
    }

    @Override
    public ResponseEntity<?> getLink(HashMap<String, Object> data) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<>(data, headers);
        // System.out.println("innefuUrl :"+innefuUrl +entity);
        return template.exchange(innefuUrl + "innsight/getLink", HttpMethod.POST, entity, Object.class);

//		ResponseEntity<?> result =template.exchange(innefuUrls+"getLink", HttpMethod.POST, entity, Object.class);
//		String da =result.getBody().toString();
//		System.out.println("da : "+da);
//		
////		 Map<String, Object> a =Arrays.asList(da)
////		  .stream()
////		  .map(str -> str.split("=")).collect(ToMapConverter(str -> str[0], str -> str[1]));
//		//  .collect(toMap(str -> str[0], str -> str[1]));
//		
//		 Map<String, String> reconstructedUtilMap = Arrays.stream(da.split(","))
//		            .map(s -> s.split("="))
//		            .collect(Collectors.toMap(s -> s[0], s -> s[1]));
//		 
//		 System.out.println("reconstructedUtilMap : "+reconstructedUtilMap);
//		return result;
    }

    @Override
    public ResponseEntity<?> getMentions(HashMap<String, Object> data) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<>(data, headers);
//		System.out.println("innefuUrls :"+innefuUrl +entity);
        return template.exchange(innefuUrl + "innsight/getMentions", HttpMethod.POST, entity, Object.class);
    }

    @Override
    public ResponseEntity<?> getThemes(HashMap<String, Object> data) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<>(data, headers);
        return template.exchange(innefuUrl + "innsight/getThemes", HttpMethod.POST, entity, Object.class);
    }

    @Override
    public ResponseEntity<?> getTweetGraph(HashMap<String, Object> data) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<>(data, headers);
        return template.exchange(innefuUrl + "innsight/getTweetGraph", HttpMethod.POST, entity, Object.class);
    }

    @Override
    public ResponseEntity<?> getHashtagWordCloud(HashMap<String, Object> data) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<>(data, headers);
        return template.exchange(innefuUrl + "innsight/getHashtagWordCloud", HttpMethod.POST, entity, Object.class);
    }

    @Override
    public ResponseEntity<?> getMentionWordCloud(HashMap<String, Object> data) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<>(data, headers);
        return template.exchange(innefuUrl + "innsight/getMentionWordCloud", HttpMethod.POST, entity, Object.class);
    }

    @Override
    public ResponseEntity<?> getPersonWordCloud(HashMap<String, Object> data) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<>(data, headers);
        return template.exchange(innefuUrl + "innsight/getPersonWordCloud", HttpMethod.POST, entity, Object.class);
    }

    @Override
    public List<DiscoverSubSourcesProjection> getSubSourceAllList() {
        return subSourceRepository.findAllSource();
    }

    @Override
    public List<Country> getCountryList() {
        return countryRepository.findAll();
    }

    @Override
    public ResponseEntity<?> listCollection(HashMap<String, Object> data) {

        System.out.println("in listcollection *******");

        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
      //  Map<String, Object> resultData = setUserId(data);
        HttpEntity<Object> entity = new HttpEntity<>(setUserId(data), headers);

        return template.exchange(innefuUrl + "InnsightRestServicesNewUi/collectionmanager/listCollection",
                HttpMethod.POST, entity, Object.class);
    }

    //        return template.exchange(innefuUrl + "InnsightRestServicesNewUi/collectionmanager/searchByName",
//                HttpMethod.POST, entity, Object.class);

    @Override
    public ResponseEntity<?> searchByName(HashMap<String, Object> data) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<>(setUserId(data), headers);
        //return template.exchange(innerInnefuUrlSearchByName+"/api/track-profile/", HttpMethod.POST, entity, Object.class);
        return template.exchange(innefuUrl+"InnsightRestServicesNewUi/collectionmanager/searchByName", HttpMethod.POST, entity, Object.class);
    }

    @Override
    public ResponseEntity<?> addNewCollectionForProfile(HashMap<String, Object> data) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<>(setUserId(data), headers);
        return template.exchange(innefuUrl + "InnsightRestServicesNewUi/collectionmanager/addNewCollection",
                HttpMethod.POST, entity, Object.class);
    }

    @Override
    public ResponseEntity<?> updateCollectionPausedStatusById(HashMap<String, Object> data) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<>(setUserId(data), headers);
        return template.exchange(
                innefuUrl + "InnsightRestServicesNewUi/collectionmanager/updateCollectionPausedStatusById",
                HttpMethod.POST, entity, Object.class);
    }

    @Override
    public ResponseEntity<?> deleteCollection(HashMap<String, Object> data) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        data = setUserId(data);
        HttpEntity<Object> entity = new HttpEntity<>(data, headers);
        return template.exchange(innefuUrl + "InnsightRestServicesNewUi/collectionmanager/deleteCollection",
                HttpMethod.POST, entity, Object.class);
    }

    /**
     * update existing collection by collection_id & collectionType
     */
    @Override
    public ResponseEntity<?> getCollectionById(HashMap<String, Object> data) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<>(setUserId(data), headers);
        return template.exchange(innefuUrl + "InnsightRestServicesNewUi/collectionmanager/getCollectionById",
                HttpMethod.POST, entity, Object.class);
    }

    /**
     * give article detailed information
     */
    @Override
    public ResponseEntity<?> getTweetDetailById(HashMap<String, Object> data) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<>(data, headers);
        return template.exchange(innefuUrl + "innsight/getTweetDetailById", HttpMethod.POST, entity, Object.class);
    }

    @Override
    public ResponseEntity<?> getTweetsUserLocation(HashMap<String, Object> data) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<>(data, headers);
        return template.exchange(innefuUrl + "innsight/getTweetsUserLocation", HttpMethod.POST, entity, Object.class);
    }

    /**
     * Used to getting Country ,Proxy, Category, AvtarCategory Data
     */
    @Override
    public ResponseEntity<?> selectAllMaster(HashMap<String, Object> data) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<>(data, headers);
        return template.exchange(innefuUrl + "InnsightRestServicesNewUi/collectionmanager/selectAllMaster",
                HttpMethod.POST, entity, Object.class);
    }

    @Override
    public ResponseEntity<?> geoTweetsLatLong(HashMap<String, Object> data) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<>(data, headers);
        return template.exchange(innefuUrl + "innsight/geoTweetsLatLong", HttpMethod.POST, entity, Object.class);
    }

    @Override
    public ResponseEntity<?> updateNewCollectionById(HashMap<String, Object> data) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<>(setUserId(data), headers);
        return template.exchange(innefuUrl + "InnsightRestServicesNewUi/collectionmanager/updateNewCollectionById",
                HttpMethod.POST, entity, Object.class);
    }

    // Get twitter Tweets Data for profile search
    @Override
    public ResponseEntity<?> getTweetsUsrDtlRpt(HashMap<String, Object> data) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<>(data, headers);
        return template.exchange(innefuUrl + "innsight/getTweetsUsrDtlRpt", HttpMethod.POST, entity, Object.class);
    }

    // Get Twitter User followers
    @Override
    public ResponseEntity<?> userDetailReportFollowers(HashMap<String, Object> data) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<>(data, headers);
        return template.exchange(innefuUrl + "innsight/userDetailReportFollowers", HttpMethod.POST, entity,
                Object.class);
    }

    // Get Twitter User following list
    @Override
    public ResponseEntity<?> userDetailReportFollowing(HashMap<String, Object> data) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<>(data, headers);
        return template.exchange(innefuUrl + "innsight/userDetailReportFollowing", HttpMethod.POST, entity,
                Object.class);
    }

    // Get Twitter User top Hashtags list
    @Override
    public ResponseEntity<?> getHashTagsUsrDtlRpt(HashMap<String, Object> data) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<>(data, headers);
        return template.exchange(innefuUrl + "innsight/getHashTagsUsrDtlRpt", HttpMethod.POST, entity, Object.class);
    }

    // Get Twitter User Top Mentions list
    @Override
    public ResponseEntity<?> getMentionUsrDtlRpt(HashMap<String, Object> data) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<>(data, headers);
        return template.exchange(innefuUrl + "innsight/getMentionUsrDtlRpt", HttpMethod.POST, entity, Object.class);

    }

    // Get Twitter User Top retweets list
    @Override
    public ResponseEntity<?> userTopRetweet(HashMap<String, Object> data) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<>(data, headers);
        return template.exchange(innefuUrl + "innsight/userTopRetweet", HttpMethod.POST, entity, Object.class);

    }

    // Get Twitter User Top Reply user list
    @Override
    public ResponseEntity<?> userTopReply(HashMap<String, Object> data) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<>(data, headers);
        return template.exchange(innefuUrl + "innsight/userTopReply", HttpMethod.POST, entity, Object.class);

    }

    // Get Twitter User tweet platform Eg. iPhone
    @Override
    public ResponseEntity<?> userTopSource(HashMap<String, Object> data) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<>(data, headers);
        return template.exchange(innefuUrl + "innsight/userTopSource", HttpMethod.POST, entity, Object.class);

    }

    // Get Twitter User Daily activity : Day of week
    @Override
    public ResponseEntity<?> getTimeLineDayOfWeek(HashMap<String, Object> data) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<>(data, headers);
        return template.exchange(innefuUrl + "innsight/getTimeLineDayOfWeek", HttpMethod.POST, entity, Object.class);
    }

    // Get Twitter User Hourly activity count : Hours of Day
    @Override
    public ResponseEntity<?> getTimeLineDayOfHour(HashMap<String, Object> data) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<>(data, headers);
        return template.exchange(innefuUrl + "innsight/getTimeLineDayOfHour", HttpMethod.POST, entity, Object.class);
    }


    private HashMap<String,Object> setUserId(HashMap<String,Object> map){

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        User loggedInUser = userService.getUserByUserName(authentication.getName());

        if (loggedInUser == null) {
            throw new ResourceNotFoundException("Please Login first For adding add url");
        }

        map.put("userId",loggedInUser.getId());

        return map;
    }

    // Get Twitter tweet Time Line Graph data
    @Override
    public ResponseEntity<?> getTweetGraphUsrDtlRpt(HashMap<String, Object> data) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<>(data, headers);
        return template.exchange(innefuUrl + "innsight/getTweetGraphUsrDtlRpt", HttpMethod.POST, entity, Object.class);
    }

    // Get Twitter User Stats line data
    @Override
    public ResponseEntity<?> gettweetStatsOffLine(HashMap<String, Object> data) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<>(data, headers);
        return template.exchange(innefuUrl + "innsight/gettweetStatsOffLine", HttpMethod.POST, entity, Object.class);
    }

    @SuppressWarnings("unchecked")
    private void getAllProfileData(HttpEntity<Object> entity, String partialUrl, List<HashMap<String, Object>> allProfileData) {
        ResponseEntity<Object> exchange = template.exchange(innefuUrl + partialUrl,
                HttpMethod.POST, entity, Object.class);
        Gson gson = new GsonBuilder().serializeNulls().create();
        String profileString = gson.toJson(exchange.getBody());
        JsonParser parser = new JsonParser();

        JsonArray jsonArray = (JsonArray) parser.parse(profileString);
        for (Object o : jsonArray) {

            JsonObject jO = (JsonObject) o;

            allProfileData.add(new Gson().fromJson(jO, HashMap.class));
        }
    }


    // Get All profile Data of source Dm Fb Yt Ins Tm Li Red Tw
    @Override
    public ResponseEntity<Object> getProfileSearchDataDmFbYtInsTmLiRedTw(HashMap<String, Object> data) {
        HttpHeaders headers = new HttpHeaders();

        ResponseEntity<Object> exchange = null;
        JsonParser parser = new JsonParser();
//		LinkedList<ResponseEntity> profileData = new LinkedList<>();

        List<HashMap<String, Object>> allProfileData = new ArrayList<>();
//        Set<HashMap<String, Object>> allProfileData = new HashSet<>();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HashMap<String, Object> payload = (HashMap<String, Object>) data.get("payload");

        HttpEntity<Object> entity = new HttpEntity<>(payload, headers);

        // fb, tw, insta, yt, dm, tm, reddit, wp
        String source = (String) data.get("sources");
        if (source.contains("tw"))
            getAllProfileData(entity, "innsight/searchTwitterUserFromSystems", allProfileData);
        if (source.contains("fb")){
            getAllProfileData(entity, "innsight/searchFbProfileFromSystems", allProfileData);
            getAllProfileData(entity, "innsight/searchFbPageFromSystems", allProfileData);
            getAllProfileData(entity, "innsight/searchFbGroupFromSystems", allProfileData);
        }



//		if (source.contains("yt"))
//			getAllProfileData(entity, "innsight/searchYoutubeChannleFromSystems", allProfileData);
//		if (source.contains("insta"))
//			getAllProfileData(entity, "innsight/searchInstaUserFromSystems", allProfileData);	
//		if (source.contains("tm"))
//			getAllProfileData(entity, "innsight/searchTmUsersFromSystems", allProfileData);
//		if (source.contains("blogger"))
//			getAllProfileData(entity, "innsight/searchGbUsersFromSystems", allProfileData);
//		if (source.contains("linkedin"))
//			getAllProfileData(entity, "innsight/searchLinkedinUsersFromSystems", allProfileData);
//		if (source.contains("reddit"))
//			getAllProfileData(entity, "innsight/searchRedditUsersFromSystems", allProfileData);
//		if (source.contains("dm"))
//			getAllProfileData(entity, "innsight/searchDMUserFromSystems", allProfileData);
       // getUniqueProfileData(allProfileData);
        return new ResponseEntity<Object>(getUniqueProfileData(allProfileData), HttpStatus.OK);
    }


    public List<HashMap<String, Object>> getUniqueProfileData(List<HashMap<String, Object>> inputData) {
        Map<Integer, Object> map = new HashMap<>();
        for(int i=0; i<inputData.size(); i++) {
            if(inputData.get(i).get("entitySourceType").equals("twitter")){
                if(inputData.get(i).containsKey("twId")) {
                    map.put(i, inputData.get(i).get("twId"));
                }
            }
            if(inputData.get(i).get("entitySourceType").equals("facebook")){
                if(inputData.get(i).containsKey("entitySocialId")) {
                    map.put(i, inputData.get(i).get("entitySocialId"));
                }
            }
        }


        List<Object> list = new ArrayList<Object>();
        List<Integer> indexOfKeysWithDuplicateValues = new ArrayList<>();
        for(Map.Entry<Integer, Object> d : map.entrySet()) {
            if(!list.contains(d.getValue())) {
                list.add(d.getValue());
            }else {
                indexOfKeysWithDuplicateValues.add(d.getKey());
            }
        }

        list.clear();
        map.clear();

       // Collections.sort(index, Collections.reverseOrder());
        List<HashMap<String, Object>> outputData = new ArrayList<>();

        if(indexOfKeysWithDuplicateValues.isEmpty()){
            inputData.get(0).put("ProfileCount",inputData.size());
            return inputData;
        }else{
            for(int k=0; k<inputData.size(); k++) {
                if(!indexOfKeysWithDuplicateValues.contains(k)){
                    outputData.add(inputData.get(k));
                }
            }
            outputData.get(0).put("ProfileCount",outputData.size());
            return outputData;
        }
    }


    @Override
    public ResponseEntity<Object> getProfileSearchDataCount(HashMap<String, Object> data) {
        HttpHeaders headers = new HttpHeaders();

        ResponseEntity<Object> exchange = null;
        JsonParser parser = new JsonParser();
//		LinkedList<ResponseEntity> profileData = new LinkedList<>();

//         Set<HashMap<String, Object>> allProfileData = new HashSet<>();
        List<HashMap<String, Object>> allProfileData = new ArrayList<>();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HashMap<String, Object> payload = (HashMap<String, Object>) data.get("payload");

        HttpEntity<Object> entity = new HttpEntity<>(payload, headers);

        // fb, tw, insta, yt, dm, tm, reddit, wp
        String source = (String) data.get("sources");
        if (source.contains("tw"))
            getAllProfileData(entity, "innsight/searchTwitterUserFromSystems", allProfileData);
        if (source.contains("fb"))
            getAllProfileData(entity, "innsight/searchFbProfileFromSystems", allProfileData);
//		if (source.contains("dm"))
//			getAllProfileData(entity, "innsight/searchDMUserFromSystems", allProfileData);
//		if (source.contains("yt"))
//			getAllProfileData(entity, "innsight/searchYoutubeChannleFromSystems", allProfileData);
//		if (source.contains("insta"))
//			getAllProfileData(entity, "innsight/searchInstaUserFromSystems", allProfileData);
//		if (source.contains("tm"))
//			getAllProfileData(entity, "innsight/searchTmUsersFromSystems", allProfileData);
//		if (source.contains("blogger"))
//			getAllProfileData(entity, "innsight/searchGbUsersFromSystems", allProfileData);
//		if (source.contains("linkedin"))
//			getAllProfileData(entity, "innsight/searchLinkedinUsersFromSystems", allProfileData);
//		if (source.contains("reddit"))
//			getAllProfileData(entity, "innsight/searchRedditUsersFromSystems", allProfileData);

        HashMap<String, Object> counts = new HashMap<>();
        counts.put("count", getUniqueProfileData(allProfileData).size());
        return new ResponseEntity<Object>(counts, HttpStatus.OK);
    }

    // Get collection details in collection manager
    @Override
    public ResponseEntity<Object> listKeywordOfCollection(HashMap<String, Object> data) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<>(setUserId(data), headers);
        return template.exchange(innefuUrl + "InnsightRestServicesNewUi/collectionmanager/listKeywordOfCollection", HttpMethod.POST, entity, Object.class);
    }

    // Get All trends source list
    @Override
    public List<Trends> getTrendsList() {
        return trendsRepository.findAll();
    }


    @Override
    public ResponseEntity<?> getPhoneCode(String countryCode) {
        return ResponseEntity.ok(countryRepository.findByCountryCode(countryCode));
    }

    // Return ALl theme tags w.r.t them & subTheme
    @Override
    public HashMap<String, Object> addThemeCollection() {

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        User loggedInUser = userService.getUserByUserName(authentication.getName());

        if (loggedInUser == null) {
            throw new ResourceNotFoundException("Please Login first For adding add url");
        }

        HashMap<String, Object> data = new HashMap<>();
        HashMap<String, Object> result = new HashMap<>();
        List<Theme> themes = themeRepository.findAll();

        if (themes.isEmpty()) {
            throw new DataNotFoundException("Themes not found");
        }

        //convert theme to themeDto
        List<ThemesDto> themeDtos = themes.stream().map(theme -> modelMapper.map(theme, ThemesDto.class))
                .collect(Collectors.toList());

        for (int i = 0; i < themeDtos.size(); i++) {
            String themePath = themeDtos.get(i).getThemePath();
            if (!themePath.isBlank()) {
                List<Keyword> keywordList = keywordRepository.findByRootThemeId(themeDtos.get(i).getId());
                if (!keywordList.isEmpty()) {
                    data.put(themePath, getKeywordList(keywordList));
                }
            }
            List<SubTheme> subThemes = themeDtos.get(i).getSubThemes();
            for (int j = 0; j < subThemes.size(); j++) {
                String subThemePath = subThemes.get(j).getSubThemePath();
                List<Keyword> dataList = subThemes.get(j).getDataList();
                List<String> keywordList = getKeywordList(dataList);
                if (!keywordList.isEmpty()) {
                    subThemePath = subThemePath.substring(1, subThemePath.length() - 1).replace("/", "_").replace(" ", "-");
                    data.put(subThemePath, getKeywordList(dataList));
                }
            }
        }
        result.put("data", data);
        result.put("userId", loggedInUser.getId());

        return result;
    }


    private List<String> getKeywordList(List<Keyword> dataList) {
        List<String> keywordList = new ArrayList<>();
        for (int k = 0; k < dataList.size(); k++) {
            String keyword = dataList.get(k).getKeyword();
            if (!keyword.isEmpty()) {
                keywordList.add(keyword);
            }
        }
        return keywordList;
    }

    // get all tag list w.r.t theme only
/*    public HashMap<String, List<String>> getThemeTag() {
        ThemeDto themeDto = new ThemeDto();

        List<Theme> themes = themeRepository.findAll();
        if (themes.isEmpty()) {
            throw new DataNotFoundException("Themes not found");
        }

        HashMap<String, List<List<Keyword>>> response = new HashMap<>();

        for (int i = 0; i < themes.size(); i++) {
            List<List<Keyword>> keywords = new ArrayList<>();
            List<SubTheme> subThemes = subThemeRepository.findByTheme(themes.get(i));
            List<Keyword> themeKeywordList = keywordRepository.findByRootThemeId(themes.get(i).getId());

            if (!themeKeywordList.isEmpty()) {
                keywords.add(themeKeywordList);
            }

            for (int j = 0; j < subThemes.size(); j++) {
                SubTheme subTheme = subThemeRepository.findBySubThemePath(subThemes.get(j).getSubThemePath());
                List<Keyword> subThemeKeywordList = keywordRepository.findBySubTheme(subTheme);
                keywords.add(subThemeKeywordList);
            }
            response.put(themes.get(i).getThemePath(), keywords);
        }

        HashMap<String, List<String>> data = new HashMap<>();
        for (int i = 0; i < themes.size(); i++) {
            List<String> tag = new ArrayList<>();
            List<List<Keyword>> keywordList = response.get(themes.get(i).getThemePath());
            for (int j = 0; j < keywordList.size(); j++) {
                List<Keyword> keywords = keywordList.get(j);
                for (int k = 0; k < keywords.size(); k++) {
                    tag.add(keywords.get(k).getKeyword());
                }
            }
            data.put(themes.get(i).getThemePath(), tag);
        }
        return data;
    }*/

    public List<ThemeDto> getThemeTag() {
        List<ThemeDto> responseData = new ArrayList<>();
        List<Theme> themes = themeRepository.findAll();
        if (themes.isEmpty()) {
            throw new DataNotFoundException("Themes not found");
        }

        HashMap<String, List<List<Keyword>>> response = new HashMap<>();

        for (int i = 0; i < themes.size(); i++) {

            List<List<Keyword>> keywords = new ArrayList<>();
            List<SubTheme> subThemes = subThemeRepository.findByTheme(themes.get(i));
            List<Keyword> themeKeywordList = keywordRepository.findByRootThemeId(themes.get(i).getId());

            if (!themeKeywordList.isEmpty()) {
                keywords.add(themeKeywordList);
            }

            for (int j = 0; j < subThemes.size(); j++) {
                SubTheme subTheme = subThemeRepository.findBySubThemePath(subThemes.get(j).getSubThemePath());
                List<Keyword> subThemeKeywordList = keywordRepository.findBySubTheme(subTheme);
                keywords.add(subThemeKeywordList);
            }
            response.put(themes.get(i).getThemePath(), keywords);


            ThemeDto themeDto = new ThemeDto();
            themeDto.setId(themes.get(i).getId());
            themeDto.setThemePath(themes.get(i).getThemePath());
            //         themeDto.setSubThemes(subThemes);
            themeDto.setSubThemeCount(subThemes.size());

            List<String> tag = new ArrayList<>();
            for (int j = 0; j < keywords.size(); j++) {
                List<Keyword> keyword = keywords.get(j);
                for (int k = 0; k < keyword.size(); k++) {
                    tag.add(keyword.get(k).getKeyword());
                }
            }

            themeDto.setKeywords(tag);
            themeDto.setKeywordsCount(tag.size());
            themeDto.setDocCount(getDocsCount(tag));
            themeDto.setLastUpdatedDate(getupdationDate(tag));
            responseData.add(themeDto);
        }
        return responseData;
    }

    // get total document count from ES : Python API
    private Long getDocsCount(List<String> tag) {
        HashMap<String, Object> tagsData = new HashMap<>();
        tagsData.put("tags", tag);

        // convert map to jason format
    /*  ObjectMapper mapper = new ObjectMapper();
        String tagsList;
        try {
           tagsList= mapper.writeValueAsString(tagsData);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    */
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<>(tagsData, headers);
        ResponseEntity<DocumentCountDto> result = template.exchange(themeDocCountUrl, HttpMethod.POST, entity, DocumentCountDto.class);
        return Long.valueOf(result.getBody().getDocs_count());
    }

    // Format List : add single quote to list values
    private static String sqlFormatedList(List<String> list) {
        StringBuilder sb = new StringBuilder();
        sb.append("('");
        for (String i : list) {
            sb.append(i + "','");
        }
        sb.deleteCharAt(sb.length() - 1);
        sb.deleteCharAt(sb.lastIndexOf(","));
        sb.append(")");
        return sb.toString();
    }

    // get Last Crawl date of latest theme keyword
    private Object getupdationDate(List<String> tags) {

        // format list
        String tagsList = sqlFormatedList(tags);

        String query = "select last_crawl_date from collection_keyword where keyword_name in" + tagsList + " ORDER BY last_crawl_date DESC LIMIT 1";

        List<Map<String, Object>> maps = jdbcTemplate.queryForList(query);

        Object last_crawl_date = maps.get(0).get("last_crawl_date");

        return last_crawl_date;
    }
}


