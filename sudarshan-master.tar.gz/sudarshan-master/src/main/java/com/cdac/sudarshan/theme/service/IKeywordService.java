package com.cdac.sudarshan.theme.service;

import com.cdac.sudarshan.theme.model.Keyword;

import java.util.List;

public interface IKeywordService{

    public List<Keyword> saveKeywords(Object keywords, String path);

    List<Keyword> getKeywords(String path);
}
