package com.cdac.sudarshan.discover.model;

import java.io.Serializable;

public class TweetTblVo implements  Serializable {
	private static final long serialVersionUID = 1L;
	String id,createdAt,geo,inReplyToScreenName,inReplyToStatusId,inReplyToUserId;
	String lang,retweetFlag,retweetSourceId,source,text,userId,retweetCount;
	String geoLevel,geoPlace,userScreenName,latitude,longitude,city,country,countryCode,place,favouriteCount,posibleSensitive,isTruncated;
	
	public String getIsTruncated() {
		return isTruncated;
	}
	public void setIsTruncated(String isTruncated) {
		this.isTruncated = isTruncated;
	}
	public String getPosibleSensitive() {
		return posibleSensitive;
	}
	public void setPosibleSensitive(String posibleSensitive) {
		this.posibleSensitive = posibleSensitive;
	}
	public String getFavouriteCount() {
		return favouriteCount;
	}
	public void setFavouriteCount(String favouriteCount) {
		this.favouriteCount = favouriteCount;
	}
	public String getPlace() {
		return place;
	}
	public void setPlace(String place) {
		this.place = place;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}
	public String getGeo() {
		return geo;
	}
	public void setGeo(String geo) {
		this.geo = geo;
	}
	public String getInReplyToScreenName() {
		return inReplyToScreenName;
	}
	public void setInReplyToScreenName(String inReplyToScreenName) {
		this.inReplyToScreenName = inReplyToScreenName;
	}
	public String getInReplyToStatusId() {
		return inReplyToStatusId;
	}
	public void setInReplyToStatusId(String inReplyToStatusId) {
		this.inReplyToStatusId = inReplyToStatusId;
	}
	public String getInReplyToUserId() {
		return inReplyToUserId;
	}
	public void setInReplyToUserId(String inReplyToUserId) {
		this.inReplyToUserId = inReplyToUserId;
	}
	public String getLang() {
		return lang;
	}
	public void setLang(String lang) {
		this.lang = lang;
	}

	public String getRetweetFlag() {
		return retweetFlag;
	}
	public void setRetweetFlag(String retweetFlag) {
		this.retweetFlag = retweetFlag;
	}
	public String getRetweetSourceId() {
		return retweetSourceId;
	}
	public void setRetweetSourceId(String retweetSourceId) {
		this.retweetSourceId = retweetSourceId;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getRetweetCount() {
		return retweetCount;
	}
	public void setRetweetCount(String retweetCount) {
		this.retweetCount = retweetCount;
	}
	public String getGeoLevel() {
		return geoLevel;
	}
	public void setGeoLevel(String geoLevel) {
		this.geoLevel = geoLevel;
	}
	public String getGeoPlace() {
		return geoPlace;
	}
	public void setGeoPlace(String geoPlace) {
		this.geoPlace = geoPlace;
	}
	public String getUserScreenName() {
		return userScreenName;
	}
	public void setUserScreenName(String userScreenName) {
		this.userScreenName = userScreenName;
	}
	public String getLatitude() {
		return latitude;
	}
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}
	public String getLongitude() {
		return longitude;
	}
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	
}
