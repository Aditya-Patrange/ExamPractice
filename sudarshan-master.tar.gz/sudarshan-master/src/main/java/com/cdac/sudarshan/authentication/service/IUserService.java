package com.cdac.sudarshan.authentication.service;

import java.util.Optional;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.cdac.sudarshan.authentication.model.User;

public interface IUserService extends UserDetailsService{

    User saveUser(User user);

    User getUserByUserName(String username);

    Optional<User> fetchUserByUserName(String username);

    boolean getAdditionalSecurity(Long userId);

    void setAdditionalSecurity(Long userId);

    void updateAdditionalSecurity(Long userId);
    UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException;
}
