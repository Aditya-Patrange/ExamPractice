package com.cdac.sudarshan.discover.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

//import com.innefu.innsight.modal.Articel_Comment;
//import com.innefu.innsight.modal.Articel_Ner;
//import com.innefu.innsight.modal.ArticleUserReview;
//import com.innefu.innsight.modal.Article_DailyMotion;
//import com.innefu.innsight.modal.Article_DailyMotion_User;
//import com.innefu.innsight.modal.Article_Datacollection_New;
//import com.innefu.innsight.modal.Article_Fb;
//import com.innefu.innsight.modal.Article_Fb_Page;
//import com.innefu.innsight.modal.Article_GoogleBlogger;
//import com.innefu.innsight.modal.Article_Image;
//import com.innefu.innsight.modal.Article_Instagram;
//import com.innefu.innsight.modal.Article_Media;
//import com.innefu.innsight.modal.Article_NerLocation;
//import com.innefu.innsight.modal.Article_Tweet;
//import com.innefu.innsight.modal.Article_WordPress;
//import com.innefu.innsight.modal.Article_Youtube;
//import com.innefu.innsight.modal.Tw_User;

//import wordcloud.WordFrequency;

public class TwitterVo implements  Serializable 
{
	private static final long serialVersionUID = 1L;
	private String entityId;
	private String tweetText;
	private String tweeterId;
	private String retweetCount;
	private String favouritesCount;
	private String impressionCount;
	private String userId;
	private String screenName;
	private String userName;
	private String createdAt;
	private String userCreatedAt;
	private String avatar;
	private String followersCount;
	private String friendsCount;
	private String retweetFlag;
	private String sentiment;
	private String sentimentScore;
	private String priority;
	private String isDeleted;
	private String hasFollowsups;
	private String followupsText;
	private String readStatus;
	private String hashtag;
	private String hashCount;
	private String hashTagId;
	private String name;
	private String tweetCount;
	private String link;
	private String linkCount;
	private String totalTweetCount;
	private String totalReTweetCount;
	private String description;
	private String listedCount;
	private String location;
	private String statusesCount;
	private String url;
	private String userCount;
	private String timeZone;
	private String retweetSourceId;
	private String source;
	private String geo;
	private String advFilter;
	private String oriTweetInfo;
	private String twLanguage;
	private String mentionCount;
	private String geoCode;
	private String count;
	private String start;
	private String totalReply;
	private String statsDateFrom;
	private String statsDateTo;
	private double tweetRatio;
	private String apiKeys;
	private String max;
	private String min;
	private String followed;
	private String followed_name;
	private String followed_screen_name;
	private String followed_img;
	private String follower;
	private String follower_name;
	private String follower_screen_name;
	private String follower_img;
	private String nodeName1;
	private String nodeName2;
	private String nodeId1;
	private String nodeId2;
	private String nodeType;
	private String nodeScreenName1;
	private String nodeScreenName2;
	private String nodeImg1;
	private String nodeImg2;
	private String documentCount;
	private String latitude;
	private String longitude;
	private String type;
	private String articleId;
	private String articleSummary;
	private String articleEmotion;
	private String articleEmotionScore;
	private String articleSource;
	private String articleType;
	private String articleNewsSource;
	private String articleTitle;
	private String articleSubTitle;
	private String articleBigContent;
	private String articleLinkUrl;
	private String articleAuthor;
	private String articleAuthorId;
	private String articleAuthorImage;
	private String articleAuthorImageUrlLocal;
	private String articleAuthorDescription;
	private String articleAuthorScreenName;
	private String articleLocation;
	private String articleLocationCountry;
	private String articleLocationCountryCode;
	private String articleLocationCity;
	private String articleUserLocation;
	private String articleUserLocationName;
	private String articleUserLocationCountry;
	private String articleUserLocationCountryCode;
	private String articleUserLocationCity;
	private String articleLocationPlace;
	private String articleLanguage;
    private String articlePriority; 
	private String articleNewsCategory;
    private String creationDate;
    private String rssCountryCode;
    private String rssCountry;
    private String profileLocalImage;
    private String coverLocalImage;
    private String innsightImageFlag;
    private String ngServiceUrl;
    private String ftpFileUrl;
    private String federateFileUrl;
    private String innsightLocalImageUrl;
    private String facebookLocalImageUrl; 
    private String linkedinLocalImageUrl;
    private String telegramLocalImageUrl;
    private String defaultDaysOfDataLoad;
    private String articlePriorityFlag;
    private String twoPageReportFlag;
    private String mediaLocalImage;    
    private String absPathLocal;
    private String absPath;

    private String activeMemberCount;
    private String articlePublishDate;
    private String articleMediaCaption;
    private String articleIpAddress;
    
	private ArrayList<String> hashtagLst;
	private ArrayList<String> mentionsLst;
	private ArrayList<String> imageLst;
	private ArrayList<String> videoLst;
	private ArrayList<String> urlLst;
	private ArrayList<String> domainLst;
	private ArrayList<Integer> entityIds;
	private ArrayList<String> articleHashTag; 
	private ArrayList<String> articleMention;
	private ArrayList<String> articleThemes;
	private ArrayList<String> articleDomains; 
	private ArrayList<String> articleTag;
	private ArrayList<String> articleClassification; 
	private ArrayList<String> articleMobile; 
	private ArrayList<String> articleEmail;

	private ArrayList<TwitterVo> twitterVoLst;
	private ArrayList<TwitterChartVo> twitterChartVo;

	private int articleSentiment=9;
	private long articleInsertedDate; 
	private long articleUpdateDate;
	private ArrayList<Integer> articleMarked;
	private ArrayList<ArticleUserReview> articleUserReview;

	private ArrayList<Article_Media> articleMedia;
	private ArrayList<Article_Image> articleImage;
	private ArrayList<Articel_Ner> articlePersonNer;
	private ArrayList<Articel_Ner> articleOrganizationNer;
	private ArrayList<Articel_Ner> articleDateNer;
	private ArrayList<Article_NerLocation> articleLocationNer;
	private ArrayList<Articel_Comment> articleComment;
   
	//Source Object
	private Article_Tweet tweet;
	private Tw_User user;
	private Article_Youtube youtube;
	private Article_DailyMotion dailymotion;
	private Article_Instagram instagram;
	private Article_Fb facebook;
	private Article_WordPress wordpress;
	private Article_GoogleBlogger blogger;
	private List<Article_Datacollection_New> lstArticleDatacollectionNew;
    
	public TwitterVo() {
		
	}
	
	public String getArticleIpAddress() {
		return articleIpAddress;
	}

	public void setArticleIpAddress(String articleIpAddress) {
		this.articleIpAddress = articleIpAddress;
	}

	public TwitterVo(String entityId) {
		this.entityId=entityId;
	}
	public String getFederateFileUrl() {
		return federateFileUrl;
	}
	public void setFederateFileUrl(String federateFileUrl) {
		this.federateFileUrl = federateFileUrl;
	}
	public String getFtpFileUrl() {
		return ftpFileUrl;
	}
	public void setFtpFileUrl(String ftpFileUrl) {
		this.ftpFileUrl = ftpFileUrl;
	}
	
	public String getLinkedinLocalImageUrl() {
		return linkedinLocalImageUrl;
	}
	public void setLinkedinLocalImageUrl(String linkedinLocalImageUrl) {
		this.linkedinLocalImageUrl = linkedinLocalImageUrl;
	}
	public String getTelegramLocalImageUrl() {
		return telegramLocalImageUrl;
	}
	public void setTelegramLocalImageUrl(String telegramLocalImageUrl) {
		this.telegramLocalImageUrl = telegramLocalImageUrl;
	}
	public String getNgServiceUrl() {
		return ngServiceUrl;
	}
	public void setNgServiceUrl(String ngServiceUrl) {
		this.ngServiceUrl = ngServiceUrl;
	}
	public String getArticleMediaCaption() {
		return articleMediaCaption;
	}
	public void setArticleMediaCaption(String articleMediaCaption) {
		this.articleMediaCaption = articleMediaCaption;
	}
	public String getArticleAuthorScreenName() {
		return articleAuthorScreenName;
	}
	public void setArticleAuthorScreenName(String articleAuthorScreenName) {
		this.articleAuthorScreenName = articleAuthorScreenName;
	}
	public String getArticleAuthorDescription() {
		return articleAuthorDescription;
	}
	public void setArticleAuthorDescription(String articleAuthorDescription) {
		this.articleAuthorDescription = articleAuthorDescription;
	}
	public String getInnsightLocalImageUrl() {
		return innsightLocalImageUrl;
	}
	public void setInnsightLocalImageUrl(String innsightLocalImageUrl) {
		this.innsightLocalImageUrl = innsightLocalImageUrl;
	}
	public String getInnsightImageFlag() {
		return innsightImageFlag;
	}
	public void setInnsightImageFlag(String innsightImageFlag) {
		this.innsightImageFlag = innsightImageFlag;
	}
	public String getFacebookLocalImageUrl() {
		return facebookLocalImageUrl;
	}
	public void setFacebookLocalImageUrl(String facebookLocalImageUrl) {
		this.facebookLocalImageUrl = facebookLocalImageUrl;
	}
	public String getDefaultDaysOfDataLoad() {
		return defaultDaysOfDataLoad;
	}
	public void setDefaultDaysOfDataLoad(String defaultDaysOfDataLoad) {
		this.defaultDaysOfDataLoad = defaultDaysOfDataLoad;
	}
	public String getArticlePriorityFlag() {
		return articlePriorityFlag;
	}
	public void setArticlePriorityFlag(String articlePriorityFlag) {
		this.articlePriorityFlag = articlePriorityFlag;
	}
	public String getTwoPageReportFlag() {
		return twoPageReportFlag;
	}
	public void setTwoPageReportFlag(String twoPageReportFlag) {
		this.twoPageReportFlag = twoPageReportFlag;
	}
	
	public String getMediaLocalImage() {
		return mediaLocalImage;
	}
	public void setMediaLocalImage(String mediaLocalImage) {
		this.mediaLocalImage = mediaLocalImage;
	}
	public String getAbsPath() {
		return absPath;
	}
	public void setAbsPath(String absPath) {
		this.absPath = absPath;
	}
	
	public String getActiveMemberCount() {
		return activeMemberCount;
	}
	public void setActiveMemberCount(String activeMemberCount) {
		this.activeMemberCount = activeMemberCount;
	}
	public String getRssCountryCode() {
		return rssCountryCode;
	}
	public void setRssCountryCode(String rssCountryCode) {
		this.rssCountryCode = rssCountryCode;
	}
	public String getRssCountry() {
		return rssCountry;
	}
	public void setRssCountry(String rssCountry) {
		this.rssCountry = rssCountry;
	}
	public ArrayList<Article_Image> getArticleImage() {
		return articleImage;
	}
	public void setArticleImage(ArrayList<Article_Image> articleImage) {
		this.articleImage = articleImage;
	}
	public String getProfileLocalImage() {
		return profileLocalImage;
	}
	public void setProfileLocalImage(String profileLocalImage) {
		this.profileLocalImage = profileLocalImage;
	}
	public String getCoverLocalImage() {
		return coverLocalImage;
	}
	public void setCoverLocalImage(String coverLocalImage) {
		this.coverLocalImage = coverLocalImage;
	}
	public String getAbsPathLocal() {
		return absPathLocal;
	}
	public void setAbsPathLocal(String absPathLocal) {
		this.absPathLocal = absPathLocal;
	}
	public String getArticlePriority() {
		return articlePriority;
	}
	public void setArticlePriority(String articlePriority) {
		this.articlePriority = articlePriority;
	}
	public String getArticleNewsCategory() {
		return articleNewsCategory;
	}
	public void setArticleNewsCategory(String articleNewsCategory) {
		this.articleNewsCategory = articleNewsCategory;
	}
	public String getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}
	public String getFollowed() {
		return followed;
	}
	public void setFollowed(String followed) {
		this.followed = followed;
	}
	public String getFollowed_name() {
		return followed_name;
	}
	public void setFollowed_name(String followed_name) {
		this.followed_name = followed_name;
	}
	public String getFollowed_screen_name() {
		return followed_screen_name;
	}
	public void setFollowed_screen_name(String followed_screen_name) {
		this.followed_screen_name = followed_screen_name;
	}
	public String getFollowed_img() {
		return followed_img;
	}
	public void setFollowed_img(String followed_img) {
		this.followed_img = followed_img;
	}
	public String getFollower() {
		return follower;
	}
	public void setFollower(String follower) {
		this.follower = follower;
	}
	public String getFollower_name() {
		return follower_name;
	}
	public void setFollower_name(String follower_name) {
		this.follower_name = follower_name;
	}
	public String getFollower_screen_name() {
		return follower_screen_name;
	}
	public void setFollower_screen_name(String follower_screen_name) {
		this.follower_screen_name = follower_screen_name;
	}
	public String getFollower_img() {
		return follower_img;
	}
	public void setFollower_img(String follower_img) {
		this.follower_img = follower_img;
	}
	public ArrayList<TwitterChartVo> getTwitterChartVo() {
		return twitterChartVo;
	}
	public void setTwitterChartVo(ArrayList<TwitterChartVo> twitterChartVo) {
		this.twitterChartVo = twitterChartVo;
	}
	public ArrayList<String> getHashtagLst() {
		return hashtagLst;
	}
	public void setHashtagLst(ArrayList<String> hashtagLst) {
		this.hashtagLst = hashtagLst;
	}
	public ArrayList<String> getMentionsLst() {
		return mentionsLst;
	}
	public void setMentionsLst(ArrayList<String> mentionsLst) {
		this.mentionsLst = mentionsLst;
	}
	public ArrayList<String> getImageLst() {
		return imageLst;
	}
	public void setImageLst(ArrayList<String> imageLst) {
		this.imageLst = imageLst;
	}
	public ArrayList<String> getVideoLst() {
		return videoLst;
	}
	public void setVideoLst(ArrayList<String> videoLst) {
		this.videoLst = videoLst;
	}
	public ArrayList<String> getUrlLst() {
		return urlLst;
	}
	public void setUrlLst(ArrayList<String> urlLst) {
		this.urlLst = urlLst;
	}
	public ArrayList<String> getDomainLst() {
		return domainLst;
	}
	public void setDomainLst(ArrayList<String> domainLst) {
		this.domainLst = domainLst;
	}
	public Tw_User getUser() {
		return user;
	}
	public void setUser(Tw_User user) {
		this.user = user;
	}
	public ArrayList<TwitterVo> getTwitterVoLst() {
		return twitterVoLst;
	}
	public void setTwitterVoLst(ArrayList<TwitterVo> twitterVoLst) {
		this.twitterVoLst = twitterVoLst;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getLatitude() {
		return latitude;
	}
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}
	public String getLongitude() {
		return longitude;
	}
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}
	public String getNodeType() {
		return nodeType;
	}
	public void setNodeType(String nodeType) {
		this.nodeType = nodeType;
	}
	public String getNodeName1() {
		return nodeName1;
	}
	public void setNodeName1(String nodeName1) {
		this.nodeName1 = nodeName1;
	}
	public String getNodeName2() {
		return nodeName2;
	}
	public void setNodeName2(String nodeName2) {
		this.nodeName2 = nodeName2;
	}
	public String getNodeId1() {
		return nodeId1;
	}
	public void setNodeId1(String nodeId1) {
		this.nodeId1 = nodeId1;
	}
	public String getNodeId2() {
		return nodeId2;
	}
	public void setNodeId2(String nodeId2) {
		this.nodeId2 = nodeId2;
	}
	public String getMax() {
		return max;
	}
	public void setMax(String max) {
		this.max = max;
	}
	public String getMin() {
		return min;
	}
	public void setMin(String min) {
		this.min = min;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public String getApiKeys() {
		return apiKeys;
	}
	public void setApiKeys(String apiKeys) {
		this.apiKeys = apiKeys;
	}
	public String getTotalReply() {
		return totalReply;
	}
	public void setTotalReply(String totalReply) {
		this.totalReply = totalReply;
	}
	public String getStatsDateFrom() {
		return statsDateFrom;
	}
	public void setStatsDateFrom(String statsDateFrom) {
		this.statsDateFrom = statsDateFrom;
	}
	public String getStatsDateTo() {
		return statsDateTo;
	}
	public void setStatsDateTo(String statsDateTo) {
		this.statsDateTo = statsDateTo;
	}
	public double getTweetRatio() {
		return tweetRatio;
	}
	public void setTweetRatio(double tweetRatio) {
		this.tweetRatio = tweetRatio;
	}
	public String getStart() {
		return start;
	}
	public void setStart(String start) {
		this.start = start;
	}
	public String getCount() {
		return count;
	}
	public void setCount(String count) {
		this.count = count;
	}
	private  List<WordFrequency> wordFrequencies;  //for word cloud

	public List<WordFrequency> getWordFrequencies() {
		return wordFrequencies;
	}
	public void setWordFrequencies(List<WordFrequency> wordFrequencies) {
		this.wordFrequencies = wordFrequencies;
	}
	public String getGeoCode() {
		return geoCode;
	}
	public void setGeoCode(String geoCode) {
		this.geoCode = geoCode;
	}
	public String getMentionCount() {
		return mentionCount;
	}
	public void setMentionCount(String mentionCount) {
		this.mentionCount = mentionCount;
	}
	public String getTwLanguage() {
		return twLanguage;
	}
	public void setTwLanguage(String twLanguage) {
		this.twLanguage = twLanguage;
	}
	public String getOriTweetInfo() {
		return oriTweetInfo;
	}
	public void setOriTweetInfo(String oriTweetInfo) {
		this.oriTweetInfo = oriTweetInfo;
	}
	public String getGeo() {
		return geo;
	}
	public void setGeo(String geo) {
		this.geo = geo;
	}
	public String getAdvFilter() {
		return advFilter;
	}
	public void setAdvFilter(String advFilter) {
		this.advFilter = advFilter;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getRetweetSourceId() {
		return retweetSourceId;
	}
	public void setRetweetSourceId(String retweetSourceId) {
		this.retweetSourceId = retweetSourceId;
	}
	public String getTimeZone() {
		return timeZone;
	}
	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}
	public String getUserCount() {
		return userCount;
	}
	public void setUserCount(String userCount) {
		this.userCount = userCount;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getListedCount() {
		return listedCount;
	}
	public void setListedCount(String listedCount) {
		this.listedCount = listedCount;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getStatusesCount() {
		return statusesCount;
	}
	public void setStatusesCount(String statusesCount) {
		this.statusesCount = statusesCount;
	}
	public String getTotalTweetCount() {
		return totalTweetCount;
	}
	public void setTotalTweetCount(String totalTweetCount) {
		this.totalTweetCount = totalTweetCount;
	}
	public String getTotalReTweetCount() {
		return totalReTweetCount;
	}
	public void setTotalReTweetCount(String totalReTweetCount) {
		this.totalReTweetCount = totalReTweetCount;
	}
	public String getLink() {
		return link;
	}
	public void setLink(String link) {
		this.link = link;
	}
	public String getLinkCount() {
		return linkCount;
	}
	public void setLinkCount(String linkCount) {
		this.linkCount = linkCount;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public String getTweetCount() {
		return tweetCount;
	}
	public void setTweetCount(String tweetCount) {
		this.tweetCount = tweetCount;
	}
	public String getHashtag() {
		return hashtag;
	}
	public void setHashtag(String hashtag) {
		this.hashtag = hashtag;
	}
	public String getHashCount() {
		return hashCount;
	}
	public void setHashCount(String hashCount) {
		this.hashCount = hashCount;
	}
	public String getHashTagId() {
		return hashTagId;
	}
	public void setHashTagId(String hashTagId) {
		this.hashTagId = hashTagId;
	}
	public String getIsDeleted() {
		return isDeleted;
	}
	public void setIsDeleted(String isDeleted) {
		this.isDeleted = isDeleted;
	}
	public String getEntityId() {
		return entityId;
	}
	public void setEntityId(String entityId) {
		this.entityId = entityId;
	}
	public String getTweetText() {
		return tweetText;
	}
	public void setTweetText(String tweetText) {
		this.tweetText = tweetText;
	}
	public String getTweeterId() {
		return tweeterId;
	}
	public void setTweeterId(String tweeterId) {
		this.tweeterId = tweeterId;
	}
	public String getRetweetCount() {
		return retweetCount;
	}
	public void setRetweetCount(String retweetCount) {
		this.retweetCount = retweetCount;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getScreenName() {
		return screenName;
	}
	public void setScreenName(String screenName) {
		this.screenName = screenName;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}
	public String getUserCreatedAt() {
		return userCreatedAt;
	}
	public void setUserCreatedAt(String userCreatedAt) {
		this.userCreatedAt = userCreatedAt;
	}
	public String getAvatar() {
		return avatar;
	}
	public void setAvatar(String avatar) {
		this.avatar = avatar;
	}
	public String getFavouritesCount() {
		return favouritesCount;
	}
	public void setFavouritesCount(String favouritesCount) {
		this.favouritesCount = favouritesCount;
	}
	public String getImpressionCount() {
		return impressionCount;
	}
	public void setImpressionCount(String impressionCount) {
		this.impressionCount = impressionCount;
	}
	public String getFollowersCount() {
		return followersCount;
	}
	public void setFollowersCount(String followersCount) {
		this.followersCount = followersCount;
	}
	public String getFriendsCount() {
		return friendsCount;
	}
	public void setFriendsCount(String friendsCount) {
		this.friendsCount = friendsCount;
	}
	public String getRetweetFlag() {
		return retweetFlag;
	}
	public void setRetweetFlag(String retweetFlag) {
		this.retweetFlag = retweetFlag;
	}
	public String getSentiment() {
		return sentiment;
	}
	public void setSentiment(String sentiment) {
		this.sentiment = sentiment;
	}
	public String getSentimentScore() {
		return sentimentScore;
	}
	public void setSentimentScore(String sentimentScore) {
		this.sentimentScore = sentimentScore;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	public String getHasFollowsups() {
		return hasFollowsups;
	}
	public void setHasFollowsups(String hasFollowsups) {
		this.hasFollowsups = hasFollowsups;
	}
	public String getFollowupsText() {
		return followupsText;
	}
	public void setFollowupsText(String followupsText) {
		this.followupsText = followupsText;
	}
	public String getReadStatus() {
		return readStatus;
	}
	public void setReadStatus(String readStatus) {
		this.readStatus = readStatus;
	}

	private Article_Fb_Page fbPage;

	public Article_Fb_Page getFbPage() {
		return fbPage;
	}
	public void setFbPage(Article_Fb_Page fbPage) {
		this.fbPage = fbPage;
	}

	private Article_DailyMotion_User dmUser;

	public Article_DailyMotion_User getDmUser() {
		return dmUser;
	}
	public void setDmUser(Article_DailyMotion_User dmUser) {
		this.dmUser = dmUser;
	}

	public ArrayList<String> getArticleMobile() {
		return articleMobile;
	}
	public void setArticleMobile(ArrayList<String> articleMobile) {
		this.articleMobile = articleMobile;
	}
	public ArrayList<String> getArticleEmail() {
		return articleEmail;
	}
	public void setArticleEmail(ArrayList<String> articleEmail) {
		this.articleEmail = articleEmail;
	}

	public String getArticleId() {
		return articleId;
	}
	public void setArticleId(String articleId) {
		this.articleId = articleId;
	}
	public String getArticleSource() {
		return articleSource;
	}
	public void setArticleSource(String articleSource) {
		this.articleSource = articleSource;
	}
	public String getArticleType() {
		return articleType;
	}
	public void setArticleType(String articleType) {
		this.articleType = articleType;
	}
	public String getArticleNewsSource() {
		return articleNewsSource;
	}
	public void setArticleNewsSource(String articleNewsSource) {
		this.articleNewsSource = articleNewsSource;
	}
	public String getArticleTitle() {
		return articleTitle;
	}
	public void setArticleTitle(String articleTitle) {
		this.articleTitle = articleTitle;
	}
	public String getArticleSubTitle() {
		return articleSubTitle;
	}
	public void setArticleSubTitle(String articleSubTitle) {
		this.articleSubTitle = articleSubTitle;
	}
	public String getArticleBigContent() {
		return articleBigContent;
	}
	public void setArticleBigContent(String articleBigContent) {
		this.articleBigContent = articleBigContent;
	}
	public String getArticleLinkUrl() {
		return articleLinkUrl;
	}
	public void setArticleLinkUrl(String articleLinkUrl) {
		this.articleLinkUrl = articleLinkUrl;
	}
	public String getArticleAuthor() {
		return articleAuthor;
	}
	public void setArticleAuthor(String articleAuthor) {
		this.articleAuthor = articleAuthor;
	}
	public String getArticleAuthorId() {
		return articleAuthorId;
	}
	public void setArticleAuthorId(String articleAuthorId) {
		this.articleAuthorId = articleAuthorId;
	}
	public String getArticleAuthorImage() {
		return articleAuthorImage;
	}
	public void setArticleAuthorImage(String articleAuthorImage) {
		this.articleAuthorImage = articleAuthorImage;
	}
	public String getArticleLocation() {
		return articleLocation;
	}
	public void setArticleLocation(String articleLocation) {
		this.articleLocation = articleLocation;
	}
	public String getArticleLocationCountry() {
		return articleLocationCountry;
	}
	public void setArticleLocationCountry(String articleLocationCountry) {
		this.articleLocationCountry = articleLocationCountry;
	}
	public String getArticleLocationCountryCode() {
		return articleLocationCountryCode;
	}
	public void setArticleLocationCountryCode(String articleLocationCountryCode) {
		this.articleLocationCountryCode = articleLocationCountryCode;
	}
	public String getArticleLocationCity() {
		return articleLocationCity;
	}
	public void setArticleLocationCity(String articleLocationCity) {
		this.articleLocationCity = articleLocationCity;
	}
	public String getArticleUserLocation() {
		return articleUserLocation;
	}
	public void setArticleUserLocation(String articleUserLocation) {
		this.articleUserLocation = articleUserLocation;
	}
	public String getArticleUserLocationName() {
		return articleUserLocationName;
	}
	public void setArticleUserLocationName(String articleUserLocationName) {
		this.articleUserLocationName = articleUserLocationName;
	}
	public String getArticleUserLocationCountry() {
		return articleUserLocationCountry;
	}
	public void setArticleUserLocationCountry(String articleUserLocationCountry) {
		this.articleUserLocationCountry = articleUserLocationCountry;
	}
	public String getArticleUserLocationCountryCode() {
		return articleUserLocationCountryCode;
	}
	public void setArticleUserLocationCountryCode(String articleUserLocationCountryCode) {
		this.articleUserLocationCountryCode = articleUserLocationCountryCode;
	}
	public String getArticleUserLocationCity() {
		return articleUserLocationCity;
	}
	public void setArticleUserLocationCity(String articleUserLocationCity) {
		this.articleUserLocationCity = articleUserLocationCity;
	}
	public String getArticleLocationPlace() {
		return articleLocationPlace;
	}
	public void setArticleLocationPlace(String articleLocationPlace) {
		this.articleLocationPlace = articleLocationPlace;
	}
	public String getArticleLanguage() {
		return articleLanguage;
	}
	public String getArticleAuthorImageUrlLocal() {
		return articleAuthorImageUrlLocal;
	}
	public void setArticleAuthorImageUrlLocal(String articleAuthorImageUrlLocal) {
		this.articleAuthorImageUrlLocal = articleAuthorImageUrlLocal;
	}
	public void setArticleLanguage(String articleLanguage) {
		this.articleLanguage = articleLanguage;
	}
	public int getArticleSentiment() {
		return articleSentiment;
	}
	public void setArticleSentiment(int articleSentiment) {
		this.articleSentiment = articleSentiment;
	}
	public ArrayList<Integer> getArticleMarked() {
		return articleMarked;
	}
	public void setArticleMarked(ArrayList<Integer> articleMarked) {
		this.articleMarked = articleMarked;
	}
	public ArrayList<ArticleUserReview> getArticleUserReview() {
		return articleUserReview;
	}
	public void setArticleUserReview(ArrayList<ArticleUserReview> articleUserReview) {
		this.articleUserReview = articleUserReview;
	}
	public ArrayList<Integer> getEntityIds() {
		return entityIds;
	}
	public void setEntityIds(ArrayList<Integer> entityIds) {
		this.entityIds = entityIds;
	}
	public ArrayList<String> getArticleHashTag() {
		return articleHashTag;
	}
	public void setArticleHashTag(ArrayList<String> articleHashTag) {
		this.articleHashTag = articleHashTag;
	}
	public ArrayList<String> getArticleMention() {
		return articleMention;
	}
	public void setArticleMention(ArrayList<String> articleMention) {
		this.articleMention = articleMention;
	}
	public ArrayList<String> getArticleThemes() {
		return articleThemes;
	}
	public void setArticleThemes(ArrayList<String> articleThemes) {
		this.articleThemes = articleThemes;
	}
	public ArrayList<String> getArticleDomains() {
		return articleDomains;
	}
	public void setArticleDomains(ArrayList<String> articleDomains) {
		this.articleDomains = articleDomains;
	}
	public ArrayList<String> getArticleTag() {
		return articleTag;
	}
	public void setArticleTag(ArrayList<String> articleTag) {
		this.articleTag = articleTag;
	}
	public long getArticleInsertedDate() {
		return articleInsertedDate;
	}
	public void setArticleInsertedDate(long articleInsertedDate) {
		this.articleInsertedDate = articleInsertedDate;
	}
	public String getArticlePublishDate() {
		return articlePublishDate;
	}
	public void setArticlePublishDate(String articlePublishDate) {
		this.articlePublishDate = articlePublishDate;
	}
	public long getArticleUpdateDate() {
		return articleUpdateDate;
	}
	public void setArticleUpdateDate(long articleUpdateDate) {
		this.articleUpdateDate = articleUpdateDate;
	}
	public ArrayList<Article_Media> getArticleMedia() {
		return articleMedia;
	}
	public void setArticleMedia(ArrayList<Article_Media> articleMedia) {
		this.articleMedia = articleMedia;
	}
	public ArrayList<Articel_Ner> getArticlePersonNer() {
		return articlePersonNer;
	}
	public void setArticlePersonNer(ArrayList<Articel_Ner> articlePersonNer) {
		this.articlePersonNer = articlePersonNer;
	}
	public ArrayList<Articel_Ner> getArticleOrganizationNer() {
		return articleOrganizationNer;
	}
	public void setArticleOrganizationNer(
			ArrayList<Articel_Ner> articleOrganizationNer) {
		this.articleOrganizationNer = articleOrganizationNer;
	}

	public ArrayList<Articel_Ner> getArticleDateNer() {
		return articleDateNer;
	}
	public void setArticleDateNer(ArrayList<Articel_Ner> articleDateNer) {
		this.articleDateNer = articleDateNer;
	}

	public ArrayList<Article_NerLocation> getArticleLocationNer() {
		return articleLocationNer;
	}
	public void setArticleLocationNer(
			ArrayList<Article_NerLocation> articleLocationNer) {
		this.articleLocationNer = articleLocationNer;
	}
	public ArrayList<Articel_Comment> getArticleComment() {
		return articleComment;
	}
	public void setArticleComment(ArrayList<Articel_Comment> articleComment) {
		this.articleComment = articleComment;
	}
	public Article_Tweet getTweet() {
		return tweet;
	}
	public void setTweet(Article_Tweet tweet) {
		this.tweet = tweet;
	}
	public Article_Youtube getYoutube() {
		return youtube;
	}
	public void setYoutube(Article_Youtube youtube) {
		this.youtube = youtube;
	}
	public Article_DailyMotion getDailymotion() {
		return dailymotion;
	}
	public void setDailymotion(Article_DailyMotion dailymotion) {
		this.dailymotion = dailymotion;
	}
	public Article_Instagram getInstagram() {
		return instagram;
	}
	public void setInstagram(Article_Instagram instagram) {
		this.instagram = instagram;
	}
	public Article_Fb getFacebook() {
		return facebook;
	}
	public void setFacebook(Article_Fb facebook) {
		this.facebook = facebook;
	}
	public Article_WordPress getWordpress() {
		return wordpress;
	}
	public void setWordpress(Article_WordPress wordpress) {
		this.wordpress = wordpress;
	}
	
	public Article_GoogleBlogger getBlogger() {
		return blogger;
	}
	public void setBlogger(Article_GoogleBlogger blogger) {
		this.blogger = blogger;
	}
	public String getArticleSummary() {
		return articleSummary;
	}
	public void setArticleSummary(String articleSummary) {
		this.articleSummary = articleSummary;
	}
	public String getArticleEmotion() {
		return articleEmotion;
	}
	public void setArticleEmotion(String articleEmotion) {
		this.articleEmotion = articleEmotion;
	}
	public String getArticleEmotionScore() {
		return articleEmotionScore;
	}
	public void setArticleEmotionScore(String articleEmotionScore) {
		this.articleEmotionScore = articleEmotionScore;
	}
	public ArrayList<String> getArticleClassification() {
		return articleClassification;
	}
	public void setArticleClassification(ArrayList<String> articleClassification) {
		this.articleClassification = articleClassification;
	}
	public List<Article_Datacollection_New> getLstArticleDatacollectionNew() {
		return lstArticleDatacollectionNew;
	}
	public void setLstArticleDatacollectionNew(List<Article_Datacollection_New> lstArticleDatacollectionNew) {
		this.lstArticleDatacollectionNew = lstArticleDatacollectionNew;
	}
	public String getNodeScreenName1() {
		return nodeScreenName1;
	}
	public void setNodeScreenName1(String nodeScreenName1) {
		this.nodeScreenName1 = nodeScreenName1;
	}
	public String getNodeScreenName2() {
		return nodeScreenName2;
	}
	public void setNodeScreenName2(String nodeScreenName2) {
		this.nodeScreenName2 = nodeScreenName2;
	}
	public String getNodeImg1() {
		return nodeImg1;
	}
	public void setNodeImg1(String nodeImg1) {
		this.nodeImg1 = nodeImg1;
	}
	public String getNodeImg2() {
		return nodeImg2;
	}
	public void setNodeImg2(String nodeImg2) {
		this.nodeImg2 = nodeImg2;
	}
	public String getDocumentCount() {
		return documentCount;
	}
	public void setDocumentCount(String documentCount) {
		this.documentCount = documentCount;
	}

	@Override
	public String toString() {
		return "TwitterVo [entityId=" + entityId + ", tweetText=" + tweetText + ", tweeterId=" + tweeterId
				+ ", retweetCount=" + retweetCount + ", favouritesCount=" + favouritesCount + ", impressionCount="
				+ impressionCount + ", userId=" + userId + ", screenName=" + screenName + ", userName=" + userName
				+ ", createdAt=" + createdAt + ", userCreatedAt=" + userCreatedAt + ", avatar=" + avatar
				+ ", followersCount=" + followersCount + ", friendsCount=" + friendsCount + ", retweetFlag="
				+ retweetFlag + ", sentiment=" + sentiment + ", sentimentScore=" + sentimentScore + ", priority="
				+ priority + ", isDeleted=" + isDeleted + ", hasFollowsups=" + hasFollowsups + ", followupsText="
				+ followupsText + ", readStatus=" + readStatus + ", hashtag=" + hashtag + ", hashCount=" + hashCount
				+ ", hashTagId=" + hashTagId + ", name=" + name + ", tweetCount=" + tweetCount + ", link=" + link
				+ ", linkCount=" + linkCount + ", totalTweetCount=" + totalTweetCount + ", totalReTweetCount="
				+ totalReTweetCount + ", description=" + description + ", listedCount=" + listedCount + ", location="
				+ location + ", statusesCount=" + statusesCount + ", url=" + url + ", userCount=" + userCount
				+ ", timeZone=" + timeZone + ", retweetSourceId=" + retweetSourceId + ", source=" + source + ", geo="
				+ geo + ", advFilter=" + advFilter + ", oriTweetInfo=" + oriTweetInfo + ", twLanguage=" + twLanguage
				+ ", mentionCount=" + mentionCount + ", geoCode=" + geoCode + ", count=" + count + ", start=" + start
				+ ", totalReply=" + totalReply + ", statsDateFrom=" + statsDateFrom + ", statsDateTo=" + statsDateTo
				+ ", tweetRatio=" + tweetRatio + ", apiKeys=" + apiKeys + ", max=" + max + ", min=" + min
				+ ", followed=" + followed + ", followed_name=" + followed_name + ", followed_screen_name="
				+ followed_screen_name + ", followed_img=" + followed_img + ", follower=" + follower
				+ ", follower_name=" + follower_name + ", follower_screen_name=" + follower_screen_name
				+ ", follower_img=" + follower_img + ", nodeName1=" + nodeName1 + ", nodeName2=" + nodeName2
				+ ", nodeId1=" + nodeId1 + ", nodeId2=" + nodeId2 + ", nodeType=" + nodeType + ", nodeScreenName1="
				+ nodeScreenName1 + ", nodeScreenName2=" + nodeScreenName2 + ", nodeImg1=" + nodeImg1 + ", nodeImg2="
				+ nodeImg2 + ", documentCount=" + documentCount + ", latitude=" + latitude + ", longitude=" + longitude
				+ ", type=" + type + ", articleId=" + articleId + ", articleSummary=" + articleSummary
				+ ", articleEmotion=" + articleEmotion + ", articleEmotionScore=" + articleEmotionScore
				+ ", articleSource=" + articleSource + ", articleType=" + articleType + ", articleNewsSource="
				+ articleNewsSource + ", articleTitle=" + articleTitle + ", articleSubTitle=" + articleSubTitle
				+ ", articleBigContent=" + articleBigContent + ", articleLinkUrl=" + articleLinkUrl + ", articleAuthor="
				+ articleAuthor + ", articleAuthorId=" + articleAuthorId + ", articleAuthorImage=" + articleAuthorImage
				+ ", articleAuthorImageUrlLocal=" + articleAuthorImageUrlLocal + ", articleAuthorDescription="
				+ articleAuthorDescription + ", articleAuthorScreenName=" + articleAuthorScreenName
				+ ", articleLocation=" + articleLocation + ", articleLocationCountry=" + articleLocationCountry
				+ ", articleLocationCountryCode=" + articleLocationCountryCode + ", articleLocationCity="
				+ articleLocationCity + ", articleUserLocation=" + articleUserLocation + ", articleUserLocationName="
				+ articleUserLocationName + ", articleUserLocationCountry=" + articleUserLocationCountry
				+ ", articleUserLocationCountryCode=" + articleUserLocationCountryCode + ", articleUserLocationCity="
				+ articleUserLocationCity + ", articleLocationPlace=" + articleLocationPlace + ", articleLanguage="
				+ articleLanguage + ", articlePriority=" + articlePriority + ", articleNewsCategory="
				+ articleNewsCategory + ", creationDate=" + creationDate + ", rssCountryCode=" + rssCountryCode
				+ ", rssCountry=" + rssCountry + ", profileLocalImage=" + profileLocalImage + ", coverLocalImage="
				+ coverLocalImage + ", innsightImageFlag=" + innsightImageFlag + ", ngServiceUrl=" + ngServiceUrl
				+ ", ftpFileUrl=" + ftpFileUrl + ", federateFileUrl=" + federateFileUrl + ", innsightLocalImageUrl="
				+ innsightLocalImageUrl + ", facebookLocalImageUrl=" + facebookLocalImageUrl
				+ ", linkedinLocalImageUrl=" + linkedinLocalImageUrl + ", telegramLocalImageUrl="
				+ telegramLocalImageUrl + ", defaultDaysOfDataLoad=" + defaultDaysOfDataLoad + ", articlePriorityFlag="
				+ articlePriorityFlag + ", twoPageReportFlag=" + twoPageReportFlag + ", mediaLocalImage="
				+ mediaLocalImage + ", absPathLocal=" + absPathLocal + ", absPath=" + absPath + ", activeMemberCount="
				+ activeMemberCount + ", articlePublishDate=" + articlePublishDate + ", articleMediaCaption="
				+ articleMediaCaption + ", articleIpAddress=" + articleIpAddress + ", hashtagLst=" + hashtagLst
				+ ", mentionsLst=" + mentionsLst + ", imageLst=" + imageLst + ", videoLst=" + videoLst + ", urlLst="
				+ urlLst + ", domainLst=" + domainLst + ", entityIds=" + entityIds + ", articleHashTag="
				+ articleHashTag + ", articleMention=" + articleMention + ", articleThemes=" + articleThemes
				+ ", articleDomains=" + articleDomains + ", articleTag=" + articleTag + ", articleClassification="
				+ articleClassification + ", articleMobile=" + articleMobile + ", articleEmail=" + articleEmail
				+ ", twitterVoLst=" + twitterVoLst + ", twitterChartVo=" + twitterChartVo + ", articleSentiment="
				+ articleSentiment + ", articleInsertedDate=" + articleInsertedDate + ", articleUpdateDate="
				+ articleUpdateDate + ", articleMarked=" + articleMarked + ", articleUserReview=" + articleUserReview
				+ ", articleMedia=" + articleMedia + ", articleImage=" + articleImage + ", articlePersonNer="
				+ articlePersonNer + ", articleOrganizationNer=" + articleOrganizationNer + ", articleDateNer="
				+ articleDateNer + ", articleLocationNer=" + articleLocationNer + ", articleComment=" + articleComment
				+ ", tweet=" + tweet + ", user=" + user + ", youtube=" + youtube + ", dailymotion=" + dailymotion
				+ ", instagram=" + instagram + ", facebook=" + facebook + ", wordpress=" + wordpress + ", blogger="
				+ blogger + ", lstArticleDatacollectionNew=" + lstArticleDatacollectionNew + ", wordFrequencies="
				+ wordFrequencies + ", fbPage=" + fbPage + ", dmUser=" + dmUser + "]";
	}

	
}
