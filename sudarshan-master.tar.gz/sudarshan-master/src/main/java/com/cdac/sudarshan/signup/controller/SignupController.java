package com.cdac.sudarshan.signup.controller;

import com.cdac.sudarshan.authentication.dto.UserDto;
import com.cdac.sudarshan.dto.SignupResponseDto;
import com.cdac.sudarshan.signup.services.ISignUpService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@Slf4j
@CrossOrigin
public class SignupController {

    @Autowired
    private ISignUpService signUpService;


/*	@PostMapping("/signup")
	public SignupResponseDto signup(@RequestBody User user) {

		LOGGER.info("Inside " + getClass().getName());

		User dbUser = userService.getUserByUserName(user.getUsername());
		//Long count = dbUser.stream().count();

		*//*if (count > 0) {
			return new SignupResponseDto(SignupResponseDto.Status.USERNAME_TAKEN);
		}*//*

		Status status = this.passwordPolicy.check(user.getPassword());
		if (status != Status.OK) {
			return new SignupResponseDto(SignupResponseDto.Status.WEAK_PASSWORD);
		}

		if (user.isTotp()) {
			String secret = Base32.random();

			CHARACTERS = (secret + "1234567890").toCharArray();
			if (codes.size() != 9) {
				for (String code : GenerateRandomOTP.generateCodes(9, CHARACTERS, CODE_LENGTH, GROUPS_NBR)) {
					codes.add(code);
				}
			} else {
				codes = new ArrayList<>();
				for (String code : GenerateRandomOTP.generateCodes(9, CHARACTERS, CODE_LENGTH, GROUPS_NBR)) {
					codes.add(code);
				}
			}

			User createdUser = new User(user.getUsername(), this.passwordEncoder.encode(user.getPassword()), secret,
					true, false);
			User saveUser = userService.saveUser(createdUser);
			List<Code> secretCodes = new ArrayList<>();

			for (String str : codes) {
				secretCodes.add(new Code(str, saveUser));
			}

			saveUser.setCodes(secretCodes);
			codeService.saveCode(secretCodes);

			System.out.println(saveUser.getCodes());

			Map<Integer, Object> codesMap = new HashMap<>();

			int i = 0;

			for (String s : codes) {
				codesMap.put(i, s);
				i++;
			}

			SignupResponseDto signupResponse = new SignupResponseDto(SignupResponseDto.Status.OK, user.getUsername(),
					secret, codesMap);

			// System.out.println(signupResponse.toString());

			System.out.println(codesMap);
			return signupResponse;
		}

		User withOut2FaUser = new User(user.getUsername(), this.passwordEncoder.encode(user.getPassword()), null, true,
				false);

		userService.saveUser(withOut2FaUser);

		return new SignupResponseDto(SignupResponseDto.Status.OK, withOut2FaUser.getUsername(),
				withOut2FaUser.getSecret());

	}*/

    @PostMapping("/signup")
    public SignupResponseDto signup(@RequestBody UserDto userDto) {

        SignupResponseDto signupResponseDto = signUpService.signup(userDto);
        return signupResponseDto;

    }

    @PostMapping("/signup-confirm-secret")
    public ResponseEntity<?> signupConfirmSecret(@RequestBody Map<String, String> loggedInuser) {

        ResponseEntity<?> responseEntity = signUpService.signupConfirmSecret(loggedInuser);
        return responseEntity;

    }

}
