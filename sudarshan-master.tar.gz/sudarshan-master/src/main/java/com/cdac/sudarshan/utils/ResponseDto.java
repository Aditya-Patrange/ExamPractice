package com.cdac.sudarshan.utils;

import lombok.*;
import lombok.Data;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class ResponseDto {

	private String message;
	private Boolean success;
	private int statusCode;
}
