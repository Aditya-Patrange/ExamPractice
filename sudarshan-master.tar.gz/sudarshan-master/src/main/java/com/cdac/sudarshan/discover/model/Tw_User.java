package com.cdac.sudarshan.discover.model;

import java.io.Serializable;

public class Tw_User implements Serializable 
{
	private static final long serialVersionUID = 1L;
	private	String id;
	private	String description;
	private	String geoEnabled;
	private	String lang;
	private	String locationUser;
	private	String country;
	private	String countryCode;
	private	String lat;
	private	String lon;
	private	String latLongLocation;
	private	String userName;
	private	String name;
	private	String profileImageUrl;
	private	String profileImageUrlHttps;
	private	String screenName;
	private	String timeZone;
	private	String userUrl;
	private	String verified;
	private	String utcOffset;
	private Long createdAt;
	private	int favouritesCount;
	private	int followersCount;
	private	int friendsCount;
	private	int listedCount;
	private	int statusesCount;

	public String getLat() {
		return lat;
	}
	public void setLat(String lat) {
		this.lat = lat;
	}
	public String getLon() {
		return lon;
	}
	public void setLon(String lon) {
		this.lon = lon;
	}
	public String getLatLongLocation() {
		return latLongLocation;
	}
	public void setLatlongLocation(String latLongLocation) {
		this.latLongLocation = latLongLocation;
	}
	public String getLocationUser() {
		return locationUser;
	}
	public void setLocationUser(String locationUser) {
		this.locationUser = locationUser;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getUserUrl() {
		return userUrl;
	}
	public void setUserUrl(String userUrl) {
		this.userUrl = userUrl;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getFavouritesCount() {
		return favouritesCount;
	}
	public void setFavouritesCount(int favouritesCount) {
		this.favouritesCount = favouritesCount;
	}
	public int getFollowersCount() {
		return followersCount;
	}
	public void setFollowersCount(int followersCount) {
		this.followersCount = followersCount;
	}
	public int getFriendsCount() {
		return friendsCount;
	}
	public void setFriendsCount(int friendsCount) {
		this.friendsCount = friendsCount;
	}
	public String getGeoEnabled() {
		return geoEnabled;
	}
	public void setGeoEnabled(String geoEnabled) {
		this.geoEnabled = geoEnabled;
	}
	public String getLang() {
		return lang;
	}
	public void setLang(String lang) {
		this.lang = lang;
	}
	public int getListedCount() {
		return listedCount;
	}
	public void setListedCount(int listedCount) {
		this.listedCount = listedCount;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getProfileImageUrl() {
		return profileImageUrl;
	}
	public void setProfileImageUrl(String profileImageUrl) {
		this.profileImageUrl = profileImageUrl;
	}
	public String getProfileImageUrlHttps() {
		return profileImageUrlHttps;
	}
	public void setProfileImageUrlHttps(String profileImageUrlHttps) {
		this.profileImageUrlHttps = profileImageUrlHttps;
	}
	public String getScreenName() {
		return screenName;
	}
	public void setScreenName(String screenName) {
		this.screenName = screenName;
	}
	public int getStatusesCount() {
		return statusesCount;
	}
	public void setStatusesCount(int statusesCount) {
		this.statusesCount = statusesCount;
	}
	public String getTimeZone() {
		return timeZone;
	}
	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}
	public String getVerified() {
		return verified;
	}
	public void setVerified(String verified) {
		this.verified = verified;
	}
	public String getUtcOffset() {
		return utcOffset;
	}
	public void setUtcOffset(String utcOffset) {
		this.utcOffset = utcOffset;
	}
	public Long getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(Long createdAt) {
		this.createdAt = createdAt;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public void setLatLongLocation(String latLongLocation) {
		this.latLongLocation = latLongLocation;
	}
	@Override
	public String toString() {
		return "Tw_User [id=" + id + ", createdAt=" + createdAt + ", description=" + description + ", favouritesCount="
				+ favouritesCount + ", followersCount=" + followersCount + ", friendsCount=" + friendsCount
				+ ", geoEnabled=" + geoEnabled + ", lang=" + lang + ", listedCount=" + listedCount + ", locationUser="
				+ locationUser + ", country=" + country + ", countryCode=" + countryCode + ", lat=" + lat + ", lon="
				+ lon + ", latLongLocation=" + latLongLocation + ", userName=" + userName + ", name=" + name
				+ ", profileImageUrl=" + profileImageUrl + ", profileImageUrlHttps=" + profileImageUrlHttps
				+ ", screenName=" + screenName + ", statusesCount=" + statusesCount + ", timeZone=" + timeZone
				+ ", userUrl=" + userUrl + ", verified=" + verified + ", utcOffset=" + utcOffset + "]";
	}
	
}
