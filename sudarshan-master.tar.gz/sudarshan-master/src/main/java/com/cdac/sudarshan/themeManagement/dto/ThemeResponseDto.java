package com.cdac.sudarshan.themeManagement.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ThemeResponseDto {
    private String themeId;
    private String themeName;
    private String parentThemeId;
    private Long userId;
}
