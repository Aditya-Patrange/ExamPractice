package com.cdac.sudarshan.folder.service;

import com.cdac.sudarshan.authentication.model.User;
import com.cdac.sudarshan.authentication.service.IAuthService;
import com.cdac.sudarshan.authentication.service.IUserService;
import com.cdac.sudarshan.dto.RequestDTO;
import com.cdac.sudarshan.exception.DataAlreadyFoundException;
import com.cdac.sudarshan.exception.DataNotFoundException;
import com.cdac.sudarshan.exception.PathNotFoundException;
import com.cdac.sudarshan.exception.ResourceNotFoundException;
import com.cdac.sudarshan.folder.dto.MediaDto;
import com.cdac.sudarshan.folder.dto.SubFolderPathDto;
import com.cdac.sudarshan.folder.model.RootFolder;
import com.cdac.sudarshan.folder.model.SubFolderPaths;
import com.cdac.sudarshan.folder.model.UrlsPath;
import com.cdac.sudarshan.folder.repository.RootFolderRepo;
import com.cdac.sudarshan.folder.repository.SubFolderPathsRepo;
import com.cdac.sudarshan.folder.repository.UrlsPathRepo;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class SubFolderPathsServiceImpl implements ISubFolderPathsService {

    @Autowired
    private SubFolderPathsRepo subFolderPathsRepo;

    @Autowired
    private RootFolderRepo rootFolderRepo;

    @Autowired
    private IUserService userService;

    @Autowired
    private JdbcTemplate jdbcTemplateTwo;

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private UrlsPathRepo urlsPathRepo;

    @Value("${elastic.search.url}")
    private String elasticSearchUrl;

    @Value("${Media_Server}")
    private String mediaServer;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private IAuthService authService;


    @SuppressWarnings("unused")
    @Override
    public List<SubFolderPaths> addSubFolderToRootFolder(String path) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication.getName() == null) {
            throw new ResourceNotFoundException("Please Login first For adding folder");
        }

        User loggedInUser = userService.getUserByUserName(authentication.getName());

        String pathFilter = path.replaceAll("/", "");

        if (path.isEmpty() || pathFilter.isEmpty() || !path.endsWith("/")) {
            throw new PathNotFoundException("Please Enter valid Path or path is empty");
        }

        String[] folderNames = path.split("/");
        List<String> subFolderNames = new ArrayList<>();
        for (String folder : folderNames) {
            if (!folder.equals("")) {
                subFolderNames.add(folder);
            }
        }

        // Check root Folder is exists or not
        RootFolder rootFolderName = rootFolderRepo.findByRootFolderNameAndUser(subFolderNames.get(0), loggedInUser);
        if (rootFolderName == null) {
            throw new PathNotFoundException("Please add root folder first then add subfolders");
        }

        // Check Subfolder is already exist or not
        List<SubFolderPaths> subFolderList = subFolderPathsRepo.findByFolderPath(rootFolderName);
        for (SubFolderPaths subFolderPaths : subFolderList) {
            String subfolderName = subFolderPaths.getSubFolderPath();
            if (subfolderName.equalsIgnoreCase(path)
                    && subFolderPaths.getFolderPath().getId() == rootFolderName.getId() && subFolderPaths.isStatus()) {
                throw new DataAlreadyFoundException("Sub folder already exist for given path");
            }
        }

        int i = 1;
        int size = subFolderNames.size() - 1;
        String mainPath = "/" + subFolderNames.get(0) + "/";
        List<SubFolderPaths> subPaths = new ArrayList<>();

        for (String s : subFolderNames) {
            if (i > size) {
                break;
            }
            SubFolderPaths folderPath = new SubFolderPaths();
            folderPath.setFolderPath(rootFolderName);
            folderPath.setStatus(true);
            mainPath = mainPath + subFolderNames.get(i) + "/";
            folderPath.setSubFolderPath(mainPath);
            String[] subFD = mainPath.substring(0).split("/");
            if (subFD.length < 4) {

                String spl[] = mainPath.split("/");
                // String s1 = mainPath.replaceAll("\\w+/$", "");
                // String s2 = s1.replace("/", "");
                String s2 = spl[1];
                RootFolder rootFolderObj = rootFolderRepo.findByRootFolderNameAndUser(s2, loggedInUser);
                folderPath.setParentSubFolderId(rootFolderObj.getId());
                //chnages
                folderPath.setStatus(true);
            } else {
                SubFolderPaths subFolderObj = getParentSubFolderByName(mainPath);
                folderPath.setParentSubFolderId(subFolderObj.getId());
                //chnages
                folderPath.setStatus(true);
            }
            subPaths.add(folderPath);
            i++;
        }

        List<SubFolderPaths> uniqueSubPaths = new ArrayList<>();
        for (int k = 0; k < subPaths.size(); k++) {
            Long rotFdId = subPaths.get(k).getFolderPath().getId();
            SubFolderPaths uniqueData = subFolderPathsRepo
                    .findBySubFolderPathAndRootFolderId(subPaths.get(k).getSubFolderPath(), rotFdId);
            if (uniqueData == null || !uniqueData.isStatus()) {
                uniqueSubPaths.add(subPaths.get(k));
            }
        }

        List<SubFolderPaths> subfolders = subFolderPathsRepo.saveAll(uniqueSubPaths);

//		for (SubFolderPaths paths : subfolders) {
//			httpSession.setAttribute("subFolderUserID", paths.getFolderPath().getUser().getId());
//		}
        return subfolders;

    }

    private SubFolderPaths getParentSubFolderByName(String subFolderName) {
        // String s1[]=subFolderName.split("/");
        // String s1 = subFolderName.replaceAll("\\w+/$", "");
        // String s1 = subFolderName.replaceAll("^([^/]*/[^/]*/).*$", "");
        String replacedOutput = subFolderName.replace("[a-zA-Z0-9\\s]+/$", "");
        String result = replacedOutput.replace("/$", "");
        String s1 = subFolderName.substring(0,
                subFolderName.substring(0, subFolderName.lastIndexOf("/")).lastIndexOf("/") + 1);
        return subFolderPathsRepo.findBySubFolderPathName(s1);

        // return subFolderPathsRepo.findBySubFolderPathName(s1[0]);

    }

    // ajay
    @Override
    public ResponseEntity<?> getSubFolderOfParentFolder(String parentFolderName) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication.getName() == null) {
            throw new ResourceNotFoundException("Please Login first For adding folder");
        }
        User loggedInUser = userService.getUserByUserName(authentication.getName());

        if (!parentFolderName.startsWith("/") || !parentFolderName.endsWith("/")) {
            throw new PathNotFoundException("Please enter valid path or path is empty");
        }

        List<SubFolderPaths> subFolderList = null;
        SubFolderPaths subFolderByRootFolder = null;
        List<Map<String, String>> dtoList = new ArrayList<>();


        String folderName = parentFolderName.replace("/", "");
        RootFolder findByRootFolderName = rootFolderRepo.findByRootFolderNameAndUser(folderName, loggedInUser);

        if (findByRootFolderName == null) {
            String rootFolderName = parentFolderName.split("/")[1];
            RootFolder RootFolderObj = rootFolderRepo.findByRootFolderNameAndUser(rootFolderName, loggedInUser);

            if (RootFolderObj == null) {
                throw new PathNotFoundException("Please enter valid path or path is empty");
            }
            subFolderByRootFolder = subFolderPathsRepo.findBySubFolderPathAndRootFolderId(parentFolderName,
                    RootFolderObj.getId());

            if (subFolderByRootFolder == null) {
                throw new PathNotFoundException("Please enter valid path or path is empty");
            }
            Long subFolderId = subFolderByRootFolder.getId();

            // subFolderList = subFolderPathsRepo.findAllByFolderPath_Id(subFolderId);
            subFolderList = subFolderPathsRepo.findByParentSubFolderId(subFolderId);

        } else {
            Long rootFolderId = findByRootFolderName.getId();
            subFolderList = subFolderPathsRepo.findByParentSubFolderId(rootFolderId);
        }

        List<SubFolderPaths> activeSubFolderList = new ArrayList<>();

        if (!subFolderList.isEmpty()) {
            activeSubFolderList = subFolderList.stream().filter(subFolderPath -> subFolderPath.isStatus() == true).collect(Collectors.toList());
        }

        for (SubFolderPaths subFolderPath : activeSubFolderList) {
            Map<String, String> map = new LinkedHashMap<>();
            String sfName = subFolderPath.getSubFolderPath();
            String sfFilter = sfName.replace(parentFolderName, "");
            String subFolderName = sfFilter.replace("/", "");

            map.put("SubFolderName", subFolderName);

            dtoList.add(map);

        }

        return ResponseEntity.ok(dtoList);

    }

    @Override
    public ResponseEntity<?> getMediaSourceData(Map<String, Object> data) throws IOException {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        User loggedInUser = userService.getUserByUserName(authentication.getName());//dbUser

        if (loggedInUser == null) {
            throw new ResourceNotFoundException("Please Login first For adding add url");
        }

        String path = String.valueOf(data.get("path"));
        String size = String.valueOf(data.get("size"));
        String tag = String.valueOf((data.get("tag")));

        if (path == null || !path.startsWith("/") || !path.endsWith("/")) {
            throw new PathNotFoundException("Entered path is empty or invalid");
        }

        String[] folderNames = path.split("/");
        List<String> subFolderNames = new ArrayList<>();
        for (String folder : folderNames) {
            if (!folder.equals("")) {
                subFolderNames.add(folder);
            }
        }

        String rootFolderName = subFolderNames.get(0).replace("/", "");

        RootFolder rootFolder = rootFolderRepo.findByRootFolderNameAndUser(rootFolderName, loggedInUser);

        if (rootFolder == null) {
            throw new PathNotFoundException("Root folder is not exists for given path...!");
        }

        SubFolderPaths subFolder = subFolderPathsRepo.findBySubFolderPathAndFolderPath(path, rootFolder);


        List<UrlsPath> urlsPaths = new ArrayList<>();
        if (subFolder == null) {
            if (rootFolder == null || rootFolder.isStatus() == false) {
                throw new PathNotFoundException("Please Enter valid Path...!");
            } else if (subFolderNames.size() == 1) {
                urlsPaths = urlsPathRepo.findByRootFolderIdAndTag(rootFolder.getId(), tag);
            } else {
                throw new PathNotFoundException("Subfolder is not exists for given path...!");
            }
        } else {
            urlsPaths = urlsPathRepo.findUrlBySubFolderPathIdAndTag(subFolder.getId(), tag);
        }


        //filtering active url list
        List<UrlsPath> activeUrlPathList = new ArrayList<>();

        if (!urlsPaths.isEmpty()) {
            activeUrlPathList = urlsPaths.stream().filter(urlsPath -> urlsPath.isStatus() == true).collect(Collectors.toList());
        }


        // getting urls from list of urlspaths
        List<UrlsPath> videoPathList = new ArrayList<>();
        List<UrlsPath> imagePathList = new ArrayList<>();

        for (int i = 0; i < activeUrlPathList.size(); i++) {
            if (tag.equals("img") && activeUrlPathList.get(i).getResourcePath() != null) {
                imagePathList.add(activeUrlPathList.get(i));
            }
            if (tag.equals("vid") && activeUrlPathList.get(i).getResourcePath() != null) {
                videoPathList.add(activeUrlPathList.get(i));
            }
        }

        if (videoPathList.isEmpty() && imagePathList.isEmpty()) {
            throw new DataNotFoundException("Data not Present in given path");
        }

        if (tag.equals("img")) {
            List<MediaDto> dataFromSystem = getDataFromSystem(imagePathList, "img");
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "Image Data")
                    .contentType(MediaType.APPLICATION_OCTET_STREAM)
                    .body(dataFromSystem);

        } else if (tag.equals("vid")) {
            List<MediaDto> dataFromSystem = getDataFromSystem(videoPathList, "vid");
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "Videos Data")
                    .contentType(MediaType.APPLICATION_OCTET_STREAM)
                    .body(dataFromSystem);
        }
        return null;
    }


    //  return media obj from file
    private List<MediaDto> getDataFromSystem(List<UrlsPath> pathList, String tag) throws IOException {
        List<MediaDto> data = new ArrayList<>();
        if (tag.equals("img") || tag.equals("vid")) {

            for (int i = 0; i < pathList.size(); i++) {

                if (!pathList.get(i).getResourcePath().isEmpty()) {
                    MediaDto mediaDto = new MediaDto();
                    mediaDto.setFileName(mediaServer + pathList.get(i).getResourcePath());
                    mediaDto.setFilePath(pathList.get(i).getResourcePath());
                    mediaDto.setType(pathList.get(i).getSource());
                    mediaDto.setTag(pathList.get(i).getTag());
                    data.add(mediaDto);
                } else {
                    continue;
                }
            }
        }
        return data;
    }

    @Override
    public ResponseEntity<?> getAllSubFolderOfRootFolder(String rootFolderName) {

        List<Map<String, String>> dtos = new ArrayList<>();
        try {
            List<SubFolderPaths> subFolderByRootFolder = subFolderPathsRepo
                    .findAllByFolderPath_RootFolderName(rootFolderName);

//			if (subFolderByRootFolder == null) {
//				subFolderByRootFolder = subFolderPathsRepo.findAllBySubFolderPath(rootFolderName);
//			}

            SubFolderPaths subFolderPaths = subFolderByRootFolder.get(subFolderByRootFolder.size() - 1);
            String[] splitPaths = subFolderPaths.getSubFolderPath().split("/");

            Arrays.asList(splitPaths).forEach(System.out::println);

            int i = 0;
            int v = splitPaths.length;
            while (i < splitPaths.length - 2) {
                for (SubFolderPaths s : subFolderByRootFolder) {
                    Map<String, String> map = new LinkedHashMap<>();
                    SubFolderPathDto subFolderPathDto = new SubFolderPathDto();
                    subFolderPathDto.setSubFolderPathId(s.getId());
                    subFolderPathDto.setSubFolderPathName(s.getSubFolderPath());
                    subFolderPathDto.setUrlsPathList(null);

                    map.put("SubFolderName_" + (i + 1), splitPaths[i + 2]);

                    dtos.add(map);
                    i++;
                }
            }
        } catch (Exception e) {
            return ResponseEntity.ok(e.getMessage());
        }

        return ResponseEntity.ok(dtos);

    }

//	@Override
//	public ResponseEntity<?> getAllSubFolderOfRootFolder_1(String subFolderName) {
//
//		List<Map<String, String>> dtos = new ArrayList<>();
//		try {
//			List<SubFolderPaths> subFolderByRootFolder = subFolderPathsRepo
//					.findAllByFolderPath_SubFolderPath(subFolderName);
//
//			SubFolderPaths subFolderPaths = subFolderByRootFolder.get(subFolderByRootFolder.size() - 1);
//			String[] splitPaths = subFolderPaths.getSubFolderPath().split("/");
//
//			Arrays.asList(splitPaths).forEach(System.out::println);
//
//			int i = 0;
//			int v = splitPaths.length;
//			while (i < splitPaths.length - 2) {
//				for (SubFolderPaths s : subFolderByRootFolder) {
//					Map<String, String> map = new LinkedHashMap<>();
//					SubFolderPathDto subFolderPathDto = new SubFolderPathDto();
//					subFolderPathDto.setSubFolderPathId(s.getId());
//					subFolderPathDto.setSubFolderPathName(s.getSubFolderPath());
//					subFolderPathDto.setUrlPathsDtos(null);
//
//					map.put("SubFolderName_" + (i + 1), splitPaths[i + 2]);
//
//					dtos.add(map);
//					i++;
//				}
//			}
//		} catch (Exception e) {
//			return ResponseEntity.ok(e.getMessage());
//		}
//
//		System.out.println(dtos);
//
//		return ResponseEntity.ok(dtos);

//	}

    @Override
    public String getUrlAndSourceFromEs(Map<String, Object> data) {

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication.getName() == null) {
            throw new ResourceNotFoundException("Please Login first For adding folder");
        }

        User dbUser = userService.getUserByUserName(authentication.getName());
        String path = String.valueOf(data.get("path"));
        String size = String.valueOf(data.get("size"));
        String tag = String.valueOf((data.get("tag")));

        if (path.isEmpty()) {
            throw new PathNotFoundException("Oops Entered path is empty...!");
        }

        String[] folderNames = path.split("/");
        List<String> subFolderNames = new ArrayList<>();
        for (String folder : folderNames) {
            if (!folder.equals("")) {
                subFolderNames.add(folder);
            }
        }

        String rootFolderName = subFolderNames.get(0).replace("/", "");

        RootFolder rootFolder = rootFolderRepo.findByRootFolderNameAndUser(rootFolderName, dbUser);

        //SubFolderPaths subFolder = subFolderPathsRepo.findBySubFolderPath(path);
        SubFolderPaths subFolder = subFolderPathsRepo.findBySubFolderPathAndFolderPathAndStatus(path, rootFolder, true);
//        SubFolderPaths subFolder = subFolderPathsRepo.findBySubFolderPathAndFolderPath(path, rootFolder);


        List<UrlsPath> urlsPaths = new ArrayList<>();

        if (subFolder == null) {
            if (rootFolder == null || rootFolder.isStatus() == false) {
                throw new PathNotFoundException("Please enter valid path...!");
            } else if (subFolderNames.size() == 1) {
                urlsPaths = urlsPathRepo.findByRootFolderIdAndTag(rootFolder.getId(), tag);
            } else {
                throw new PathNotFoundException("Sub folder not exist for given path !!");
            }
        } else if (subFolder.isStatus() == true) {
            urlsPaths = urlsPathRepo.findUrlBySubFolderPathIdAndTag(subFolder.getId(), tag);
        } else {
            throw new PathNotFoundException("Sub folder not exist for given path !!");
        }


        //filtering active url list
        List<UrlsPath> activeUrlPathList = new ArrayList<>();
        if (!urlsPaths.isEmpty()) {
            activeUrlPathList = urlsPaths.stream().
                    filter(urlsPath -> urlsPath.isStatus() == true).
                    collect(Collectors.toList());
        }

        // getting urls from list of urlspaths
        List<String> urlList = new ArrayList<>();
        List<String> profileIds = new ArrayList<>();


        for (UrlsPath urlPath : activeUrlPathList) {
            if (urlPath.getUrl() != null) {
                urlList.add(urlPath.getUrl());
            } else if (tag.equals("pr") && urlPath.getProfileId() != null) {
                profileIds.add(urlPath.getProfileId());
            }
        }


//        for (int i = 0; i < activeUrlPathList.size(); i++) {
//            if (activeUrlPathList.get(i).getUrl() != null) {
//                urlsList.add(activeUrlPathList.get(i).getUrl());
//            }
//            if (tag.equals("pr") && activeUrlPathList.get(i).getProfileId() != null) {
//                profileIds.add(activeUrlPathList.get(i).getProfileId());
//            }
//        }

        if (urlList.isEmpty() && profileIds.isEmpty()) {
            throw new DataNotFoundException("Data not Present in given path");
        }

        RequestDTO dtoForEs = new RequestDTO();

        String jsonResult = null;

        if (tag.equals("pr")) {
            // getting profile data from maria-db using profile ids
            SubFolderPathsServiceImpl SubFolderPathsServiceImpl = new SubFolderPathsServiceImpl();
            String profileIdList = sqlFormatedList(profileIds);
            String query = "select * from collection_profile where row_number in" + profileIdList;
            List<Map<String, Object>> maps = jdbcTemplateTwo.queryForList(query);
            // convert map to jason format
            //ObjectMapper mapper = new ObjectMapper();
            String tagsList;
            try {
                tagsList = objectMapper.writeValueAsString(maps);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            jsonResult = tagsList;

        } else if (tag.equals("p") || tag.equals("article")) {
            dtoForEs.setList(urlList);
            dtoForEs.setSize(Integer.parseInt(size));
            dtoForEs.setTag(tag);
            // call for es service to get data from es for other tag than pr
            jsonResult = restTemplate.postForObject(elasticSearchUrl, dtoForEs, String.class);

            if (jsonResult.isEmpty()) {
                throw new DataNotFoundException("Data not found in given path");
            }
        }

        return jsonResult;
    }

//	@Override
//	public ResponseEntity<?> getAllSubFolderOfRootFolder_1(String rootFolderName) {
//		return null;
//	}

    /**
     * @param list
     * @return
     */
    private static String sqlFormatedList(List<String> list) {
        StringBuilder sb = new StringBuilder();
        sb.append("('");
        for (String i : list) {
            sb.append(i).append("','");
        }
        sb.deleteCharAt(sb.length() - 1);
        sb.deleteCharAt(sb.lastIndexOf(","));
        sb.append(")");
        return sb.toString();
    }

    @Override
    public ResponseEntity<?> renameSubFolder(Map<String, String> data) {

        //get logged in details from token
        User loggedInUser = (User) authService.getLoggedInUserDetails().getBody();

        Map<String, Object> response = new HashMap<>();

        if (!data.get("oldPath").startsWith("/") || !data.get("oldPath").endsWith("/")) {
            throw new PathNotFoundException("Please enter valid old path or entered path is empty");
        }

        if (!data.get("newPath").startsWith("/") || !data.get("newPath").endsWith("/")) {
            throw new PathNotFoundException("Please enter valid new path or entered path is empty");
        }

        String oldPath = data.get("oldPath");
        String newPath = data.get("newPath");

        String[] folderNames = oldPath.split("/");
        List<String> subFolderNames = new ArrayList<>();
        for (String folder : folderNames) {
            if (!folder.equals("")) {
                subFolderNames.add(folder);
            }
        }

        //getting root folder
        RootFolder rootFolder = rootFolderRepo.findByRootFolderNameAndUser(subFolderNames.get(0), loggedInUser);
        if (rootFolder == null) {
            throw new PathNotFoundException("root folder is not exists with given path");
        }

        SubFolderPaths subFolder = subFolderPathsRepo.findBySubFolderPath(oldPath);

        if (subFolder == null) {
            throw new PathNotFoundException("entered path is not valid please enter valid path");
        }

        SubFolderPaths subFolderByNewPath = subFolderPathsRepo.findBySubFolderPath(newPath);
        if(subFolderByNewPath != null){
            throw new DataAlreadyFoundException("sub-folder already exists with given new-path");
        }
        if (subFolder.isStatus()) {
            //find folders under current sub-folder
            List<SubFolderPaths> subsubFolders = subFolderPathsRepo.findByParentSubFolderId(subFolder.getId());
            for(SubFolderPaths subsubFolder : subsubFolders){
               //changing name of parent folder into sub-subfolder
               // subsubFolder.getSubFolderPath().substring(rootFolder.getRootFolderName().length()+2,subsubFolder.getSubFolderPath().length()-subsubFolder.ge);
            }
            subFolder.setSubFolderPath(newPath);
            subFolderPathsRepo.save(subFolder);
        }
        response.put("message", "Foldername updated successfully");
        response.put("success", true);
        response.put("statusCode", HttpStatus.OK);

        return ResponseEntity.status(HttpStatus.OK).body(response);
    }


}
