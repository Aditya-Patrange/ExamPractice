package com.cdac.sudarshan.authentication.model;

public enum Role {
    U,A
}
