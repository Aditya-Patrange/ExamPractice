package com.cdac.sudarshan.discover.common;

import java.util.ArrayList;
import java.util.List;

import com.cdac.sudarshan.discover.model.Fb_OutputVo;


public interface DashboardDAO 
{

	public ArrayList<DashOutputVo> dashEntityCount(DashInputVo dashInputVo);
	public ArrayList<DashOutputVo> dashTimeLine(DashInputVo dashInputVo);
	public ArrayList<DashOutputVo> dashTwTrends(DashInputVo dashInputVo);
	public ArrayList<DashOutputVo> dashGeoMap(DashInputVo dashInputVo);
	public ArrayList<DashOutputVo> dashRssNER(DashInputVo dashInputVo);
	public ArrayList<DashOutputVo> dashPhases(DashInputVo dashInputVo);
	public ArrayList<DashOutputVo> dashActiveUser(DashInputVo dashInputVo);
	public ArrayList<DashOutputVo> dashActiveHashTag(DashInputVo dashInputVo);
	public ArrayList<DashOutputVo> dashActiveMedia(DashInputVo dashInputVo);
	public ArrayList<DashOutputVo> dashTopTrendingTweets(DashInputVo dashInputVo);
	public ArrayList<DashOutputVo> dashTopTrendingVideos(DashInputVo dashInputVo);
	public ArrayList<DashOutputVo> dashTopTrendingInstaPost(DashInputVo dashInputVo);
	public ArrayList<FbOutputVo> dashTopTrendingFacebookPost(DashInputVo dashInputVo);
	
	
	//**********pankaj**************
	public List<Dashboard> getDashboardByUserId(String userId);
	public boolean removeDashboardById(Dashboard dashboard);
	public boolean createDashboard(Dashboard dashboard);
	public boolean updateDashboardById(Dashboard dashboard);
	public ArrayList<Dashboard> getAllDashboard(Dashboard dashboard);
	
	//***********Widgets ***********************8
	boolean updateWidget(Widget widget);
	public ArrayList<Widget> getAllWidget(Widget widget);
    public void addWidgetsToDashboard(Dashboard dashboard);
    public void removeWidgetsFromDashboard(Dashboard dashboard);
	public List<DashboardWidgetVo> getWidgetsByDashboardId(Long dashboardId);
	
	public int deleteWidgetDashboard(List<DashboardWidgetVo> list) throws Exception;
	public int updateWidgetDashboard(List<DashboardWidgetVo> list) throws Exception;
	public int addWidgetDashboard(List<DashboardWidgetVo> added) throws Exception;
	List<DashboardWidgetVo> getAllDashboard();
    public void markCurrentDashboard(String dashboardId,String caseId);
	public ArrayList<Dashboard> getUserCurrentDashboard(String caseId);

}
