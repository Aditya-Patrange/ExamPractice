package com.cdac.sudarshan.dto;

import java.util.List;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class UrlPathDTO {

	private String path;

	private List<com.cdac.sudarshan.utils.Data> urlAndSource;

}
