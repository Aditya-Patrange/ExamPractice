package com.cdac.sudarshan.folder.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class RequestDto {

    private String path;
    private List<String> urls;
    private List<String> profileIds;
    private String tag;
}
