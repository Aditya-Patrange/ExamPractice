package com.cdac.sudarshan.discover.model;

import java.io.Serializable;

public class Yt_Channel_Info implements Serializable 
{
	private static final long serialVersionUID = 1L;
	private String channelId;
	private String title;
	private String description;
	private String thumbnailsMediumUrl;
	private String thumbnailsHighUrl;
	private String relatedPlayListsLikeId;
	private String relatedPlaylistsFavoritesId;
	private String relatedPlaylistsUploadsId;
	private long publishedAt;
	private int viewCount;
	private int commentCount;
	private int subscriberCount;
	private int hiddenSubscriberCount;
	private int videoCount;
	
	public long getPublishedAt() {
		return publishedAt;
	}
	public void setPublishedAt(long publishedAt) {
		this.publishedAt = publishedAt;
	}
	public String getChannelId() {
		return channelId;
	}
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getThumbnailsMediumUrl() {
		return thumbnailsMediumUrl;
	}
	public void setThumbnailsMediumUrl(String thumbnailsMediumUrl) {
		this.thumbnailsMediumUrl = thumbnailsMediumUrl;
	}
	public String getThumbnailsHighUrl() {
		return thumbnailsHighUrl;
	}
	public void setThumbnailsHighUrl(String thumbnailsHighUrl) {
		this.thumbnailsHighUrl = thumbnailsHighUrl;
	}
	public String getRelatedPlayListsLikeId() {
		return relatedPlayListsLikeId;
	}
	public void setRelatedPlayListsLikeId(String relatedPlayListsLikeId) {
		this.relatedPlayListsLikeId = relatedPlayListsLikeId;
	}
	public String getRelatedPlaylistsFavoritesId() {
		return relatedPlaylistsFavoritesId;
	}
	public void setRelatedPlaylistsFavoritesId(String relatedPlaylistsFavoritesId) {
		this.relatedPlaylistsFavoritesId = relatedPlaylistsFavoritesId;
	}
	public String getRelatedPlaylistsUploadsId() {
		return relatedPlaylistsUploadsId;
	}
	public void setRelatedPlaylistsUploadsId(String relatedPlaylistsUploadsId) {
		this.relatedPlaylistsUploadsId = relatedPlaylistsUploadsId;
	}
	public int getViewCount() {
		return viewCount;
	}
	public void setViewCount(int viewCount) {
		this.viewCount = viewCount;
	}
	public int getCommentCount() {
		return commentCount;
	}
	public void setCommentCount(int commentCount) {
		this.commentCount = commentCount;
	}
	public int getSubscriberCount() {
		return subscriberCount;
	}
	public void setSubscriberCount(int subscriberCount) {
		this.subscriberCount = subscriberCount;
	}
	public int getHiddenSubscriberCount() {
		return hiddenSubscriberCount;
	}
	public void setHiddenSubscriberCount(int hiddenSubscriberCount) {
		this.hiddenSubscriberCount = hiddenSubscriberCount;
	}
	public int getVideoCount() {
		return videoCount;
	}
	public void setVideoCount(int videoCount) {
		this.videoCount = videoCount;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "Yt_Channel_Info [publishedAt=" + publishedAt + ", channelId=" + channelId + ", title=" + title
				+ ", description=" + description + ", thumbnailsMediumUrl=" + thumbnailsMediumUrl
				+ ", thumbnailsHighUrl=" + thumbnailsHighUrl + ", relatedPlayListsLikeId=" + relatedPlayListsLikeId
				+ ", relatedPlaylistsFavoritesId=" + relatedPlaylistsFavoritesId + ", relatedPlaylistsUploadsId="
				+ relatedPlaylistsUploadsId + ", viewCount=" + viewCount + ", commentCount=" + commentCount
				+ ", subscriberCount=" + subscriberCount + ", hiddenSubscriberCount=" + hiddenSubscriberCount
				+ ", videoCount=" + videoCount + "]";
	}

}
