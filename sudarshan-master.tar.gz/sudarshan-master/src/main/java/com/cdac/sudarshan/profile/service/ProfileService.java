package com.cdac.sudarshan.profile.service;

import com.cdac.sudarshan.watchlist.configuration.ApplicationConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.HashMap;

@Service
public class ProfileService implements IProfileService{

    @Autowired
    private ApplicationConfiguration appConfig;

    @Autowired
    private RestTemplate template;

    @Override
    public ResponseEntity<?> searchByName(HashMap<String, Object> data) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<Object>(data, headers);
        return template.exchange(appConfig.getProperty("InnefuURL") + "searchByName", HttpMethod.POST, entity,
                Object.class);
    }

    @Override
    public ResponseEntity<?> selectAllAvatarByParameter(HashMap<String, Object> data) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<Object>(data, headers);
        return template.exchange(appConfig.getProperty("InnefuURL") + "selectAllAvatarByParameter", HttpMethod.POST, entity,
                Object.class);
    }
}
