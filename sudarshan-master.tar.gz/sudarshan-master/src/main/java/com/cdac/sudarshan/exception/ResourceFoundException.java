package com.cdac.sudarshan.exception;

import lombok.Data;

@Data
public class ResourceFoundException extends RuntimeException{

    private String message;

    public ResourceFoundException(String message) {
        super(message);
        this.message=message;
    }
}
