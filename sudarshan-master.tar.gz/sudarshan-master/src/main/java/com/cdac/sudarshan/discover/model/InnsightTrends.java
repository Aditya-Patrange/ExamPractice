package com.cdac.sudarshan.discover.model;

public class InnsightTrends {
	
	private int tweetVolume;
	private String city, country, countryCode, trends, cityWoeId;
	private long insertedDate;
	
	//setters and getters
	
	public String getCity() {
		return city;
	}
	public int getTweetVolume() {
		return tweetVolume;
	}
	public void setTweetVolume(int tweetVolume) {
		this.tweetVolume = tweetVolume;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getTrends() {
		return trends;
	}
	public void setTrends(String trends) {
		this.trends = trends;
	}
	public long getInsertedDate() {
		return insertedDate;
	}
	public void setInsertedDate(long insertedDate) {
		this.insertedDate = insertedDate;
	}
	public String getCityWoeId() {
		return cityWoeId;
	}
	public void setCityWoeId(String cityWoeId) {
		this.cityWoeId = cityWoeId;
	}
	
}