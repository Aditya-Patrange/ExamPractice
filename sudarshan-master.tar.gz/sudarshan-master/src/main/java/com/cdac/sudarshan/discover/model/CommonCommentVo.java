package com.cdac.sudarshan.discover.model;

import java.io.Serializable;

public class CommonCommentVo implements Serializable 
{
	private static final long serialVersionUID = 1L;
	private String commentUserName;
	private String commentUserId;
	private String commentUserImg;
	private String commentContent;
	private long commentCreatedAt;
	public String getCommentUserName() {
		return commentUserName;
	}
	public void setCommentUserName(String commentUserName) {
		this.commentUserName = commentUserName;
	}
	public String getCommentUserId() {
		return commentUserId;
	}
	public void setCommentUserId(String commentUserId) {
		this.commentUserId = commentUserId;
	}
	public String getCommentUserImg() {
		return commentUserImg;
	}
	public void setCommentUserImg(String commentUserImg) {
		this.commentUserImg = commentUserImg;
	}
	public String getCommentContent() {
		return commentContent;
	}
	public void setCommentContent(String commentContent) {
		this.commentContent = commentContent;
	}
	public long getCommentCreatedAt() {
		return commentCreatedAt;
	}
	public void setCommentCreatedAt(long commentCreatedAt) {
		this.commentCreatedAt = commentCreatedAt;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "CommonCommentVo [commentUserName=" + commentUserName + ", commentUserId=" + commentUserId
				+ ", commentUserImg=" + commentUserImg + ", commentContent=" + commentContent + ", commentCreatedAt="
				+ commentCreatedAt + "]";
	}
	 
}
