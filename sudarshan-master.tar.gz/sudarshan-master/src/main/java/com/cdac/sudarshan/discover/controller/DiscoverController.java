package com.cdac.sudarshan.discover.controller;

import com.cdac.sudarshan.discover.dto.BaseEntityDto;
import com.cdac.sudarshan.discover.service.ISourceService;
import com.cdac.sudarshan.dto.DTO;
import com.cdac.sudarshan.folder.dto.RootFolderDto;
import com.cdac.sudarshan.folder.service.IRootFolderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@CrossOrigin("*")
public class DiscoverController {

    @Autowired
    private ISourceService sourceService;

    @Autowired
    private IRootFolderService rootFolderServiceImpl;

    /* To test application */
    @GetMapping("/home")
    public String homeTest() {
        return "First Testing Page";

    }

    @GetMapping("/getPhoneCode/{code}")
    public ResponseEntity<?> getPhoneCode(@PathVariable String code) {
        return ResponseEntity.ok(sourceService.getPhoneCode(code));
    }

    /**
     * This API is used to get source list.
     *
     * @param NA
     * @return List<DiscoverSources>
     */
    @GetMapping("/getSourceList")
    public ResponseEntity<?> getSourceList() {
        return new ResponseEntity<>(sourceService.getSourceList(), HttpStatus.OK);

    }

    /**
     * This API is used to get specific subsource list on the basis of input source
     * id.
     *
     * @param sourceid
     * @return List<DiscoverSubSources>
     */
    @PostMapping("/getSubsourceList")
    public ResponseEntity<?> getSubSourceList(@RequestBody BaseEntityDto baseEntityDto) {
        return new ResponseEntity<>(sourceService.getSubSourceList(baseEntityDto), HttpStatus.OK);

    }

    /**
     * This API is used to get All subsource list present in discover_sub_sources
     * table.
     *
     * @param Na
     * @return List<DiscoverSubSourcesProjection>
     */
    @GetMapping("/getSubsource")
    public ResponseEntity<?> getSubSourceAllList() {
        return new ResponseEntity<>(sourceService.getSubSourceAllList(), HttpStatus.OK);

    }

    /**
     * This API is used to get All Country list, country code, code present in
     * country table.
     *
     * @param Na
     * @return List<Country>
     */
    @GetMapping("getCountryList")
    public ResponseEntity<?> getCountryList() {
        return new ResponseEntity<>(sourceService.getCountryList(), HttpStatus.OK);

    }

    /**
     * This API is used to get data list on the basis of input keyword search.
     *
     * @param keyword
     * @return List<Object>
     */

    @PostMapping("/addCollections")
    public ResponseEntity<?> addNewCollection(@RequestBody HashMap<String, Object> data) {
        return new ResponseEntity<>(sourceService.searchEntity(data), HttpStatus.OK);

    }

    /**
     * This API is used to get collection list.
     *
     * @param data
     * @return
     */
    @PostMapping("/getListCollection")
    public ResponseEntity<?> getListCollection(@RequestBody HashMap<String, Object> data) {
        return new ResponseEntity<>(sourceService.listCollection(data), HttpStatus.OK);

    }

    /**
     * This API is used to get Profile search data.
     *
     * @param data
     * @return
     */
    @PostMapping("/searchByName")
    public ResponseEntity<?> searchByName(@RequestBody HashMap<String, Object> data) {
        return new ResponseEntity<>(sourceService.searchByName(data), HttpStatus.OK);

    }

    /**
     * This API is used to add new collection for profile
     *
     * @param data
     * @return
     */
    @PostMapping("/addNewCollection")
    public ResponseEntity<?> addNewCollectionForProfile(@RequestBody HashMap<String, Object> data) {
        return new ResponseEntity<>(sourceService.addNewCollectionForProfile(data), HttpStatus.OK);

    }

    /**
     * get all tag list w.r.t theme and subtheme
     *
     * @return
     */
    @GetMapping("/addThemeCollection")
    public ResponseEntity<?> addThemeCollectionForKeyword() {
        return new ResponseEntity<>(sourceService.addThemeCollection(), HttpStatus.OK);

    }

    /**
     * get all tag list w.r.t theme only
     *
     * @return
     */
    @GetMapping("/getThemeTag")
    public ResponseEntity<?> getThemeTag() {
        return new ResponseEntity<>(sourceService.getThemeTag(), HttpStatus.OK);

    }

    /**
     * This API is used to update collection status active to pause by
     * collection_id.
     *
     * @param data
     * @return
     */
    @PostMapping("/pauseCollectionStatus")
    public ResponseEntity<?> updateCollectionPausedStatusById(@RequestBody HashMap<String, Object> data) {
        return new ResponseEntity<>(sourceService.updateCollectionPausedStatusById(data), HttpStatus.OK);

    }

    /**
     * This API is used to update collection status pause to resume by
     * collection_id.
     *
     * @param data
     * @return
     */
    @PostMapping("/resumeCollectionStatus")
    public ResponseEntity<?> resumeCollectionPausedStatusById(@RequestBody HashMap<String, Object> data) {
        return new ResponseEntity<>(sourceService.updateCollectionPausedStatusById(data), HttpStatus.OK);

    }

    /**
     * This API is used to delete existing collection entry by collection_id.
     *
     * @param data
     * @return
     */
    @PostMapping("/deleteCollection")
    public ResponseEntity<?> deleteCollection(@RequestBody HashMap<String, Object> data) {
        return new ResponseEntity<>(sourceService.deleteCollection(data), HttpStatus.OK);

    }

    /**
     * This API is used to get existing collection data by collection_id.
     *
     * @param data
     * @return
     */
    @PostMapping("/getCollection")
    public ResponseEntity<?> getCollectionById(@RequestBody HashMap<String, Object> data) {
        return new ResponseEntity<>(sourceService.getCollectionById(data), HttpStatus.OK);

    }

    /**
     * This API is used to edit existing collection entry by collection_id.
     *
     * @param data
     * @return
     */
    @PostMapping("/updateCollection")
    public ResponseEntity<?> updateNewCollectionById(@RequestBody HashMap<String, Object> data) {
        return new ResponseEntity<>(sourceService.updateNewCollectionById(data), HttpStatus.OK);

    }

    /**
     * This API is used to get details article more information w.r.t source type
     *
     * @param data
     * @return
     */
    @PostMapping("/getArticleDetailById")
    public ResponseEntity<?> getTweetDetailById(@RequestBody HashMap<String, Object> data) {
        return new ResponseEntity<>(sourceService.getTweetDetailById(data), HttpStatus.OK);

    }

    /**
     * This API is used to get list of category, proxy and country
     */
    @PostMapping("/getCategoryProxyCountry")
    public ResponseEntity<?> selectAllMaster(@RequestBody HashMap<String, Object> data) {
        return new ResponseEntity<>(sourceService.selectAllMaster(data), HttpStatus.OK);

    }

    /**
     * This API is used to get location co-ordinates of user.
     *
     * @param data
     * @return
     */
    @PostMapping("/getUserLocation")
    public ResponseEntity<?> getTweetsUserLocation(@RequestBody HashMap<String, Object> data) {
        return new ResponseEntity<>(sourceService.getTweetsUserLocation(data), HttpStatus.OK);

    }

    /**
     * This API is used to get location co-ordinates of Article.
     *
     * @param data
     * @return
     */
    @PostMapping("/getArticleLocation")
    public ResponseEntity<?> geoTweetsLatLong(@RequestBody HashMap<String, Object> data) {
        return new ResponseEntity<>(sourceService.geoTweetsLatLong(data), HttpStatus.OK);

    }

    /**
     * This API is used to get Tweets of user in profile search + Profile bio
     *
     * @param data
     * @return
     */
    @PostMapping("/getTwPosts")
    public ResponseEntity<?> getTweetsUsrDtlRpt(@RequestBody HashMap<String, Object> data) {
        return new ResponseEntity<>(sourceService.getTweetsUsrDtlRpt(data), HttpStatus.OK);

    }

    /**
     * This API is used to get Twitter User followers in profile search
     *
     * @param data
     * @return
     */
    @PostMapping("/getTwFollowers")
    public ResponseEntity<?> userDetailReportFollowers(@RequestBody HashMap<String, Object> data) {
        return new ResponseEntity<>(sourceService.userDetailReportFollowers(data), HttpStatus.OK);

    }

    /**
     * This API is used to get Twitter User Following in profile search
     *
     * @param data
     * @return
     */
    @PostMapping("/getTwFollowing")
    public ResponseEntity<?> userDetailReportFollowing(@RequestBody HashMap<String, Object> data) {
        return new ResponseEntity<>(sourceService.userDetailReportFollowing(data), HttpStatus.OK);

    }

    /**
     * This API is used to get Twitter User TopHashtag in profile search
     *
     * @param data
     * @return
     */
    @PostMapping("/getTwTopHashtag")
    public ResponseEntity<?> getHashTagsUsrDtlRpt(@RequestBody HashMap<String, Object> data) {
        return new ResponseEntity<>(sourceService.getHashTagsUsrDtlRpt(data), HttpStatus.OK);

    }

    /**
     * This API is used to get Twitter User TopMentions in profile search
     *
     * @param data
     * @return
     */
    @PostMapping("/getTwTopMentions")
    public ResponseEntity<?> getMentionUsrDtlRpt(@RequestBody HashMap<String, Object> data) {
        return new ResponseEntity<>(sourceService.getMentionUsrDtlRpt(data), HttpStatus.OK);

    }

    /**
     * This API is used to get Twitter TopRetweets User in profile search
     *
     * @param data
     * @return
     */
    @PostMapping("/getTwTopRetweetsUser")
    public ResponseEntity<?> userTopRetweet(@RequestBody HashMap<String, Object> data) {
        return new ResponseEntity<>(sourceService.userTopRetweet(data), HttpStatus.OK);

    }

    /**
     * This API is used to get Twitter TopReply User in profile search
     *
     * @param data
     * @return
     */
    @PostMapping("/getTwTopReplyUser")
    public ResponseEntity<?> userTopReply(@RequestBody HashMap<String, Object> data) {
        return new ResponseEntity<>(sourceService.userTopReply(data), HttpStatus.OK);

    }

    /**
     * This API can get User which platform source is used to tweets in profile
     * search eg.iPhone
     *
     * @param data
     * @return
     */
    @PostMapping("/getTwUserPlatform")
    public ResponseEntity<?> userTopSource(@RequestBody HashMap<String, Object> data) {
        return new ResponseEntity<>(sourceService.userTopSource(data), HttpStatus.OK);

    }

    /**
     * This API is used to get Twitter Daily Activity Count (Day of week) of User in
     * profile search
     *
     * @param data
     * @return
     */
    @PostMapping("/getTwDailyActivityCount")
    public ResponseEntity<?> getTimeLineDayOfWeek(@RequestBody HashMap<String, Object> data) {
        return new ResponseEntity<>(sourceService.getTimeLineDayOfWeek(data), HttpStatus.OK);

    }

    /**
     * This API is used to get Twitter Hourly Activity Count (Hours of Day) of User
     * in profile search
     *
     * @param data
     * @return
     */
    @PostMapping("/getTwHourlyActivityCount")
    public ResponseEntity<?> getTimeLineDayOfHour(@RequestBody HashMap<String, Object> data) {
        return new ResponseEntity<>(sourceService.getTimeLineDayOfHour(data), HttpStatus.OK);

    }

    /**
     * This API is used to get Twitter tweets Time Line Graph data in profile search
     *
     * @param data
     * @return
     */
    @PostMapping("/getTweetsTimeLine")
    public ResponseEntity<?> getTweetGraphUsrDtlRpt(@RequestBody HashMap<String, Object> data) {
        return new ResponseEntity<>(sourceService.getTweetGraphUsrDtlRpt(data), HttpStatus.OK);

    }

    /**
     * This API is used to get Twitter BIO data in profile search eg. tweet ratio,
     * sentiment etc
     *
     * @param data
     * @return
     */
    @PostMapping("/getTwUserStats")
    public ResponseEntity<?> gettweetStatsOffLine(@RequestBody HashMap<String, Object> data) {
        return new ResponseEntity<>(sourceService.gettweetStatsOffLine(data), HttpStatus.OK);

    }

    @PostMapping("/getCollectionDetails")
    public ResponseEntity<?> listKeywordOfCollection(@RequestBody HashMap<String, Object> data) {
        return new ResponseEntity<>(sourceService.listKeywordOfCollection(data), HttpStatus.OK);

    }

    /**
     * This API is used to get All source profile search data
     *
     * @param data
     * @return
     */
    @RequestMapping(value = "/getAllProfileSearchData", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> getProfileSearchDataDmFbYtInsTmLiRedTw(@RequestBody HashMap<String, Object> data) {
        return new ResponseEntity<Object>(sourceService.getProfileSearchDataDmFbYtInsTmLiRedTw(data), HttpStatus.OK);

    }

    @RequestMapping(value = "/getAllProfileSearchDataCount", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> getProfileSearchDataCount(@RequestBody HashMap<String, Object> data) {
        return new ResponseEntity<Object>(sourceService.getProfileSearchDataCount(data), HttpStatus.OK);

    }

    /**
     * This API is used to call below url.
     *
     * @param innefuUrls :http://192.168.181.128/innsight/getLink
     * @return Object.class
     */
    @PostMapping("/getLink")
    public ResponseEntity<?> getLink(@RequestBody HashMap<String, Object> data) {
        return new ResponseEntity<>(sourceService.getLink(data), HttpStatus.OK);
    }

    /**
     * This API is used to call below url.
     *
     * @param innefuUrls :http://192.168.181.128/innsight/getMentions
     * @return Object.class
     */
    @PostMapping("/getMentions")
    public ResponseEntity<?> getMentions(@RequestBody HashMap<String, Object> data) {
        return new ResponseEntity<>(sourceService.getMentions(data), HttpStatus.OK);
    }

    /**
     * This API is used to call below url.
     *
     * @param innefuUrls :http://192.168.181.128/innsight/getThemes
     * @return Object.class
     */
    @PostMapping("/getThemes")
    public ResponseEntity<?> getThemes(@RequestBody HashMap<String, Object> data) {
        return new ResponseEntity<>(sourceService.getThemes(data), HttpStatus.OK);
    }

    /**
     * This API is used to call below url.
     *
     * @param innefuUrls :http://192.168.181.128/innsight/getTweetGraph
     * @return Object.class
     */
    @PostMapping("/getTweetGraph")
    public ResponseEntity<?> getTweetGraph(@RequestBody HashMap<String, Object> data) {
        return new ResponseEntity<>(sourceService.getTweetGraph(data), HttpStatus.OK);
    }

    /**
     * This API is used to call below url.
     *
     * @param innefuUrls :http://192.168.181.128/innsight/getHashtagWordCloud
     * @return Object.class
     */
    @PostMapping("/getHashtagWordCloud")
    public ResponseEntity<?> getHashtagWordCloud(@RequestBody HashMap<String, Object> data) {
        return new ResponseEntity<>(sourceService.getHashtagWordCloud(data), HttpStatus.OK);
    }

    /**
     * This API is used to call below url.
     *
     * @param innefuUrls :http://192.168.181.128/innsight/getMentionWordCloud
     * @return Object.class
     */
    @PostMapping("/getMentionWordCloud")
    public ResponseEntity<?> getMentionWordCloud(@RequestBody HashMap<String, Object> data) {
        return new ResponseEntity<>(sourceService.getMentionWordCloud(data), HttpStatus.OK);
    }

    @GetMapping("/getrootfolderofuser")
    public ResponseEntity<?> getRootOfUser() {

        Map<Object, Object> response = new HashMap<>();
        List<RootFolderDto> list = new ArrayList<RootFolderDto>();

            DTO dto = new DTO();
            list = rootFolderServiceImpl.getRootFolderOfUser();
            response.put("FolderList: ", list);
            response.put("statusCode", HttpStatus.OK.value());
            dto.setDtos(rootFolderServiceImpl.getRootFolderOfUser());
            return ResponseEntity.ok(dto);
    }


    /**
     * This API is used to call below url.
     *
     * @param innefuUrls :http://192.168.181.128/innsight/getPersonWordCloud
     * @return Object.class
     */
    @PostMapping("/getPersonWordCloud")
    public ResponseEntity<?> getPersonWordCloud(@RequestBody HashMap<String, Object> data) {
        return new ResponseEntity<>(sourceService.getPersonWordCloud(data), HttpStatus.OK);
    }

    @GetMapping("/getTrendsList")
    public ResponseEntity<?> getTrendsList() {
        return new ResponseEntity<>(sourceService.getTrendsList(), HttpStatus.OK);

    }


}
