package com.cdac.sudarshan.discover.common;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
//import org.apache.poi.hssf.util.HSSFColor.HSSFColorPredefined;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
//import org.springframework.web.servlet.view.document.AbstractExcelView;

@Component
public class ExcelExportWidgetDataReport {
	@SuppressWarnings("unchecked")
//	protected void buildExcelDocument(Map<String, Object> model, HSSFWorkbook workbook, HttpServletRequest request,
//			HttpServletResponse response) throws Exception {
	public HttpEntity<?> buildExcelDocument(ArrayList<ArrayList<String>> data, String fileName, HttpServletResponse response) throws Exception {

//		System.out.println("Data " + data);
		
		
		XSSFWorkbook workbook = new XSSFWorkbook();
		

//		System.out.println("fileName:= " + fileName);

		Sheet sheet = workbook.createSheet(fileName);
		sheet.setDefaultColumnWidth(30);

		// create style for header cells
		
//		Font font = workbook.createFont();
//		font.setFontName("Arial");
//		font.setBold(true);;
//		font.setColor(HSSFColorPredefined.WHITE.getIndex());
//		
//		CellStyle style = workbook.createCellStyle();
//		style.setFillForegroundColor(HSSFColorPredefined.BLUE.getIndex());
//		style.setFillPattern(FillPatternType.SOLID_FOREGROUND);


		/*
		 * ArrayList<String> heading = data.get(0); int count=0; for(String column :
		 * heading){
		 * 
		 * }
		 */

		// create data rows
		int rowCount = 0;
		for (ArrayList<String> row : data) {
			Row aRow = sheet.createRow(rowCount++);
			int columnCount = 0;
			for (String rowData : row) {
				if (rowCount == 0) {
					aRow.createCell(columnCount++).setCellValue(rowData);
//					aRow.getCell(columnCount++).setCellStyle(style);
				}
				aRow.createCell(columnCount++).setCellValue(rowData);
			}
		}

		

		
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        workbook.write(baos);
        
        byte[] excelContent = baos.toByteArray();
        // prepare response
        HttpHeaders header = new HttpHeaders();
        header.setContentType(new MediaType("application", "vnd.openxmlformats-officedocument.spreadsheetml.sheet"));
        header.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + fileName + ".xlsx");
//        header.setContentLength(excelContent.length);
     

        return new HttpEntity<>(excelContent, header);
        
        
//		return ResponseEntity.ok()
//	            .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" +fileName+".xlsx")
//	            .body(new InputStreamReader(is));
//		return new ResponseEntity<>(, header, HttpStatus.OK);
		
//		response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8");
//		response.setCharacterEncoding("UTF-8");
//		response.setHeader("Content-Disposition", "attachment; filename=" + fileName + "Data.xls");
//		return new ResponseEntity<>(null, HttpStatus.OK);
		
	}

}