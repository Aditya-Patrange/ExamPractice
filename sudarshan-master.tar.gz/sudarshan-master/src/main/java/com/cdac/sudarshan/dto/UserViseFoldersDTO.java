package com.cdac.sudarshan.dto;

import java.util.List;

import com.cdac.sudarshan.authentication.model.User;

import com.cdac.sudarshan.folder.model.RootFolder;
import com.cdac.sudarshan.folder.model.SubFolderPaths;
import com.cdac.sudarshan.folder.model.UrlsPath;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@Getter
@Setter
@ToString
public class UserViseFoldersDTO {
	
	private User user;
	
	private List<RootFolder> rootFolder;
	
	private List<SubFolderPaths> subFolderPaths;
	
	private List<UrlsPath> urlsPath;

}
