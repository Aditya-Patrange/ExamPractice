package com.cdac.sudarshan.discover.model;

import java.io.Serializable;
import java.util.ArrayList;

public class Article_Datacollection_New  implements Serializable 
{
	private static final long serialVersionUID = 1L;
    private String articleId;
    private String articleClassificationScore;
    private String articleSummary;
    private String articleEmotion;
    private String articleEmotionScore;
    private String articleSource;
    private String articleType;
    private String articleNewsSource;
    private String articleTitle;
    private String articleSubTitle;
    private String metaData;
    private String articleBigContent;
    private String articleTitleContentHash;
    private String articleLinkUrl;
    private String articleAuthor;
    private String articleAuthorGender;
    private String articleAuthorReligion;
    private String articleAuthorId;
    private String articleAuthorImage;
    private String articleAuthorImageUrlLocal;
    private String articleLocation;
    private String articleLocationCity;
    private String articleLocationCountry;
    private String articleLocationCountryCode;
    private String articleUserLocation;
    private String articleUserLocationName;
    private String articleUserLocationCity;
    private String articleUserLocationCountry;
    private String articleUserLocationCountryCode;
    private String articleLocationPlace;
    private String articleMediaCaption;
    private String articleLanguage;
    private String articleOfflineUrl;
    private String articleAuthorScreenName;
    private String sourceId;
    
    private String rssUrl;
    private String rssCountryCode;
    private String rssCountry;
    private String articleTitleHash;
    private String articlePriority;
    private String articleNewsCategory;
    private String articleDarkwebCategory;
    private String profileImageFolder;
    private String mediaImageFolder;
    private String postImageOcrSearch;
    private String articleAuthorDescription;
    private String articleParentId;
    private String articleChildId;
    
    private ArrayList<Integer> articleMarked=new ArrayList<Integer>();
    private int articleSentiment=9;
    private ArrayList<ArticleUserReview> articleUserReview=new ArrayList<ArticleUserReview>();
    private ArrayList<Integer> entityId;
    
    private ArrayList<String> articleHashTag;
    private ArrayList<String> articleMention;
    private ArrayList<String> articleThemes; 
    private ArrayList<String> articleDomains; 
    private ArrayList<String> articleTag;
    private ArrayList<String> articleClassification; 
    private ArrayList<String> articleMobile; 
    private ArrayList<String> articleEmail; 
    private ArrayList<String> articleIp; 
    private ArrayList<String> articlePinCode;
    private ArrayList<String> vehicleNo;
    private ArrayList<String> mobileImeiNo; 
    private ArrayList<String> articleTimeNer; 
    private ArrayList<String> debitCreditCardNo; 
    private ArrayList<String> bankAccountNo;
    private ArrayList<String> taxonomy;
    private ArrayList<String> profileImageOds;
    private ArrayList<String> postImageOds;
    private ArrayList<String> postImageOcrAggs;
    private ArrayList<String> profileImageFrs;
    private ArrayList<String> postImageFrs;
    private ArrayList<String> keywordIds;
    
    private long articleInsertedDate;
    private long articlePublishDate;
    private long articleUpdateDate;
    
    private ArrayList<Article_Media> articleMedia;
    private ArrayList<Article_Image> articleImage;   
    private ArrayList<Articel_Ner> articlePersonNer;
    private ArrayList<Article_NerLocation> articleLocationNer;
    private ArrayList<Articel_Ner> articleOrganizationNer; 
    private ArrayList<Articel_Ner> articleEvent; 
    private ArrayList<Artilcle_Ner_Date> articleDateNer;
    private ArrayList<Articel_Comment> articleComment;
    
    private Article_Tweet tweet;
    private Article_Youtube youtube;
    private Article_DailyMotion dailymotion;
    private Article_Instagram instagram;
    private Article_Fb facebook;
    private Article_WordPress wordpress;
    private Article_GooglePlus gplus;
    private Article_GoogleBlogger blogger;
    private Article_DarkWeb darkweb;
    private Article_WhatsApp whatsApp;
    private Article_Telegram telegram;
    private ArrayList<String> articleAuthorImageUrlObjects;
    private Weibo weibo;
    private Article_NewsScrap newsScrap;
    private SearchEngine searchEngine;
    private String articleThreatClassification;
       
	public String getArticleThreatClassification() {
		return articleThreatClassification;
	}
	public void setArticleThreatClassification(String articleThreatClassification) {
		this.articleThreatClassification = articleThreatClassification;
	}
	public String getMetaData() {
		return metaData;
	}
	public void setMetaData(String metaData) {
		this.metaData = metaData;
	}
	public String getArticleAuthorDescription() {
		return articleAuthorDescription;
	}
	public void setArticleAuthorDescription(String articleAuthorDescription) {
		this.articleAuthorDescription = articleAuthorDescription;
	}
	public String getArticleParentId() {
		return articleParentId;
	}
	public void setArticleParentId(String articleParentId) {
		this.articleParentId = articleParentId;
	}
	public String getArticleChildId() {
		return articleChildId;
	}
	public void setArticleChildId(String articleChildId) {
		this.articleChildId = articleChildId;
	}
	public String getSourceId() {
		return sourceId;
	}
	public void setSourceId(String sourceId) {
		this.sourceId = sourceId;
	}
	
	public SearchEngine getSearchEngine() {
		return searchEngine;
	}
	public void setSearchEngine(SearchEngine searchEngine) {
		this.searchEngine = searchEngine;
	}
	public Article_Telegram getTelegram() {
		return telegram;
	}
	public void setTelegram(Article_Telegram telegram) {
		this.telegram = telegram;
	}
	public ArrayList<String> getProfileImageOds() {
		return profileImageOds;
	}
	public void setProfileImageOds(ArrayList<String> profileImageOds) {
		this.profileImageOds = profileImageOds;
	}
	public ArrayList<String> getPostImageOds() {
		return postImageOds;
	}
	public void setPostImageOds(ArrayList<String> postImageOds) {
		this.postImageOds = postImageOds;
	}
	public ArrayList<String> getPostImageOcrAggs() {
		return postImageOcrAggs;
	}
	public void setPostImageOcrAggs(ArrayList<String> postImageOcrAggs) {
		this.postImageOcrAggs = postImageOcrAggs;
	}
	public String getPostImageOcrSearch() {
		return postImageOcrSearch;
	}
	public void setPostImageOcrSearch(String postImageOcrSearch) {
		this.postImageOcrSearch = postImageOcrSearch;
	}
	public ArrayList<String> getProfileImageFrs() {
		return profileImageFrs;
	}
	public void setProfileImageFrs(ArrayList<String> profileImageFrs) {
		this.profileImageFrs = profileImageFrs;
	}
	public ArrayList<String> getPostImageFrs() {
		return postImageFrs;
	}
	public void setPostImageFrs(ArrayList<String> postImageFrs) {
		this.postImageFrs = postImageFrs;
	}
	public Article_NewsScrap getNewsScrap() {
		return newsScrap;
	}
	public void setNewsScrap(Article_NewsScrap newsScrap) {
		this.newsScrap = newsScrap;
	}
	public ArrayList<Article_Image> getArticleImage() {
		return articleImage;
	}
	public void setArticleImage(ArrayList<Article_Image> articleImage) {
		this.articleImage = articleImage;
	}
	public String getArticlePriority() {
		return articlePriority;
	}
	public void setArticlePriority(String articlePriority) {
		this.articlePriority = articlePriority;
	}
	public String getArticleNewsCategory() {
		return articleNewsCategory;
	}
	public void setArticleNewsCategory(String articleNewsCategory) {
		this.articleNewsCategory = articleNewsCategory;
	}
	public String getArticleDarkwebCategory() {
		return articleDarkwebCategory;
	}
	public void setArticleDarkwebCategory(String articleDarkwebCategory) {
		this.articleDarkwebCategory = articleDarkwebCategory;
	}
	public String getProfileImageFolder() {
		return profileImageFolder;
	}
	public void setProfileImageFolder(String profileImageFolder) {
		this.profileImageFolder = profileImageFolder;
	}
	public String getMediaImageFolder() {
		return mediaImageFolder;
	}
	public void setMediaImageFolder(String mediaImageFolder) {
		this.mediaImageFolder = mediaImageFolder;
	}
	public String getArticleTitleHash() {
		return articleTitleHash;
	}
	public void setArticleTitleHash(String articleTitleHash) {
		this.articleTitleHash = articleTitleHash;
	}
	
	public Weibo getWeibo() {
    	return weibo;
    }
    public void setWeibo(Weibo weibo) {
    	this.weibo = weibo;
    }
    public ArrayList<String> getArticleMobile() {
    	return articleMobile;
    }
    public void setArticleMobile(ArrayList<String> articleMobile) {
    	this.articleMobile = articleMobile;
    }
    public ArrayList<String> getArticleEmail() {
    	return articleEmail;
    }
    public void setArticleEmail(ArrayList<String> articleEmail) {
    	this.articleEmail = articleEmail;
    }
    public ArrayList<String> getArticleClassification() {
    	return articleClassification;
    }
    public void setArticleClassification(ArrayList<String> articleClassification) {
    	this.articleClassification = articleClassification;
    }
    public String getArticleId() {
    	return articleId;
    }
    public void setArticleId(String articleId) {
    	this.articleId = articleId;
    }
    public String getArticleSource() {
    	return articleSource;
    }
    public void setArticleSource(String articleSource) {
    	this.articleSource = articleSource;
    }
    public String getArticleType() {
    	return articleType;
    }
    public void setArticleType(String articleType) {
    	this.articleType = articleType;
    }
    public String getArticleNewsSource() {
    	return articleNewsSource;
    }
    public void setArticleNewsSource(String articleNewsSource) {
    	this.articleNewsSource = articleNewsSource;
    }
    public String getArticleTitle() {
    	return articleTitle;
    }
    public void setArticleTitle(String articleTitle) {
    	this.articleTitle = articleTitle;
    }
    public String getArticleSubTitle() {
    	return articleSubTitle;
    }
    public void setArticleSubTitle(String articleSubTitle) {
    	this.articleSubTitle = articleSubTitle;
    }
    public String getArticleBigContent() {
    	return articleBigContent;
    }
    public void setArticleBigContent(String articleBigContent) {
    	this.articleBigContent = articleBigContent;
    }
    public String getArticleTitleContentHash() {
		return articleTitleContentHash;
	}
	public void setArticleTitleContentHash(String articleTitleContentHash) {
		this.articleTitleContentHash = articleTitleContentHash;
	}
	public String getArticleLinkUrl() {
    	return articleLinkUrl;
    }
    public void setArticleLinkUrl(String articleLinkUrl) {
    	this.articleLinkUrl = articleLinkUrl;
    }
    public String getArticleAuthor() {
    	return articleAuthor;
    }
    public void setArticleAuthor(String articleAuthor) {
    	this.articleAuthor = articleAuthor;
    }
    public String getArticleAuthorId() {
    	return articleAuthorId;
    }
    public void setArticleAuthorId(String articleAuthorId) {
    	this.articleAuthorId = articleAuthorId;
    }
    public String getArticleAuthorImage() {
    	return articleAuthorImage;
    }
    public void setArticleAuthorImage(String articleAuthorImage) {
    	this.articleAuthorImage = articleAuthorImage;
    }
    public String getArticleLocation() {
    	return articleLocation;
    }
    public void setArticleLocation(String articleLocation) {
    	this.articleLocation = articleLocation;
    }
    public String getArticleOfflineUrl() {
		return articleOfflineUrl;
	}
	public void setArticleOfflineUrl(String articleOfflineUrl) {
		this.articleOfflineUrl = articleOfflineUrl;
	}
	public String getArticleAuthorScreenName() {
		return articleAuthorScreenName;
	}
	public void setArticleAuthorScreenName(String articleAuthorScreenName) {
		this.articleAuthorScreenName = articleAuthorScreenName;
	}
	public String getArticleLocationCountry() {
    	return articleLocationCountry;
    }
    public void setArticleLocationCountry(String articleLocationCountry) {
    	this.articleLocationCountry = articleLocationCountry;
    }
    public String getArticleLocationCity() {
    	return articleLocationCity;
    }
    public void setArticleLocationCity(String articleLocationCity) {
    	this.articleLocationCity = articleLocationCity;
    }
    public String getArticleLocationPlace() {
    	return articleLocationPlace;
    }
    public void setArticleLocationPlace(String articleLocationPlace) {
    	this.articleLocationPlace = articleLocationPlace;
    }
    public String getArticleMediaCaption() {
		return articleMediaCaption;
	}
	public void setArticleMediaCaption(String articleMediaCaption) {
		this.articleMediaCaption = articleMediaCaption;
	}
	public String getArticleLanguage() {
    	return articleLanguage;
    }
    public void setArticleLanguage(String articleLanguage) {
    	this.articleLanguage = articleLanguage;
    }
    public ArrayList<Integer> getEntityId() {
    	return entityId;
    }
    public void setEntityId(ArrayList<Integer> entityId) {
    	this.entityId = entityId;
    }
	public ArrayList<String> getArticleHashTag() {
    	return articleHashTag;
    }
    public void setArticleHashTag(ArrayList<String> articleHashTag) {
    	this.articleHashTag = articleHashTag;
    }
    public ArrayList<String> getArticleMention() {
    	return articleMention;
    }
    public void setArticleMention(ArrayList<String> articleMention) {
    	this.articleMention = articleMention;
    }
    public ArrayList<String> getArticleThemes() {
    	return articleThemes;
    }
    public void setArticleThemes(ArrayList<String> articleThemes) {
    	this.articleThemes = articleThemes;
    }
    public ArrayList<String> getArticleDomains() {
    	return articleDomains;
    }
    public void setArticleDomains(ArrayList<String> articleDomains) {
    	this.articleDomains = articleDomains;
    }
    public ArrayList<String> getArticleTag() {
    	return articleTag;
    }
    public void setArticleTag(ArrayList<String> articleTag) {
    	this.articleTag = articleTag;
    }
    public long getArticleInsertedDate() {
    	return articleInsertedDate;
    }
    public void setArticleInsertedDate(long articleInsertedDate) {
    	this.articleInsertedDate = articleInsertedDate;
    }
    public long getArticlePublishDate() {
    	return articlePublishDate;
    }
    public void setArticlePublishDate(long articlePublishDate) {
    	this.articlePublishDate = articlePublishDate;
    }
    public long getArticleUpdateDate() {
    	return articleUpdateDate;
    }
    public void setArticleUpdateDate(long articleUpdateDate) {
    	this.articleUpdateDate = articleUpdateDate;
    }
    public ArrayList<Articel_Ner> getArticlePersonNer() {
    	return articlePersonNer;
    }
    public void setArticlePersonNer(ArrayList<Articel_Ner> articlePersonNer) {
    	this.articlePersonNer = articlePersonNer;
    }
    public ArrayList<Articel_Ner> getArticleOrganizationNer() {
    	return articleOrganizationNer;
    }
    public void setArticleOrganizationNer(
    		ArrayList<Articel_Ner> articleOrganizationNer) {
    	this.articleOrganizationNer = articleOrganizationNer;
    }
    public ArrayList<Artilcle_Ner_Date> getArticleDateNer() {
    	return articleDateNer;
    }
    public void setArticleDateNer(ArrayList<Artilcle_Ner_Date> articleDateNer) {
    	this.articleDateNer = articleDateNer;
    }
    public ArrayList<Article_NerLocation> getArticleLocationNer() {
    	return articleLocationNer;
    }
    public void setArticleLocationNer(
    		ArrayList<Article_NerLocation> articleLocationNer) {
    	this.articleLocationNer = articleLocationNer;
    }
    public ArrayList<Articel_Comment> getArticleComment() {
    	return articleComment;
    }
    public void setArticleComment(ArrayList<Articel_Comment> articleComment) {
    	this.articleComment = articleComment;
    }
    public Article_Tweet getTweet() {
    	return tweet;
    }
    public void setTweet(Article_Tweet tweet) {
    	this.tweet = tweet;
    }
    public Article_Youtube getYoutube() {
    	return youtube;
    }
    public void setYoutube(Article_Youtube youtube) {
    	this.youtube = youtube;
    }
    public Article_DailyMotion getDailymotion() {
    	return dailymotion;
    }
    public void setDailymotion(Article_DailyMotion dailymotion) {
    	this.dailymotion = dailymotion;
    }
    public Article_Instagram getInstagram() {
    	return instagram;
    }
    public void setInstagram(Article_Instagram instagram) {
    	this.instagram = instagram;
    }
    public Article_Fb getFacebook() {
    	return facebook;
    }
    public void setFacebook(Article_Fb facebook) {
    	this.facebook = facebook;
    }
    public Article_WordPress getWordpress() {
    	return wordpress;
    }
    public void setWordpress(Article_WordPress wordpress) {
    	this.wordpress = wordpress;
    }
    public Article_GooglePlus getGplus() {
    	return gplus;
    }
    public void setGplus(Article_GooglePlus gplus) {
    	this.gplus = gplus;
    }
    public String getArticleLocationCountryCode() {
    	return articleLocationCountryCode;
    }
    public void setArticleLocationCountryCode(String articleLocationCountryCode) {
    	this.articleLocationCountryCode = articleLocationCountryCode;
    }
    public String getArticleUserLocation() {
		return articleUserLocation;
	}
	public void setArticleUserLocation(String articleUserLocation) {
		this.articleUserLocation = articleUserLocation;
	}
	public String getArticleUserLocationName() {
		return articleUserLocationName;
	}
	public void setArticleUserLocationName(String articleUserLocationName) {
		this.articleUserLocationName = articleUserLocationName;
	}
	public String getArticleUserLocationCity() {
		return articleUserLocationCity;
	}
	public void setArticleUserLocationCity(String articleUserLocationCity) {
		this.articleUserLocationCity = articleUserLocationCity;
	}
	public String getArticleUserLocationCountry() {
		return articleUserLocationCountry;
	}
	public void setArticleUserLocationCountry(String articleUserLocationCountry) {
		this.articleUserLocationCountry = articleUserLocationCountry;
	}
	public String getArticleUserLocationCountryCode() {
		return articleUserLocationCountryCode;
	}
	public void setArticleUserLocationCountryCode(String articleUserLocationCountryCode) {
		this.articleUserLocationCountryCode = articleUserLocationCountryCode;
	}
	public ArrayList<Article_Media> getArticleMedia() {
    	return articleMedia;
    }
    public void setArticleMedia(ArrayList<Article_Media> articleMedia) {
    	this.articleMedia = articleMedia;
    }
    public Article_GoogleBlogger getBlogger() {
    	return blogger;
    }
    public void setBlogger(Article_GoogleBlogger blogger) {
    	this.blogger = blogger;
    }
    public ArrayList<Integer> getArticleMarked() {
    	return articleMarked;
    }
    public void setArticleMarked(ArrayList<Integer> articleMarked) {
    	this.articleMarked = articleMarked;
    }
    public int getArticleSentiment() {
    	return articleSentiment;
    }
    public void setArticleSentiment(int articleSentiment) {
    	this.articleSentiment = articleSentiment;
    }
    public ArrayList<ArticleUserReview> getArticleUserReview() {
    	return articleUserReview;
    }
    public void setArticleUserReview(ArrayList<ArticleUserReview> articleUserReview) {
    	this.articleUserReview = articleUserReview;
    }
    public String getArticleSummary() {
    	return articleSummary;
    }
    public void setArticleSummary(String articleSummary) {
    	this.articleSummary = articleSummary;
    }
    public String getArticleEmotion() {
    	return articleEmotion;
    }
    public void setArticleEmotion(String articleEmotion) {
    	this.articleEmotion = articleEmotion;
    }
    public String getArticleEmotionScore() {
    	return articleEmotionScore;
    }
    public void setArticleEmotionScore(String articleEmotionScore) {
    	this.articleEmotionScore = articleEmotionScore;
    }
    public String getArticleClassificationScore() {
    	return articleClassificationScore;
    }
    public void setArticleClassificationScore(String articleClassificationScore) {
    	this.articleClassificationScore = articleClassificationScore;
    }
    public String getArticleAuthorImageUrlLocal() {
    	return articleAuthorImageUrlLocal;
    }
    public void setArticleAuthorImageUrlLocal(String articleAuthorImageUrlLocal) {
    	this.articleAuthorImageUrlLocal = articleAuthorImageUrlLocal;
    }
    public ArrayList<String> getArticleIp() {
    	return articleIp;
    }
    public void setArticleIp(ArrayList<String> articleIp) {
    	this.articleIp = articleIp;
    }
    public ArrayList<String> getArticlePinCode() {
    	return articlePinCode;
    }
    public void setArticlePinCode(ArrayList<String> articlePinCode) {
    	this.articlePinCode = articlePinCode;
    }
    public ArrayList<String> getVehicleNo() {
    	return vehicleNo;
    }
    public void setVehicleNo(ArrayList<String> vehicleNo) {
    	this.vehicleNo = vehicleNo;
    }
    public ArrayList<String> getMobileImeiNo() {
    	return mobileImeiNo;
    }
    public void setMobileImeiNo(ArrayList<String> mobileImeiNo) {
    	this.mobileImeiNo = mobileImeiNo;
    }
    public ArrayList<String> getArticleTimeNer() {
    	return articleTimeNer;
    }
    public void setArticleTimeNer(ArrayList<String> articleTimeNer) {
    	this.articleTimeNer = articleTimeNer;
    }
    public ArrayList<String> getDebitCreditCardNo() {
    	return debitCreditCardNo;
    }
    public void setDebitCreditCardNo(ArrayList<String> debitCreditCardNo) {
    	this.debitCreditCardNo = debitCreditCardNo;
    }
    public ArrayList<String> getBankAccountNo() {
    	return bankAccountNo;
    }
    public void setBankAccountNo(ArrayList<String> bankAccountNo) {
    	this.bankAccountNo = bankAccountNo;
    }
    public String getArticleAuthorGender() {
    	return articleAuthorGender;
    }
    public void setArticleAuthorGender(String articleAuthorGender) {
    	this.articleAuthorGender = articleAuthorGender;
    }
    public String getArticleAuthorReligion() {
    	return articleAuthorReligion;
    }
    public void setArticleAuthorReligion(String articleAuthorReligion) {
    	this.articleAuthorReligion = articleAuthorReligion;
    }
    public ArrayList<Articel_Ner> getArticleEvent() {
    	return articleEvent;
    }
    public void setArticleEvent(ArrayList<Articel_Ner> articleEvent) {
    	this.articleEvent = articleEvent;
    }
    public ArrayList<String> getTaxonomy() {
    	return taxonomy;
    }
    public void setTaxonomy(ArrayList<String> taxonomy) {
    	this.taxonomy = taxonomy;
    }
    public String getRssUrl() {
    	return rssUrl;
    }
    public void setRssUrl(String rssUrl) {
    	this.rssUrl = rssUrl;
    }
    public String getRssCountryCode() {
    	return rssCountryCode;
    }
    public void setRssCountryCode(String rssCountryCode) {
    	this.rssCountryCode = rssCountryCode;
    }
    public String getRssCountry() {
    	return rssCountry;
    }
    public void setRssCountry(String rssCountry) {
    	this.rssCountry = rssCountry;
    }
    public Article_DarkWeb getDarkweb() {
    	return darkweb;
    }
    public void setDarkweb(Article_DarkWeb darkweb) {
    	this.darkweb = darkweb;
    }
    public Article_WhatsApp getWhatsApp() {
    	return whatsApp;
    }
    public void setWhatsApp(Article_WhatsApp whatsApp) {
    	this.whatsApp = whatsApp;
    }
    public ArrayList<String> getArticleAuthorImageUrlObjects() {
    	return articleAuthorImageUrlObjects;
    }
    public void setArticleAuthorImageUrlObjects(ArrayList<String> articleAuthorImageUrlObjects) {
    	this.articleAuthorImageUrlObjects = articleAuthorImageUrlObjects;
    }
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public ArrayList<String> getKeywordIds() {
		return keywordIds;
	}
	public void setKeywordIds(ArrayList<String> keywordIds) {
		this.keywordIds = keywordIds;
	}
	@Override
	public String toString() {
		return "Article_Datacollection_New [articleId=" + articleId + ", articleClassificationScore="
				+ articleClassificationScore + ", articleSummary=" + articleSummary + ", articleEmotion="
				+ articleEmotion + ", articleEmotionScore=" + articleEmotionScore + ", articleSource=" + articleSource
				+ ", articleType=" + articleType + ", articleNewsSource=" + articleNewsSource + ", articleTitle="
				+ articleTitle + ", articleSubTitle=" + articleSubTitle + ", metaData=" + metaData
				+ ", articleBigContent=" + articleBigContent + ", articleTitleContentHash=" + articleTitleContentHash
				+ ", articleLinkUrl=" + articleLinkUrl + ", articleAuthor=" + articleAuthor + ", articleAuthorGender="
				+ articleAuthorGender + ", articleAuthorReligion=" + articleAuthorReligion + ", articleAuthorId="
				+ articleAuthorId + ", articleAuthorImage=" + articleAuthorImage + ", articleAuthorImageUrlLocal="
				+ articleAuthorImageUrlLocal + ", articleLocation=" + articleLocation + ", articleLocationCity="
				+ articleLocationCity + ", articleLocationCountry=" + articleLocationCountry
				+ ", articleLocationCountryCode=" + articleLocationCountryCode + ", articleUserLocation="
				+ articleUserLocation + ", articleUserLocationName=" + articleUserLocationName
				+ ", articleUserLocationCity=" + articleUserLocationCity + ", articleUserLocationCountry="
				+ articleUserLocationCountry + ", articleUserLocationCountryCode=" + articleUserLocationCountryCode
				+ ", articleLocationPlace=" + articleLocationPlace + ", articleMediaCaption=" + articleMediaCaption
				+ ", articleLanguage=" + articleLanguage + ", articleOfflineUrl=" + articleOfflineUrl
				+ ", articleAuthorScreenName=" + articleAuthorScreenName + ", sourceId=" + sourceId + ", rssUrl="
				+ rssUrl + ", rssCountryCode=" + rssCountryCode + ", rssCountry=" + rssCountry + ", articleTitleHash="
				+ articleTitleHash + ", articlePriority=" + articlePriority + ", articleNewsCategory="
				+ articleNewsCategory + ", articleDarkwebCategory=" + articleDarkwebCategory + ", profileImageFolder="
				+ profileImageFolder + ", mediaImageFolder=" + mediaImageFolder + ", postImageOcrSearch="
				+ postImageOcrSearch + ", articleAuthorDescription=" + articleAuthorDescription + ", articleParentId="
				+ articleParentId + ", articleChildId=" + articleChildId + ", articleMarked=" + articleMarked
				+ ", articleSentiment=" + articleSentiment + ", articleUserReview=" + articleUserReview + ", entityId="
				+ entityId + ", articleHashTag=" + articleHashTag + ", articleMention=" + articleMention
				+ ", articleThemes=" + articleThemes + ", articleDomains=" + articleDomains + ", articleTag="
				+ articleTag + ", articleClassification=" + articleClassification + ", articleMobile=" + articleMobile
				+ ", articleEmail=" + articleEmail + ", articleIp=" + articleIp + ", articlePinCode=" + articlePinCode
				+ ", vehicleNo=" + vehicleNo + ", mobileImeiNo=" + mobileImeiNo + ", articleTimeNer=" + articleTimeNer
				+ ", debitCreditCardNo=" + debitCreditCardNo + ", bankAccountNo=" + bankAccountNo + ", taxonomy="
				+ taxonomy + ", profileImageOds=" + profileImageOds + ", postImageOds=" + postImageOds
				+ ", postImageOcrAggs=" + postImageOcrAggs + ", profileImageFrs=" + profileImageFrs + ", postImageFrs="
				+ postImageFrs + ", keywordIds=" + keywordIds + ", articleInsertedDate=" + articleInsertedDate
				+ ", articlePublishDate=" + articlePublishDate + ", articleUpdateDate=" + articleUpdateDate
				+ ", articleMedia=" + articleMedia + ", articleImage=" + articleImage + ", articlePersonNer="
				+ articlePersonNer + ", articleLocationNer=" + articleLocationNer + ", articleOrganizationNer="
				+ articleOrganizationNer + ", articleEvent=" + articleEvent + ", articleDateNer=" + articleDateNer
				+ ", articleComment=" + articleComment + ", tweet=" + tweet + ", youtube=" + youtube + ", dailymotion="
				+ dailymotion + ", instagram=" + instagram + ", facebook=" + facebook + ", wordpress=" + wordpress
				+ ", gplus=" + gplus + ", blogger=" + blogger + ", darkweb=" + darkweb + ", whatsApp=" + whatsApp
				+ ", telegram=" + telegram + ", articleAuthorImageUrlObjects=" + articleAuthorImageUrlObjects
				+ ", weibo=" + weibo + ", newsScrap=" + newsScrap + ", searchEngine=" + searchEngine
				+ ", articleThreatClassification=" + articleThreatClassification + "]";
	}
}