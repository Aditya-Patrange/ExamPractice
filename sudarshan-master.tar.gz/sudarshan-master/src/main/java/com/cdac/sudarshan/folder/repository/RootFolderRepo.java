package com.cdac.sudarshan.folder.repository;

import com.cdac.sudarshan.authentication.model.User;
import com.cdac.sudarshan.folder.model.RootFolder;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RootFolderRepo extends JpaRepository<RootFolder, Long> {

	RootFolder findByRootFolderNameAndUser(String rootFolderName, User user);

	RootFolder findByRootFolderName(String rootFolderName);

	List<RootFolder> findByUser_Id(Long id);
	List<RootFolder> findByUser(User user);



}
