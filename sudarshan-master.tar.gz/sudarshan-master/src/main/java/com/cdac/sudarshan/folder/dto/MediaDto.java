package com.cdac.sudarshan.folder.dto;

import lombok.Getter;
import lombok.Setter;


@Setter
@Getter
public class MediaDto {
    private String filePath;
    private String fileName;
    private String type;
    private String tag;
}
