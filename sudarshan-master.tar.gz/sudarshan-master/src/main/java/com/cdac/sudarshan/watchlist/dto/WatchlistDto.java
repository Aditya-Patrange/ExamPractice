package com.cdac.sudarshan.watchlist.dto;

import java.time.Instant;

import javax.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class WatchlistDto {

	@NotBlank(message = "Watchlist Name cannot be blank!!")
	private String watchlistName;
	@NotBlank(message = "Attribute cannot be blank!!")
	private String entityAttribute;
//	private List<BaseEntityDto> sourceIdList;

	private int sourceIdList;
	private int frequencyId;
	private Instant fromDate;
	private Instant toDate;
	private String priority;
	private String remarks;

}