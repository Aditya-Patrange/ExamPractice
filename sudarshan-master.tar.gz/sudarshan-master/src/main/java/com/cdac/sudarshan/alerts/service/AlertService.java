package com.cdac.sudarshan.alerts.service;

import com.cdac.sudarshan.alerts.model.Alert;
import com.cdac.sudarshan.alerts.model.CaseVo;
import com.cdac.sudarshan.alerts.repository.AlertRepository;
import com.cdac.sudarshan.authentication.controller.AuthController;
import com.cdac.sudarshan.authentication.model.User;
import com.cdac.sudarshan.authentication.service.IUserService;
import com.cdac.sudarshan.discover.common.CommonUtils;
import com.cdac.sudarshan.dto.RequestDTO;
import com.cdac.sudarshan.exception.ResourceNotFoundException;
import com.cdac.sudarshan.folder.model.SubFolderPaths;
import com.cdac.sudarshan.folder.repository.RootFolderRepo;
import com.cdac.sudarshan.folder.repository.SubFolderPathsRepo;
import com.cdac.sudarshan.folder.repository.UrlsPathRepo;
import com.cdac.sudarshan.watchlist.configuration.ApplicationConfiguration;
import com.cdac.sudarshan.watchlist.dto.ResponseDto;
import com.cdac.sudarshan.watchlist.model.Watchlist;
import com.cdac.sudarshan.watchlist.repository.WatchlistRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.google.gson.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.client.RestTemplate;

import java.lang.reflect.Type;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.util.*;

@Service
public class AlertService implements IAlertService {

    @Autowired
    private IUserService userService;
    @Autowired
    private PlatformTransactionManager transactionManager;

    @Autowired
    private JdbcTemplate jdbcTemplateTwo;

    @Autowired
    private WatchlistRepository watchlistRepository;

    @Autowired
    private SubFolderPathsRepo subFolderPathsRepo;

    @Autowired
    private RootFolderRepo rootFolderRepo;

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private UrlsPathRepo urlsPathRepo;

    @Autowired
    private AlertRepository alertRepository;

    @Autowired
    private RestTemplate template;

    @Autowired
    private ApplicationConfiguration appConfig;

    private static final Logger logger = LoggerFactory.getLogger(AlertService.class);

    public Alert saveAlert(Alert alert) {
        try {
//			System.out.println("Alert data added..");
            return alertRepository.save(alert);
//			return alertRepository.insertData();
        } catch (Exception e) {
            logger.error("Exception occur while save Alert ", e);
            return null;
        }
    }

//	public static void parse(String jsonLine) {
//	    JsonObject root = new JsonParser().parse(jsonLine).getAsJsonObject();
//	    JsonArray terms = root.getAsJsonObject("_source").getAsJsonArray("articleId");
//	          
//	    for (int i = 0; i < terms.size(); i++) {
//	        JsonObject term = terms.get(i).getAsJsonObject();
//	        System.out.printf("%s - %s \n", term.get("term").toString(), term.get("count").toString());
//	    }
//
//	}

    @Override
    public String getAlertsDataFromEs(String path, String size) throws Exception {
        SubFolderPaths s = subFolderPathsRepo.findBySubFolderPathName(path);
        List<String> urlsList = urlsPathRepo.findUrlBySubFolerPathId(s.getId());

        RequestDTO dtoForEs = new RequestDTO();
        dtoForEs.setList(urlsList);
        dtoForEs.setSize(Integer.parseInt(size));

//		HttpHeaders headers = new HttpHeaders();
//		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
//		HttpEntity<RequestDTO> entity = new HttpEntity<RequestDTO>(dtoForEs, headers);

//		String body = restTemplate.exchange("http://localhost:8009/elastic/", HttpMethod.POST, entity, String.class).getBody();

        String data = restTemplate.postForObject("http://localhost:8009/esAlertData/", dtoForEs, String.class);
//		parse(data);

        JsonParser parser = new JsonParser();
        JsonArray jsonArray = (JsonArray) parser.parse(data);
        for (Object o : jsonArray) {
            JsonObject jsonObject = (JsonObject) o;

//			Gson gson = new Gson();
            Gson gson = new GsonBuilder()
                    .registerTypeAdapter(LocalDateTime.class, new JsonDeserializer<LocalDateTime>() {
                        @Override
                        public LocalDateTime deserialize(JsonElement json, Type type,
                                                         JsonDeserializationContext jsonDeserializationContext) throws JsonParseException {
                            return ZonedDateTime.parse(json.getAsJsonPrimitive().getAsString()).toLocalDateTime();
                        }
                    }).create();

            JsonObject source = (JsonObject) jsonObject.get("_source");


            JsonObject alertJson = new JsonObject();
//			alertJson.add("article", jsonArray)
            alertJson.add("articleId", source.get("articleId"));
            alertJson.add("articleTitle", source.get("articleTitle"));
            alertJson.add("articleSource", source.get("articleSource"));
            alertJson.add("articleLinkUrl", source.get("articleLinkUrl"));
            alertJson.add("articleNewsSource", source.get("articleNewsSource"));
            alertJson.add("articleAuthorId", source.get("articleAuthorId"));
            alertJson.add("creationDate", source.get("creationDate"));


            Alert alert = new Alert();
//			alert.setCreatedAt(new Date());
//			alert.setUser(AuthController.mainUser);
            alert = gson.fromJson(alertJson, Alert.class);

            saveAlert(alert);
        }
        return data;
    }

    @Override
    public List<Alert> getAlerts() {
        return alertRepository.findAll();
    }

    //	saveAlertsToDB(data);
    @Override
    public ResponseEntity<?> saveAlertsToDB(HashMap<String, Object> data) throws Exception {

        ResponseEntity<?> entity = null;
        List<Watchlist> allWatchlists = watchlistRepository.getAllWatchlists();
//		System.out.println("all watchlist : " + allWatchlists);
        int count = 0;
        for (Watchlist watchlist : allWatchlists) {

            String sourceValue = watchlist.getSource().getValue();
            Instant fromDate = watchlist.getFromDate();
            Instant toDate = watchlist.getToDate();
            String attribute = watchlist.getAttributes();

            Date from = Date.from(fromDate);
            Date to = Date.from(toDate);

            SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
            String formattedFromDate = formatter.format(from);
            String formattedToDate = formatter.format(to);

//			System.out.println("From = " + formattedFromDate);
//			System.out.println("To = " + formattedToDate);

            data.put("dateFrom", formattedFromDate);
            data.put("dateTo", formattedToDate);
            data.put("sourceFilter", sourceValue);
            data.put("keywordFilter", attribute);
            getAlertsDataFromCollections(data);

        }
        return new ResponseEntity<>("Alerts Added to DB", HttpStatus.OK);
    }

    @Override
    public ResponseEntity<?> getAlertsDataFromCollections(HashMap<String, Object> data)
            throws JsonMappingException, JsonProcessingException {

        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<Object>(data, headers);
//		System.out.println("entity : " + data);

        ResponseEntity<Object> resultData = template.exchange(appConfig.getProperty("URL") + "getTweets",
                HttpMethod.POST, entity, Object.class);

        // Default Gson Object
        Gson gson = new Gson();
        Gson gson1 = new GsonBuilder().registerTypeAdapter(LocalDateTime.class, new JsonDeserializer<LocalDateTime>() {
            @Override
            public LocalDateTime deserialize(JsonElement json, Type type,
                                             JsonDeserializationContext jsonDeserializationContext) throws JsonParseException {
                return ZonedDateTime.parse(json.getAsJsonPrimitive().getAsString()).toLocalDateTime();
            }
        }).create();
//		System.out.println("result data : " + resultData.getBody());
        String stringJson = gson.toJson(resultData.getBody());
        JsonParser parser = new JsonParser();
        JsonObject source = (JsonObject) parser.parse(stringJson);
        JsonArray jsonArray = (JsonArray) parser.parse(source.get("body").toString());

        // Converting User Object into JsonObject.
//		User user = AuthController.mainUser;
//		 String userJsonString = gson1.toJson(user);
//		 JsonObject userJson =  (JsonObject) parser.parse(userJsonString);
//		 System.out.println("USER = " + user.toString());
//

        List<Alert> alerts = alertRepository.findAll();
        Set<String> alertIDs = new HashSet<>();
        for (Alert alert : alerts) {
//			System.out.println("AlertIDs =" + alert.getArticleId());
            alertIDs.add(alert.getArticleId());
        }

        for (Object o : jsonArray) {
            JsonObject jsonObject = (JsonObject) o;

            JsonObject alertJson = new JsonObject();
            alertJson.add("articleId", jsonObject.get("articleId"));
            alertJson.add("articleTitle", jsonObject.get("articleTitle"));
            alertJson.add("articleSource", jsonObject.get("articleSource"));
            alertJson.add("articleLinkUrl", jsonObject.get("link"));
            alertJson.add("articleNewsSource", jsonObject.get("articleNewsSource"));
            alertJson.add("articleAuthor", jsonObject.get("articleAuthor"));
            alertJson.add("creationDate", jsonObject.get("creationDate"));

//			System.out.println("Alert JSON - " + alertJson);

            Alert alert = new Alert();
//			alert.setCreatedAt(new Date());

//			System.out.println("alert : " + alert);
            alert = gson1.fromJson(alertJson, Alert.class);
            alert.setUserId(AuthController.mainUser.getId());
            alert.setRead(false);
//			System.out.println("alert :" + alert);
            String input = jsonObject.get("articleId").toString();
            String res = input.replaceAll("^\"|\"$", "");
//			System.out.println("res - "+res);
//			alertIDs.forEach(System.out::println);
            if (!alertIDs.contains(res)) {
                saveAlert(alert);
            }
        }
        return resultData;
    }

    @Override
    public List<Alert> getAlertsByUserID(Long userId) {
        return alertRepository.findByUserId(userId);
    }


    public void addUserAlertsImplementation(CaseVo caseVo) {

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication.getName() == null) {
            throw new ResourceNotFoundException("Please Login first For getting urls count");
        }
        User loggedInUser = userService.getUserByUserName(authentication.getName());
        String user = loggedInUser.getUsername();
        if (caseVo.getId().equals("")) {
//            System.out.println("CASEVO.GETID = " + caseVo.getUid());
            String query = " insert ignore into "
                    + "tbl_alert(alert_name, keyword, mail_to, mail_cc, mail_bcc, mobile_no, alert_via_m, alert_via_e, notification, activation_flag,"
                    + " login_id, alert_created_at, frequency, count_limit, sentiment, user, alert_type, case_id, snapshot_id, threat_classification) "
                    + " values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            KeyHolder keyHolder = new GeneratedKeyHolder();
            jdbcTemplateTwo.update(new PreparedStatementCreator() {
                public PreparedStatement createPreparedStatement(Connection connection) throws
                        SQLException {
                    PreparedStatement ps = connection.prepareStatement(query,
                            Statement.RETURN_GENERATED_KEYS);
                    ps.setString(1, caseVo.getKey1().trim());
                    ps.setString(2, caseVo.getKey2() == null ? "" : caseVo.getKey2().trim());
                    ps.setString(3, caseVo.getKey7().trim());
                    ps.setString(4, caseVo.getKey8().trim());
                    ps.setString(5, caseVo.getKey9().trim());
                    ps.setString(6, caseVo.getKey10().trim());
                    ps.setString(7, caseVo.getKey5().trim());
                    ps.setString(8, caseVo.getKey6().trim());
                    ps.setString(9, caseVo.getKey11().trim());
//ps.setString(10, caseVo.getKey3().trim());
                    ps.setString(10, caseVo.getKey4().trim());
                    ps.setString(11, loggedInUser.getId().toString());
                    ps.setString(12, CommonUtils.getSqlCurrentDateTime());
//					Date dt = new Date();
//					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//					ps.setString(12, sdf.format(dt));
                    ps.setString(13, caseVo.getFrequency().trim());
                    ps.setString(14, caseVo.getCountLimit().trim());
                    ps.setString(15, caseVo.getSentiment().trim());
                    ps.setString(16, user);
                    ps.setString(17, caseVo.getAccountType().trim());
                    ps.setInt(18, (caseVo.getCaseId() == null ||
                            caseVo.getCaseId() == "") ? 0 : Integer.parseInt(caseVo.getCaseId().trim()));
                    ps.setInt(19, (caseVo.getUserId() == null ||
                            caseVo.getUserId() == "") ? 0 : Integer.parseInt(caseVo.getUserId().trim()));
                    ps.setString(20, caseVo.getThreatScore().trim());

                    return ps;
                }
            }, keyHolder);
            int crawlerAutogenertdId = keyHolder.getKey().intValue();

            ArrayList<ArrayList<String>> alertDay = caseVo.getAlertDay();
            for (ArrayList<String> dayList : alertDay) {
                String query2 = " insert ignore into tbl_alert_interval(alert_id, day, hour, minutes) values(?, ?, ?, ?)";
                jdbcTemplateTwo.update(query2, new Object[]{crawlerAutogenertdId, dayList.get(0), dayList.get(1), dayList.get(2)});
            }
        } else {
            String keyword = caseVo.getKey2() == null ? "" : caseVo.getKey2().trim();
            int caseId =
                    caseVo.getCaseId() == null ? 0 : Integer.parseInt(caseVo.getCaseId().trim());
            int snapshotId =
                    caseVo.getUserId() == null ? 0 : Integer.parseInt(caseVo.getUserId().trim());
            String sentiment =
                    caseVo.getSentiment().trim().length() == 0 ? "0" : caseVo.getSentiment().trim();
            String threatClassification = caseVo.getThreatScore().trim();

            String query = " update tbl_alert set keyword='" + keyword + "',"
                    + " mail_to='" + caseVo.getKey7().trim() + "', mail_cc='" + caseVo.getKey8().trim() + "', mail_bcc='" + caseVo.getKey9().trim() + "',"
                    + " mobile_no='" + caseVo.getKey10().trim() + "', alert_via_m='" + caseVo.getKey5().trim() + "',  alert_via_e='" + caseVo.getKey6().trim() + "',"
                    + " notification='" + caseVo.getKey11().trim() + "',  frequency='" + caseVo.getFrequency().trim() + "',  count_limit='" + caseVo.getCountLimit().trim() + "',"
                    + " sentiment='" + sentiment + "', threat_classification='" + threatClassification + "', user='" + caseVo.getUser().trim() + "', alert_type='" + caseVo.getAccountType().trim() + "',"
                    + " case_id=" + caseId + ", snapshot_id=" + snapshotId + " where id='" + caseVo.getId() + "'";
            jdbcTemplateTwo.update(query);

            query = "delete from tbl_alert_interval where alert_id = '" + caseVo.getId() + "'";
            jdbcTemplateTwo.update(query);

            ArrayList<ArrayList<String>> alertDay = caseVo.getAlertDay();
            for (ArrayList<String> dayList : alertDay) {
                String query2 = " insert ignore into tbl_alert_interval(alert_id,day,hour,minutes) values(?,?,?,?)";
                jdbcTemplateTwo.update(query2, new Object[]
                        {caseVo.getId(), dayList.get(0), dayList.get(1), dayList.get(2)});
            }
        }
    }

    @Override
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> addUserAlerts(CaseVo data) {

        String query = "SELECT * FROM tbl_alert WHERE keyword='" + data.getKey2() + "'";
        List<Map<String, Object>> maps = jdbcTemplateTwo.queryForList(query);
        if (maps.size() > 0) {
            ResponseDto responseDto = new ResponseDto();
            responseDto.setMsg("Duplicate Entry for the alerts!!");
            return new ResponseEntity<>(responseDto, HttpStatus.CONFLICT);
        } else {
            addUserAlertsImplementation(data);
            ResponseDto responseDto = new ResponseDto();
            responseDto.setMsg("Alert Added SuccessFully!!");
            return new ResponseEntity<>(responseDto, HttpStatus.OK);
        }
    }

//    @Override
//    public ResponseEntity<?>  getAlertByUsers(HashMap<String, Object> data) {
//        HttpHeaders headers = new HttpHeaders();
//        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
//        headers.setContentType(MediaType.APPLICATION_JSON);
//        HttpEntity<Object> entity = new HttpEntity<Object>(data, headers);
//        System.out.println("data : " + data);
//        System.out.println("URL     "+appConfig.getProperty("innsightUrl"));
//
//        ResponseEntity<Object> ans = template.exchange(appConfig.getProperty("innsightUrl") + "getAlertByUsers", HttpMethod.POST, entity,
//                Object.class);
//
//        System.out.println(ans);
//        return ans;
//    }

    @Override
    public ResponseEntity<?> getAlertDetails(CaseVo data) {
        ArrayList<CaseVo> result = getAlertDetailsImplementation(data);
        return new ResponseEntity<>(result, HttpStatus.OK);

    }


    @Override
    public ResponseEntity<?> getAlertCounts(CaseVo data) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<Object>(data, headers);
        ArrayList<CaseVo> result = getAlertCountsImplementation(data);

        return new ResponseEntity<>(result, HttpStatus.OK);

    }

    @Override
    public ResponseEntity<?> getAlertByUsersId(HashMap<String, Integer> data) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<Object>(data, headers);
        return new ResponseEntity<>(getAlertByUsersIdImpl(data), HttpStatus.OK);
//        return template.exchange(appConfig.getProperty("innsightUrl") + "getAlertByUsersId", HttpMethod.POST, entity,
//                Object.class);
    }

    @Override
    public ArrayList<CaseVo> getAlertByUsersIdImpl(HashMap<String, Integer> data) {
        ArrayList<CaseVo> lst = new ArrayList<CaseVo>();
        try {
            String query = "SELECT id, alert_name, keyword, mail_to, mail_cc, mail_bcc, mobile_no, alert_via_m, alert_via_e, notification, activation_flag,"
                    + " login_id, frequency, count_limit, sentiment, user, alert_type, case_id, snapshot_id from tbl_alert where  id = '" + data.get("id") + "'";


            List<Map<String, Object>> rows = jdbcTemplateTwo.queryForList(query);
            for (Map<String, Object> rs : rows) {
                CaseVo caseVoObj = new CaseVo();
                caseVoObj.setId(rs.get("id") == null ? "" : rs.get("id").toString());
                caseVoObj.setKey1(rs.get("alert_name") == null ? "" : rs.get("alert_name").toString());
                caseVoObj.setKey2(rs.get("keyword") == null ? "" : rs.get("keyword").toString());
                caseVoObj.setKey3(rs.get("mail_to") == null ? "" : rs.get("mail_to").toString());
                caseVoObj.setKey4(rs.get("mail_cc") == null ? "" : rs.get("mail_cc").toString());
                caseVoObj.setKey5(rs.get("mail_bcc") == null ? "" : rs.get("mail_bcc").toString());
                caseVoObj.setKey6(rs.get("alert_via_m") == null ? "" : rs.get("alert_via_m").toString());
                caseVoObj.setKey7(rs.get("alert_via_e") == null ? "" : rs.get("alert_via_e").toString());
                caseVoObj.setKey8(rs.get("activation_flag") == null ? "" : rs.get("activation_flag").toString());
                //caseVoObj.setKey9(rs.get("alert_send_time")==null?"":rs.get("alert_send_time").toString());
                caseVoObj.setKey10(rs.get("mobile_no") == null ? "" : rs.get("mobile_no").toString());
                caseVoObj.setKey11(rs.get("notification") == null ? "" : rs.get("notification").toString());
                caseVoObj.setFrequency(rs.get("frequency") == null ? "" : rs.get("frequency").toString());
                caseVoObj.setCountLimit(rs.get("count_limit") == null ? "" : rs.get("count_limit").toString());
                caseVoObj.setSentiment(rs.get("sentiment") == null ? "" : rs.get("sentiment").toString());
                caseVoObj.setUser(rs.get("user") == null ? "" : rs.get("user").toString());
                caseVoObj.setAccountType(rs.get("alert_type") == null ? "" : rs.get("alert_type").toString());
                caseVoObj.setUserId(rs.get("case_id") == null ? "" : rs.get("case_id").toString());
                caseVoObj.setCaseId(rs.get("snapshot_id") == null ? "" : rs.get("snapshot_id").toString());
                lst.add(caseVoObj);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return lst;
    }

    @Override
    public ResponseEntity<?> getAlertWorkDaysById(HashMap<String, Integer> data) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<Object>(data, headers);
        return new ResponseEntity<>(getAlertWorkDaysByIdImpl(data), HttpStatus.OK);
    }

    @Override
    public ArrayList<CaseVo> getAlertCountsImplementation(CaseVo caseVo) {
        int alertCount = 0;

        ArrayList<CaseVo> lst = new ArrayList<CaseVo>();
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication.getName() == null) {
            throw new ResourceNotFoundException("Please Login first For getting urls count");
        }
        User loggedInUser = userService.getUserByUserName(authentication.getName());

        Long user = loggedInUser.getId();
        try {
            String query = "SELECT COUNT(tbl_alert_result.id) AS COUNT " +
                    "FROM tbl_alert_result INNER JOIN tbl_alert_interval ON tbl_alert_result.alert_id=tbl_alert_interval.id " +
                    "INNER JOIN tbl_alert ON tbl_alert.id=tbl_alert_interval.alert_id " +
                    "WHERE tbl_alert_result.read_status='unread'  " +
                    "AND tbl_alert.login_id='" + user + "'";
            //System.out.println("Alert counts :  "+query);
            List<Map<String, Object>> rows = jdbcTemplateTwo.queryForList(query);

            for (Map<String, Object> rs : rows) {
                alertCount = Integer.parseInt(rs.get("COUNT") == null ? "0" : rs.get("COUNT").toString());
            }


            CaseVo caseVoObj = new CaseVo();
            caseVoObj.setKey1(Integer.toString(alertCount));
            lst.add(caseVoObj);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lst;
    }

    public ArrayList<CaseVo> getAlertDetailsImplementation(CaseVo caseVo) {
        ArrayList<CaseVo> lst = new ArrayList<CaseVo>();

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication.getName() == null) {
            throw new ResourceNotFoundException("Please Login first For getting urls count");
        }
        User loggedInUser = userService.getUserByUserName(authentication.getName());

        String user = loggedInUser.getId().toString();
        String userRole = "";
        try {
            String subQuery = "";
            if (!userRole.equals("a")) {
                subQuery += " and tbl_alert.login_id='" + user + "'";
            }

            String query = "SELECT tbl_alert.alert_name, tbl_alert.keyword,tbl_alert.sentiment, tbl_alert_result.no_of_posts, "
                    + " tbl_alert_result.alert_from_date, tbl_alert_result.alert_to_date, tbl_alert_result.id, tbl_alert_result.read_status, "
                    + " tbl_alert.case_id, tbl_alert.snapshot_id, tbl_alert.alert_type, tbl_alert.threat_classification "
                    + " FROM tbl_alert_result "
                    + " INNER JOIN tbl_alert_interval"
                    + " ON tbl_alert_result.alert_id=tbl_alert_interval.id "
                    + " INNER JOIN tbl_alert "
                    + " ON tbl_alert.id=tbl_alert_interval.alert_id "
                    + " WHERE tbl_alert_result.read_status='unread'" + subQuery;

            List<Map<String, Object>> rows = jdbcTemplateTwo.queryForList(query);

            for (Map<String, Object> rs : rows) {
                CaseVo caseVoObj = new CaseVo();
                caseVoObj.setId(rs.get("id") == null ? "" : rs.get("id").toString());
                caseVoObj.setKey1(rs.get("alert_name") == null ? "" : rs.get("alert_name").toString());
                caseVoObj.setKey2(rs.get("no_of_posts") == null ? "" : rs.get("no_of_posts").toString());
                caseVoObj.setKey3(CommonUtils.convertUnixTimeToDateDisplayFormat(Long.parseLong(rs.get("alert_from_date").toString())));
                caseVoObj.setKey4(rs.get("read_status") == null ? "" : rs.get("read_status").toString());
                caseVoObj.setKey5(CommonUtils.convertUnixTimeToDateDisplayFormat(Long.parseLong(rs.get("alert_to_date").toString())));
                caseVoObj.setKey6(rs.get("keyword") == null ? "" : rs.get("keyword").toString());
                caseVoObj.setKey7(rs.get("sentiment") == null ? "" : rs.get("sentiment").toString());
                caseVoObj.setKey9(rs.get("threat_classification") == null ? "" : rs.get("threat_classification").toString());
                caseVoObj.setKey8("alert");
                caseVoObj.setCaseId(rs.get("case_id") == null ? "" : rs.get("case_id").toString());
                caseVoObj.setSnapShortId(rs.get("snapshot_id") == null ? "" : rs.get("snapshot_id").toString());
                caseVoObj.setAlertType(rs.get("alert_type") == null ? "" : rs.get("alert_type").toString());
                caseVoObj.setDateFrom(rs.get("alert_from_date") == null ? "" : rs.get("alert_from_date").toString());
                caseVoObj.setDateTo(rs.get("alert_to_date") == null ? "" : rs.get("alert_to_date").toString());

                if (!caseVoObj.getKey2().equals("0")) {
                    lst.add(caseVoObj);
                }
            }


        } catch (Exception e) {
            e.printStackTrace();
        }
        return lst;
    }

    @Override
    public ArrayList<CaseVo> getAlertWorkDaysByIdImpl(HashMap<String, Integer> data) {
        ArrayList<CaseVo> lst = new ArrayList<CaseVo>();
        try {
            String query = "	SELECT day,hour,minutes from tbl_alert_interval where  alert_id = '" + data.get("id") + "'";
            List<Map<String, Object>> rows = jdbcTemplateTwo.queryForList(query);

            for (Map<String, Object> rs : rows) {
                CaseVo caseVoObj = new CaseVo();
                caseVoObj.setId(rs.get("id") == null ? "" : rs.get("id").toString());
                caseVoObj.setKey1(rs.get("day") == null ? "" : rs.get("day").toString());
                caseVoObj.setKey2(rs.get("hour") == null ? "" : rs.get("hour").toString());
                caseVoObj.setKey3(rs.get("minutes") == null ? "" : rs.get("minutes").toString());
                lst.add(caseVoObj);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lst;
    }

    @Override
    public ResponseEntity<?> dltUserAlerts(HashMap<String, Integer> data) {
        return new ResponseEntity<>(dltUserAlertsImpl(data), HttpStatus.OK);
    }


//    @Override
//    public ArrayList<CaseVo> getAlertByUsers(CaseVo caseVo)
//    {
////        String userName =(String)httpSession.getAttribute(ApplicationConstants.LOGINUSERID);
////        String userRole =(String)httpSession.getAttribute(ApplicationConstants.USERROLE);
//
//        String userName = "";
//        String userRole = "";
//        ArrayList<CaseVo> lst=new ArrayList<CaseVo>();
//        try
//        {
//            String subQuery="";
//            String sortQuery="";
//            if(!userRole.toLowerCase().equals("a"))
//            {
//                subQuery+=" and tbl_alert.login_id='"+userName+"'";
//            }
//
//            switch(caseVo.getActType())
//            {
//                case "1":
//                    subQuery+=" and tbl_alert.activation_flag='1'";
//                    break;
//                case "0":
//                    subQuery+=" and tbl_alert.activation_flag='0'";
//                    break;
//            }
//
//            switch(caseVo.getEntitySortStatus())
//            {
//                case "dd":
//                    sortQuery=" order by id DESC ";
//                    break;
//                case "da":
//                    sortQuery=" order by tbl_alert.alert_created_at ASC ";
//                    break;
//                case "na":
//                    sortQuery=" order by tbl_alert.alert_name ASC ";
//                    break;
//                case "nd":
//                    sortQuery=" order by tbl_alert.alert_name DESC ";
//                    break;
//                case "ada": //alert sent date asc
//                    sortQuery=" order by alert_date ASC ";
//                    break;
//                case "add": //alert sent date desc
//                    sortQuery=" order by alert_date DESC ";
//                    break;
//            }
//            String query=" SELECT tbl_alert.id,tbl_alert.alert_name,tbl_alert.keyword,tbl_alert.activation_flag,login_detail.user_logon_id,"
//                    + " COALESCE(DATE_FORMAT((tbl_alert.alert_created_at),'%b %d,%Y %r'),'') AS alert_created_at, "
//                    + "  COALESCE(DATE_FORMAT((SELECT MAX(alert_date_time) FROM tbl_alert_result WHERE main_alert_id=tbl_alert.id),'%b %d,%Y %r'),'') AS alert_date  "
//                    + " FROM tbl_alert"
//                    + " INNER JOIN login_detail ON login_detail.id=tbl_alert.login_id "
//                    + " where  (tbl_alert.alert_name like '%"+caseVo.getCaseName()+"%' or tbl_alert.keyword like '%"+caseVo.getCaseName()+"%')"
//                    +subQuery + sortQuery ;
//            System.out.println("Get User Alerts Query :: "+query);
//            List<Map<String,Object>> rows = jdbcTemplateTwo.queryForList(query);
//            for(Map<String,Object> rs : rows){
//                CaseVo caseVoObj=new CaseVo();
//                caseVoObj.setId(rs.get("id")==null?"":rs.get("id").toString());
//                caseVoObj.setKey1(rs.get("alert_name")==null?"":rs.get("alert_name").toString());
//                caseVoObj.setKey2(rs.get("keyword")==null?"":rs.get("keyword").toString());
//                caseVoObj.setKey3(rs.get("alert_created_at")==null?"":rs.get("alert_created_at").toString());
//                caseVoObj.setKey4(rs.get("user_logon_id")==null?"":rs.get("user_logon_id").toString());
//                caseVoObj.setKey5(rs.get("alert_date")==null?"":rs.get("alert_date").toString());
//                caseVoObj.setKey6(rs.get("activation_flag")==null?"":rs.get("activation_flag").toString());
//                lst.add(caseVoObj);
//            }
//        }catch (Exception e) {
//            e.printStackTrace();
//        }
//        return lst;
//    }


    @Override
    public String dltUserAlertsImpl(HashMap<String, Integer> data) {
        ArrayList<CaseVo> lst = new ArrayList<CaseVo>();
        TransactionDefinition def = new DefaultTransactionDefinition();
        TransactionStatus status = transactionManager.getTransaction(def);
        String query = "";
        try {
            query = " DELETE tbl_alert_result.* FROM tbl_alert_result "
                    + " INNER JOIN tbl_alert_interval ON tbl_alert_result.alert_id = tbl_alert_interval.id "
                    + " INNER JOIN tbl_alert ON tbl_alert.id = tbl_alert_interval.alert_id  "
                    + " where tbl_alert.id= '" + data.get("id") + "' ";
            jdbcTemplateTwo.update(query);

            query = " delete from tbl_alert where id= '" + data.get("id") + "' ";
            jdbcTemplateTwo.update(query);

            query = " delete from tbl_alert_interval where alert_id= '" + data.get("id") + "' ";
            jdbcTemplateTwo.update(query);

            transactionManager.commit(status);
        } catch (Exception e) {
            transactionManager.rollback(status);
            e.printStackTrace();
        }
        return "Alert Deleted Succesfully!!";
    }

    @Override
    public ResponseEntity<?> getAlertByStatusType(HashMap<String, String> data) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<Object>(data, headers);
        return new ResponseEntity<>(getAlertByStatusTypeImpl(data), HttpStatus.OK);
    }

    @Override
    public ArrayList<CaseVo> getAlertByStatusTypeImpl(HashMap<String, String> data) {
        ArrayList<CaseVo> lst = new ArrayList<CaseVo>();
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication.getName() == null) {
            throw new ResourceNotFoundException("Please Login first For getting urls count");
        }
        User loggedInUser = userService.getUserByUserName(authentication.getName());

        String user = loggedInUser.getId().toString();


        try {
            String query = "SELECT tbl_alert.alert_name,tbl_alert.keyword,tbl_alert.sentiment,tbl_alert_result.no_of_posts,tbl_alert_result.alert_from_date,tbl_alert_result.alert_to_date,tbl_alert_result.id,tbl_alert_result.read_status " +
                    "FROM tbl_alert_result INNER JOIN tbl_alert_interval ON tbl_alert_result.alert_id=tbl_alert_interval.id " +
                    "INNER JOIN tbl_alert ON tbl_alert.id=tbl_alert_interval.alert_id WHERE tbl_alert.login_id='" + user + "'";
            if (data.get("caseName").equals("read")) {
                query += " and tbl_alert_result.read_status='read' ";
            } else if (data.get("caseName").equals("unread")) {
                query += " and tbl_alert_result.read_status='unread' ";
            }
//            System.out.println("Alert Details : " + query);
            List<Map<String, Object>> rows = jdbcTemplateTwo.queryForList(query);
            for (Map<String, Object> rs : rows) {
                CaseVo caseVoObj = new CaseVo();
                caseVoObj.setId(rs.get("id") == null ? "" : rs.get("id").toString());
                caseVoObj.setKey1(rs.get("alert_name") == null ? "" : rs.get("alert_name").toString());
                caseVoObj.setKey2(rs.get("no_of_posts") == null ? "" : rs.get("no_of_posts").toString());
                caseVoObj.setKey3(CommonUtils.convertUnixTimeToDateDisplayFormat(Long.parseLong(rs.get("alert_from_date").toString())));
                caseVoObj.setKey4(rs.get("read_status") == null ? "" : rs.get("read_status").toString());
                caseVoObj.setKey5(CommonUtils.convertUnixTimeToDateDisplayFormat(Long.parseLong(rs.get("alert_to_date").toString())));
                caseVoObj.setKey6(rs.get("keyword") == null ? "" : rs.get("keyword").toString());
                caseVoObj.setKey7(rs.get("sentiment") == null ? "" : rs.get("sentiment").toString());
                caseVoObj.setKey8("alert");
                lst.add(caseVoObj);

            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return lst;
    }

    @Override
    public String updateAllAlertReadStatusImpl() {
        try {
            String query = "update tbl_alert_result set read_status='read'";
            jdbcTemplateTwo.update(query);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return "All Alert Status changed to Read!!";
    }

    @Override
    public ResponseEntity<?> updateAllAlertReadStatus() {
        return new ResponseEntity<>(updateAllAlertReadStatusImpl(), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<?> getAlertByUsers(CaseVo data) {
        return new ResponseEntity<>(getAlertByUsersImpl(data), HttpStatus.OK);
    }


    @Override
    public ArrayList<CaseVo> getAlertByUsersImpl(CaseVo caseVo) {
        //        String userName =(String)httpSession.getAttribute(ApplicationConstants.LOGINUSERID);
//        String userRole =(String)httpSession.getAttribute(ApplicationConstants.USERROLE);
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication.getName() == null) {
            throw new ResourceNotFoundException("Please Login first For getting urls count");
        }
        User loggedInUser = userService.getUserByUserName(authentication.getName());


        String userName = loggedInUser.getId().toString();
        String userRole = "";
        ArrayList<CaseVo> lst = new ArrayList<CaseVo>();
        try {
            String subQuery = "";
            String sortQuery = "";
            if (!userRole.toLowerCase().equals("a")) {
                subQuery += " and tbl_alert.login_id='" + userName + "'";
            }

            switch (caseVo.getActType()) {
                case "1":
                    subQuery += " and tbl_alert.activation_flag='1'";
                    break;
                case "0":
                    subQuery += " and tbl_alert.activation_flag='0'";
                    break;
            }

            switch (caseVo.getEntitySortStatus()) {
                case "dd":
                    sortQuery = " order by id DESC ";
                    break;
                case "da":
                    sortQuery = " order by tbl_alert.alert_created_at ASC ";
                    break;
                case "na":
                    sortQuery = " order by tbl_alert.alert_name ASC ";
                    break;
                case "nd":
                    sortQuery = " order by tbl_alert.alert_name DESC ";
                    break;
                case "ada": //alert sent date asc
                    sortQuery = " order by alert_date ASC ";
                    break;
                case "add": //alert sent date desc
                    sortQuery = " order by alert_date DESC ";
                    break;
            }
            String query = " SELECT tbl_alert.id,tbl_alert.alert_name,tbl_alert.keyword,tbl_alert.sentiment,tbl_alert.activation_flag, tbl_alert.threat_classification, login_detail.user_logon_id,"
                    + " COALESCE(DATE_FORMAT((tbl_alert.alert_created_at),'%b %d,%Y %r'),'') AS alert_created_at, "
                    + "  COALESCE(DATE_FORMAT((SELECT MAX(alert_date_time) FROM tbl_alert_result WHERE main_alert_id=tbl_alert.id),'%b %d,%Y %r'),'') AS alert_date  "
                    + " FROM tbl_alert"
                    + " INNER JOIN login_detail ON login_detail.id=tbl_alert.login_id "
                    + " where  (tbl_alert.alert_name like '%" + caseVo.getCaseName() + "%' or tbl_alert.keyword like '%" + caseVo.getCaseName() + "%')"
                    + subQuery + sortQuery;
            List<Map<String, Object>> rows = jdbcTemplateTwo.queryForList(query);
            for (Map<String, Object> rs : rows) {
                CaseVo caseVoObj = new CaseVo();
                caseVoObj.setThreatScore(rs.get("threat_classification") == null ? "" : rs.get("threat_classification").toString());
                caseVoObj.setId(rs.get("id") == null ? "" : rs.get("id").toString());
                caseVoObj.setKey1(rs.get("alert_name") == null ? "" : rs.get("alert_name").toString());
                caseVoObj.setKey2(rs.get("keyword") == null ? "" : rs.get("keyword").toString());
                caseVoObj.setKey3(rs.get("alert_created_at") == null ? "" : rs.get("alert_created_at").toString());
                caseVoObj.setKey4(rs.get("user_logon_id") == null ? "" : rs.get("user_logon_id").toString());
                caseVoObj.setKey5(rs.get("alert_date") == null ? "" : rs.get("alert_date").toString());
                caseVoObj.setKey6(rs.get("activation_flag") == null ? "" : rs.get("activation_flag").toString());
                caseVoObj.setSentiment(rs.get("sentiment") == null ? "" : rs.get("sentiment").toString());
                caseVoObj.setIsActive(rs.get("activation_flag") == null ? "" : rs.get("activation_flag").toString());

                lst.add(caseVoObj);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lst;
    }


    @Override
    public ResponseEntity<?> updateAlertStatusReadByID(HashMap<String, Integer> data) {
        return new ResponseEntity<>(updateAlertStatusReadByIDImpl(data), HttpStatus.OK);
    }

    @Override
    public String updateAlertStatusReadByIDImpl(HashMap<String, Integer> data) {
        try {
            String query = "update tbl_alert_result set read_status='read' where id = '" + data.get("id") + "'";
            jdbcTemplateTwo.update(query);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return "Alert Status for AlertId " + data.get("id") + " changed to Read!!!";
    }


    public ResponseEntity<?> actDactAlertValue(CaseVo caseVo) {
        return new ResponseEntity<>(actDactAlertValueImpl(caseVo), HttpStatus.OK);
    }

    @Override
    public String actDactAlertValueImpl(CaseVo caseVo) {

        String sql1 = "select activation_flag from tbl_alert where id='" + caseVo.getId() + "'";
        List<Map<String, Object>> maps = jdbcTemplateTwo.queryForList(sql1);
        int activation_flag = (Integer) maps.get(0).get("activation_flag");
        if (activation_flag == 0)
            activation_flag = 1;
        else
            activation_flag = 0;
        try {
            String query = "update tbl_alert set activation_flag='" + activation_flag + "' where id='" + caseVo.getId() + "'";
//            System.out.println("actDactAlertValue: " + query);
            jdbcTemplateTwo.update(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "Active Status toggled!!";
    }


}