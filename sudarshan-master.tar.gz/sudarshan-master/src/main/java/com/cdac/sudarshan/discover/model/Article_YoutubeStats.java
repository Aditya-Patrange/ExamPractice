package com.cdac.sudarshan.discover.model;

import java.io.Serializable;

public class Article_YoutubeStats implements Serializable 
{
	private static final long serialVersionUID = 1L;
	private Integer ytViewCount;
	private Integer ytLikeCount;
	private Integer ytDisLikeCount;
	private Integer ytFavoriteCount;
	private Integer ytCommentCount;
	private Integer ytViewCountDelta;
	private Integer ytLikeCountDelta;
	private Integer ytDisLikeCountDelta;
	private Integer ytCommentCountDelta;
	private Integer ytFavoriteCountDelta;
	private long statsDate;
	
	public Integer getYtViewCount() {
		return ytViewCount;
	}
	public void setYtViewCount(Integer ytViewCount) {
		this.ytViewCount = ytViewCount;
	}
	public Integer getYtLikeCount() {
		return ytLikeCount;
	}
	public void setYtLikeCount(Integer ytLikeCount) {
		this.ytLikeCount = ytLikeCount;
	}
	public Integer getYtDisLikeCount() {
		return ytDisLikeCount;
	}
	public void setYtDisLikeCount(Integer ytDisLikeCount) {
		this.ytDisLikeCount = ytDisLikeCount;
	}
	public Integer getYtFavoriteCount() {
		return ytFavoriteCount;
	}
	public void setYtFavoriteCount(Integer ytFavoriteCount) {
		this.ytFavoriteCount = ytFavoriteCount;
	}
	public Integer getYtCommentCount() {
		return ytCommentCount;
	}
	public void setYtCommentCount(Integer ytCommentCount) {
		this.ytCommentCount = ytCommentCount;
	}
	public Integer getYtViewCountDelta() {
		return ytViewCountDelta;
	}
	public void setYtViewCountDelta(Integer ytViewCountDelta) {
		this.ytViewCountDelta = ytViewCountDelta;
	}
	public Integer getYtLikeCountDelta() {
		return ytLikeCountDelta;
	}
	public void setYtLikeCountDelta(Integer ytLikeCountDelta) {
		this.ytLikeCountDelta = ytLikeCountDelta;
	}
	public Integer getYtDisLikeCountDelta() {
		return ytDisLikeCountDelta;
	}
	public void setYtDisLikeCountDelta(Integer ytDisLikeCountDelta) {
		this.ytDisLikeCountDelta = ytDisLikeCountDelta;
	}
	public Integer getYtCommentCountDelta() {
		return ytCommentCountDelta;
	}
	public void setYtCommentCountDelta(Integer ytCommentCountDelta) {
		this.ytCommentCountDelta = ytCommentCountDelta;
	}
	public long getStatsDate() {
		return statsDate;
	}
	public void setStatsDate(long statsDate) {
		this.statsDate = statsDate;
	}

	public Integer getYtFavoriteCountDelta() {
		return ytFavoriteCountDelta;
	}
	public void setYtFavoriteCountDelta(Integer ytFavoriteCountDelta) {
		this.ytFavoriteCountDelta = ytFavoriteCountDelta;
	}
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "Article_YoutubeStats [ytViewCount=" + ytViewCount + ", ytLikeCount=" + ytLikeCount + ", ytDisLikeCount="
				+ ytDisLikeCount + ", ytFavoriteCount=" + ytFavoriteCount + ", ytCommentCount=" + ytCommentCount
				+ ", ytViewCountDelta=" + ytViewCountDelta + ", ytLikeCountDelta=" + ytLikeCountDelta
				+ ", ytDisLikeCountDelta=" + ytDisLikeCountDelta + ", ytCommentCountDelta=" + ytCommentCountDelta
				+ ", ytFavoriteCountDelta=" + ytFavoriteCountDelta + ", statsDate=" + statsDate + "]";
	}

}
