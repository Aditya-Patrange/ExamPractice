package com.cdac.sudarshan.code.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cdac.sudarshan.authentication.model.User;
import com.cdac.sudarshan.code.model.Code;

@Repository
public interface CodeRepository extends JpaRepository<Code,Long> {

    List<Code> findByUser(User user);
    
    

}
