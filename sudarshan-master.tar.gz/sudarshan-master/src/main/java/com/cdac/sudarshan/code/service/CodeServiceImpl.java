package com.cdac.sudarshan.code.service;

import java.util.List;

import javax.transaction.Transactional;

import com.cdac.sudarshan.exception.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.sudarshan.authentication.model.User;
import com.cdac.sudarshan.authentication.repository.UserRepository;
import com.cdac.sudarshan.code.model.Code;
import com.cdac.sudarshan.code.repository.CodeRepository;

@Service
@Transactional
public class CodeServiceImpl implements ICodeService {

	@Autowired
	private CodeRepository codeRepository;

	@Autowired
	private UserRepository userRepository;

	@Override
	public void saveCode(List<Code> code) {
		codeRepository.saveAll(code);
	}

	@Override
	public List<Code> getSecurityCode(User user) {
		return codeRepository.findByUser(user);

	}

	@Override
	public List<Code> getScurityCodeOfUser(String username){
		User user = userRepository.findByUsername(username).get();
		if(user == null) {
			throw new ResourceNotFoundException(username + " having name not found");
		}
		return codeRepository.findByUser(user);
	}

}
