package com.cdac.sudarshan.discover.projection;

public interface PhoneCodeProjection {
    String getPhoneCode();
}
