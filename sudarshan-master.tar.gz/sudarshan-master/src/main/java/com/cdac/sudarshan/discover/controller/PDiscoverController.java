package com.cdac.sudarshan.discover.controller;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.cdac.sudarshan.discover.service.IDashboardService;

@RestController
@CrossOrigin("*")
@RequestMapping("/eva/dashboard")
public class PDiscoverController {

	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private IDashboardService iDashboardService;
	
	
	@PostMapping("/classification")
	public ResponseEntity<?> getClassification(@RequestBody HashMap<String, Object> data) 
	{
		return new ResponseEntity<>(iDashboardService.getClassification(data), HttpStatus.OK);		

	}
	
	@PostMapping("/sentiment")
	public ResponseEntity<?> getSentiment(@RequestBody HashMap<String, Object> data) 
	{
		return new ResponseEntity<>(iDashboardService.getSentiment(data), HttpStatus.OK);		

	}
	
	@PostMapping("/wordcolud")
	public ResponseEntity<?> getWordCloud(@RequestBody HashMap<String, Object> data) 
	{
		return new ResponseEntity<>(iDashboardService.getWordCloud(data), HttpStatus.OK);		

	}
	
	

}
