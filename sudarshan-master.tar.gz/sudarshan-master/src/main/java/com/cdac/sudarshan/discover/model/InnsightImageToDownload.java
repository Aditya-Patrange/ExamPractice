package com.cdac.sudarshan.discover.model;

import java.util.ArrayList;

public class InnsightImageToDownload 
{
	private int downloadStatus=0; 
	private int frsMakeStatus=0;
	private int innsightUpdateStatus=0; 
	private int odsStaus=0;
	private int faceCount=0; 
	private int faceCountStatus=0; 
	private int ocrStatus=0;
	private String imageBase;
	private String imageHash; 
	private String imageId;
	private String imageUrl; 
	private String downloadFolder; 
	private String postId;
	private String targetImageName; 
	private String authorId;
	private String authorName; 
	private String imageText;
	private ArrayList<String> ods; 
	private ArrayList<String> frs;
	private String imageType;   //user, post
	private String sourceType="tw"; //tw,fb
	private String client;
	private long insertedDate=System.currentTimeMillis();
	private long downloadedDate;
	private long odsDate;
	private long frsDate;
	
	//setters and getters
	public String getClient() {
		return client;
	}
	public void setClient(String client) {
		this.client = client;
	}
	public int getDownloadStatus() {
		return downloadStatus;
	}
	public void setDownloadStatus(int downloadStatus) {
		this.downloadStatus = downloadStatus;
	}
	public int getFrsMakeStatus() {
		return frsMakeStatus;
	}
	public void setFrsMakeStatus(int frsMakeStatus) {
		this.frsMakeStatus = frsMakeStatus;
	}
	public int getInnsightUpdateStatus() {
		return innsightUpdateStatus;
	}
	public void setInnsightUpdateStatus(int innsightUpdateStatus) {
		this.innsightUpdateStatus = innsightUpdateStatus;
	}
	public int getOdsStaus() {
		return odsStaus;
	}
	public void setOdsStaus(int odsStaus) {
		this.odsStaus = odsStaus;
	}
	public int getFaceCount() {
		return faceCount;
	}
	public void setFaceCount(int faceCount) {
		this.faceCount = faceCount;
	}
	public int getFaceCountStatus() {
		return faceCountStatus;
	}
	public void setFaceCountStatus(int faceCountStatus) {
		this.faceCountStatus = faceCountStatus;
	}
	public String getImageBase() {
		return imageBase;
	}
	public void setImageBase(String imageBase) {
		this.imageBase = imageBase;
	}
	public String getImageHash() {
		return imageHash;
	}
	public void setImageHash(String imageHash) {
		this.imageHash = imageHash;
	}
	public String getImageId() {
		return imageId;
	}
	public void setImageId(String imageId) {
		this.imageId = imageId;
	}
	public String getImageUrl() {
		return imageUrl;
	}
	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}
	public String getDownloadFolder() {
		return downloadFolder;
	}
	public void setDownloadFolder(String downloadFolder) {
		this.downloadFolder = downloadFolder;
	}
	
	public String getPostId() {
		return postId;
	}
	public void setPostId(String postId) {
		this.postId = postId;
	}
	public String getTargetImageName() {
		return targetImageName;
	}
	public void setTargetImageName(String targetImageName) {
		this.targetImageName = targetImageName;
	}
	public String getAuthorId() {
		return authorId;
	}
	public void setAuthorId(String authorId) {
		this.authorId = authorId;
	}
	public String getAuthorName() {
		return authorName;
	}
	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}
	public String getImageText() {
		return imageText;
	}
	public void setImageText(String imageText) {
		this.imageText = imageText;
	}
	public ArrayList<String> getOds() {
		return ods;
	}
	public void setOds(ArrayList<String> ods) {
		this.ods = ods;
	}
	public ArrayList<String> getFrs() {
		return frs;
	}
	public void setFrs(ArrayList<String> frs) {
		this.frs = frs;
	}
	public String getImageType() {
		return imageType;
	}
	public void setImageType(String imageType) {
		this.imageType = imageType;
	}
	public String getSourceType() {
		return sourceType;
	}
	public void setSourceType(String sourceType) {
		this.sourceType = sourceType;
	}
	public long getInsertedDate() {
		return insertedDate;
	}
	public void setInsertedDate(long insertedDate) {
		this.insertedDate = insertedDate;
	}
	public long getDownloadedDate() {
		return downloadedDate;
	}
	public void setDownloadedDate(long downloadedDate) {
		this.downloadedDate = downloadedDate;
	}
	public long getOdsDate() {
		return odsDate;
	}
	public void setOdsDate(long odsDate) {
		this.odsDate = odsDate;
	}
	public long getFrsDate() {
		return frsDate;
	}
	public void setFrsDate(long frsDate) {
		this.frsDate = frsDate;
	}
	public int getOcrStatus() {
		return ocrStatus;
	}
	public void setOcrStatus(int ocrStatus) {
		this.ocrStatus = ocrStatus;
	}
	@Override
	public String toString() {
		return "InnsightImageToDownload [downloadStatus=" + downloadStatus + ", frsMakeStatus=" + frsMakeStatus
				+ ", innsightUpdateStatus=" + innsightUpdateStatus + ", odsStaus=" + odsStaus + ", faceCount="
				+ faceCount + ", faceCountStatus=" + faceCountStatus + ", ocrStatus=" + ocrStatus + ", imageBase="
				+ imageBase + ", imageHash=" + imageHash + ", imageId=" + imageId + ", imageUrl=" + imageUrl
				+ ", downloadFolder=" + downloadFolder + ", postId=" + postId + ", targetImageName=" + targetImageName
				+ ", authorId=" + authorId + ", authorName=" + authorName + ", imageText=" + imageText + ", ods=" + ods
				+ ", frs=" + frs + ", imageType=" + imageType + ", sourceType=" + sourceType + ", insertedDate="
				+ insertedDate + ", downloadedDate=" + downloadedDate + ", odsDate=" + odsDate + ", frsDate=" + frsDate
				+ ", client=" + client + "]";
	}
		
}