package com.cdac.sudarshan.folderManagement.service;

import com.cdac.sudarshan.authentication.model.User;
import com.cdac.sudarshan.authentication.service.IAuthService;
import com.cdac.sudarshan.exception.ResourceNotFoundException;
import com.cdac.sudarshan.folderManagement.dto.ApiResponse;
import com.cdac.sudarshan.folderManagement.dto.FolderDataRequestDto;
import com.cdac.sudarshan.folderManagement.dto.RequestMediaDto;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class FolderDataServiceImpl {

    @Value("${folder.management.host}")
    private String folderManagementHost;

    @Autowired
    private IAuthService authService;

    @Autowired
    private RestTemplate template;

    public ApiResponse saveArticleData(List<FolderDataRequestDto> data){
        ObjectMapper mapper = new ObjectMapper();
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        User loggedInUser = (User) authService.getLoggedInUserDetails().getBody();
        if(loggedInUser == null){
            throw new ResourceNotFoundException("Please Login first For adding data");
        }
        //setting logged in user to data
        List<FolderDataRequestDto> folderDataRequestDtos = data.stream().map(folderDataRequestDto -> {
            folderDataRequestDto.setUserId(loggedInUser.getId());
            return folderDataRequestDto;
        }).toList();
        HttpEntity<Object> entity = new HttpEntity<>(folderDataRequestDtos,headers);
            ResponseEntity<ApiResponse> responseEntity = template.postForEntity(folderManagementHost+"folderData/saveArticleData",entity,ApiResponse.class);
            return responseEntity.getBody();
        }

    public ApiResponse saveProfileData(List<FolderDataRequestDto> data){
        ObjectMapper mapper = new ObjectMapper();
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        User loggedInUser = (User) authService.getLoggedInUserDetails().getBody();

        //setting logged in user to data
        List<FolderDataRequestDto> folderDataRequestDtos = data.stream().map(folderDataRequestDto -> {
            folderDataRequestDto.setUserId(loggedInUser.getId());
            return folderDataRequestDto;
        }).toList();

        HttpEntity<Object> entity = new HttpEntity<>(folderDataRequestDtos,headers);
        ResponseEntity<ApiResponse> responseEntity = template.postForEntity(folderManagementHost+"folderData/saveProfileData",entity,ApiResponse.class);
        return responseEntity.getBody();
    }

    public Object getFolderData(FolderDataRequestDto data){
        ObjectMapper mapper = new ObjectMapper();
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        User loggedInUser = (User) authService.getLoggedInUserDetails().getBody();
        if(loggedInUser == null){
            throw new ResourceNotFoundException("Please Login first For adding data");
        }
        data.setUserId(((User) authService.getLoggedInUserDetails().getBody()).getId());

        HttpEntity<Object> entity = new HttpEntity<>(data,headers);
       // ResponseEntity<String> resultString = template.postForEntity(folderManagementHost + "folderData/getFolderData", entity, String.class);
        ResponseEntity<Object> resultString = template.postForEntity(folderManagementHost + "folderData/getFolderData", entity, Object.class);
        return resultString.getBody();
    }

    public ApiResponse<?> removeFolderData(Map<String,Object> folderData){
        ObjectMapper mapper = new ObjectMapper();
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        User loggedInUser = (User) authService.getLoggedInUserDetails().getBody();
        if(loggedInUser == null){
            throw new ResourceNotFoundException("Please Login first For adding data");
        }
        HttpEntity<Object> entity = new HttpEntity<>(folderData,headers);
        ResponseEntity<ApiResponse> responseEntity = template.postForEntity(folderManagementHost + "folderData/removeFolderData", entity, ApiResponse.class);
        return responseEntity.getBody();
    }

    public ApiResponse saveMediaData(List<RequestMediaDto> data){
        ObjectMapper mapper = new ObjectMapper();
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        User loggedInUser = (User) authService.getLoggedInUserDetails().getBody();
        if(loggedInUser == null){
            throw new ResourceNotFoundException("Please Login first For adding data");
        }
        //setting logged in user to data
        List<RequestMediaDto> folderDataRequestDtos = data.stream().map(folderDataRequestDto -> {
            folderDataRequestDto.setUserId(loggedInUser.getId());
            return folderDataRequestDto;
        }).toList();
        HttpEntity<Object> entity = new HttpEntity<>(folderDataRequestDtos,headers);
        ResponseEntity<ApiResponse> responseEntity = template.postForEntity(folderManagementHost+"folderData/saveMediaData",entity,ApiResponse.class);
        return responseEntity.getBody();
    }

    public ApiResponse getMedia(RequestMediaDto data){
        ObjectMapper mapper = new ObjectMapper();
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        User loggedInUser = (User) authService.getLoggedInUserDetails().getBody();
        if(loggedInUser == null){
            throw new ResourceNotFoundException("Please Login first For getting data");
        }
        //setting logged in user to data
        data.setUserId(loggedInUser.getId());
        HttpEntity<Object> entity = new HttpEntity<>(data,headers);
        ResponseEntity<ApiResponse> responseEntity = template.postForEntity(folderManagementHost + "folderData/getMediaData", entity, ApiResponse.class);
        return responseEntity.getBody();
    }

    public Object getFolderThemeData(FolderDataRequestDto data){
        ObjectMapper mapper = new ObjectMapper();
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        User loggedInUser = (User) authService.getLoggedInUserDetails().getBody();
        if(loggedInUser == null){
            throw new ResourceNotFoundException("Please Login first For adding data");
        }
        data.setUserId(((User) authService.getLoggedInUserDetails().getBody()).getId());

        HttpEntity<Object> entity = new HttpEntity<>(data,headers);
        ResponseEntity<Object> resultString = template.postForEntity(folderManagementHost + "folderData/getFolderDataOfTheme", entity, Object.class);
        return resultString.getBody();
    }

    public Object getFilterData(FolderDataRequestDto data){
        ObjectMapper mapper = new ObjectMapper();
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        User loggedInUser = (User) authService.getLoggedInUserDetails().getBody();
        if(loggedInUser == null){
            throw new ResourceNotFoundException("Please Login first For adding data");
        }
        data.setUserId(((User) authService.getLoggedInUserDetails().getBody()).getId());

        HttpEntity<Object> entity = new HttpEntity<>(data,headers);
        ResponseEntity<Object> resultString = template.postForEntity(folderManagementHost + "folderData/getFilterData", entity, Object.class);
        return resultString.getBody();
    }



    private HashMap<String,Object> setUserId(HashMap<String,Object> map){

        User loggedInUser = (User) authService.getLoggedInUserDetails().getBody();

        if (loggedInUser == null) {
            throw new ResourceNotFoundException("Please Login first For adding add url");
        }

        map.put("userId",loggedInUser.getId());

        return map;
    }

}
