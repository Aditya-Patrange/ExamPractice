package com.cdac.sudarshan.discover.common;

public class ArticlePriority {
	
private String title, content, articleId, country;
int priority;
long insertionDate;

public int getPriority() {
	return priority;
}

public void setPriority(int priority) {
	this.priority = priority;
}

public String getTitle() {
	return title;
}

public void setTitle(String title) {
	this.title = title;
}

public String getContent() {
	return content;
}

public void setContent(String content) {
	this.content = content;
}

public String getArticleId() {
	return articleId;
}

public void setArticleId(String articleId) {
	this.articleId = articleId;
}

public long getInsertionDate() {
	return insertionDate;
}

public void setInsertionDate(long insertionDate) {
	this.insertionDate = insertionDate;
}

public String getCountry() {
	return country;
}

public void setCountry(String country) {
	this.country = country;
}

}
