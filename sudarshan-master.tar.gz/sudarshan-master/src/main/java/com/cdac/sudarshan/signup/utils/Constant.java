package com.cdac.sudarshan.signup.utils;

public class Constant {

    public static final int CODE_LENGTH = 6;
    public static final int GROUPS_NBR = 4;

}
