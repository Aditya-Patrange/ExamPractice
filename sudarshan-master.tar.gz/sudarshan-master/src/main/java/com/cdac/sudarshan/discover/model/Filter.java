package com.cdac.sudarshan.discover.model;

//import ch.lambdaj.function.matcher.Predicate;

/**
 * Created by kenny on 7/1/14.
 */
public abstract class Filter  {
//    public boolean apply(String word);
}

