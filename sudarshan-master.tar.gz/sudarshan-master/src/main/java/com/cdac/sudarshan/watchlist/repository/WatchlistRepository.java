package com.cdac.sudarshan.watchlist.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cdac.sudarshan.authentication.model.User;
import com.cdac.sudarshan.watchlist.model.Watchlist;

public interface WatchlistRepository extends JpaRepository<Watchlist, Integer> {

	@Query("SELECT u FROM Watchlist u WHERE u.isEnabled = true")
	List<Watchlist> getAllWatchlists();

	@Modifying
	@Query("update Watchlist w set w.isEnabled = false where w.id = id")
	void deactivateWatchlist(@Param("id") Integer id);

	List<Watchlist> findByUser(User user);

//	get Watchlist By User Id.
	List<Watchlist> findByUser_Id(Long id);
}
