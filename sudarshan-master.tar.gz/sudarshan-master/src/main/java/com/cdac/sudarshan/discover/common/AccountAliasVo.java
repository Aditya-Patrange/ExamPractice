package com.cdac.sudarshan.discover.common;

public class AccountAliasVo {

	private String proflName,photo,coverPhoto,age,sex,address,twitterAcc,fbAcc,ytAcc,gpAcc,tumblrAcc,instaAcc;

	public String getPhoto() {
		return photo;
	}

	public void setPhoto(String photo) {
		this.photo = photo;
	}

	public String getCoverPhoto() {
		return coverPhoto;
	}

	public void setCoverPhoto(String coverPhoto) {
		this.coverPhoto = coverPhoto;
	}

	public String getProflName() {
		return proflName;
	}

	public void setProflName(String proflName) {
		this.proflName = proflName;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getTwitterAcc() {
		return twitterAcc;
	}

	public void setTwitterAcc(String twitterAcc) {
		this.twitterAcc = twitterAcc;
	}

	public String getFbAcc() {
		return fbAcc;
	}

	public void setFbAcc(String fbAcc) {
		this.fbAcc = fbAcc;
	}

	public String getYtAcc() {
		return ytAcc;
	}

	public void setYtAcc(String ytAcc) {
		this.ytAcc = ytAcc;
	}

	public String getGpAcc() {
		return gpAcc;
	}

	public void setGpAcc(String gpAcc) {
		this.gpAcc = gpAcc;
	}

	public String getTumblrAcc() {
		return tumblrAcc;
	}

	public void setTumblrAcc(String tumblrAcc) {
		this.tumblrAcc = tumblrAcc;
	}

	public String getInstaAcc() {
		return instaAcc;
	}

	public void setInstaAcc(String instaAcc) {
		this.instaAcc = instaAcc;
	}

}

