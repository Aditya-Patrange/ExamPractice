package com.cdac.sudarshan.signup.services;

import com.cdac.sudarshan.authentication.dto.UserDto;
import com.cdac.sudarshan.dto.SignupResponseDto;
import org.springframework.http.ResponseEntity;

import java.util.Map;

public interface ISignUpService {

    SignupResponseDto signup(UserDto userDto);
    ResponseEntity<?> signupConfirmSecret(Map<String,String> loggedInUser);
}
