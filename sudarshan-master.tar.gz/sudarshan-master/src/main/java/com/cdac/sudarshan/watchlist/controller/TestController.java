package com.cdac.sudarshan.watchlist.controller;

import java.util.Arrays;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.cdac.sudarshan.watchlist.configuration.ApplicationConfiguration;

@RestController
@RequestMapping("test")
@CrossOrigin("*")
public class TestController {

	@Autowired
	private RestTemplate template;

	@Autowired
	private ApplicationConfiguration appConfig;

	@PostMapping("getAlertByUsers")
	public ResponseEntity<?> getAlertByUsers(@RequestBody HashMap<String, Object> data) {
//		http://192.168.181.128:8080/innsight/getAlertByUsers
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<Object>(data, headers);

		ResponseEntity<Object> exchange = template.exchange(appConfig.getProperty("testUrl") + "getAlertByStatusType",
				HttpMethod.POST, entity, Object.class);

		return exchange;
//		return new ResponseEntity<>("", HttpStatus.OK);
	}

}
