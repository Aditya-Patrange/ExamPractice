package com.cdac.sudarshan.discover.model;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by kenny on 7/1/14.
 */
public class StopWordFilter {

    private final Set<String> stopWords = new HashSet<>();

    public StopWordFilter(final Collection<String> stopWords) {
        this.stopWords.addAll(stopWords);
    }

    public boolean apply(String word) {
        return !this.stopWords.contains(word.toLowerCase());
    }

}

