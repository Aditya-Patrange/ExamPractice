package com.cdac.sudarshan.themeManagement.service;

import com.cdac.sudarshan.authentication.model.User;
import com.cdac.sudarshan.authentication.service.IUserService;
import com.cdac.sudarshan.exception.ResourceNotFoundException;
import com.cdac.sudarshan.folderManagement.dto.ApiResponse;
import com.cdac.sudarshan.themeManagement.dto.KeywordRequestDto;
import com.cdac.sudarshan.themeManagement.dto.ThemeRequestDto;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.*;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;

@Service("newKeywordServiceImpl")
public class KeywordServiceImpl implements IKeywordService{

    private RestTemplate template;

    @Autowired
    private IUserService userService;

    @Value("${folderManagementHost}")
    private String keywordManagementHost;

    @Autowired
    public KeywordServiceImpl(RestTemplateBuilder builder) {
        template = builder.build();
    }

/*    private KeywordRequestDto addUserId(KeywordRequestDto data) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication.getName() == null) {
            throw new ResourceNotFoundException("Please Login first...!");
        }

        User loginUser = userService.getUserByUserName(authentication.getName());
        data.setUserId(loginUser.getId());
        return data;
    }*/

    @Override
    public ApiResponse<?> saveKeyword(KeywordRequestDto data) throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<>(data, headers);
        try {
            ResponseEntity<ApiResponse> responseEntity = template.exchange(keywordManagementHost + "theme/saveKeyword", HttpMethod.POST, entity, ApiResponse.class);
            return responseEntity.getBody();
        } catch(HttpStatusCodeException e) {
            return mapper.readValue( e.getResponseBodyAsString(),ApiResponse.class);
        }
    }

    @Override
    public ApiResponse<?> getKeyword(KeywordRequestDto data) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<>(data, headers);
        ResponseEntity<ApiResponse> responseEntity = template.exchange(keywordManagementHost + "theme/getKeyword", HttpMethod.POST, entity, ApiResponse.class);
        return responseEntity.getBody();
    }
}
