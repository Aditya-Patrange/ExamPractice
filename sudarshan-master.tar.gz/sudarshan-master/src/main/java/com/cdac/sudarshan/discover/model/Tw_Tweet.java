package com.cdac.sudarshan.discover.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;

public class Tw_Tweet implements Serializable 
{
	private static final long serialVersionUID = 1L;
	private	String id;
	private String inReplyToScreenName;
	private String inReplyToStatusId;
	private String inReplyToUserId;
	private String lang;
	private String retweetFlag;
	private String retweetSourceId;
	private	String source;
	private String text;
	private String userId;
	private String userName;
	private String latitude;
	private String longitude;
	private String geoLevel;
	private String geoPlace;
	private String city;
	private String country;
	private String countryCode;
	private Long createdAt;
	private int retweetCount;
	private int likeCount;
	private int impressionCount;
	private int sentiment;
	private int favouriteCount;
	private String posibleSensitive;
	private String isTruncated;
	private ArrayList<Integer> entityId;
	private ArrayList<String> hashtag;
	private ArrayList<String> mentions;
	private ArrayList<String> image;
	private ArrayList<String> video;
	private ArrayList<String> url;
	private ArrayList<String> domain;
	private ArrayList<String> priority;
	private Tw_User user;
	
	public ArrayList<String> getPriority() {
		return priority;
	}
	public void setPriority(ArrayList<String> priority) {
		this.priority = priority;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public ArrayList<Integer> getEntityId() {
		return entityId;
	}
	public void setEntityId(ArrayList<Integer> entityId) {
		this.entityId = entityId;
	}
	public ArrayList<String> getHashtag() {
		return hashtag;
	}
	public void setHashtag(ArrayList<String> hashtag) {
		this.hashtag = hashtag;
	}
	public ArrayList<String> getMentions() {
		return mentions;
	}
	public void setMentions(ArrayList<String> mentions) {
		this.mentions = mentions;
	}
	public ArrayList<String> getImage() {
		return image;
	}
	public void setImage(ArrayList<String> image) {
		this.image = image;
	}
	public ArrayList<String> getVideo() {
		return video;
	}
	public void setVideo(ArrayList<String> video) {
		this.video = video;
	}
	public ArrayList<String> getUrl() {
		return url;
	}
	public void setUrl(ArrayList<String> url) {
		this.url = url;
	}
	public ArrayList<String> getDomain() {
		return domain;
	}
	public void setDomain(ArrayList<String> domain) {
		this.domain = domain;
	}
	public String getInReplyToScreenName() {
		return inReplyToScreenName;
	}
	public void setInReplyToScreenName(String inReplyToScreenName) {
		this.inReplyToScreenName = inReplyToScreenName;
	}
	public String getInReplyToStatusId() {
		return inReplyToStatusId;
	}
	public void setInReplyToStatusId(String inReplyToStatusId) {
		this.inReplyToStatusId = inReplyToStatusId;
	}
	public String getInReplyToUserId() {
		return inReplyToUserId;
	}
	public void setInReplyToUserId(String inReplyToUserId) {
		this.inReplyToUserId = inReplyToUserId;
	}
	public String getLang() {
		return lang;
	}
	public void setLang(String lang) {
		this.lang = lang;
	}
	public String getRetweetFlag() {
		return retweetFlag;
	}
	public void setRetweetFlag(String retweetFlag) {
		this.retweetFlag = retweetFlag;
	}
	public String getRetweetSourceId() {
		return retweetSourceId;
	}
	public void setRetweetSourceId(String retweetSourceId) {
		this.retweetSourceId = retweetSourceId;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public int getRetweetCount() {
		return retweetCount;
	}
	public void setRetweetCount(int retweetCount) {
		this.retweetCount = retweetCount;
	}
	public int getLikeCount() {
		return likeCount;
	}
	public void setLikeCount(int likeCount) {
		this.likeCount = likeCount;
	}
	public int getImpressionCount() {
		return impressionCount;
	}
	public void setImpressionCount(int impressionCount) {
		this.impressionCount = impressionCount;
	}
	public String getLatitude() {
		return latitude;
	}
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}
	public String getLongitude() {
		return longitude;
	}
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}
	public String getGeoLevel() {
		return geoLevel;
	}
	public void setGeoLevel(String geoLevel) {
		this.geoLevel = geoLevel;
	}
	public String getGeoPlace() {
		return geoPlace;
	}
	public void setGeoPlace(String geoPlace) {
		this.geoPlace = geoPlace;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public int getSentiment() {
		return sentiment;
	}
	public void setSentiment(int sentiment) {
		this.sentiment = sentiment;
	}
	public int getFavouriteCount() {
		return favouriteCount;
	}
	public void setFavouriteCount(int favouriteCount) {
		this.favouriteCount = favouriteCount;
	}
	public String getPosibleSensitive() {
		return posibleSensitive;
	}
	public void setPosibleSensitive(String posibleSensitive) {
		this.posibleSensitive = posibleSensitive;
	}
	public String getIsTruncated() {
		return isTruncated;
	}
	public void setIsTruncated(String isTruncated) {
		this.isTruncated = isTruncated;
	}
	
	public Long getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(Long createdAt) {
		this.createdAt = createdAt;
	}
	public Tw_User getUser() {
		return user;
	}
	public void setUser(Tw_User user) {
		this.user = user;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "Tw_Tweet [id=" + id + ", entityId=" + entityId + ", hashtag=" + hashtag + ", mentions=" + mentions
				+ ", image=" + image + ", video=" + video + ", url=" + url + ", domain=" + domain + ", priority="
				+ priority + ", createdAt=" + createdAt + ", inReplyToScreenName=" + inReplyToScreenName
				+ ", inReplyToStatusId=" + inReplyToStatusId + ", inReplyToUserId=" + inReplyToUserId + ", lang=" + lang
				+ ", retweetFlag=" + retweetFlag + ", retweetSourceId=" + retweetSourceId + ", source=" + source
				+ ", text=" + text + ", userId=" + userId + ", userName=" + userName + ", retweetCount=" + retweetCount
				+ ", likeCount=" + likeCount + ", impressionCount=" + impressionCount + ", latitude=" + latitude
				+ ", longitude=" + longitude + ", geoLevel=" + geoLevel + ", geoPlace=" + geoPlace + ", city=" + city
				+ ", country=" + country + ", countryCode=" + countryCode + ", sentiment=" + sentiment
				+ ", favouriteCount=" + favouriteCount + ", posibleSensitive=" + posibleSensitive + ", isTruncated="
				+ isTruncated + ", user=" + user + "]";
	}
}
