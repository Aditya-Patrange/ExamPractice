package com.cdac.sudarshan.discover.common;

import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;

public class CollectionUtil 
{
	public static <T> Set<T> getCommonElements(Collection<? extends Collection<T>> collections) {

	    Set<T> common = new LinkedHashSet<T>();
	    if (!collections.isEmpty()) {
	       Iterator<? extends Collection<T>> iterator = collections.iterator();
	       
	       Collection<T> xTop = iterator.next();
	       
	       if(xTop!=null)
	       {
		       common.addAll(xTop);
		       while (iterator.hasNext()) {
		    	   Collection<T> x = iterator.next();
		    	   if(x!=null)
		    		   common.retainAll(x);
		       }
	       }
	    }
	    return common;
	}
}