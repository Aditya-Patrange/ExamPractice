package com.cdac.sudarshan.authentication.service;

import com.cdac.sudarshan.*;
import com.cdac.sudarshan.authentication.model.User;
import com.cdac.sudarshan.code.model.Code;
import com.cdac.sudarshan.code.service.ICodeService;
import com.cdac.sudarshan.discover.dto.JwtResponse;
import com.cdac.sudarshan.dto.SignInResponseDto;
import com.cdac.sudarshan.exception.ResourceNotFoundException;
import com.cdac.sudarshan.exception.UserNameNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.http.client.ClientHttpRequest;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RequestCallback;
import org.springframework.web.client.ResponseExtractor;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.*;

@Service
public class AuthServiceImpl implements IAuthService {

    @Autowired
    private IUserService userService;

    private AppUserAuthentication appUserAuthentication;

    @Autowired
    private JwtTokenUtil jwtUtil;

   // private static String uiCaptcha;

    @Value("${innerInnefuUrl}")
    private String innefuUrl;

    @Autowired
    private RestTemplate template;

    @Autowired
    private ICodeService codeService;

    @Autowired
    private PasswordEncoder passwordEncoder;


    @Override
    public ResponseEntity<?> signIn(Map<String, String> user) {

        User existingUser = userService.getUserByUserName(user.get("username"));
        Map<String, String> response = new HashMap<String, String>();
        if (existingUser.getUsername().equals(user.get("username"))) {
            boolean pwMatches = this.passwordEncoder.matches(user.get("password"), existingUser.getPasswordHash());

            if (pwMatches && existingUser.getEnabled()) {

                // 	if (user.get("captcha").equals(uiCaptcha)) {
                if (true) {

                    // with 2fa enabled user authentication
                    if (isNotBlank(existingUser.getSecret())) {

                        SignInResponseDto signInResponseDto = new SignInResponseDto();
                        signInResponseDto.setData(existingUser.getUsername());
                        signInResponseDto.setMessage("SignIn SuccessFully");
                        signInResponseDto.setStatusCode(HttpStatus.OK.value());
                        //final UserDetails userDetails = userService.loadUserByUsername(user.get("username"));
                     //   final String token = jwtUtil.generateToken(userDetails);

                        // Inneffu Login Done
                        HttpHeaders httpHeadersAfterLogin = getHttpHeadersAfterLogin(user.get("username"), user.get("password"));
                        if (httpHeadersAfterLogin.isEmpty()) {
                            throw new ResourceNotFoundException("Invalid User Credentials for login...!!!");
                        }

                      //  return ResponseEntity.ok(new JwtResponse(token, existingUser.getUsername(), existingUser.getId()));
                        response.put("message","Login Succesfull");
                        return ResponseEntity.ok(response);
                    } else {
                        // without 2fa enabled user authentication
                        //SecurityContextHolder.getContext().setAuthentication(userAuthentication);
                        //final UserDetails userDetails = userService.loadUserByUsername(user.get("username"));
                       // final String token = jwtUtil.generateToken(userDetails);
                     //   return ResponseEntity.ok(new JwtResponse(token, existingUser.getUsername(), existingUser.getId()));
                          return new ResponseEntity<>(new SignInResponseDto("User Authenticated", HttpStatus.OK.value()),
                                    HttpStatus.OK);
                    }

                } else {
                    return new ResponseEntity<>(
                            new SignInResponseDto("Invalid Captcha !!", HttpStatus.INTERNAL_SERVER_ERROR.value()),
                            HttpStatus.INTERNAL_SERVER_ERROR);
                }
            }
        } else {
            throw new UserNameNotFoundException("Invalid username...!!");
        }

        return new ResponseEntity<>(new SignInResponseDto("Invalid password !!", HttpStatus.FORBIDDEN.value()),
                HttpStatus.FORBIDDEN);

    }

    @Override
    public ResponseEntity<?> verifyOTP(Map<String, String> details) {

        Map<String, Object> response = new HashMap<>();

        try {

            User user = userService.getUserByUserName(details.get("username"));

            List<Code> codes = codeService.getScurityCodeOfUser(user.getUsername());
            List<String> backCode = new ArrayList<>();

            if (user == null) {
                response.put("message", String.valueOf(AuthenticationFlow.NOT_AUTHENTICATED));
                return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
            }

            if (isNotBlank(user.getSecret()) && isNotBlank(details.get("code"))) {
                CustomTotp totp = new CustomTotp(user.getSecret());
                final UserDetails userDetails = userService.loadUserByUsername(user.getUsername());
                final String token = jwtUtil.generateToken(userDetails);
                for (Code c : codes) {
                    backCode.add(c.getSecurityCode());
                }
                if (backCode.contains(details.get("code"))) {
                    response.put("jwt", new JwtResponse(token, user.getUsername(), user.getId()));
                    response.put("status", HttpStatus.OK);
                    return new ResponseEntity<>(response, HttpStatus.OK);
                }

                if (!details.get("code").toLowerCase().matches("[a-z]")) {

                    if (totp.verify(details.get("code"), 2, 2).isValid()) {

                       // SecurityContextHolder.getContext().setAuthentication(authentication);
                        response.put("jwt", new JwtResponse(token, user.getUsername(), user.getId()));
                        response.put("status", HttpStatus.OK);
                        return new ResponseEntity<>(response, HttpStatus.OK);
//                        return new ResponseEntity<>(response, HttpStatus.OK);
                    }
                }

//                setAdditionalSecurityFlag(detail.getAppUserId());
//                return ResponseEntity.ok().body(AuthenticationFlow.TOTP_ADDITIONAL_SECURITY);
            }

        } catch (NumberFormatException e) {
            response.put("message", "Invalid OTP!!!");
            response.put("status",HttpStatus.BAD_REQUEST);
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            response.put("message", "Something went wrong!!!");
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
//        catch ( e) {
//            response.put("message", "Something went wrong!!!");
//            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
//       }
        response.put("message", String.valueOf(AuthenticationFlow.NOT_AUTHENTICATED));
        return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);

    }

    @Override
    public ResponseEntity<?> getCodesOfUser(String username) {

        List<Code> securityCode = new ArrayList<>();
        Map<String, Object> response = new HashMap<>();
        Map<Object, String> securityCodeIntoMap = new HashMap<>();
        try {
            securityCode = codeService.getScurityCodeOfUser(username);
        } catch (Exception e) {
            response.put("message", e.getMessage());
            response.put("status Code", String.valueOf(HttpStatus.NOT_FOUND.value()));
            return ResponseEntity.ok(response);
        }
        int i = 0;
        String secret = "";
        for (Code c : securityCode) {
            securityCodeIntoMap.put(i, c.getSecurityCode());
            secret = c.getUser().getSecret();
            i++;
        }

        response.put("message", "Codes Fetch");
        response.put("codes", securityCodeIntoMap);
        response.put("Secret", secret);
        return ResponseEntity.ok(response);

    }

/*    @Override
    public ResponseEntity<?> getCaptcha() {
        User user = new User();
        String captcha = CaptchaUtil.getCaptcha(user);
        uiCaptcha = captcha;
        SignInResponseDto signInResponse = new SignInResponseDto("Captcha generated!!", captcha, HttpStatus.OK.value());
        return ResponseEntity.ok(signInResponse);
    }*/

    private HttpHeaders getHttpHeadersAfterLogin(String username, String password) {
        ClientHttpResponse response = template.execute(innefuUrl + "innsight/login_validateCredential",
                HttpMethod.POST, new RequestCallback() {
                    public void doWithRequest(ClientHttpRequest request) throws IOException {
                        request.getBody().write(("userName=" + username + "&password=" + password).getBytes());
                    }
                }, new ResponseExtractor<ClientHttpResponse>() {

                    @Override
                    public ClientHttpResponse extractData(ClientHttpResponse response) throws IOException {
                        return response;
                    }
                });

        HttpHeaders headers = new HttpHeaders();
        List<String> cookies = response.getHeaders().get("Set-Cookie");
        headers.set("Cookie", cookies.get(0));
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        return headers;
//		return null;
    }

    private static boolean isNotBlank(String str) {
        return str != null && !str.isBlank();
    }

    @Override
    public ResponseEntity<?> getLoggedInUserDetails() {

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication.getName() == null) {
            throw new ResourceNotFoundException("Please Login first For getting urls count");
        }

        User loggedInUser = userService.getUserByUserName(authentication.getName());

        return ResponseEntity.ok(loggedInUser);
    }




}
