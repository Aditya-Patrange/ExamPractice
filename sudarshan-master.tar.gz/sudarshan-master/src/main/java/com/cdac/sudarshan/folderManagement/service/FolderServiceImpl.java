package com.cdac.sudarshan.folderManagement.service;

import com.cdac.sudarshan.authentication.model.User;
import com.cdac.sudarshan.authentication.service.IUserService;
import com.cdac.sudarshan.exception.ResourceNotFoundException;
import com.cdac.sudarshan.folderManagement.dto.ApiResponse;
import com.cdac.sudarshan.folderManagement.dto.ErrorResponse;
import com.cdac.sudarshan.folderManagement.dto.FolderRequestDto;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

@Service
public class FolderServiceImpl implements IFolderService {

    /* Synchronus rest client class to invoke backend API */
    private RestTemplate template;

    @Autowired
    private IUserService userService;

    @Value("${folder.management.host}")
    private String folderManagementHost;

    @Autowired
    public FolderServiceImpl(RestTemplateBuilder builder) {
        template = builder.build();
    }

    private FolderRequestDto addUserId(FolderRequestDto data) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication.getName() == null) {
            throw new ResourceNotFoundException("Please Login first...!");
        }

        User loginUser = userService.getUserByUserName(authentication.getName());
        data.setUserId(loginUser.getId());
        return data;
    }

    private List<FolderRequestDto> addUserId(List<FolderRequestDto> data) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication.getName() == null) {
            throw new ResourceNotFoundException("Please Login first...!");
        }

        User loginUser = userService.getUserByUserName(authentication.getName());
        for(int i=0; i<data.size(); i++){
            data.get(i).setUserId(loginUser.getId());
        }
        return data;
    }

    @Override
    public ApiResponse saveFolder(FolderRequestDto data) throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<>(addUserId(data), headers);
        try {
            ResponseEntity<ApiResponse> responseEntity = template.exchange(folderManagementHost + "folder/saveFolder", HttpMethod.POST, entity, ApiResponse.class);
            return responseEntity.getBody();
        } catch(HttpStatusCodeException e) {
            return mapper.readValue( e.getResponseBodyAsString(),ApiResponse.class);
        }

    }

    @Override
    public ApiResponse getFolder(FolderRequestDto data) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<>(addUserId(data), headers);
        //return template.exchange(folderManagementHost + "folder/getFolder", HttpMethod.POST, entity, ApiResponse.class);
        ResponseEntity<ApiResponse> responseEntity = template.exchange(folderManagementHost + "folder/getFolder", HttpMethod.POST, entity, ApiResponse.class);
        return responseEntity.getBody();
    }

    @Override
    public ApiResponse<?> getStatusReference() {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<>(null, headers);
        //return template.exchange(folderManagementHost + "folder/getFolder", HttpMethod.POST, entity, ApiResponse.class);
        ResponseEntity<ApiResponse> responseEntity = template.exchange(folderManagementHost + "folder/getStatusList", HttpMethod.GET,entity, ApiResponse.class);
        return responseEntity.getBody();
    }

    @Override
    public ApiResponse<?> moveFolder(List<FolderRequestDto> data) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<>(addUserId(data), headers);
        //return template.exchange(folderManagementHost + "folder/getFolder", HttpMethod.POST, entity, ApiResponse.class);
        ResponseEntity<ApiResponse> responseEntity = template.exchange(folderManagementHost + "folder/moveFolder", HttpMethod.POST,entity, ApiResponse.class);
        return responseEntity.getBody();
    }

    @Override
    public ApiResponse<?> renameFolder(List<FolderRequestDto> data) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<>(addUserId(data), headers);
        //return template.exchange(folderManagementHost + "folder/getFolder", HttpMethod.POST, entity, ApiResponse.class);
        ResponseEntity<ApiResponse> responseEntity = template.exchange(folderManagementHost + "folder/renameFolder", HttpMethod.POST,entity, ApiResponse.class);
        return responseEntity.getBody();
    }

    @Override
    public ApiResponse<?> restoreFolder(FolderRequestDto data) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<>(addUserId(data), headers);
        //return template.exchange(folderManagementHost + "folder/getFolder", HttpMethod.POST, entity, ApiResponse.class);
        ResponseEntity<ApiResponse> responseEntity = template.exchange(folderManagementHost + "folder/restoreFolder", HttpMethod.POST,entity, ApiResponse.class);
        return responseEntity.getBody();
    }

    @Override
    public ApiResponse<?> softRemoveFolder(FolderRequestDto data) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<>(addUserId(data), headers);
        //return template.exchange(folderManagementHost + "folder/getFolder", HttpMethod.POST, entity, ApiResponse.class);
        ResponseEntity<ApiResponse> responseEntity = template.exchange(folderManagementHost + "folder/softRemoveFolder", HttpMethod.POST,entity, ApiResponse.class);
        return responseEntity.getBody();
    }

    @Override
    public ApiResponse<?> copyFolder(List<FolderRequestDto> data) throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<>(addUserId(data), headers);
        try {
        ResponseEntity<ApiResponse> responseEntity = template.exchange(folderManagementHost + "folder/copyFolder", HttpMethod.POST,entity, ApiResponse.class);
            System.out.println("Body :"+responseEntity.getBody());
        return responseEntity.getBody();
        } catch(HttpStatusCodeException e) {
            return mapper.readValue( e.getResponseBodyAsString(),ApiResponse.class);
        }
    }

    @Override
    public ApiResponse<?> getFolderList(FolderRequestDto data) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<>(addUserId(data), headers);
        //return template.exchange(folderManagementHost + "folder/getFolder", HttpMethod.POST, entity, ApiResponse.class);
        ResponseEntity<ApiResponse> responseEntity = template.exchange(folderManagementHost + "folder/getFolderList", HttpMethod.POST, entity, ApiResponse.class);
        return responseEntity.getBody();
    }
    @Override
    public ApiResponse<?> permanentRemoveFolder(FolderRequestDto data) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<>(addUserId(data), headers);
        ResponseEntity<ApiResponse> responseEntity = template.exchange(folderManagementHost + "folder/removeFolder", HttpMethod.POST,entity, ApiResponse.class);
        return responseEntity.getBody();
    }

    @Override
    public ApiResponse<?> getItemCount(List<FolderRequestDto> data) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<>(addUserId(data), headers);
        ResponseEntity<ApiResponse> responseEntity = template.exchange(folderManagementHost + "folder/getItemCount", HttpMethod.POST,entity, ApiResponse.class);
        return responseEntity.getBody();
    }
}
