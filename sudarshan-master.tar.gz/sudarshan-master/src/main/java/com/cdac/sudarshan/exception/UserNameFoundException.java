package com.cdac.sudarshan.exception;

public class UserNameFoundException extends RuntimeException {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public UserNameFoundException(String message) {
        super(message);
    }
}
