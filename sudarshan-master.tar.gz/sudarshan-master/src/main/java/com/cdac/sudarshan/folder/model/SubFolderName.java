package com.cdac.sudarshan.folder.model;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class SubFolderName {
	
	private String subFolderName;
	
	private SubSubFolderName subSubFolderName;

}
