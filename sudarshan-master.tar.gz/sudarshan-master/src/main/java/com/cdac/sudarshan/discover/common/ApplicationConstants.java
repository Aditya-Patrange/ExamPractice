package com.cdac.sudarshan.discover.common;

public class ApplicationConstants 
{
   public static final String LOGIN_USER = "loginUser"; 
   public static final String LOGINUSERID = "userLoginId";
   public static final String SESSIONUSER = "sessionUser";
   public static final String COMPANYCIN="companyCin";
   public static final String NEWS="news";
   public static final String TWEET="tweet";
   public static final String USERROLE = "role"; 
   public static final String APIKEYSTW = "twapikeys"; 
   
   public static final String INNSIGHTIMAGEPATHLOCAL = "innsightImagePathLocal"; 
   public static final String FBIMAGEPATHLOCAL = "fbImagePathLocal";
   public static final String WHATSAPPIMAGEPATHLOCAL = "whatsappImagePathLocal";
   public static final String TELEGRAMIMAGEPATHLOCAL = "telegramImagePathLocal";
   public static final String INNSIGHTIMAGEFLAG = "innsightImageFlag";
   public static final String FRSSERVERURL = "frsServerURL";
   
   public static final String HIDEWHATSAPPSENDERFLAG = "hideWhatsappSenderFlag";
   public static final String CLIENTNAME = "clientName";
   public static final String DEFAULTDAYSOFDATALOAD = "defaultDaysOfDataLoad";
   public static final String ARTICLEPRIORITYFLAG = "articlePriorityFlag";
   public static final String TWOPAGEREPORTFLAG = "twoPageReportFlag";
   public static final String REQUESTEDURL = "requestedURL";
   public static final String NGSERVICEURL = "ngServiceUrl";
   public static final String USERTEMPLATE = "userTemplate";
   public static final String ODSSERVERURL = "odsServerUrl";
   
   public static final String BLACKLISTKEYWORDS = "blacklistKeywords";
   public static final String NERIGNOREKEYWORDS = "nerIgnoreKeywords";
   
}