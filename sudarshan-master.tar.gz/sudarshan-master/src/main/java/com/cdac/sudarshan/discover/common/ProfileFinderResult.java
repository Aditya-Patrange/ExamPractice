package com.cdac.sudarshan.discover.common;

import java.util.HashMap;

public class ProfileFinderResult {
	
	private int id;
	private String countryCode;
	private String keyword;
	private String profileName;
	private String socialId;
	private String profileId;
	private String image;
	private int newProfile;
	private String sourceType;
	private String resultDate, insertedDate, entityStats;
	private String profileHandler;
	private String description;
	private String jobProfile;
	private String profileLocation, country;
	private String resultFlag;
	private HashMap<String, String> sourceResult;
	private String searchKeywordId;
	private String isVerified;
	
	//setters and getters
	
	public String getResultFlag() {
		return resultFlag;
	}
	public String getEntityStats() {
		return entityStats;
	}
	public void setEntityStats(String entityStats) {
		this.entityStats = entityStats;
	}
	public void setResultFlag(String resultFlag) {
		this.resultFlag = resultFlag;
	}
	
	public int getNewProfile() {
		return newProfile;
	}
	public void setNewProfile(int newProfile) {
		this.newProfile = newProfile;
	}
	
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getInsertedDate() {
		return insertedDate;
	}
	public void setInsertedDate(String insertedDate) {
		this.insertedDate = insertedDate;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getKeyword() {
		return keyword;
	}
	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}
	public String getProfileName() {
		return profileName;
	}
	public void setProfileName(String profileName) {
		this.profileName = profileName;
	}
	public String getProfileId() {
		return profileId;
	}
	public void setProfileId(String profileId) {
		this.profileId = profileId;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getSourceType() {
		return sourceType;
	}
	public void setSourceType(String sourceType) {
		this.sourceType = sourceType;
	}
	public String getResultDate() {
		return resultDate;
	}
	public void setResultDate(String resultDate) {
		this.resultDate = resultDate;
	}
	public String getProfileHandler() {
		return profileHandler;
	}
	public void setProfileHandler(String profileHandler) {
		this.profileHandler = profileHandler;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getJobProfile() {
		return jobProfile;
	}
	public void setJobProfile(String jobProfile) {
		this.jobProfile = jobProfile;
	}
	public String getProfileLocation() {
		return profileLocation;
	}
	public void setProfileLocation(String profileLocation) {
		this.profileLocation = profileLocation;
	}
	public HashMap<String, String> getSourceResult() {
		return sourceResult;
	}
	public void setSourceResult(HashMap<String, String> sourceResult) {
		this.sourceResult = sourceResult;
	}
	public String getSearchKeywordId() {
		return searchKeywordId;
	}
	public void setSearchKeywordId(String searchKeywordId) {
		this.searchKeywordId = searchKeywordId;
	}
	public String getIsVerified() {
		return isVerified;
	}
	public void setIsVerified(String isVerified) {
		this.isVerified = isVerified;
	}
	public String getSocialId() {
		return socialId;
	}
	public void setSocialId(String socialId) {
		this.socialId = socialId;
	}
	@Override
	public String toString() {
		return "ProfileFinderResult [id=" + id + ", countryCode=" + countryCode + ", keyword=" + keyword
				+ ", profileName=" + profileName + ", profileId=" + profileId + ", image=" + image + ", newProfile="
				+ newProfile + ", sourceType=" + sourceType + ", resultDate=" + resultDate + ", insertedDate="
				+ insertedDate + ", entityStats=" + entityStats + ", profileHandler=" + profileHandler
				+ ", description=" + description + ", jobProfile=" + jobProfile + ", profileLocation=" + profileLocation
				+ ", country=" + country + ", resultFlag=" + resultFlag + ", sourceResult=" + sourceResult + "]";
	}
		
}