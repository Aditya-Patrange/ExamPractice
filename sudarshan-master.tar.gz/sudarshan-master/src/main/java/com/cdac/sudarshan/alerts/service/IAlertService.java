package com.cdac.sudarshan.alerts.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.cdac.sudarshan.alerts.model.CaseVo;
import org.springframework.http.ResponseEntity;

import com.cdac.sudarshan.alerts.model.Alert;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

public interface IAlertService {
	

	public Alert saveAlert(Alert alert);

	String getAlertsDataFromEs(String path, String size) throws Exception;

	public List<Alert> getAlerts();

	public ResponseEntity<?> getAlertsDataFromCollections(HashMap<String, Object> data) throws JsonMappingException, JsonProcessingException;
	
	public ResponseEntity<?> saveAlertsToDB(HashMap<String, Object> data) throws Exception;
	
	public List<Alert> getAlertsByUserID(Long userId);

	public ResponseEntity<?> addUserAlerts(CaseVo data);

//	public ArrayList<CaseVo> getAlertByUsers(CaseVo caseVo);

	public ArrayList<CaseVo> getAlertCountsImplementation(CaseVo caseVo);

	public ResponseEntity<?> getAlertDetails(CaseVo data);


	public ResponseEntity<?> getAlertCounts(CaseVo data);

	public  ResponseEntity<?> getAlertByUsersId(HashMap<String , Integer> data);

	public ArrayList<CaseVo> getAlertByUsersIdImpl(HashMap<String , Integer> data);

	public ResponseEntity<?> getAlertWorkDaysById(HashMap<String, Integer> data);

	public ArrayList<CaseVo> getAlertWorkDaysByIdImpl(HashMap<String, Integer> data);

	public ResponseEntity<?> dltUserAlerts(HashMap<String, Integer> data);

	public String dltUserAlertsImpl(HashMap<String, Integer> data);


	public  ResponseEntity<?> getAlertByStatusType(HashMap<String, String> data);

	public ArrayList<CaseVo> getAlertByStatusTypeImpl(HashMap<String ,String> data);

	public  ResponseEntity<?> updateAlertStatusReadByID(HashMap<String, Integer> data);

	public String updateAlertStatusReadByIDImpl(HashMap<String , Integer> data);

	public String updateAllAlertReadStatusImpl();

	public ResponseEntity<?> updateAllAlertReadStatus();

	public ResponseEntity<?>  getAlertByUsers(CaseVo data);

	public ArrayList<CaseVo> getAlertByUsersImpl(CaseVo caseVo);

	public String actDactAlertValueImpl(CaseVo caseVo);
	public ResponseEntity<?> actDactAlertValue(CaseVo caseVo);
}
