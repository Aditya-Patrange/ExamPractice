package com.cdac.sudarshan.discover.common;

import java.io.Serializable;

public class UserProfileBasicInformationVo implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private int profileId;
	private String firstName;
	private String lastName;
	private int profilePhotoId;
	private int profileCoverPhotoId;
	private String permanentAddress;
	private String localAddress;
	private String fatherName;
	private String motherName;
	private String dob;
	private String gender;
	private String nationality;
	private String martialStatus;
	private String addaharCard;
	private String panCard;
	private String passportNo;
	private String description;
	private String classification;
	private String loginId;
	private String alias;
	private String searchStr;
	private String profilePhoto;
	private String coverPhoto;
	
	public int getProfileId() 
	{
		return profileId;
	}
	public void setProfileId(int profileId) 
	{
		this.profileId = profileId;
	}
	public String getFirstName() 
	{
		return firstName;
	}
	public void setFirstName(String firstName) 
	{
		this.firstName = firstName;
	}
	public String getLastName()
	{
		return lastName;
	}
	public void setLastName(String lastName)
	{
		this.lastName = lastName;
	}
    
	public int getProfilePhotoId() 
	{
		return profilePhotoId;
	}
	public void setProfilePhotoId(int profilePhotoId) 
	{
		this.profilePhotoId = profilePhotoId;
	}
	public int getProfileCoverPhotoId()
	{
		return profileCoverPhotoId;
	}
	public void setProfileCoverPhotoId(int profileCoverPhotoId) 
	{
		this.profileCoverPhotoId = profileCoverPhotoId;
	}
	public String getPermanentAddress() 
	{
		return permanentAddress;
	}
	public void setPermanentAddress(String permanentAddress)
	{
		this.permanentAddress = permanentAddress;
	}
	public String getLocalAddress() 
	{
		return localAddress;
	}
	public void setLocalAddress(String localAddress) 
	{
		this.localAddress = localAddress;
	}
	public String getFatherName() 
	{
		return fatherName;
	}
	public void setFatherName(String fatherName) 
	{
		this.fatherName = fatherName;
	}
	public String getMotherName() 
	{
		return motherName;
	}
	public void setMotherName(String motherName) 
	{
		this.motherName = motherName;
	}
	public String getDob() 
	{
		return dob;
	}
	public void setDob(String dob)
	{
		this.dob = dob;
	}
	public String getGender()
	{
		return gender;
	}
	public void setGender(String gender) 
	{
		this.gender = gender;
	}
	public String getNationality() 
	{
		return nationality;
	}
	public void setNationality(String nationality)
	{
		this.nationality = nationality;
	}
	public String getMartialStatus() 
	{
		return martialStatus;
	}
	public void setMartialStatus(String martialStatus) 
	{
		this.martialStatus = martialStatus;
	}
	public String getAddaharCard() 
	{
		return addaharCard;
	}
	public void setAddaharCard(String addaharCard) 
	{
		this.addaharCard = addaharCard;
	}
	public String getPanCard() 
	{
		return panCard;
	}
	public void setPanCard(String panCard) 
	{
		this.panCard = panCard;
	}
	public String getPassportNo() 
	{
		return passportNo;
	}
	public void setPassportNo(String passportNo) 
	{
		this.passportNo = passportNo;
	}
	public String getDescription() 
	{
		return description;
	}
	public void setDescription(String description) 
	{
		this.description = description;
	}
	public String getClassification() 
	{
		return classification;
	}
	public void setClassification(String classification) 
	{
		this.classification = classification;
	}
	public String getLoginId() 
	{
		return loginId;
	}
	public void setLoginId(String loginId) 
	{
		this.loginId = loginId;
	}
	public static long getSerialversionuid() 
	{
		return serialVersionUID;
	}
	
	public String getAlias() 
	{
		return alias;
	}
	public void setAlias(String alias) 
	{
		this.alias = alias;
	}	
	public String getSearchStr() 
	{
		return searchStr;
	}
		
	public String getProfilePhoto() {
		return profilePhoto;
	}
	public void setProfilePhoto(String profilePhoto) {
		this.profilePhoto = profilePhoto;
	}
	public String getCoverPhoto() {
		return coverPhoto;
	}
	public void setCoverPhoto(String coverPhoto) {
		this.coverPhoto = coverPhoto;
	}
	public void setSearchStr(String searchStr) 
	{
		this.searchStr = searchStr;
	}
	
	@Override
	public String toString() 
	{
		return "UserProfileBasicInformationVo [profileId=" + profileId + ", firstName=" + firstName + ", lastName="
				+ lastName + ", profilePhotoId=" + profilePhotoId + ", profileCoverPhotoId=" + profileCoverPhotoId
				+ ", permanentAddress=" + permanentAddress + ", localAddress=" + localAddress + ", fatherName="
				+ fatherName + ", motherName=" + motherName + ", dob=" + dob + ", gender=" + gender + ", nationality="
				+ nationality + ", martialStatus=" + martialStatus + ", addaharCard=" + addaharCard + ", panCard="
				+ panCard + ", passportNo=" + passportNo + ", description=" + description + ", classification="
				+ classification + ", loginId=" + loginId + ", alias=" + alias + ", searchStr=" + searchStr
				+ ", profilePhoto=" + profilePhoto + ", coverPhoto=" + coverPhoto
				+ "]";
	}
	
}
