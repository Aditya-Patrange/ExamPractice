package com.cdac.sudarshan.exception;

import com.cdac.sudarshan.folderManagement.dto.ApiResponse;
import com.cdac.sudarshan.folderManagement.dto.ErrorResponse;
import io.jsonwebtoken.ExpiredJwtException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.cdac.sudarshan.utils.ResponseDto;
import org.springframework.web.bind.annotation.ResponseStatus;

import javax.validation.ConstraintViolationException;
import java.util.HashMap;
import java.util.Map;

@ControllerAdvice
public class GlobalExceptionHandler {

	
	@ExceptionHandler(Exception.class)
	public ResponseEntity<?> globalExceptionHandler(Exception ex){
		ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage("Something went wrong on serverside...!!!");
		responseDto.setSuccess(false);
		responseDto.setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
		return new ResponseEntity<>(responseDto, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@ExceptionHandler(ResourceNotFoundException.class)
	public ResponseEntity<?> ResourceNotFoundException(ResourceNotFoundException ex){
		ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(ex.getMessage());
		responseDto.setSuccess(false);
		responseDto.setStatusCode(HttpStatus.UNAUTHORIZED.value());
		return new ResponseEntity<>(responseDto, HttpStatus.UNAUTHORIZED);
	}

	@ExceptionHandler(DataNotFoundException.class)
	public ResponseEntity<?> DataNotFoundException(DataNotFoundException ex){
		ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(ex.getMessage());
		responseDto.setSuccess(false);
		responseDto.setStatusCode(HttpStatus.NOT_FOUND.value());
		return new ResponseEntity<>(responseDto, HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(PathNotFoundException.class)
	public ResponseEntity<?> PathNotFoundException(PathNotFoundException ex){
		ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(ex.getMessage());
		responseDto.setSuccess(false);
		responseDto.setStatusCode(HttpStatus.NOT_FOUND.value());
		return new ResponseEntity<>(responseDto, HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(DataAlreadyFoundException.class)
	public ResponseEntity<?> DataAlreadyFoundException(DataAlreadyFoundException ex){
		ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(ex.getMessage());
		responseDto.setSuccess(false);
		responseDto.setStatusCode(HttpStatus.CONFLICT.value());
		return new ResponseEntity<>(responseDto, HttpStatus.CONFLICT);
	}

	@ExceptionHandler(UserNameFoundException.class)
	public ResponseEntity<?> UserNameFoundException(UserNameFoundException ex){
		ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(ex.getMessage());
		responseDto.setSuccess(false);
		responseDto.setStatusCode(HttpStatus.CONFLICT.value());
		return new ResponseEntity<>(responseDto, HttpStatus.CONFLICT);
	}
	
	@ExceptionHandler(UserNameNotFoundException.class)
	public ResponseEntity<?> UserNameNotFoundException(UserNameNotFoundException ex){
		ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(ex.getMessage());
		responseDto.setSuccess(false);
		responseDto.setStatusCode(HttpStatus.FORBIDDEN.value());
		return new ResponseEntity<>(responseDto, HttpStatus.FORBIDDEN);
	}

//	@ExceptionHandler(PathNotFoundException.class)
//	public ResponseEntity<?> PathNotFoundException(PathNotFoundException ex){
//		ResponseDto responseDto = new ResponseDto();
//		responseDto.setMessage(ex.getMessage());
//		responseDto.setSuccess(false);
//		responseDto.setStatusCode(HttpStatus.NOT_FOUND.value());
//		return new ResponseEntity<>(responseDto, HttpStatus.NOT_FOUND);
//	}

	@ExceptionHandler(JwtTokenExpired.class)
	public ResponseEntity<?> ExpiredJwtException(JwtTokenExpired ex){
		ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(ex.getMessage());
		responseDto.setSuccess(false);
		responseDto.setStatusCode(HttpStatus.UNAUTHORIZED.value());
		return new ResponseEntity<>(responseDto, HttpStatus.UNAUTHORIZED);
	}

	@ExceptionHandler(ResourceFoundException.class)
	public ResponseEntity<?> ResourceFoundException(ResourceFoundException ex){
		ResponseDto responseDto = new ResponseDto();
		responseDto.setMessage(ex.getMessage());
		responseDto.setSuccess(false);
		responseDto.setStatusCode(HttpStatus.CONFLICT.value());
		return new ResponseEntity<>(responseDto, HttpStatus.CONFLICT);
	}

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<?> handleMethodArgsNotValidException(MethodArgumentNotValidException ex) {
		ErrorResponse<?> errorResponse = new ErrorResponse<>();
		ex.getBindingResult().getAllErrors().forEach((error) -> {
			errorResponse.setMessage(error.getDefaultMessage());
			errorResponse.setSuccess(false);
			errorResponse.setStatusCode(HttpStatus.BAD_REQUEST.value());
		});
		return new ResponseEntity<ErrorResponse>(errorResponse, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(ConstraintViolationException.class)
	public ResponseEntity<?> handle(ConstraintViolationException ex) {
		ApiResponse<Object> responseDto = new ApiResponse<>();
		responseDto.setMessage(ex.getMessage());
		responseDto.setSuccess(false);
		responseDto.setStatus("CONFLICT");
		responseDto.setStatusCode(HttpStatus.CONFLICT.value());
		return new ResponseEntity<>(responseDto, HttpStatus.BAD_REQUEST);
	}



}
