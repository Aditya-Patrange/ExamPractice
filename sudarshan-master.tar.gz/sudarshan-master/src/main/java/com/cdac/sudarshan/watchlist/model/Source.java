package com.cdac.sudarshan.watchlist.model;

import javax.persistence.Entity;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@ToString
@RequiredArgsConstructor
public class Source extends BaseEntity{	
	
//	@Column(unique = true)
	private String source;

	private String value;
}
