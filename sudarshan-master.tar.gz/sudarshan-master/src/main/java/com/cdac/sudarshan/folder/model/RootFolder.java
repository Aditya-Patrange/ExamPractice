package com.cdac.sudarshan.folder.model;

import com.cdac.sudarshan.authentication.model.User;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "root_folder")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
//@ToString
public class RootFolder {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String rootFolderName;

	@CreationTimestamp
	private LocalDateTime creationTimeAndDate;

	@OneToMany(mappedBy = "folderPath")
	private List<SubFolderPaths> subFolderPaths;

	@ManyToOne
	@JoinColumn(name = "user_id")
	@JsonIgnore
	private User user;

	private boolean status;

//	@OneToMany(mappedBy = "rootFolder")
//	private List<UrlsPath> urlsPaths;
	
//	@Embedded
//	private Data data;

}
