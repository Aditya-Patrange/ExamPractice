package com.cdac.sudarshan.alerts.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cdac.sudarshan.alerts.model.Alert;

@Repository
public interface AlertRepository extends JpaRepository<Alert, Long> {
	
	List<Alert> findByUserId(Long id);
}
