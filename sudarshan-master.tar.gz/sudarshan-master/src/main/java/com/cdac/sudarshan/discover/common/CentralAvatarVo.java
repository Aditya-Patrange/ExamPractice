package com.cdac.sudarshan.discover.common;

import java.io.Serializable;

public class CentralAvatarVo implements Serializable
{
	private static final long serialVersionUID = 1L;
	private String avatarId;
	private String firstName;
	private String lastName;
	private String fullName;
	private String email;
	private String phone;
	private String birthDay;
	private String gender;
	private String country;
	private String countryCode;
	private String source;
	private String userName;
	private String password;
	private String isActive;
	private String accountType;
	private String avatarCreatedTime;
	private String avatarBlockedDateTime;
	private String avatarCategory;
	private String clientUserName;
	private String clientUserId;
	private String globalClientId;
	private String avatarAddedFrom;
	private String synchStatus;
	private int profileCount;
	
	public int getProfileCount() {
		return profileCount;
	}
	public void setProfileCount(int profileCount) {
		this.profileCount = profileCount;
	}
	public String getSynchStatus() {
		return synchStatus;
	}
	public void setSynchStatus(String synchStatus) {
		this.synchStatus = synchStatus;
	}
	public String getAvatarAddedFrom() {
		return avatarAddedFrom;
	}
	public void setAvatarAddedFrom(String avatarAddedFrom) {
		this.avatarAddedFrom = avatarAddedFrom;
	}
	public String getAvatarCreatedTime() {
		return avatarCreatedTime;
	}
	public String getAvatarBlockedDateTime() {
		return avatarBlockedDateTime;
	}
	public void setAvatarBlockedDateTime(String avatarBlockedDateTime) {
		this.avatarBlockedDateTime = avatarBlockedDateTime;
	}
	public void setAvatarCreatedTime(String avatarCreatedTime) {
		this.avatarCreatedTime = avatarCreatedTime;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getIsActive() {
		return isActive;
	}
	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}
	public String getAvatarId() {
		return avatarId;
	}
	public void setAvatarId(String avatarId) {
		this.avatarId = avatarId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getBirthDay() {
		return birthDay;
	}
	public void setBirthDay(String birthDay) {
		this.birthDay = birthDay;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getAvatarCategory() {
		return avatarCategory;
	}
	public void setAvatarCategory(String avatarCategory) {
		this.avatarCategory = avatarCategory;
	}
	public String getClientUserName() {
		return clientUserName;
	}
	public void setClientUserName(String clientUserName) {
		this.clientUserName = clientUserName;
	}
	public String getClientUserId() {
		return clientUserId;
	}
	public void setClientUserId(String clientUserId) {
		this.clientUserId = clientUserId;
	}
	public String getGlobalClientId() {
		return globalClientId;
	}
	public void setGlobalClientId(String globalClientId) {
		this.globalClientId = globalClientId;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "CentralAvatarVo [avatarId=" + avatarId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", fullName=" + fullName + ", email=" + email + ", phone=" + phone + ", birthDay=" + birthDay
				+ ", gender=" + gender + ", country=" + country + ", countryCode=" + countryCode + ", source=" + source
				+ ", userName=" + userName + ", password=" + password + ", isActive=" + isActive + ", accountType="
				+ accountType + ", avatarCreatedTime=" + avatarCreatedTime + ", avatarBlockedDateTime="
				+ avatarBlockedDateTime + ", avatarCategory=" + avatarCategory + ", clientUserName=" + clientUserName
				+ ", clientUserId=" + clientUserId + ", globalClientId=" + globalClientId + ", avatarAddedFrom="
				+ avatarAddedFrom + ", synchStatus=" + synchStatus + ", profileCount=" + profileCount + "]";
	}
}
