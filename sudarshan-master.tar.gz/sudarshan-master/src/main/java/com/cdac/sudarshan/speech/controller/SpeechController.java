package com.cdac.sudarshan.speech.controller;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.cdac.sudarshan.speech.service.ISpeechService;

@RestController
@CrossOrigin("*")
public class SpeechController {

	@Autowired
	private ISpeechService speechService;

	@PostMapping("/speech/getTranscribe/English")
	public ResponseEntity<?> getTranscribeEnglish(@RequestParam("file") MultipartFile file) {
		return new ResponseEntity<>(speechService.getTranscribeEnglish(file), HttpStatus.OK);
	}

	@PostMapping("/speech/getTranscribe/Hindi")
	public ResponseEntity<?> getTranscribeHindi(@RequestParam("file") MultipartFile file, String language) {
		return new ResponseEntity<>(speechService.getTranscribeHindi(file), HttpStatus.OK);
	}

	@PostMapping("/speech/advancesearchnew/English")
	public ResponseEntity<?> getKWSAdvanceSearchEnglish(@RequestParam("file") MultipartFile file) {
		return new ResponseEntity<>(speechService.getKWSAdvanceSearchEnglish(file), HttpStatus.OK);
	}

	@PostMapping("/speech/advancesearchnew/Hindi")
	public ResponseEntity<?> getKWSAdvanceSearchHindi(@RequestParam("file") MultipartFile file) {
		return new ResponseEntity<>(speechService.getKWSAdvanceSearchHindi(file), HttpStatus.OK);
	}

	@PostMapping("/speech/getLanguage")
	public ResponseEntity<?> getLIDLanguage(@RequestParam("file") MultipartFile file) {
		return new ResponseEntity<>(speechService.getLIDLanguage(file), HttpStatus.OK);
	}

	@PostMapping("/speech/getTranscribe")
	public ResponseEntity<?> getTranscribe(@RequestParam("file") MultipartFile file) {

		try {
			return new ResponseEntity<>(speechService.getTranscribeTest(file), HttpStatus.OK);
		} catch (KeyManagementException | NoSuchAlgorithmException | KeyStoreException | CertificateException
				| IOException e) {
			e.printStackTrace();
		}

		return null;
	}

}
