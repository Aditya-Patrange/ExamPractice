package com.cdac.sudarshan.mysearches.dto;

public interface MySearchesProjection {
String getKeyword();

}
