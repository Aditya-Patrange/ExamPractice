package com.cdac.sudarshan.discover.common;

import java.io.Serializable;

public class UserProfileAssociatedOrganizationsVo implements Serializable
{
	private static final long serialVersionUID = 1L;
	
	private int organizationId;
	private int profileId;
	private String organizationName;
	private String frequency;
	private String organizationCategory;
	
	public int getOrganizationId() 
	{
		return organizationId;
	}
	public void setOrganizationId(int organizationId)
	{
		this.organizationId = organizationId;
	}
	public int getProfileId()
	{
		return profileId;
	}
	public void setProfileId(int profileId) 
	{
		this.profileId = profileId;
	}
	public String getOrganizationName() 
	{
		return organizationName;
	}
	public void setOrganizationName(String organizationName) 
	{
		this.organizationName = organizationName;
	}
	public String getFrequency()
	{
		return frequency;
	}
	public void setFrequency(String frequency) 
	{
		this.frequency = frequency;
	}
	public String getOrganizationCategory()
	{
		return organizationCategory;
	}
	public void setOrganizationCategory(String organizationCategory) 
	{
		this.organizationCategory = organizationCategory;
	}
	public static long getSerialversionuid() 
	{
		return serialVersionUID;
	}
	
	@Override
	public String toString() 
	{
		return "UserProfileAssociatedOrganizationsVo [organizationId=" + organizationId + ", profileId=" + profileId
				+ ", organizationName=" + organizationName + ", frequency=" + frequency + ", organizationCategory="
				+ organizationCategory + "]";
	}
	
}
