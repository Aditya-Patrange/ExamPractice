package com.cdac.sudarshan.discover.common;

import java.io.Serializable;

public class UserProfileAssociatedLocationsVo implements Serializable
{
	private static final long serialVersionUID = 1L;
	
	private int locationId;
	private int profileId;
	private String locationName;
	private String frequency;
	private String sentimentOfLocation;
	
	public int getLocationId() 
	{
		return locationId;
	}
	public void setLocationId(int locationId) 
	{
		this.locationId = locationId;
	}
	public int getProfileId() 
	{
		return profileId;
	}
	public void setProfileId(int profileId) 
	{
		this.profileId = profileId;
	}
	public String getLocationName() 
	{
		return locationName;
	}
	public void setLocationName(String locationName) 
	{
		this.locationName = locationName;
	}
	public String getFrequency() 
	{
		return frequency;
	}
	public void setFrequency(String frequency) 
	{
		this.frequency = frequency;
	}
	public String getSentimentOfLocation() 
	{
		return sentimentOfLocation;
	}
	public void setSentimentOfLocation(String sentimentOfLocation) 
	{
		this.sentimentOfLocation = sentimentOfLocation;
	}
	public static long getSerialversionuid() 
	{
		return serialVersionUID;
	}
	
	@Override
	public String toString() 
	{
		return "UserProfileAssociatedLocationsVo [locationId=" + locationId + ", profileId=" + profileId
				+ ", locationName=" + locationName + ", frequency=" + frequency + ", sentimentOfLocation="
				+ sentimentOfLocation + "]";
	}
	
}
