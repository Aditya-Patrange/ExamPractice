package com.cdac.sudarshan.watchlist.model;
import java.time.Instant;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import com.cdac.sudarshan.authentication.model.User;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Entity
@ApiModel(value = "Watchlist class")
public class Watchlist extends BaseEntity {

	private String watchlistName;
	private String attributes;
//	@ManyToMany
//	@JoinTable(joinColumns = @JoinColumn(name = "watchlist_id"), inverseJoinColumns = @JoinColumn(name = "source_id"))
//	private List<Source> sourcesList = new ArrayList<>();
	@OneToOne
	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
	private Source source;
	@OneToOne
	private Frequency frequency;
	private Instant createdOn;
	private Instant fromDate;
	private Instant toDate;
	private String priority;
	private String remarks;
	private boolean isEnabled;
//	private String collectionId;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "user_Id")
	private User user;

}
