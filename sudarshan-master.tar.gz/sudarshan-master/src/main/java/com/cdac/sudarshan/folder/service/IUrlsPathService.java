package com.cdac.sudarshan.folder.service;

import com.cdac.sudarshan.folder.dto.RequestDto;
import com.cdac.sudarshan.folder.dto.UrlResponseDto;
import com.cdac.sudarshan.folder.model.UrlsPath;
import com.cdac.sudarshan.utils.Data;
import org.springframework.http.ResponseEntity;

import java.io.IOException;
import java.util.List;

public interface IUrlsPathService {

	List<UrlResponseDto> addUrls(String path, List<Data> urlAndSource) throws IOException;
	List<UrlsPath> getBySubfolderId(Long subFolderId);

	List<UrlResponseDto> addProfileUrls(String path,List<Data> urlAndSource);

	List<UrlResponseDto> addMediaUrls(String path, List<Data> urlAndSource);

	ResponseEntity<?> deleteUrlsData(RequestDto requestDto);

}
