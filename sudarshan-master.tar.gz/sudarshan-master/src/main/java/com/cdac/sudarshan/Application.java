package com.cdac.sudarshan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;

import javax.net.ssl.SSLContext;

import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLContextBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.client.ClientHttpRequest;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.client.RequestCallback;
import org.springframework.web.client.ResponseExtractor;
import org.springframework.web.client.RestTemplate;

import com.cdac.sudarshan.authentication.repository.UserRepository;
import com.cdac.sudarshan.discover.controller.SpringSessionClientHttpRequestInterceptor;

import io.searchbox.client.JestClient;
import io.searchbox.client.JestClientFactory;
import io.searchbox.client.config.HttpClientConfig;

import org.springframework.core.io.Resource;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;


@SpringBootApplication
@EnableSwagger2
@EnableScheduling
public class Application {
	@Autowired
	private RestTemplate template;
	
	@Value("${elasticSearch2InnefuUrl}")
	private String elasticSearch2InnefuUrl;


	public static final Logger log = LoggerFactory.getLogger("app");

	public static void main(String[] args) throws IOException {
	//	System.setProperty("javax.net.ssl.trustStore", "/home/ns25/Desktop/openssl/apache.crt");

		SpringApplication.run(Application.class, args);




	}

	

	@Bean
	public Docket api() {
		return new Docket(DocumentationType.SWAGGER_2).select()
				.apis(RequestHandlerSelectors.basePackage("com.cdac.sudarshan")).paths(PathSelectors.any()).build()
				.apiInfo(application());
	}

	@Bean
	public ModelMapper modelMapper(){
		return new ModelMapper();
	}


	
	@Bean
	public RestTemplate getRestTemplate() {
	    return new RestTemplate();
//	    ClientHttpRequestInterceptor interceptor= new SpringSessionClientHttpRequestInterceptor();
//	    List<ClientHttpRequestInterceptor> interceptors = new ArrayList<ClientHttpRequestInterceptor>();
//	    interceptors.add(interceptor);
//	    rest.setInterceptors(interceptors);
//	    return rest;
//		return new RestTemplate();
	}
	
	@Bean
	public HttpHeaders getHttpHeadersAfterLogin() {
		String user = "admin";
		String pw = "123456";
		ClientHttpResponse response = template.execute("http://192.168.181.41:8080/innsight/login_validateCredential",
				HttpMethod.POST, new RequestCallback() {
					public void doWithRequest(ClientHttpRequest request) throws IOException {
						request.getBody().write(("userName=" + user + "&password=" + pw).getBytes());
					}
				}, new ResponseExtractor<ClientHttpResponse>() {

					@Override
					public ClientHttpResponse extractData(ClientHttpResponse response) throws IOException {
						return response;
					}
				});

		HttpHeaders headers = new HttpHeaders();
		List<String> cookies = response.getHeaders().get("Set-Cookie");
		headers.set("Cookie", cookies.get(0));
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		return headers;
	}


	private ApiInfo application() {
		return new ApiInfoBuilder().title("Sudarshan Backend")
				.description("\" Swagger configuration for application \"").version("1.1.0").license("Apache 2.0")
				.licenseUrl(null).contact(new Contact("Sudarshan", "http:192.168.181.87", "a@cdac.in")).build();
	}
	
//	@Value("${trust-store}")
//	private Resource trustStore;
//	
//	@Bean
//	public RestTemplate restTemplateWithTrustStore(RestTemplateBuilder builder) throws IOException, CertificateException, NoSuchAlgorithmException, KeyStoreException, KeyManagementException {  
//	    SSLContext sslContext = new SSLContextBuilder()
//	    	.loadTrustMaterial(trustStore.getURL())	
//	        .build();
//	    SSLConnectionSocketFactory socketFactory = new SSLConnectionSocketFactory(sslContext);
//
//	    CloseableHttpClient httpClient = HttpClients.custom()
//	        .setSSLSocketFactory(socketFactory)
//	        .build();
// 
//	    return builder
//	        .requestFactory(() -> new HttpComponentsClientHttpRequestFactory(httpClient))
//	        .build();
//	}

//	@Bean
//	public RestTemplate restTemplate() {
//		return new RestTemplate();
//	}
	
	@Bean
    public JestClient jestClient(){
		JestClientFactory factory = new JestClientFactory();
		factory.setHttpClientConfig(new HttpClientConfig
		                        .Builder("http://"+ elasticSearch2InnefuUrl +":9200")
		                        .multiThreaded(true)
		                        .connTimeout(1000*60*10)
		                        .readTimeout(1000*60*10)
		                        .defaultMaxTotalConnectionPerRoute(100)
		                        .maxTotalConnection(200)
		                        .build());
		 JestClient client = factory.getObject();
        return client;
    }
}
