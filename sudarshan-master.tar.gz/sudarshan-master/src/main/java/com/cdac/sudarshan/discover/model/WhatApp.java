package com.cdac.sudarshan.discover.model;

import java.io.Serializable;

public class WhatApp implements Serializable
{
	private static final long serialVersionUID = 1L;
	private String deviceId;
    private String deviceMobileNo;
    private WhatApp_Group group;
    private WhatApp_Member member;

    public String getDeviceId() 
    {
		return deviceId;
	}
	public void setDeviceId(String deviceId)
	{
		this.deviceId = deviceId;
	}
	public String getDeviceMobileNo() 
	{
		return deviceMobileNo;
	}
	public void setDeviceMobileNo(String deviceMobileNo)
	{
		this.deviceMobileNo = deviceMobileNo;
	}	
	public WhatApp_Group getGroup() 
	{
		return group;
	}
	public void setGroup(WhatApp_Group group)
	{
		this.group = group;
	}
	public WhatApp_Member getMember() 
	{
		return member;
	}
	public void setMember(WhatApp_Member member) 
	{
		this.member = member;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "WhatApp [deviceId=" + deviceId + ", deviceMobileNo=" + deviceMobileNo + ", group=" + group + ", member="
				+ member + "]";
	}
}
