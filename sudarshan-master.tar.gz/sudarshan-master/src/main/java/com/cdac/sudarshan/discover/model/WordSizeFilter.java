package com.cdac.sudarshan.discover.model;

import static org.apache.commons.lang3.StringUtils.isNotBlank;

/**
 * Created by kenny
 */
public class WordSizeFilter  {

    private final int minLength;

    private final int maxLength;

    public WordSizeFilter(final int minLength, final int maxLength) {
        this.minLength = minLength;
        this.maxLength = maxLength;
    }

    public boolean apply(String word) {
        return isNotBlank(word)
                && word.length() >= minLength
                && word.length() < maxLength;
    }

}
