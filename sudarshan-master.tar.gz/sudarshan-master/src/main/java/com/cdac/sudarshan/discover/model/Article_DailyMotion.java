package com.cdac.sudarshan.discover.model;

import java.io.Serializable;

public class Article_DailyMotion implements Serializable 
{
	private static final long serialVersionUID = 1L;
	private String dmThumblnailUrl;
	private int dmViewCount;
	private int dmCommentCount;
	private int viewLastDay;
	private int viewsLastHour;
	private int viewsLastMonth;
	private int viewsLastWeek;
	private Article_DailyMotion_User dmUser;
	
	public int getDmViewCount() {
		return dmViewCount;
	}
	public void setDmViewCount(int dmViewCount) {
		this.dmViewCount = dmViewCount;
	}
	public int getDmCommentCount() {
		return dmCommentCount;
	}
	public void setDmCommentCount(int dmCommentCount) {
		this.dmCommentCount = dmCommentCount;
	}
	public String getDmThumblnailUrl() {
		return dmThumblnailUrl;
	}
	public void setDmThumblnailUrl(String dmThumblnailUrl) {
		this.dmThumblnailUrl = dmThumblnailUrl;
	}
	
	public Article_DailyMotion_User getDmUser() {
		return dmUser;
	}
	public void setDmUser(Article_DailyMotion_User dmUser) {
		this.dmUser = dmUser;
	}
	public int getViewLastDay() {
		return viewLastDay;
	}
	public void setViewLastDay(int viewLastDay) {
		this.viewLastDay = viewLastDay;
	}
	public int getViewsLastHour() {
		return viewsLastHour;
	}
	public void setViewsLastHour(int viewsLastHour) {
		this.viewsLastHour = viewsLastHour;
	}
	public int getViewsLastMonth() {
		return viewsLastMonth;
	}
	public void setViewsLastMonth(int viewsLastMonth) {
		this.viewsLastMonth = viewsLastMonth;
	}
	public int getViewsLastWeek() {
		return viewsLastWeek;
	}
	public void setViewsLastWeek(int viewsLastWeek) {
		this.viewsLastWeek = viewsLastWeek;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "Article_DailyMotion [dmThumblnailUrl=" + dmThumblnailUrl + ", dmViewCount=" + dmViewCount
				+ ", dmCommentCount=" + dmCommentCount + ", viewLastDay=" + viewLastDay + ", viewsLastHour="
				+ viewsLastHour + ", viewsLastMonth=" + viewsLastMonth + ", viewsLastWeek=" + viewsLastWeek
				+ ", dmUser=" + dmUser + "]";
	}
}
