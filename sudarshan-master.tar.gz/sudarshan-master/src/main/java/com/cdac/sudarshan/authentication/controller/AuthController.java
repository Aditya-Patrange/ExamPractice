package com.cdac.sudarshan.authentication.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.cdac.sudarshan.authentication.service.IAuthService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.*;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cdac.sudarshan.AppUserAuthentication;
import com.cdac.sudarshan.AuthenticationFlow;
import com.cdac.sudarshan.JwtTokenUtil;
import com.cdac.sudarshan.authentication.model.User;
import com.cdac.sudarshan.authentication.service.IUserService;
import com.cdac.sudarshan.code.service.ICodeService;

import lombok.extern.slf4j.Slf4j;

import org.springframework.web.client.RestTemplate;

/**
 * @author ns37
 */
@RestController
@CrossOrigin("*")
@Slf4j
public class AuthController {

    Logger _LOGGER_ = LoggerFactory.getLogger(AuthController.class);

    private final static String USER_AUTHENTICATION_OBJECT = "USER_AUTHENTICATION_OBJECT";


    private static String uiCaptcha;

    public static User mainUser;


    @Autowired
    private IAuthService authService;

    @Autowired
    private IUserService userService;

    @Autowired
    private ICodeService codeService;

    @Autowired
    private JwtTokenUtil jwtUtil;

    @Autowired
    private RestTemplate template;


    /**
     * @param request
     * @return
     */
    @GetMapping("/authenticate")
    public AuthenticationFlow authenticate(HttpServletRequest request) {

        //System.out.println("In authenticate");
        _LOGGER_.info("In authenticate of " + getClass().getName());

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth instanceof AppUserAuthentication) {
            return AuthenticationFlow.AUTHENTICATED;
        }

        HttpSession httpSession = request.getSession(false);
        if (httpSession != null) {
            httpSession.invalidate();
        }

        _LOGGER_.info("Authenticate Method of " + getClass().getName() + "	Completed");
        return AuthenticationFlow.NOT_AUTHENTICATED;

    }


    /**
     * @return
     */
/*    @GetMapping("/getcaptcha")
    public ResponseEntity<?> getCaptcha() {
        return authService.getCaptcha();
    }*/

    /**
     * @param user
     * @param httpSession
     * @return
     */


    /**
     * @param user
     * @return
     */
    @PostMapping("/signin")
    public ResponseEntity<?> login(@RequestBody Map<String, String> user) {

        ResponseEntity<?> signInResponse = authService.signIn(user);

        return signInResponse;

    }

    /**
     * @param secretCode
     * @return
     */
    @SuppressWarnings("unused")
    @PostMapping("/verify-totp")
    public ResponseEntity<?> verifyOTP(@RequestBody Map<String, String> secretCode) {
        ResponseEntity<?> verifyOTPResponse = authService.verifyOTP(secretCode);
        return verifyOTPResponse;

    }

    /**
     * @param user
     * @return
     */
    @PostMapping("/codes")
    public ResponseEntity<?> getBackUpCodesOfLoginUser(@RequestBody Map<String, String> user) {

        ResponseEntity<?> codeResponse = authService.getCodesOfUser(user.get("username"));

        return codeResponse;

    }

    /**
     * @param code1
     * @param code2
     * @param code3
     * @param httpSession
     * @return
     */
//    @PostMapping("/verify-totp-additional-security")
//    public ResponseEntity<AuthenticationFlow> verifyTotpAdditionalSecurity(@RequestParam String code1,
//                                                                           @RequestParam String code2, @RequestParam String code3, HttpSession httpSession) {
//
//        System.out.println("In verify-totp-additional-security");
//
//        AppUserAuthentication userAuthentication = (AppUserAuthentication) httpSession
//                .getAttribute(USER_AUTHENTICATION_OBJECT);
//        if (userAuthentication == null) {
//            return ResponseEntity.ok().body(AuthenticationFlow.NOT_AUTHENTICATED);
//        }
//        if (code1.equals(code2) || code1.equals(code3) || code2.equals(code3)) {
//            return ResponseEntity.ok().body(AuthenticationFlow.NOT_AUTHENTICATED);
//        }
//        List<String> backCode = SignupController.codes;
//
//        String secret = ((AppUserDetail) userAuthentication.getPrincipal()).getSecret();
//        if (isNotBlank(secret) && isNotBlank(code1) && isNotBlank(code2) && isNotBlank(code3)) {
//            CustomTotp totp = new CustomTotp(secret);
//            List<Integer> securityCode = Arrays.asList(Integer.parseInt(code1), Integer.parseInt(code2),
//                    Integer.parseInt(code3));
//
//            if (backCode.containsAll(securityCode)) {
//                System.out.println("AUTHENTICATED");
//                return ResponseEntity.ok().body(AuthenticationFlow.AUTHENTICATED);
//            } else {
//                System.out.println("NOT AUTHENTICATED");
//            }
//
//            // check 25 hours into the past and future.
//            long noOf30SecondsIntervals = TimeUnit.HOURS.toSeconds(25) / 30;
//            CustomTotp.Result result = totp.verify(List.of(code1, code2, code3), noOf30SecondsIntervals,
//                    noOf30SecondsIntervals);
//            if (result.isValid()) {
//                if (result.getShift() > 2 || result.getShift() < -2) {
//                    httpSession.setAttribute("totp-shift", result.getShift());
//                }
//
//                AppUserDetail detail = (AppUserDetail) userAuthentication.getPrincipal();
//                clearAdditionalSecurityFlag(detail.getAppUserId());
//                httpSession.removeAttribute(USER_AUTHENTICATION_OBJECT);
//
//                SecurityContextHolder.getContext().setAuthentication(userAuthentication);
//                return ResponseEntity.ok().body(AuthenticationFlow.AUTHENTICATED);
//            }
//        }
//
//        return ResponseEntity.ok().body(AuthenticationFlow.NOT_AUTHENTICATED);
//    }

//    @GetMapping("/totp-shift")
//    public String getTotpShift(HttpSession httpSession) {
//        Long shift = (Long) httpSession.getAttribute("totp-shift");
//        if (shift == null) {
//            return null;
//        }
//        httpSession.removeAttribute("totp-shift");
//
//        StringBuilder out = new StringBuilder();
//        long total30Seconds = (int) Math.abs(shift);
//        long hours = total30Seconds / 120;
//        total30Seconds = total30Seconds % 120;
//        long minutes = total30Seconds / 2;
//        boolean seconds = total30Seconds % 2 != 0;
//
//        if (hours == 1) {
//            out.append("1 hour ");
//        } else if (hours > 1) {
//            out.append(hours).append(" hours ");
//        }
//
//        if (minutes == 1) {
//            out.append("1 minute ");
//        } else if (minutes > 1) {
//            out.append(minutes).append(" minutes ");
//        }
//
//        if (seconds) {
//            out.append("30 seconds ");
//        }
//
//        return out.append(shift < 0 ? "behind" : "ahead").toString();
//    }



//    private Boolean isUserInAdditionalSecurityMode(long appUserId) {
//        return userService.getAdditionalSecurity(appUserId);
//    }
//
//    private void setAdditionalSecurityFlag(Long appUserId) {
//        userService.setAdditionalSecurity(appUserId);
//    }
//
//    private void clearAdditionalSecurityFlag(Long appUserId) {
//        userService.updateAdditionalSecurity(appUserId);
//    }

}
