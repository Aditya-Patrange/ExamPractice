package com.cdac.sudarshan.mysearches.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.cdac.sudarshan.authentication.model.User;
import com.cdac.sudarshan.authentication.service.IUserService;
import com.cdac.sudarshan.exception.ResourceNotFoundException;
import com.cdac.sudarshan.mysearches.dto.MySearchesDto;
import com.cdac.sudarshan.mysearches.dto.MySearchesProjection;
import com.cdac.sudarshan.mysearches.model.MySearches;
import com.cdac.sudarshan.mysearches.repository.MySearchesRepository;

@Service
public class MySearchesService<E> implements IMySearchesService{
	@Autowired
	MySearchesRepository searchRepository;
	@Autowired
	IUserService userService;

	// getting all search records
	public HashMap<String,Object> findByUserId(MySearchesDto searchDto) {
		
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

		if(authentication.getName() == null){
			throw new ResourceNotFoundException("Please Login first To Get MySearches Records");
		}

		User loggedInUser = userService.getUserByUserName(authentication.getName());
		if (loggedInUser != null) {
			Pageable pageable=PageRequest.of(searchDto.getPageNo(),searchDto.getLimit());
			// to return entries with specific userId
			List<MySearches> allSearchList = searchRepository.findByUserIdAndDeleteFlag(loggedInUser.getId(),true,pageable);
			Long count = searchRepository.sizeCount(loggedInUser.getId());
				HashMap<String,Object> map = new HashMap<>();
				map.put("data", allSearchList);
				map.put("size", count);
			
			return map;
		}
		return null;
	}

	// to save a specific record by using save method of CrudRepository
	public void saveOrUpdate(MySearches search) {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

		if(authentication.getName() == null){
			throw new ResourceNotFoundException("Please Login first to Insert MySearches Records");
		}

		User loggedInUser = userService.getUserByUserName(authentication.getName());
		
		search.setUserId(loggedInUser.getId());
		searchRepository.save(search);
	}

	// deleting specific record by using the method deleteById() of CrudRepository
	public void delete(List<Integer> ids) {
		for (int id : ids) {
			MySearches user = searchRepository.findById(id).get();
			// set status false
			user.setDeleteFlag(false);
			searchRepository.save(user);
		}
	}

	public MySearches getSearchDataById(Integer id) {
		  Optional<MySearches> mySearch = searchRepository.findById(id);
		return mySearch.get();
	}
	
	public HashMap<String, Object>getMostSearchedHistory(){
		List<MySearchesProjection> profile = getMostSearchedProfile();
		List<MySearchesProjection> keyword = getMostSearchedKeyword();
		List<MySearchesProjection> location= getMostSearchedLocation();
		List<MySearchesProjection> federated = getMostSearchedFederated();
		List<MySearchesProjection> eNews = getMostSearchedENews();
		HashMap<String, Object> map = new HashMap<>();
		map.put("Profiles", profile);
		map.put("SocialMediaKeywords", keyword);
		map.put("location", location);
		map.put("Federated", federated);
		map.put("ENews", eNews);
		return map;
	}
	
	private List<MySearchesProjection> getMostSearchedProfile(){
	List<MySearchesProjection> list = searchRepository.mostSearchedKeyword("Profile Search");
	return  list;
	}
	
	private List<MySearchesProjection> getMostSearchedKeyword(){
		List<MySearchesProjection> list = searchRepository.mostSearchedKeyword("Social Media Search");
		return  list;
	}

	private List<MySearchesProjection> getMostSearchedLocation(){
		List<MySearchesProjection> list = searchRepository.mostSearchedKeyword("Track By Location");
	
		return list;
	}
	private List<MySearchesProjection>getMostSearchedFederated(){
		List<MySearchesProjection> list = searchRepository.mostSearchedKeyword("Federated Search");
		return list;
	}
	private List<MySearchesProjection>getMostSearchedENews(){
		List<MySearchesProjection> list = searchRepository.mostSearchedKeyword("E-News");
		return list;
	}
}
