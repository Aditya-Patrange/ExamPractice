package com.cdac.sudarshan.folder.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@ToString
public class RootFolderDto {

	private Long rootFolderId;

	private String RootFolderName;
	
	private List<SubFolderPathDto> subFolderPathDtos = new ArrayList<SubFolderPathDto>();
	
	

}
