package com.cdac.sudarshan.discover.common;

import java.io.Serializable;

public class UserProfileAliasVo implements Serializable
{
	private static final long serialVersionUID = 1L;
	
	private int aliasId;
	private int profileId;
	private String alias;
	
	public int getAliasId() 
	{
		return aliasId;
	}
	public void setAliasId(int aliasId) 
	{
		this.aliasId = aliasId;
	}
	public int getProfileId() 
	{
		return profileId;
	}
	public void setProfileId(int profileId)
	{
		this.profileId = profileId;
	}
	public String getAlias() 
	{
		return alias;
	}
	public void setAlias(String alias) 
	{
		this.alias = alias;
	}
	public static long getSerialversionuid() 
	{
		return serialVersionUID;
	}
	
	@Override
	public String toString() 
	{
		return "UserProfileAliasVo [aliasId=" + aliasId + ", profileId=" + profileId + ", alias=" + alias + "]";
	}
	
}
