package com.cdac.sudarshan.watchlist.controller;

import java.io.IOException;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cdac.sudarshan.discover.dto.BaseEntityDto;
import com.cdac.sudarshan.watchlist.dto.WatchlistDto;
import com.cdac.sudarshan.watchlist.dto.Watchlist_CollectionDto;
import com.cdac.sudarshan.watchlist.service.IWatchlistService;

@RestController
@RequestMapping("/watchlist")
@CrossOrigin("*")
public class WatchlistController {
	@Autowired
	private IWatchlistService watchService;

	@PostMapping("/addWatchlist")
	public ResponseEntity<?> addWatchlist(@RequestBody @Valid WatchlistDto watchlistDto) {
		return new ResponseEntity<>(watchService.saveWatchlist(watchlistDto), HttpStatus.OK);
	}

	@GetMapping("/getWatchlists")
	public ResponseEntity<?> getAllWatchlist() {
		return new ResponseEntity<>(watchService.getAllWatchlist(), HttpStatus.OK);
	}

	@GetMapping("/getSources")
	public ResponseEntity<?> getSources() {
		return new ResponseEntity<>(watchService.getSources(), HttpStatus.OK);
	}

	@DeleteMapping("/deleteWatchlistById/{id}")
	public ResponseEntity<?> deleteWatchlist(@PathVariable("id") int id) {
		return new ResponseEntity<>(watchService.deleteWatchlistById(id), HttpStatus.OK);
	}

	@GetMapping("/getFrequencyList")
	public ResponseEntity<?> getFrequencyList() {
		return new ResponseEntity<>(watchService.getFrequencyList(), HttpStatus.OK);
	}

	@GetMapping("/updateWatchlistStatus")
	public ResponseEntity<?> updateWatchlistStatus() throws IOException {
		return new ResponseEntity<>(watchService.updateWatchlistStatus(), HttpStatus.OK);
	}

	@PutMapping("/updateWatchlistbyId/{id}")
	public ResponseEntity<?> updateWatchlistbyId(@PathVariable Integer id,
			@RequestBody @Valid WatchlistDto watchlistDto) {
		return new ResponseEntity<>(watchService.updateWatchlist(id, watchlistDto), HttpStatus.OK);
	}

	@GetMapping("/deActivateWatchlistByDate")
	public ResponseEntity<?> deActivateWatchlistByDate() throws IOException {
		return new ResponseEntity<>(watchService.deActivateWatchlistByDate(), HttpStatus.OK);
	}
	
	@PostMapping("/getWatchlistByUser")
	public ResponseEntity<?> getWatchlistByUser(@RequestBody BaseEntityDto userId){
		return new ResponseEntity<>( watchService.getWatchlistsByUserId(Integer.toUnsignedLong(  userId.getId())), HttpStatus.OK);
	}

//	@GetMapping("/updateCollectionById")
//	public ResponseEntity<?> updateCollectionById() throws IOException {
//		return new ResponseEntity<>(watchService.updateCollectionById(), HttpStatus.OK);
//	}

	@PostMapping("/addWatchlist_Collection")
	public ResponseEntity<?> addWatchlist_Collection(@RequestBody Watchlist_CollectionDto WCDto){
		return new ResponseEntity<>( watchService.addWatchlist_Collection(WCDto), HttpStatus.OK);
	}
	
}
