package com.cdac.sudarshan.watchlist.dto;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@RequiredArgsConstructor
public class BaseEntityDto {
	private int id;

}
