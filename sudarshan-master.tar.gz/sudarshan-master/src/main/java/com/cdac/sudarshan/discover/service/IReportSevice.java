package com.cdac.sudarshan.discover.service;

import java.util.HashMap;

import org.springframework.http.ResponseEntity;

public interface IReportSevice {
	
	public ResponseEntity<?> trendingOrganization(HashMap<String, Object> data);
	
	public ResponseEntity<?> getTweetsRpt(HashMap<String, Object> data);
	
	public ResponseEntity<?> getUserWordCloud(HashMap<String, Object> data);
	
	public ResponseEntity<?> getThemeWordCloud(HashMap<String, Object> data);
}
