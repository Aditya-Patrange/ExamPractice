package com.cdac.sudarshan.discover.common;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class HttpUtil 
{
	public static String sendPostRequestForSynchronizeCentralAvatarDetails(String url, String urlParameters) throws Exception 
	{
		String result="";
		StringBuffer response = null;
		int responseCode=-1;
		InputStream is = null;
		InputStreamReader isr = null;
		BufferedReader br = null;
		String inputLine;
		
		try 
		{
			URL obj = new URL(url);
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();
			//add request header
			con.setRequestMethod("POST");
			con.setRequestProperty("User-Agent", "Mozilla/5.0");
			//con.setRequestProperty("Authorization", "Bearer "+authStr);			
			con.setRequestProperty("Content-Type", "application/json;charset=UTF-8");
			
			// Send post request
			con.setDoOutput(true);
			DataOutputStream wr = new DataOutputStream(con.getOutputStream());
			wr.write(urlParameters.getBytes(StandardCharsets.UTF_8));			
			wr.flush();
			wr.close();

			responseCode = con.getResponseCode();

			is = con.getInputStream();
			isr = new InputStreamReader(is, StandardCharsets.UTF_8);
			br = new BufferedReader(isr);
			
			response = new StringBuffer();			
			while((inputLine = br.readLine()) != null) 
			{
				response.append(inputLine);
			}
			
			if(response != null) 
			{
				result = response.toString();
			}

		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
			throw new Exception("<Exception>:Response code: "+responseCode);
		}
		finally
		{
			try
			{
				if(br!=null) 
					br.close();
			} 
			catch(IOException ex) 
			{
				ex.printStackTrace();
			}
			
			try 
			{
				if(isr!=null) 
					isr.close();
			}
			catch(IOException ex) 
			{
				ex.printStackTrace();
			}
			
			try 
			{
				if(is!=null) 
					is.close();
			}
			catch(IOException ex) 
			{
				ex.printStackTrace();
			}
		}
		return result;
	}
}