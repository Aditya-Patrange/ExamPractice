package com.cdac.sudarshan.discover.common;

import java.util.ArrayList;
import java.util.List;

import com.cdac.sudarshan.discover.model.TweeterActionVo;
import com.cdac.sudarshan.discover.model.TwitterVo;

//import com.innefu.innsight.dashboard.daoVo.DashInputVo;
//import com.innefu.innsight.dashboard.daoVo.DashOutputVo;
//import com.innefu.innsight.dashboard.daoVo.Dashboard;
//import com.innefu.innsight.dashboard.daoVo.DashboardWidgetVo;
//import com.innefu.innsight.dashboard.daoVo.Widget;
//import com.innefu.innsight.facebook.vo.FbOutputVo;
//import com.innefu.innsight.twitter.vo.TweeterActionVo;
//import com.innefu.innsight.twitter.vo.TwitterVo;


public interface DashBoardManager {

	/*********************DashBoard**************************/
	public ArrayList<TwitterVo> dashEntityCount(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> dashTimeLine(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> dashTwTrends(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> dashGeoMap(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> dashActiveMedia(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> dashActiveEntity(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> dashODSImage(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> dashOCRImage(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> dashArticles(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> dashActiveUser(TweeterActionVo tweeterActionVo);
	
	public List<Dashboard> getDashboardByUserId(String userId);
	public boolean removeDashboardById(Dashboard dashboard);
	public boolean createDashboard(Dashboard dashboard);
	public boolean updateDashboardById(Dashboard dashboard);
	public ArrayList<Dashboard> getAllDashboard(Dashboard dashboard);
	
	//***********Widgets ***********************8
	boolean updateWidget(Widget widget);
	public ArrayList<Widget> getAllWidget(Widget widget);
    public void addWidgetsToDashboard(Dashboard dashboard);
    public void removeWidgetsFromDashboard(Dashboard dashboard);
	public List<DashboardWidgetVo> getWidgetsByDashboardId(Long dashboardId);
	public int saveDashboard(List<DashboardWidgetVo> list);
	public List<DashboardWidgetVo> getAllDashboard();
    public void markCurrentDashboard(String dashboardId,String caseId);
	public ArrayList<Dashboard> getUserCurrentDashboard(String caseId);

	
}
