package com.cdac.sudarshan.theme.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.cdac.sudarshan.authentication.model.User;
import com.cdac.sudarshan.authentication.service.IUserService;
import com.cdac.sudarshan.exception.DataNotFoundException;
import com.cdac.sudarshan.exception.PathNotFoundException;
import com.cdac.sudarshan.exception.ResourceNotFoundException;
import com.cdac.sudarshan.theme.model.Keyword;
import com.cdac.sudarshan.theme.model.SubTheme;
import com.cdac.sudarshan.theme.model.Theme;
import com.cdac.sudarshan.theme.repository.IKeywordRepository;
import com.cdac.sudarshan.theme.repository.ISubThemeRepository;
import com.cdac.sudarshan.theme.repository.IThemeRepository;

@Service
public class KeywordServiceImpl implements IKeywordService{

    @Autowired
    private IUserService userService;

    @Autowired
    private IThemeRepository themeRepository;

    @Autowired
    private IKeywordRepository keywordRepository;

    @Autowired
    private ISubThemeRepository subThemeRepository;

    @Override
    public List<Keyword> saveKeywords(Object keywords, String path) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        User loggedInUser = userService.getUserByUserName(authentication.getName());

        if (loggedInUser == null) {
            throw new ResourceNotFoundException("Please Login first For adding add url");
        }

        List<String> themeKeywords = (List<String>) keywords;

        if (path.isEmpty() || !path.endsWith("/")) {
            throw new PathNotFoundException("Entered path is empty or invalid");
        }

        String pathName = path.replace("/", "");

        String[] themePaths = path.split("/");
        List<String> subThemeNames = new ArrayList<>();
        for (String t : themePaths) {
            if (!t.equals("")) {
                subThemeNames.add(t);
            }
        }

        List<Keyword> savedKeywordList = new ArrayList<>();

        List<Theme> rootTheme = themeRepository.findByThemePath(pathName);
        if (rootTheme.isEmpty()) {
            List<Theme> Themes = themeRepository.findByThemePath(subThemeNames.get(0));
            if (Themes.isEmpty())
                throw new ResourceNotFoundException(subThemeNames.get(0) + " is Not present, Please add Theme first");
        }

        List<Keyword> keywordList = keywordRepository.findAll();
        List<String> dbKeywordList = new ArrayList<>();
        for (int j = 0; j < keywordList.size(); j++) {
            dbKeywordList.add(keywordList.get(j).getKeyword());
        }

        // To add keywords in Theme
        if (!rootTheme.isEmpty()) {
            for (int i = 0; i < themeKeywords.size(); i++) {
                if (dbKeywordList.contains(themeKeywords.get(i))) {
                    continue;
                } else {
                    Keyword keyword = new Keyword();
                    keyword.setKeyword(themeKeywords.get(i));
                    keyword.setThemeId(rootTheme.get(0).getId());
                    Keyword saveKeyword = keywordRepository.save(keyword);
                    savedKeywordList.add(saveKeyword);
                }
            }
  //          return savedKeywordList;
        } else {
            List<SubTheme> subThemeList = subThemeRepository.fetchBySubThemePath(path);

            if (subThemeList.isEmpty()) {
                throw new ResourceNotFoundException(path + " is Not present, Please add subTheme first");
            }

            if (!subThemeList.isEmpty()) {
                for (int i = 0; i < themeKeywords.size(); i++) {
                    if (dbKeywordList.contains(themeKeywords.get(i))) {
                        continue;
                    } else {
                        Keyword keyword = new Keyword();
                        keyword.setKeyword(themeKeywords.get(i));
                        keyword.setSubTheme(subThemeList.get(0));
                        Keyword saveKeyword = keywordRepository.save(keyword);
                        savedKeywordList.add(saveKeyword);
                    }
                }
             //   return savedKeywordList;
            }
        }
        return savedKeywordList;
    }

    @Override
    public List<Keyword> getKeywords(String path) {

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        User loggedInUser = userService.getUserByUserName(authentication.getName());

        if (loggedInUser == null) {
            throw new ResourceNotFoundException("Please Login first For adding add url");
        }

        if (path.isEmpty() ||  !path.startsWith("/") || !path.endsWith("/")) {
            throw new PathNotFoundException("Please enter valid path or path is empty");
        }

        String rootThemePathName = path.replace("/", "");

        String[] themePaths = path.split("/");
        List<String> subThemeNames = new ArrayList<>();
        for (String t : themePaths) {
            if (!t.equals("")) {
                subThemeNames.add(t);
            }
        }

        List<Theme> rootThemeList = themeRepository.findByThemePath(rootThemePathName);

        if (rootThemeList.isEmpty()) {
            List<Theme> Themes = themeRepository.findByThemePath(subThemeNames.get(0));
            if (Themes.isEmpty())
                throw new PathNotFoundException(subThemeNames.get(0) + " Theme is not present");
        }

        List<Keyword> keywordList = null;

        if (!rootThemeList.isEmpty()) {
            keywordList = keywordRepository.findByRootThemeId(rootThemeList.get(0).getId());
        }else{
            List<SubTheme> subThemeList = subThemeRepository.fetchBySubThemePath(path);

            if (subThemeList.isEmpty()) {
                throw new PathNotFoundException(path + " Sub-theme is not present ");
            }

            keywordList = keywordRepository.findBySubTheme(subThemeList.get(0));
        }
//        if(keywordList.isEmpty()){
//            throw new DataNotFoundException("Keywords not Present in given theme");
//        	
//        }
        return keywordList;
    }
}
