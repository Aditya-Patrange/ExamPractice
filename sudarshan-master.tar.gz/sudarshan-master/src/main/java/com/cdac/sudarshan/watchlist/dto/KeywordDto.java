package com.cdac.sudarshan.watchlist.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class KeywordDto {

	List<String> keyword;
	
	List<String> sources;
}
