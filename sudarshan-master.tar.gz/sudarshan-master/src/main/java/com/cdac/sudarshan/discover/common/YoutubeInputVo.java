package com.cdac.sudarshan.discover.common;

import java.io.Serializable;
import java.util.ArrayList;

public class YoutubeInputVo implements Serializable 
{
	private static final long serialVersionUID = 1L;
	private	String rowNum;
	private String channelId,channelName,caseId,entityId,videoId;
	private	String dateFrom;
	private	String dateTo;
	private	String dateFromGr;
	private	String dateToGr;
	private	String advFilter;
	private	String sortFilter;
	private String isDashBord;
	private String sentimentFilter;
	private String priorityFilter,priority;
	private String isMarked;
	private String keywordFilter2;
	private String keywordFilter,type;
	private String isRpt,id,userSortFilter,vidoeSortFilter;
    private String userFilter,userNotFilter,hashtagFilter,hashtagNotFilter,noVideo,noChannel,noHashtag;
    private  ArrayList<String> entityIds;
    private String sourceType;
    
	public String getSourceType() {
		return sourceType;
	}
	public void setSourceType(String sourceType) {
		this.sourceType = sourceType;
	}
	public ArrayList<String> getEntityIds() {
		return entityIds;
	}
	public void setEntityIds(ArrayList<String> entityIds) {
		this.entityIds = entityIds;
	}
	public String getNoVideo() {
		return noVideo;
	}
	public void setNoVideo(String noVideo) {
		this.noVideo = noVideo;
	}
	public String getNoChannel() {
		return noChannel;
	}
	public void setNoChannel(String noChannel) {
		this.noChannel = noChannel;
	}
	public String getNoHashtag() {
		return noHashtag;
	}
	public void setNoHashtag(String noHashtag) {
		this.noHashtag = noHashtag;
	}
	public String getVidoeSortFilter() {
		return vidoeSortFilter;
	}
	public void setVidoeSortFilter(String vidoeSortFilter) {
		this.vidoeSortFilter = vidoeSortFilter;
	}
	public String getUserFilter() {
		return userFilter;
	}
	public void setUserFilter(String userFilter) {
		this.userFilter = userFilter;
	}
	public String getUserNotFilter() {
		return userNotFilter;
	}
	public void setUserNotFilter(String userNotFilter) {
		this.userNotFilter = userNotFilter;
	}
	public String getHashtagFilter() {
		return hashtagFilter;
	}
	public void setHashtagFilter(String hashtagFilter) {
		this.hashtagFilter = hashtagFilter;
	}
	public String getHashtagNotFilter() {
		return hashtagNotFilter;
	}
	public void setHashtagNotFilter(String hashtagNotFilter) {
		this.hashtagNotFilter = hashtagNotFilter;
	}
	public String getUserSortFilter() {
		return userSortFilter;
	}
	public void setUserSortFilter(String userSortFilter) {
		this.userSortFilter = userSortFilter;
	}
	
	public String getRowNum() {
		return rowNum;
	}
	public void setRowNum(String rowNum) {
		this.rowNum = rowNum;
	}
	public String getDateFrom() {
		return dateFrom;
	}
	public void setDateFrom(String dateFrom) {
		this.dateFrom = dateFrom;
	}
	public String getDateTo() {
		return dateTo;
	}
	public void setDateTo(String dateTo) {
		this.dateTo = dateTo;
	}
	public String getDateFromGr() {
		return dateFromGr;
	}
	public void setDateFromGr(String dateFromGr) {
		this.dateFromGr = dateFromGr;
	}
	public String getDateToGr() {
		return dateToGr;
	}
	public void setDateToGr(String dateToGr) {
		this.dateToGr = dateToGr;
	}
	public String getAdvFilter() {
		return advFilter;
	}
	public void setAdvFilter(String advFilter) {
		this.advFilter = advFilter;
	}
	public String getSortFilter() {
		return sortFilter;
	}
	public void setSortFilter(String sortFilter) {
		this.sortFilter = sortFilter;
	}
	public String getIsDashBord() {
		return isDashBord;
	}
	public void setIsDashBord(String isDashBord) {
		this.isDashBord = isDashBord;
	}
	public String getSentimentFilter() {
		return sentimentFilter;
	}
	public void setSentimentFilter(String sentimentFilter) {
		this.sentimentFilter = sentimentFilter;
	}
	public String getPriorityFilter() {
		return priorityFilter;
	}
	public void setPriorityFilter(String priorityFilter) {
		this.priorityFilter = priorityFilter;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	public String getIsMarked() {
		return isMarked;
	}
	public void setIsMarked(String isMarked) {
		this.isMarked = isMarked;
	}
	public String getKeywordFilter2() {
		return keywordFilter2;
	}
	public void setKeywordFilter2(String keywordFilter2) {
		this.keywordFilter2 = keywordFilter2;
	}
	public String getKeywordFilter() {
		return keywordFilter;
	}
	public void setKeywordFilter(String keywordFilter) {
		this.keywordFilter = keywordFilter;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getIsRpt() {
		return isRpt;
	}
	public void setIsRpt(String isRpt) {
		this.isRpt = isRpt;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getVideoId() {
		return videoId;
	}
	public void setVideoId(String videoId) {
		this.videoId = videoId;
	}
	public String getEntityId() {
		return entityId;
	}
	public void setEntityId(String entityId) {
		this.entityId = entityId;
	}
	public String getChannelId() {
		return channelId;
	}
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
	public String getChannelName() {
		return channelName;
	}
	public void setChannelName(String channelName) {
		this.channelName = channelName;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public String getCaseId() {
		return caseId;
	}
	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}

}

