package com.cdac.sudarshan.discover.common;

import java.io.IOException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.cdac.sudarshan.discover.model.KeyMapVo;
import com.cdac.sudarshan.discover.model.TweeterActionVo;
import com.cdac.sudarshan.discover.model.TwitterChartVo;
import com.cdac.sudarshan.discover.model.TwitterVo;
import com.cdac.sudarshan.discover.model.WordFrequency;
import com.google.gson.JsonParseException;
import com.google.gson.internal.LinkedTreeMap;

import twitter4j.JSONArray;
import twitter4j.JSONException;
import twitter4j.JSONObject;
//import wordcloud.WordFrequency;

@Component
public class DashBoardController {
	
	@Autowired
	DashBoardManager dashBoardManager;
	
	@Autowired
	TwitterManagerInn tweetManagerInn;
	
	@Autowired
	private CommonUtils commonUtils;
	
	@Autowired
	private ExcelExportWidgetDataReport excelExportWidgetDataReport;
	
	
	/**
	 * This method is used to return total count of documents with their source.
	 * @param TweeterActionVo
	 * @return ArrayList<TwitterVo>
	 */
	@RequestMapping(value="/dashEntityCount")
	public  @ResponseBody ArrayList<TwitterVo> dashEntityCount(@RequestBody TweeterActionVo tweeterActionVo) {
		return dashBoardManager.dashEntityCount(tweeterActionVo);
	}
	
	/**
	 * This method is used to fetch sentiment time-line data report
	 * @param tweeterActionVo
	 * @return ArrayList<TwitterVo>
	 */
	@RequestMapping(value="/dashTimeLine")
	public @ResponseBody ArrayList<TwitterVo> dashTimeLine(@RequestBody TweeterActionVo tweeterActionVo){
		return dashBoardManager.dashTimeLine(tweeterActionVo);
	}
	
	/**
	 * 
	 * @param tweeterActionVo
	 * @return ArrayList<TwitterVo> 
	 */
	@RequestMapping(value="/dashTwTrends")
	public  @ResponseBody ArrayList<TwitterVo> dashTwTrends(@RequestBody TweeterActionVo tweeterActionVo)
	{
		return dashBoardManager.dashTwTrends(tweeterActionVo);
	}

	/**
	 * This method is used to fetch data for "Document Density World Wide" report.
	 * @param tweeterActionVo
	 * @return ArrayList<TwitterVo>
	 */
	@RequestMapping(value="/dashGeoMap")
	public  @ResponseBody ArrayList<TwitterVo> dashGeoMap(@RequestBody TweeterActionVo tweeterActionVo)
	{
		return dashBoardManager.dashGeoMap(tweeterActionVo);
	}

	/**
	 * This method is used to fetch data "Top HashTags"," Top Mention", "Places Talked About", "Person Talked About", "Organization Talked About", "Top Mobile Number", "Top Email", "Top Themes", "Ip Address" 
	 * @param tweeterActionVo
	 * @return ArrayList<TwitterVo>
	 */
	@RequestMapping(value="/dashActiveEntity")
	public @ResponseBody ArrayList<TwitterVo> dashActiveEntity(@RequestBody TweeterActionVo tweeterActionVo)
	{
		return dashBoardManager.dashActiveEntity(tweeterActionVo);
		
	}
	
	/**
	 * This method is used to fetch data of post image ods and profile image ods data.
	 * @param tweeterActionVo
	 * @return ArrayList<TwitterVo>
	 */
	@RequestMapping(value="/dashODSImage")
	public @ResponseBody ArrayList<TwitterVo> dashODSImage(@RequestBody TweeterActionVo tweeterActionVo)
	{
		return dashBoardManager.dashODSImage(tweeterActionVo);
	}
	
	/**
	 * This method is used to fetch data of post image OCR data.
	 * @param tweeterActionVo
	 * @return ArrayList<TwitterVo>
	 */
	@RequestMapping(value="/dashOCRImage")
	public @ResponseBody ArrayList<TwitterVo> dashOCRImage(@RequestBody TweeterActionVo tweeterActionVo)
	{
		return dashBoardManager.dashOCRImage(tweeterActionVo);
	}

	/**
	 * This method is used to fetch report data for "Dashboard" page and data is binded with "Trending Tweets", "Latest Tweets", "Latest Video", "Most Liked Video", "Most Dislike Video", "Most View Video", "Most Commented Video", "Latest Posts", "Most Share Post", "Most Liked Post", "Most Commented Post", " Only Tweet"
	 * @param tweeterActionVo
	 * @return ArrayList<TwitterVo>
	 */
	@RequestMapping(value="/dashArticles")
	public @ResponseBody ArrayList<TwitterVo> dashArticles(@RequestBody TweeterActionVo tweeterActionVo)
	{
		return dashBoardManager.dashArticles(tweeterActionVo);
	}

	/**
	 * This method is used to fetch report data for "Top Image", "Top video", "Top URL", "Top Audio"
	 * @param tweeterActionVo
	 * @return ArrayList<TwitterVo>
	 */
	@RequestMapping(value="/dashActiveMedia")
	public @ResponseBody ArrayList<TwitterVo> dashActiveMedia(@RequestBody TweeterActionVo tweeterActionVo)
	{
		return dashBoardManager.dashActiveMedia(tweeterActionVo);
	}
	
	
	
    /**
	 * This method is used to fetch dashboard widget "Most active users", "User who retweeted most", "User Who Tweeted Most", "Users With Maximum friend count", "Users With Maximum Follower count"
	 * @param tweeterActionVo
	 * @return ArrayList<TwitterVo>
	 */
	@RequestMapping(value="/dashActiveUser")
	public @ResponseBody ArrayList<TwitterVo> dashActiveUser(@RequestBody TweeterActionVo tweeterActionVo) {
		return dashBoardManager.dashActiveUser(tweeterActionVo);
	}
	
	/**
	 * 
	 * @param model
	 * @param request
	 * @return String
	 * @throws JsonParseException
	 * @throws JsonMappingException
	 * @throws IOException
	 */
	@RequestMapping(value="/dashboardRpt")
	public String dashboardRpt(Model model,HttpServletRequest request) throws JsonParseException, JsonMappingException, IOException
	{
		
/*		ObjectMapper mapper = new ObjectMapper();
		TweeterActionVo DashIndaputVo = mapper.readValue(request.getParameter("dashRptAction"), TweeterActionVo.class);
		
		System.out.println("Date And Id : "+DashIndaputVo.getFromDate()+","+DashIndaputVo.getCaseId());

		ArrayList<TwitterVo> entityCountLst=	dashBoardManager.dashEntityCount(DashIndaputVo);
		ArrayList<TwitterVo> dashNerLst=dashBoardManager.dashRssNER(DashIndaputVo);
		ArrayList<TwitterVo> dashPhrasesLst=dashBoardManager.dashPhases(DashIndaputVo);
		ArrayList<TwitterVo> trendHashTagLst=dashBoardManager.dashActiveHashTag(DashIndaputVo);
		ArrayList<TwitterVo> mediaLst=dashBoardManager.dashActiveMedia(DashIndaputVo);
		ArrayList<TwitterVo> usrLst=dashBoardManager.dashActiveUser(DashIndaputVo);
		ArrayList<TwitterVo> tweetLst=dashBoardManager.dashTopTrendingTweets(DashIndaputVo);
		ArrayList<TwitterVo> videoLst=dashBoardManager.dashTopTrendingVideos(DashIndaputVo);
		ArrayList<TwitterVo> instaLst=dashBoardManager.dashTopTrendingInstaPost(DashIndaputVo);
		ArrayList<FbOutputVo> postLst=dashBoardManager.dashTopTrendingFacebookPost(DashIndaputVo);
		ArrayList<TwitterVo> geoMapLst=	dashBoardManager.dashGeoMap(DashIndaputVo);
		ArrayList<TwitterVo> trendsLst=dashBoardManager.dashTwTrends(DashIndaputVo);

		model.addAttribute("entityList", entityCountLst);
		model.addAttribute("countLstd", dashNerLst);
		model.addAttribute("phrases", dashPhrasesLst);
		model.addAttribute("trendingHashtags", trendHashTagLst);
		model.addAttribute("images", mediaLst);
		model.addAttribute("usersss", usrLst);
		model.addAttribute("usersssDF", tweetLst);
		model.addAttribute("usersssDFd", videoLst);
		model.addAttribute("usersssDFddf", instaLst);
		model.addAttribute("userssfb", postLst);
		model.addAttribute("geoMapLst", geoMapLst);
		model.addAttribute("trendsLst", trendsLst);
*/		return "dashboardRpt";
	}
	
	/**
	 * This method is used to create a custom Dashboard	
	 * @param dashboard
	 * @return String
	 */
	@RequestMapping(value="/customDashboard")
	public @ResponseBody String createDashboard(@RequestBody Dashboard dashboard){
		  dashBoardManager.createDashboard(dashboard);
		  return "true";
	}
	
	/**
	 * This method is used to fetch created name of custom dashboard list.
	 * @param dashboard
	 * @return List<Dashboard>
	 */
	@RequestMapping(value="/customDashboardList")
	public @ResponseBody List<Dashboard> getAllDashboard(@RequestBody Dashboard dashboard)
	{
		 return dashBoardManager.getAllDashboard(dashboard);
	}
	
	/**
	 * This method is used to insert widget data to DB.
	 * @param dashboard
	 * @return String
	 */
	@RequestMapping(value="/addWidgetsToDashboard")
	public @ResponseBody String addWidgetsToDashboard(@RequestBody Dashboard dashboard) {
		  dashBoardManager.addWidgetsToDashboard(dashboard);
		  return "true";
	}

	/**
	 * This method is used to remove widget mapping and data from DB.
	 * @param dashboard
	 * @return String
	 */
	@RequestMapping(value="/removeWidgetsFromDashboard")
	public @ResponseBody String removeWidgetsFromDashboard(@RequestBody Dashboard dashboard)
	{
		  dashBoardManager.removeWidgetsFromDashboard(dashboard);
		  return "true";
	}

	/**
	 * This method is used to fetch all mapped widget data to dashboard.
	 * @param widget
	 * @return List<Widget>
	 */
	@RequestMapping(value="/getAllWidget")
	public @ResponseBody List<Widget> getAllWidget(@RequestBody Widget widget)
	{
		 return dashBoardManager.getAllWidget(widget);
	}

	/**
	 * This method is used to remove custom created dashboad from DB.
	 * @param dashboard
	 * @return String
	 */
	@RequestMapping(value="/removeDashboardById")
	public @ResponseBody String removeDashboardById(@RequestBody Dashboard dashboard)
	{
		  dashBoardManager.removeDashboardById(dashboard);
		  return "true";
	}

	/**
	 * This method is used to assign custom created dashboard to all users.
	 * @param dashboard
	 * @return String
	 */
	@RequestMapping(value="/makePublic")
	public @ResponseBody String makePublic(@RequestBody Dashboard dashboard)
	{
		  dashBoardManager.updateDashboardById(dashboard);
		  return "true";
	}

	/**
	 * This method is used to fetch custom dashboard mapped widget data by dashboard ID. 
	 * @param dashboardId
	 * @return List<DashboardWidgetVo>
	 */
	@RequestMapping(value="/getWidgetsByDashboardId")
	public @ResponseBody List<DashboardWidgetVo> getWidgetsByDashboardId(@RequestParam Long dashboardId) {
		 String userLog = "Fetching data for dashboard";
		 commonUtils.insertUserActivityLogs(userLog);
		 return dashBoardManager.getWidgetsByDashboardId(dashboardId);
	}
	
	/**
	 * This method is used to save Dashboard detail to DB.
	 * @param param
	 * @return int
	 */
	@RequestMapping(value="/saveDashboard")
	@ResponseBody	
	public int saveDashboard(@RequestBody String param)
	{
		/*
		 [
		{x: 2, y: 5, width: 2, height: 2, widget_id:9, dashboard_id:2},
		{x: 2, y: 5, width: 2, height: 2, widget_id:1, dashboard_id:2}
		]
		*/
		List<DashboardWidgetVo> list = new ArrayList<DashboardWidgetVo>();	
		
		try 
		{
			JSONArray arr = new JSONArray(param);
			for(int i=0; i!=arr.length(); i++)
			{
				JSONObject x =(JSONObject)arr.get(i);
				
				DashboardWidgetVo vo = new DashboardWidgetVo();
				
				String temp = (String)x.get("id");
				temp = temp.replace("widget_dashboard_", "");
				long widgetId = Long.parseLong(temp.split("-")[0]);
				String dashboardId = temp.split("-")[1];
				
				vo.setWidgetId(widgetId);
				vo.setWidgetX((Integer)x.get("x"));
				vo.setWidgetY((Integer)x.get("y"));
				vo.setWidgetWidth((Integer)x.get("width"));
				vo.setWidgetHeight((Integer)x.get("height"));
				vo.setDashboardId(Integer.parseInt(dashboardId));
				list.add(vo);
			}
		} 
		catch(JSONException e) 
		{
			e.printStackTrace();
		}
		return dashBoardManager.saveDashboard(list);
	}
	
	/**
	 * This method is used to fetch all dashboard detail. 
	 * @return List<DashboardWidgetVo>
	 */
	@RequestMapping(value="/getAllDashboard")
	@ResponseBody	
	public List<DashboardWidgetVo> getAllDashboard()
	{
		return dashBoardManager.getAllDashboard();
	}
	
	/**
	 * This method is used to fetch data for Sentiment World Wide widget.
	 * @param tweeterActionVo
	 * @return ArrayList<TwitterVo>
	 */
	@RequestMapping(value="/getSentimentCountryDash")
	public  @ResponseBody ArrayList<TwitterVo> getSentimentcounty(@RequestBody TweeterActionVo tweeterActionVo)
	{
		return tweetManagerInn.getSentimentcounty(tweeterActionVo);
	}

	/**
	 * This method is used to export/retrieve Dashboard word file document report
	 * @param request
	 * @param mp
	 * @param qparam
	 * @return ModelAndView
	 */
	@RequestMapping(value="/exportDashboard")
	public ModelAndView exportDashboard(HttpServletRequest request,Map<String,Object> mp,@RequestParam(value="qparam") String qparam)
	{
		try
		{
			ObjectMapper mapper = new ObjectMapper();
			List<DashboardExportVo> list = (List<DashboardExportVo>)mapper.readValue(qparam, List.class);
			
			mp.put("exportList",list);
		}  
		catch(Exception e) 
		{
			e.printStackTrace();
		}
		
		return new ModelAndView("exportDashboard");
	}
	
	/**
	 * This method is used to export/retrieve Dashboard word file document report For Viva Graph
	 * @param request
	 * @param mp
	 * @param qparam
	 * @return ModelAndView
	 */
	@RequestMapping(value="/exportVivaReport")
	public ModelAndView exportVivaReport(HttpServletRequest request,Map<String,Object> mp,@RequestParam(value="qparam") String qparam)
	{
		try {
			ObjectMapper mapper = new ObjectMapper();
			Object object = mapper.readValue(qparam, List.class);
			
			mp.put("exportList",object);
		}  catch (Exception e) {
			e.printStackTrace();
		}
		
		return new ModelAndView("exportVivaReport");
	}
	
	/**
	 * This method is used to export Custom dashboard report.
	 * @param request
	 * @return String
	 */
	//FOR Export Fixed Dashborad Report
	@RequestMapping(value="/exportFixedDashboardAllDataRpt")
	public String exportFixedDashboardAllDataRpt(HttpServletRequest request) {
		return "ReportJsp/exportFixedDashboardReport";
	}
	
	/**
	 * This method is used to export Custom dashboard report.
	 * @param request
	 * @return String
	 */
	// EXPORT CUSTOM DASHBOARD
	@RequestMapping(value="/exportCustomDashboardAllDataRpt")
	public String exportCustomDashboardAllDataRpt(HttpServletRequest request) 
	{
		return "ReportJsp/exportCustomDashboardReport";		
	}
	
	
	/**
	 * This method is used to export Fixed default dashboard report.
	 * @param request
	 * @return String
	 */
	// EXPORT DEFAULT DASHBOARD
	@RequestMapping(value="/exportDefaultDashboardDataRpt")
	public String exportDefaultDashboardDataRpt(HttpServletRequest request) throws JsonParseException, JsonMappingException, IOException
	{
		return "ReportJsp/defaultDashboardReportExport";
	}
	
	/**
	 * This method is used to export Fixed main dashboard report.
	 * @param request
	 * @return String
	 */
	// EXPORT MAIN DASHBOARD
	@RequestMapping(value="/exportMainDashboardDataRpt")
	public String exportMainDashboardDataRpt(HttpServletRequest request) throws JsonParseException, JsonMappingException, IOException
	{
		return "ReportJsp/mainDashboardReportExport";
	}
		
	/**
	 * This method is used to export Fixed facebook dashboard report.
	 * @param request
	 * @return String
	 */	
	// EXPORT FACEBOOK DASHBOARD
	@RequestMapping(value="/exportFacebookDashboardDataRpt")
	public String exportFacebookDashboardDataRpt(HttpServletRequest request) throws JsonParseException, JsonMappingException, IOException
	{
		return "ReportJsp/facebookDashboardReportExport";
	}
		
	/**
	 * This method is to map user id with logged in User in Innsight.
	 * @param dashboardId
	 * @param caseId
	 * @return String
	 */
	@RequestMapping(value="/setAsDefaultDashboard")
	public @ResponseBody String markCurrentDashboard(@RequestParam String dashboardId,@RequestParam String caseId)
	{
		  dashBoardManager.markCurrentDashboard(dashboardId,caseId);
		  return "true";
	}
	
	/**
	 * This method is used to fetch recently used dashboard by Innsight logged in user.
	 * @param caseId
	 * @return List<Dashboard>
	 */
	@RequestMapping(value="/getUserCurrentDashboard")
	public @ResponseBody List<Dashboard> getUserCurrentDashboard(@RequestParam String caseId)
	{
		return dashBoardManager.getUserCurrentDashboard(caseId);
	}
		
	
	/**
	 * This method is used to export all report in excel form on dashboard by passing their required comment. 
	 * @param request
	 * @param mp
	 * @param qparam
	 * @return ModelAndView
	 * @throws Exception 
	 */
	//Dashboard Excel export
//	@SuppressWarnings("rawtypes")
//	@RequestMapping(value="/exportExcelDashboardWidgetData")
	public HttpEntity<?> exportExcelDashboardWidgetData(TweeterActionVo tweeterActionVo, HttpServletResponse response) throws Exception 
	{
//		String inputData = URLDecoder.decode(mp.toString(), "UTF-8");		  
//		byte[] bytes = inputData.getBytes(StandardCharsets.ISO_8859_1);
//		inputData = new String(bytes, StandardCharsets.UTF_8);
		String fileName="";		
		int documentCount=0;
		ArrayList<ArrayList<String>> finalList = new ArrayList<ArrayList<String>>();
		ArrayList<String> headingList = new ArrayList<String>();
		String type=tweeterActionVo.getExportWidgetType();
		ArrayList<TwitterVo> dashActiveEntity=null;
		ArrayList<LinkedTreeMap> getFieldTypeData=null;
		try 
		{
//			ObjectMapper mapper = new ObjectMapper();
//			TweeterActionVo tweeterActionVo = mapper.readValue(mp, TweeterActionVo.class);
			//TweeterActionVo tweeterActionVo = mapper.readValue(qparam, TweeterActionVo.class);
			
			
			

			switch(type)
			{			    
			  case "top_hashtag_cmn":
				  fileName="Top Hashtag";
				  headingList.add("Hashtag");
				  headingList.add("Count");
				  headingList.add("Source");
				  finalList.add(headingList);		  
				  
				  dashActiveEntity = dashBoardManager.dashActiveEntity(tweeterActionVo);
				  for(TwitterVo twitterVo : dashActiveEntity)
				  {
					  String sourceType = CommonUtils.getFullSourceName(twitterVo.getType());
					  for(TwitterChartVo twitterChartVo: twitterVo.getTwitterChartVo())
					  {
						  ArrayList<String> dataList = new ArrayList<String>();
						  dataList.add("#"+twitterChartVo.getKey());
						  dataList.add(twitterChartVo.getCount());
						  dataList.add(sourceType);
						  finalList.add(dataList);
					  }
				  }
				  break;
				  
			  case "top_mentions_cmn":
				  fileName="Top Mentions";
				  headingList.add("Mention");
				  headingList.add("Count");
				  headingList.add("Source");
				  finalList.add(headingList);		  
				  
				  dashActiveEntity = dashBoardManager.dashActiveEntity(tweeterActionVo);
				  for(TwitterVo twitterVo : dashActiveEntity) 
				  {
					  String sourceType = CommonUtils.getFullSourceName(twitterVo.getType());
					  for(TwitterChartVo twitterChartVo: twitterVo.getTwitterChartVo())
					  {
						  ArrayList<String> dataList = new ArrayList<String>();
						  dataList.add("@"+twitterChartVo.getKey());
						  dataList.add(twitterChartVo.getCount());
						  dataList.add(sourceType);
						  finalList.add(dataList);
					  }
				  }
				  break;
				  
			  case "top_users_cmn":
				  fileName="Most Active User";
				  headingList.add("Place");
				  headingList.add("Count");
				  headingList.add("Source");
				  finalList.add(headingList);
				  
				  dashActiveEntity = dashBoardManager.dashActiveEntity(tweeterActionVo);
				  for(TwitterVo twitterVo : dashActiveEntity)
				  {
					  String sourceType = CommonUtils.getFullSourceName(twitterVo.getType());
					  for(TwitterChartVo twitterChartVo: twitterVo.getTwitterChartVo())
					  {
						  ArrayList<String> dataList = new ArrayList<String>();
						  dataList.add(twitterChartVo.getKey());
						  dataList.add(twitterChartVo.getCount());
						  dataList.add(sourceType);
						  finalList.add(dataList);
					  }
				  }
				  break;
				  
			  case "top_place_cmn":
				  fileName="Places Talked About";
				  headingList.add("Place");
				  headingList.add("Count");
				  headingList.add("Source");
				  finalList.add(headingList);
				  
				  dashActiveEntity = dashBoardManager.dashActiveEntity(tweeterActionVo);
				  for(TwitterVo twitterVo : dashActiveEntity) 
				  {
					  String sourceType = CommonUtils.getFullSourceName(twitterVo.getType());
					  for(TwitterChartVo twitterChartVo: twitterVo.getTwitterChartVo())
					  {
						  ArrayList<String> dataList = new ArrayList<String>();
						  dataList.add(twitterChartVo.getKey());
						  dataList.add(twitterChartVo.getCount());
						  dataList.add(sourceType);
						  finalList.add(dataList);
					  }
				  }
				  break;
				  
			  case "top_person_cmn":
				  fileName="Persons Talked About";
				  headingList.add("Person");
				  headingList.add("Count");
				  headingList.add("Source");
				  finalList.add(headingList);		  
				  
				  dashActiveEntity = dashBoardManager.dashActiveEntity(tweeterActionVo);
				  for(TwitterVo twitterVo : dashActiveEntity)
				  {
					  String sourceType = CommonUtils.getFullSourceName(twitterVo.getType());
					  for(TwitterChartVo twitterChartVo: twitterVo.getTwitterChartVo()) 
					  {
						  ArrayList<String> dataList = new ArrayList<String>();
						  dataList.add(twitterChartVo.getKey());
						  dataList.add(twitterChartVo.getCount());
						  dataList.add(sourceType);
						  finalList.add(dataList);
					  }
				  }
				  break;
				  
			  case "top_org_cmn":
				  fileName="Org Talked About";
				  headingList.add("Organization");
				  headingList.add("Count");
				  headingList.add("Source");
				  finalList.add(headingList);		  
				  
				  dashActiveEntity = dashBoardManager.dashActiveEntity(tweeterActionVo);
				  for(TwitterVo twitterVo : dashActiveEntity) 
				  {
					  String sourceType = CommonUtils.getFullSourceName(twitterVo.getType());
					  for(TwitterChartVo twitterChartVo: twitterVo.getTwitterChartVo())
					  {
						  ArrayList<String> dataList = new ArrayList<String>();
						  dataList.add(twitterChartVo.getKey());
						  dataList.add(twitterChartVo.getCount());
						  dataList.add(sourceType);
						  finalList.add(dataList);
					  }
				  }
				  break;
				  
			  case "top_theme_cmn":
				  fileName="Top Themes";
				  headingList.add("Theme");
				  headingList.add("Count");
				  headingList.add("Source");
				  finalList.add(headingList);		  
				  
				  dashActiveEntity = dashBoardManager.dashActiveEntity(tweeterActionVo);
				  for(TwitterVo twitterVo : dashActiveEntity) 
				  {
					  String sourceType = CommonUtils.getFullSourceName(twitterVo.getType());
					  for(TwitterChartVo twitterChartVo: twitterVo.getTwitterChartVo())
					  {
						  ArrayList<String> dataList = new ArrayList<String>();
						  dataList.add(twitterChartVo.getKey());
						  dataList.add(twitterChartVo.getCount());
						  dataList.add(sourceType);
						  finalList.add(dataList);
					  }
				  }
				  break;
				  
			  case "top_email_id_cmm":
				  fileName="Top Email Ids";
				  headingList.add("Email");
				  headingList.add("Count");
				  headingList.add("Source");
				  finalList.add(headingList);		  
				  
				  dashActiveEntity = dashBoardManager.dashActiveEntity(tweeterActionVo);
				  for(TwitterVo twitterVo : dashActiveEntity) 
				  {
					  String sourceType = CommonUtils.getFullSourceName(twitterVo.getType());
					  for(TwitterChartVo twitterChartVo: twitterVo.getTwitterChartVo()) 
					  {
						  ArrayList<String> dataList = new ArrayList<String>();
						  dataList.add(twitterChartVo.getKey());
						  dataList.add(twitterChartVo.getCount());
						  dataList.add(sourceType);
						  finalList.add(dataList);
					  }
				  }
				  break;
				  
			  case "top_mobile_no_cmm":
				  fileName="Top Mobiles ";
				  headingList.add("Mobile");
				  headingList.add("Count");
				  headingList.add("Source");
				  finalList.add(headingList);		  
				  
				  dashActiveEntity = dashBoardManager.dashActiveEntity(tweeterActionVo);
				  for(TwitterVo twitterVo : dashActiveEntity)
				  {
					  String sourceType = CommonUtils.getFullSourceName(twitterVo.getType());
					  for(TwitterChartVo twitterChartVo: twitterVo.getTwitterChartVo())
					  {
						  ArrayList<String> dataList = new ArrayList<String>();
						  dataList.add(twitterChartVo.getKey());
						  dataList.add(twitterChartVo.getCount());
						  dataList.add(sourceType);
						  finalList.add(dataList);
					  }
				  }
				  break;
				  
			  case "top_event_ml":
				  fileName="Top Events ";
				  headingList.add("Event");
				  headingList.add("Count");
				  headingList.add("Source");
				  finalList.add(headingList);		  
				  
				  dashActiveEntity = dashBoardManager.dashActiveEntity(tweeterActionVo);
				  for(TwitterVo twitterVo : dashActiveEntity) 
				  {
					  String sourceType = CommonUtils.getFullSourceName(twitterVo.getType());
					  for(TwitterChartVo twitterChartVo: twitterVo.getTwitterChartVo())
					  {
						  ArrayList<String> dataList = new ArrayList<String>();
						  dataList.add(twitterChartVo.getKey());
						  dataList.add(twitterChartVo.getCount());
						  dataList.add(sourceType);
						  finalList.add(dataList);
					  }
				  }
				  break;
				  
			   case "top_ip_address_cmm":
				   fileName="Top Ip Address";
				   headingList.add("Ip Address");
				   headingList.add("Count");
				   //headingList.add("Source");
				   finalList.add(headingList);
				   
				   getFieldTypeData= tweetManagerInn.getFieldTypeData(tweeterActionVo);
				   
				   for(LinkedTreeMap row : getFieldTypeData) 
				   {
					   ArrayList<String> rowData = new ArrayList<String>();
					   Set entrySet = row.entrySet();
					   Iterator it = entrySet.iterator();
					   while(it.hasNext()) {
						   Map.Entry entry = (Entry) it.next();
						   if(entry.getKey().toString().equalsIgnoreCase("key"))
						   {
							   rowData.add(entry.getValue().toString());
						   }
						   if(entry.getKey().toString().equalsIgnoreCase("doc_count")) 
						   {
							   String count = entry.getValue().toString();
							   rowData.add(count.contains(".")?count.split("\\.")[0]:count);
						   }
					   }
					   finalList.add(rowData);
				   }			   
				   
				   break;
				   
			   case "top_bank_account_cmm":	
				   fileName="Top Bank Account numbers ";
				   headingList.add("Account Number");
				   headingList.add("Count");
				   //headingList.add("Source");
				   finalList.add(headingList);
				   
				   getFieldTypeData= tweetManagerInn.getFieldTypeData(tweeterActionVo);
				   
				   for(LinkedTreeMap row : getFieldTypeData) 
				   {
					   ArrayList<String> rowData = new ArrayList<String>();
					   Set entrySet = row.entrySet();
					   Iterator it = entrySet.iterator();
					   while(it.hasNext()) 
					   {
						   Map.Entry entry = (Entry) it.next();
						   if(entry.getKey().toString().equalsIgnoreCase("key")) 
						   {
							   rowData.add(entry.getValue().toString());
						   }
						   if(entry.getKey().toString().equalsIgnoreCase("doc_count"))
						   {
							   String count = entry.getValue().toString();
							   rowData.add(count.contains(".")?count.split("\\.")[0]:count);
						   }
					   }
					   finalList.add(rowData);
				   }
				   
				   break;
			   case "top_time_spotted_cmm":
				   fileName="Top Time Spotted ";
				   headingList.add("Time Spotted");
				   headingList.add("Count");
				   //headingList.add("Source");
				   finalList.add(headingList);
				   
				   getFieldTypeData= tweetManagerInn.getFieldTypeData(tweeterActionVo);
				   
				   for(LinkedTreeMap row : getFieldTypeData) 
				   {
					   ArrayList<String> rowData = new ArrayList<String>();
					   Set entrySet = row.entrySet();
					   Iterator it = entrySet.iterator();
					   while(it.hasNext()) 
					   {
						   Map.Entry entry = (Entry) it.next();
						   if(entry.getKey().toString().equalsIgnoreCase("key")) 
						   {
							   rowData.add(entry.getValue().toString());
						   }
						   if(entry.getKey().toString().equalsIgnoreCase("doc_count")) 
						   {
							   String count = entry.getValue().toString();
							   rowData.add(count.contains(".")?count.split("\\.")[0]:count);
						   }
					   }
					   finalList.add(rowData);
				   }
				   break;
				   
			   case "top_debit_credit_card_no_cmm":
				   fileName="Top Debit Credit Card numbers ";
				   headingList.add("Card Number");
				   headingList.add("Count");
				   //headingList.add("Source");
				   finalList.add(headingList);
				   
				   getFieldTypeData= tweetManagerInn.getFieldTypeData(tweeterActionVo);
				   
				   for(LinkedTreeMap row : getFieldTypeData) 
				   {
					   ArrayList<String> rowData = new ArrayList<String>();
					   Set entrySet = row.entrySet();
					   Iterator it = entrySet.iterator();
					   while(it.hasNext()) 
					   {
						   Map.Entry entry = (Entry) it.next();
						   if(entry.getKey().toString().equalsIgnoreCase("key")) 
						   {
							   rowData.add(entry.getValue().toString());
						   }
						   if(entry.getKey().toString().equalsIgnoreCase("doc_count"))
						   {
							   String count = entry.getValue().toString();
							   rowData.add(count.contains(".")?count.split("\\.")[0]:count);
						   }
					   }
					   finalList.add(rowData);
				   }
				   break;
				   
			   case "top_vehicles_no_cmm":
				   fileName="Top Vehicles number ";
				   headingList.add("Vehicle Number");
				   headingList.add("Count");
				   //headingList.add("Source");
				   finalList.add(headingList);
				   
				   getFieldTypeData= tweetManagerInn.getFieldTypeData(tweeterActionVo);
				   
				   for(LinkedTreeMap row : getFieldTypeData) 
				   {
					   ArrayList<String> rowData = new ArrayList<String>();
					   Set entrySet = row.entrySet();
					   Iterator it = entrySet.iterator();
					   while(it.hasNext()) {
						   Map.Entry entry = (Entry) it.next();
						   if(entry.getKey().toString().equalsIgnoreCase("key"))
						   {
							   rowData.add(entry.getValue().toString());
						   }
						   if(entry.getKey().toString().equalsIgnoreCase("doc_count")) 
						   {
							   String count = entry.getValue().toString();
							   rowData.add(count.contains(".")?count.split("\\.")[0]:count);
						   }
					   }
					   finalList.add(rowData);
				   }
				   break;
				   
			   case "top_pin_code_cmm":	
				   fileName="Top Pin Codes ";
				   headingList.add("Pin Code");
				   headingList.add("Count");
				   //headingList.add("Source");
				   finalList.add(headingList);
				   
				   getFieldTypeData= tweetManagerInn.getFieldTypeData(tweeterActionVo);
				   
				   for(LinkedTreeMap row : getFieldTypeData) {
					   ArrayList<String> rowData = new ArrayList<String>();
					   Set entrySet = row.entrySet();
					   Iterator it = entrySet.iterator();
					   while(it.hasNext()) {
						   Map.Entry entry = (Entry) it.next();
						   if(entry.getKey().toString().equalsIgnoreCase("key")) {
							   rowData.add(entry.getValue().toString());
						   }
						   if(entry.getKey().toString().equalsIgnoreCase("doc_count")) {
							   String count = entry.getValue().toString();
							   rowData.add(count.contains(".")?count.split("\\.")[0]:count);
						   }
					   }
					   finalList.add(rowData);
				   }
				   break;
				   
			   case "top_country_cmm":	
				   fileName="Article Location ";
				   headingList.add("Country");
				   headingList.add("Count");
				   //headingList.add("Source");
				   finalList.add(headingList);
				   
				   getFieldTypeData= tweetManagerInn.getFieldTypeData(tweeterActionVo);
				   int location=0;
				   for(LinkedTreeMap row : getFieldTypeData) {
					   ArrayList<String> rowData = new ArrayList<String>();
					   Set entrySet = row.entrySet();
					   Iterator it = entrySet.iterator();
					   while(it.hasNext()) {
						   Map.Entry entry = (Entry) it.next();
						   if(entry.getValue()==null || entry.getValue().toString().isEmpty()) 
						   {
							   location=1;
						   	  continue;						   	
						   }
						   if(entry.getKey().toString().equalsIgnoreCase("key")) {
							   rowData.add(entry.getValue().toString());
						   }
						   if(entry.getKey().toString().equalsIgnoreCase("doc_count")) {
							   String count = entry.getValue().toString();
							   rowData.add(count.contains(".")?count.split("\\.")[0]:count);
						   }
					   }
					   if(location==1){
						   location=0;
						   continue;
					   }
					   finalList.add(rowData);
				   }
				   break;
				   
			   case "top_city_cmm":	
				   fileName="Top City ";
				   headingList.add("City");
				   headingList.add("Count");
				   finalList.add(headingList);
				   
				   getFieldTypeData= tweetManagerInn.getFieldTypeData(tweeterActionVo);
				   
				   for(LinkedTreeMap row : getFieldTypeData) {
					   ArrayList<String> rowData = new ArrayList<String>();
					   Set entrySet = row.entrySet();
					   Iterator it = entrySet.iterator();
					   while(it.hasNext()) {
						   Map.Entry entry = (Entry) it.next();
						   if(entry.getKey().toString().equalsIgnoreCase("key")) {
							   rowData.add(entry.getValue().toString());
						   }
						   if(entry.getKey().toString().equalsIgnoreCase("doc_count")) {
							   String count = entry.getValue().toString();
							   rowData.add(count.contains(".")?count.split("\\.")[0]:count);
						   }
					   }
					   finalList.add(rowData);
				   }
				   break;
				   
			   case "author_location_cmm":
				   fileName="Author Location number ";
				   headingList.add("Author Location");
				   headingList.add("Count");
				   //headingList.add("Source");
				   finalList.add(headingList);
				   
				   getFieldTypeData= tweetManagerInn.getFieldTypeData(tweeterActionVo);
				   int author_location=0;
				   for(LinkedTreeMap row : getFieldTypeData) {
					   ArrayList<String> rowData = new ArrayList<String>();
					   Set entrySet = row.entrySet();
					   Iterator it = entrySet.iterator();
					   while(it.hasNext()) {
						   Map.Entry entry = (Entry) it.next();
						   if(entry.getValue()==null || entry.getValue().toString().isEmpty()) 
						   {
							   author_location=1;
						   	  continue;						   	
						   }
						   if(entry.getKey().toString().equalsIgnoreCase("key")) {
							   rowData.add(entry.getValue().toString());
						   }
						   if(entry.getKey().toString().equalsIgnoreCase("doc_count")) {
							   String count = entry.getValue().toString();
							   rowData.add(count.contains(".")?count.split("\\.")[0]:count);
						   }
					   }
					   if(author_location==1){
						   author_location=0;
						   continue;
					   }
					   finalList.add(rowData);
				   }
				   break;
				   
			   case "top_languages_ml":	
				   fileName="Top Languages ML ";
				   headingList.add("Language");
				   headingList.add("Count");
				   //headingList.add("Source");
				   finalList.add(headingList);
				   
				   getFieldTypeData= tweetManagerInn.getFieldTypeData(tweeterActionVo);
				   
				   for(LinkedTreeMap row : getFieldTypeData) {
					   ArrayList<String> rowData = new ArrayList<String>();
					   Set entrySet = row.entrySet();
					   Iterator it = entrySet.iterator();
					   while(it.hasNext()) {
						   Map.Entry entry = (Entry) it.next();
						   if(entry.getKey().toString().equalsIgnoreCase("key")) {
							   rowData.add(entry.getValue().toString());
						   }
						   if(entry.getKey().toString().equalsIgnoreCase("doc_count")) {
							   String count = entry.getValue().toString();
							   rowData.add(count.contains(".")?count.split("\\.")[0]:count);
						   }
					   }
					   finalList.add(rowData);
				   }
				   break;
				   
			   case "top_language_cmm":	
				   fileName="Top Languages ";
				   headingList.add("Language");
				   headingList.add("Count");
				   //headingList.add("Source");
				   finalList.add(headingList);
				   
				   getFieldTypeData= tweetManagerInn.getFieldTypeData(tweeterActionVo);
				   
				   for(LinkedTreeMap row : getFieldTypeData) {
					   ArrayList<String> rowData = new ArrayList<String>();
					   Set entrySet = row.entrySet();
					   Iterator it = entrySet.iterator();
					   while(it.hasNext()) {
						   Map.Entry entry = (Entry) it.next();
						   if(entry.getKey().toString().equalsIgnoreCase("key")) {
							   rowData.add(entry.getValue().toString());
						   }
						   if(entry.getKey().toString().equalsIgnoreCase("doc_count")) {
							   String count = entry.getValue().toString();
							   rowData.add(count.contains(".")?count.split("\\.")[0]:count);
						   }
					   }
					   finalList.add(rowData);
				   }
				   break;
				   
			   case "most_influence_tweet_users_tw":
				   fileName="Most Tweeted Users ";
				   headingList.add("User");
				   headingList.add("Count");
				   finalList.add(headingList);
				   
				   dashActiveEntity = tweetManagerInn.mostInfluenceTweetUser(tweeterActionVo);
				   for(TwitterVo twitterVo : dashActiveEntity) {
					  ArrayList<String> list = new ArrayList<String>();
					  list.add(twitterVo.getHashtag());
					  list.add(twitterVo.getHashCount());
					  finalList.add(list);  
				   }
				   break;
				   
			   case "user_tweeted_tw":
				   fileName="Most Tweeted Users ";
				   headingList.add("User");
				   headingList.add("Count");
				   headingList.add("Image");
				   finalList.add(headingList);
				   
				   dashActiveEntity= dashBoardManager.dashActiveUser(tweeterActionVo);
				   for(TwitterVo twitterVo : dashActiveEntity) {
					  if(twitterVo.getType().equalsIgnoreCase("tw")) {
						   ArrayList<TwitterChartVo> twitterChartVoList = twitterVo.getTwitterChartVo();
						   for(TwitterChartVo twitterChartVo : twitterChartVoList) {
							   ArrayList<String> list = new ArrayList<String>();
							   list.add(twitterChartVo.getKey());
							   list.add(twitterChartVo.getCount());
							   list.add(twitterChartVo.getKey2());
							   finalList.add(list);							   
						   }
					   }					   
				   }
				   break;
				   
			   case "top_taxonomy_ml":
				   fileName="Top Taxonomy ";
				   headingList.add("Taxonomy");
				   headingList.add("Count");
				   finalList.add(headingList);
				   
				   getFieldTypeData= tweetManagerInn.getFieldTypeData(tweeterActionVo);
				   
				   for(LinkedTreeMap row : getFieldTypeData) {
					   ArrayList<String> rowData = new ArrayList<String>();
					   Set entrySet = row.entrySet();
					   Iterator it = entrySet.iterator();
					   while(it.hasNext()) {
						   Map.Entry entry = (Entry) it.next();
						   if(entry.getKey().toString().equalsIgnoreCase("key")) {
							   rowData.add(entry.getValue().toString());
						   }
						   if(entry.getKey().toString().equalsIgnoreCase("doc_count")) {
							   String count = entry.getValue().toString();
							   rowData.add(count.contains(".")?count.split("\\.")[0]:count);
						   }
					   }
					   finalList.add(rowData);
				   }
				   break;
				   
			   case "top_urls_cmn":
				   fileName="Top Urls ";
				   headingList.add("URL");
				   headingList.add("Count");
				   finalList.add(headingList);
				   
				   dashActiveEntity= dashBoardManager.dashActiveMedia(tweeterActionVo);
				   for(TwitterVo twitterVo : dashActiveEntity) {
					  if(twitterVo.getType().equalsIgnoreCase("tw")) {
						   ArrayList<TwitterChartVo> twitterChartVoList = twitterVo.getTwitterChartVo();
						   for(TwitterChartVo twitterChartVo : twitterChartVoList) {
							   ArrayList<String> list = new ArrayList<String>();
							   list.add(twitterChartVo.getMediaKey());
							   list.add(twitterChartVo.getMediaCount());
							   finalList.add(list);							   
						   }
					   }					   
				   }
				   break;
				   
			   case "user_gender_ml":
				   fileName="Gender Distribution ";
				   headingList.add("Gender");
				   headingList.add("Count");
				   finalList.add(headingList);
				   
				   getFieldTypeData= tweetManagerInn.getFieldTypeData(tweeterActionVo);
				   int gender=0;
				   for(LinkedTreeMap row : getFieldTypeData) {
					   ArrayList<String> rowData = new ArrayList<String>();
					   Set entrySet = row.entrySet();
					   Iterator it = entrySet.iterator();
					   while(it.hasNext()) {
						   Map.Entry entry = (Entry) it.next();
						   if(entry.getValue().equals("Absent") || entry.getValue().equals("sikh")) 
						   {
							   gender=1;
						   	  continue;						   	
						   }
						   if(entry.getKey().toString().equalsIgnoreCase("key")) {
							   rowData.add(entry.getValue().toString());
						   }
						   if(entry.getKey().toString().equalsIgnoreCase("doc_count")) {
							   String count = entry.getValue().toString();
							   rowData.add(count.contains(".")?count.split("\\.")[0]:count);
						   }
					   }
					   if(gender==1){
						   gender=0;
						   continue;
					   }
					   finalList.add(rowData);
				   }
				   break;
				   
			   case "user_religion_ml":
				   fileName="Religion Distribution ";
				   headingList.add("Religion");
				   headingList.add("Count");
				   finalList.add(headingList);
				   
				   getFieldTypeData= tweetManagerInn.getFieldTypeData(tweeterActionVo);
				   int i=0;
				   for(LinkedTreeMap row : getFieldTypeData) {
					   ArrayList<String> rowData = new ArrayList<String>();
					   Set entrySet = row.entrySet();
					   Iterator it = entrySet.iterator();
					   while(it.hasNext()) {
						   Map.Entry entry = (Entry) it.next();						   
						   if(entry.getValue().equals("Absent")) {
						      i=1;
						   	  continue;						   	
						   }						   
						   if(entry.getKey().toString().equalsIgnoreCase("key")) {
							   rowData.add(entry.getValue().toString());
						   }
						   if(entry.getKey().toString().equalsIgnoreCase("doc_count")) {
							   String count = entry.getValue().toString();
							   rowData.add(count.contains(".")?count.split("\\.")[0]:count);
							
						   }						   
					   }
					   if(i==1) {
						   i=0;
						   continue;
					   }
					  finalList.add(rowData);
				   }
				   break;
				   
			   case "top_images_cmn":
				   fileName="Top Images ";
				   headingList.add("Image URL");
				   headingList.add("Count");
				   headingList.add("Media Url");
				   headingList.add("Media Thumbnail Local");
				   finalList.add(headingList);
				   
				   dashActiveEntity= dashBoardManager.dashActiveMedia(tweeterActionVo);
				   for(TwitterVo twitterVo : dashActiveEntity) {
					  //if(twitterVo.getType().equalsIgnoreCase("tw")) {
						   ArrayList<TwitterChartVo> twitterChartVoList = twitterVo.getTwitterChartVo();
						   for(TwitterChartVo twitterChartVo : twitterChartVoList) {
							   ArrayList<String> list = new ArrayList<String>();
							   list.add(twitterChartVo.getKey());
							   list.add(twitterChartVo.getCount());
							   list.add(twitterChartVo.getKey1());
							   list.add(twitterChartVo.getKey2());
							   finalList.add(list);
						   }
					   //}					   
				   }
				   break;
				   
			   case "top_video_cmn":
				   fileName="Top Videos ";
				   headingList.add("Video URL");
				   headingList.add("Count");
				   finalList.add(headingList);
				   
				   dashActiveEntity= dashBoardManager.dashActiveMedia(tweeterActionVo);
				   for(TwitterVo twitterVo : dashActiveEntity) {
					  //if(twitterVo.getType().equalsIgnoreCase("tw")) {
						   ArrayList<TwitterChartVo> twitterChartVoList = twitterVo.getTwitterChartVo();
						   for(TwitterChartVo twitterChartVo : twitterChartVoList) {
							   ArrayList<String> list = new ArrayList<String>();
							   list.add(twitterChartVo.getMediaKey());
							   list.add(twitterChartVo.getMediaCount());
							   finalList.add(list);
						   }
					   //}					   
				   }
				   break;
				   
			   case "sent_timeline_cmn":
				   fileName="Sentiment Timeline ";
				   headingList.add("Date");
				   headingList.add("Count");
				   headingList.add("Sentiment");
				   finalList.add(headingList);
				   
				   dashActiveEntity= dashBoardManager.dashTimeLine(tweeterActionVo);
				   for(TwitterVo twitterVo : dashActiveEntity) {
					   ArrayList<String> list = new ArrayList<String>();
					   list.add(twitterVo.getCreatedAt());
					   list.add(twitterVo.getTotalTweetCount());
					   list.add(twitterVo.getCount());
					   finalList.add(list);
				   }
				   break;
				   
			   case "sentiment_over_world_map_cmn":
				   fileName="Sentiment Worldwide";
				   headingList.add("Country Code");
				   headingList.add("Sentiment");
				   finalList.add(headingList);
				   
				   dashActiveEntity= tweetManagerInn.getSentimentcounty(tweeterActionVo);
				   for(TwitterVo twitterVo : dashActiveEntity) {
					   ArrayList<String> list = new ArrayList<String>();
					   list.add(twitterVo.getGeoCode());
					   list.add(twitterVo.getTweetCount());
					   finalList.add(list);
				   }
				   break; 
				   
			   case "article_count_per_source_cmn":	
				   fileName="Source-Based Document Count";
				   headingList.add("Source Type");
				   headingList.add("Count");
				   finalList.add(headingList);
				   
				   dashActiveEntity= dashBoardManager.dashEntityCount(tweeterActionVo);
				   for(TwitterVo twitterVo : dashActiveEntity) {
					   ArrayList<String> list = new ArrayList<String>();
					   list.add(twitterVo.getType());
					   list.add(twitterVo.getCount());
					   finalList.add(list);
				   }
				   break;
				   
			   case "document_over_world_map_cmn":
				   fileName="Sentiment Worldwide";
				   headingList.add("Country Code");
				   headingList.add("Sentiment");
				   finalList.add(headingList);
				   
				   dashActiveEntity= dashBoardManager.dashGeoMap(tweeterActionVo);
				   for(TwitterVo twitterVo : dashActiveEntity) {
					   ArrayList<String> list = new ArrayList<String>();
					   list.add(twitterVo.getHashtag());
					   list.add(twitterVo.getHashCount());
					   finalList.add(list);
				   }
				   break; 
				   
			   case "source_activity_timeline_together_cmn":
				   fileName="Document Timeline ";
				   headingList.add("Source");
				   headingList.add("Date");
				   headingList.add("Count");
				   finalList.add(headingList);
				   
				   dashActiveEntity= dashBoardManager.dashEntityCount(tweeterActionVo);
				   for(TwitterVo twitterVo : dashActiveEntity) {
					   //if(twitterVo.getType().equalsIgnoreCase("tw")) {
						   ArrayList<TwitterChartVo> twitterChartVoList = twitterVo.getTwitterChartVo();
						   for(TwitterChartVo twitterChartVo : twitterChartVoList) {
							   ArrayList<String> list = new ArrayList<String>();
							   list.add(CommonUtils.getFullSourceName(twitterVo.getType()));
							   list.add(twitterChartVo.getCreatedAt());
							   list.add(twitterChartVo.getCount());
							   finalList.add(list);
						   }
					   //}	
				   }
				   break;
				   
			   case "trending_tweet_tw":
				   fileName="Trending Tweets ";
				   headingList.add("Image Url");
				   headingList.add("Screen Name");
				   headingList.add("Handler");
				   headingList.add("Article Title");
				   headingList.add("Published Date");
				   headingList.add("Follower Count");
				   headingList.add("Friend Count");
				   headingList.add("Tweet Count");
				   headingList.add("Like Count");
				   headingList.add("Retweet Count");
				   finalList.add(headingList);
				   
				   dashActiveEntity= dashBoardManager.dashArticles(tweeterActionVo);
				   for(TwitterVo twitterVo : dashActiveEntity) {
					   ArrayList<String> list = new ArrayList<String>();
					   if(twitterVo.getTweet()!=null && twitterVo.getTweet().getTweetUser()!=null) {
						   list.add(twitterVo.getArticleAuthorImage());
						   list.add(twitterVo.getTweet().getTweetUser().getTweetUserScreenName()==null?"":twitterVo.getTweet().getTweetUser().getTweetUserScreenName());
						   list.add(twitterVo.getTweet().getTweetUser().getTweetUserScreenName()==null?"":"https://twitter.com/"+twitterVo.getTweet().getTweetUser().getTweetUserScreenName());
						   list.add(twitterVo.getArticleTitle()==null?"":twitterVo.getArticleTitle());
						   list.add(twitterVo.getArticlePublishDate()==null?"":twitterVo.getArticlePublishDate());
						   list.add(twitterVo.getTweet().getTweetUser().getTweetUserFollowersCount()+"");
						   list.add(twitterVo.getTweet().getTweetUser().getTweetUserFriendsCount()+"");
						   list.add(twitterVo.getTweet().getTweetUser().getTweetUserStatusCount()+"");
						   list.add(twitterVo.getTweet().getTweetUser().getTweetUserFavouriteCount()+"");
						   list.add(twitterVo.getTweet().getTweetRetweetCount()+"");
						   finalList.add(list);
					   }					   	
				   }
				   break;
				   
			   case "latest_tweet_tw":
				   fileName="Latest Tweets ";
				   headingList.add("Image Url");
				   headingList.add("Screen Name");
				   headingList.add("Handler");
				   headingList.add("Article Title");
				   headingList.add("Published Date");
				   headingList.add("Follower Count");
				   headingList.add("Friend Count");
				   headingList.add("Tweet Count");
				   headingList.add("Like Count");
				   headingList.add("Retweet Count");
				   finalList.add(headingList);
				   
				   dashActiveEntity= dashBoardManager.dashArticles(tweeterActionVo);
				   for(TwitterVo twitterVo : dashActiveEntity) {
					   ArrayList<String> list = new ArrayList<String>();
					   if(twitterVo.getTweet()!=null && twitterVo.getTweet().getTweetUser()!=null) {
						   list.add(twitterVo.getArticleAuthorImage());
						   list.add(twitterVo.getTweet().getTweetUser().getTweetUserScreenName()==null?"":twitterVo.getTweet().getTweetUser().getTweetUserScreenName());
						   list.add(twitterVo.getTweet().getTweetUser().getTweetUserScreenName()==null?"":"https://twitter.com/"+twitterVo.getTweet().getTweetUser().getTweetUserScreenName());
						   list.add(twitterVo.getArticleTitle()==null?"":twitterVo.getArticleTitle());
						   list.add(twitterVo.getArticlePublishDate()==null?"":twitterVo.getArticlePublishDate());
						   list.add(twitterVo.getTweet().getTweetUser().getTweetUserFollowersCount()+"");
						   list.add(twitterVo.getTweet().getTweetUser().getTweetUserFriendsCount()+"");
						   list.add(twitterVo.getTweet().getTweetUser().getTweetUserStatusCount()+"");
						   list.add(twitterVo.getTweet().getTweetUser().getTweetUserFavouriteCount()+"");
						   list.add(twitterVo.getTweet().getTweetRetweetCount()+"");
						   finalList.add(list);
					   }					   	
				   }
				   break;
				   
			   case "user_retweeted_tw":
				   fileName="Most Retweeted Users ";
				   headingList.add("User");
				   headingList.add("Count");
				   headingList.add("Image");
				   finalList.add(headingList);
				   
				   dashActiveEntity= dashBoardManager.dashActiveUser(tweeterActionVo);
				   for(TwitterVo twitterVo : dashActiveEntity) {
					  if(twitterVo.getType().equalsIgnoreCase("tw")) {
						   ArrayList<TwitterChartVo> twitterChartVoList = twitterVo.getTwitterChartVo();
						   for(TwitterChartVo twitterChartVo : twitterChartVoList) {
							   ArrayList<String> list = new ArrayList<String>();
							   list.add(twitterChartVo.getKey());
							   list.add(twitterChartVo.getCount());
							   list.add(twitterChartVo.getKey2());
							   finalList.add(list);							   
						   }
					   }
				   }
				   break;
				   
			   case "user_created_between_dates_tw":
				   fileName="User Created Between Dates ";
				   headingList.add("Date");
				   headingList.add("Count");
				   finalList.add(headingList);
				   
				   dashActiveEntity= tweetManagerInn.getAllTwitterUserCreatiedBetweenDates(tweeterActionVo);
				   for(TwitterVo twitterVo : dashActiveEntity) {
					   ArrayList<String> list = new ArrayList<String>();
					   list.add(twitterVo.getCreatedAt());
					   list.add(twitterVo.getCount());
					   finalList.add(list);
				   }
				   break;
				   
			   case "latest_video_yt":
				   fileName="Latest Videos Youtube";
				   headingList.add("Image URL ");
				   headingList.add("Article Title");
				   headingList.add("Article Author");
				   headingList.add("View Count");
				   headingList.add("Like Count");
				   headingList.add("Dislike Count");
				   headingList.add("Comment Count");
				   finalList.add(headingList);
				   
				   dashActiveEntity = dashBoardManager.dashArticles(tweeterActionVo);
				   for(TwitterVo twitterVo : dashActiveEntity) {
					   if(twitterVo.getYoutube() != null) {
						   ArrayList<String> list = new ArrayList<String>();
						   list.add(twitterVo.getArticleMedia()==null?"":twitterVo.getArticleMedia().size()>0?twitterVo.getArticleMedia().get(0).getMediaThumbnail():"");
						   list.add(twitterVo.getArticleTitle());
						   list.add(twitterVo.getArticleAuthor());
						   list.add(twitterVo.getYoutube()==null?"":twitterVo.getYoutube().getYtViewCount()+"");
						   list.add(twitterVo.getYoutube()==null?"":twitterVo.getYoutube().getYtLikeCount()+"");
						   list.add(twitterVo.getYoutube()==null?"":twitterVo.getYoutube().getYtDisLikeCount()+"");
						   list.add(twitterVo.getYoutube()==null?"":twitterVo.getYoutube().getYtCommentCount()+"");
						   finalList.add(list);
					   }
				   }
				   break;
				   
			   case "liked_video_yt":
				   fileName="Most Liked Videos Youtube ";
				   headingList.add("Image URL");
				   headingList.add("Article Title");
				   headingList.add("Article Author");
				   headingList.add("View Count");
				   headingList.add("Like Count");
				   headingList.add("Dislike Count");
				   headingList.add("Comment Count");
				   finalList.add(headingList);
				   
				   dashActiveEntity = dashBoardManager.dashArticles(tweeterActionVo);
				   for(TwitterVo twitterVo : dashActiveEntity) {
					   if(twitterVo.getYoutube() != null) {
						   ArrayList<String> list = new ArrayList<String>();
						   list.add(twitterVo.getArticleMedia()==null?"":twitterVo.getArticleMedia().size()>0?twitterVo.getArticleMedia().get(0).getMediaThumbnail():"");
						   list.add(twitterVo.getArticleTitle());
						   list.add(twitterVo.getArticleAuthor());
						   list.add(twitterVo.getYoutube()==null?"":twitterVo.getYoutube().getYtViewCount()+"");
						   list.add(twitterVo.getYoutube()==null?"":twitterVo.getYoutube().getYtLikeCount()+"");
						   list.add(twitterVo.getYoutube()==null?"":twitterVo.getYoutube().getYtDisLikeCount()+"");
						   list.add(twitterVo.getYoutube()==null?"":twitterVo.getYoutube().getYtCommentCount()+"");
						   finalList.add(list);
					   }
				   }
				   break;
				   
			   case "disliked_video_yt":
				   fileName="Most Dislike Videos Youtube ";
				   headingList.add("Image URL");
				   headingList.add("Article Title");
				   headingList.add("Article Author");
				   headingList.add("View Count");
				   headingList.add("Like Count");
				   headingList.add("Dislike Count");
				   headingList.add("Comment Count");
				   finalList.add(headingList);
				   
				   dashActiveEntity = dashBoardManager.dashArticles(tweeterActionVo);
				   for(TwitterVo twitterVo : dashActiveEntity) {
					   if(twitterVo.getYoutube() != null) {
						   ArrayList<String> list = new ArrayList<String>();
						   list.add(twitterVo.getArticleMedia()==null?"":twitterVo.getArticleMedia().size()>0?twitterVo.getArticleMedia().get(0).getMediaThumbnail():"");
						   list.add(twitterVo.getArticleTitle());
						   list.add(twitterVo.getArticleAuthor());
						   list.add(twitterVo.getYoutube()==null?"":twitterVo.getYoutube().getYtViewCount()+"");
						   list.add(twitterVo.getYoutube()==null?"":twitterVo.getYoutube().getYtLikeCount()+"");
						   list.add(twitterVo.getYoutube()==null?"":twitterVo.getYoutube().getYtDisLikeCount()+"");
						   list.add(twitterVo.getYoutube()==null?"":twitterVo.getYoutube().getYtCommentCount()+"");
						   finalList.add(list);
					   }
				   }
				   break;
				   
			   case "viewed_video_yt":
				   fileName="Viewed Videos Youtube ";
				   headingList.add("Image URL");
				   headingList.add("Article Title");
				   headingList.add("Article Author");
				   headingList.add("View Count");
				   headingList.add("Like Count");
				   headingList.add("Dislike Count");
				   headingList.add("Comment Count");
				   finalList.add(headingList);
				   
				   dashActiveEntity = dashBoardManager.dashArticles(tweeterActionVo);
				   for(TwitterVo twitterVo : dashActiveEntity) {
					   if(twitterVo.getYoutube() != null) {
						   ArrayList<String> list = new ArrayList<String>();
						   list.add(twitterVo.getArticleMedia()==null?"":twitterVo.getArticleMedia().size()>0?twitterVo.getArticleMedia().get(0).getMediaThumbnail():"");
						   list.add(twitterVo.getArticleTitle());
						   list.add(twitterVo.getArticleAuthor());
						   list.add(twitterVo.getYoutube()==null?"":twitterVo.getYoutube().getYtViewCount()+"");
						   list.add(twitterVo.getYoutube()==null?"":twitterVo.getYoutube().getYtLikeCount()+"");
						   list.add(twitterVo.getYoutube()==null?"":twitterVo.getYoutube().getYtDisLikeCount()+"");
						   list.add(twitterVo.getYoutube()==null?"":twitterVo.getYoutube().getYtCommentCount()+"");
						   finalList.add(list);
					   }
				   }
				   break;
				   
			   case "commented_video_yt":
				   fileName="Commented Videos Youtube ";
				   headingList.add("Image URL");
				   headingList.add("Article Title");
				   headingList.add("Article Author");
				   headingList.add("View Count");
				   headingList.add("Like Count");
				   headingList.add("Dislike Count");
				   headingList.add("Comment Count");
				   finalList.add(headingList);
				   
				   dashActiveEntity = dashBoardManager.dashArticles(tweeterActionVo);
				   for(TwitterVo twitterVo : dashActiveEntity) {
					   if(twitterVo.getYoutube() != null) {
						   ArrayList<String> list = new ArrayList<String>();
						   list.add(twitterVo.getArticleMedia()==null?"":twitterVo.getArticleMedia().size()>0?twitterVo.getArticleMedia().get(0).getMediaThumbnail():"");
						   list.add(twitterVo.getArticleTitle());
						   list.add(twitterVo.getArticleAuthor());
						   list.add(twitterVo.getYoutube()==null?"":twitterVo.getYoutube().getYtViewCount()+"");
						   list.add(twitterVo.getYoutube()==null?"":twitterVo.getYoutube().getYtLikeCount()+"");
						   list.add(twitterVo.getYoutube()==null?"":twitterVo.getYoutube().getYtDisLikeCount()+"");
						   list.add(twitterVo.getYoutube()==null?"":twitterVo.getYoutube().getYtCommentCount()+"");
						   finalList.add(list);
					   }
				   }
				   break;
				   
			   case "latest_post_fb":
				   fileName="Latest Post FB ";
				   headingList.add("Image URL");
				   headingList.add("Article Author");
				   headingList.add("Published Date");
				   headingList.add("Content");
				   headingList.add("Like Count");
				   headingList.add("Comment Count");
				   headingList.add("Share Count");
				   finalList.add(headingList);
				   
				   dashActiveEntity = dashBoardManager.dashArticles(tweeterActionVo);
				   for(TwitterVo twitterVo : dashActiveEntity) {
					   if(twitterVo.getFacebook() != null) {
						   ArrayList<String> list = new ArrayList<String>();
						   list.add(twitterVo.getArticleAuthorImage());
						   list.add(twitterVo.getArticleAuthor());
						   list.add(twitterVo.getArticlePublishDate());
						   list.add(twitterVo.getArticleTitle());
						   list.add(twitterVo.getFacebook().getFbPostLikeCount()+"");
						   list.add(twitterVo.getFacebook().getFbPostCommentCount()+"");
						   list.add(twitterVo.getFacebook().getFbPostShareCount()+"");
						   finalList.add(list);
					   }
				   }
				   break;
				   
			   case "max_shared_count_fb":
				   fileName="Most Shared Post FB ";
				   headingList.add("Image URL");
				   headingList.add("Article Author");
				   headingList.add("Published Date");
				   headingList.add("Content");
				   headingList.add("Like Count");
				   headingList.add("Comment Count");
				   headingList.add("Share Count");
				   finalList.add(headingList);
				   
				   dashActiveEntity = dashBoardManager.dashArticles(tweeterActionVo);
				   for(TwitterVo twitterVo : dashActiveEntity) {
					   if(twitterVo.getFacebook() != null) {
						   ArrayList<String> list = new ArrayList<String>();
						   list.add(twitterVo.getArticleAuthorImage());
						   list.add(twitterVo.getArticleAuthor());
						   list.add(twitterVo.getArticlePublishDate());
						   list.add(twitterVo.getArticleTitle());
						   list.add(twitterVo.getFacebook().getFbPostLikeCount()+"");
						   list.add(twitterVo.getFacebook().getFbPostCommentCount()+"");
						   list.add(twitterVo.getFacebook().getFbPostShareCount()+"");
						   finalList.add(list);
					   }
				   }
				   break;
				   
			   case "max_liked_count_fb":
				   fileName="Most Liked Post FB ";
				   headingList.add("Image URL");
				   headingList.add("Article Author");
				   headingList.add("Published Date");
				   headingList.add("Content");
				   headingList.add("Like Count");
				   headingList.add("Comment Count");
				   headingList.add("Share Count");
				   finalList.add(headingList);
				   
				   dashActiveEntity = dashBoardManager.dashArticles(tweeterActionVo);
				   for(TwitterVo twitterVo : dashActiveEntity) {
					   if(twitterVo.getFacebook() != null) {
						   ArrayList<String> list = new ArrayList<String>();
						   list.add(twitterVo.getArticleAuthorImage());
						   list.add(twitterVo.getArticleAuthor());
						   list.add(twitterVo.getArticlePublishDate());
						   list.add(twitterVo.getArticleTitle());
						   list.add(twitterVo.getFacebook().getFbPostLikeCount()+"");
						   list.add(twitterVo.getFacebook().getFbPostCommentCount()+"");
						   list.add(twitterVo.getFacebook().getFbPostShareCount()+"");
						   finalList.add(list);
					   }
				   }
				   break;
				   
			   case "max_comment_count_fb":
				   fileName="Most Comment Post FB ";
				   headingList.add("Image URL");
				   headingList.add("Article Author");
				   headingList.add("Published Date");
				   headingList.add("Content");
				   headingList.add("Like Count");
				   headingList.add("Comment Count");
				   headingList.add("Share Count");
				   finalList.add(headingList);
				   
				   dashActiveEntity = dashBoardManager.dashArticles(tweeterActionVo);
				   for(TwitterVo twitterVo : dashActiveEntity) {
					   if(twitterVo.getFacebook() != null) {
						   ArrayList<String> list = new ArrayList<String>();
						   list.add(twitterVo.getArticleAuthorImage());
						   list.add(twitterVo.getArticleAuthor());
						   list.add(twitterVo.getArticlePublishDate());
						   list.add(twitterVo.getArticleTitle());
						   list.add(twitterVo.getFacebook().getFbPostLikeCount()+"");
						   list.add(twitterVo.getFacebook().getFbPostCommentCount()+"");
						   list.add(twitterVo.getFacebook().getFbPostShareCount()+"");
						   finalList.add(list);
					   }
				   }
				   break;
				   
			   case "doc_emotion_ml":
				   fileName="Document Emotions ";
				   headingList.add("Emotions");
				   headingList.add("Count");
				   finalList.add(headingList);
				   ArrayList<TwitterVo> emotions= tweetManagerInn.getEmotions(tweeterActionVo);
				   for(TwitterVo twitterVo : emotions) {

					   ArrayList<String> list = new ArrayList<String>();
					   list.add(twitterVo.getHashtag());
					   list.add(twitterVo.getHashCount());
					   finalList.add(list);
					 
				  }
				   break;
			   
			   case "doc_classification_ml":
				   fileName="Document Classification";
				   headingList.add("Classifications");
				   headingList.add("Count");
				   finalList.add(headingList);
				   ArrayList<TwitterVo> classifications= tweetManagerInn.getClassification(tweeterActionVo);
				   for(TwitterVo twitterVo : classifications) {

					   ArrayList<String> list = new ArrayList<String>();
					   list.add(twitterVo.getHashtag());
					   list.add(twitterVo.getHashCount());
					   finalList.add(list);
					 
				  }
				   break;
				   
			   case "doc_sentiment_overall_ml":
				   fileName="Overall Sentiment";
				   headingList.add("Sentiment");
				   headingList.add("Count");
				   finalList.add(headingList);
				   ArrayList<TwitterVo> dashActiveEntity1d= tweetManagerInn.getSentiment(tweeterActionVo);
				   for(TwitterVo twitterVo : dashActiveEntity1d) {

					   ArrayList<String> list = new ArrayList<String>();
					   String docType="";
					   switch(twitterVo.getSentiment())
					    {
						case "0":
							docType="Neutral";
							break;
						case "-1":
							docType="Negetive";
							break;
						case "1":
							docType="Positive";
							break;
						default:
						//	docFlag=false;
							break;					
					    }
					   list.add(docType);
					   list.add(twitterVo.getCount());
					   finalList.add(list);					 
				  }
				   break;
				   
			   case "top_calender_ml":
				   fileName="Event Calendar ";
				   headingList.add("Date");
				   headingList.add("Event");
				   headingList.add("Count");
				   finalList.add(headingList);
				   ArrayList<KeyMapVo> dashActiveEntity1= tweetManagerInn.getAllTredingDateWithTheme360(tweeterActionVo);
				   for(KeyMapVo twitterVo : dashActiveEntity1) {
					  Set<Entry<String, String>> fg= twitterVo.getMap().entrySet();
					  for (Iterator iterator = fg.iterator(); iterator.hasNext();) {
						   ArrayList<String> list = new ArrayList<String>();
						Entry<String, String> entry = (Entry<String, String>) iterator.next();
						   list.add(twitterVo.getKey());
						   list.add(entry.getKey());
						   list.add(entry.getValue());
						   finalList.add(list);		
					}
				  }
				   break;
				   
			   case "only_tweet_tw":
				   fileName="Tweet ";
				   headingList.add("Image Url");
				   headingList.add("Screen Name");
				   headingList.add("Handler");
				   headingList.add("Title");
				   headingList.add("Published Date");
				   headingList.add("Follower Count");
				   headingList.add("Friend Count");
				   headingList.add("Tweet Count");
				   headingList.add("Like Count");
				   headingList.add("Retweet Count");
				   finalList.add(headingList);
				   
				   dashActiveEntity= dashBoardManager.dashArticles(tweeterActionVo);
				   for(TwitterVo twitterVo : dashActiveEntity) {
					   ArrayList<String> list = new ArrayList<String>();
					   if(twitterVo.getTweet()!=null && twitterVo.getTweet().getTweetUser()!=null) {
						   list.add(twitterVo.getArticleAuthorImage());
						   list.add(twitterVo.getTweet().getTweetUser().getTweetUserScreenName()==null?"":twitterVo.getTweet().getTweetUser().getTweetUserScreenName());
						   list.add(twitterVo.getTweet().getTweetUser().getTweetUserScreenName()==null?"":"https://twitter.com/"+twitterVo.getTweet().getTweetUser().getTweetUserScreenName());
						   list.add(twitterVo.getArticleTitle()==null?"":twitterVo.getArticleTitle());
						   list.add(twitterVo.getArticlePublishDate()==null?"":twitterVo.getArticlePublishDate());
						   list.add(twitterVo.getTweet().getTweetUser().getTweetUserFollowersCount()+"");
						   list.add(twitterVo.getTweet().getTweetUser().getTweetUserFriendsCount()+"");
						   list.add(twitterVo.getTweet().getTweetUser().getTweetUserStatusCount()+"");
						   list.add(twitterVo.getTweet().getTweetUser().getTweetUserFavouriteCount()+"");
						   list.add(twitterVo.getTweet().getTweetRetweetCount()+"");
						   finalList.add(list);
					   }					   	
				   }
				   break;
				   
			   case "only_retweet_tw":
				   fileName="Retweet ";
				   headingList.add("Image Url");
				   headingList.add("Screen Name");
				   headingList.add("Handler");
				   headingList.add("Title");
				   headingList.add("Published Date");
				   headingList.add("Follower Count");
				   headingList.add("Friend Count");
				   headingList.add("Tweet Count");
				   headingList.add("Like Count");
				   headingList.add("Retweet Count");
				   finalList.add(headingList);
				   
				   dashActiveEntity= dashBoardManager.dashArticles(tweeterActionVo);
				   for(TwitterVo twitterVo : dashActiveEntity) {
					   ArrayList<String> list = new ArrayList<String>();
					   if(twitterVo.getTweet()!=null && twitterVo.getTweet().getTweetUser()!=null) {
						   list.add(twitterVo.getArticleAuthorImage());
						   list.add(twitterVo.getTweet().getTweetUser().getTweetUserScreenName()==null?"":twitterVo.getTweet().getTweetUser().getTweetUserScreenName());
						   list.add(twitterVo.getTweet().getTweetUser().getTweetUserScreenName()==null?"":"https://twitter.com/"+twitterVo.getTweet().getTweetUser().getTweetUserScreenName());
						   list.add(twitterVo.getArticleTitle()==null?"":twitterVo.getArticleTitle());
						   list.add(twitterVo.getArticlePublishDate()==null?"":twitterVo.getArticlePublishDate());
						   list.add(twitterVo.getTweet().getTweetUser().getTweetUserFollowersCount()+"");
						   list.add(twitterVo.getTweet().getTweetUser().getTweetUserFriendsCount()+"");
						   list.add(twitterVo.getTweet().getTweetUser().getTweetUserStatusCount()+"");
						   list.add(twitterVo.getTweet().getTweetUser().getTweetUserFavouriteCount()+"");
						   list.add(twitterVo.getTweet().getTweetRetweetCount()+"");
						   finalList.add(list);
					   }					   	
				   }
				   break;
				   
			   case "total_analysis_stats":
				   fileName="total_analysis_stats ";
				   headingList.add("Name");
				   headingList.add("Count");
				   finalList.add(headingList);
				 ArrayList<String> valueslist=  tweeterActionVo.getEntityIds();
				 for (String string : valueslist) {
					String[] arrOfStr = string.split("#"); 
			        ArrayList<String> list1 = new ArrayList<String>();
					   list1.add(arrOfStr[0]);
					   list1.add(arrOfStr[1]);
					   finalList.add(list1);
				}
				   break;
				   			   				   
				   
			   case "raw_data_cmm":
				   break;
				   
			  
				   
			   case "day_of_week_wtsap":
				   fileName="Daily Activity Count";
				   headingList.add("Day");
				   headingList.add("Count");
				   finalList.add(headingList);
				   
				   dashActiveEntity= tweetManagerInn.getTimeLineDayOfWeek(tweeterActionVo);
				   for(TwitterVo twitterVo : dashActiveEntity) {
					   ArrayList<String> list = new ArrayList<String>();
					   list.add(twitterVo.getCreatedAt());
					   list.add(twitterVo.getCount());
					   finalList.add(list);
				   }
				   break;
				   
			   case "hour_of_day_wtsap":
				   fileName="Hourly Activity Count";
				   headingList.add("Hour");
				   headingList.add("Count");
				   finalList.add(headingList);
				   
				   dashActiveEntity= tweetManagerInn.getTimeLineDayOfHour(tweeterActionVo);
				   for(TwitterVo twitterVo : dashActiveEntity) {
					   ArrayList<String> list = new ArrayList<String>();
					   SimpleDateFormat parseFormat = new SimpleDateFormat("hh");
			              int ok=Integer.parseInt(twitterVo.getCreatedAt());
			              String pmam="";
			              if (ok<=11){
			            	  pmam="am";
			              }
			              else {
			            	  pmam="pm";
						}
			              Date date = parseFormat.parse(String.valueOf(ok));
					   list.add(parseFormat.format(date)+pmam);
					   list.add(twitterVo.getCount());
					   finalList.add(list);
				   }
				   break;
				   
			   case "keywords_wtsap":
				   fileName="Word Cloud ";
				   headingList.add("Keyword");
				   headingList.add("Count");
				   finalList.add(headingList);
				   
				   dashActiveEntity= tweetManagerInn.getThemeWordCloud(tweeterActionVo);
				   for(TwitterVo twitterVo : dashActiveEntity) {
					 List<WordFrequency> kl=  twitterVo.getWordFrequencies();
					 for (WordFrequency wordFrequency : kl) {
						   ArrayList<String> list = new ArrayList<String>();
						   list.add(wordFrequency.getWord());
						   list.add(String.valueOf(wordFrequency.getFrequency()));
						   finalList.add(list);
					  }
				   }
				   break;
				   
			   case "positive_keywords_wtsap":
				   fileName="Positive Word Cloud ";
				   headingList.add("Keyword");
				   headingList.add("Count");
				   finalList.add(headingList);
				   
				   dashActiveEntity= tweetManagerInn.getThemeWordCloud(tweeterActionVo);
				   for(TwitterVo twitterVo : dashActiveEntity) {
					 List<WordFrequency> kl=  twitterVo.getWordFrequencies();
					 for (WordFrequency wordFrequency : kl) {
						   ArrayList<String> list = new ArrayList<String>();
						   list.add(wordFrequency.getWord());
						   list.add(String.valueOf(wordFrequency.getFrequency()));
						   finalList.add(list);
					  }
				   }
				   break;
				   
			   case "negative_keywords_wtsap":
				   fileName="Negative Word Cloud ";
				   headingList.add("Keyword");
				   headingList.add("Count");
				   finalList.add(headingList);
				   
				   dashActiveEntity= tweetManagerInn.getThemeWordCloud(tweeterActionVo);
				   for(TwitterVo twitterVo : dashActiveEntity) {
					 List<WordFrequency> kl=  twitterVo.getWordFrequencies();
					 for (WordFrequency wordFrequency : kl) {
						   ArrayList<String> list = new ArrayList<String>();
						   list.add(wordFrequency.getWord());
						   list.add(String.valueOf(wordFrequency.getFrequency()));
						   finalList.add(list);
					  }
				   }
				   break;
				   
			 
			}
			
//			mp.put("widgetReportData", finalList);
//			mp.put("headingData", fileName);
		
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return excelExportWidgetDataReport.buildExcelDocument(finalList, fileName, response);
	}
	
}