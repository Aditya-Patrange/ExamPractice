package com.cdac.sudarshan.discover.model;

import java.io.Serializable;

public class Fb_Comment implements Serializable 
{
	private static final long serialVersionUID = 1L;
	private String commentId;
	private String commentUserId;
	private String commentUserName;
	private String commentMessage;
	private String commentLikecount;
	private long commentCreatedTime;
	
	public String getCommentId() {
		return commentId;
	}
	public void setCommentId(String commentId) {
		this.commentId = commentId;
	}
	public String getCommentMessage() {
		return commentMessage;
	}
	public void setCommentMessage(String commentMessage) {
		this.commentMessage = commentMessage;
	}
	public String getCommentLikecount() {
		return commentLikecount;
	}
	public void setCommentLikecount(String commentLikecount) {
		this.commentLikecount = commentLikecount;
	}
	public long getCommentCreatedTime() {
		return commentCreatedTime;
	}
	public void setCommentCreatedTime(long commentCreatedTime) {
		this.commentCreatedTime = commentCreatedTime;
	}
	public String getCommentUserId() {
		return commentUserId;
	}
	public void setCommentUserId(String commentUserId) {
		this.commentUserId = commentUserId;
	}
	public String getCommentUserName() {
		return commentUserName;
	}
	public void setCommentUserName(String commentUserName) {
		this.commentUserName = commentUserName;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "Fb_Comment [commentId=" + commentId + ", commentUserId=" + commentUserId + ", commentUserName="
				+ commentUserName + ", commentMessage=" + commentMessage + ", commentLikecount=" + commentLikecount
				+ ", commentCreatedTime=" + commentCreatedTime + "]";
	}
	
}
