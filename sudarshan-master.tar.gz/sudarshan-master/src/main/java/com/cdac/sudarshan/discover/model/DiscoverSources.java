package com.cdac.sudarshan.discover.model;

import javax.persistence.Entity;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Entity
@Setter
@Getter
@RequiredArgsConstructor
public class DiscoverSources  extends BaseEntity{
	private String sourceList;
	
}
