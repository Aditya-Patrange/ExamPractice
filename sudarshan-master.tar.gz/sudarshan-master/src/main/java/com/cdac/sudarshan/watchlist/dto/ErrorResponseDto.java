package com.cdac.sudarshan.watchlist.dto;

import java.time.Instant;

public class ErrorResponseDto {
	private String errorMessage;
	private String errorDescription;
	private Instant timeStamp;
	public ErrorResponseDto(String errorMessage, String errorDescription) {
		super();
		this.errorMessage = errorMessage;
		this.errorDescription = errorDescription;
		this.timeStamp = Instant.now();
	}
	public ErrorResponseDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "ErrorResponseDto [errorMessage=" + errorMessage + ", errorDescription=" + errorDescription
				+ ", timeStamp=" + timeStamp + "]";
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public String getErrorDescription() {
		return errorDescription;
	}
	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}
	public Instant getTimeStamp() {
		return timeStamp;
	}
	

	
}
