package com.cdac.sudarshan.discover.model;

public class TwitterKloutVo {
String nick,bucket,dayChange,monthChange,weekChange,score,kType;

public String getNick() {
    return nick;
}

public void setNick(String nick) {
    this.nick = nick;
}

public String getBucket() {
    return bucket;
}

public void setBucket(String bucket) {
    this.bucket = bucket;
}

public String getDayChange() {
    return dayChange;
}

public void setDayChange(String dayChange) {
    this.dayChange = dayChange;
}

public String getMonthChange() {
    return monthChange;
}

public void setMonthChange(String monthChange) {
    this.monthChange = monthChange;
}

public String getWeekChange() {
    return weekChange;
}

public void setWeekChange(String weekChange) {
    this.weekChange = weekChange;
}

public String getScore() {
    return score;
}

public void setScore(String score) {
    this.score = score;
}

public String getkType() {
    return kType;
}

public void setkType(String kType) {
    this.kType = kType;
}
public TwitterKloutVo(){};
public TwitterKloutVo(String nick, String bucket, String dayChange,
	String monthChange, String weekChange, String score, String kType) {
    this.nick = nick;
    this.bucket = bucket;
    this.dayChange = dayChange;
    this.monthChange = monthChange;
    this.weekChange = weekChange;
    this.score = score;
    this.kType = kType;
}

}
