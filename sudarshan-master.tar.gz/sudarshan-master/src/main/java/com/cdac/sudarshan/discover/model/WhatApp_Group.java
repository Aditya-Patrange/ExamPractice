package com.cdac.sudarshan.discover.model;

import java.io.Serializable;

public class WhatApp_Group  implements Serializable
{
	private static final long serialVersionUID = 1L;
	private String groupName;
    private String groupId;
    private String groupCreatedBy;
    private String groupStatus;
    private String groupImage;
    private long groupCreatedAt;
   
    public String getGroupName() 
    {
	    return groupName;
    }
	public void setGroupName(String groupName) 
	{
		this.groupName = groupName;
	}
	public String getGroupId() 
	{
		return groupId;
	}
	public void setGroupId(String groupId) 
	{
		this.groupId = groupId;
	}
	public String getGroupCreatedBy() 
	{
		return groupCreatedBy;
	}
	public void setGroupCreatedBy(String groupCreatedBy)
	{
		this.groupCreatedBy = groupCreatedBy;
	}
	public String getGroupStatus() 
	{
		return groupStatus;
	}
	public void setGroupStatus(String groupStatus) 
	{
		this.groupStatus = groupStatus;
	}
	public long getGroupCreatedAt() 
	{
		return groupCreatedAt;
	}
	public void setGroupCreatedAt(long groupCreatedAt)
	{
		this.groupCreatedAt = groupCreatedAt;
	}
	public String getGroupImage() 
	{
		return groupImage;
	}
	public void setGroupImage(String groupImage)
	{
		this.groupImage = groupImage;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() 
	{
		return "WhatApp_Group [groupName=" + groupName + ", groupId=" + groupId + ", groupCreatedBy=" + groupCreatedBy
				+ ", groupStatus=" + groupStatus + ", groupCreatedAt=" + groupCreatedAt + ", groupImage=" + groupImage
				+ "]";
	}
}



