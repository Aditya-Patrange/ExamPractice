package com.cdac.sudarshan.discover.model;

public class TwitterPMFollow {
	private int id;
	private int screenId;
	private String followName;
	private String relationshipType;
	private String status;
	private java.sql.Timestamp creationDate;
	private String createdBy;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getScreenId() {
		return screenId;
	}
	public void setScreenId(int screenId) {
		this.screenId = screenId;
	}
	public String getFollowName() {
		return followName;
	}
	public void setFollowName(String followName) {
		this.followName = followName;
	}
	public String getRelationshipType() {
		return relationshipType;
	}
	public void setRelationshipType(String relationshipType) {
		this.relationshipType = relationshipType;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public java.sql.Timestamp getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(java.sql.Timestamp creationDate) {
		this.creationDate = creationDate;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	
	@Override
	public String toString() {
		return "TwitterPMFollow [id=" + id + ", screenId=" + screenId + ", followName=" + followName
				+ ", relationshipType=" + relationshipType + ", status=" + status + ", creationDate=" + creationDate
				+ ", createdBy=" + createdBy + "]";
	}
}
