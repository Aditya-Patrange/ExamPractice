package com.cdac.sudarshan.entityprofiles.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.cdac.sudarshan.authentication.model.User;
import com.cdac.sudarshan.folder.model.UrlsPath;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "entity_profiles")
@Getter
@Setter
@Data
@AllArgsConstructor
@NoArgsConstructor
public class EntityProfile {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	@Column
	private String name;
	@Column
	private LocalDate dateOfBirth;
	@ManyToOne
	@JsonIgnore
	private User user;
	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(
			  name = "entity_profile_urlspath", 
			  joinColumns = @JoinColumn(name = "entity_profile_id"), 
			  inverseJoinColumns = @JoinColumn(name = "urls_path_id"))
	private List<UrlsPath> urlsPaths = new ArrayList<>();
}
