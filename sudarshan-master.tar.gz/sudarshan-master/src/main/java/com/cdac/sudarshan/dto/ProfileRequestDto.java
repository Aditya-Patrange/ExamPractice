package com.cdac.sudarshan.dto;

import com.cdac.sudarshan.folder.model.UrlsPath;

import java.util.List;


public class ProfileRequestDto {

	private List<UrlsPath> list;

	private int size;

	private String tag;

	private String profileId;

}
