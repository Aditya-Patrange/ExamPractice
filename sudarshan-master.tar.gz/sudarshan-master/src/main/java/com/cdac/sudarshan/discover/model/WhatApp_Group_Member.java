package com.cdac.sudarshan.discover.model;

import java.io.Serializable;

public class WhatApp_Group_Member  implements Serializable
{
	private static final long serialVersionUID = 1L;
	private String groupMemberName;
	private String groupMemberPhone;
	private String groupMemberImg;
	private String groupMemberStatus;
	
	public String getGroupMemberName() 
	{
		return groupMemberName;
	}
	public void setGroupMemberName(String groupMemberName)
	{
		this.groupMemberName = groupMemberName;
	}
	public String getGroupMemberPhone()
	{
		return groupMemberPhone;
	}
	public void setGroupMemberPhone(String groupMemberPhone) 
	{
		this.groupMemberPhone = groupMemberPhone;
	}
	public String getGroupMemberImg() 
	{
		return groupMemberImg;
	}
	public void setGroupMemberImg(String groupMemberImg) 
	{
		this.groupMemberImg = groupMemberImg;
	}
	public String getGroupMemberStatus() 
	{
		return groupMemberStatus;
	}
	public void setGroupMemberStatus(String groupMemberStatus) 
	{
		this.groupMemberStatus = groupMemberStatus;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() 
	{
		return "WhatApp_Group_Member [groupMemberName=" + groupMemberName + ", groupMemberPhone=" + groupMemberPhone
				+ ", groupMemberImg=" + groupMemberImg + ", groupMemberStatus=" + groupMemberStatus + "]";
	}
}
