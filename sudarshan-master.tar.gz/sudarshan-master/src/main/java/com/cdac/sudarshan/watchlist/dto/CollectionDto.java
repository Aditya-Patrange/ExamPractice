package com.cdac.sudarshan.watchlist.dto;


import org.springframework.stereotype.Component;

import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
@Component
public class CollectionDto {

	private String collectionType;
	private String clientId;
	private String userId;
	private String activationDate;
	private String deactivationDate;
	private String hasAnalysis;
	private String analysisName;
	private String priority;
	private KeywordDto keyword;
	
}
