package com.cdac.sudarshan.discover.model;
import java.io.Serializable;
import java.util.ArrayList;

public class Article_Datacollection implements Serializable 
{
	private static final long serialVersionUID = 1L;
	private String id;
	private ArrayList<String> entityId;
	private long articleDate;
	private long articleUpdateDate;
	private String title;
	private String subTitle;
	private String author;
	private String authorId;
	private String sourceArticle;
	private String urlArticle;
	private String content;
	private String mdval;
	private String webArticleType;
	private String setProfilePicAuthor;
	private String sourceArticleImage;
	private ArrayList<String> articleImage;
	private int sentiment=9;
	private int nerStatus=0;
	private int contFlag=0;
	private ArrayList<String> locationNer=new  ArrayList<String>();
	private ArrayList<String> moneyNer=new  ArrayList<String>();
	private ArrayList<String> dateNer=new  ArrayList<String>();
	private ArrayList<String> organizationNer=new  ArrayList<String>();
	private ArrayList<String> personNer=new  ArrayList<String>();
	private ArrayList<String> timeNer=new  ArrayList<String>();
	private ArrayList<String> percentNer=new  ArrayList<String>();
	private ArrayList<String> priority=new ArrayList<String>();
	private ArrayList<String> articleHashTags;
	private ArrayList<String> articleMention;
	private ArrayList<CommonCommentVo> articleComments;
	private int articleCommentCount;
	private int articleReshareCount;
	private int articlePlusOneCount;
	private String articleRawContent;
	private ArrayList<AttachmentVo> articleAttachment;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public ArrayList<String> getEntityId() {
		return entityId;
	}
	public void setEntityId(ArrayList<String> entityId) {
		this.entityId = entityId;
	}
	public long getArticleDate() {
		return articleDate;
	}
	public void setArticleDate(long articleDate) {
		this.articleDate = articleDate;
	}
	public long getArticleUpdateDate() {
		return articleUpdateDate;
	}
	public void setArticleUpdateDate(long articleUpdateDate) {
		this.articleUpdateDate = articleUpdateDate;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getSubTitle() {
		return subTitle;
	}
	public void setSubTitle(String subTitle) {
		this.subTitle = subTitle;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getAuthorId() {
		return authorId;
	}
	public void setAuthorId(String authorId) {
		this.authorId = authorId;
	}
	public String getSourceArticle() {
		return sourceArticle;
	}
	public void setSourceArticle(String sourceArticle) {
		this.sourceArticle = sourceArticle;
	}
	public String getUrlArticle() {
		return urlArticle;
	}
	public void setUrlArticle(String urlArticle) {
		this.urlArticle = urlArticle;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getMdval() {
		return mdval;
	}
	public void setMdval(String mdval) {
		this.mdval = mdval;
	}
	public String getWebArticleType() {
		return webArticleType;
	}
	public void setWebArticleType(String webArticleType) {
		this.webArticleType = webArticleType;
	}
	public String getSetProfilePicAuthor() {
		return setProfilePicAuthor;
	}
	public void setSetProfilePicAuthor(String setProfilePicAuthor) {
		this.setProfilePicAuthor = setProfilePicAuthor;
	}
	public String getSourceArticleImage() {
		return sourceArticleImage;
	}
	public void setSourceArticleImage(String sourceArticleImage) {
		this.sourceArticleImage = sourceArticleImage;
	}
	public ArrayList<String> getArticleImage() {
		return articleImage;
	}
	public void setArticleImage(ArrayList<String> articleImage) {
		this.articleImage = articleImage;
	}
	public int getSentiment() {
		return sentiment;
	}
	public void setSentiment(int sentiment) {
		this.sentiment = sentiment;
	}
	public int getNerStatus() {
		return nerStatus;
	}
	public void setNerStatus(int nerStatus) {
		this.nerStatus = nerStatus;
	}
	public int getContFlag() {
		return contFlag;
	}
	public void setContFlag(int contFlag) {
		this.contFlag = contFlag;
	}
	public ArrayList<String> getLocationNer() {
		return locationNer;
	}
	public void setLocationNer(ArrayList<String> locationNer) {
		this.locationNer = locationNer;
	}
	public ArrayList<String> getMoneyNer() {
		return moneyNer;
	}
	public void setMoneyNer(ArrayList<String> moneyNer) {
		this.moneyNer = moneyNer;
	}
	public ArrayList<String> getDateNer() {
		return dateNer;
	}
	public void setDateNer(ArrayList<String> dateNer) {
		this.dateNer = dateNer;
	}
	public ArrayList<String> getOrganizationNer() {
		return organizationNer;
	}
	public void setOrganizationNer(ArrayList<String> organizationNer) {
		this.organizationNer = organizationNer;
	}
	public ArrayList<String> getPersonNer() {
		return personNer;
	}
	public void setPersonNer(ArrayList<String> personNer) {
		this.personNer = personNer;
	}
	public ArrayList<String> getTimeNer() {
		return timeNer;
	}
	public void setTimeNer(ArrayList<String> timeNer) {
		this.timeNer = timeNer;
	}
	public ArrayList<String> getPercentNer() {
		return percentNer;
	}
	public void setPercentNer(ArrayList<String> percentNer) {
		this.percentNer = percentNer;
	}
	public ArrayList<String> getPriority() {
		return priority;
	}
	public void setPriority(ArrayList<String> priority) {
		this.priority = priority;
	}
	public ArrayList<String> getArticleHashTags() {
		return articleHashTags;
	}
	public void setArticleHashTags(ArrayList<String> articleHashTags) {
		this.articleHashTags = articleHashTags;
	}
	public ArrayList<String> getArticleMention() {
		return articleMention;
	}
	public void setArticleMention(ArrayList<String> articleMention) {
		this.articleMention = articleMention;
	}
	public ArrayList<CommonCommentVo> getArticleComments() {
		return articleComments;
	}
	public void setArticleComments(ArrayList<CommonCommentVo> articleComments) {
		this.articleComments = articleComments;
	}
	public int getArticleCommentCount() {
		return articleCommentCount;
	}
	public void setArticleCommentCount(int articleCommentCount) {
		this.articleCommentCount = articleCommentCount;
	}
	public int getArticleReshareCount() {
		return articleReshareCount;
	}
	public void setArticleReshareCount(int articleReshareCount) {
		this.articleReshareCount = articleReshareCount;
	}
	public int getArticlePlusOneCount() {
		return articlePlusOneCount;
	}
	public void setArticlePlusOneCount(int articlePlusOneCount) {
		this.articlePlusOneCount = articlePlusOneCount;
	}
	public String getArticleRawContent() {
		return articleRawContent;
	}
	public void setArticleRawContent(String articleRawContent) {
		this.articleRawContent = articleRawContent;
	}
	public ArrayList<AttachmentVo> getArticleAttachment() {
		return articleAttachment;
	}
	public void setArticleAttachment(ArrayList<AttachmentVo> articleAttachment) {
		this.articleAttachment = articleAttachment;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "Article_Datacollection [id=" + id + ", entityId=" + entityId + ", articleDate=" + articleDate
				+ ", articleUpdateDate=" + articleUpdateDate + ", title=" + title + ", subTitle=" + subTitle
				+ ", author=" + author + ", authorId=" + authorId + ", sourceArticle=" + sourceArticle + ", urlArticle="
				+ urlArticle + ", content=" + content + ", mdval=" + mdval + ", webArticleType=" + webArticleType
				+ ", setProfilePicAuthor=" + setProfilePicAuthor + ", sourceArticleImage=" + sourceArticleImage
				+ ", articleImage=" + articleImage + ", sentiment=" + sentiment + ", nerStatus=" + nerStatus
				+ ", contFlag=" + contFlag + ", locationNer=" + locationNer + ", moneyNer=" + moneyNer + ", dateNer="
				+ dateNer + ", organizationNer=" + organizationNer + ", personNer=" + personNer + ", timeNer=" + timeNer
				+ ", percentNer=" + percentNer + ", priority=" + priority + ", articleHashTags=" + articleHashTags
				+ ", articleMention=" + articleMention + ", articleComments=" + articleComments
				+ ", articleCommentCount=" + articleCommentCount + ", articleReshareCount=" + articleReshareCount
				+ ", articlePlusOneCount=" + articlePlusOneCount + ", articleRawContent=" + articleRawContent
				+ ", articleAttachment=" + articleAttachment + "]";
	}
	
}
