package com.cdac.sudarshan.theme.repository;

import com.cdac.sudarshan.theme.model.Keyword;
import com.cdac.sudarshan.theme.model.SubTheme;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IKeywordRepository extends JpaRepository<Keyword,Long> {



    List<Keyword> findBySubTheme(SubTheme subTheme);

    @Query(value = "select k from Keyword k where k.themeId = :rootThemeId")
    List<Keyword> findByRootThemeId(@Param("rootThemeId") Long rootThemeId);

    @Query(value = "select k from Keyword k where k.subTheme.id = :subThemeId")
    List<Keyword> findKeywordBySubFolderPathId(@Param("subThemeId") Long subFolderId);


}
