package com.cdac.sudarshan.alerts.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;

public class CaseVo implements Serializable
{
    private static final long serialVersionUID = 1L;
    private String caseName;
    private	String actType;
    private	String caseId;

    private	String snapShortId;
    private	String alertType;
    private	String noOfEntity;
    private ArrayList<EntityVo> lstEntityVos;
    private String entityFilter;
    private String entitySortName;
    private String entitySortDate;
    private String entitySortStatus;
    private String entitySearch;
    private String entityId;
    private String dateOfCreation;
    private String caseType;
    private String[] darkwebArray;
    private String[] darkwebKeywordArray;
    private String archivalFlag;
    private String arcivalDate;
    private String insertedStatus;
    private String insertedDate;
    private String archivalUpdationDate;
    private String archivalDataFlag;
    private int targetProfileId;
    private int targetOrganizationId;
    private String filter;
    private String txtSearch;
    private String sort;
    private String mark;
    private String rowNum;
    private String uid;
    private String notFilter;
    private String type;
    private String key1;
    private String key2;
    private String key3;
    private String key4;
    private String key5;
    private String key6;
    private String key7;
    private String key8;
    private String key9;
    private String key10;
    private String key11;
    private String key12;
    private String id;
    private String frequency;
    private String sentiment;
    private String countLimit;
    private String user;
    private String entityIdLst;
    private String active;
    private String blockDate;
    private String keyword;
    private String sourceType;
    private int categoryId;
    private String categoryName;
    private long profileMapCount;
    private String countryCode;
    private String statusType;
    private String entityType;
    private String fbType;
    private String twType;
    private String logText;
    public long logDate;
    public String userName;
    public String userId;
    public String syncStatus;
    public String globalClientId;
    public String addedFrom;
    public String isActive;
    public String accountBlockDate;
    public String accountType;
    public String autoIncKeyId;
    public String threatScore;
    public String dateFrom;
    public String dateTo;
    private String noTweet;
    private ArrayList<CentralAvatarVo> centralAvatarVo;

    public String getNoTweet() {
        return noTweet;
    }
    public void setNoTweet(String noTweet) {
        this.noTweet = noTweet;
    }
    public String getAlertType() {
        return alertType;
    }
    public void setAlertType(String alertType) {
        this.alertType = alertType;
    }
    public String getSnapShortId() {
        return snapShortId;
    }
    public void setSnapShortId(String snapShortId) {
        this.snapShortId = snapShortId;
    }
    public ArrayList<CentralAvatarVo> getCentralAvatarVo() {
        return centralAvatarVo;
    }
    public void setCentralAvatarVo(ArrayList<CentralAvatarVo> centralAvatarVo) {
        this.centralAvatarVo = centralAvatarVo;
    }

    public String getDateFrom() {
        return dateFrom;
    }
    public void setDateFrom(String dateFrom) {
        this.dateFrom = dateFrom;
    }
    public String getDateTo() {
        return dateTo;
    }
    public void setDateTo(String dateTo) {
        this.dateTo = dateTo;
    }
    public String getThreatScore() {
        return threatScore;
    }
    public void setThreatScore(String threatScore) {
        this.threatScore = threatScore;
    }
    public String getAutoIncKeyId() {
        return autoIncKeyId;
    }
    public void setAutoIncKeyId(String autoIncKeyId) {
        this.autoIncKeyId = autoIncKeyId;
    }
    public String getAddedFrom() {
        return addedFrom;
    }
    public void setAddedFrom(String addedFrom) {
        this.addedFrom = addedFrom;
    }
    public String getIsActive() {
        return isActive;
    }
    public void setIsActive(String isActive) {
        this.isActive = isActive;
    }
    public String getAccountBlockDate() {
        return accountBlockDate;
    }
    public void setAccountBlockDate(String accountBlockDate) {
        this.accountBlockDate = accountBlockDate;
    }
    public String getAccountType() {
        return accountType;
    }
    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }
    public String getUserName() {
        return userName;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
    public String getUserId() {
        return userId;
    }
    public void setUserId(String userId) {
        this.userId = userId;
    }
    public String getSyncStatus() {
        return syncStatus;
    }
    public void setSyncStatus(String syncStatus) {
        this.syncStatus = syncStatus;
    }
    public String getGlobalClientId() {
        return globalClientId;
    }
    public void setGlobalClientId(String globalClientId) {
        this.globalClientId = globalClientId;
    }
    public String getLogText() {
        return logText;
    }
    public void setLogText(String logText) {
        this.logText = logText;
    }
    public long getLogDate() {
        return logDate;
    }
    public void setLogDate(long logDate) {
        this.logDate = logDate;
    }
    private ArrayList<ArrayList<String>> alertDay;

    public String getStatusType() {
        return statusType;
    }
    public void setStatusType(String statusType) {
        this.statusType = statusType;
    }
    public String getEntityType() {
        return entityType;
    }
    public void setEntityType(String entityType) {
        this.entityType = entityType;
    }
    public String getFbType() {
        return fbType;
    }
    public void setFbType(String fbType) {
        this.fbType = fbType;
    }
    public String getTwType() {
        return twType;
    }
    public void setTwType(String twType) {
        this.twType = twType;
    }
    public String getCountryCode() {
        return countryCode;
    }
    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }
    public String getKeyword() {
        return keyword;
    }
    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }
    public String getSourceType() {
        return sourceType;
    }
    public void setSourceType(String sourceType) {
        this.sourceType = sourceType;
    }
    public ArrayList<ArrayList<String>> getAlertDay() {
        return alertDay;
    }
    public void setAlertDay(ArrayList<ArrayList<String>> alertDay) {
        this.alertDay = alertDay;
    }
    public static long getSerialversionuid() {
        return serialVersionUID;
    }
    public String[] getDarkwebArray() {
        return darkwebArray;
    }
    public void setDarkwebArray(String[] darkwebArray) {
        this.darkwebArray = darkwebArray;
    }
    public String[] getDarkwebKeywordArray() {
        return darkwebKeywordArray;
    }
    public void setDarkwebKeywordArray(String[] darkwebKeywordArray) {
        this.darkwebKeywordArray = darkwebKeywordArray;
    }
    public String getActive() {
        return active;
    }
    public void setActive(String active) {
        this.active = active;
    }
    public String getBlockDate() {
        return blockDate;
    }
    public void setBlockDate(String blockDate) {
        this.blockDate = blockDate;
    }
    public String getUser() {
        return user;
    }
    public void setUser(String user) {
        this.user = user;
    }
    public String getCountLimit() {
        return countLimit;
    }
    public void setCountLimit(String countLimit) {
        this.countLimit = countLimit;
    }
    public String getFrequency() {
        return frequency;
    }
    public void setFrequency(String frequency) {
        this.frequency = frequency;
    }
    public String getSentiment() {
        return sentiment;
    }
    public void setSentiment(String sentiment) {
        this.sentiment = sentiment;
    }
    public String getEntityIdLst() {
        return entityIdLst;
    }
    public void setEntityIdLst(String entityIdLst) {
        this.entityIdLst = entityIdLst;
    }
    public String getKey1() {
        return key1;
    }
    public void setKey1(String key1) {
        this.key1 = key1;
    }
    public String getKey2() {
        return key2;
    }
    public void setKey2(String key2) {
        this.key2 = key2;
    }
    public String getKey3() {
        return key3;
    }
    public void setKey3(String key3) {
        this.key3 = key3;
    }
    public String getKey7() {
        return key7;
    }
    public void setKey7(String key7) {
        this.key7 = key7;
    }
    public String getKey8() {
        return key8;
    }
    public void setKey8(String key8) {
        this.key8 = key8;
    }
    public String getKey9() {
        return key9;
    }
    public void setKey9(String key9) {
        this.key9 = key9;
    }
    public String getKey10() {
        return key10;
    }
    public void setKey10(String key10) {
        this.key10 = key10;
    }
    public String getKey11() {
        return key11;
    }
    public void setKey11(String key11) {
        this.key11 = key11;
    }
    public String getKey4() {
        return key4;
    }
    public void setKey4(String key4) {
        this.key4 = key4;
    }
    public String getKey5() {
        return key5;
    }
    public void setKey5(String key5) {
        this.key5 = key5;
    }
    public String getKey6() {
        return key6;
    }
    public void setKey6(String key6) {
        this.key6 = key6;
    }
    public String getKey12() {
        return key12;
    }
    public void setKey12(String key12) {
        this.key12 = key12;
    }
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }
    public String getNotFilter() {
        return notFilter;
    }
    public void setNotFilter(String notFilter) {
        this.notFilter = notFilter;
    }
    public String getUid() {
        return uid;
    }
    public void setUid(String uid) {
        this.uid = uid;
    }
    public String getRowNum() {
        return rowNum;
    }
    public void setRowNum(String rowNum) {
        this.rowNum = rowNum;
    }
    public String getMark() {
        return mark;
    }
    public void setMark(String mark) {
        this.mark = mark;
    }
    public String getTxtSearch() {
        return txtSearch;
    }
    public void setTxtSearch(String txtSearch) {
        this.txtSearch = txtSearch;
    }
    public String getSort() {
        return sort;
    }
    public void setSort(String sort) {
        this.sort = sort;
    }
    public String getFilter() {
        return filter;
    }
    public void setFilter(String filter) {
        this.filter = filter;
    }
    public String getDateOfCreation() {
        return dateOfCreation;
    }
    public void setDateOfCreation(String dateOfCreation) {
        this.dateOfCreation = dateOfCreation;
    }
    public String getCaseType() {
        return caseType;
    }
    public void setCaseType(String caseType) {
        this.caseType = caseType;
    }
    public String getEntityId() {
        return entityId;
    }
    public void setEntityId(String entityId) {
        this.entityId = entityId;
    }
    public String getEntitySearch() {
        return entitySearch;
    }
    public void setEntitySearch(String entitySearch) {
        this.entitySearch = entitySearch;
    }
    public String getEntitySortName() {
        return entitySortName;
    }
    public void setEntitySortName(String entitySortName) {
        this.entitySortName = entitySortName;
    }
    public String getEntitySortDate() {
        return entitySortDate;
    }
    public void setEntitySortDate(String entitySortDate) {
        this.entitySortDate = entitySortDate;
    }
    public String getEntitySortStatus() {
        return entitySortStatus;
    }
    public void setEntitySortStatus(String entitySortStatus) {
        this.entitySortStatus = entitySortStatus;
    }
    public String getEntityFilter() {
        return entityFilter;
    }
    public void setEntityFilter(String entityFilter) {
        this.entityFilter = entityFilter;
    }
    public ArrayList<EntityVo> getLstEntityVos() {
        return lstEntityVos;
    }
    public void setLstEntityVos(ArrayList<EntityVo> lstEntityVos) {
        this.lstEntityVos = lstEntityVos;
    }
    public String getCaseId() {
        return caseId;
    }
    public void setCaseId(String caseId) {
        this.caseId = caseId;
    }
    public String getActType() {
        return actType;
    }
    public void setActType(String actType) {
        this.actType = actType;
    }
    public String getCaseName() {
        return caseName;
    }
    public void setCaseName(String caseName) {
        this.caseName = caseName;
    }
    public CaseVo(){}
    public String getNoOfEntity() {
        return noOfEntity;
    }
    public void setNoOfEntity(String noOfEntity) {
        this.noOfEntity = noOfEntity;
    }
    public CaseVo(String caseName ,String caseId,String noOfEntity) {
        super();
        this.caseName = caseName;
        this.caseId = caseId;
        this.noOfEntity = noOfEntity;
    }
    public CaseVo(String caseName ,String caseId) {
        super();
        this.caseName = caseName;
        this.caseId = caseId;
    }
    public String getArchivalFlag()
    {
        return archivalFlag;
    }
    public void setArchivalFlag(String archivalFlag)
    {
        this.archivalFlag = archivalFlag;
    }
    public String getArcivalDate()
    {
        return arcivalDate;
    }
    public void setArcivalDate(String arcivalDate)
    {
        this.arcivalDate = arcivalDate;
    }

    public String getInsertedStatus()
    {
        return insertedStatus;
    }
    public void setInsertedStatus(String insertedStatus)
    {
        this.insertedStatus = insertedStatus;
    }

    public String getInsertedDate()
    {
        return insertedDate;
    }
    public void setInsertedDate(String insertedDate)
    {
        this.insertedDate = insertedDate;
    }

    public String getArchivalUpdationDate()
    {
        return archivalUpdationDate;
    }

    public void setArchivalUpdationDate(String archivalUpdationDate)
    {
        this.archivalUpdationDate = archivalUpdationDate;
    }

    public String getArchivalDataFlag()
    {
        return archivalDataFlag;
    }

    public void setArchivalDataFlag(String archivalDataFlag)
    {
        this.archivalDataFlag = archivalDataFlag;
    }

    public int getTargetProfileId()
    {
        return targetProfileId;
    }
    public void setTargetProfileId(int targetProfileId)
    {
        this.targetProfileId = targetProfileId;
    }

    public int getTargetOrganizationId()
    {
        return targetOrganizationId;
    }

    public void setTargetOrganizationId(int targetOrganizationId)
    {
        this.targetOrganizationId = targetOrganizationId;
    }
    public int getCategoryId()
    {
        return categoryId;
    }
    public void setCategoryId(int categoryId)
    {
        this.categoryId = categoryId;
    }
    public String getCategoryName()
    {
        return categoryName;
    }
    public void setCategoryName(String categoryName)
    {
        this.categoryName = categoryName;
    }
    public long getProfileMapCount()
    {
        return profileMapCount;
    }
    public void setProfileMapCount(long profileMapCount)
    {
        this.profileMapCount = profileMapCount;
    }
    @Override
    public String toString() {
        return "CaseVo [caseName=" + caseName + ", actType=" + actType + ", caseId=" + caseId + ", snapShortId="
                + snapShortId + ", alertType=" + alertType + ", noOfEntity=" + noOfEntity + ", lstEntityVos="
                + lstEntityVos + ", entityFilter=" + entityFilter + ", entitySortName=" + entitySortName
                + ", entitySortDate=" + entitySortDate + ", entitySortStatus=" + entitySortStatus + ", entitySearch="
                + entitySearch + ", entityId=" + entityId + ", dateOfCreation=" + dateOfCreation + ", caseType="
                + caseType + ", darkwebArray=" + Arrays.toString(darkwebArray) + ", darkwebKeywordArray="
                + Arrays.toString(darkwebKeywordArray) + ", archivalFlag=" + archivalFlag + ", arcivalDate="
                + arcivalDate + ", insertedStatus=" + insertedStatus + ", insertedDate=" + insertedDate
                + ", archivalUpdationDate=" + archivalUpdationDate + ", archivalDataFlag=" + archivalDataFlag
                + ", targetProfileId=" + targetProfileId + ", targetOrganizationId=" + targetOrganizationId
                + ", filter=" + filter + ", txtSearch=" + txtSearch + ", sort=" + sort + ", mark=" + mark + ", rowNum="
                + rowNum + ", uid=" + uid + ", notFilter=" + notFilter + ", type=" + type + ", key1=" + key1 + ", key2="
                + key2 + ", key3=" + key3 + ", key4=" + key4 + ", key5=" + key5 + ", key6=" + key6 + ", key7=" + key7
                + ", key8=" + key8 + ", key9=" + key9 + ", key10=" + key10 + ", key11=" + key11 + ", key12=" + key12
                + ", id=" + id + ", frequency=" + frequency + ", sentiment=" + sentiment + ", countLimit=" + countLimit
                + ", user=" + user + ", entityIdLst=" + entityIdLst + ", active=" + active + ", blockDate=" + blockDate
                + ", keyword=" + keyword + ", sourceType=" + sourceType + ", categoryId=" + categoryId
                + ", categoryName=" + categoryName + ", profileMapCount=" + profileMapCount + ", countryCode="
                + countryCode + ", statusType=" + statusType + ", entityType=" + entityType + ", fbType=" + fbType
                + ", twType=" + twType + ", logText=" + logText + ", logDate=" + logDate + ", userName=" + userName
                + ", userId=" + userId + ", syncStatus=" + syncStatus + ", globalClientId=" + globalClientId
                + ", addedFrom=" + addedFrom + ", isActive=" + isActive + ", accountBlockDate=" + accountBlockDate
                + ", accountType=" + accountType + ", autoIncKeyId=" + autoIncKeyId + ", threatScore=" + threatScore
                + ", dateFrom=" + dateFrom + ", dateTo=" + dateTo + ", noTweet=" + noTweet + ", centralAvatarVo="
                + centralAvatarVo + ", alertDay=" + alertDay + "]";
    }

}