package com.cdac.sudarshan.exception;

public class UserNameNotFoundException extends RuntimeException {

    private String message;

    public UserNameNotFoundException(String message) {
        super(message);
        this.message=message;
    }
}
