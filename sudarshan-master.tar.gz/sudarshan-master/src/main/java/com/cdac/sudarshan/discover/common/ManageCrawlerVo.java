package com.cdac.sudarshan.discover.common;

import java.util.Arrays;

public class ManageCrawlerVo 
{
	private String seedUrl;
	private String jobName;
	private String hasRecrawling;
	private String useProxy;
	private String startDate;
	private String endDate;
	private String domainRegex;
	private String depth;
	private String day;
	private String recrawlingDay;
	private String recrawlingHour;
	private String recrawlingMinute;
	private String recrawlingSecond;
	private String recrawlingFrequency;
	private String recrawlingInterval;
	private String maxRestartTry;
	private String restartInterval;
	private String id;
	private String proxyArray[];

	public String getDomainRegex() {
		return domainRegex;
	}
	public void setDomainRegex(String domainRegex) {
		this.domainRegex = domainRegex;
	}
	public String[] getProxyArray() {
		return proxyArray;
	}
	public String getUseProxy() {
		return useProxy;
	}
	public void setUseProxy(String useProxy) {
		this.useProxy = useProxy;
	}
	public void setProxyArray(String[] proxyArray) {
		this.proxyArray = proxyArray;
	}
	public String getHasRecrawling() {
		return hasRecrawling;
	}
	public void setHasRecrawling(String hasRecrawling) {
		this.hasRecrawling = hasRecrawling;
	}
	public String getMaxRestartTry() {
		return maxRestartTry;
	}
	public void setMaxRestartTry(String maxRestartTry) {
		this.maxRestartTry = maxRestartTry;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getSeedUrl() {
		return seedUrl;
	}
	public void setSeedUrl(String seedUrl) {
		this.seedUrl = seedUrl;
	}
	public String getJobName() {
		return jobName;
	}
	public void setJobName(String jobName) {
		this.jobName = jobName;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getDepth() {
		return depth;
	}
	public void setDepth(String depth) {
		this.depth = depth;
	}
	public String getDay() {
		return day;
	}
	public void setDay(String day) {
		this.day = day;
	}
	public String getRecrawlingDay() {
		return recrawlingDay;
	}
	public void setRecrawlingDay(String recrawlingDay) {
		this.recrawlingDay = recrawlingDay;
	}
	public String getRecrawlingHour() {
		return recrawlingHour;
	}
	public void setRecrawlingHour(String recrawlingHour) {
		this.recrawlingHour = recrawlingHour;
	}
	public String getRecrawlingMinute() {
		return recrawlingMinute;
	}
	public void setRecrawlingMinute(String recrawlingMinute) {
		this.recrawlingMinute = recrawlingMinute;
	}
	public String getRecrawlingSecond() {
		return recrawlingSecond;
	}
	public void setRecrawlingSecond(String recrawlingSecond) {
		this.recrawlingSecond = recrawlingSecond;
	}
	public String getRecrawlingFrequency() {
		return recrawlingFrequency;
	}
	public void setRecrawlingFrequency(String recrawlingFrequency) {
		this.recrawlingFrequency = recrawlingFrequency;
	}
	public String getRecrawlingInterval() {
		return recrawlingInterval;
	}
	public void setRecrawlingInterval(String recrawlingInterval) {
		this.recrawlingInterval = recrawlingInterval;
	}
	public String getRestartInterval() {
		return restartInterval;
	}
	public void setRestartInterval(String restartInterval) {
		this.restartInterval = restartInterval;
	}
	@Override
	public String toString() {
		return "ManageCrawlerVo [seedUrl=" + seedUrl + ", jobName=" + jobName + ", hasRecrawling=" + hasRecrawling
				+ ", useProxy=" + useProxy + ", startDate=" + startDate + ", endDate=" + endDate + ", domainRegex="
				+ domainRegex + ", depth=" + depth + ", day=" + day + ", recrawlingDay=" + recrawlingDay
				+ ", recrawlingHour=" + recrawlingHour + ", recrawlingMinute=" + recrawlingMinute
				+ ", recrawlingSecond=" + recrawlingSecond + ", recrawlingFrequency=" + recrawlingFrequency
				+ ", recrawlingInterval=" + recrawlingInterval + ", maxRestartTry=" + maxRestartTry
				+ ", restartInterval=" + restartInterval + ", id=" + id + ", proxyArray=" + Arrays.toString(proxyArray)
				+ "]";
	}
}
