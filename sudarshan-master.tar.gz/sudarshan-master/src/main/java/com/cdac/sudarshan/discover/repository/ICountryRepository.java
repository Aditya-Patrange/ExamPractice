package com.cdac.sudarshan.discover.repository;

import com.cdac.sudarshan.discover.projection.PhoneCodeProjection;
import org.springframework.data.jpa.repository.JpaRepository;

import com.cdac.sudarshan.discover.model.Country;
import org.springframework.data.jpa.repository.Query;

public interface ICountryRepository extends JpaRepository<Country, Integer>{
    @Query("select new com.cdac.sudarshan.discover.model.Country(c.phoneCode) from Country c where c.countryCode=:countryCode")
    PhoneCodeProjection getPhoneCodeByCountryCode(String countryCode);
    Country findByCountryCode(String countryCode);
}
