package com.cdac.sudarshan.folder.service;

import com.cdac.sudarshan.authentication.model.User;
import com.cdac.sudarshan.authentication.repository.UserRepository;
import com.cdac.sudarshan.authentication.service.IAuthService;
import com.cdac.sudarshan.authentication.service.IUserService;
import com.cdac.sudarshan.dto.UserFolderDTO;
import com.cdac.sudarshan.exception.DataAlreadyFoundException;
import com.cdac.sudarshan.exception.PathNotFoundException;
import com.cdac.sudarshan.exception.ResourceNotFoundException;
import com.cdac.sudarshan.folder.dto.RootFolderDto;
import com.cdac.sudarshan.folder.dto.SubFolderPathDto;
import com.cdac.sudarshan.folder.dto.UserDto;
import com.cdac.sudarshan.folder.model.RootFolder;
import com.cdac.sudarshan.folder.model.SubFolderPaths;
import com.cdac.sudarshan.folder.model.UrlsPath;
import com.cdac.sudarshan.folder.repository.RootFolderRepo;
import com.cdac.sudarshan.folder.repository.SubFolderPathsRepo;
import com.cdac.sudarshan.folder.repository.UrlsPathRepo;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class RootFolderServiceImpl implements IRootFolderService {

    @Autowired
    private RootFolderRepo rootFolderRepo;

    @Autowired
    private JdbcTemplate jdbcTemplateTwo;
    @Autowired
    private SubFolderPathsRepo subFolderPathsRepo;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private IUserService userService;

    @Autowired
    private UrlsPathRepo urlsPathRepo;

    @Autowired
    private IAuthService authService;

    @Override
    public RootFolder saveRootFolder(List<String> path) {
        //User mainUser = AuthController.mainUser;

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication.getName() == null) {
            throw new ResourceNotFoundException("Please Login first For adding folder");
        }

        User loggedInUser = userService.getUserByUserName(authentication.getName());

        if (path.isEmpty()) {
            throw new PathNotFoundException("Please Enter valid Path or path is empty");
        }

        RootFolder dbRootFolder = rootFolderRepo.findByRootFolderNameAndUser(path.get(0), loggedInUser);

        if (dbRootFolder == null) {
            RootFolder folderPath = new RootFolder();
            folderPath.setRootFolderName(path.get(0));
            folderPath.setUser(loggedInUser);
            folderPath.setStatus(true);
            return rootFolderRepo.save(folderPath);
        } else if (!dbRootFolder.isStatus()) {
            //checking root-folder already exist with given name and status is false
            dbRootFolder.setStatus(true);
            return rootFolderRepo.save(dbRootFolder);
        } else {
            throw new DataAlreadyFoundException("Root Folder Name already Exists choose another name");
        }
    }

    @Override
    public List<RootFolder> listOfRootFolders() {

        List<RootFolder> rootFolders = rootFolderRepo.findAll();
        if (rootFolders.isEmpty()) {
            throw new PathNotFoundException("No Root Folder found");
        }
        return rootFolders;
    }

    @Override
    public UserFolderDTO getAllSubFolderAndUrlPathsOfRootFolderOfUser() {
        UserFolderDTO userFolderDTO = new UserFolderDTO();

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication.getName() == null) {
            throw new ResourceNotFoundException("Please Login first for getting folders");
        }

        User user = userService.getUserByUserName(authentication.getName());


        //optimize logic for get folders

        //getting list of root-folders of user
        List<RootFolder> rootFolders = rootFolderRepo.findByUser(user);

        //filtering root-folders only that is active
        List<RootFolder> activeRootFolders = rootFolders.stream().filter(rootFolder -> rootFolder.isStatus() == true).collect(Collectors.toList());

        //List<SubFolderPathDto> subfolderPathDtoList = new ArrayList<>();
        List<RootFolderDto> rootFolderDtoList = new ArrayList<>();

        for (RootFolder rootFolder : activeRootFolders) {
            RootFolderDto rootFolderDto = new RootFolderDto();
            rootFolderDto.setRootFolderId(rootFolder.getId());
            rootFolderDto.setRootFolderName(rootFolder.getRootFolderName());
            //getting subfolder from root folder
            List<SubFolderPaths> subFolderList = rootFolder.getSubFolderPaths().stream().
                    filter(subFolder -> subFolder.isStatus() == true).collect(Collectors.toList());

            List<SubFolderPathDto> subfolderPathDtoList = new ArrayList<>();

            //getting url data from subfolder
            for (SubFolderPaths subFolderPath : subFolderList) {
                SubFolderPathDto subFolderPathDto = new SubFolderPathDto();
                //getting url data list from subfolder
                subFolderPathDto.setSubFolderPathName(subFolderPath.getSubFolderPath());
                subFolderPathDto.setSubFolderPathId(subFolderPath.getId());
                subFolderPathDto.setUrlsPathList(subFolderPath.getUrlsPaths());
                subfolderPathDtoList.add(subFolderPathDto);
                rootFolderDto.setSubFolderPathDtos(subfolderPathDtoList);
            }

            rootFolderDtoList.add(rootFolderDto);
        }

        userFolderDTO.setUser(this.modelMapper.map(user, UserDto.class));
        userFolderDTO.setRootFolderDtos(rootFolderDtoList);

        //before optimize logic

//		List<RootFolderDto> rootFoldersDto = new ArrayList<>();
//		List<SubFolderPaths> subFoldersPaths = new ArrayList<>();
//		for(int i=0;i<rootFolders.size();i++){
//			subFoldersPaths = subFolderPathsRepo.findAllByFolderPath_Id(rootFolders.get(i).getId());
//			RootFolderDto rootFolderDto = new RootFolderDto();
//			rootFolderDto.setId(rootFolders.get(i).getId());
//			rootFolderDto.setRootFolderPath(rootFolders.get(i).getRootFolderName());
//			rootFolderDto.setSubFolderPaths(subFoldersPaths);
//			List<UrlsPath> urlsDataList = new ArrayList<>();
//			for(int j=0;j<subFoldersPaths.size();j++){
//				List<UrlsPath> urlsPathList = urlsPathRepo.findBySubFolderPaths(subFoldersPaths.get(j));
//				for(int k=0;k<urlsPathList.size();k++){
//					urlsDataList.add(urlsPathList.get(k));
//				}
//			}
//			rootFolderDto.setUrlsPaths(urlsDataList);
//			rootFoldersDto.add(rootFolderDto);
//		}
//
//		userFolderDTO.setRootFolder(rootFoldersDto);
//		userFolderDTO.setUser(this.modelMapper.map(user,UserDto.class));


//		List<Long> rootFolderIds = new ArrayList<Long>();
//
//		//collecting all id from root-folder list
//		for (RootFolder folder : rootFolders) {
//			rootFolderIds.add(folder.getId());
//		}
//
//		//getting all subfolder from root-folder using root-folder id
//		List<List<SubFolderPaths>> findAllByFolderPath_Id = new ArrayList<List<SubFolderPaths>>();
//		for (Long folderId : rootFolderIds) {
//			findAllByFolderPath_Id.add(subFolderPathsRepo.findAllByFolderPath_Id(folderId));
//		}
//
//
//		List<RootFolderDto> rootFolderDto = new ArrayList<RootFolderDto>();
//		for (RootFolder r : rootFolders) {
//
//			RootFolderDto rfd = new RootFolderDto();
//			rfd.setRootFolderId(r.getId());
//			rfd.setRootFolderName(r.getRootFolderName());
//			List<SubFolderPathDto> subFolderPathDtos = new ArrayList<SubFolderPathDto>();
//			for (List<SubFolderPaths> l : findAllByFolderPath_Id) {
//
//				for (SubFolderPaths s : l) {
//					if (s.getFolderPath().getId() == r.getId()) {
//
//						SubFolderPathDto subFolderDto = new SubFolderPathDto();
//						subFolderDto.setSubFolderPathId(s.getId());
//						subFolderDto.setSubFolderPathName(s.getSubFolderPath());
//						List<UrlPathsDto> urlPathsDtos = new ArrayList<UrlPathsDto>();
//						for (UrlsPath u : s.getUrlsPaths()) {
//
//							if (u.getSubFolderPaths().getId() == s.getId()) {
//
//								UrlPathsDto urlPathsDto = new UrlPathsDto();
//
//								urlPathsDto.setUrlPathId(u.getId());
//								urlPathsDto.setUrl(u.getUrl());
//								urlPathsDto.setSource(u.getSource());
//								urlPathsDtos.add(urlPathsDto);
//							}
//							subFolderDto.setUrlPathsDto(urlPathsDtos);
//						}
//						subFolderPathDtos.add(subFolderDto);
//
//					}
//
//				}
//			}
//			rfd.setSubFolderPathDtos(subFolderPathDtos);
//			rootFolderDto.add(rfd);
//		}

        return userFolderDTO;
    }

    @Override
    public List<RootFolderDto> getRootFolderOfUser() {


        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication.getName() == null) {
            throw new ResourceNotFoundException("Please Login first");
        }

        User loggedInUser = userService.getUserByUserName(authentication.getName());

        userRepository.findById(loggedInUser.getId()).orElseThrow(() -> new ResourceNotFoundException("Please Enter Valid User Id...!"));

        List<RootFolder> rootFolderListOfUser = rootFolderRepo.findByUser_Id(loggedInUser.getId());

        List<RootFolder> activeRootFolders = rootFolderListOfUser.stream().filter(rootFolder -> rootFolder.isStatus() == true).collect(Collectors.toList());

//        if (activeRootFolders.isEmpty()) {
//            throw new PathNotFoundException("There are no root folders");
//        }

        return activeRootFolders.stream().map(rootFolder -> this.modelMapper.map(rootFolder, RootFolderDto.class)).collect(Collectors.toList());

    }

    // Ajay
    @Override
    public Map<String, Integer> getUrlCount(String path) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication.getName() == null) {
            throw new ResourceNotFoundException("Please Login first For getting urls count");
        }

        User loggedInUser = userService.getUserByUserName(authentication.getName());

        String pathFilter = path.replaceAll("/", "");

        if (path.isEmpty() || pathFilter.isEmpty() || !path.endsWith("/")) {
            throw new PathNotFoundException("Please Enter valid Path or Entered Path is Empty");
        }

        String[] folderNames = path.split("/");
        List<String> subFolderNames = new ArrayList<>();
        for (String folder : folderNames) {
            if (!folder.equals("")) {
                subFolderNames.add(folder);
            }
        }
        // Check entered path is root Folder or not
        RootFolder rootFolder = rootFolderRepo.findByRootFolderNameAndUser(pathFilter, loggedInUser);
        if (rootFolder != null) {
            Map<String, Integer> data = getUrlCountByRootID(rootFolder.getId(), "root", pathFilter);
            return data;
        } else {
            RootFolder rootFolders = rootFolderRepo.findByRootFolderNameAndUser(subFolderNames.get(0), loggedInUser);
            Map<String, Integer> data = getUrlCountByRootID(rootFolders.getId(), "sub", path);
            return data;
        }
    }

    @Override
    public Map<String, Integer> getItemCount(String path) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication.getName() == null) {
            throw new ResourceNotFoundException("Please Login first For getting urls count");
        }

        User loggedInUser = userService.getUserByUserName(authentication.getName());

        String pathFilter = path.replaceAll("/", "");

        if (path.isEmpty() || pathFilter.isEmpty() || !path.endsWith("/")) {
            throw new PathNotFoundException("Please Enter valid Path or Entered Path is Empty");
        }

        String[] folderNames = path.split("/");
        List<String> subFolderNames = new ArrayList<>();
        for (String folder : folderNames) {
            if (!folder.equals("")) {
                subFolderNames.add(folder);
            }
        }
        // Check entered path is root Folder or not
        RootFolder rootFolder = rootFolderRepo.findByRootFolderNameAndUser(pathFilter, loggedInUser);
        if (rootFolder != null) {
            Map<String, Integer> data = getItemCountByRootID(rootFolder.getId(), "root", pathFilter);
            return data;
        } else {
            RootFolder rootFolders = rootFolderRepo.findByRootFolderNameAndUser(subFolderNames.get(0), loggedInUser);
            Map<String, Integer> data = getItemCountByRootID(rootFolders.getId(), "sub", path);
            return data;
        }
        //	return null;
    }

    // To delete urlPath, subfolder w.r.t root folder
    @Override
    public ResponseEntity<?> deleteFolderAllData(String path) {

        Map<String, Object> response = new HashMap<>();

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication.getName() == null) {
            throw new ResourceNotFoundException("Please Login first For getting urls count");
        }

        User loggedInUser = userService.getUserByUserName(authentication.getName());

        String pathFilter = path.replaceAll("/", "");

        String msg = null;

        if (path.isEmpty() || pathFilter.isEmpty() || !path.endsWith("/")) {
            throw new PathNotFoundException("Please Enter valid Path or Entered Path is Empty");
        }

        String[] folderNames = path.split("/");
        List<String> subFolderNames = new ArrayList<>();
        for (String folder : folderNames) {
            if (!folder.equals("")) {
                subFolderNames.add(folder);
            }
        }
        // Check entered path is root Folder or not
        RootFolder rootFolder = rootFolderRepo.findByRootFolderNameAndUser(pathFilter, loggedInUser);

        if (rootFolder != null && rootFolder.isStatus() == true) {
            deleteFolderWithData(rootFolder.getId(), "root", pathFilter);
            rootFolder.setStatus(false);
            rootFolderRepo.save(rootFolder);
            //msg = "Folder " + rootFolder.getRootFolderName() + " deleted successfully";
            msg = "Folder deleted successfully";
        } else {
            RootFolder rootFolders = rootFolderRepo.findByRootFolderNameAndUser(subFolderNames.get(0), loggedInUser);
            if (rootFolders == null || rootFolders.isStatus() == false) {
                throw new PathNotFoundException("Please enter valid path...!");
            }
            deleteFolderWithData(rootFolders.getId(), "sub", path);
            msg = "Folder deleted successfully";
        }

        response.put("message", msg);
        response.put("success", true);
        response.put("statusCode", HttpStatus.OK.value());

        return ResponseEntity.status(HttpStatus.OK).body(response);

    }

    //delete multiple folders at a time api
    @Override
    public ResponseEntity<?> deleteFolderAllData2(Map<String, List<String>> map) {

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication.getName() == null) {
            throw new ResourceNotFoundException("Please Login first For getting urls count");
        }

        User loggedInUser = userService.getUserByUserName(authentication.getName());


        List<String> pathList = map.get("paths");

        Map<String, Object> response = new HashMap<>();

        RootFolder rootFolder = new RootFolder();

        String[] folderNames = null;

        SubFolderPaths subFolder = new SubFolderPaths();

        String msg = null;


        for (String path : pathList) {

            if (!path.startsWith("/") || !path.endsWith("/")) {
                throw new PathNotFoundException("Please enter valid path or entered path is empty");
            }

            folderNames = path.split("/");
            List<String> subFolderNames = new ArrayList<>();
            for (String folder : folderNames) {
                if (!folder.equals("")) {
                    subFolderNames.add(folder);
                }
            }
            rootFolder = rootFolderRepo.findByRootFolderNameAndUser(subFolderNames.get(0), loggedInUser);

            if (rootFolder == null) {
                throw new PathNotFoundException("Root folder is not exists for given path...!");
            }

            subFolder = subFolderPathsRepo.findBySubFolderPath(path);

            if (subFolderNames.size() == 1) {
                deleteFolderWithData(rootFolder.getId(), "root", subFolderNames.get(0));
                rootFolder.setStatus(false);
                rootFolderRepo.save(rootFolder);

            } else {
                deleteFolderWithData(rootFolder.getId(), "sub", path);
//				msg = "Data Deleted from folder successfully";
            }

            msg = "Folders Deleted successfully";
            response.put("message", msg);
            response.put("success", true);
            response.put("statusCode", HttpStatus.OK.value());

        }
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    private void deleteFolderWithData(Long rootId, String folderType, String path) {
        if (folderType.equals("root")) {
            ArrayList<UrlsPath> urlsPathList = urlsPathRepo.findUrlsByRootFolderId(rootId);
            List<SubFolderPaths> subFolderList = subFolderPathsRepo.findBySubFoldersByRootFolderId(rootId);

            for (SubFolderPaths subFolderPath : subFolderList) {
                if (subFolderPath.isStatus() == true) {
                    ArrayList<UrlsPath> urlsBySubFolderPathId = urlsPathRepo.findUrlsBySubFolderPathId(subFolderPath.getId());
                    if (!urlsBySubFolderPathId.isEmpty()) {
                        urlsPathList.addAll(urlsBySubFolderPathId);
                    }
                }
            }

            //change the status of url path
            if (!urlsPathList.isEmpty()) {
                List<UrlsPath> updatedUrlPathList = urlsPathList.stream().map(urlsPath -> {
                    urlsPath.setStatus(false);
                    return urlsPath;
                }).collect(Collectors.toList());
                //save updated state to db
                urlsPathRepo.saveAll(updatedUrlPathList);
            }

            if (!subFolderList.isEmpty()) {
                List<SubFolderPaths> updatedSubFolderList = subFolderList.stream().map(subFolder -> {
                    subFolder.setStatus(false);
                    return subFolder;
                }).collect(Collectors.toList());
                //save updated state to db
                subFolderPathsRepo.saveAll(updatedSubFolderList);
            }


        } else {
            ArrayList<UrlsPath> urlsPathList = new ArrayList<>();
            List<SubFolderPaths> subFolderList = new ArrayList<>();

            SubFolderPaths subFolder = subFolderPathsRepo.findBySubFolderPathAndRootFolderId(path, rootId);
            if (subFolder == null || subFolder.isStatus() == false) {
                throw new ResourceNotFoundException("Entered path " + path + " is not valid...!!!");
            }
            urlsPathList.addAll(subFolder.getUrlsPaths());
            List<SubFolderPaths> subFdPaths = subFolderPathsRepo.fetchBySubFoldersByParentSubFolderId(subFolder.getId());

            List<SubFolderPaths> subSubFolderList = new ArrayList<>();
            for (SubFolderPaths subFolderPath : subFdPaths) {
                subSubFolderList = subFolderPathsRepo.findByParentSubFolderId(subFolderPath.getId());
                //getting subfolder list from sub folder
                for (SubFolderPaths subSubFolder : subSubFolderList) {
                    urlsPathList.addAll(subSubFolder.getUrlsPaths());
                    subFolderList.add(subSubFolder);
                }
                urlsPathList.addAll(subFolderPath.getUrlsPaths());
                subFolderList.add(subFolderPath);
            }


            //change the status of url list and disable it and save state to db

            if (!urlsPathList.isEmpty()) {
                List<UrlsPath> updatedUrlList = urlsPathList.stream().map(urlsPath -> {
                    urlsPath.setStatus(false);
                    return urlsPath;
                }).collect(Collectors.toList());
                urlsPathRepo.saveAll(updatedUrlList);
            }

            //change the status of subfolder list and disable it and save state to db

            if (!subFolderList.isEmpty()) {
                List<SubFolderPaths> updatedSubFolderList = subFolderList.stream().map(subFolderPath -> {
                    subFolderPath.setStatus(false);
                    return subFolderPath;
                }).collect(Collectors.toList());
                subFolderPathsRepo.saveAll(updatedSubFolderList);
            }

            //finally change status of subfolder and disable it and save state to db
            subFolder.setStatus(false);
            subFolderPathsRepo.save(subFolder);


//			do {
//				for(int i=0; i<subFdPaths.size(); i++){
//						if (k == 0) {
//							subFdPath = subFolderPathsRepo.findBySubFoldersByParentSubFolderId(subFdPaths.get(i).getParentSubFolderId());
//							k++;
//						} else {
//							if (subFdPath != null) {
//								subFdPath = subFolderPathsRepo.findById(subFdPath.getId()).get();
//								subFdPath = subFolderPathsRepo.findBySubFoldersByParentSubFolderId(subFdPath.getId());
//							}
//
//						}
//
//					if (subFdPath != null) {
//						subFolderList.add(subFdPath);
//					}
//				}
//
//			}
//			while (subFdPath != null);

//			for (int i = 0; i < subFolderList.size(); i++) {
//				ArrayList<UrlsPath> urlsBySubFolderPathId = urlsPathRepo.findUrlsBySubFolderPathId(subFolderList.get(i).getId());
//				if (!urlsBySubFolderPathId.isEmpty()) {
//					urlsPathList.addAll(urlsBySubFolderPathId);
//				}
//			}

        }
    }

    private Map<String, Integer> getItemCountByRootID(Long rootID, String folderType, String path) {
        List<SubFolderPaths> subFolderPathList = new ArrayList<>();
        int[] array = new int[7];
        Map<String, Integer> map = new HashMap<>();

        if (folderType.equals("root")) {
            // For Root folder data
            List<UrlsPath> RootP = findActiveUrlPath(urlsPathRepo.findByRootFolderIdAndTag(rootID, "p"));
            List<UrlsPath> RootPR = findActiveUrlPath(urlsPathRepo.findByRootFolderIdAndTag(rootID, "pr"));
            List<UrlsPath> RootIMG = findActiveUrlPath(urlsPathRepo.findByRootFolderIdAndTag(rootID, "img"));
            List<UrlsPath> RootVID = findActiveUrlPath(urlsPathRepo.findByRootFolderIdAndTag(rootID, "vid"));
            List<UrlsPath> RootARTICLE = findActiveUrlPath(urlsPathRepo.findByRootFolderIdAndTag(rootID, "article"));

            subFolderPathList = subFolderPathsRepo.fetchBySubFoldersByParentSubFolderId(rootID);

            //filtering only active sub folders
            List<SubFolderPaths> activeSubFolders = new ArrayList<>();
            if (!subFolderPathList.isEmpty()) {
                activeSubFolders = subFolderPathList.stream().filter(subFolderPaths -> subFolderPaths.isStatus() == true)
                        .collect(Collectors.toList());
            }

            array[0] = array[0] + RootP.size();
            array[1] = array[1] + RootPR.size();
            array[2] = array[2] + RootIMG.size();
            array[3] = array[3] + RootVID.size();
            array[4] = array[4] + RootARTICLE.size();
            array[5] = array[5] + activeSubFolders.size();
            array[6] = array[0] + array[1] + array[2] + array[3] + array[4] + array[5];

            map.put("post", (array[0]));
            map.put("profile", (array[1]));
            map.put("image", (array[2]));
            map.put("video", (array[3]));
            map.put("article", (array[4]));
            map.put("subfolders", (array[5]));
            map.put("total", (array[6]));

            return map;
        } else {
            SubFolderPaths subFolder = subFolderPathsRepo.findBySubFolderPathAndRootFolderId(path, rootID);

            subFolderPathList = subFolderPathsRepo.fetchBySubFoldersByParentSubFolderId(subFolder.getId());

            List<SubFolderPaths> activeSubFolders = new ArrayList<>();
            if (!subFolderPathList.isEmpty()) {
                activeSubFolders = subFolderPathList.stream().filter(subFolderPaths -> subFolderPaths.isStatus() == true)
                        .collect(Collectors.toList());
            }

            List<UrlsPath> SubP = findActiveUrlPath(urlsPathRepo.findUrlBySubFolderPathIdAndTag(subFolder.getId(), "p"));
            List<UrlsPath> SubPR = findActiveUrlPath(urlsPathRepo.findUrlBySubFolderPathIdAndTag(subFolder.getId(), "pr"));
            List<UrlsPath> SubIMG = findActiveUrlPath(urlsPathRepo.findUrlBySubFolderPathIdAndTag(subFolder.getId(), "img"));
            List<UrlsPath> SubVID = findActiveUrlPath(urlsPathRepo.findUrlBySubFolderPathIdAndTag(subFolder.getId(), "vid"));
            List<UrlsPath> SubARTICLE = findActiveUrlPath(urlsPathRepo.findUrlBySubFolderPathIdAndTag(subFolder.getId(), "article"));

            array[0] = array[0] + SubP.size();
            array[1] = array[1] + SubPR.size();
            array[2] = array[2] + SubIMG.size();
            array[3] = array[3] + SubVID.size();
            array[4] = array[4] + SubARTICLE.size();
            array[5] = array[5] + activeSubFolders.size();
            array[6] = array[0] + array[1] + array[2] + array[3] + array[4] + array[5];

            map.put("post", (array[0]));
            map.put("profile", (array[1]));
            map.put("image", (array[2]));
            map.put("video", (array[3]));
            map.put("article", (array[4]));
            map.put("subfolders", (array[5]));
            map.put("total", (array[6]));

            return map;
        }
    }

    private List<UrlsPath> findActiveUrlPath(List<UrlsPath> urlsPathList) {

        return urlsPathList.stream().filter(urlsPath -> urlsPath.isStatus() == true).
                collect(Collectors.toList());

    }

    // Ajay :Method for getting all urls count w.r.t tags
    private Map<String, Integer> getUrlCountByRootID(Long rootID, String folderType, String path) {
        List<UrlsPath> SubP = null;
        List<UrlsPath> SubPR = null;
        List<UrlsPath> SubIMG = null;
        List<UrlsPath> SubVID = null;
        Map<String, Integer> map = new HashMap<>();
        // 0=post 1=profile 2=img 3=vid
        int[] array = new int[4];
        if (folderType.equals("root")) {
            // For Root folder data
            List<UrlsPath> RootP = urlsPathRepo.findByRootFolderIdAndTag(rootID, "p");
            List<UrlsPath> RootPR = urlsPathRepo.findByRootFolderIdAndTag(rootID, "pr");
            List<UrlsPath> RootIMG = urlsPathRepo.findByRootFolderIdAndTag(rootID, "img");
            List<UrlsPath> RootVID = urlsPathRepo.findByRootFolderIdAndTag(rootID, "vid");

            // get subfolder path list
            List<SubFolderPaths> subFolderPaths = subFolderPathsRepo.findBySubFoldersByRootFolderId(rootID);

            // For subfolders Url List
            for (int i = 0; i < subFolderPaths.size(); i++) {
                SubP = urlsPathRepo.findUrlBySubFolderPathIdAndTag(subFolderPaths.get(i).getId(), "p");
                SubPR = urlsPathRepo.findUrlBySubFolderPathIdAndTag(subFolderPaths.get(i).getId(), "pr");
                SubIMG = urlsPathRepo.findUrlBySubFolderPathIdAndTag(subFolderPaths.get(i).getId(), "img");
                SubVID = urlsPathRepo.findUrlBySubFolderPathIdAndTag(subFolderPaths.get(i).getId(), "vid");
                array[0] = array[0] + SubP.size();
                array[1] = array[1] + SubPR.size();
                array[2] = array[2] + SubIMG.size();
                array[3] = array[3] + SubVID.size();
            }
            map.put("post", (RootP.size() + array[0]));
            map.put("profile", (RootPR.size() + array[1]));
            map.put("image", (RootIMG.size() + array[2]));
            map.put("video", (RootVID.size() + array[3]));
            return map;
        } else {
            List<SubFolderPaths> subFolderPaths = new ArrayList<>();
            SubFolderPaths subFdPath = new SubFolderPaths();
            int k = 0;
            SubFolderPaths subFolder = subFolderPathsRepo.findBySubFolderPathAndRootFolderId(path, rootID);
            do {
                if (subFolder != null) {
                    if (k == 0) {
                        subFdPath = subFolderPathsRepo.findBySubFoldersByParentSubFolderId(subFolder.getParentSubFolderId());
                        k++;
                    } else {
                        if (subFdPath != null) {
                            subFdPath = subFolderPathsRepo.findById(subFdPath.getId()).get();
                            subFdPath = subFolderPathsRepo.findBySubFoldersByParentSubFolderId(subFdPath.getId());
                        }

                    }
                }

                if (subFdPath != null) {
                    subFolderPaths.add(subFdPath);
                }
            }
            while (subFdPath != null);

            for (int i = 0; i < subFolderPaths.size(); i++) {
                SubP = urlsPathRepo.findUrlBySubFolderPathIdAndTag(subFolderPaths.get(i).getId(), "p");
                SubPR = urlsPathRepo.findUrlBySubFolderPathIdAndTag(subFolderPaths.get(i).getId(), "pr");
                SubIMG = urlsPathRepo.findUrlBySubFolderPathIdAndTag(subFolderPaths.get(i).getId(), "img");
                SubVID = urlsPathRepo.findUrlBySubFolderPathIdAndTag(subFolderPaths.get(i).getId(), "vid");
                array[0] = array[0] + SubP.size();
                array[1] = array[1] + SubPR.size();
                array[2] = array[2] + SubIMG.size();
                array[3] = array[3] + SubVID.size();
            }
            map.put("post", array[0]);
            map.put("profile", array[1]);
            map.put("image", array[2]);
            map.put("video", array[3]);
            return map;

        }
    }

    @Override
    public ResponseEntity<?> renameFolderName(Map<String, String> map) {

		//get logged in details from token
        User loggedInUser = (User) authService.getLoggedInUserDetails().getBody();

        Map<String, Object> response = new HashMap<>();

        String pathFilter = map.get("oldPath").replaceAll("/", "");
        String newPathFilter = map.get("newPath").replaceAll("/", "");

        if (map.get("oldPath").isEmpty() || pathFilter.isEmpty() || !map.get("oldPath").endsWith("/")) {
            throw new PathNotFoundException("Please enter valid old path or entered path is empty");
        }

        if (map.get("newPath").isEmpty() || newPathFilter.isEmpty() || !map.get("newPath").endsWith("/")) {
            throw new PathNotFoundException("Please enter valid new old path or entered path is empty");
        }

        String oldPath = map.get("oldPath").replaceAll("/", "");
        String newPath = map.get("newPath").replaceAll("/", "");

        RootFolder rootFolder = rootFolderRepo.findByRootFolderNameAndUser(oldPath, loggedInUser);

        if(rootFolder == null){
            throw new PathNotFoundException("Please enter valid old path or entered path is empty");
        }

        //getting sub-folders
        List<SubFolderPaths> subFolderPaths = rootFolder.getSubFolderPaths();
        String[] folderNames = null;

        if (rootFolder != null) {
            if(rootFolder.isStatus()){
                //checking if root-folder is exists with given new name in db
                RootFolder rootFolderExistsWithNewPath = rootFolderRepo.findByRootFolderNameAndUser(newPath, loggedInUser);
                if(rootFolderExistsWithNewPath == null){
                    //rename folder name logic
                    rootFolder.setRootFolderName(newPath);
                    for(SubFolderPaths subFolder : subFolderPaths){
                        //changing root-folder name is sub-folder-path and root-folder id
                        String oldRootName = subFolder.getSubFolderPath().substring(1, oldPath.length() + 1);
                        String newRootFolderName = subFolder.getSubFolderPath().replace(oldRootName, newPath);
                        subFolder.setSubFolderPath(newRootFolderName);
                       //save updated state to db
                       subFolderPathsRepo.save(subFolder);
                    }
                    //save updated state to db
                    rootFolderRepo.save(rootFolder);

                }else{
                    throw new DataAlreadyFoundException("root-folder already exists with given new path");
                }
            }

        } else {
            //if root-folder is null or root-folder status false
            throw new PathNotFoundException("Please enter valid path...!");
        }

        response.put("message", "Foldername updated successfully");
        response.put("success", true);
        response.put("statusCode", HttpStatus.OK);

        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @Override
    public ResponseEntity<?> copyRootFolderAndData(List<String> Sourcepaths, String destinationPath) {
        //get logged in details from token
        User loggedInUser = (User) authService.getLoggedInUserDetails().getBody();

        Map<String, Object> response = new HashMap<>();

        List<RootFolder> rootFolderList = new ArrayList<>();
        List<List<UrlsPath>> urlsDataList = new ArrayList<>();
        List<List<SubFolderPaths>> subFolderList = new ArrayList<>();

        // Get All root folder list
        for(String path : Sourcepaths){
            String rootPath =path.replaceAll("/", "");
            rootFolderList.add(getRootFolderList(rootPath,loggedInUser));
        }

        // Get All subfolderList and urlsdata w.r.t rootId
        for(RootFolder rootfolder : rootFolderList){
            subFolderList.add(getSubFolderList(rootfolder.getId()));
            urlsDataList.add(getUrlsListfromRootfolder(rootfolder.getId()));

        }

        // Get All urls data w.r.t subfolder id
        for (List<SubFolderPaths> subFolderPathList : subFolderList){
            for(SubFolderPaths subFolderPaths : subFolderPathList){
                urlsDataList.add(getUrlsListfromSubfolder(subFolderPaths.getId()));
            }
        }

        return null;
    }
    private RootFolder getRootFolderList(String rootFolderPath, User user){
        return rootFolderRepo.findByRootFolderNameAndUser(rootFolderPath,user);
    }
    
    private List<SubFolderPaths> getSubFolderList(Long rootId){
        return subFolderPathsRepo.findAllByFolderPath_Id(rootId);
    }

    // get all urls list from rootfoders
    private List<UrlsPath> getUrlsListfromRootfolder(Long rootId){
        return urlsPathRepo.findUrlsByRootFolderId(rootId);
    }

    // get all urls list from subfolders
    private List<UrlsPath> getUrlsListfromSubfolder(Long subfolderId){
        return urlsPathRepo.findUrlsBySubFolderPathId(subfolderId);
    }

}
