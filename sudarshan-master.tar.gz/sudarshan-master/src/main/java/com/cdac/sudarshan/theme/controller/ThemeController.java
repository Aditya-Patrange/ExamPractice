package com.cdac.sudarshan.theme.controller;

import com.cdac.sudarshan.theme.dto.ThemeDto;
import com.cdac.sudarshan.theme.service.IThemeService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("themes")
public class ThemeController {

    @Autowired
    private IThemeService themeService;

    //save root theme
    @PostMapping("/save-theme")
    public ResponseEntity<?> saveTheme(@RequestBody ThemeDto themeDto) {

        Map<String, Object> response = new HashMap<>();

        ThemeDto savedTheme = themeService.saveTheme(themeDto);

        response.put("Message", "Theme added SuccessFully");
        response.put("Status_Code", String.valueOf(HttpStatus.CREATED.value()));
        response.put("Theme name", savedTheme.getThemePath());
        response.put("Creation_Date_And_Time", String.valueOf(savedTheme.getCreationDate()));

        return ResponseEntity.ok(response);
    }

    @GetMapping("/")
    public ResponseEntity<?> getAllThemes() {
        List<ThemeDto> allThemes = themeService.getAllThemes();
        return ResponseEntity.ok(allThemes);
    }

    @GetMapping("/getThemesOfUser")
    public ResponseEntity<?> getAllThemesOfUser() {

        Map<String, Object> response = new HashMap<>();

        List<ThemeDto> themesOfLoggedInUser = themeService.getThemesOfLoggedInUser();
        return ResponseEntity.ok(themesOfLoggedInUser);
    }

    @GetMapping("/getThemesByUserId/{userId}")
    public ResponseEntity<?> getThemesOfUserById(@PathVariable("userId") Long userId){
        Map<String, Object> response = new HashMap<>();

        List<ThemeDto> rootThemesOfUser = themeService.getRootThemesOfUser(userId);

        return ResponseEntity.ok(rootThemesOfUser);
    }

//    @PostMapping("/keywordsCount")
//    public ResponseEntity<?> getItemCount(@RequestBody Map<String, String> map) {
//        return new ResponseEntity<>(themeService.getItemCount(map.get("path")), HttpStatus.OK);
//    }
    @GetMapping("/getThemeCount")
    public ResponseEntity<?> getThemeKeywordCount() {
        return new ResponseEntity<>(themeService.getThemeKeywordCount(), HttpStatus.OK);
    }




}
