package com.cdac.sudarshan.dto;

import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class RequestDTO {
	
	private List<String> list;
	
	private int size;

	private String tag;
	
	private String profileId;
}
