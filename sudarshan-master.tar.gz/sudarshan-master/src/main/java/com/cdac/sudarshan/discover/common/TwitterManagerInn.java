package com.cdac.sudarshan.discover.common;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;

import com.cdac.sudarshan.discover.model.ArticleDataExportVo;
import com.cdac.sudarshan.discover.model.CommonArticleVo;
import com.cdac.sudarshan.discover.model.CommonFbVo;
import com.cdac.sudarshan.discover.model.CountryCode;
import com.cdac.sudarshan.discover.model.Fb_OutputVo;
import com.cdac.sudarshan.discover.model.Fb_groupVo;
import com.cdac.sudarshan.discover.model.InnsightTrends;
import com.cdac.sudarshan.discover.model.KeyMapVo;
import com.cdac.sudarshan.discover.model.TweetHashTagsTblVo;
import com.cdac.sudarshan.discover.model.TweetLinksTblVo;
import com.cdac.sudarshan.discover.model.TweetMentionTblVo;
import com.cdac.sudarshan.discover.model.TweetTblVo;
import com.cdac.sudarshan.discover.model.TweetUserTblVo;
import com.cdac.sudarshan.discover.model.TweeterActionVo;
import com.cdac.sudarshan.discover.model.TwitterKloutVo;
import com.cdac.sudarshan.discover.model.TwitterTrendsVo;
import com.cdac.sudarshan.discover.model.TwitterUserListVo;
import com.cdac.sudarshan.discover.model.TwitterVo;
import com.cdac.sudarshan.discover.model.UserProfileConnectionExportVo;
import com.cdac.sudarshan.discover.model.UserProfileExportVo;
//import com.innefu.innsight.twitter.vo.CommonArticleVo;
//import com.innefu.innsight.twitter.vo.InnsightTrends;
//import com.innefu.innsight.twitter.vo.KeyMapVo;
//import com.innefu.innsight.twitter.vo.TweetHashTagsTblVo;
//import com.innefu.innsight.twitter.vo.TweetLinksTblVo;
//import com.innefu.innsight.twitter.vo.TweetMentionTblVo;
//import com.innefu.innsight.twitter.vo.TweetTblVo;
//import com.innefu.innsight.twitter.vo.TweetUserTblVo;
//import com.innefu.innsight.twitter.vo.TweeterActionVo;
//import com.innefu.innsight.twitter.vo.TwitterKloutVo;
//import com.innefu.innsight.twitter.vo.TwitterTrendsVo;
//import com.innefu.innsight.twitter.vo.TwitterUserListVo;
//import com.innefu.innsight.twitter.vo.TwitterVo;
import com.google.gson.internal.LinkedTreeMap;
//import com.innefu.innsight.cases.vo.EntityVo;
//import com.innefu.innsight.cases.vo.SaveFilterVo;
//import com.innefu.innsight.common.CountryCode;
//import com.innefu.innsight.facebook.SeleniumVo.Fb_OutputVo;
//import com.innefu.innsight.facebook.SeleniumVo.Fb_groupVo;
//import com.innefu.innsight.facebook.vo.ArticleDataExportVo;
//import com.innefu.innsight.facebook.vo.CommonFbVo;
//import com.innefu.innsight.facebook.vo.UserProfileConnectionExportVo;
//import com.innefu.innsight.facebook.vo.UserProfileExportVo;

public interface TwitterManagerInn 
{
	public ArrayList<TwitterVo>	getTweets(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo>	getRetweetOfTweet(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo>	getHashTags(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo>	getThemes(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo>	getUsers(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> getAllAuthorsDetails(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo>	getUsersOnly(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> getTwUsersDetails(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo>	getLink(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo>	getMedia(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo>	getTweetGeo(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo>	getTweetGraph(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo>	getTweetDetailById(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> getArticleDetailsById(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo>	getUserDetailById(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo>	getRetweetGraph(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo>	getTweetRetweetCount(TweeterActionVo tweeterActionVo);
	public void	setTweetOperation(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> userTweetCount(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> CheckQueryReport(TweeterActionVo tweeterActionVo) ;
	public ArrayList<TwitterVo> getSentiment(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> getMention(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> getTwGeoMap(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> getTwWordCloud(TweeterActionVo tweeterActionVo);
	public void getUpdatePriority(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo>	getTimeLine(TweeterActionVo tweeterActionVo);

	public ArrayList<TwitterVo> getHashtagWordCloud(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> getUserWordCloud(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> getMentionWordCloud(TweeterActionVo tweeterActionVo);

	public ArrayList<TwitterVo> getPersonWordCloud(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> getPlaceWordCloud(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> getOrganizationWordCloud(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> getEventsWordCloud(TweeterActionVo tweeterActionVo);
	
	public ArrayList<TwitterVo>	getMentionUserLink(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> getHashLink(TweeterActionVo tweeteractionvo);
	public ArrayList<TwitterVo> getTweetDomainLink(TweeterActionVo tweeteractionvo);
	public ArrayList<TwitterVo> getTweetUrlLink(TweeterActionVo tweeteractionvo);

	public ArrayList<TwitterVo> getFollFollowing(TweeterActionVo tweeteractionvo);
	public ArrayList<TwitterVo>	getTweetSentimentTimeLineGraph(TweeterActionVo tweeterActionVo);
	
	public void setTweetIdForReTweet(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> checkRetweetStatus(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> getTwitterApi(String type);
	public void crawlAllTweetsOfUser(ArrayList<TweetTblVo> tweetTblVos,
            ArrayList<TweetHashTagsTblVo> hashTagsTblVos,
            ArrayList<TweetMentionTblVo> mentionTblVos,
            ArrayList<TweetLinksTblVo> tweetLinksTblVos,
            ArrayList<TweetUserTblVo> tweetUserTblVos,
            int entityId
            );
	
	public ArrayList<String> getAllTweetsByProfileEntity(String screenName);
	public void crawlAllFolowerFollowingOfUser(
	        ArrayList<TweetUserTblVo> tweetUserTblVos,
	        String screenName,String userId,String type
	        );
	
	public ArrayList<TwitterVo> getUserIdByScreenName(String screenName);
	public void crawlAllListOfUser(ArrayList<TwitterUserListVo> twitterUserListVos);
	public void crawlKloutDataOfUser(ArrayList<TwitterKloutVo> lstInfluencer,ArrayList<TwitterKloutVo> lstInfluencee,String screenName);

	
	//***User Detaild Report Start*************************/
	public ArrayList<TwitterVo>	getTweetsUsrDtlRpt(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo>	getHashTagsUsrDtlRpt(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo>	getLinkUsrDtlRpt(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo>	getMediaUsrDtlRpt(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> getTimeLineDayOfWeek(TweeterActionVo tweeterActionVo);	
	public ArrayList<TwitterVo> getTimeLineDayOfHour(TweeterActionVo tweeterActionVo);	
	public ArrayList<TwitterVo> gettweetStatsOffLine(TweeterActionVo tweeterActionVo);	
	public ArrayList<TwitterVo> userDetailReportFollowers(TweeterActionVo tweeterActionVo);	
	public ArrayList<TwitterVo> userDetailReportFollowing(TweeterActionVo tweeterActionVo);	
	public ArrayList<TwitterVo> userInfluerncerInfluencee(TweeterActionVo tweeterActionVo);	
	public ArrayList<TwitterVo> userTopRetweet(TweeterActionVo tweeterActionVo);	
	public ArrayList<TwitterVo> userTopReply(TweeterActionVo tweeterActionVo);	
	public ArrayList<TwitterVo> userTopSource(TweeterActionVo tweeterActionVo);	
	public ArrayList<TwitterVo> userTopList(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> getMentionUsrDtlRpt(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo>	getTweetGraphUsrDtlRpt(TweeterActionVo tweeterActionVo);

	//***User Detaild Report End*************************/
	public String checkUserEntity(String screenName);
	public ArrayList<TwitterVo> getTwProfileEntityWithFollowers(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> getCommonFollower_Following(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> getTwProfileEntityWithFollowersFin(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> getCommonFollower_FollowingMaxMin(TweeterActionVo tweeterActionVo);
	public void updateTwitterFollower_Following(ArrayList<TweetUserTblVo> tweetUserTblVos);
	public ArrayList<TwitterVo> getTwitterLinkAnalysis(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> getFBExcelCommonLinkAnalysis(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> getLinkedinExcelCommonLinkAnalysis(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> getTwitterExcelCommonLinkAnalysis(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> getTwitterExcelCommonFriendsLinkAnalysis(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> getTwitterExcelCommonLinkAnalysisTrendsData(TweeterActionVo tweeterActionVo);

	public ArrayList<TwitterVo> getCommonFollower_Following_Source(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> getTimeLineDayOfWeekCmnProfile(TweeterActionVo tweeterActionVo);	
	public ArrayList<TwitterVo> getTimeLineDayOfHourCmnProfile(TweeterActionVo tweeterActionVo);
	
	public ArrayList<TwitterVo>	geoTweetsByLoc(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo>	geoProfileTwitter(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo>	geoTweetsLatLong(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo>	geoRptLatLongRetweetUser(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo>	getSentimentcounty(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo>	geoProfileDetails(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo>	geoTweetRetweetsLatLong(TweeterActionVo tweeterActionVo);

	//05 august 2016
	public ArrayList<TwitterVo>	getCommonFollower_Following_Report(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo>	getCommonFollower_Following_Source_Report(TweeterActionVo tweeterActionVo);

	
	public ArrayList<TwitterVo>	getTweetDetailByParam(TweeterActionVo tweeterActionVo);
	public ArrayList<CountryCode> getCountryCode();
	
	/*************************************************************************/
	public ArrayList<TwitterVo>	getMetaTags(TweeterActionVo tweeterActionVo);
	
	public ArrayList<TwitterVo> geoCloud(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> dashSourceCount(TweeterActionVo tweeterActionVo);
	
	public ArrayList<TwitterVo>  timelineTrends(TweeterActionVo tweeterActionVo);

	public ArrayList<TwitterVo>  mostCommentedUser(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo>  mostFbLikedUser(TweeterActionVo tweeterActionVo);
	/******Common report*********************/
	public CommonArticleVo	getAllDataForCommon(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo>	getCommonFriendFacebook(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo>	getCommonGroupFacebook(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo>	getCommonLikesFacebook(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo>	getCommonCheckinsFacebook(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo>	getCommonEventFacebook(TweeterActionVo tweeterActionVo);
	public CommonFbVo getCommonSocialData(TweeterActionVo tweeterActionVo, String type);
	
	
	/***************Facebook**************************/
	public ArrayList<Object> fb_scrapy_basic_info(TweeterActionVo fbInputVo);
	public ArrayList<Fb_OutputVo> fb_scrapy_user_media(TweeterActionVo fbInputVo);
	public ArrayList<Fb_groupVo> fb_scrapy_user_gp(TweeterActionVo fbInputVo);
	public ArrayList<Fb_groupVo> fb_scrapy_user_check_ins(TweeterActionVo fbInputVo);
	public ArrayList<Fb_groupVo> fb_scrapy_user_friends(TweeterActionVo fbInputVo);
	public ArrayList<Fb_groupVo> fb_scrapy_user_likes(TweeterActionVo fbInputVo);
	public ArrayList<String> fbUserODS(TweeterActionVo fbInputVo);
	public ArrayList<Fb_groupVo> fbUserFRS(TweeterActionVo fbInputVo);
	
	
	public ArrayList<TwitterVo>	getLanguage(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo>	getCountry(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo>	getCity(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> getThemeWordCloud(TweeterActionVo tweeterActionVo);
	ArrayList<TwitterVo> getClassification(TweeterActionVo tweeterActionVo);
	ArrayList<TwitterVo> getAllAttriubuteCount(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> getAllAttriubuteCountNER(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> dashActiveEntity(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> mostInfluenceTweetUser(TweeterActionVo tweeterActionVo);
	public ArrayList<KeyMapVo> getAllTredingDateWithTheme360(TweeterActionVo tweeterActionVo);
	public ArrayList<LinkedTreeMap> getAllInfluencerUser360(TweeterActionVo tweeterActionVo); 
	public ArrayList<TwitterVo> getEmailId(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> getPhoneNo(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> getAllTwitterUserCreatiedBetweenDates(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> topDashActiveEntity(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo>	getEmotions(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> docCountWithSentiment(TweeterActionVo tweeterActionVo);
	public ArrayList<LinkedTreeMap> getFieldTypeData(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> getUserNodeDetail(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> getAllDataForLinkAnalysis(TweeterActionVo tweeterActionVo);
	
	public ArrayList<TwitterVo> getEvent(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> getTaxonomy(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> getAuthorCountry(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> getAuthorCity(TweeterActionVo tweeterActionVo);
	
	public ArrayList<Fb_groupVo> fbTopMostUserReacted(TweeterActionVo tweeterActionVo);
	public ArrayList<Fb_groupVo> fbTopMostReactionChart(TweeterActionVo tweeterActionVo);
	public ArrayList<Fb_groupVo> fbTopMosCityOfFriend(TweeterActionVo tweeterActionVo);
	public ArrayList<Fb_groupVo> fbTopMostUserCommented(TweeterActionVo tweeterActionVo);
	public ArrayList<Fb_groupVo> fbTopMostUserStrongConnection(TweeterActionVo tweeterActionVo);
	
	public ArrayList<TwitterVo> getHashtagViewBasicInformation(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> getMaxAndMinDateOfFacebookUserProfilePost(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> getMaxAndMinDateOfLinkedinProfilePost(TweeterActionVo tweeterActionVo);
	public ArrayList<EntityVo> getFacebookUserProfileFromNewAnalysis(EntityVo entityVo);
	

	//====================================================================================	
	public void updateClassification(TweeterActionVo tweeterActionVo);
	public void updateSentiment(TweeterActionVo tweeterActionVo);
	public ArrayList<Fb_groupVo> getFBPeopleProfileWithSameGroup(TweeterActionVo tweeterActionVo);
	public ArrayList<Fb_groupVo> getFBPeopleProfileWithSameLikes(TweeterActionVo tweeterActionVo);
	public ArrayList<Fb_groupVo> getFBPeopleProfileWithSameCheckIn(TweeterActionVo tweeterActionVo);
	public ArrayList<Fb_groupVo> getFBPeopleProfileWithSameLocation(TweeterActionVo tweeterActionVo);
	public ArrayList<Fb_OutputVo> getFBPageBasicInfo(TweeterActionVo fbInputVo);
	
	//FOR DEMO WORK==========================================//FOR DEMO WORK
	public ArrayList<TwitterVo> strongFollowersOfAPC(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> strongFollowersOfAPCImage(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> suspectedBOTsOfAPC(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> strongFollowersOfPDP(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> suspectedBOTsOfPDP(TweeterActionVo tweeterActionVo);
	
	//=================FB PAGE RPT=========================//
	public ArrayList<TwitterVo> fbPageBasicInfoRpt(TweeterActionVo fbInputVo);
	public ArrayList<TwitterVo> fbPageBasicInformationsDetailsRpt(TweeterActionVo fbInputVo);
	public ArrayList<TwitterVo> fbPageMediaImageRpt(TweeterActionVo fbInputVo);
	public ArrayList<TwitterVo> fbPageMediaVideoRpt(TweeterActionVo fbInputVo);
	public ArrayList<Fb_groupVo> fbPageTopMostUserStrongConnection(TweeterActionVo fbInputVo);
	public ArrayList<Fb_groupVo> fbPageAllPeoplesLikesThePage(TweeterActionVo fbInputVo);
	public ArrayList<Fb_groupVo> fbPageTopFan(TweeterActionVo fbInputVo);

	//=================FB GROUP RPT=========================//
	public ArrayList<TwitterVo> fbGroupBasicInfoRpt(TweeterActionVo fbInputVo);
	public ArrayList<TwitterVo> fbGroupMediaImageRpt(TweeterActionVo fbInputVo);
	public ArrayList<TwitterVo> fbGroupMediaVideoRpt(TweeterActionVo fbInputVo);
	public ArrayList<Fb_groupVo> fbGroupTopMostUserStrongConnection(TweeterActionVo fbInputVo);
	public ArrayList<Fb_groupVo> fbGroupAllMembersRpt(TweeterActionVo fbInputVo);
	public ArrayList<Fb_groupVo> fbGroupNewMembersRpt(TweeterActionVo fbInputVo);
	public ArrayList<Fb_groupVo> fbGroupEventsRpt(TweeterActionVo fbInputVo);
	public ArrayList<Fb_groupVo> fbGroupAllAdminRpt(TweeterActionVo fbInputVo);
	
	public ArrayList<InnsightTrends> getTrendsByLocation(InnsightTrends innsightTrends);
	public ArrayList<InnsightTrends> getCitiesForTrends();
	
	public ArrayList<TwitterVo> getTweetsUserLocation(TweeterActionVo tweeterActionVo);
	
	//===========================Tweet Update From tweeter=========================//
	public TwitterVo updateTweetRealTimeByTweetId(TweeterActionVo tweeterActionVo);
	public LinkedHashMap<String, ArrayList<TwitterTrendsVo>> timelineChipsTrends(TweeterActionVo tweeterActionVo);
	
	public Long getTweetReach(String tweetId);
	public ArrayList<ArticleDataExportVo> exportFBProfilePostJsonDataReport(TweeterActionVo tweeterActionVo);
	public ArrayList<UserProfileConnectionExportVo> exportFBProfileConnectionJsonDataReport(TweeterActionVo tweeterActionVo);
	public ArrayList<UserProfileExportVo> exportFBBasicInfoJsonDataReport(TweeterActionVo tweeterActionVo);
	public String exportFbTotalDocumentCount(TweeterActionVo tweeterActionVo);
	public ArrayList<HashMap<String, String>> exportFbOverallSentimentReportData(TweeterActionVo tweeterActionVo);
	public ArrayList<HashMap<String, String>> exportFbClassificationReportData(TweeterActionVo tweeterActionVo);
	public ArrayList<HashMap<String, String>> exportFbPersonReportData(TweeterActionVo tweeterActionVo);
	public ArrayList<HashMap<String, String>> exportFbPlaceReportData(TweeterActionVo tweeterActionVo);
	public ArrayList<HashMap<String, String>> exportFbOrgReportData(TweeterActionVo tweeterActionVo);
	public ArrayList<HashMap<String, String>> exportFbThemesReportData(TweeterActionVo tweeterActionVo);
	public ArrayList<String> exportFbPhotoReportData(TweeterActionVo tweeterActionVo);
	public ArrayList<String> exportFbVideoReportData(TweeterActionVo tweeterActionVo);
	public ArrayList<HashMap<String, String>> exportFbCheckinsReportData(TweeterActionVo tweeterActionVo);
	public ArrayList<HashMap<String, String>> exportFbLikesReportData(TweeterActionVo tweeterActionVo);
	public ArrayList<SaveFilterVo> getAllAnalysisName(SaveFilterVo saveFilterVo);
	public ArrayList<SaveFilterVo> getAllRequiredSnapshotName(SaveFilterVo saveFilterVo);
	public ArrayList<TwitterVo> getAllUniqueTWBoatsUser(TweeterActionVo tweeterActionVo);
	public ArrayList<TwitterVo> getFBUserPostComment(TweeterActionVo tweeterActionVo);
	

	

	
	
	
}
