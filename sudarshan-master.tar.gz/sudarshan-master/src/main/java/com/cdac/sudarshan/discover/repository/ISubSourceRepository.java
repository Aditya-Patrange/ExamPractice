package com.cdac.sudarshan.discover.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cdac.sudarshan.discover.model.DiscoverSubSources;
import com.cdac.sudarshan.discover.projection.DiscoverSubSourcesProjection;

@Repository
public interface ISubSourceRepository extends JpaRepository<DiscoverSubSources, Integer>{

//	@Query(value = "SELECT * FROM discover_sub_source where source_subsource_fk=?1",nativeQuery = true)
//	List<DiscoverSubSources>findDiscoverSubSources(int sourceid);
	@Query("select new com.cdac.sudarshan.discover.model.DiscoverSubSources(d.id,d.subSource,d.alias) from DiscoverSubSources d where d.discoverSources.id=:id")
	List<DiscoverSubSourcesProjection>  getSubSourceNameAndId(int id);

//	@Query(value="select id,subSource from discover_sub_sources", nativeQuery=true)
	@Query("select new com.cdac.sudarshan.discover.model.DiscoverSubSources(d.id,d.subSource,d.alias) from DiscoverSubSources d")
	List<DiscoverSubSourcesProjection> findAllSource();
}
