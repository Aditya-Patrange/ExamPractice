package com.cdac.sudarshan.watchlist.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cdac.sudarshan.watchlist.model.Frequency;

public interface FrequencyRepository extends JpaRepository<Frequency, Integer> {

}
