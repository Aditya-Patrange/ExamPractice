package com.cdac.sudarshan.watchlist.service;

import com.cdac.sudarshan.authentication.model.User;
import com.cdac.sudarshan.authentication.service.IUserService;
import com.cdac.sudarshan.exception.ResourceNotFoundException;
import com.cdac.sudarshan.watchlist.configuration.ApplicationConfiguration;
import com.cdac.sudarshan.watchlist.dto.ResponseDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class AvatarService implements IAvatarService {


    @Autowired
    private IUserService userService;
    @Autowired
    private ApplicationConfiguration appConfig;

    @Autowired
    private ProxyService proxyService;

    @Autowired
    private JdbcTemplate jdbcTemplateTwo;

    @Autowired
    private RestTemplate template;

    @Override
    public ResponseEntity<?> getAvatarList(HashMap<String, Object> data) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<Object>(data, headers);
        return template.exchange(appConfig.getProperty("InnefuURL") + "selectAllAvatar", HttpMethod.POST, entity,
                Object.class);
    }

    @Override
    public ResponseEntity<?> addNewAvatar(HashMap<String, Object> data) {

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication.getName() == null) {
            throw new ResourceNotFoundException("Please Login first For getting urls count");
        }
        User loggedInUser = userService.getUserByUserName(authentication.getName());
        System.out.println(loggedInUser);

        data.put("userId", loggedInUser.getId());
        data.put("isPrivate", "no");
        System.out.println(data);

//		System.out.println(data);
//		System.out.println(data.get("userName"));
        String query = "SELECT * FROM tbl_avatars WHERE user_name='" + data.get("userName") + "'"
                + " AND source='" + data.get("source") + "'";

//		System.out.println("Query :  " + query);
        List<Map<String, Object>> maps = jdbcTemplateTwo.queryForList(query);

//		System.out.println("MAPS = "+ maps);
        if (maps.size() > 0) {
            ResponseDto responseDto = new ResponseDto();
            responseDto.setMsg("Duplicate Entry for the avatar!!");
            return new ResponseEntity<>(responseDto, HttpStatus.CONFLICT);
        } else {
            HttpHeaders headers = new HttpHeaders();
            headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<Object> entity = new HttpEntity<Object>(data, headers);
            return template.exchange(appConfig.getProperty("InnefuURL") + "addNewAvatar", HttpMethod.POST, entity,
                    Object.class);
        }

//
//		HttpHeaders headers = new HttpHeaders();
//		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
//		headers.setContentType(MediaType.APPLICATION_JSON);
//		HttpEntity<Object> entity = new HttpEntity<Object>(data, headers);
//		return template.exchange(appConfig.getProperty("InnefuURL") + "addNewAvatar", HttpMethod.POST, entity,
//				Object.class);
    }

    @Override
    public ResponseEntity<?> selectAllProxy(HashMap<String, Object> data) {
//		HashMap<String, Object> ans = proxyService.selectProxy(data);
        return new ResponseEntity<>(proxyService.selectProxy(data), HttpStatus.OK);


//		HttpHeaders headers = new HttpHeaders();
//		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
//		headers.setContentType(MediaType.APPLICATION_JSON);
//		HttpEntity<Object> entity = new HttpEntity<Object>(data, headers);
//		ResponseEntity<Object> response = template.exchange(appConfig.getProperty("InnefuURL") + "selectAllProxy", HttpMethod.POST, entity,
//				Object.class);
//
//		System.out.println(response);
//		return response;
    }


    @Override
    public ResponseEntity<?> selectProxyById(HashMap<String, Object> data) {

        String sql = "select ip from tbl_proxies where record_id='" + data.get("id") + "'";
//		System.out.println(sql);
        List<Map<String, Object>> maps = jdbcTemplateTwo.queryForList(sql);
        return new ResponseEntity<>(maps, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<?> addNewProxy(HashMap<String, Object> data) {

        String query = "SELECT * FROM tbl_proxies WHERE ip='" + data.get("ip") + "'"
                + "and country='" + data.get("country") + "'";
        List<Map<String, Object>> maps = jdbcTemplateTwo.queryForList(query);
        if (maps.size() > 0) {
            ResponseDto responseDto = new ResponseDto();
            responseDto.setMsg("Duplicate Entry for the proxy!!");
            return new ResponseEntity<>(responseDto, HttpStatus.CONFLICT);
        } else {
            HttpHeaders headers = new HttpHeaders();
            headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<Object> entity = new HttpEntity<Object>(data, headers);
            return template.exchange(appConfig.getProperty("InnefuURL") + "addNewProxy", HttpMethod.POST, entity,
                    Object.class);
        }

    }

    @Override
    public ResponseEntity<?> selectAllMaster(HashMap<String, Object> data) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<Object>(data, headers);
        return template.exchange(appConfig.getProperty("InnefuURL") + "selectAllMaster", HttpMethod.POST, entity,
                Object.class);
    }

//	@Override
//	public ResponseEntity<?> updateAvatar(HashMap<String, Object> data) {
//		
//		System.out.println("Update Avatar...");
//		System.out.println("data"+data);
//		HttpHeaders headers = new HttpHeaders();
//		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
//		headers.setContentType(MediaType.APPLICATION_JSON);
//		HttpEntity<Object> entity = new HttpEntity<Object>(data, headers);
//		return template.exchange(appConfig.getProperty("InnefuURL") + "updateAvatar", HttpMethod.POST, entity,
//				Object.class);
//	}

    @Override
    public ResponseEntity<?> selectAvatarById(String id, HashMap<String, Object> data) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<Object>(data, headers);
        return template.exchange(appConfig.getProperty("InnefuURL") + "selectAvatarById?id=" + id, HttpMethod.POST,
                entity, Object.class);

    }

    @Override
    public ResponseEntity<?> deleteAvatarById(String id) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<Object>(headers);
        return template.exchange(appConfig.getProperty("InnefuURL") + "deleteAvatarById?id=" + id, HttpMethod.POST,
                entity, Object.class);
    }

    @Override
    public ResponseEntity<?> updateProxy(HashMap<String, Object> data) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<Object>(data, headers);
        return template.exchange(appConfig.getProperty("InnefuURL") + "updateProxy", HttpMethod.POST, entity,
                Object.class);
    }

    @Override
    public ResponseEntity<?> deleteProxyById(String id) {

        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<Object> entity = new HttpEntity<Object>(headers);
        return template.exchange(appConfig.getProperty("InnefuURL") + "deleteProxyById?id=" + id, HttpMethod.POST, entity,
                Object.class);
    }

    @Override
    public ResponseEntity<?> updateAvatar(HashMap<String, Object> data) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication.getName() == null) {
            throw new ResourceNotFoundException("Please Login first For getting urls count");
        }
        User loggedInUser = userService.getUserByUserName(authentication.getName());

        data.put("userId", loggedInUser.getId());
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<Object>(data, headers);
        return template.exchange(appConfig.getProperty("InnefuURL") + "updateAvatar", HttpMethod.POST, entity, Object.class);
    }


//	@Override
//	public ResponseEntity<?> selectAvatarById(HashMap<String, Object> data) {
//	HttpHeaders headers = new HttpHeaders();
//	headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
//	headers.setContentType(MediaType.APPLICATION_JSON);
//	HttpEntity<Object> entity = new HttpEntity<Object>(data, headers);
//	return template.exchange(appConfig.getProperty("InnefuURL")+"selectAvatarById", HttpMethod.POST, entity, Object.class);
//	}

//	@Override
//	public ResponseEntity<?> selectAvatarById(String id) {
//	HttpHeaders headers = new HttpHeaders();
//	headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
//	headers.setContentType(MediaType.APPLICATION_JSON);
//	//HttpEntity<Object> entity = new HttpEntity<Object>(data, headers);
//	return template.postForEntity(appConfig.getProperty("InnefuURL")+"selectAvatarById?id="+id,HttpMethod.POST,Object.class);
//	//return template.exchange(appConfig.getProperty("InnefuURL")+"selectAvatarById?id="+id, HttpMethod.POST,Object.class);
//	}
//	
//	@Override
//	public ResponseEntity<?> deleteAvtarById(String id) {
//	HttpHeaders headers = new HttpHeaders();
//	headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
//	headers.setContentType(MediaType.APPLICATION_JSON);
//	return template.postForEntity(appConfig.getProperty("InnefuURL")+"deleteAvatarById?id="+id, HttpMethod.POST,Object.class);
//	}


}
