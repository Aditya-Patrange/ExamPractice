package com.cdac.sudarshan.discover.common;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.sudarshan.discover.model.TweeterActionVo;
import com.cdac.sudarshan.discover.model.TwitterVo;

//import com.innefu.innsight.common.CommonUtils;
//import com.innefu.innsight.dashboard.dao.DashboardDAO;
//import com.innefu.innsight.dashboard.daoVo.DashInputVo;
//import com.innefu.innsight.dashboard.daoVo.DashOutputVo;
//import com.innefu.innsight.dashboard.daoVo.Dashboard;
//import com.innefu.innsight.dashboard.daoVo.DashboardWidgetVo;
//import com.innefu.innsight.dashboard.daoVo.Widget;
//import com.innefu.innsight.dashboard.manager.DashBoardManager;
//import com.innefu.innsight.twitter.dao.TwitterInnDao;
//import com.innefu.innsight.twitter.vo.TweeterActionVo;
//import com.innefu.innsight.twitter.vo.TwitterVo;

@Service
public class DashBoardManagerImpl implements DashBoardManager {
	
	@Autowired
	TwitterInnDao twitterInnDao;
	
	@Autowired
	DashboardDAO dashboardDAO;
	
	@Autowired
	private CommonUtils commonUtils;

	@Override
	public ArrayList<TwitterVo> dashEntityCount(TweeterActionVo tweeterActionVo) 
	{
		return twitterInnDao.dashEntityCount(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> dashTimeLine(TweeterActionVo tweeterActionVo) 
	{
		return twitterInnDao.dashTimeLine(tweeterActionVo);	
	}
	@Override
	public ArrayList<TwitterVo> dashTwTrends(TweeterActionVo tweeterActionVo) 
	{
		return twitterInnDao.dashTwTrends(tweeterActionVo);	
	}

	@Override
	public ArrayList<TwitterVo> dashGeoMap(TweeterActionVo tweeterActionVo) 
	{
		return twitterInnDao.dashGeoMap(tweeterActionVo);	
	}

	@Override
	public ArrayList<TwitterVo> dashActiveMedia(TweeterActionVo tweeterActionVo) {
		return twitterInnDao.dashActiveMedia(tweeterActionVo);	
	}
	

	@Override
	public ArrayList<TwitterVo> dashActiveEntity(TweeterActionVo tweeterActionVo) 
	{
		return twitterInnDao.dashActiveEntity(tweeterActionVo);	
	}
	
	@Override
	public ArrayList<TwitterVo> dashODSImage(TweeterActionVo tweeterActionVo) 
	{
		return twitterInnDao.dashODSImage(tweeterActionVo);	
	}
	
	@Override
	public ArrayList<TwitterVo> dashOCRImage(TweeterActionVo tweeterActionVo) 
	{
		return twitterInnDao.dashOCRImage(tweeterActionVo);	
	}
	
	@Override
	public ArrayList<TwitterVo> dashArticles(TweeterActionVo tweeterActionVo) {
		return twitterInnDao.dashArticles(tweeterActionVo);
	}

	public ArrayList<DashOutputVo> dashActiveUser(DashInputVo dashInputVo)
	{
		return dashboardDAO.dashActiveUser(dashInputVo);
	}

	public ArrayList<DashOutputVo> dashActiveHashTag(DashInputVo dashInputVo) 
	{
		return dashboardDAO.dashActiveHashTag(dashInputVo);
	}

	public ArrayList<TwitterVo> dashActiveUser(TweeterActionVo tweeterActionVo) {
		return twitterInnDao.dashActiveUser(tweeterActionVo);
	}
	
	@Override
	public List<Dashboard> getDashboardByUserId(String userId) 
	{
		return dashboardDAO.getDashboardByUserId(userId);
	}
	@Override
	public boolean removeDashboardById(Dashboard dashboard) 
	{
		return dashboardDAO.removeDashboardById(dashboard);
	}
	
	@Override
	public boolean createDashboard(Dashboard dashboard) {
		return dashboardDAO.createDashboard(dashboard);
	}

	@Override
	public boolean updateDashboardById(Dashboard dashboard) 
	{
		return dashboardDAO.updateDashboardById(dashboard);
	}
	@Override
	public ArrayList<Dashboard> getAllDashboard(Dashboard dashboard) 
	{
		return dashboardDAO.getAllDashboard(dashboard);
	}
	@Override
	public boolean updateWidget(Widget widget) 
	{
		return dashboardDAO.updateWidget(widget);
	}
	@Override
	public ArrayList<Widget> getAllWidget(Widget widget) 
	{
		return dashboardDAO.getAllWidget(widget);
	}
	@Override
	public void addWidgetsToDashboard(Dashboard dashboard) {
		dashboardDAO.addWidgetsToDashboard(dashboard);		
	}
	@Override
	public void removeWidgetsFromDashboard(Dashboard dashboard) 
	{
		dashboardDAO.removeWidgetsFromDashboard(dashboard);	
	}
	@Override
	public List<DashboardWidgetVo> getWidgetsByDashboardId(Long dashboardId) {
		return dashboardDAO.getWidgetsByDashboardId(dashboardId);
	}
	
	@Override
	public int saveDashboard(List<DashboardWidgetVo> list) 
	{
		int i = -1;
		String userLog ="";
		try 
		{
			long dashboardId = list.get(0).getDashboardId();
			
			List<DashboardWidgetVo> clist = dashboardDAO.getWidgetsByDashboardId(dashboardId);

			/*-------------------------------*/
			List<DashboardWidgetVo> removed = new ArrayList<DashboardWidgetVo>(clist);
			removed.removeAll(list);

			List<DashboardWidgetVo> same = new ArrayList<DashboardWidgetVo>(list);
			same.retainAll(clist);

			List<DashboardWidgetVo> added = new ArrayList<DashboardWidgetVo>(list);
			added.removeAll(clist);
			/*-------------------------------*/
			
			if(removed.size()>0)
			{
				userLog = "Delete Widget From Dashboard";
				commonUtils.insertUserActivityLogs(userLog);
				dashboardDAO.deleteWidgetDashboard(removed);
			}	
			
			if(added.size()>0)
			{
				userLog = "Add Widget In Dashboard";
				commonUtils.insertUserActivityLogs(userLog);
				dashboardDAO.addWidgetDashboard(added);
			}	
			
			if(same.size()>0)
			{
				userLog = "Update Widget In Dashboard";
				commonUtils.insertUserActivityLogs(userLog);
				dashboardDAO.updateWidgetDashboard(same);
			}
						
			i = 1;
		}
		catch(Exception e) 
		{
			i = -1;
			e.printStackTrace();
		}		
		return i;		
	}
	
	@Override
	public List<DashboardWidgetVo> getAllDashboard() 
	{
		return dashboardDAO.getAllDashboard();
	}
	
	@Override
	public void markCurrentDashboard(String dashboardId,String caseId) 
	{
		dashboardDAO.markCurrentDashboard(dashboardId,caseId);
	}

	@Override
	public ArrayList<Dashboard> getUserCurrentDashboard(String caseId) 
	{
	      return dashboardDAO.getUserCurrentDashboard(caseId);
	}
	
	
}
