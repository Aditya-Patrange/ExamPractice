package com.cdac.sudarshan.discover.model;

import java.io.Serializable;
import java.util.ArrayList;

public class Article_Fb_Page implements Serializable 
{
	private static final long serialVersionUID = 1L;
	private String pageId;
	private String pageName;
	private String pageUserName;
	private String pageCountry;
	private String pageCity;
	private String pageZip;
	private String pageCoverSource;
	private String pagePicture;
	private String pageAbout;
	private String pageLink;
	private String pagePhone;
	private String pageDescription;
	private String pageWebSite;
	private String pageCategory;
	private String pageLocation;
	private int pageCheckins;
	private int pageLikeCount;
	private int pageWereHereCount;
	private ArrayList<Article_Fb_User> fbPageLikeUser;
	
	public String getPageId() {
		return pageId;
	}
	public void setPageId(String pageId) {
		this.pageId = pageId;
	}
	public String getPageName() {
		return pageName;
	}
	public void setPageName(String pageName) {
		this.pageName = pageName;
	}
	public String getPageUserName() {
		return pageUserName;
	}
	public void setPageUserName(String pageUserName) {
		this.pageUserName = pageUserName;
	}
	public String getPageCountry() {
		return pageCountry;
	}
	public void setPageCountry(String pageCountry) {
		this.pageCountry = pageCountry;
	}
	public String getPageCity() {
		return pageCity;
	}
	public void setPageCity(String pageCity) {
		this.pageCity = pageCity;
	}
	public String getPageZip() {
		return pageZip;
	}
	public void setPageZip(String pageZip) {
		this.pageZip = pageZip;
	}
	public String getPageCoverSource() {
		return pageCoverSource;
	}
	public void setPageCoverSource(String pageCoverSource) {
		this.pageCoverSource = pageCoverSource;
	}
	public String getPageAbout() {
		return pageAbout;
	}
	public void setPageAbout(String pageAbout) {
		this.pageAbout = pageAbout;
	}
	public String getPageLink() {
		return pageLink;
	}
	public void setPageLink(String pageLink) {
		this.pageLink = pageLink;
	}
	public String getPagePhone() {
		return pagePhone;
	}
	public void setPagePhone(String pagePhone) {
		this.pagePhone = pagePhone;
	}
	public String getPageDescription() {
		return pageDescription;
	}
	public void setPageDescription(String pageDescription) {
		this.pageDescription = pageDescription;
	}
	public String getPageWebSite() {
		return pageWebSite;
	}
	public void setPageWebSite(String pageWebSite) {
		this.pageWebSite = pageWebSite;
	}
	public String getPageCategory() {
		return pageCategory;
	}
	public void setPageCategory(String pageCategory) {
		this.pageCategory = pageCategory;
	}
	public int getPageCheckins() {
		return pageCheckins;
	}
	public void setPageCheckins(int pageCheckins) {
		this.pageCheckins = pageCheckins;
	}
	public int getPageLikeCount() {
		return pageLikeCount;
	}
	public void setPageLikeCount(int pageLikeCount) {
		this.pageLikeCount = pageLikeCount;
	}
	public int getPageWereHereCount() {
		return pageWereHereCount;
	}
	public void setPageWereHereCount(int pageWereHereCount) {
		this.pageWereHereCount = pageWereHereCount;
	}
	public ArrayList<Article_Fb_User> getFbPageLikeUser() {
		return fbPageLikeUser;
	}
	public void setFbPageLikeUser(ArrayList<Article_Fb_User> fbPageLikeUser) {
		this.fbPageLikeUser = fbPageLikeUser;
	}
	public String getPagePicture() {
		return pagePicture;
	}
	public void setPagePicture(String pagePicture) {
		this.pagePicture = pagePicture;
	}
	public String getPageLocation() {
		return pageLocation;
	}
	public void setPageLocation(String pageLocation) {
		this.pageLocation = pageLocation;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "Article_Fb_Page [pageId=" + pageId + ", pageName=" + pageName + ", pageUserName=" + pageUserName
				+ ", pageCountry=" + pageCountry + ", pageCity=" + pageCity + ", pageZip=" + pageZip
				+ ", pageCoverSource=" + pageCoverSource + ", pagePicture=" + pagePicture + ", pageAbout=" + pageAbout
				+ ", pageLink=" + pageLink + ", pagePhone=" + pagePhone + ", pageDescription=" + pageDescription
				+ ", pageWebSite=" + pageWebSite + ", pageCategory=" + pageCategory + ", pageLocation=" + pageLocation
				+ ", pageCheckins=" + pageCheckins + ", pageLikeCount=" + pageLikeCount + ", pageWereHereCount="
				+ pageWereHereCount + ", fbPageLikeUser=" + fbPageLikeUser + "]";
	}
}
