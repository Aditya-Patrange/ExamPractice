package com.cdac.sudarshan.folder.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class UrlResponseDto {

        private String url;
        private String source;
        private String tag;
        private String profileId;
        private String resourcePath;
        private int totalUrlCount;
        private int duplicateUrlCount;

}
