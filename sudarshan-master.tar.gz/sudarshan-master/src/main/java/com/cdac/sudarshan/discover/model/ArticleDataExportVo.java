package com.cdac.sudarshan.discover.model;

import java.util.ArrayList;


public class ArticleDataExportVo 
{

	private static final long serialVersionUID = 1L;
    private String articleId;
    private String articleEmotion;
    private String articleSource;
    private String articleType;
    private String articleTitle;
    private String articleSubTitle;
    private String articleBigContent;
    private String articleAuthor;
    private String articleAuthorId;
    private String articleAuthorGender;
    private String articleAuthorReligion;
    private String articleAuthorImage;
    private String articleAuthorImageUrlLocal;
    private String articleLocation;
    private String articleLocationCity;
    private String articleLocationCountry;
    private String articleLocationCountryCode;
    private String articleUserLocation;
    private String articleUserLocationName;
    private String articleUserLocationCountry;
    private String articleUserLocationCountryCode;
    private String articleLocationPlace;
    private String articleLanguage;
    private String articleSentiment;
    
    private String fbUserId;
    private String fbUserName;
    private String fbProfilePicture;
    private String fbCoverPicture;
    private String fbPageLink;
    private String fbPostShareCount;
    private String fbPostLikeCount;
    private String fbPostCommentCount;
    private String fbPostViewerCount;
    
    private ArrayList<String> articleHashTag;
    private ArrayList<String> articleMention;
    private ArrayList<String> articleThemes; 
    private ArrayList<String> articleClassification; 
    private ArrayList<String> articleMobile; 
    private ArrayList<String> articleEmail; 
    private ArrayList<String> articleIp; 
    private ArrayList<String> articlePinCode;
    private ArrayList<String> vehicleNo;
    private ArrayList<String> mobileImeiNo; 
    private ArrayList<String> articleTimeNer; 
    private ArrayList<String> debitCreditCardNo; 
    private ArrayList<String> bankAccountNo;
    private ArrayList<String> taxonomy;
    private ArrayList<String> postImageOds;
    private ArrayList<String> postImageOcrAggs;
    private ArrayList<String> postImageFrs;
    private long articlePublishDate; 
    private ArrayList<Article_Media> articleMedia;
    private ArrayList<Articel_Ner> articlePersonNer;
    private ArrayList<Articel_Ner> articleOrganizationNer; 
    private ArrayList<Articel_Ner> articleEvent; 
    private ArrayList<Artilcle_Ner_Date> articleDateNer;
    private ArrayList<Article_NerLocation> articleLocationNer;
	public String getArticleId() {
		return articleId;
	}
	public void setArticleId(String articleId) {
		this.articleId = articleId;
	}
	public String getArticleEmotion() {
		return articleEmotion;
	}
	public void setArticleEmotion(String articleEmotion) {
		this.articleEmotion = articleEmotion;
	}
	public String getArticleSource() {
		return articleSource;
	}
	public void setArticleSource(String articleSource) {
		this.articleSource = articleSource;
	}
	public String getArticleType() {
		return articleType;
	}
	public void setArticleType(String articleType) {
		this.articleType = articleType;
	}
	public String getArticleTitle() {
		return articleTitle;
	}
	public void setArticleTitle(String articleTitle) {
		this.articleTitle = articleTitle;
	}
	public String getArticleSubTitle() {
		return articleSubTitle;
	}
	public void setArticleSubTitle(String articleSubTitle) {
		this.articleSubTitle = articleSubTitle;
	}
	public String getArticleBigContent() {
		return articleBigContent;
	}
	public void setArticleBigContent(String articleBigContent) {
		this.articleBigContent = articleBigContent;
	}
	public String getArticleAuthor() {
		return articleAuthor;
	}
	public void setArticleAuthor(String articleAuthor) {
		this.articleAuthor = articleAuthor;
	}
	public String getArticleAuthorGender() {
		return articleAuthorGender;
	}
	public void setArticleAuthorGender(String articleAuthorGender) {
		this.articleAuthorGender = articleAuthorGender;
	}
	public String getArticleAuthorReligion() {
		return articleAuthorReligion;
	}
	public void setArticleAuthorReligion(String articleAuthorReligion) {
		this.articleAuthorReligion = articleAuthorReligion;
	}
	public String getArticleAuthorId() {
		return articleAuthorId;
	}
	public void setArticleAuthorId(String articleAuthorId) {
		this.articleAuthorId = articleAuthorId;
	}
	public String getArticleAuthorImage() {
		return articleAuthorImage;
	}
	public void setArticleAuthorImage(String articleAuthorImage) {
		this.articleAuthorImage = articleAuthorImage;
	}
	public String getArticleAuthorImageUrlLocal() {
		return articleAuthorImageUrlLocal;
	}
	public void setArticleAuthorImageUrlLocal(String articleAuthorImageUrlLocal) {
		this.articleAuthorImageUrlLocal = articleAuthorImageUrlLocal;
	}
	public String getArticleLocation() {
		return articleLocation;
	}
	public void setArticleLocation(String articleLocation) {
		this.articleLocation = articleLocation;
	}
	public String getArticleLocationCity() {
		return articleLocationCity;
	}
	public void setArticleLocationCity(String articleLocationCity) {
		this.articleLocationCity = articleLocationCity;
	}
	public String getArticleLocationCountry() {
		return articleLocationCountry;
	}
	public void setArticleLocationCountry(String articleLocationCountry) {
		this.articleLocationCountry = articleLocationCountry;
	}
	public String getArticleLocationCountryCode() {
		return articleLocationCountryCode;
	}
	public void setArticleLocationCountryCode(String articleLocationCountryCode) {
		this.articleLocationCountryCode = articleLocationCountryCode;
	}
	public String getArticleUserLocation() {
		return articleUserLocation;
	}
	public void setArticleUserLocation(String articleUserLocation) {
		this.articleUserLocation = articleUserLocation;
	}
	public String getArticleUserLocationName() {
		return articleUserLocationName;
	}
	public void setArticleUserLocationName(String articleUserLocationName) {
		this.articleUserLocationName = articleUserLocationName;
	}
	public String getArticleUserLocationCountry() {
		return articleUserLocationCountry;
	}
	public void setArticleUserLocationCountry(String articleUserLocationCountry) {
		this.articleUserLocationCountry = articleUserLocationCountry;
	}
	public String getArticleUserLocationCountryCode() {
		return articleUserLocationCountryCode;
	}
	public void setArticleUserLocationCountryCode(String articleUserLocationCountryCode) {
		this.articleUserLocationCountryCode = articleUserLocationCountryCode;
	}
	public String getArticleLocationPlace() {
		return articleLocationPlace;
	}
	public void setArticleLocationPlace(String articleLocationPlace) {
		this.articleLocationPlace = articleLocationPlace;
	}
	public String getArticleLanguage() {
		return articleLanguage;
	}
	public void setArticleLanguage(String articleLanguage) {
		this.articleLanguage = articleLanguage;
	}
	public String getArticleSentiment() {
		return articleSentiment;
	}
	public void setArticleSentiment(String articleSentiment) {
		this.articleSentiment = articleSentiment;
	}
	public String getFbUserId() {
		return fbUserId;
	}
	public void setFbUserId(String fbUserId) {
		this.fbUserId = fbUserId;
	}
	public String getFbUserName() {
		return fbUserName;
	}
	public void setFbUserName(String fbUserName) {
		this.fbUserName = fbUserName;
	}
	public String getFbProfilePicture() {
		return fbProfilePicture;
	}
	public void setFbProfilePicture(String fbProfilePicture) {
		this.fbProfilePicture = fbProfilePicture;
	}
	public String getFbCoverPicture() {
		return fbCoverPicture;
	}
	public void setFbCoverPicture(String fbCoverPicture) {
		this.fbCoverPicture = fbCoverPicture;
	}
	public String getFbPageLink() {
		return fbPageLink;
	}
	public void setFbPageLink(String fbPageLink) {
		this.fbPageLink = fbPageLink;
	}
	public String getFbPostShareCount() {
		return fbPostShareCount;
	}
	public void setFbPostShareCount(String fbPostShareCount) {
		this.fbPostShareCount = fbPostShareCount;
	}
	public String getFbPostLikeCount() {
		return fbPostLikeCount;
	}
	public void setFbPostLikeCount(String fbPostLikeCount) {
		this.fbPostLikeCount = fbPostLikeCount;
	}
	public String getFbPostCommentCount() {
		return fbPostCommentCount;
	}
	public void setFbPostCommentCount(String fbPostCommentCount) {
		this.fbPostCommentCount = fbPostCommentCount;
	}
	public String getFbPostViewerCount() {
		return fbPostViewerCount;
	}
	public void setFbPostViewerCount(String fbPostViewerCount) {
		this.fbPostViewerCount = fbPostViewerCount;
	}
	public ArrayList<String> getArticleHashTag() {
		return articleHashTag;
	}
	public void setArticleHashTag(ArrayList<String> articleHashTag) {
		this.articleHashTag = articleHashTag;
	}
	public ArrayList<String> getArticleMention() {
		return articleMention;
	}
	public void setArticleMention(ArrayList<String> articleMention) {
		this.articleMention = articleMention;
	}
	public ArrayList<String> getArticleThemes() {
		return articleThemes;
	}
	public void setArticleThemes(ArrayList<String> articleThemes) {
		this.articleThemes = articleThemes;
	}
	public ArrayList<String> getArticleClassification() {
		return articleClassification;
	}
	public void setArticleClassification(ArrayList<String> articleClassification) {
		this.articleClassification = articleClassification;
	}
	public ArrayList<String> getArticleMobile() {
		return articleMobile;
	}
	public void setArticleMobile(ArrayList<String> articleMobile) {
		this.articleMobile = articleMobile;
	}
	public ArrayList<String> getArticleEmail() {
		return articleEmail;
	}
	public void setArticleEmail(ArrayList<String> articleEmail) {
		this.articleEmail = articleEmail;
	}
	public ArrayList<String> getArticleIp() {
		return articleIp;
	}
	public void setArticleIp(ArrayList<String> articleIp) {
		this.articleIp = articleIp;
	}
	public ArrayList<String> getArticlePinCode() {
		return articlePinCode;
	}
	public void setArticlePinCode(ArrayList<String> articlePinCode) {
		this.articlePinCode = articlePinCode;
	}
	public ArrayList<String> getVehicleNo() {
		return vehicleNo;
	}
	public void setVehicleNo(ArrayList<String> vehicleNo) {
		this.vehicleNo = vehicleNo;
	}
	public ArrayList<String> getMobileImeiNo() {
		return mobileImeiNo;
	}
	public void setMobileImeiNo(ArrayList<String> mobileImeiNo) {
		this.mobileImeiNo = mobileImeiNo;
	}
	public ArrayList<String> getArticleTimeNer() {
		return articleTimeNer;
	}
	public void setArticleTimeNer(ArrayList<String> articleTimeNer) {
		this.articleTimeNer = articleTimeNer;
	}
	public ArrayList<String> getDebitCreditCardNo() {
		return debitCreditCardNo;
	}
	public void setDebitCreditCardNo(ArrayList<String> debitCreditCardNo) {
		this.debitCreditCardNo = debitCreditCardNo;
	}
	public ArrayList<String> getBankAccountNo() {
		return bankAccountNo;
	}
	public void setBankAccountNo(ArrayList<String> bankAccountNo) {
		this.bankAccountNo = bankAccountNo;
	}
	public ArrayList<String> getTaxonomy() {
		return taxonomy;
	}
	public void setTaxonomy(ArrayList<String> taxonomy) {
		this.taxonomy = taxonomy;
	}
	public ArrayList<String> getPostImageOds() {
		return postImageOds;
	}
	public void setPostImageOds(ArrayList<String> postImageOds) {
		this.postImageOds = postImageOds;
	}
	public ArrayList<String> getPostImageOcrAggs() {
		return postImageOcrAggs;
	}
	public void setPostImageOcrAggs(ArrayList<String> postImageOcrAggs) {
		this.postImageOcrAggs = postImageOcrAggs;
	}
	public ArrayList<String> getPostImageFrs() {
		return postImageFrs;
	}
	public void setPostImageFrs(ArrayList<String> postImageFrs) {
		this.postImageFrs = postImageFrs;
	}
	public long getArticlePublishDate() {
		return articlePublishDate;
	}
	public void setArticlePublishDate(long articlePublishDate) {
		this.articlePublishDate = articlePublishDate;
	}
	public ArrayList<Article_Media> getArticleMedia() {
		return articleMedia;
	}
	public void setArticleMedia(ArrayList<Article_Media> articleMedia) {
		this.articleMedia = articleMedia;
	}
	public ArrayList<Articel_Ner> getArticlePersonNer() {
		return articlePersonNer;
	}
	public void setArticlePersonNer(ArrayList<Articel_Ner> articlePersonNer) {
		this.articlePersonNer = articlePersonNer;
	}
	public ArrayList<Articel_Ner> getArticleOrganizationNer() {
		return articleOrganizationNer;
	}
	public void setArticleOrganizationNer(ArrayList<Articel_Ner> articleOrganizationNer) {
		this.articleOrganizationNer = articleOrganizationNer;
	}
	public ArrayList<Articel_Ner> getArticleEvent() {
		return articleEvent;
	}
	public void setArticleEvent(ArrayList<Articel_Ner> articleEvent) {
		this.articleEvent = articleEvent;
	}
	public ArrayList<Artilcle_Ner_Date> getArticleDateNer() {
		return articleDateNer;
	}
	public void setArticleDateNer(ArrayList<Artilcle_Ner_Date> articleDateNer) {
		this.articleDateNer = articleDateNer;
	}
	public ArrayList<Article_NerLocation> getArticleLocationNer() {
		return articleLocationNer;
	}
	public void setArticleLocationNer(ArrayList<Article_NerLocation> articleLocationNer) {
		this.articleLocationNer = articleLocationNer;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "ArticleDataExportVo [articleId=" + articleId + ", articleEmotion=" + articleEmotion + ", articleSource="
				+ articleSource + ", articleType=" + articleType + ", articleTitle=" + articleTitle
				+ ", articleSubTitle=" + articleSubTitle + ", articleBigContent=" + articleBigContent
				+ ", articleAuthor=" + articleAuthor + ", articleAuthorId=" + articleAuthorId + ", articleAuthorGender="
				+ articleAuthorGender + ", articleAuthorReligion=" + articleAuthorReligion + ", articleAuthorImage="
				+ articleAuthorImage + ", articleAuthorImageUrlLocal=" + articleAuthorImageUrlLocal
				+ ", articleLocation=" + articleLocation + ", articleLocationCity=" + articleLocationCity
				+ ", articleLocationCountry=" + articleLocationCountry + ", articleLocationCountryCode="
				+ articleLocationCountryCode + ", articleUserLocation=" + articleUserLocation
				+ ", articleUserLocationName=" + articleUserLocationName + ", articleUserLocationCountry="
				+ articleUserLocationCountry + ", articleUserLocationCountryCode=" + articleUserLocationCountryCode
				+ ", articleLocationPlace=" + articleLocationPlace + ", articleLanguage=" + articleLanguage
				+ ", articleSentiment=" + articleSentiment + ", fbUserId=" + fbUserId + ", fbUserName=" + fbUserName
				+ ", fbProfilePicture=" + fbProfilePicture + ", fbCoverPicture=" + fbCoverPicture + ", fbPageLink="
				+ fbPageLink + ", fbPostShareCount=" + fbPostShareCount + ", fbPostLikeCount=" + fbPostLikeCount
				+ ", fbPostCommentCount=" + fbPostCommentCount + ", fbPostViewerCount=" + fbPostViewerCount
				+ ", articleHashTag=" + articleHashTag + ", articleMention=" + articleMention + ", articleThemes="
				+ articleThemes + ", articleClassification=" + articleClassification + ", articleMobile="
				+ articleMobile + ", articleEmail=" + articleEmail + ", articleIp=" + articleIp + ", articlePinCode="
				+ articlePinCode + ", vehicleNo=" + vehicleNo + ", mobileImeiNo=" + mobileImeiNo + ", articleTimeNer="
				+ articleTimeNer + ", debitCreditCardNo=" + debitCreditCardNo + ", bankAccountNo=" + bankAccountNo
				+ ", taxonomy=" + taxonomy + ", postImageOds=" + postImageOds + ", postImageOcrAggs=" + postImageOcrAggs
				+ ", postImageFrs=" + postImageFrs + ", articlePublishDate=" + articlePublishDate + ", articleMedia="
				+ articleMedia + ", articlePersonNer=" + articlePersonNer + ", articleOrganizationNer="
				+ articleOrganizationNer + ", articleEvent=" + articleEvent + ", articleDateNer=" + articleDateNer
				+ ", articleLocationNer=" + articleLocationNer + "]";
	}


}
