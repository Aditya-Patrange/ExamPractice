package com.cdac.sudarshan.discover.model;

import java.io.Serializable;

public class TwitterUserInfo implements  Serializable 
{
	private static final long serialVersionUID = 1L;
	String id,name,screenName,description,image,following,follower,favourite;
	private boolean verified;

	public TwitterUserInfo() 
	{
		super();
	}

	public TwitterUserInfo(String id, String name, String screenName,
			String description, String image, String following,
			String follower, String favourite,boolean verified) 
	{
		super();
		this.id = id;
		this.name = name;
		this.screenName = screenName;
		this.description = description;
		this.image = image;
		this.following = following;
		this.follower = follower;
		this.favourite = favourite;
		this.verified = verified;
	}


	public boolean isVerified() {
		return verified;
	}

	public void setVerified(boolean verified) {
		this.verified = verified;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getScreenName() {
		return screenName;
	}

	public void setScreenName(String screenName) {
		this.screenName = screenName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getFollowing() {
		return following;
	}

	public void setFollowing(String following) {
		this.following = following;
	}

	public String getFollower() {
		return follower;
	}

	public void setFollower(String follower) {
		this.follower = follower;
	}

	public String getFavourite() {
		return favourite;
	}

	public void setFavourite(String favourite) {
		this.favourite = favourite;
	}
	
}
