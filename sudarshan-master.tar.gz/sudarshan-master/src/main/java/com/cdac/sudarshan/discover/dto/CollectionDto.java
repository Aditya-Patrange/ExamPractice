package com.cdac.sudarshan.discover.dto;

import java.sql.Timestamp;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
@Setter
@Getter
@RequiredArgsConstructor
//@NoArgsConstructor
@AllArgsConstructor
public class CollectionDto {

	private String collectionType;
	private String deactivationDate;
	private String hasAnalysis;
	private String clientId;
	private String activationDate;
	private String priority;
	private String keyword;
	private String sources;
	private String userId;
	private String collectionName;
	private String analysisName;
	
//	
//	private String collectionType;
//	private Timestamp deactivationDate;
//	private String hasAnalysis;
//	private String clientId;
//	private Timestamp activationDate;
//	private String priority;
//	private List<String> keyword;
//	private List<String> sources;
//	private String userId;
//	private String collectionName;
//	private String analysisName;
}
