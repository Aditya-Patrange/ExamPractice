

package com.cdac.sudarshan.watchlist.dto;

import java.time.Instant;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class WatchlistDashboardDto {
	
	private String entityAttribute;
	private Instant endDate;
	private String priority;
	private String status;

}
