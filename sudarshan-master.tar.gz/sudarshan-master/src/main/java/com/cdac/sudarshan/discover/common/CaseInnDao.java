package com.cdac.sudarshan.discover.common;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;

import org.springframework.web.multipart.MultipartFile;



public interface CaseInnDao 
{
	public ArrayList<CaseVo> caseCrud(CaseVo caseVo);
	public LoginDetails validateUser(String userName,String password);

	public void entityCurd(CaseVo caseVo);
	public void setCaseForAnalysis(CaseVo caseVo);
	public ArrayList<EntityVo> entitySelect(CaseVo caseVo);
	public ArrayList<EntityVo> caseEntitySelectById(CaseVo caseVo);
	public ArrayList<EntityVo> entitySelectAll(CaseVo caseVo);
	public ArrayList<CaseVo> selectCase(CaseVo caseVo);
	public ArrayList<CaseVo> selectAllCase(CaseVo caseVo);
	public void markCase(CaseVo caseVo);
	public void actDeactivate(CaseVo caseVo);

	public void  analysisCurd(CaseVo caseVo);
	public ArrayList<CaseVo> selectAnalysisForEdit(CaseVo caseVo); 
	public ArrayList<LoginDetails> createUser(LoginDetails loginDetails);
	public LoginDetails selectUserById(LoginDetails loginDetails);
	public ArrayList<CaseVo> getCaseForAnalysis();
	public int setTwProfileEntity(EntityVo entityVo);
	public String activateDeActivateEntity(EntityVo entityVo);
	public ArrayList<LoginDetails> createFbUser(LoginDetails loginDetails);
	public ArrayList<LoginDetails> createFbUserProf(LoginDetails loginDetails);
	public ArrayList<LoginDetails> selectFbUserById(LoginDetails loginDetails);
	public void mapFbProfileToAccount(LoginDetails loginDetails);
	
	public void apiUrl(CaseVo caseVo);
	public ArrayList<CaseVo> apiSelectUrl(CaseVo caseVo);
	public ArrayList<CaseVo> apiDltUrl(CaseVo caseVo);
	public ArrayList<LoginDetails> slctAccountFb(LoginDetails loginDetails);
	public ArrayList<LoginDetails> innsightUserLoginLimit(LoginDetails loginDetails);
	public ArrayList<CaseVo> getUserAccessTemplate(CaseVo caseVo);
	public boolean editMaxInnsightUserLoginConnection(LoginDetails loginDetails);
	public void insertManageCrawler(ManageCrawlerVo manageCrawlerVo);
	public ArrayList<ManageCrawlerVo> getManageCrawler(ManageCrawlerVo manageCrawlerVo);
	public void deleteManageCrawler(ManageCrawlerVo manageCrawlerVo);
	public ArrayList<CrawlerSourceVo> getCrawlerSources(ManageCrawlerVo manageCrawlerVo);
	
	//***************Save Search****************//
	public LinkedHashMap<String, String> setFilter(SaveFilterVo saveFilterVo);
	public boolean saveFilterForTrackTwKeyword(SaveFilterVo saveFilterVo);
	public ArrayList<SaveFilterVo> getSaveFilter(SaveFilterVo saveFilterVo);
	public void deleteSaveFilter(SaveFilterVo saveFilterVo);
	public ArrayList<SaveFilterVo> getFilterValues(SaveFilterVo saveFilterVo);
	public void accountinsrt(AccountAliasVo accountAliasVo);
	public ArrayList<EntityVo> entitySelectByFilter(CaseVo caseVo);

	public ArrayList<EntityVo> getEntityNameIdFromCase(CaseVo caseVo);
	public ArrayList<CaseVo> getProxyAvatar(CaseVo caseVo);
	public void addProxyAvatar(CaseVo caseVo);
	public ArrayList<CaseVo> dltProxyIP(CaseVo caseVo);
	public ArrayList<CaseVo> getProxyCountry(CaseVo caseVo);
	public void addSrcUserAvatar(CaseVo caseVo);
	public String addSrcUserCentralAvatar(CaseVo caseVo);
	public ArrayList<CaseVo> getSourcesAvatar(CaseVo caseVo);
	public ArrayList<CaseVo> getSourcesCentralAvatar(CaseVo caseVo);
	public ArrayList<CentralAvatarVo> getAvatarToSyncCentralCrawlerServer(CentralAvatarVo centralAvatarVo);
	public ArrayList<CaseVo> dltSrcAvatar(CaseVo caseVo);
	public boolean dltSrcCentralAvatar(CaseVo caseVo);
	
	//Central Ceawling
	public ArrayList<CentralAvatarVo> getActiveAvatarForCentralCrawling(CentralAvatarVo centralAvatarVo);
	public String addDataCollectionJobsCnf(CaseVo caseVo);

	
	
	
	
	
	//*********USER PROFILR VIEW REPORT**********************************//
	//ADD
	public boolean addUserProfileBasicInformations(UserProfileBasicInformationVo basicInformationVo) throws FileNotFoundException;  
	public boolean addUsersProfilePhotoForUpload(MultipartFile file);
	public boolean addSuspectPhotoForUpload(MultipartFile file, String profileId);
	public boolean addUsersProfileCoverPhotoForUpload(MultipartFile file);
	public boolean addUserProfileAlias(UserProfileAliasVo aliasVo);
	public boolean addUserProfileContact(UserProfileContactVo contactVo);
	public boolean addUserProfileSocialAccount(UserProfileSocialAccountVo socialAccountVo);
	public boolean addUserProfileAssociatedFriends(UserProfileAssociatedFriendsVo associatedFriendsVo);
	public boolean addUserProfileAssociatedHandles(UserProfileAssociatedHandlesVo associatedHandlesVo);
	public boolean addUserProfileAssociatedEvents(UserProfileAssociatedEventsVo associatedEventsVo);
	public boolean addUserProfileAssociatedLocations(UserProfileAssociatedLocationsVo associatedLocationsVo);
	public boolean addUserProfileAssociatedOrganizations(UserProfileAssociatedOrganizationsVo associatedOrganizationsVo);
	//SELECT
	public ArrayList<UserProfileBasicInformationVo> getUserProfileBasicInformationsDetails(UserProfileBasicInformationVo basicInformationVo);
	public ArrayList<UserProfileBasicInformationVo> getTargetCurrentAddedUserProfileBasicInfo(UserProfileBasicInformationVo basicInformationVo);
	public ArrayList<UserProfileBasicInformationVo> getTargetUserProfileBasicInfo(UserProfileBasicInformationVo basicInformationVo);
	
	public ArrayList<UserProfileAliasVo> getUserProfileAliasDetails(UserProfileAliasVo aliasVo);
	public ArrayList<UserProfileContactVo> getUserProfileContactDetails(UserProfileContactVo contactVo);
	public ArrayList<UserProfileContactVo> getTargetProfileContactDetailsForEdit(UserProfileContactVo contactVo);
	public ArrayList<UserProfileSocialAccountVo> getUserProfileSocialAccountDetails(
			UserProfileSocialAccountVo socialAccountVo);
	public ArrayList<UserProfileAssociatedFriendsVo> getUserProfileAssociatedFriendsDetails(
			UserProfileAssociatedFriendsVo associatedFriendsVo);
	public ArrayList<UserProfileAssociatedHandlesVo> getUserProfileAssociatedHandlesDetails(
			UserProfileAssociatedHandlesVo associatedHandlesVo);
	public ArrayList<UserProfileAssociatedEventsVo> getUserProfileAssociatedEventsDetails(
			UserProfileAssociatedEventsVo associatedEventsVo);
	public ArrayList<UserProfileAssociatedLocationsVo> getUserProfileAssociatedLocationsDetails(
			UserProfileAssociatedLocationsVo associatedLocationsVo);
	public ArrayList<UserProfileAssociatedOrganizationsVo> getUserProfileAssociatedOrganizationsDetails(
			UserProfileAssociatedOrganizationsVo associatedOrganizationsVo);
	//DELETE
	public ArrayList<UserProfileBasicInformationVo> deleteUserProfileBasicInformations(
			UserProfileBasicInformationVo basicInformationVo);
	public ArrayList<UserProfileAliasVo> deleteUserProfileAlias(UserProfileAliasVo aliasVo);
	public ArrayList<UserProfileContactVo> deleteUserProfileContact(UserProfileContactVo contactVo);
	public ArrayList<UserProfileSocialAccountVo> deleteUserProfileSocialAccount(
			UserProfileSocialAccountVo socialAccountVo);
	public ArrayList<UserProfileAssociatedFriendsVo> deleteUserProfileAssociatedFriends(
			UserProfileAssociatedFriendsVo associatedFriendsVo);
	public ArrayList<UserProfileAssociatedHandlesVo> deleteUserProfileAssociatedHandles(
			UserProfileAssociatedHandlesVo associatedHandlesVo);
	public ArrayList<UserProfileAssociatedEventsVo> deleteUserProfileAssociatedEvents(
			UserProfileAssociatedEventsVo associatedEventsVo);
	public ArrayList<UserProfileAssociatedLocationsVo> deleteUserProfileAssociatedLocations(
			UserProfileAssociatedLocationsVo associatedLocationsVo);
	public ArrayList<UserProfileAssociatedOrganizationsVo> deleteUserProfileAssociatedOrganizations(
			UserProfileAssociatedOrganizationsVo associatedOrganizationsVo);
	//UPDATE
	public boolean editUserProfileBasicInformations(UserProfileBasicInformationVo basicInformationVo);
	public boolean editUserProfileAlias(UserProfileAliasVo aliasVo);
	public boolean editUserProfileContact(UserProfileContactVo contactVo);
	public boolean editUserProfileSocialAccount(UserProfileSocialAccountVo socialAccountVo);
	public boolean editUserProfileAssociatedFriends(UserProfileAssociatedFriendsVo associatedFriendsVo);
	public boolean editUserProfileAssociatedHandles(UserProfileAssociatedHandlesVo associatedHandlesVo);
	public boolean editUserProfileAssociatedEvents(UserProfileAssociatedEventsVo associatedEventsVo);
	public boolean editUserProfileAssociatedLocations(UserProfileAssociatedLocationsVo associatedLocationsVo);
	public boolean editUserProfileAssociatedOrganizations(UserProfileAssociatedOrganizationsVo associatedOrganizationsVo);
	
	public ArrayList<UserProfilePhotoVo> getUserProfileCoverPhoto(UserProfilePhotoVo photoVo);
	public ArrayList<UserProfilePhotoVo> getUserProfilePhoto(UserProfilePhotoVo photoVo);
	public void saveSocialAccountToTargetView(CaseVo caseVo);
	public ArrayList<UserProfileBasicInformationVo> getTargetProfileBasicInformationsDetailsReport(UserProfileBasicInformationVo basicInformationVo);
	public ArrayList<UserProfilePhotoVo> getTargetProfileCoverPhotoReport(UserProfilePhotoVo photoVo);
	public ArrayList<UserProfilePhotoVo> getTargetProfilePhotoReport(UserProfilePhotoVo photoVo);
	public ArrayList<UserProfileContactVo> getTargetProfileContactDetailsReport(UserProfileContactVo contactVo);
	public void saveSocialMediaAccountToTargetProfileView(CaseVo caseVo);
	
	public ArrayList<CaseVo> getMappedProxy(CaseVo caseVo);
	public ArrayList<CaseVo> getMappedProxyByCntry(CaseVo caseVo);
	public ArrayList<CaseVo> getMenuCountry(CaseVo caseVo);
	public ArrayList<CaseVo> getCountryRssMap(CaseVo caseVo);
	public void addUserAlerts(CaseVo caseVo);
	public ArrayList<CaseVo> getAlertByUsers(CaseVo caseVo);
	public ArrayList<CaseVo> dltUserAlerts(CaseVo caseVo);
	public void actDactAlertValue(CaseVo caseVo);
	public ArrayList<CaseVo> getAlertByUsersId(CaseVo caseVo);
	
	public boolean addOrganizationViewBasicInformationDetails(OrganizationBasicInformationVo orgBasicInfo);
	public ArrayList<OrganizationBasicInformationVo> getTargetOrganizationBasicInformationsDetails(
			OrganizationBasicInformationVo orgBasicInfo);
	public ArrayList<OrganizationBasicInformationVo> getTargetOrganizationBasicInformationsForEdit(
			OrganizationBasicInformationVo orgBasicInfo);
	public ArrayList<OrganizationBasicInformationVo> deleteTargetOrganizationBasicInformations(
			OrganizationBasicInformationVo orgBasicInfo);
	public boolean addOrganizationProfilePhotoForUpload(MultipartFile file);
	public boolean addOrganizationProfileCoverPhotoForUpload(MultipartFile file);
	public ArrayList<OrganizationPhotoVo> getOrganizationCoverPhoto(OrganizationPhotoVo photoVo);
	public ArrayList<OrganizationPhotoVo> getOrganizationProfilePhoto(OrganizationPhotoVo photoVo);
	public boolean editOrganizationBasicInformationsDetails(OrganizationBasicInformationVo orgBasicInfo);

	public ArrayList<OrganizationBasicInformationVo> getTargetOrganizationBasicInformationsDetailsReport(OrganizationBasicInformationVo orgInfoVo);
	public ArrayList<OrganizationPhotoVo> getTargetOrganizationCoverPhotoReport(OrganizationPhotoVo photoVo);
	public ArrayList<OrganizationPhotoVo> getTargetOrganizationProfilePhotoReport(OrganizationPhotoVo photoVo);
	public ArrayList<UserProfileBasicInformationVo> getTargetProfileBasicInformationsForEdit(
			UserProfileBasicInformationVo basicInformationVo);

	
	public ArrayList<CaseVo> getAlertWorkDaysById(CaseVo caseVo);
	public ArrayList<CaseVo> getAlertDetails(CaseVo caseVo);
	public ArrayList<CaseVo> getAlertCounts(CaseVo caseVo);
	public void updateAlertReadStatus(CaseVo caseVo);
	public void updateAlertStatusRead(CaseVo caseVo);
	public ArrayList<CaseVo> getAlertByStatusType(CaseVo caseVo);
	public ArrayList<CaseVo> setViewbyAlertId(CaseVo caseVo);
	
	public int getTargetUserProfileSocialAccountSize(UserProfileSocialAccountVo accountVo);
	public ArrayList<EntityVo> getTargetProfileRelatedSocialMediaAccountsDetails(EntityVo entityVo);
	public void saveSocialMediaAccountToTargetOrganizationView(CaseVo caseVo);
	public ArrayList<EntityVo> getTargetOrganizationRelatedSocialMediaAccountsDetails(EntityVo entityVo);
	public ArrayList<OrganizationBasicInformationVo> getCurrentAddedTargetOrganizationBasicInfo(
			OrganizationBasicInformationVo basicInformationVo);
	public void addTargetOrganizationContact(OrganizationContactVo contactVo);
	public void editTargetOrganizationContact(OrganizationContactVo contactVo);
	public void deleteTargetOrganizationContact(OrganizationContactVo contactVo);
	public ArrayList<OrganizationContactVo> getTargetOrganizationContactList(OrganizationContactVo contactVo);
	
	//SEARCH ANALYSIS PROFILE FROM SYSTEM:======================================
	public ArrayList<EntityVo> searchTwitterUserFromSystems(EntityVo twUser);
	public ArrayList<EntityVo> searchFbPageFromSystems(EntityVo fbPage);
	public ArrayList<EntityVo> searchFbGroupFromSystems(EntityVo fbGroup);
	public ArrayList<EntityVo> searchFbProfileFromSystems(EntityVo fbProfile);
	public ArrayList<EntityVo> searchInstaUserFromSystems(EntityVo instaUser);
	public ArrayList<EntityVo> searchYoutubeChannleFromSystems(EntityVo ytUser);
	public ArrayList<EntityVo> searchGbUsersFromSystems(EntityVo gbUser);
	public ArrayList<EntityVo> searchTmUsersFromSystems(EntityVo tmUser);
	public ArrayList<EntityVo> searchDMUserFromSystems(EntityVo dmUser);
	public ArrayList<EntityVo> searchRedditUsersFromSystems(EntityVo redditUser);
	public ArrayList<EntityVo> searchFlickrUsersFromSystems(EntityVo flickrUser);
	public ArrayList<EntityVo> searchLinkedinUsersFromSystems(EntityVo linkedinUser);
    //========================================================================
	public ArrayList<CaseVo> getCountryState(CaseVo caseVo);
	public ArrayList<CaseVo> getStateCity(CaseVo caseVo);
	public void actDeactivateAvatar(CaseVo caseVo);
	
	//NER ALias add/Replace/ignore
	public void addAlias(CaseVo caseVo);
	public ArrayList<CaseVo> getNerAlias(CaseVo caseVo);
	public void addAliasIgnore(CaseVo caseVo);
	public ArrayList<CaseVo> getAliasIgnore(CaseVo caseVo);
	public void addAliasReplace(CaseVo caseVo);
	public ArrayList<CaseVo> getAliasReplace(CaseVo caseVo);
	public ArrayList<CaseVo> getAllDistinctAliasEntity(CaseVo caseVo);	
	
	//Advance Facebook User Search
	public void addFbUserToSearch(CaseVo caseVo);
	public ArrayList<CaseVo> getFbUserAfterSearch(CaseVo caseVo);
	public void deleteFbUserToSearch(CaseVo caseVo);
	public ArrayList<CaseVo> getFbUserListAfterSearch(CaseVo caseVo);	
	public void addFacebookProfileToCrawl(CaseVo caseVo);
	public void hideAndUpdareFbUserAddToCrawlerFlag(CaseVo caseVo);
	public void showAndUpdareFbUserAddToCrawlerFlag(CaseVo caseVo);
	
	
	public String deleteEntityInnsight(CaseVo caseVo);
	public String deleteMultipleEntityInnsight(CaseVo caseVo);
	public void addProfileCategory(CaseVo caseVo);
	public ArrayList<CaseVo> getCategory(CaseVo caseVo);
	public ArrayList<CaseVo> getCollectionCategory(CaseVo caseVo);
	public ArrayList<CaseVo> getProfileCategoryDetaisInfo(CaseVo caseVo);
	public void editProfileCategory(CaseVo caseVo);
	public void deleteProfileCategory(CaseVo caseVo);
	public ArrayList<CaseVo> totalProfileCategoryCount(CaseVo caseVo);
	public ArrayList<EntityVo> getProfileDetailsForEdit(CaseVo caseVo);
	public void editProCategoryMap(EntityVo entityVo);
	public void editProfileCountryCode(EntityVo entityVo);
	public ArrayList<CaseVo> checkFbProAddedValue(CaseVo caseVo);
	public ArrayList<ProfileFinderResult> srchFbProfileByMobileEmail(EntityVo fbPage);
	public void saveFbUserMobileEmail(CaseVo caseVo);
	public void mobileEmailDelete(CaseVo caseVo);
	
	public ArrayList<ProfileFinderResult> getFinderNewResults();
	public void updateFinderNewResultStatus();
	
	public boolean deleteSnapshot(SaveFilterVo saveFilterVo);
	public ArrayList<SaveFilterVo> getSnapshotsById(SaveFilterVo saveFilterVo);
	public boolean entityNewCurd(CaseVo caseVo);
	
	public ArrayList<UserProfilePhotoVo> getImagesForProfileId(UserProfilePhotoVo userProfilePhotoVo);
	public boolean deleteSuspectPhoto(UserProfilePhotoVo userProfilePhotoVo);
	public ArrayList<CaseVo> getAllLoginUsers(CaseVo caseVo);
	public ArrayList<CaseVo> getUserLogsEs(CaseVo caseVo);
	public boolean updateProfileFinderMobileDeviceHealthStatus();
	public boolean checkLoginUserAccount(LoginDetails loginDetails);
	public CaseVo searchLatLonFromES(CaseVo caseVo);
	public boolean checkUserCreationLimit(CaseVo caseVo);
	
	public ArrayList<String> blacklistKeywords();
	public boolean saveNerToWordCloud(CaseVo caseVo);
	public HashMap<String, ArrayList<String>> nerIgnoreKeywords();
	public ArrayList<CaseVo> getODSObjectData(CaseVo caseVo);
	public ArrayList<CaseVo> getAnalysisSnapDetails(CaseVo caseVo);
	public ArrayList<CaseVo> getAnalysisSnapDetailsById(CaseVo caseVo);
	public boolean deleteAnalysisSnap(CaseVo caseVo);
	public boolean editAnalysisSnapDetailsById(CaseVo caseVo);
	public ArrayList<CaseVo> getThreatKeyword(CaseVo caseVo);
	public ArrayList<CaseVo> getThreatScoreKeyword(CaseVo caseVo);
	public boolean addThreatScoreKeyword(CaseVo caseVo);
	public boolean deleteThreatScoreKeyword(CaseVo caseVo);
	public boolean getThreatScoreFlag(CaseVo caseVo);
	public boolean writeThreatKeywordInSentimentService(CaseVo caseVo);
	public ArrayList<CaseVo> getAnalysisDetailsByUser(CaseVo caseVo);
	public ArrayList<CaseVo> getSnapshortDetailsByUser(CaseVo caseVo);
	public boolean addExportReportInfo(CaseVo caseVo);
	public ArrayList<CaseVo> getExportReportDetails(CaseVo caseVo);
	
	
	
	
	
	

}