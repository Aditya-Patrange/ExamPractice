package com.cdac.sudarshan.watchlist.controller;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cdac.sudarshan.watchlist.service.IAvatarService;

@RestController
@RequestMapping("/avatar")
@CrossOrigin("*")
public class AvatarController {

	@Autowired
	private IAvatarService avatarService;

	@PostMapping("/getAllAvatar")
	public ResponseEntity<?> getAvatarList(@RequestBody HashMap<String, Object> data) {
		return new ResponseEntity<>(avatarService.getAvatarList(data), HttpStatus.OK);
	}

	@PostMapping("/addNewAvatar")
	public ResponseEntity<?> addNewAvatar(@RequestBody HashMap<String, Object> data) {
		return new ResponseEntity<>(avatarService.addNewAvatar(data), HttpStatus.OK);
	}

	@PostMapping("/selectAllProxy")
	public ResponseEntity<?> selectAllProxy(@RequestBody HashMap<String, Object> data) {
		return new ResponseEntity<>(avatarService.selectAllProxy(data), HttpStatus.OK);
	}

	@PostMapping("/selectProxyById")
	public ResponseEntity<?> selectProxyById(@RequestBody HashMap<String, Object> data) {
		return new ResponseEntity<>(avatarService.selectProxyById(data), HttpStatus.OK);
	}

	@PostMapping("/addNewProxy")
	public ResponseEntity<?> addNewProxy(@RequestBody HashMap<String, Object> data) {
		return new ResponseEntity<>(avatarService.addNewProxy(data), HttpStatus.OK);
	}

	@PostMapping("/selectAllMaster")
	public ResponseEntity<?> selectAllMaster(@RequestBody HashMap<String, Object> data) {
		return new ResponseEntity<>(avatarService.selectAllMaster(data), HttpStatus.OK);
	}

	@PostMapping("updateAvatar")
	public ResponseEntity<?> updateAvatar(@RequestBody HashMap<String, Object> data) {
		return new ResponseEntity<>(avatarService.updateAvatar(data), HttpStatus.OK);
	}

	@PostMapping("selectAvatarById/{id}")
	public ResponseEntity<?> selectAvatarById(@PathVariable String id, @RequestBody HashMap<String, Object> data) {
		return new ResponseEntity<>(avatarService.selectAvatarById(id, data), HttpStatus.OK);
	}

	@PostMapping("deleteAvatarById/{id}")
	public ResponseEntity<?> deleteAvatarById(@PathVariable String id) {
		return new ResponseEntity<>(avatarService.deleteAvatarById(id), HttpStatus.OK);
	}

	@PostMapping("updateProxy")
	public ResponseEntity<?> updateProxy(@RequestBody HashMap<String, Object> data) {
		return new ResponseEntity<>(avatarService.updateProxy(data), HttpStatus.OK);
	}
	
//	deleteProxyById?id=4be3e08313b73d927420ad60ee2ff746
			@PostMapping("deleteProxyById/{id}")
	public ResponseEntity<?> deleteProxyById(@PathVariable String id) {
		return new ResponseEntity<>(avatarService.deleteProxyById(id), HttpStatus.OK);
	}
	
}