package com.cdac.sudarshan.discover.model;

import java.io.Serializable;

public class SearchEngine implements Serializable 
{
	private static final long serialVersionUID = 1L;
	private	String searchEngineName;
	private String jsonEncriptData;
	private String jsonData;
	private String dataUrl;
	public String getSearchEngineName() {
		return searchEngineName;
	}
	public void setSearchEngineName(String searchEngineName) {
		this.searchEngineName = searchEngineName;
	}
	public String getJsonEncriptData() {
		return jsonEncriptData;
	}
	public void setJsonEncriptData(String jsonEncriptData) {
		this.jsonEncriptData = jsonEncriptData;
	}
	public String getJsonData() {
		return jsonData;
	}
	public void setJsonData(String jsonData) {
		this.jsonData = jsonData;
	}
	public String getDataUrl() {
		return dataUrl;
	}
	public void setDataUrl(String dataUrl) {
		this.dataUrl = dataUrl;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "SearchEngine [searchEngineName=" + searchEngineName + ", jsonEncriptData=" + jsonEncriptData
				+ ", jsonData=" + jsonData + ", dataUrl=" + dataUrl + "]";
	}
	
}
