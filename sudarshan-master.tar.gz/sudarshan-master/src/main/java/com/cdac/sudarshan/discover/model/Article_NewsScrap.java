package com.cdac.sudarshan.discover.model;

import java.io.Serializable;

public class Article_NewsScrap implements Serializable
{
	private static final long serialVersionUID = 1L;
	private String author;
	private String title;
	private String content;
	private String summary;
	private String linkUrl;
	private String country;
	private String countryCode;
	private String articleNewsCategory;
    private long publishDate;

	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getSummary() {
		return summary;
	}
	public void setSummary(String summary) {
		this.summary = summary;
	}
	public String getLinkUrl() {
		return linkUrl;
	}
	public void setLinkUrl(String linkUrl) {
		this.linkUrl = linkUrl;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getArticleNewsCategory() {
		return articleNewsCategory;
	}
	public void setArticleNewsCategory(String articleNewsCategory) {
		this.articleNewsCategory = articleNewsCategory;
	}
	public long getPublishDate() {
		return publishDate;
	}
	public void setPublishDate(long publishDate) {
		this.publishDate = publishDate;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "Article_NewsScrap [author=" + author + ", title=" + title + ", content=" + content + ", summary="
				+ summary + ", linkUrl=" + linkUrl + ", country=" + country + ", countryCode=" + countryCode
				+ ", articleNewsCategory=" + articleNewsCategory + ", publishDate=" + publishDate + "]";
	}
}

