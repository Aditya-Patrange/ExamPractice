package com.cdac.sudarshan.speech.service;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.ResourceUtils;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

@Service
public class SpeechServiceImpl implements ISpeechService {

	/* Synchronus rest client class to invoke backend API */
	private RestTemplate template;

	@Value("${local_Speech_Url}")
	private String speechUrl;

	@Value("${local_YouTube_FileStorage_Path}")
	private String youTubeStoragePath;

	public SpeechServiceImpl(RestTemplateBuilder builder) {
		template = builder.build();
	}

	/**
	 * This method return RestTemplate Instance to access all https APIs
	 * 
	 * @return
	 */
	private RestTemplate restTemplatesHttps() {
		final HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
		SSLContextBuilder builder = new SSLContextBuilder();

		SSLConnectionSocketFactory sslsf;
		try {
			builder.loadTrustMaterial(ResourceUtils.getFile("classpath:certificate.p12"), null,
					new TrustSelfSignedStrategy());

			sslsf = new SSLConnectionSocketFactory(builder.build(), NoopHostnameVerifier.INSTANCE);

			CloseableHttpClient httpclient = HttpClients.custom().setSSLSocketFactory(sslsf).build();
			requestFactory.setHttpClient(httpclient);

		} catch (KeyManagementException | NoSuchAlgorithmException | KeyStoreException | CertificateException
				| IOException e) {
			e.printStackTrace();
		}

		return new RestTemplate(requestFactory);
	}
	
	/**
	 * replace all special chars + spaces except "." with "_" from fileName & Rename the file.
	 * 
	 * @param file
	 * @return
	 * 
	 */
	private FileSystemResource renameFileName(FileSystemResource file) {
		File oldfile = file.getFile();
		File newfile = null;
		String fileName =null;
		int k=0;
		
		Long dotCount = file.getFilename().chars().filter(ch -> ch == '.').count();
		
		if(dotCount <= 1) {
			newfile = (new FileSystemResource(
					youTubeStoragePath + (file.getFilename().replaceAll("[^a-zA-Z0-9.]", "_")))).getFile();
		}else {
			//To get List of indexes:
			List<Integer> indexes = IntStream.range(0, file.getFilename().length())
			        .filter(i -> file.getFilename().charAt(i) == '.').boxed()
			        .collect(Collectors.toList());
	
			fileName = file.getFilename().replaceAll("[^a-zA-Z0-9]", "_");
			fileName = fileName.substring(0, indexes.get(indexes.size()-1)) + '.'+ fileName.substring(indexes.get(indexes.size()-1) + 1);
			newfile = (new FileSystemResource(youTubeStoragePath + fileName)).getFile();
		}
	
		while(newfile.exists()) {
			newfile = (new FileSystemResource(youTubeStoragePath +k+ fileName)).getFile();
			k++;
		}
		
		if (oldfile.renameTo(newfile)) {

			return new FileSystemResource(newfile);
		} else {

			return new FileSystemResource(oldfile);
		}
	}


	/**
	 * Access Https transcribe api to convert video in English lang.
	 */
	@Override
	public ResponseEntity<?> getTranscribeEnglish(MultipartFile file) {
		HttpHeaders headers = new HttpHeaders();
		MultiValueMap<String, Object> parameters = new LinkedMultiValueMap<String, Object>();
//		parameters.add("file", new FileSystemResource(youTubeStoragePath + file.getOriginalFilename()));
//		parameters.add("file",renameFileName(new FileSystemResource(youTubeStoragePath + file.getOriginalFilename())));
		FileSystemResource renameFileName = renameFileName(
				new FileSystemResource(youTubeStoragePath + file.getOriginalFilename()));
		parameters.add("file", renameFileName);

		headers.set("Content-Type", "multipart/form-data");
		headers.set("Accept", "text/plain");
		HttpEntity<Object> entity = new HttpEntity<>(parameters, headers);

		RestTemplate restTemplate = restTemplatesHttps();
		return restTemplate.exchange(speechUrl + "transcribe/English", HttpMethod.POST, entity, Object.class);

	}


	/**
	 * Access Https transcribe api to convert video in Hindi lang.
	 */
	@Override
	public ResponseEntity<?> getTranscribeHindi(MultipartFile file) {
		HttpHeaders headers = new HttpHeaders();
		MultiValueMap<String, Object> parameters = new LinkedMultiValueMap<String, Object>();
//		parameters.add("file", new FileSystemResource(youTubeStoragePath + file.getOriginalFilename()));
		parameters.add("file", renameFileName(new FileSystemResource(youTubeStoragePath + file.getOriginalFilename())));
		headers.set("Content-Type", "multipart/form-data");
		headers.set("Accept", "text/plain");
		HttpEntity<Object> entity = new HttpEntity<>(parameters, headers);

		RestTemplate restTemplate = restTemplatesHttps();
		return restTemplate.exchange(speechUrl + "transcribe/Hindi", HttpMethod.POST, entity, Object.class);

	}

	/**
	 * Access Https KWS api to convert video in English text with timelap
	 */
	@Override
	public ResponseEntity<?> getKWSAdvanceSearchEnglish(MultipartFile file) {
		HttpHeaders headers = new HttpHeaders();
		MultiValueMap<String, Object> parameters = new LinkedMultiValueMap<String, Object>();
//		parameters.add("file", new FileSystemResource(youTubeStoragePath + file.getOriginalFilename()));
		parameters.add("file", renameFileName(new FileSystemResource(youTubeStoragePath + file.getOriginalFilename())));
		headers.set("Content-Type", "multipart/form-data");
		headers.set("Accept", "text/plain");
		HttpEntity<Object> entity = new HttpEntity<>(parameters, headers);

		RestTemplate restTemplate = restTemplatesHttps();
		return restTemplate.exchange(speechUrl + "advancesearchnew/English", HttpMethod.POST, entity, Object.class);
	}

	/**
	 * Access Https KWS api to convert video in Hindi text with timelap
	 */
	@Override
	public ResponseEntity<?> getKWSAdvanceSearchHindi(MultipartFile file) {
		HttpHeaders headers = new HttpHeaders();
		MultiValueMap<String, Object> parameters = new LinkedMultiValueMap<String, Object>();
//		parameters.add("file", new FileSystemResource(youTubeStoragePath + file.getOriginalFilename()));
		parameters.add("file", renameFileName(new FileSystemResource(youTubeStoragePath + file.getOriginalFilename())));
		headers.set("Content-Type", "multipart/form-data");
		headers.set("Accept", "text/plain");
		HttpEntity<Object> entity = new HttpEntity<>(parameters, headers);

		RestTemplate restTemplate = restTemplatesHttps();
		return restTemplate.exchange(speechUrl + "advancesearchnew/Hindi", HttpMethod.POST, entity, Object.class);
	}

	/**
	 * Access Https LID api to know video language
	 */
	@Override
	public ResponseEntity<?> getLIDLanguage(MultipartFile file) {
		HttpHeaders headers = new HttpHeaders();
		MultiValueMap<String, Object> parameters = new LinkedMultiValueMap<String, Object>();
//		parameters.add("file", new FileSystemResource(youTubeStoragePath + file.getOriginalFilename()));
		parameters.add("file", renameFileName(new FileSystemResource(youTubeStoragePath + file.getOriginalFilename())));
		headers.set("Content-Type", "multipart/form-data");
		headers.set("Accept", "text/plain");
		HttpEntity<Object> entity = new HttpEntity<>(parameters, headers);

		RestTemplate restTemplate = restTemplatesHttps();
		return restTemplate.exchange(speechUrl + "langid", HttpMethod.POST, entity, Object.class);
	}

	/**
	 * Testing API to check all https api is accessible or not
	 */
	@Override
	public ResponseEntity<?> getTranscribeTest(MultipartFile file) throws NoSuchAlgorithmException, KeyStoreException,
			CertificateException, FileNotFoundException, IOException, KeyManagementException {

		HttpHeaders headers = new HttpHeaders();

		MultiValueMap<String, Object> parameters = new LinkedMultiValueMap<String, Object>();
//		parameters.add("file", new FileSystemResource(youTubeStoragePath + file.getOriginalFilename()));
		parameters.add("file", renameFileName(new FileSystemResource(youTubeStoragePath + file.getOriginalFilename())));

		headers.set("Content-Type", "multipart/form-data");
		headers.set("Accept", "text/plain");

		final HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
		SSLContextBuilder builder = new SSLContextBuilder();

		builder.loadTrustMaterial(ResourceUtils.getFile("classpath:certificate.p12"), null,
				new TrustSelfSignedStrategy());

		SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(builder.build(),
				NoopHostnameVerifier.INSTANCE);
		CloseableHttpClient httpclient = HttpClients.custom().setSSLSocketFactory(sslsf).build();
		requestFactory.setHttpClient(httpclient);

		RestTemplate restTemplate = new RestTemplate(requestFactory);

		HttpEntity<Object> entity = new HttpEntity<>(parameters, headers);

		return restTemplate.exchange(speechUrl + "transcribe/Hindi", HttpMethod.POST, entity, Object.class);

	}

}
