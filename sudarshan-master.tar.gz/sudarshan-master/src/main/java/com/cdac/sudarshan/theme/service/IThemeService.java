package com.cdac.sudarshan.theme.service;

import com.cdac.sudarshan.theme.dto.ThemeCountDto;
import com.cdac.sudarshan.theme.dto.ThemeDto;
import com.cdac.sudarshan.theme.model.Theme;

import java.util.List;
import java.util.Map;

public interface IThemeService {

    //save root theme
    ThemeDto saveTheme(ThemeDto themeDto);

    //get all themes
    List<ThemeDto> getAllThemes();

    List<ThemeDto> getThemesOfLoggedInUser();

    List<ThemeDto> getRootThemesOfUser(Long userId);


    public List<ThemeCountDto> getThemeKeywordCount();



}
