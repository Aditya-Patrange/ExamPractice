package com.cdac.sudarshan.watchlist.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import javax.validation.Valid;

import org.springframework.http.ResponseEntity;

import com.cdac.sudarshan.authentication.model.User;
import com.cdac.sudarshan.watchlist.dto.ResponseDto;
import com.cdac.sudarshan.watchlist.dto.WatchlistDashboardDto;
import com.cdac.sudarshan.watchlist.dto.WatchlistDto;
import com.cdac.sudarshan.watchlist.dto.Watchlist_CollectionDto;
import com.cdac.sudarshan.watchlist.model.Frequency;
import com.cdac.sudarshan.watchlist.model.Source;
import com.cdac.sudarshan.watchlist.model.Watchlist;

public interface IWatchlistService {

	public Watchlist saveWatchlist(WatchlistDto watchlistDto);

	public List<Watchlist> getAllWatchlist();

	public List<Source> getSources();

	public ResponseDto deleteWatchlistById(Integer id);

	public List<Frequency> getFrequencyList();

	public List<WatchlistDashboardDto> updateWatchlistStatus() throws IOException;

	public Watchlist updateWatchlist(Integer id, @Valid WatchlistDto watchlistDto);

	public List<Watchlist> deActivateWatchlistByDate();

	public ResponseEntity<?> checkCollectionId(HashMap<String, Object> data);
	
//	List<Watchlist> getWatchlistsByUser(User user);
	
	List<Watchlist> getWatchlistsByUserId(Long id);

	public ResponseEntity<?> addWatchlist_Collection(Watchlist_CollectionDto wCDto);
	
}
 