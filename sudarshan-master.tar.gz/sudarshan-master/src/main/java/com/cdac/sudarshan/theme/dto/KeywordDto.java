package com.cdac.sudarshan.theme.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class KeywordDto {

    private Long id;
    private String data;
    @JsonIgnore
    private SubThemeDto subTheme;


}
