package com.cdac.sudarshan.watchlist.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.cdac.sudarshan.discover.common.Helper;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Transactional
public class ProxyService implements IProxyService {

    @Autowired
    private JdbcTemplate jdbcTemplateTwo;

    @Override
    public HashMap<String, Object> selectProxy(HashMap<String, Object> input) {
        HashMap<String, Object> mp = new HashMap<String, Object>();
        try {
            String subQuery = " and tbl_proxies.action!='delete' ";
            if (Helper.keyContainsHashMap(input, "pageNumber") == null
                    || (Helper.keyContainsHashMap(input, "pageNumber") != null
                    && Helper.emptyNullCheckString(input.get("pageNumber").toString()) == false)) {
                mp.put("type", "error");
                mp.put("msg", "Page Number is blank");
                return mp;
            } else if (Helper.keyContainsHashMap(input, "limit") == null
                    || (Helper.keyContainsHashMap(input, "limit") != null
                    && Helper.emptyNullCheckString(input.get("limit").toString()) == false)) {
                mp.put("type", "limit");
                mp.put("msg", "limit is blank");
                return mp;
            }

            String limit = Helper.calculatePagination(Integer.parseInt(input.get("pageNumber").toString()),
                    Integer.parseInt(input.get("limit").toString()));
            if ((Helper.keyContainsHashMap(input, "ip") != null
                    && Helper.emptyNullCheckString(input.get("ip").toString()) == true)) {
                subQuery += " and tbl_proxies.ip like '%" + input.get("ip").toString() + "%'";
            }
            if ((Helper.keyContainsHashMap(input, "country") != null
                    && Helper.emptyNullCheckString(input.get("country").toString()) == true)) {
                subQuery += " and tbl_proxies.country ='" + input.get("country").toString() + "'";
            }
            if ((Helper.keyContainsHashMap(input, "status") != null
                    && Helper.emptyNullCheckString(input.get("status").toString()) == true)) {
                subQuery += " and tbl_proxies.status ='" + input.get("status").toString() + "'";
            }

            String sql2 = "Select count(*) as count  from tbl_proxies"
                    + " inner join countrycodes on countrycodes.code=tbl_proxies.country " + " where 1=1 " + subQuery;
            int count = jdbcTemplateTwo.queryForObject(sql2, Integer.class);
            if (count > 0) {
                String sql = "select tbl_proxies.record_id,tbl_proxies.ip,tbl_proxies.port,tbl_proxies.username,tbl_proxies.password,tbl_proxies.status,"
                        + " countrycodes.country " + " from tbl_proxies inner join countrycodes "
                        + " on countrycodes.code=tbl_proxies.country where action!='delete' ORDER BY row_number desc" ;

                List<Map<String, Object>> lst = jdbcTemplateTwo.queryForList(sql);
                if (lst.size() > 0) {
                    lst.get(0).put("totalCount", count);
                }
                mp.put("type", "success");
                mp.put("data", lst);
            } else {
                mp.put("type", "success");
                mp.put("data", new ArrayList<>());
            }
        } catch (Exception e) {
            mp = Helper.getErrorMap(e);
            e.printStackTrace();
        }
        return mp;

    }
}
