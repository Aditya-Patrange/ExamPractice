package com.cdac.sudarshan.folderManagement.dto;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class FolderDataRequestDto {

    private String id;
    //@NotBlank(message = "Article id can not be empty.")
    private String articleId;
    //  @NotBlank(message = "Profile id can not be empty.")
    private String profileId;
    //@NotNull(message = "Folder id can not be empty")
    private String folderId;
    //  @NotBlank(message = "Source can not be empty.")
    private String source;
    //  @NotBlank(message = "Tag can not be empty.")
    private Long userId;
    private String tag;
    private LocalDateTime creationDate;
    private LocalDateTime lastUpdatedDate;
    private Integer status;
    private int size;
    private String folderDataType;
    private List<String> sourceFilter = new ArrayList<>();
    private List<String> folderDataTypeFilter = new ArrayList<>();


}
