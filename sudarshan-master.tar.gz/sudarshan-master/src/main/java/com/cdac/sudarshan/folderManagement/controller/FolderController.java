package com.cdac.sudarshan.folderManagement.controller;

import com.cdac.sudarshan.folderManagement.dto.FolderRequestDto;
import com.cdac.sudarshan.folderManagement.service.IFolderService;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Map;

@CrossOrigin("*")
@RestController
@RequestMapping("/folder")
public class FolderController {

    @Autowired
    private IFolderService folderService;

    @GetMapping("/getStatusList")
    public ResponseEntity<?> getStatusReference() {
        return new ResponseEntity<>(folderService.getStatusReference(), HttpStatus.OK);
    }

    @PostMapping("/saveFolder")
    public ResponseEntity<?> saveFolder(@Valid @RequestBody FolderRequestDto data) throws JsonProcessingException {
        return new ResponseEntity<>(folderService.saveFolder(data), HttpStatus.OK);

    }

    @PostMapping("/getFolder")
    public ResponseEntity<?> getFolder(@Valid @RequestBody FolderRequestDto data) throws JsonProcessingException {
        return new ResponseEntity<>(folderService.getFolder(data), HttpStatus.OK);

    }

    @PostMapping("/moveFolder")
    public ResponseEntity<?> moveFolder( @RequestBody List<@Valid FolderRequestDto> data) {
        return new ResponseEntity<>(folderService.moveFolder(data), HttpStatus.OK);

    }

    @PostMapping("/renameFolder")
    public ResponseEntity<?> renameFolder(@Valid @RequestBody List<FolderRequestDto> data) {
        return new ResponseEntity<>(folderService.renameFolder(data), HttpStatus.OK);

    }

    @PostMapping("/restoreFolder")
    public ResponseEntity<?> restoreFolder(@Valid @RequestBody FolderRequestDto data) {
        return new ResponseEntity<>(folderService.restoreFolder(data), HttpStatus.OK);

    }

    @PostMapping("/softRemoveFolder")
    public ResponseEntity<?> softRemoveFolder(@Valid @RequestBody FolderRequestDto data) {
        return new ResponseEntity<>(folderService.softRemoveFolder(data), HttpStatus.OK);

    }

    @PostMapping("/copyFolder")
    public ResponseEntity<?> copyFolder(@RequestBody List<@Valid FolderRequestDto> data) throws JsonProcessingException {
        return new ResponseEntity<>(folderService.copyFolder(data), HttpStatus.OK);
    }

    @PostMapping("/getFolderList")
    public ResponseEntity<?> getFolderList(@RequestBody FolderRequestDto data) {
        return new ResponseEntity<>(folderService.getFolderList(data), HttpStatus.OK);

    }

    @PostMapping("/removeFolder")
    public ResponseEntity<?> permanentRemoveFolder(@Valid @RequestBody FolderRequestDto data) {
        return new ResponseEntity<>(folderService.permanentRemoveFolder(data), HttpStatus.OK);

    }

    @PostMapping("/getItemCount")
    public ResponseEntity<?> getItemCount(@RequestBody List<@Valid FolderRequestDto> data) {
        return new ResponseEntity<>(folderService.getItemCount(data), HttpStatus.OK);
    }
}
