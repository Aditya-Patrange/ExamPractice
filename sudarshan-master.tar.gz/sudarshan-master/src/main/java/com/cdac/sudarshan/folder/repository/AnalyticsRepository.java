package com.cdac.sudarshan.folder.repository;

import com.cdac.sudarshan.folder.model.Analytics;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface AnalyticsRepository extends JpaRepository<Analytics,Long> {

    @Query(value = "select article_id from text_analytics",nativeQuery = true)
    public List<String> getAllArticleId();

//    @Query(value = "select a from text_analytics a where a.article_id in :article_ids",nativeQuery = true)
//    List<Analytics> getAnalyticsOfArticleId(@Param("article_ids") String article_ids);

    List<Analytics> findByArticleIdIn(List<String> articleId);

//    @Query(value = "select * from text_analytics",nativeQuery = true)
//    public List<Analytics> getAllArticles();

}
