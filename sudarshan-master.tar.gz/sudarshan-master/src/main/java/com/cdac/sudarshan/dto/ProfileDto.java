package com.cdac.sudarshan.dto;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class ProfileDto {
	
	private String id;
	private String keywordId;
	private String profileName;
	private String profileUserName;
	private String profileId;
	private String profileImageUrl;
	private String profileType;
	private String profileUrl;
	private String source;
	private LocalDate startCrawlDate;
	private boolean startCrawlingStatus;
	private LocalDate lastCrawlDate;
	private boolean lastCrawlingStatus;
	private LocalDate lastValidationDate;
	private String collectionId;
	private String profileCountry;
	private String profileCategory;
	private int threatScore;
	private String isValid;
	private boolean verifiedUserFlag;
	private String message;
	private LocalDate lastMigrationDate;
	private String avtarUserName;
	private Long deltaInterval;
	private String lastMigratedRecordInsertedDate;
	private boolean crawlingStatus;
	private String LastRecordDate;
	private String profileImageName;
	private int profileImageDownloadStatus;
	
	

}
