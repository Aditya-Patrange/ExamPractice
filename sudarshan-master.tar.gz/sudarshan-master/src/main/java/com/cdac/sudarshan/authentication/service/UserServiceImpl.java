package com.cdac.sudarshan.authentication.service;

import java.util.ArrayList;
import java.util.Optional;

import com.cdac.sudarshan.exception.ResourceNotFoundException;
import com.cdac.sudarshan.exception.UserNameNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.cdac.sudarshan.authentication.model.User;
import com.cdac.sudarshan.authentication.repository.UserRepository;
import com.cdac.sudarshan.exception.UserNameFoundException;
import com.cdac.sudarshan.exception.UserNameNotFoundException;

@Service
public class UserServiceImpl implements IUserService,UserDetailsService {

	@Autowired
	private UserRepository userRepository;

	@Override
	public User saveUser(User user) {
		if (fetchUserByUserName(user.getUsername()).isPresent()) {
			throw new UserNameFoundException(user.getUsername() + " already exist!!!");
		}
		return userRepository.save(user);
	}

	@Override
	public User getUserByUserName(String username) {
		return userRepository.findByUsername(username).orElseThrow(() -> new UserNameNotFoundException("User does not exists for "+username+" ...!!!"));
	}

	public Optional<User> fetchUserByUserName(String username) {
		return userRepository.findByUsername(username);
	}

	@Override
	public boolean getAdditionalSecurity(Long userId) {
		User user = userRepository.findById(userId).orElseThrow(() -> new UserNameNotFoundException("User does not exists for "+userId+" ...!!!"));
		return user.getAdditionalSecurity();
	}

	@Override
	public void setAdditionalSecurity(Long userId) {
		User user = userRepository.findById(userId).orElseThrow(() -> new UserNameNotFoundException("User does not exists for "+userId+" ...!!!"));
		user.setAdditionalSecurity(true);
	}

	@Override
	public void updateAdditionalSecurity(Long userId) {
		User user = userRepository.findById(userId).orElseThrow(() -> new UserNameNotFoundException("User does not exists for "+userId+" ...!!!"));
		user.setAdditionalSecurity(false);
	}

	@Override
	public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {

		// TODO Auto-generated method stub
		User user = userRepository.findByUsername(userName).get();

		return new org.springframework.security.core.userdetails.User(userName, user.getPasswordHash(),
				new ArrayList<GrantedAuthority>());
	}

}
