package com.cdac.sudarshan.profile.controller;

import com.cdac.sudarshan.profile.service.IProfileService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;

@RestController
@CrossOrigin("*")
@RequestMapping("profile")
public class ProfileController {

    @Autowired
    private IProfileService profileService;

    @PostMapping("/searchByName")
    public ResponseEntity<?> searchByName(@RequestBody HashMap<String, Object> data) {
        return new ResponseEntity<>(profileService.searchByName(data), HttpStatus.OK);
    }

    @PostMapping("/selectAllAvatarByParameter")
    public ResponseEntity<?> selectAllAvatarByParameter(@RequestBody HashMap<String, Object> data) {
        return new ResponseEntity<>(profileService.selectAllAvatarByParameter(data), HttpStatus.OK);
    }



}
