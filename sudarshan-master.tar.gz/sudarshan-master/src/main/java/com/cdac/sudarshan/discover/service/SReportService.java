package com.cdac.sudarshan.discover.service;

import java.util.HashMap;

import org.springframework.http.ResponseEntity;

public interface SReportService {

	public ResponseEntity<?> getHashtagWordCloud(HashMap<String, Object> data);
	
	public ResponseEntity<?> getMentionWordCloud(HashMap<String, Object> data);
	
	public ResponseEntity<?> getPersonWordCloud(HashMap<String, Object> data);
	
	public ResponseEntity<?> getPlaceWordCloud(HashMap<String, Object> data);
	
	
	
}
