package com.cdac.sudarshan.discover.model;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

import javax.persistence.Entity;
@Entity
@Setter
@Getter
@RequiredArgsConstructor
public class Trends extends BaseEntity{
    private String trendsData;
}


