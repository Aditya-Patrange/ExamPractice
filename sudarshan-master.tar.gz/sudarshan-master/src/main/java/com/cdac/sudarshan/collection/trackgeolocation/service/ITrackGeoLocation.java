package com.cdac.sudarshan.collection.trackgeolocation.service;

import java.util.HashMap;

import org.springframework.http.ResponseEntity;

public interface ITrackGeoLocation {
	public ResponseEntity<?> trackGeoLocation(HashMap<String, Object> data);
}
