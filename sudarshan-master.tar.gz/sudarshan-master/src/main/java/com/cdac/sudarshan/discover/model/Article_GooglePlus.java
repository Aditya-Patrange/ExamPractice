package com.cdac.sudarshan.discover.model;

import java.io.Serializable;

public class Article_GooglePlus implements Serializable 
{
	private static final long serialVersionUID = 1L;
	private int gplusPostShareCount;
	private int gplusPostPlusOneCount;
	private int gplusPostCommentCount;
	private String gpAuthorUrl;

	public String getGpAuthorUrl() {
		return gpAuthorUrl;
	}

	public void setGpAuthorUrl(String gpAuthorUrl) {
		this.gpAuthorUrl = gpAuthorUrl;
	}

	public int getGplusPostShareCount() {
		return gplusPostShareCount;
	}

	public void setGplusPostShareCount(int gplusPostShareCount) {
		this.gplusPostShareCount = gplusPostShareCount;
	}

	public int getGplusPostPlusOneCount() {
		return gplusPostPlusOneCount;
	}

	public void setGplusPostPlusOneCount(int gplusPostPlusOneCount) {
		this.gplusPostPlusOneCount = gplusPostPlusOneCount;
	}

	public int getGplusPostCommentCount() {
		return gplusPostCommentCount;
	}

	public void setGplusPostCommentCount(int gplusPostCommentCount) {
		this.gplusPostCommentCount = gplusPostCommentCount;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "Article_GooglePlus [gplusPostShareCount=" + gplusPostShareCount + ", gplusPostPlusOneCount="
				+ gplusPostPlusOneCount + ", gplusPostCommentCount=" + gplusPostCommentCount + ", gpAuthorUrl="
				+ gpAuthorUrl + "]";
	}
	
}
