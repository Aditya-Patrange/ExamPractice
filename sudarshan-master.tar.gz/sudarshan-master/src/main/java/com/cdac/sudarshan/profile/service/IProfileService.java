package com.cdac.sudarshan.profile.service;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.HashMap;

@Service
public interface IProfileService{

    public ResponseEntity<?> searchByName(HashMap<String, Object> data) ;

    public ResponseEntity<?> selectAllAvatarByParameter(HashMap<String, Object> data);
}
