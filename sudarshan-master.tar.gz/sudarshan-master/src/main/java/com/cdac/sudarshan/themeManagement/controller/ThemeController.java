package com.cdac.sudarshan.themeManagement.controller;

import com.cdac.sudarshan.themeManagement.dto.ThemeRequestDto;
import com.cdac.sudarshan.themeManagement.service.IThemeService;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@CrossOrigin("*")
@RestController("newThemeController")
@RequestMapping("/theme")
public class ThemeController {

    @Autowired
    @Qualifier("newThemeServiceImpl")
    private IThemeService themeService;

    @PostMapping("/saveTheme")
    public ResponseEntity<?> saveTheme(@Valid @RequestBody ThemeRequestDto data) throws JsonProcessingException {
        return new ResponseEntity<>(themeService.saveTheme(data), HttpStatus.OK);
    }

    @PostMapping("/getTheme")
    public ResponseEntity<?> getTheme(@Valid @RequestBody ThemeRequestDto data) {
        return new ResponseEntity<>(themeService.getTheme(data), HttpStatus.OK);

    }

    @GetMapping("/getThemeWithTag")
    public ResponseEntity<?> getThemeWithTag() {
        return new ResponseEntity<>(themeService.getThemeWithTag(), HttpStatus.OK);

    }

    @GetMapping("/getThemeDetails")
    public ResponseEntity<?> getThemeDetails() {
        return new ResponseEntity<>(themeService.getThemeDetails(), HttpStatus.OK);

    }
    @PostMapping("/getThemeCount")
	public ResponseEntity<?> getThemeCount(@Valid @RequestBody ThemeRequestDto data) {
		return new ResponseEntity<>(themeService.getThemeCount(data), HttpStatus.OK);

	}

}
