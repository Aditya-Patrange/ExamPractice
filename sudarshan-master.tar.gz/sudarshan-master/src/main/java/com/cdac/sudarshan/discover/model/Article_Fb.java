package com.cdac.sudarshan.discover.model;

import java.io.Serializable;
import java.util.ArrayList;

public class Article_Fb implements Serializable
{
	private static final long serialVersionUID = 1L;
	private String fbPostSource;
	private String fbPostStatusType;
	private String fbPostPageName;
	private String fbPostPageId;
	private String fbPostPicture;
	private String fbPostCaption;
	private String fbPostLinkName;
	private String fbPostDescription;
	private String fbPostShareUserId;
	private String fbPostShareUserName;
	private String fbPostUserFullName;
	private String fbPostUserType;     //page,user,group,event
	private int fbPostShareCount;
	private int fbPostLikeCount;
	private int fbPostCommentCount;
	private int fbPostViewerCount;
	private Article_Fb_Page fbPage;
	private ArrayList<Article_Fb_User> fbPostLikeUser;
	
	public String getFbPostDescription() {
		return fbPostDescription;
	}
	public void setFbPostDescription(String fbPostDescription) {
		this.fbPostDescription = fbPostDescription;
	}
	public Article_Fb_Page getFbPage() {
		return fbPage;
	}
	public void setFbPage(Article_Fb_Page fbPage) {
		this.fbPage = fbPage;
	}
	public ArrayList<Article_Fb_User> getFbPostLikeUser() {
		return fbPostLikeUser;
	}
	public void setFbPostLikeUser(ArrayList<Article_Fb_User> fbPostLikeUser) {
		this.fbPostLikeUser = fbPostLikeUser;
	}
	public String getFbPostLinkName() {
		return fbPostLinkName;
	}
	public void setFbPostLinkName(String fbPostLinkName) {
		this.fbPostLinkName = fbPostLinkName;
	}
	public String getFbPostCaption() {
		return fbPostCaption;
	}
	public void setFbPostCaption(String fbPostCaption) {
		this.fbPostCaption = fbPostCaption;
	}
	public String getFbPostSource() {
		return fbPostSource;
	}
	public void setFbPostSource(String fbPostSource) {
		this.fbPostSource = fbPostSource;
	}
	public String getFbPostPageName() {
		return fbPostPageName;
	}
	public void setFbPostPageName(String fbPostPageName) {
		this.fbPostPageName = fbPostPageName;
	}
	public String getFbPostPageId() {
		return fbPostPageId;
	}
	public void setFbPostPageId(String fbPostPageId) {
		this.fbPostPageId = fbPostPageId;
	}
	public String getFbPostPicture() {
		return fbPostPicture;
	}
	public void setFbPostPicture(String fbPostPicture) {
		this.fbPostPicture = fbPostPicture;
	}
	public int getFbPostShareCount() {
		return fbPostShareCount;
	}
	public void setFbPostShareCount(int fbPostShareCount) {
		this.fbPostShareCount = fbPostShareCount;
	}
	public int getFbPostLikeCount() {
		return fbPostLikeCount;
	}
	public void setFbPostLikeCount(int fbPostLikeCount) {
		this.fbPostLikeCount = fbPostLikeCount;
	}
	public int getFbPostCommentCount() {
		return fbPostCommentCount;
	}
	public void setFbPostCommentCount(int fbPostCommentCount) {
		this.fbPostCommentCount = fbPostCommentCount;
	}
	public String getFbPostStatusType() {
		return fbPostStatusType;
	}
	public void setFbPostStatusType(String fbPostStatusType) {
		this.fbPostStatusType = fbPostStatusType;
	}
	public String getFbPostShareUserId() {
		return fbPostShareUserId;
	}
	public void setFbPostShareUserId(String fbPostShareUserId) {
		this.fbPostShareUserId = fbPostShareUserId;
	}
	public String getFbPostShareUserName() {
		return fbPostShareUserName;
	}
	public void setFbPostShareUserName(String fbPostShareUserName) {
		this.fbPostShareUserName = fbPostShareUserName;
	}
	public int getFbPostViewerCount() {
		return fbPostViewerCount;
	}
	public void setFbPostViewerCount(int fbPostViewerCount) {
		this.fbPostViewerCount = fbPostViewerCount;
	}
	public String getFbPostUserFullName() {
		return fbPostUserFullName;
	}
	public void setFbPostUserFullName(String fbPostUserFullName) {
		this.fbPostUserFullName = fbPostUserFullName;
	}
	public String getFbPostUserType() {
		return fbPostUserType;
	}
	public void setFbPostUserType(String fbPostUserType) {
		this.fbPostUserType = fbPostUserType;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "Article_Fb [fbPostSource=" + fbPostSource + ", fbPostStatusType=" + fbPostStatusType
				+ ", fbPostPageName=" + fbPostPageName + ", fbPostPageId=" + fbPostPageId + ", fbPostPicture="
				+ fbPostPicture + ", fbPostCaption=" + fbPostCaption + ", fbPostLinkName=" + fbPostLinkName
				+ ", fbPostDescription=" + fbPostDescription + ", fbPostShareUserId=" + fbPostShareUserId
				+ ", fbPostShareUserName=" + fbPostShareUserName + ", fbPostUserFullName=" + fbPostUserFullName
				+ ", fbPostShareCount=" + fbPostShareCount + ", fbPostLikeCount=" + fbPostLikeCount
				+ ", fbPostCommentCount=" + fbPostCommentCount + ", fbPostViewerCount=" + fbPostViewerCount
				+ ", fbPage=" + fbPage + ", fbPostLikeUser=" + fbPostLikeUser + ", fbPostUserType=" + fbPostUserType
				+ "]";
	}
	
}
