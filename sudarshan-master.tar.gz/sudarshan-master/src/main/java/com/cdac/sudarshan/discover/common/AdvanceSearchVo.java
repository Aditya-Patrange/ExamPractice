package com.cdac.sudarshan.discover.common;

public class AdvanceSearchVo {
	private String allTheseWords;
	private	String exactWord;
	private	String anyTheseWords;
	private	String noneTheseWords;
	public String getAllTheseWords() {
		return allTheseWords;
	}
	public void setAllTheseWords(String allTheseWords) {
		this.allTheseWords = allTheseWords;
	}
	public String getExactWord() {
		return exactWord;
	}
	public void setExactWord(String exactWord) {
		this.exactWord = exactWord;
	}
	public String getAnyTheseWords() {
		return anyTheseWords;
	}
	public void setAnyTheseWords(String anyTheseWords) {
		this.anyTheseWords = anyTheseWords;
	}
	public String getNoneTheseWords() {
		return noneTheseWords;
	}
	public void setNoneTheseWords(String noneTheseWords) {
		this.noneTheseWords = noneTheseWords;
	}
	@Override
	public String toString() {
		return "AdvanceSearchVo [allTheseWords=" + allTheseWords + ", exactWord=" + exactWord + ", anyTheseWords="
				+ anyTheseWords + ", noneTheseWords=" + noneTheseWords + "]";
	}
	
}
