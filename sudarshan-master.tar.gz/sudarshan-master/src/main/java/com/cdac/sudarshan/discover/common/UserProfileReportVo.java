package com.cdac.sudarshan.discover.common;

public class UserProfileReportVo {

}
