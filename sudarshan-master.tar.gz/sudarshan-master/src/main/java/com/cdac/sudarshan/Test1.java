package com.cdac.sudarshan;

public class Test1 {
	
	public static void main(String[] args) {
		
		String subFolderName = "/kedar123/kedar12/kedar 123";
		
		String replacedOutput = subFolderName.replace("[/.\\w+/\\w+(|\\s+)\\w+/]", "");
		//String result = replacedOutput.replace("/$", "");

	}

}
