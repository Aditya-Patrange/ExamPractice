package com.cdac.sudarshan.discover.model;

import java.io.Serializable;

public class Insta_User implements Serializable
{
	private static final long serialVersionUID = 1L;
	private String instaUserName;
	private String instaUserId;
	private String instaUserImg;

	public String getInstaUserName() {
		return instaUserName;
	}

	public void setInstaUserName(String instaUserName) {
		this.instaUserName = instaUserName;
	}

	public String getInstaUserId() {
		return instaUserId;
	}

	public void setInstaUserId(String instaUserId) {
		this.instaUserId = instaUserId;
	}

	public String getInstaUserImg() {
		return instaUserImg;
	}

	public void setInstaUserImg(String instaUserImg) {
		this.instaUserImg = instaUserImg;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "Insta_User [instaUserName=" + instaUserName + ", instaUserId=" + instaUserId + ", instaUserImg="
				+ instaUserImg + "]";
	}
	
}
