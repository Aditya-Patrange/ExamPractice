package com.cdac.sudarshan.discover.model;

import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;

public class CommonFbVo 
{
	private HashSet<String> uniqueSet;
	private LinkedHashMap<String, HashSet<String>> keyUniqueSet;
	private HashMap<String,String> imageMap;

	public HashSet<String> getUniqueSet() {
		return uniqueSet;
	}
	public void setUniqueSet(HashSet<String> uniqueSet) {
		this.uniqueSet = uniqueSet;
	}
	public LinkedHashMap<String, HashSet<String>> getKeyUniqueSet() {
		return keyUniqueSet;
	}
	public void setKeyUniqueSet(LinkedHashMap<String, HashSet<String>> keyUniqueSet) {
		this.keyUniqueSet = keyUniqueSet;
	}
	public void setImageMap(HashMap<String, String> imageMap) {
		this.imageMap = imageMap;
	}
	public HashMap<String, String> getImageMap() {
		return imageMap;
	}	
}

