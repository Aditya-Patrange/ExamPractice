package com.cdac.sudarshan.themeManagement.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class KeywordResponseDto {
    private String keywordId;
    private String keywordName;
    private String keywordKey;
    private String themeId;
}
