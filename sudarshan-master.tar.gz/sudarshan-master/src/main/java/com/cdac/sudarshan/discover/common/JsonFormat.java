package com.cdac.sudarshan.discover.common;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;

public class JsonFormat
{
	public static String getJsonFormat(String mapInclude)
	{		
		List<Map<String, Double>> resultList = new ArrayList<Map<String, Double>>();  							
		//String mapInclude = "[{\"lat\":\"31.14650398\",\"lon\":\"71.90670776\"},{\"lat\":\"13.94416033\",\"lon\":\"77.44381714\"},{\"lat\":\"16.31957616\",\"lon\":\"58.45944214\"}]";
		JSONArray jsonArray = new JSONArray(mapInclude);
		
		for(int i=0; i < jsonArray.length(); i++)
		{
			Map<String, Double> hashMap = new HashMap<String, Double>();
			JSONObject jsonObject = jsonArray.getJSONObject(i);
			hashMap.put("\"lat\"", Double.valueOf(jsonObject.getString("lat")));
			hashMap.put("\"lng\"", Double.valueOf(jsonObject.getString("lng")));			
			resultList.add(hashMap);
		}
		

		String result = resultList.toString();

		result=result.replaceAll("=", ":");

		return result;
	}
}