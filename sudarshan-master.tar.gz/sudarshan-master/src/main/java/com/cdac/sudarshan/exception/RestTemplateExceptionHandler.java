package com.cdac.sudarshan.exception;

import com.cdac.sudarshan.utils.ResponseDto;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import javax.servlet.http.HttpServletRequest;

@ControllerAdvice
public class RestTemplateExceptionHandler extends ResponseEntityExceptionHandler {
    @ExceptionHandler(value = ResourceFoundException.class)
    ResponseEntity<?> handleMyRestTemplateException(ResourceFoundException ex, HttpServletRequest request) {
      //  LOGGER.error("An error happened while calling {} Downstream API: {}", ex.getApi(), ex.toString());
        ResponseDto responseDto = new ResponseDto();
        responseDto.setMessage(ex.getMessage());
        responseDto.setSuccess(false);
        responseDto.setStatusCode(HttpStatus.CONFLICT.value());
        return new ResponseEntity<>(responseDto, HttpStatus.CONFLICT);
    }
}
