package com.cdac.sudarshan.folder.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "urls_paths")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class UrlsPath {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	private String url;

	private String resourcePath;

	@ManyToOne
	@JoinColumn(name = "sub_folder_id")
	@JsonIgnore
	private SubFolderPaths subFolderPaths;
	
	private String source;
	private String tag;
	private String profileId;

	@CreationTimestamp
	private  LocalDateTime creationDate;
	
	@UpdateTimestamp
	private LocalDateTime lastUpdatedDate;

	
//	@ManyToOne
//	@JoinColumn(name = "root_folder_id")
//	@JsonIgnore
//	private RootFolder rootFolder;
	@Column(name = "root_folder_id")
	private Long rootFolderId;

	private boolean status;

}
