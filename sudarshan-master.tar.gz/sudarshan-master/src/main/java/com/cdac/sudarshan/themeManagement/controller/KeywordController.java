package com.cdac.sudarshan.themeManagement.controller;

import com.cdac.sudarshan.themeManagement.dto.KeywordRequestDto;
import com.cdac.sudarshan.themeManagement.service.IKeywordService;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@CrossOrigin("*")
@RestController("newKeywordController")
@RequestMapping("/keyword")
public class KeywordController {

    @Autowired
    @Qualifier("newKeywordServiceImpl")
    private IKeywordService keywordService;

    @PostMapping("/saveKeyword")
    public ResponseEntity<?> saveKeyword(@Valid @RequestBody KeywordRequestDto data) throws JsonProcessingException {
        return new ResponseEntity<>(keywordService.saveKeyword(data), HttpStatus.OK);

    }

    @PostMapping("/getKeyword")
    public ResponseEntity<?> getKeyword(@Valid @RequestBody KeywordRequestDto data) {
        return new ResponseEntity<>(keywordService.getKeyword(data), HttpStatus.OK);

    }
}
