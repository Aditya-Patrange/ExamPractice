package com.cdac.sudarshan.discover.model;

import java.io.Serializable;
import java.util.ArrayList;

//import com.innefu.innsight.modal.Articel_Ner;
//import com.innefu.innsight.modal.Article_NerLocation;

public class ReportExportVo implements Serializable
{
	private static final long serialVersionUID = 1L;
	private String articleSource;
	private String articleTitle;
	private String articleSubTitle;
	private String articleBigContent;
	private String articleLanguage;
	private String link;
	private String userName;
	private String articleAuthor;
	private String articleUserLocation;
	private int articleSentiment=9;
	private String articleInsertedDate; 
	private String articlePublishDate;
	
	private ArrayList<String> articleMobile; 
	private ArrayList<String> articleEmail;
	private ArrayList<String> articleIpAddress;
	private ArrayList<Articel_Ner> articlePersonNer;
	private ArrayList<Article_NerLocation> articleLocationNer;
	private ArrayList<Articel_Ner> articleOrganizationNer;
	
	
	public String getArticleSource() {
		return articleSource;
	}
	public void setArticleSource(String articleSource) {
		this.articleSource = articleSource;
	}
	public String getArticleTitle() {
		return articleTitle;
	}
	public void setArticleTitle(String articleTitle) {
		this.articleTitle = articleTitle;
	}
	public String getArticleSubTitle() {
		return articleSubTitle;
	}
	public void setArticleSubTitle(String articleSubTitle) {
		this.articleSubTitle = articleSubTitle;
	}
	public String getArticleBigContent() {
		return articleBigContent;
	}
	public void setArticleBigContent(String articleBigContent) {
		this.articleBigContent = articleBigContent;
	}
	public String getArticleLanguage() {
		return articleLanguage;
	}
	public void setArticleLanguage(String articleLanguage) {
		this.articleLanguage = articleLanguage;
	}
	public String getLink() {
		return link;
	}
	public void setLink(String link) {
		this.link = link;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getArticleAuthor() {
		return articleAuthor;
	}
	public void setArticleAuthor(String articleAuthor) {
		this.articleAuthor = articleAuthor;
	}
	public String getArticleUserLocation() {
		return articleUserLocation;
	}
	public void setArticleUserLocation(String articleUserLocation) {
		this.articleUserLocation = articleUserLocation;
	}
	public ArrayList<String> getArticleIpAddress() {
		return articleIpAddress;
	}
	public void setArticleIpAddress(ArrayList<String> articleIpAddress) {
		this.articleIpAddress = articleIpAddress;
	}
	public int getArticleSentiment() {
		return articleSentiment;
	}
	public void setArticleSentiment(int articleSentiment) {
		this.articleSentiment = articleSentiment;
	}
	public String getArticleInsertedDate() {
		return articleInsertedDate;
	}
	public void setArticleInsertedDate(String articleInsertedDate) {
		this.articleInsertedDate = articleInsertedDate;
	}
	public String getArticlePublishDate() {
		return articlePublishDate;
	}
	public void setArticlePublishDate(String articlePublishDate) {
		this.articlePublishDate = articlePublishDate;
	}
	public ArrayList<String> getArticleMobile() {
		return articleMobile;
	}
	public void setArticleMobile(ArrayList<String> articleMobile) {
		this.articleMobile = articleMobile;
	}
	public ArrayList<String> getArticleEmail() {
		return articleEmail;
	}
	public void setArticleEmail(ArrayList<String> articleEmail) {
		this.articleEmail = articleEmail;
	}
	public ArrayList<Articel_Ner> getArticlePersonNer() {
		return articlePersonNer;
	}
	public void setArticlePersonNer(ArrayList<Articel_Ner> articlePersonNer) {
		this.articlePersonNer = articlePersonNer;
	}
	public ArrayList<Article_NerLocation> getArticleLocationNer() {
		return articleLocationNer;
	}
	public void setArticleLocationNer(ArrayList<Article_NerLocation> articleLocationNer) {
		this.articleLocationNer = articleLocationNer;
	}
	public ArrayList<Articel_Ner> getArticleOrganizationNer() {
		return articleOrganizationNer;
	}
	public void setArticleOrganizationNer(ArrayList<Articel_Ner> articleOrganizationNer) {
		this.articleOrganizationNer = articleOrganizationNer;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "ReportExport [articleSource=" + articleSource + ", articleTitle=" + articleTitle + ", articleSubTitle="
				+ articleSubTitle + ", articleBigContent=" + articleBigContent + ", articleLanguage=" + articleLanguage
				+ ", link=" + link + ", userName=" + userName + ", articleAuthor=" + articleAuthor
				+ ", articleUserLocation=" + articleUserLocation + ", articleIpAddress=" + articleIpAddress
				+ ", articleSentiment=" + articleSentiment + ", articleInsertedDate=" + articleInsertedDate
				+ ", articlePublishDate=" + articlePublishDate + ", articleMobile=" + articleMobile + ", articleEmail="
				+ articleEmail + ", articlePersonNer=" + articlePersonNer + ", articleLocationNer=" + articleLocationNer
				+ ", articleOrganizationNer=" + articleOrganizationNer + "]";
	}
	
}
