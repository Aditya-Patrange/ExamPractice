package com.cdac.sudarshan.discover.model;

import java.io.Serializable;
import java.util.Arrays;

public class Article_Tweet_User implements Serializable 
{
	private static final long serialVersionUID = 1L;
	private	String tweetUserId;
	private	String tweetUserDescription;
	private	String geoEnabled;
	private	String tweetUserLang;
	private	String tweetUserLocation;
	private	String tweetUserName;
	private	String tweetUserImageUrl;
	private	String tweetUserImageUrlLocal;
	private	String tweetUserScreenName;
	private	String tweetUserTimeZone;
	private	String tweetUserUrl;
	private	String tweetUserCountry;
	private	String tweetUserCountryCode;
	private	String tweetUserLatLong;
	private String tweetUserBgImageUrl;
	private String tweetUserBgImageUrlLocal;
    private String[] tweetUserWithHeldInCountry;
	private String tweetUserEmail;
	private Long tweetUserCreatedTime;
	private	int tweetUserFavouriteCount;
	private	int tweetUserFollowersCount;
	private	int tweetUserFriendsCount;
	private	int tweetUserListedCount;
	private	int tweetUserStatusCount;
	private	boolean tweetUserVerified;
	private	boolean tweetUserProtected;
	
	
	public String getTweetUserCountry() {
		return tweetUserCountry;
	}
	public void setTweetUserCountry(String tweetUserCountry) {
		this.tweetUserCountry = tweetUserCountry;
	}
	public String getTweetUserCountryCode() {
		return tweetUserCountryCode;
	}
	public void setTweetUserCountryCode(String tweetUserCountryCode) {
		this.tweetUserCountryCode = tweetUserCountryCode;
	}
	public String getTweetUserLatLong() {
		return tweetUserLatLong;
	}
	public void setTweetUserLatLong(String tweetUserLatLong) {
		this.tweetUserLatLong = tweetUserLatLong;
	}
	public String getTweetUserId() {
		return tweetUserId;
	}
	public void setTweetUserId(String tweetUserId) {
		this.tweetUserId = tweetUserId;
	}
	public Long getTweetUserCreatedTime() {
		return tweetUserCreatedTime;
	}
	public void setTweetUserCreatedTime(Long tweetUserCreatedTime) {
		this.tweetUserCreatedTime = tweetUserCreatedTime;
	}
	public String getTweetUserDescription() {
		return tweetUserDescription;
	}
	public void setTweetUserDescription(String tweetUserDescription) {
		this.tweetUserDescription = tweetUserDescription;
	}
	public int getTweetUserFavouriteCount() {
		return tweetUserFavouriteCount;
	}
	public void setTweetUserFavouriteCount(int tweetUserFavouriteCount) {
		this.tweetUserFavouriteCount = tweetUserFavouriteCount;
	}
	public int getTweetUserFollowersCount() {
		return tweetUserFollowersCount;
	}
	public void setTweetUserFollowersCount(int tweetUserFollowersCount) {
		this.tweetUserFollowersCount = tweetUserFollowersCount;
	}
	public int getTweetUserFriendsCount() {
		return tweetUserFriendsCount;
	}
	public void setTweetUserFriendsCount(int tweetUserFriendsCount) {
		this.tweetUserFriendsCount = tweetUserFriendsCount;
	}
	public String getGeoEnabled() {
		return geoEnabled;
	}
	public void setGeoEnabled(String geoEnabled) {
		this.geoEnabled = geoEnabled;
	}
	public String getTweetUserLang() {
		return tweetUserLang;
	}
	public void setTweetUserLang(String tweetUserLang) {
		this.tweetUserLang = tweetUserLang;
	}
	public int getTweetUserListedCount() {
		return tweetUserListedCount;
	}
	public void setTweetUserListedCount(int tweetUserListedCount) {
		this.tweetUserListedCount = tweetUserListedCount;
	}
	public String getTweetUserLocation() {
		return tweetUserLocation;
	}
	public void setTweetUserLocation(String tweetUserLocation) {
		this.tweetUserLocation = tweetUserLocation;
	}
	public String getTweetUserName() {
		return tweetUserName;
	}
	public void setTweetUserName(String tweetUserName) {
		this.tweetUserName = tweetUserName;
	}
	public String getTweetUserImageUrl() {
		return tweetUserImageUrl;
	}
	public void setTweetUserImageUrl(String tweetUserImageUrl) {
		this.tweetUserImageUrl = tweetUserImageUrl;
	}
	public String getTweetUserScreenName() {
		return tweetUserScreenName;
	}
	public void setTweetUserScreenName(String tweetUserScreenName) {
		this.tweetUserScreenName = tweetUserScreenName;
	}
	public int getTweetUserStatusCount() {
		return tweetUserStatusCount;
	}
	public void setTweetUserStatusCount(int tweetUserStatusCount) {
		this.tweetUserStatusCount = tweetUserStatusCount;
	}
	public String getTweetUserTimeZone() {
		return tweetUserTimeZone;
	}
	public void setTweetUserTimeZone(String tweetUserTimeZone) {
		this.tweetUserTimeZone = tweetUserTimeZone;
	}
	public String getTweetUserUrl() {
		return tweetUserUrl;
	}
	public void setTweetUserUrl(String tweetUserUrl) {
		this.tweetUserUrl = tweetUserUrl;
	}
	public boolean isTweetUserVerified() {
		return tweetUserVerified;
	}
	public void setTweetUserVerified(boolean tweetUserVerified) {
		this.tweetUserVerified = tweetUserVerified;
	}
	public String getTweetUserImageUrlLocal() {
		return tweetUserImageUrlLocal;
	}
	public void setTweetUserImageUrlLocal(String tweetUserImageUrlLocal) {
		this.tweetUserImageUrlLocal = tweetUserImageUrlLocal;
	}
	public boolean isTweetUserProtected() {
		return tweetUserProtected;
	}
	public void setTweetUserProtected(boolean tweetUserProtected) {
		this.tweetUserProtected = tweetUserProtected;
	}
	public String getTweetUserBgImageUrl() {
		return tweetUserBgImageUrl;
	}
	public void setTweetUserBgImageUrl(String tweetUserBgImageUrl) {
		this.tweetUserBgImageUrl = tweetUserBgImageUrl;
	}
	public String getTweetUserBgImageUrlLocal() {
		return tweetUserBgImageUrlLocal;
	}
	public void setTweetUserBgImageUrlLocal(String tweetUserBgImageUrlLocal) {
		this.tweetUserBgImageUrlLocal = tweetUserBgImageUrlLocal;
	}
	public String[] getTweetUserWithHeldInCountry() {
		return tweetUserWithHeldInCountry;
	}
	public void setTweetUserWithHeldInCountry(String[] tweetUserWithHeldInCountry) {
		this.tweetUserWithHeldInCountry = tweetUserWithHeldInCountry;
	}
	public String getTweetUserEmail() {
		return tweetUserEmail;
	}
	public void setTweetUserEmail(String tweetUserEmail) {
		this.tweetUserEmail = tweetUserEmail;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "Article_Tweet_User [tweetUserId=" + tweetUserId + ", tweetUserCreatedTime=" + tweetUserCreatedTime
				+ ", tweetUserDescription=" + tweetUserDescription + ", tweetUserFavouriteCount="
				+ tweetUserFavouriteCount + ", tweetUserFollowersCount=" + tweetUserFollowersCount
				+ ", tweetUserFriendsCount=" + tweetUserFriendsCount + ", geoEnabled=" + geoEnabled + ", tweetUserLang="
				+ tweetUserLang + ", tweetUserListedCount=" + tweetUserListedCount + ", tweetUserLocation="
				+ tweetUserLocation + ", tweetUserName=" + tweetUserName + ", tweetUserImageUrl=" + tweetUserImageUrl
				+ ", tweetUserImageUrlLocal=" + tweetUserImageUrlLocal + ", tweetUserScreenName=" + tweetUserScreenName
				+ ", tweetUserStatusCount=" + tweetUserStatusCount + ", tweetUserTimeZone=" + tweetUserTimeZone
				+ ", tweetUserUrl=" + tweetUserUrl + ", tweetUserCountry=" + tweetUserCountry
				+ ", tweetUserCountryCode=" + tweetUserCountryCode + ", tweetUserLatLong=" + tweetUserLatLong
				+ ", tweetUserVerified=" + tweetUserVerified + ", tweetUserProtected=" + tweetUserProtected
				+ ", tweetUserBgImageUrl=" + tweetUserBgImageUrl + ", tweetUserBgImageUrlLocal="
				+ tweetUserBgImageUrlLocal + ", tweetUserWithHeldInCountry="
				+ Arrays.toString(tweetUserWithHeldInCountry) + ", tweetUserEmail=" + tweetUserEmail + "]";
	}

}
