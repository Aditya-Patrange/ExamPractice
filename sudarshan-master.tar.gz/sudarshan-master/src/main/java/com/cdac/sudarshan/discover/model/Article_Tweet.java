package com.cdac.sudarshan.discover.model;

import java.io.Serializable;

public class Article_Tweet implements Serializable 
{
	private static final long serialVersionUID = 1L;
	private String tweetInReplyToScreenName;
	private String tweetInReplyToStatusId;
	private String tweetInReplyToUserId;
	private String tweetRetweetSourceId;
	private	String tweetSource;
	private String tweetQuotedStatusId;
	private String tweetQuotedStatusUserId;
	private String tweetQuotedStatusScreenName;
	private String tweetRetweetUserScreenName;
	private String tweetRetweetUserId;
	private int tweetRetweetCount;
	private int tweetFavouriteCount;
	private int tweetImpressionCount;
	private int tweetQuoteCount;
	private int tweetReplyCount;
	private boolean tweetIsRetweetFlag;
	private boolean tweetIsQuoteStatus;
	private boolean tweetIsPosibleSensitive;
	private boolean tweetTruncated;
	private Article_Tweet_User tweetUser;
	
	
	public String getTweetInReplyToScreenName() {
		return tweetInReplyToScreenName;
	}
	public void setTweetInReplyToScreenName(String tweetInReplyToScreenName) {
		this.tweetInReplyToScreenName = tweetInReplyToScreenName;
	}
	public String getTweetInReplyToStatusId() {
		return tweetInReplyToStatusId;
	}
	public void setTweetInReplyToStatusId(String tweetInReplyToStatusId) {
		this.tweetInReplyToStatusId = tweetInReplyToStatusId;
	}
	public String getTweetInReplyToUserId() {
		return tweetInReplyToUserId;
	}
	public void setTweetInReplyToUserId(String tweetInReplyToUserId) {
		this.tweetInReplyToUserId = tweetInReplyToUserId;
	}
	public String getTweetRetweetSourceId() {
		return tweetRetweetSourceId;
	}
	public void setTweetRetweetSourceId(String tweetRetweetSourceId) {
		this.tweetRetweetSourceId = tweetRetweetSourceId;
	}
	public String getTweetSource() {
		return tweetSource;
	}
	public void setTweetSource(String tweetSource) {
		this.tweetSource = tweetSource;
	}
	public String getTweetQuotedStatusId() {
		return tweetQuotedStatusId;
	}
	public void setTweetQuotedStatusId(String tweetQuotedStatusId) {
		this.tweetQuotedStatusId = tweetQuotedStatusId;
	}
	public String getTweetQuotedStatusUserId() {
		return tweetQuotedStatusUserId;
	}
	public void setTweetQuotedStatusUserId(String tweetQuotedStatusUserId) {
		this.tweetQuotedStatusUserId = tweetQuotedStatusUserId;
	}
	public String getTweetQuotedStatusScreenName() {
		return tweetQuotedStatusScreenName;
	}
	public void setTweetQuotedStatusScreenName(String tweetQuotedStatusScreenName) {
		this.tweetQuotedStatusScreenName = tweetQuotedStatusScreenName;
	}
	public String getTweetRetweetUserScreenName() {
		return tweetRetweetUserScreenName;
	}
	public void setTweetRetweetUserScreenName(String tweetRetweetUserScreenName) {
		this.tweetRetweetUserScreenName = tweetRetweetUserScreenName;
	}
	public String getTweetRetweetUserId() {
		return tweetRetweetUserId;
	}
	public void setTweetRetweetUserId(String tweetRetweetUserId) {
		this.tweetRetweetUserId = tweetRetweetUserId;
	}
	public int getTweetRetweetCount() {
		return tweetRetweetCount;
	}
	public void setTweetRetweetCount(int tweetRetweetCount) {
		this.tweetRetweetCount = tweetRetweetCount;
	}
	public int getTweetFavouriteCount() {
		return tweetFavouriteCount;
	}
	public void setTweetFavouriteCount(int tweetFavouriteCount) {
		this.tweetFavouriteCount = tweetFavouriteCount;
	}
	public int getTweetImpressionCount() {
		return tweetImpressionCount;
	}
	public void setTweetImpressionCount(int tweetImpressionCount) {
		this.tweetImpressionCount = tweetImpressionCount;
	}
	public int getTweetQuoteCount() {
		return tweetQuoteCount;
	}
	public void setTweetQuoteCount(int tweetQuoteCount) {
		this.tweetQuoteCount = tweetQuoteCount;
	}
	public int getTweetReplyCount() {
		return tweetReplyCount;
	}
	public void setTweetReplyCount(int tweetReplyCount) {
		this.tweetReplyCount = tweetReplyCount;
	}
	public boolean isTweetIsRetweetFlag() {
		return tweetIsRetweetFlag;
	}
	public void setTweetIsRetweetFlag(boolean tweetIsRetweetFlag) {
		this.tweetIsRetweetFlag = tweetIsRetweetFlag;
	}
	public boolean isTweetIsQuoteStatus() {
		return tweetIsQuoteStatus;
	}
	public void setTweetIsQuoteStatus(boolean tweetIsQuoteStatus) {
		this.tweetIsQuoteStatus = tweetIsQuoteStatus;
	}
	public boolean isTweetIsPosibleSensitive() {
		return tweetIsPosibleSensitive;
	}
	public void setTweetIsPosibleSensitive(boolean tweetIsPosibleSensitive) {
		this.tweetIsPosibleSensitive = tweetIsPosibleSensitive;
	}
	public boolean isTweetTruncated() {
		return tweetTruncated;
	}
	public void setTweetTruncated(boolean tweetTruncated) {
		this.tweetTruncated = tweetTruncated;
	}
	public Article_Tweet_User getTweetUser() {
		return tweetUser;
	}
	public void setTweetUser(Article_Tweet_User tweetUser) {
		this.tweetUser = tweetUser;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "Article_Tweet [tweetInReplyToScreenName=" + tweetInReplyToScreenName + ", tweetInReplyToStatusId="
				+ tweetInReplyToStatusId + ", tweetInReplyToUserId=" + tweetInReplyToUserId + ", tweetRetweetSourceId="
				+ tweetRetweetSourceId + ", tweetSource=" + tweetSource + ", tweetQuotedStatusId=" + tweetQuotedStatusId
				+ ", tweetQuotedStatusUserId=" + tweetQuotedStatusUserId + ", tweetQuotedStatusScreenName="
				+ tweetQuotedStatusScreenName + ", tweetRetweetUserScreenName=" + tweetRetweetUserScreenName
				+ ", tweetRetweetUserId=" + tweetRetweetUserId + ", tweetRetweetCount=" + tweetRetweetCount
				+ ", tweetFavouriteCount=" + tweetFavouriteCount + ", tweetImpressionCount=" + tweetImpressionCount
				+ ", tweetQuoteCount=" + tweetQuoteCount + ", tweetReplyCount=" + tweetReplyCount
				+ ", tweetIsRetweetFlag=" + tweetIsRetweetFlag + ", tweetIsQuoteStatus=" + tweetIsQuoteStatus
				+ ", tweetIsPosibleSensitive=" + tweetIsPosibleSensitive + ", tweetTruncated=" + tweetTruncated
				+ ", tweetUser=" + tweetUser + "]";
	}
}
