package com.cdac.sudarshan.discover.common;

public class ApiVo {
private String value,type,pname,value1;
private int key;



public String getValue1() {
	return value1;
}
public void setValue1(String value1) {
	this.value1 = value1;
}
public String getValue() {
	return value;
}
public void setValue(String value) {
	this.value = value;
}
public String getType() {
	return type;
}
public void setType(String type) {
	this.type = type;
}
public int getKey() {
	return key;
}
public void setKey(int key) {
	this.key = key;
}
public String getPname() {
	return pname;
}
public void setPname(String pname) {
	this.pname = pname;
}


}
