package com.cdac.sudarshan.discover.service;

import java.util.HashMap;

import org.springframework.http.ResponseEntity;


public interface IDashboardService {
	
	public ResponseEntity<?> getClassification(HashMap<String, Object> data);
	
	public ResponseEntity<?> getSentiment(HashMap<String, Object> data);
	
	public ResponseEntity<?> getWordCloud(HashMap<String, Object> data);

	

}
