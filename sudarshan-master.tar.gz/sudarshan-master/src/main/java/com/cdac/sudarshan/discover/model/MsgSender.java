package com.cdac.sudarshan.discover.model;

import java.io.Serializable;

public class MsgSender  implements Serializable
{
	private static final long serialVersionUID = 1L;
	private String name; 
	private String phoneno; 
	private String status; 
	private String photo;

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getPhoto() {
		return photo;
	}
	public void setPhoto(String photo) {
		this.photo = photo;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString()
	{
		return "MsgSender [name=" + name + ", phoneno=" + phoneno + ", status=" + status + ", photo=" + photo + "]";
	}
}
