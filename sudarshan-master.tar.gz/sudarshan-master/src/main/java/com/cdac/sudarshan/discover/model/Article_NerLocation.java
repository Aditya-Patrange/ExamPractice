package com.cdac.sudarshan.discover.model;

import java.io.Serializable;

public class Article_NerLocation implements Serializable
{
	private static final long serialVersionUID = 1L;
	private String keyword;
	private String nerCountry;
	private String nerLatLong;
	private String timeZone;
	private String countryName;
	private int count;
	private int nerSentiment=9;
	
	public String getTimeZone() {
		return timeZone;
	}
	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}
	public String getCountryName() {
		return countryName;
	}
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
	public String getKeyword() {
		return keyword;
	}
	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}
	public String getNerCountry() {
		return nerCountry;
	}
	public void setNerCountry(String nerCountry) {
		this.nerCountry = nerCountry;
	}
	public String getNerLatLong() {
		return nerLatLong;
	}
	public void setNerLatLong(String nerLatLong) {
		this.nerLatLong = nerLatLong;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public float getNerSentiment() {
		return nerSentiment;
	}
	public void setNerSentiment(int nerSentiment) {
		this.nerSentiment = nerSentiment;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "Article_NerLocation [keyword=" + keyword + ", nerCountry=" + nerCountry + ", nerLatLong=" + nerLatLong
				+ ", timeZone=" + timeZone + ", countryName=" + countryName + ", count=" + count + ", nerSentiment="
				+ nerSentiment + "]";
	}
}
