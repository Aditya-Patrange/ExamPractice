package com.cdac.sudarshan.discover.model;

public class TwitterChartVo 
{
	private String createdAt;
	private String count;
	private String mediaKey;
	private String mediaCount;
	private String localMediaKey;
	private String key;
	private String key1;
	private String key2;
	private String key3;
	private String key4;
	private String whatsappImageUrl;
	private String telegramImageUrl;

	public String getLocalMediaKey() {
		return localMediaKey;
	}
	public void setLocalMediaKey(String localMediaKey) {
		this.localMediaKey = localMediaKey;
	}
	public String getKey1() {
		return key1;
	}
	public void setKey1(String key1) {
		this.key1 = key1;
	}
	public String getKey2() {
		return key2;
	}
	public void setKey2(String key2) {
		this.key2 = key2;
	}
	public String getKey3() {
		return key3;
	}
	public void setKey3(String key3) {
		this.key3 = key3;
	}
	public String getKey4() {
		return key4;
	}
	public void setKey4(String key4) {
		this.key4 = key4;
	}
	public String getWhatsappImageUrl() {
		return whatsappImageUrl;
	}
	public void setWhatsappImageUrl(String whatsappImageUrl) {
		this.whatsappImageUrl = whatsappImageUrl;
	}
	public String getTelegramImageUrl() {
		return telegramImageUrl;
	}
	public void setTelegramImageUrl(String telegramImageUrl) {
		this.telegramImageUrl = telegramImageUrl;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public String getMediaKey() {
		return mediaKey;
	}
	public void setMediaKey(String mediaKey) {
		this.mediaKey = mediaKey;
	}
	public String getMediaCount() {
		return mediaCount;
	}
	public void setMediaCount(String mediaCount) {
		this.mediaCount = mediaCount;
	}
	public String getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}
	public String getCount() {
		return count;
	}
	public void setCount(String count) {
		this.count = count;
	}
	@Override
	public String toString() {
		return "TwitterChartVo [createdAt=" + createdAt + ", count=" + count + ", mediaKey=" + mediaKey
				+ ", mediaCount=" + mediaCount + ", localMediaKey=" + localMediaKey + ", key=" + key + ", key1=" + key1
				+ ", key2=" + key2 + ", key3=" + key3 + ", key4=" + key4 + ", whatsappImageUrl=" + whatsappImageUrl
				+ ", telegramImageUrl=" + telegramImageUrl + "]";
	}
}
