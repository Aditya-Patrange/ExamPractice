package com.cdac.sudarshan.discover.model;

import java.util.HashMap;

public class KeyMapVo 
{
	private String key;
	private String keyDate;
	private String count;
	private HashMap<String, String> map;
	
	public String getKeyDate() {
		return keyDate;
	}
	public void setKeyDate(String keyDate) {
		this.keyDate = keyDate;
	}
	public String getCount() {
		return count;
	}
	public void setCount(String count) {
		this.count = count;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public HashMap<String, String> getMap() {
		return map;
	}
	public void setMap(HashMap<String, String> map) {
		this.map = map;
	}
	@Override
	public String toString() {
		return "KeyMapVo [key=" + key + ", keyDate=" + keyDate + ", count=" + count + ", map=" + map + "]";
	}
}
