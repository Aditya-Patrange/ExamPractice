package com.cdac.sudarshan.discover.common;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.JSONArray;
import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.cdac.sudarshan.discover.model.Articel_Comment;
import com.cdac.sudarshan.discover.model.Articel_Ner;
import com.cdac.sudarshan.discover.model.ArticleDataExportVo;
import com.cdac.sudarshan.discover.model.Article_DailyMotion_User;
import com.cdac.sudarshan.discover.model.Article_Datacollection_New;
import com.cdac.sudarshan.discover.model.Article_Fb_Page;
import com.cdac.sudarshan.discover.model.Article_Media;
import com.cdac.sudarshan.discover.model.Article_NerLocation;
import com.cdac.sudarshan.discover.model.Article_Tweet_User;
import com.cdac.sudarshan.discover.model.Artilcle_Ner_Date;
import com.cdac.sudarshan.discover.model.CommonArticleVo;
import com.cdac.sudarshan.discover.model.CommonFbVo;
import com.cdac.sudarshan.discover.model.CountryCode;
import com.cdac.sudarshan.discover.model.Fb_OutputVo;
import com.cdac.sudarshan.discover.model.Fb_groupVo;
import com.cdac.sudarshan.discover.model.FrequencyAnalyzer;
import com.cdac.sudarshan.discover.model.InnsightTrends;
import com.cdac.sudarshan.discover.model.KeyMapVo;
import com.cdac.sudarshan.discover.model.LinkAnalysisDataVo;
import com.cdac.sudarshan.discover.model.MultipleEntryVo;
import com.cdac.sudarshan.discover.model.Tw_Tweet;
import com.cdac.sudarshan.discover.model.TweetHashTagsTblVo;
import com.cdac.sudarshan.discover.model.TweetLinksTblVo;
import com.cdac.sudarshan.discover.model.TweetMentionTblVo;
import com.cdac.sudarshan.discover.model.TweetTblVo;
import com.cdac.sudarshan.discover.model.TweetUserTblVo;
import com.cdac.sudarshan.discover.model.TweeterActionVo;
import com.cdac.sudarshan.discover.model.TwitterChartVo;
import com.cdac.sudarshan.discover.model.TwitterKloutVo;
import com.cdac.sudarshan.discover.model.TwitterTrendsVo;
import com.cdac.sudarshan.discover.model.TwitterUserListVo;
import com.cdac.sudarshan.discover.model.TwitterVo;
import com.cdac.sudarshan.discover.model.UserProfileConnectionExportVo;
import com.cdac.sudarshan.discover.model.UserProfileExportVo;
import com.cdac.sudarshan.discover.model.WordFrequency;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.internal.LinkedTreeMap;


import io.searchbox.client.JestClient;
import io.searchbox.client.JestResult;
import io.searchbox.core.Index;
import io.searchbox.core.Search;
import io.searchbox.core.SearchResult;
import io.searchbox.core.Update;
import io.searchbox.core.UpdateByQuery;
import io.searchbox.core.Validate;
import io.searchbox.core.search.aggregation.AvgAggregation;
import io.searchbox.core.search.aggregation.CardinalityAggregation;
import io.searchbox.core.search.aggregation.DateHistogramAggregation;
import io.searchbox.core.search.aggregation.DateHistogramAggregation.DateHistogram;
import io.searchbox.core.search.aggregation.StatsAggregation;
import io.searchbox.core.search.aggregation.SumAggregation;
import io.searchbox.core.search.aggregation.TermsAggregation;
import io.searchbox.core.search.aggregation.TermsAggregation.Entry;
import io.searchbox.core.search.aggregation.ValueCountAggregation;
import io.searchbox.params.Parameters;
import twitter4j.ResponseList;
import twitter4j.Status;
import twitter4j.Twitter;
import twitter4j.TwitterFactory;
import twitter4j.conf.ConfigurationBuilder;

@Repository
public class TwitterInnDaoImpl implements TwitterInnDao
{
	@Autowired
	private DataSource dataSource;

	@Autowired 
	private HttpSession httpSession;

	@Autowired
	private CommonUtils commonUtils;

	@Autowired
	private TwitterConstant twitterConstant;
	
	private static final Logger log = Logger.getLogger(TwitterInnDaoImpl.class);
	private JdbcTemplate jdbcTemplate;

	@Autowired
	public void setDataSource(DataSource dataSource) 
	{
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@Autowired
	JestClient client;

	public String getHighlightFields() 
	{
		String query=","+
				"\"highlight\" : {\n"+
				"\"fields\" : {\n"+
				"\"articleTitle\" : { \"number_of_fragments\": 0 ,\"pre_tags\" : [\"<b>\"], \"post_tags\" : [\"</b>\"]  },\n"+
				"\"articleBigContent\" : { \"number_of_fragments\": 0,\"pre_tags\" : [\"<b>\"], \"post_tags\" : [\"</b>\"] }\n"+
				"}\n"+
				"}\n";
		return query;
		//return "";
	}


	
	
	public ArrayList<TwitterVo> getTweets(TweeterActionVo tweeterActionVo) 
	{
		long t1=System.currentTimeMillis();
				
		ArrayList<TwitterVo> list = new ArrayList<TwitterVo>();
		HashSet set = new HashSet();
		
	    //Getting the current date
        Date date = new Date();
        //This method returns the time in millis
        long timeMilli = date.getTime();

		try 
		{
			int from=0;
			int size=50;
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getIsRpt())) 
			{
				if(CommonUtils.stringNotEmpty(tweeterActionVo.getNoTweet())) 
				{   
					from=0;
					size=Integer.parseInt(tweeterActionVo.getNoTweet());
				}
			}
			else 
			{
				from=Integer.parseInt(tweeterActionVo.getRowNum());
				size=50;
			}
						
			String subQuery = rtnFilterQuery(tweeterActionVo, -1);
			String query="{\n"
					+ "      \"from\":"+from+",\n"
					+ "      \"size\":"+size+",\n"
					+subQuery+
					getTweetsSortOrder(tweeterActionVo);
					
					
			if(!CommonUtils.stringNotEmpty(tweeterActionVo.getIsRpt())) 
			{
			    query += getHighlightFields();
			}					
					
			query+= "}\n";
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			long t2=System.currentTimeMillis();			
						
			List<Article_Datacollection_New> testLst = result.getSourceAsObjectList(Article_Datacollection_New.class);
			JsonArray arry = null;
			if(testLst.size()>0) 
			{
				
				
				arry=result.getJsonObject().get("hits").getAsJsonObject().get("hits").getAsJsonArray();
			}

			int i=0;
			for(Article_Datacollection_New article_Datacollection_New : testLst) 
			{
				String articleId = article_Datacollection_New.getArticleId();
				//System.out.println("articleId: "+articleId);
				
				if(set.add(articleId))
				{
					TwitterVo twitterVo = new TwitterVo();
					String link = article_Datacollection_New.getArticleLinkUrl();				
					switch(article_Datacollection_New.getArticleSource())
					{
					case "tw":
						link="https://twitter.com/"+article_Datacollection_New.getArticleAuthor()+"/status/"+article_Datacollection_New.getArticleId();
						break;
					case "yt":
						link=article_Datacollection_New.getArticleLinkUrl();
						break;
					case "fb":
						break;
					case "insta":
						break;
					case "dm":
						break;
					
					case "wp":
						break;
					case "tm":
						break;
					case "wb":
						break;
					case "article":
						link=article_Datacollection_New.getArticleLinkUrl();
						break;
									
					default:
						link=article_Datacollection_New.getArticleLinkUrl();
						break;
					}
					
					String fileName=article_Datacollection_New.getArticleMediaCaption()==null?"":article_Datacollection_New.getArticleMediaCaption().trim();
					twitterVo.setLink(link);
					//twitterVo.setTotalTweetCount(Integer.toString(result.getTotal()));
					twitterVo.setTotalTweetCount(Long.toString(result.getTotal()));
					twitterVo.setArticleId(article_Datacollection_New.getArticleId());
					twitterVo.setArticleAuthor(article_Datacollection_New.getArticleAuthor());
					twitterVo.setArticleAuthorId(article_Datacollection_New.getArticleAuthorId());
					twitterVo.setArticleAuthorImage(article_Datacollection_New.getArticleAuthorImage());
					twitterVo.setArticleAuthorImageUrlLocal(article_Datacollection_New.getArticleAuthorImageUrlLocal());			
					twitterVo.setArticlePublishDate(CommonUtils.convertUnixTimeToDateDisplayFormat((article_Datacollection_New.getArticlePublishDate())));
					twitterVo.setCreationDate(CommonUtils.convertUnixTimeToDateDisplayFormat(timeMilli));
					twitterVo.setArticleTitle(article_Datacollection_New.getArticleTitle());
					twitterVo.setArticleSubTitle(article_Datacollection_New.getArticleSubTitle());
					twitterVo.setArticleBigContent(article_Datacollection_New.getArticleBigContent());
					twitterVo.setArticleSentiment(article_Datacollection_New.getArticleSentiment());
					twitterVo.setArticleNewsSource(article_Datacollection_New.getArticleNewsSource());
					twitterVo.setArticleNewsCategory(article_Datacollection_New.getArticleNewsCategory());
					twitterVo.setArticleLinkUrl(article_Datacollection_New.getArticleLinkUrl());
					twitterVo.setPriority("0");
					twitterVo.setArticlePriority(article_Datacollection_New.getArticlePriority()==null?"2":article_Datacollection_New.getArticlePriority());
					twitterVo.setRssCountry(article_Datacollection_New.getRssCountry());
					twitterVo.setRssCountryCode(article_Datacollection_New.getRssCountryCode());
					twitterVo.setArticleAuthorScreenName(article_Datacollection_New.getArticleAuthorScreenName());
					twitterVo.setArticleSource(article_Datacollection_New.getArticleSource());
					twitterVo.setArticleType(article_Datacollection_New.getArticleType());
					twitterVo.setArticleMedia(article_Datacollection_New.getArticleMedia());
					twitterVo.setArticleMediaCaption(article_Datacollection_New.getArticleMediaCaption());
					twitterVo.setArticleEmotion(article_Datacollection_New.getArticleEmotion());
					twitterVo.setArticleEmotionScore(article_Datacollection_New.getArticleEmotionScore());
					twitterVo.setArticleSummary(article_Datacollection_New.getArticleSummary());
					twitterVo.setArticleClassification(article_Datacollection_New.getArticleClassification());
					twitterVo.setFtpFileUrl(TwitterConstant.getFtpFileUrl()+"ftp/"+fileName);
					twitterVo.setFederateFileUrl(TwitterConstant.getFtpFileUrl()+"federated/"+fileName);
					twitterVo.setName(fileName);
					
					
					//ArrayList<Articel_Ner> peronNerList = article_Datacollection_New.getArticlePersonNer();
					twitterVo.setArticlePersonNer(article_Datacollection_New.getArticlePersonNer());
					twitterVo.setArticleLocationNer(article_Datacollection_New.getArticleLocationNer());
					twitterVo.setArticleOrganizationNer(article_Datacollection_New.getArticleOrganizationNer());
					//twitterVo.setArticleLocationNer(article_Datacollection_New.getArticleLocationNer());

					if(article_Datacollection_New.getArticleMarked() !=null) 
					{
						if(article_Datacollection_New.getArticleMarked().size()>0)
						{
							String user = (String)httpSession.getAttribute(ApplicationConstants.LOGINUSERID);
							if(article_Datacollection_New.getArticleMarked().indexOf(Integer.parseInt(user))>-1)
							{
								twitterVo.setPriority("1");
							}
						}
					}

					twitterVo.setTweet(article_Datacollection_New.getTweet());
					twitterVo.setYoutube(article_Datacollection_New.getYoutube());
					twitterVo.setDailymotion(article_Datacollection_New.getDailymotion());
					twitterVo.setInstagram(article_Datacollection_New.getInstagram());
					twitterVo.setFacebook(article_Datacollection_New.getFacebook());
					twitterVo.setWordpress(article_Datacollection_New.getWordpress());
					twitterVo.setBlogger(article_Datacollection_New.getBlogger());				

					//Innsight Local Image and ODS, FRS
					twitterVo.setArticleImage(article_Datacollection_New.getArticleImage());
					String profileImgName = article_Datacollection_New.getArticleAuthorImageUrlLocal();
					twitterVo.setProfileLocalImage(profileImgName);
					twitterVo.setInnsightImageFlag(TwitterConstant.getInnsightImageFlag());
					twitterVo.setInnsightLocalImageUrl(TwitterConstant.getInnsightLocalImageUrl());
					twitterVo.setFacebookLocalImageUrl(TwitterConstant.getFacebookLocalImageUrl());	
					

					if(arry.get(i).getAsJsonObject().has("highlight")) 
					{
						JsonObject highlightObj=arry.get(i).getAsJsonObject().get("highlight").getAsJsonObject();
						if(highlightObj.has("articleTitle")) 
						{
							try 
							{
								twitterVo.setArticleTitle(highlightObj.get("articleTitle").getAsJsonArray().getAsString());
							}
							catch(Exception ex) 
							{ 
								ex.printStackTrace();
							}
						}
						if(highlightObj.has("articleBigContent"))
						{
							try
							{
								twitterVo.setArticleBigContent(highlightObj.get("articleBigContent").getAsJsonArray().getAsString());
							}
							catch(Exception ex) 
							{
								ex.printStackTrace();
							}
						}
					}

					list.add(twitterVo);
					i++;
				}				
			}
		} 
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return list;
	}

	
	
	public ArrayList<TwitterVo> getHashTags(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		try 
		{
			int size=TwitterConstant.getSizeForEsTermAgg(tweeterActionVo, tweeterActionVo.getNoHashtag());	
			String sortQuery=TwitterConstant.getSortForEsTermAgg(tweeterActionVo.getHashTagSortOrder().toLowerCase().trim());
			String subQuery=rtnFilterQuery(tweeterActionVo, -1);

			String avgAgg="";
			if(tweeterActionVo.getOnlyCount().isEmpty())
			{
			   avgAgg=TwitterConstant.getAvg("articleSentiment");
			}
			
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"termagg\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\"articleHashTag\"\n,"+
					"\"size\":\""+size+"\"\n,"+
					sortQuery+
					"}\n"+
					avgAgg+
					"}\n"+
					"}\n"+
					"}\n";
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);					
			TermsAggregation terms = result.getAggregations().getTermsAggregation("termagg");
			
			if(terms !=null) 
			{
				List<Entry> entry = terms.getBuckets();
				for(Entry entry2 : entry)
				{
					TwitterVo twitterVo=new TwitterVo();
					twitterVo.setHashtag(entry2.getKey());
					twitterVo.setHashCount(Long.toString(entry2.getCount()));
					if(tweeterActionVo.getOnlyCount().isEmpty())
					{
						AvgAggregation avg = entry2.getAvgAggregation("avg");
						twitterVo.setSentiment(Double.toString(avg.getAvg()));
					}
					lst.add(twitterVo);							   
				}
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return lst; 
	}

	
	
	public ArrayList<TwitterVo> mostInfluenceTweetUsers(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		try 
		{
			int size=TwitterConstant.getSizeForEsTermAgg(tweeterActionVo, tweeterActionVo.getNoHashtag());	
			String sortQuery=TwitterConstant.getSortForEsTermAgg(tweeterActionVo.getHashTagSortOrder().toLowerCase().trim());
			String subQuery=rtnFilterQuery(tweeterActionVo, -1);

			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"termagg\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\"tweet.tweetRetweetUserScreenName\"\n,"+
					"\"size\":\""+size+"\"\n,"+
					sortQuery+
					"}\n"+
					//TwitterConstant.getAvg("articleSentiment")+
					"}\n"+
					"}\n"+
					"}\n";
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			TermsAggregation terms = result.getAggregations().getTermsAggregation("termagg");
			List<Entry> entry = terms.getBuckets();
			for(Entry entry2 : entry) 
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setHashtag(entry2.getKey());
				twitterVo.setHashCount(Long.toString(entry2.getCount()));
				/*AvgAggregation avg = entry2.getAvgAggregation("avg");
			    twitterVo.setSentiment(Double.toString(avg.getAvg()));*/
				lst.add(twitterVo);
			}
		} 
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return lst;
	}
	
	
	public ArrayList<TwitterVo> getUsers(TweeterActionVo tweeterActionVo)
	{
		ArrayList<TwitterVo> list = new ArrayList<TwitterVo>();
		try
		{
			String subAggs=",\n"+
					"\"aggs\": {\n"+
					"\"myaggs\": {\n"+
					"\"top_hits\": {\n"+
					"\"_source\": {\n"+
					"\"include\": [\n"+
					"\"articleAuthorId\"\n,"+
					"\"articleAuthor\"\n,"+
					"\"articleAuthorImage\"\n,"+
					"\"articleAuthorImageUrlLocal\"\n,"+				
					"\"tweet.tweetUser.tweetUserCreatedTime\"\n,"+
					"\"articleSource\"\n"+
					"]"+
					"},"+
					"\"size\": 1\n"+
					"}"+
					"}"+
					"}";

			int size = TwitterConstant.getSizeForEsTermAgg(tweeterActionVo, tweeterActionVo.getNoUser());	
			//int size = 1000;
			String subQuery=rtnFilterQuery(tweeterActionVo, -1);
			String sortQuery=TwitterConstant.getSortForEsTermAgg(tweeterActionVo.getUserSortFilter().toLowerCase().trim());
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"termagg\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\"articleAuthor\"\n,"+
					"\"size\":\""+size+"\"\n,"+
					sortQuery+
					"}\n"+
					subAggs+
					"}\n"+
					"}\n"+
					"}\n";
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			//Nested 
			JSONObject obj = new JSONObject(result.getJsonString());
			
			String totalCount=obj.getJSONObject("hits").get("total").toString();
			if(obj.has("aggregations"))
			{
				JSONArray bucketArr = obj.getJSONObject("aggregations").getJSONObject("termagg").getJSONArray("buckets");
				for(int i = 0; i < bucketArr.length(); i++)
				{
					TwitterVo twitterVo=new TwitterVo();
					twitterVo.setUserName(bucketArr.getJSONObject(i).getString("key").toString());
					twitterVo.setUserCount(Integer.toString(bucketArr.getJSONObject(i).getInt("doc_count")));
					if(i == 0)
					{
						twitterVo.setTweetCount(totalCount);
					}
					
					JSONArray hitsArr=bucketArr.getJSONObject(i).getJSONObject("myaggs").getJSONObject("hits").getJSONArray("hits");
					for(int ii = 0; ii < hitsArr.length(); ii++)
					{
						JSONObject objUser=hitsArr.getJSONObject(ii).getJSONObject("_source");
						if(!objUser.isNull("articleAuthorId"))
						{
							twitterVo.setUserId(objUser.getString("articleAuthorId"));
						}
						else 
						{
							twitterVo.setUserId(twitterVo.getUserName());
						}						
						twitterVo.setArticleAuthor(objUser.getString("articleAuthor"));
						twitterVo.setType(objUser.getString("articleSource"));
						twitterVo.setArticleAuthorImage(objUser.isNull("articleAuthorImage")?"":objUser.getString("articleAuthorImage"));
						twitterVo.setArticleAuthorImageUrlLocal(objUser.isNull("articleAuthorImageUrlLocal")?"":objUser.getString("articleAuthorImageUrlLocal"));
						if(objUser.has("tweet") && !objUser.isNull("tweet"))
						{
							BigInteger createdDate=objUser.getJSONObject("tweet").getJSONObject("tweetUser").getBigInteger("tweetUserCreatedTime");
							//System.out.println("createdDate::::::::"+createdDate);
							//twitterVo.setTweeterId(createdDate.toString());
							twitterVo.setArticlePublishDate(CommonUtils.convertUnixTimeToDateDisplayFormat(createdDate.longValue()));
						}   
					}
					list.add(twitterVo);
				}
			}		
		}	
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return list; 
	}

	
	
	public ArrayList<TwitterVo> getAllAuthorsDetails(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> list = new ArrayList<TwitterVo>();
		try
		{
			String subAggs=",\n"+
					"\"aggs\": {\n"+
					"\"myaggs\": {\n"+
					"\"top_hits\": {\n"+
					"\"_source\": {\n"+
					"\"include\": [\n"+
					"\"articleAuthorId\"\n,"+
					"\"articleAuthor\"\n,"+
					"\"articleAuthorImage\"\n,"+
					"\"tweet.tweetUser.tweetUserCreatedTime\"\n,"+
					"\"tweet.tweetUser.tweetUserDescription\"\n,"+
					"\"tweet.tweetUser.tweetUserLocation\"\n,"+
					"\"tweet.tweetUser.tweetUserName\"\n,"+
					"\"tweet.tweetUser.tweetUserImageUrl\"\n,"+
					"\"tweet.tweetUser.tweetUserScreenName\"\n,"+
					"\"tweet.tweetUser.tweetUserFollowersCount\"\n,"+
					"\"tweet.tweetUser.tweetUserFriendsCount\"\n,"+
					"\"tweet.tweetUser.tweetUserStatusCount\"\n,"+					
					"\"articleSource\"\n"+
					"]"+
					"},"+
					"\"size\": 1\n"+
					"}"+
					"}"+
					"}";

			int size = TwitterConstant.getSizeForEsTermAgg(tweeterActionVo, tweeterActionVo.getNoUser());	
			//int size = 1000;
			String subQuery=rtnFilterQuery(tweeterActionVo, -1);
			String sortQuery=TwitterConstant.getSortForEsTermAgg(tweeterActionVo.getUserSortFilter().toLowerCase().trim());
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"termagg\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\"articleAuthor\"\n,"+
					"\"size\":\""+size+"\"\n,"+
					sortQuery+
					"}\n"+
					subAggs+
					"}\n"+
					"}\n"+
					"}\n";
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			//Nested 
			JSONObject obj = new JSONObject(result.getJsonString());
			if(obj.has("aggregations"))
			{
				JSONArray bucketArr = obj.getJSONObject("aggregations").getJSONObject("termagg").getJSONArray("buckets");
				for(int i = 0; i < bucketArr.length(); i++)
				{
					TwitterVo twitterVo=new TwitterVo();
					twitterVo.setUserName(bucketArr.getJSONObject(i).getString("key").toString());
					twitterVo.setUserCount(Integer.toString(bucketArr.getJSONObject(i).getInt("doc_count")));
					JSONArray hitsArr=bucketArr.getJSONObject(i).getJSONObject("myaggs").getJSONObject("hits").getJSONArray("hits");
					for(int ii = 0; ii < hitsArr.length(); ii++)
					{
						JSONObject objUser=hitsArr.getJSONObject(ii).getJSONObject("_source");
						if(!objUser.isNull("articleAuthorId"))
						{
							twitterVo.setUserId(objUser.getString("articleAuthorId"));
						}
						else 
						{
							twitterVo.setUserId(twitterVo.getUserName());
						}						
						twitterVo.setArticleAuthor(objUser.getString("articleAuthor"));
						twitterVo.setType(objUser.getString("articleSource"));
						twitterVo.setArticleAuthorImage(objUser.isNull("articleAuthorImage")?"":objUser.getString("articleAuthorImage"));
						
						if(objUser.has("tweet") && !objUser.isNull("tweet"))
						{
							BigInteger createdDate=objUser.getJSONObject("tweet").getJSONObject("tweetUser").getBigInteger("tweetUserCreatedTime");
							String userLocation=objUser.getJSONObject("tweet").getJSONObject("tweetUser").getString("tweetUserLocation");
							String userDescription=objUser.getJSONObject("tweet").getJSONObject("tweetUser").getString("tweetUserDescription");
							String userName=objUser.getJSONObject("tweet").getJSONObject("tweetUser").getString("tweetUserName");
							String userImageUrl=objUser.getJSONObject("tweet").getJSONObject("tweetUser").getString("tweetUserImageUrl");
							String userScreenName=objUser.getJSONObject("tweet").getJSONObject("tweetUser").getString("tweetUserScreenName");
							int userFollowersCount=objUser.getJSONObject("tweet").getJSONObject("tweetUser").getInt("tweetUserFollowersCount");
							int userFriendsCount=objUser.getJSONObject("tweet").getJSONObject("tweetUser").getInt("tweetUserFriendsCount");
							int userTweetsCount=objUser.getJSONObject("tweet").getJSONObject("tweetUser").getInt("tweetUserStatusCount");

							
							
							twitterVo.setArticlePublishDate(CommonUtils.convertUnixTimeToDateDisplayFormat(createdDate.longValue()));
							twitterVo.setLocation(userLocation);
							twitterVo.setDescription(userDescription);
							twitterVo.setArticleAuthorImage(userImageUrl);
							twitterVo.setUserName(userName);
							twitterVo.setScreenName(userScreenName);
							twitterVo.setFollowersCount(String.valueOf(userFollowersCount));
							twitterVo.setFriendsCount(String.valueOf(userFriendsCount));
							twitterVo.setTweetCount(String.valueOf(userTweetsCount));
						}   
					}
					list.add(twitterVo);
				}
			}		
		}	
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return list;
	}
	
	
	
	public ArrayList<TwitterVo> getUsersOnly(TweeterActionVo tweeterActionVo)
	{
		ArrayList<TwitterVo> list = new ArrayList<TwitterVo>();
		try
		{
			int size = TwitterConstant.getSizeForEsTermAgg(tweeterActionVo, tweeterActionVo.getNoUser());	
			String subQuery=rtnFilterQuery(tweeterActionVo, -1);
			String sortQuery=TwitterConstant.getSortForEsTermAgg(tweeterActionVo.getUserSortFilter().toLowerCase().trim());
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"termagg\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\"articleAuthor\"\n,"+
					"\"size\":\""+size+"\"\n,"+
					sortQuery+
					"}\n"+
					//subAggs+
					"}\n"+
					"}\n"+
					"}\n";
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			//Nested 
			JSONObject obj = new JSONObject(result.getJsonString());
			if(obj.has("aggregations"))
			{
				JSONArray bucketArr = obj.getJSONObject("aggregations").getJSONObject("termagg").getJSONArray("buckets");
				for(int i = 0; i < bucketArr.length(); i++)
				{
					TwitterVo twitterVo=new TwitterVo();
					twitterVo.setUserName(bucketArr.getJSONObject(i).getString("key").toString());
					twitterVo.setUserCount(Integer.toString(bucketArr.getJSONObject(i).getInt("doc_count")));
					list.add(twitterVo);
				}
			}		
		}	
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return list; 
	}

	
	
	public ArrayList<TwitterVo> getTwUsersDetails(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> list = new ArrayList<TwitterVo>();
		try
		{
			String subAggs=",\n"+
					"\"aggs\": {\n"+
					"\"myaggs\": {\n"+
					"\"top_hits\": {\n"+
					"\"_source\": {\n"+
					"\"include\": [\n"+
					"\"articleAuthorId\"\n,"+
					"\"articleAuthor\"\n,"+
					"\"articleAuthorImage\"\n,"+
					"\"articleAuthorImageUrlLocal\"\n,"+				
					"\"tweet.tweetUser.tweetUserCreatedTime\"\n,"+
					"\"tweet.tweetUser.tweetUserDescription\"\n,"+
					"\"tweet.tweetUser.tweetUserLocation\"\n,"+
					"\"tweet.tweetUser.tweetUserName\"\n,"+
					"\"tweet.tweetUser.tweetUserImageUrl\"\n,"+
					"\"tweet.tweetUser.tweetUserScreenName\"\n,"+
					"\"tweet.tweetUser.tweetUserFollowersCount\"\n,"+
					"\"tweet.tweetUser.tweetUserFriendsCount\"\n,"+
					"\"tweet.tweetUser.tweetUserStatusCount\"\n,"+					
					"\"articleSource\"\n"+
					"]"+
					"},"+
					"\"size\": 1\n"+
					"}"+
					"}"+
					"}";

			int size = TwitterConstant.getSizeForEsTermAgg(tweeterActionVo, tweeterActionVo.getNoUser());	
			//int size = 1000;
			String subQuery=rtnFilterQuery(tweeterActionVo, -1);
			String sortQuery=TwitterConstant.getSortForEsTermAgg(tweeterActionVo.getUserSortFilter().toLowerCase().trim());
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"termagg\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\"articleAuthor\"\n,"+
					"\"size\":\""+size+"\"\n,"+
					sortQuery+
					"}\n"+
					subAggs+
					"}\n"+
					"}\n"+
					"}\n";
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			//Nested 
			JSONObject obj = new JSONObject(result.getJsonString());
			if(obj.has("aggregations"))
			{
				JSONArray bucketArr = obj.getJSONObject("aggregations").getJSONObject("termagg").getJSONArray("buckets");
				for (int i = 0; i < bucketArr.length(); i++)
				{
					TwitterVo twitterVo=new TwitterVo();
					twitterVo.setUserName(bucketArr.getJSONObject(i).getString("key").toString());
					twitterVo.setUserCount(Integer.toString(bucketArr.getJSONObject(i).getInt("doc_count")));
					JSONArray hitsArr=bucketArr.getJSONObject(i).getJSONObject("myaggs").getJSONObject("hits").getJSONArray("hits");
					for (int ii = 0; ii < hitsArr.length(); ii++)
					{
						JSONObject objUser=hitsArr.getJSONObject(ii).getJSONObject("_source");
						if(!objUser.isNull("articleAuthorId"))
						{
							twitterVo.setUserId(objUser.getString("articleAuthorId"));
						}
						else 
						{
							twitterVo.setUserId(twitterVo.getUserName());
						}						
						twitterVo.setArticleAuthor(objUser.getString("articleAuthor"));
						twitterVo.setType(objUser.getString("articleSource"));
						twitterVo.setArticleAuthorImage(objUser.isNull("articleAuthorImage")?"":objUser.getString("articleAuthorImage"));
						twitterVo.setArticleAuthorImageUrlLocal(objUser.isNull("articleAuthorImageUrlLocal")?"":objUser.getString("articleAuthorImageUrlLocal"));
						if(objUser.has("tweet") && !objUser.isNull("tweet"))
						{
							BigInteger createdDate=objUser.getJSONObject("tweet").getJSONObject("tweetUser").getBigInteger("tweetUserCreatedTime");
							String userLocation=objUser.getJSONObject("tweet").getJSONObject("tweetUser").getString("tweetUserLocation");
							String userDescription=objUser.getJSONObject("tweet").getJSONObject("tweetUser").getString("tweetUserDescription");
							String userName=objUser.getJSONObject("tweet").getJSONObject("tweetUser").getString("tweetUserName");
							String userImageUrl=objUser.getJSONObject("tweet").getJSONObject("tweetUser").getString("tweetUserImageUrl");
							String userScreenName=objUser.getJSONObject("tweet").getJSONObject("tweetUser").getString("tweetUserScreenName");
							int userFollowersCount=objUser.getJSONObject("tweet").getJSONObject("tweetUser").getInt("tweetUserFollowersCount");
							int userFriendsCount=objUser.getJSONObject("tweet").getJSONObject("tweetUser").getInt("tweetUserFriendsCount");
							int userTweetsCount=objUser.getJSONObject("tweet").getJSONObject("tweetUser").getInt("tweetUserStatusCount");
							
                           /*
							System.out.println("createdDate: "+createdDate);
							System.out.println("userLocation: "+userLocation);
							System.out.println("userDescription: "+userDescription);
							System.out.println("userName: "+userName);
							System.out.println("userImageUrl: "+userImageUrl);
							System.out.println("userScreenName: "+userScreenName);
							System.out.println("userFollowersCount: "+userFollowersCount);
							System.out.println("userFriendsCount: "+userFriendsCount);
							System.out.println("userTweetsCount: "+userTweetsCount);
							System.out.println("--------------------------------------------------------");
							*/
							
							twitterVo.setArticlePublishDate(CommonUtils.convertUnixTimeToDateDisplayFormat(createdDate.longValue()));
							twitterVo.setLocation(userLocation);
							twitterVo.setDescription(userDescription);
							twitterVo.setArticleAuthorImage(userImageUrl);
							twitterVo.setUserName(userName);
							twitterVo.setScreenName(userScreenName);
							twitterVo.setFollowersCount(String.valueOf(userFollowersCount));
							twitterVo.setFriendsCount(String.valueOf(userFriendsCount));
							twitterVo.setTweetCount(String.valueOf(userTweetsCount));
							
						}   
					}
					list.add(twitterVo);
				}
			}		
		}	
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return list; 
	}
	

	public String getUserSortOrder(TweeterActionVo tweeterActionVo)
	{
		String sortQuery="";
		try
		{
			if(tweeterActionVo.getUserSortFilter().toLowerCase().trim().equals("fav")) //favourite
			{
				sortQuery="{\n"
						+"\"user.favouritesCount\": {\n"
						+"\"order\": \"desc\""
						+"}\n"
						+"}\n";
			}
			else if(tweeterActionVo.getUserSortFilter().toLowerCase().trim().equals("frnds"))  //friends
			{
				sortQuery="{\n"
						+"\"user.friendsCount\": {\n"
						+"\"order\": \"desc\""
						+"}\n"
						+"}\n";
			}
			else if(tweeterActionVo.getUserSortFilter().toLowerCase().trim().equals("ttw"))  //total tweet
			{
				sortQuery="{\n"
						+"\"user.statusesCount\": {\n"
						+"\"order\": \"desc\""
						+"}\n"
						+"}\n";
			}
			else if(tweeterActionVo.getUserSortFilter().toLowerCase().trim().equals("foll"))  //followers
			{
				sortQuery="{\n"
						+"\"user.followersCount\": {\n"
						+"\"order\": \"desc\""
						+"}\n"
						+"}\n";

			}
			String sort=",\"sort\": [\n"
					+sortQuery
					+"]\n";
			return sort;
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			return "";
		}
		finally
		{
			sortQuery=null;
		}
	}

	
	
	public ArrayList<TwitterVo> getLink(TweeterActionVo tweeterActionVo)
	{
        ArrayList<TwitterVo> list = new ArrayList<TwitterVo>();
        try 
        {
              int size=0;
              String linkType="articleMedia.mediaUrl";
              if(tweeterActionVo.getMediaType() != null && tweeterActionVo.getMediaType().equals("domain")) 
              {
                    size=TwitterConstant.getSizeForEsTermAgg(tweeterActionVo, tweeterActionVo.getNoDomain());    
              }
              else 
              {
                    size=TwitterConstant.getSizeForEsTermAgg(tweeterActionVo, tweeterActionVo.getNoLinks());
              }
              
              String sortQuery=null;
              if(tweeterActionVo.getMediaType() != null && !tweeterActionVo.getMediaType().equals("domain"))
              {
                    sortQuery=TwitterConstant.getSortForEsTermAgg(tweeterActionVo.getUrlSortOrder().toLowerCase().trim());
              } 
              else 
              {
                    sortQuery=TwitterConstant.getSortForEsTermAgg(tweeterActionVo.getDomainSortOrder().toLowerCase().trim());
              }
              String subQuery=rtnFilterQuery(tweeterActionVo,-1);
              String query="{\n"+
                          "\"size\": 0,\n" +
                          subQuery+
                          ",\"aggs\":\n"+
                          "{\n"+
                          "\"termagg\":{\n"+
                          "\"terms\":{\n"+
                          "\"field\":\""+linkType+"\"\n,"+
                          "\"size\":\""+size+"\"\n,"+
                          sortQuery+
                          "}\n"+
                          "}\n"+
                          "}\n"+
                          "}\n";

              System.out.println(linkType+"********* "+query);
              Search search = new Search.Builder(query)
                          // multiple index or types can be added.
                          .addIndex(TwitterConstant.getDbname())
                          .addType(TwitterConstant.getTypeName())
                          .build();

              SearchResult result = client.execute(search);
              TermsAggregation terms = result.getAggregations().getTermsAggregation("termagg");
              if(terms !=null) 
              {
                    List<Entry> entry = terms.getBuckets();
                    for(Entry entry2 : entry)
                    {
                          TwitterVo twitterVo=new TwitterVo();
                          twitterVo.setLink((entry2.getKey()));
                          twitterVo.setLinkCount(Long.toString(entry2.getCount()));
                          twitterVo.setUrl((entry2.getKey()));
                          list.add(twitterVo);
                    }
              }
        } 
        catch(Exception ex) 
        {
              ex.printStackTrace();
        }
        return list;
  }


	
	public ArrayList<TwitterVo> getTweetGeo(TweeterActionVo tweeterActionVo)
	{
		return null;
	}

	
	public ArrayList<TwitterVo> getTweetGraph(TweeterActionVo tweeterActionVo)
	{
		ArrayList<TwitterVo> list = new ArrayList<TwitterVo>();
		try
		{
			String subQuery=rtnFilterQuery(tweeterActionVo,-1);
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"dateHistogram\":{\n"+
					"\"date_histogram\":{\n"+
					"\"field\":\"articlePublishDate\",\n"+
					"\"interval\": \"day\",\n"+
					"\"min_doc_count\": 0,\n"+
					"\"extended_bounds\" : {\n"+ 
					"\"min\" : \""+TwitterConstant.convertStrToDate_yyyy_MM_dd(tweeterActionVo.getDateFrom())+"\",\n"+
					"\"max\" : \""+TwitterConstant.convertStrToDate_yyyy_MM_dd(tweeterActionVo.getDateTo())+"\"\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";

			System.out.println("getTweetGraph()==== "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			DateHistogramAggregation terms = result.getAggregations().getDateHistogramAggregation("dateHistogram");
			if(terms !=null) 
			{
				List<DateHistogram> entry = terms.getBuckets();
				for(DateHistogram dateHistogram : entry) 
				{
					TwitterVo twitterVo=new TwitterVo();
					twitterVo.setCreatedAt(CommonUtils.convertUnixTimeToDate_yyyy_mm_dd((dateHistogram.getKey())));
					twitterVo.setCount(Long.toString(dateHistogram.getCount()));
					list.add(twitterVo);
				}
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return list;
	}

	
	public ArrayList<TwitterVo> getTweetDetailById(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> list = new ArrayList<TwitterVo>();
		String fileName="";
		try 
		{
			String tweetId=null;
			String subQuery=  "\"query\": {\n"+
					"\"term\": {\n"+
					"\"articleId\": {\n"+
					"\"value\": \""+tweeterActionVo.getTweetId().trim()+"\"\n"+
					"}\n"+
					"}\n"+
					"}\n";

			String query="{\n"
					+subQuery
					+ "}\n";

			System.out.println("getTweetDetailById**********"+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();
			SearchResult result = client.execute(search);
			List<Article_Datacollection_New> testLst = result.getSourceAsObjectList(Article_Datacollection_New.class);

			if(tweeterActionVo.getType().equals("tw")) 
			{
				for(Article_Datacollection_New tweet : testLst)
				{
					fileName=tweet.getArticleMediaCaption()==null?"":tweet.getArticleMediaCaption().trim();
					TwitterVo twitterVo=new TwitterVo();
					twitterVo.setTweetText(tweet.getArticleTitle().trim());
					twitterVo.setTweeterId(tweet.getArticleId());
					twitterVo.setRetweetCount(Integer.toString(tweet.getTweet().getTweetRetweetCount()));
					twitterVo.setFavouritesCount(Integer.toString(tweet.getTweet().getTweetFavouriteCount()));					
					twitterVo.setUserId(tweet.getArticleAuthorId());
					twitterVo.setScreenName(tweet.getTweet().getTweetUser().getTweetUserScreenName());
					twitterVo.setUserName(tweet.getTweet().getTweetUser().getTweetUserName());
					twitterVo.setCreatedAt(CommonUtils.convertUnixTimeToDateDisplayFormat((tweet.getArticlePublishDate())));
					twitterVo.setUserCreatedAt(CommonUtils.convertUnixTimeToDateDisplayFormat((tweet.getTweet().getTweetUser().getTweetUserCreatedTime())));
					twitterVo.setAvatar(tweet.getTweet().getTweetUser().getTweetUserImageUrl());
					twitterVo.setArticleAuthorImage(tweet.getArticleAuthorImage());
					twitterVo.setArticleAuthorImageUrlLocal(tweet.getArticleAuthorImageUrlLocal());
					twitterVo.setArticleAuthorScreenName(tweet.getArticleAuthorScreenName());
					twitterVo.setFollowersCount(Integer.toString(tweet.getTweet().getTweetUser().getTweetUserFollowersCount()));
					twitterVo.setFriendsCount(Integer.toString(tweet.getTweet().getTweetUser().getTweetUserFriendsCount()));
					twitterVo.setStatusesCount(Integer.toString(tweet.getTweet().getTweetUser().getTweetUserStatusCount()));
					twitterVo.setRetweetFlag(tweet.getTweet().isTweetIsRetweetFlag()==true?"1":"0");
					twitterVo.setSentiment(Integer.toString(tweet.getArticleSentiment()));
					twitterVo.setFtpFileUrl(TwitterConstant.getFtpFileUrl()+"ftp/"+fileName);
					twitterVo.setFederateFileUrl(TwitterConstant.getFtpFileUrl()+"federated/"+fileName);
					twitterVo.setName(fileName);
					//twitterVo.setUserCount(tweet.get);
					twitterVo.setArticleMedia(tweet.getArticleMedia());
					twitterVo.setHashCount(tweet.getArticleHashTag()==null?"0":Integer.toString(tweet.getArticleHashTag().size()));
					ArrayList<String> urllst=new ArrayList<String>();
					
					if(tweet.getArticleMedia() !=null)
					{
						ArrayList<Article_Media> lstArtMedias=tweet.getArticleMedia();
						for(Article_Media article_Media : lstArtMedias)
						{
							if(article_Media.getMediaType().equals("url")) 
							{
								urllst.add(article_Media.getMediaUrl());
							}
						}
					}
					
					twitterVo.setLinkCount(Integer.toString(urllst.size()));
					twitterVo.setMentionCount(tweet.getArticleMention()==null?"0":Integer.toString(tweet.getArticleMention().size()));
					twitterVo.setHashtagLst(tweet.getArticleHashTag());
					twitterVo.setUrlLst(urllst);
					twitterVo.setMentionsLst(tweet.getArticleMention());
					String source=tweet.getTweet().getTweetSource()==null?"":tweet.getTweet().getTweetSource();
					
					if(!source.isEmpty())
					{
						Document doc = Jsoup.parse(source);
						Element link = doc.select("a").first();
						source=link.text();
					}
					
					twitterVo.setSource(source);
					twitterVo.setArticleLocation(tweet.getArticleLocation()==null?"":tweet.getArticleLocation());
					twitterVo.setArticleLocationCountry(tweet.getArticleLocationCountry()==null?"":tweet.getArticleLocationCountry());
					twitterVo.setArticleLocationNer(tweet.getArticleLocationNer());
					twitterVo.setTwLanguage(tweet.getArticleLanguage()==null?"":tweet.getArticleLanguage());					
					twitterVo.setArticleLocationNer(tweet.getArticleLocationNer());
					twitterVo.setArticleOrganizationNer(tweet.getArticleOrganizationNer());
					twitterVo.setArticlePersonNer(tweet.getArticlePersonNer());
					
					if(tweet.getTweet().isTweetIsRetweetFlag()==true) 
					{
						tweetId=tweet.getTweet().getTweetRetweetSourceId();
					} 
					else
                    {
						tweetId=tweet.getArticleId();
					}
					list.add(twitterVo);
				}

				if(tweeterActionVo.getTweetIdFlag().trim().equals("1"))   // It is retweet
				{
					subQuery=  "\"query\": {\n"+
							"\"term\": {\n"+
							"\"articleId\": {\n"+
							"\"value\": \""+tweetId+"\"\n"+
							"}\n"+
							"}\n"+
							"}\n";
					query="{\n"
							+subQuery
							+ "}\n";
					
					System.out.println("fetching original Tweet**********"+query);
					search = new Search.Builder(query)
							.addIndex(TwitterConstant.getDbname())
							.addType(TwitterConstant.getTypeName())
							.build();
					
					result = client.execute(search);
					testLst= result.getSourceAsObjectList(Article_Datacollection_New.class);
					for(Article_Datacollection_New tweet : testLst)
					{
						TwitterVo twitterVo=new TwitterVo();
						twitterVo.setUserId(tweet.getArticleAuthorId());
						twitterVo.setScreenName(tweet.getArticleAuthor());
						twitterVo.setUserName(tweet.getTweet().getTweetUser().getTweetUserName());
						twitterVo.setCreatedAt(CommonUtils.convertUnixTimeToDateDisplayFormat((tweet.getArticlePublishDate())));
						twitterVo.setUserCreatedAt(CommonUtils.convertUnixTimeToDateDisplayFormat((tweet.getTweet().getTweetUser().getTweetUserCreatedTime())));
						twitterVo.setAvatar(tweet.getTweet().getTweetUser().getTweetUserImageUrl());
						twitterVo.setArticleAuthorImage(tweet.getTweet().getTweetUser().getTweetUserImageUrl());
						twitterVo.setArticleAuthorImageUrlLocal(tweet.getTweet().getTweetUser().getTweetUserImageUrlLocal());						
						twitterVo.setFavouritesCount(Integer.toString(tweet.getTweet().getTweetUser().getTweetUserFavouriteCount()));
						twitterVo.setFollowersCount(Integer.toString(tweet.getTweet().getTweetUser().getTweetUserFollowersCount()));
						twitterVo.setFriendsCount(Integer.toString(tweet.getTweet().getTweetUser().getTweetUserFriendsCount()));
						twitterVo.setStatusesCount(Integer.toString(tweet.getTweet().getTweetUser().getTweetUserStatusCount()));
						twitterVo.setRetweetFlag(tweet.getTweet().isTweetIsRetweetFlag()==true?"1":"0");
						list.add(twitterVo);
					}
				}

				// All is retweet Users
				{
					subQuery=  "\"query\": {\n"+
							"\"term\": {\n"+
							"\"tweet.tweetRetweetSourceId\": {\n"+
							"\"value\": \""+tweetId+"\"\n"+
							"}\n"+
							"}\n"+
							"}\n";
					query="{\n"
							+subQuery
							+ "}\n";
					
					System.out.println("All Retweet Users**********"+query);				
					search = new Search.Builder(query)
							.addIndex(TwitterConstant.getDbname())
							.addType(TwitterConstant.getTypeName())
							.build();
					result = client.execute(search);
					testLst=    result.getSourceAsObjectList(Article_Datacollection_New.class);

					ArrayList<TwitterVo> twitterVoLst=new ArrayList<TwitterVo>();	     
					for(Article_Datacollection_New tweet : testLst)
					{
						TwitterVo twitterVo=new TwitterVo();
						twitterVo.setUserId(tweet.getArticleAuthorId());
						twitterVo.setScreenName(tweet.getArticleAuthor());
						twitterVo.setUserName(tweet.getTweet().getTweetUser().getTweetUserName());
						twitterVo.setCreatedAt(CommonUtils.convertUnixTimeToDateDisplayFormat((tweet.getArticlePublishDate())));
						twitterVo.setUserCreatedAt(CommonUtils.convertUnixTimeToDateDisplayFormat((tweet.getTweet().getTweetUser().getTweetUserCreatedTime())));
						twitterVo.setAvatar(tweet.getTweet().getTweetUser().getTweetUserImageUrl());
						twitterVo.setArticleAuthorImage(tweet.getTweet().getTweetUser().getTweetUserImageUrl());
						twitterVo.setArticleAuthorImageUrlLocal(tweet.getTweet().getTweetUser().getTweetUserImageUrlLocal());						
						twitterVo.setFavouritesCount(Integer.toString(tweet.getTweet().getTweetUser().getTweetUserFavouriteCount()));
						twitterVo.setFollowersCount(Integer.toString(tweet.getTweet().getTweetUser().getTweetUserFollowersCount()));
						twitterVo.setFriendsCount(Integer.toString(tweet.getTweet().getTweetUser().getTweetUserFriendsCount()));
						twitterVo.setStatusesCount(Integer.toString(tweet.getTweet().getTweetUser().getTweetUserStatusCount()));
						twitterVo.setRetweetFlag(tweet.getTweet().isTweetIsRetweetFlag()==true?"1":"0");
						twitterVoLst.add(twitterVo);
					}
					
					if(twitterVoLst.size()>0)
					{
						TwitterVo twitterVo=new TwitterVo();
						twitterVo.setTwitterVoLst(twitterVoLst);
						list.add(twitterVo);
					}
				}
			}
			else 
			{
				for(Article_Datacollection_New article_Datacollection_New : testLst) 
				{					
					TwitterVo twitterVo=new TwitterVo();
					String link=article_Datacollection_New.getArticleLinkUrl();
					fileName=article_Datacollection_New.getArticleMediaCaption()==null?"":article_Datacollection_New.getArticleMediaCaption().trim();
					
					switch(article_Datacollection_New.getArticleSource()) 
					{
					case "tw":
						link="https://twitter.com/"+article_Datacollection_New.getArticleAuthor()+"/status/"+article_Datacollection_New.getArticleId();
						break;
					case "yt":
						link=article_Datacollection_New.getArticleLinkUrl();
						break;
					case "fb":
						break;
					case "insta":
						break;
					case "dm":
						break;
					case "gp":
						break;
					case "wp":
						break;
					case "tm":
						break;
					case "wb":
						break;
					case "article":
						link=article_Datacollection_New.getArticleLinkUrl();
						break;
					default:
						break;
					}
					twitterVo.setLink(link);
					//twitterVo.setTotalTweetCount(Integer.toString(result.getTotal()));
					twitterVo.setTotalTweetCount(Long.toString(result.getTotal()));
					twitterVo.setArticleId(article_Datacollection_New.getArticleId());
					twitterVo.setArticleAuthor(article_Datacollection_New.getArticleAuthor());
					twitterVo.setArticleAuthorId(article_Datacollection_New.getArticleAuthorId());
					twitterVo.setArticleAuthorImage(article_Datacollection_New.getArticleAuthorImage());
					twitterVo.setArticleAuthorImageUrlLocal(article_Datacollection_New.getArticleAuthorImageUrlLocal());
					twitterVo.setArticleAuthorScreenName(article_Datacollection_New.getArticleAuthorScreenName());
					twitterVo.setArticlePublishDate(CommonUtils.convertUnixTimeToDateDisplayFormat((article_Datacollection_New.getArticlePublishDate())));
					twitterVo.setArticleTitle(article_Datacollection_New.getArticleTitle());
					twitterVo.setArticleSubTitle(article_Datacollection_New.getArticleSubTitle());
					twitterVo.setArticleBigContent(article_Datacollection_New.getArticleBigContent());
					twitterVo.setArticleSentiment(article_Datacollection_New.getArticleSentiment());
					twitterVo.setArticleLinkUrl(article_Datacollection_New.getArticleLinkUrl());
					twitterVo.setArticleBigContent(article_Datacollection_New.getArticleBigContent());
					twitterVo.setFtpFileUrl(TwitterConstant.getFtpFileUrl()+"ftp/"+fileName);
					twitterVo.setFederateFileUrl(TwitterConstant.getFtpFileUrl()+"federated/"+fileName);
					twitterVo.setName(fileName);
					twitterVo.setArticleHashTag(article_Datacollection_New.getArticleHashTag());
					twitterVo.setArticleMention(article_Datacollection_New.getArticleMention());
					twitterVo.setArticleLanguage(article_Datacollection_New.getArticleLanguage());
					twitterVo.setArticleLocation(article_Datacollection_New.getArticleLocation());
					twitterVo.setArticleLocationCountry(article_Datacollection_New.getArticleLocationCountry());
					twitterVo.setArticleLocationCountryCode(article_Datacollection_New.getArticleLocationCountryCode());
					twitterVo.setArticleLocationCity(article_Datacollection_New.getArticleLocationCity());
					twitterVo.setArticleLocationPlace(article_Datacollection_New.getArticleLocationPlace());
					twitterVo.setArticleLocationNer(article_Datacollection_New.getArticleLocationNer());
					twitterVo.setArticleOrganizationNer(article_Datacollection_New.getArticleOrganizationNer());
					twitterVo.setArticlePersonNer(article_Datacollection_New.getArticlePersonNer());
					twitterVo.setInnsightLocalImageUrl(TwitterConstant.getInnsightLocalImageUrl());
					
					twitterVo.setPriority("0");
					if(article_Datacollection_New.getArticleMarked() !=null)
					{
						if(article_Datacollection_New.getArticleMarked().size()>0)
						{
							String user=(String)httpSession.getAttribute(ApplicationConstants.LOGINUSERID);
							if(article_Datacollection_New.getArticleMarked().indexOf(Integer.parseInt(user))>-1)
							{
								twitterVo.setPriority("1");
							}
						}
					}
					
					twitterVo.setTweet(article_Datacollection_New.getTweet());
					twitterVo.setYoutube(article_Datacollection_New.getYoutube());
					twitterVo.setDailymotion(article_Datacollection_New.getDailymotion());
					twitterVo.setInstagram(article_Datacollection_New.getInstagram());
					twitterVo.setFacebook(article_Datacollection_New.getFacebook());
					twitterVo.setWordpress(article_Datacollection_New.getWordpress());
					twitterVo.setBlogger(article_Datacollection_New.getBlogger());
					twitterVo.setArticleSource(article_Datacollection_New.getArticleSource());
					twitterVo.setArticleType(article_Datacollection_New.getArticleType());
					twitterVo.setArticleMedia(article_Datacollection_New.getArticleMedia());
					twitterVo.setArticleComment(article_Datacollection_New.getArticleComment());
					
					list.add(twitterVo);
				}
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		} 
		return list; 
	}
	

	
	public ArrayList<TwitterVo> getUserDetailById(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> list = new ArrayList<TwitterVo>();
		try
		{
			String source="  \"_source\":[\"tweet.tweetUser\"],";
			switch(tweeterActionVo.getType().trim())
			{
			case "tw":
				source="  \"_source\":[\"tweet.tweetUser\"],";
				break;
			case "fb":
				source="  \"_source\":[\"facebook.fbPage\"],";
				break;
			case "dm":
				source="  \"_source\":[\"dailymotion.dmUser\"],";
				break;
			default:
				source="  \"_source\":[\"articleAuthor\",\"articleAuthorId\",\"articleAuthorDescription\",\"articleAuthorImage\"],";
				break;
			}

			String sortQuery=",\"sort\": [\n"+
					"{"+
					"\"articlePublishDate\": {"+
					"\"order\": \"desc\"\n"+
					"}\n"+
					"}\n"+
					"]\n";

			String author=TwitterConstant.getJsonForEsTerm("articleAuthorId","\""+tweeterActionVo.getUserScreenName().trim()+"\"");
			String sourceType=TwitterConstant.getJsonForEsTerm("articleSource","\""+tweeterActionVo.getType().trim()+"\"");

			String subQuery=source+ 
					"\"size\": 1,\n"+
					"\"query\": {\n"+
					"\"bool\": {\n"+
					"\"must\": [{}\n"+
					author+
					sourceType+
					"]\n"+
					"}\n"+
					"}\n";
			String query="{\n"
					+subQuery
					+sortQuery
					+ "}\n";

			System.out.println("userById********** "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();
			SearchResult result = client.execute(search);
			List<Article_Datacollection_New>  testLst=    result.getSourceAsObjectList(Article_Datacollection_New.class);
			for(Article_Datacollection_New article_Datacollection_New : testLst) 
			{
				TwitterVo twitterVo=new TwitterVo();
				switch(tweeterActionVo.getType().trim()) 
				{
				case "tw":
					Article_Tweet_User tw_User = article_Datacollection_New.getTweet().getTweetUser();
					twitterVo.setName(tw_User.getTweetUserName().trim());
					twitterVo.setUserName(tw_User.getTweetUserScreenName().trim());
					twitterVo.setUserId(tw_User.getTweetUserId().trim());
					twitterVo.setUserCreatedAt(CommonUtils.convertUnixTimeToDateDisplayFormat((tw_User.getTweetUserCreatedTime())));
					twitterVo.setAvatar(tw_User.getTweetUserImageUrl().trim());
					twitterVo.setArticleAuthorImageUrlLocal(tw_User.getTweetUserImageUrlLocal());					
					twitterVo.setDescription(tw_User.getTweetUserDescription());
					twitterVo.setFavouritesCount(Integer.toString(tw_User.getTweetUserFavouriteCount()));
					twitterVo.setFollowersCount(Integer.toString(tw_User.getTweetUserFollowersCount()));
					twitterVo.setFriendsCount(Integer.toString(tw_User.getTweetUserFriendsCount()));
					twitterVo.setListedCount(Integer.toString(tw_User.getTweetUserListedCount()));
					twitterVo.setLocation(tw_User.getTweetUserLocation()==null?"":tw_User.getTweetUserLocation());
					twitterVo.setTimeZone(tw_User.getTweetUserTimeZone()==null?"":tw_User.getTweetUserTimeZone());
					twitterVo.setStatusesCount(Integer.toString(tw_User.getTweetUserStatusCount()));
					twitterVo.setUrl(tw_User.getTweetUserUrl()==null?"":tw_User.getTweetUserUrl());
					break;

				case "yt":
					twitterVo.setArticleAuthor(article_Datacollection_New.getArticleAuthor());
					twitterVo.setArticleAuthorId(article_Datacollection_New.getArticleAuthorId());
					twitterVo.setArticleAuthorImage(article_Datacollection_New.getArticleAuthorImage());
					twitterVo.setArticleAuthorImageUrlLocal(article_Datacollection_New.getArticleAuthorImageUrlLocal());
					break;

				case "fb":
					Article_Fb_Page fbPage = article_Datacollection_New.getFacebook().getFbPage();
					twitterVo.setFbPage(fbPage);
					break;

				case "dm":
					Article_DailyMotion_User dmUser = article_Datacollection_New.getDailymotion().getDmUser();
					twitterVo.setDmUser(dmUser);
					break;

				case "insta":
					twitterVo.setArticleAuthor(article_Datacollection_New.getArticleAuthor());
					twitterVo.setArticleAuthorId(article_Datacollection_New.getArticleAuthorId());
					twitterVo.setArticleAuthorImage(article_Datacollection_New.getArticleAuthorImage());
					twitterVo.setArticleAuthorImageUrlLocal(article_Datacollection_New.getArticleAuthorImageUrlLocal());
					break;
				
				case "rss":
					twitterVo.setArticleAuthor(article_Datacollection_New.getArticleAuthor());
					twitterVo.setArticleAuthorId(article_Datacollection_New.getArticleAuthorId());
					twitterVo.setArticleAuthorImage(article_Datacollection_New.getArticleAuthorImage());
					twitterVo.setArticleAuthorImageUrlLocal(article_Datacollection_New.getArticleAuthorImageUrlLocal());
					break;
					
				case "tm":	
					twitterVo.setArticleAuthor(article_Datacollection_New.getArticleAuthor());
					twitterVo.setArticleAuthorId(article_Datacollection_New.getArticleAuthorId());
					twitterVo.setArticleAuthorImage(article_Datacollection_New.getArticleAuthorImage());
					break;

					
				case "wp":	
					twitterVo.setArticleAuthor(article_Datacollection_New.getArticleAuthor());
					twitterVo.setArticleAuthorId(article_Datacollection_New.getArticleAuthorId());
					twitterVo.setArticleAuthorImage(article_Datacollection_New.getArticleAuthorImage());
					twitterVo.setArticleAuthorImageUrlLocal(article_Datacollection_New.getArticleAuthorImageUrlLocal());
					break;
					
				case "linkedin":	
					twitterVo.setArticleAuthor(article_Datacollection_New.getArticleAuthor());
					twitterVo.setArticleAuthorId(article_Datacollection_New.getArticleAuthorId());
					twitterVo.setArticleAuthorImage(article_Datacollection_New.getArticleAuthorImage());
					twitterVo.setArticleAuthorImageUrlLocal(article_Datacollection_New.getArticleAuthorImageUrlLocal());
					twitterVo.setArticleAuthorDescription(article_Datacollection_New.getArticleAuthorDescription());
					break;
										
				default:
					break;
				}
				list.add(twitterVo);
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return list; 
	}

	
	
	public ArrayList<TwitterVo> getRetweetGraph(TweeterActionVo tweeterActionVo) 
	{
		return null;
	}

	
	public ArrayList<TwitterVo> getTweetRetweetCount(TweeterActionVo tweeterActionVo)
	{
		String user=(String)httpSession.getAttribute(ApplicationConstants.LOGIN_USER);
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		//JdbcTemplate jdbcTemplate=new JdbcTemplate(dataSource);
		try
		{
			String query = null;
			query= " SELECT * FROM ((SELECT "+
					"	COUNT(DISTINCT tweet.id) AS totalTweetCount "+
					"	FROM tw_tweet AS tweet "+
					rtnJoinQuery(tweeterActionVo,false,true,false)+
					rtnFilterQuery(tweeterActionVo,6)+
					"	) AS tbl, "+
					"	(SELECT "+
					"	COUNT(DISTINCT tweet.id) AS totalReTweetCount "+
					"	FROM tw_tweet AS tweet "+
					rtnJoinQuery(tweeterActionVo,false,true,false)+
					rtnFilterQuery(tweeterActionVo,7)+
					") AS tbl1) " ;
			System.out.println("getTweetRetweetCount======== "+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setTotalTweetCount(rs.get("totalTweetCount")==null?"":rs.get("totalTweetCount").toString());
				twitterVo.setTotalReTweetCount(rs.get("totalReTweetCount")==null?"":rs.get("totalReTweetCount").toString());
				lst.add(twitterVo);
			}	
			if(log.isInfoEnabled())
			{
				log.info("User Name------>"+user+"    method=========getTweetRetweetCount()  "+"sql============"+query);
			}

		}
		catch(Exception e) 
		{
			log.error("--------- Exception--------", e);
			e.printStackTrace();
		} 
		return lst; 
	}

	
	public void setTweetOperation(TweeterActionVo tweeterActionVo) 
	{

	}

	
	public ArrayList<TwitterVo> getMedia(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> list = new ArrayList<TwitterVo>();
		try 
		{
			int from=0, finalSize=100;
			try 
			{
				if(tweeterActionVo.getNoMedia() != null) 
				{
					finalSize=Integer.parseInt(tweeterActionVo.getNoMedia());
				}
			}
			catch(Exception ex) 
			{
				ex.printStackTrace();
			}
			
			int size = 100;
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getIsRpt()))
			{
				if(CommonUtils.stringNotEmpty(tweeterActionVo.getNoLinks()))
				{
					from=0;
					size=Integer.parseInt(tweeterActionVo.getNoLinks());
				}
			}
			else 
			{
				from=Integer.parseInt(tweeterActionVo.getRowNum())*100;
				size=100;
			}

			String subQuery=rtnFilterQuery(tweeterActionVo, -1);
			String query="{\n"
					+ "    \"from\":"+from+",\n"
					+ "    \"size\":"+size+",\n"
					+subQuery+
					getTweetsSortOrder(tweeterActionVo)
					+ "}\n";
			
			System.out.println("**getMedia()**  "+tweeterActionVo.getMediaType()+"***  "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			List<Article_Datacollection_New> testLst = result.getSourceAsObjectList(Article_Datacollection_New.class);
			System.out.println("Retrun Size : "+testLst.size());			
			
			//String absMediaPath = TwitterConstant.getInnsightImageLocal();
			for(Article_Datacollection_New article_Datacollection_New : testLst) 
			{
				ArrayList<Article_Media> lstMedia=	article_Datacollection_New.getArticleMedia();
				for(Article_Media article_Media : lstMedia) 
				{
					if(tweeterActionVo.getMediaType().equals(article_Media.getMediaType())) 
					{						
						TwitterVo twitterVo=new TwitterVo();
						//String mediaLocalImgName = article_Media.getMediaThumbnailLocal();
						twitterVo.setInnsightImageFlag(TwitterConstant.getInnsightImageFlag());
						twitterVo.setLink(article_Media.getMediaThumbnail());
						//twitterVo.setMediaImageLocal(absMediaPath+mediaLocalImgName);
						twitterVo.setUrl(article_Media.getMediaUrl());
						twitterVo.setMediaLocalImage(article_Media.getMediaThumbnailLocal());						
						twitterVo.setTweeterId(article_Datacollection_New.getArticleId());
						twitterVo.setType(article_Datacollection_New.getArticleSource());
						if(list.size() < finalSize && !linkAlreadyExist(list, article_Media.getMediaThumbnail()))
						{
							list.add(twitterVo);
						}						
					}
				}
			}
			System.out.println("Final Size  : "+list.size());
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return list; 
	}
	
	public boolean linkAlreadyExist(ArrayList<TwitterVo> twitterVoList, String link) 
	{
		boolean alreadyExist = false;	
		for(TwitterVo twitterVo : twitterVoList)
		{
			if(link.equalsIgnoreCase(twitterVo.getLink()))
			{
				alreadyExist = true;
				break;
			}
		}
		return alreadyExist;
	}


	public ArrayList<TwitterVo> getMedia_Url_Domain(TweeterActionVo tweeterActionVo)
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		try
		{
			int size=50;	
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getIsRpt()))
			{
				if(CommonUtils.stringNotEmpty(tweeterActionVo.getNoMedia()))
				{
					size=Integer.parseInt(tweeterActionVo.getNoMedia());
				}
			}
			else
			{
				if(!tweeterActionVo.getIsDashBord().toLowerCase().trim().equals("y"))
				{
					size=Integer.parseInt(tweeterActionVo.getRowNum())*50;
				}
				else
				{
					size=18;
				}
			}

			String sortQuery=TwitterConstant.getSortForEsTermAgg(tweeterActionVo.getImageSortOrder().toLowerCase().trim());
			String linkType="image";
			if(tweeterActionVo.getMediaType().equals("i"))
			{
				linkType="image";	
			}
			else 
			{
				linkType="video";
			}
			String subQuery=rtnFilterQuery(tweeterActionVo,-1);
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"termagg\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\""+linkType+"\"\n,"+
					"\"size\":\""+size+"\"\n,"+
					sortQuery+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";

			System.out.println("linkType =="+query);
			Search search = new Search.Builder(""+query)
					// multiple index or types can be added.
					.addIndex(TwitterConstant.getDbname())
					.addType("tw_tweet")
					.build();

			SearchResult result = client.execute(search);
			TermsAggregation terms = result.getAggregations().getTermsAggregation("termagg");
			List<Entry>  entry=  terms.getBuckets();
			for(Entry entry2 : entry) 
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setLink(entry2.getKey());
				twitterVo.setLinkCount(Long.toString(entry2.getCount()));
				twitterVo.setUrl(entry2.getKey());
				twitterVo.setTweeterId(entry2.getKey());
				lst.add(twitterVo);
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return lst; 
	} 
	
	//**************************Custom Function
	public String rtnJoinQuery(TweeterActionVo tweeterActionVo,Boolean hasUser,Boolean lnkJoin,Boolean isUser)
	{
		return "";
	}

	
	public String rtnFilterQuery(TweeterActionVo tweeterActionVo, int type) 
	{
		Long dateFrom=0L;
		Long dateTo=0L;
		String entityId="";
		String dateFilter="";
		String dateTypeFilter="";
		String userFilter="";
		String userNotFilter="";
		String userIdFilter="";
		String joinQuery="";
		String timeZoneFilter="";
		String timeZoneNotFilter="";
		String hashTagFilter="";
		String hashTagNotFilter="";
		String themeFilter="";
		String themeNotFilter="";
		String mentionFilter="";
		String mentionNotFilter="";
		String domainFilter="";
		String domainNotFilter="";
		String urlFilter="";
		String urlNotFilter="";
		String advFilter="";
		String keywordFilter="";
		String keywordFilter1="";
		String tweetFlagFilter="";
		String mediaTypeFilter="";
		String sentimentFilter="";
		String sentimentNotFilter=""; 
		String latitudeFilter="";
		String priorityFilter="";
		String countryCodeFilter="";
		String tweetIdFilter="";
		String sourceFilter="";
		String placeFilter="";
		String placeNotFilter="";
		String personFilter="";
		String personNotFilter="";
		String orgFilter="";
		String orgNotFilter="";
		String mediaFilter="";
		String imgFilter="";
		String imgNotFilter=""; 
		String videoFilter="";
		String videoNotFilter="";
		String audioFilter="";
		String audioNotFilter="";
		String groupFilter="";
		String groupNotFilter="";
		String viralTextFilter="";
		String viralTextNotFilter="";
		String docTypeFilter="";
		String docTypeNotFilter="";
	
		String phoneNo="";  
		String wtGroupNo="";
		String contactNo="";		
		String msgwtReceiver="";				
		String twUserCountryCode="";
		String geoSearch=""; 
		String geoPolygonFilter="";
		String geoPolygonNotFilter="";
		String geoUserPolygonFilter="";
		String geoUserPolygonNotFilter="";
		String componentFilter="";	
		String componentTweetFilter="";	
		String isComponentFilter="";
		String classificationFilter="";
		String classificationNotFilter="";
		String threatClassificationFilter="";
	    String threatClassificationNotFilter="";
		String emotionFilter="";
		String emotionNotFilter="";
		String langFilter="";
		String langNotFilter="";
		String cityFilter="";
		String cityNotFilter="";
		String countryFilter="";
		String countryNotFilter="";
		String nerDateFilter="";
		String nerDateNotFilter="";
		String mobileFilter="";
		String mobileNotFilter=""; 
		String emailFilter="";
		String emailNotFilter="";
		String userCreatedDate="";
		String globalProfileFilter="";
		String globalProfileFilterLinkAnalysis="";
		String globalKeywordFilter="";
		String globalLocationFilter="";
		String globalFilter="";
		String userSearch="";
		String rssCountryCodeFilter="";
		String eventFilter="";
		String eventNotFilter="";
		String taxonomyFilter="";
		String taxonomyNotFilter="";
		String authorCountryFilter="";
		String authorCountryNotFilter="";
		String authorCityFilter="";
		String authorCityNotFilter="";		
		String articleNewsSource="";
		String articleNewsWebsite="";
		String articleNewsFTP="";
		String articleNewsFederated="";
		String wordCloudNotFilter="";
		String articleIdFilter="";
		String articleTitleHashFilter="";
		String articlePriority="";

		String retweetedUserFilter="";
		String retweetedUserNotFilter="";
        String articleNewsCategory="";
        String articleNewsOtherCategory="";
        String twUserTypeFilter="";
        String fbUserProfileFilter="";
        String exactMatchKeyword="";
        
		try 
		{					
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getExactKeywordFilter()))
			{
				exactMatchKeyword= TwitterConstant.getJsonForEsMatchPhrase(tweeterActionVo.getExactKeywordFilter());
			}
						
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getUserSearchKeyword()))
			{
				userSearch= TwitterConstant.getJsonForEsQueryStringWithOutField(TwitterConstant.searchUserByKeyword(tweeterActionVo.getUserSearchKeyword()));
			}

			if(tweeterActionVo.getProfileGlobalFilter() != null && tweeterActionVo.getProfileGlobalFilter().size() > 0) 
			{
				globalProfileFilter = TwitterConstant.getJsonForEsQueryStringWithOutField(TwitterConstant.getGlobalProfileFilter(tweeterActionVo.getProfileGlobalFilter()));
			}
			
			if(tweeterActionVo.getProfileGlobalFilterLinkAnalysis() != null && tweeterActionVo.getProfileGlobalFilterLinkAnalysis().size() > 0) 
			{
				globalProfileFilterLinkAnalysis = TwitterConstant.getJsonForEsQueryStringWithOutField(TwitterConstant.getGlobalProfileFilterForLinkAnalysis(tweeterActionVo.getProfileGlobalFilterLinkAnalysis()));
			}

		  /*if(tweeterActionVo.getKeywordGlobalFilter().size()>0)
			{
				globalKeywordFilter= TwitterConstant.getJsonForEsQueryString("",TwitterConstant.getGlobalKeywordFilter(tweeterActionVo.getKeywordGlobalFilter()));
			}
		  */
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getKeywordFilter()))  //Search By Keyword
			{					
				keywordFilter = TwitterConstant.getJsonForEsQueryStringCustomType("articleTitle", tweeterActionVo.getKeywordFilter().trim(), tweeterActionVo.getSearchType().trim());
			}

			if(CommonUtils.stringNotEmpty(tweeterActionVo.getGeoDistance())
					&& CommonUtils.stringNotEmpty(tweeterActionVo.getGeoPoint())
					)  //Geo Circle Query
			{
				/*
				ArrayList<ArrayList<LocationPoints>> lst = new ArrayList<>();
				for(String string : tweeterActionVo.getLocationGlobalFilter())
				{
					ArrayList<LocationPoints> lstLocationPoints = new ArrayList<>(); 

					String[] arr = string.split(",");
					LocationPoints locationPoints = new LocationPoints();
					locationPoints.setLat( Double.parseDouble(arr[2]));
					locationPoints.setLng(Double.parseDouble(arr[1]));
					lstLocationPoints.add(locationPoints);

					locationPoints=new LocationPoints();
					locationPoints.setLat(Double.parseDouble(arr[2]));
					locationPoints.setLng(Double.parseDouble(arr[3]));
					lstLocationPoints.add(locationPoints);

					locationPoints=new LocationPoints();
					locationPoints.setLat(Double.parseDouble(arr[0]));
					locationPoints.setLng(Double.parseDouble(arr[3]));
					lstLocationPoints.add(locationPoints);

					locationPoints=new LocationPoints();
					locationPoints.setLat(Double.parseDouble(arr[0]));
					locationPoints.setLng(Double.parseDouble(arr[1]));
					lstLocationPoints.add(locationPoints);
					lst.add(lstLocationPoints);
				} */
				//globalLocationFilter = TwitterConstant.getJsonForEsPolygon(lst, "articleLocation");
			String[] cordinates=tweeterActionVo.getGeoPoint().split(",");
			String lat=cordinates[0];
			String lon=cordinates[1];
				
			globalLocationFilter=TwitterConstant.getJsonForEsGeoDistance(tweeterActionVo.getGeoDistance(),"articleLocation",lat,lon);
			
			}

			//ARTICLE SOURCE FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getRssCountryCode()))  //Multiple RssCountryCode
			{
				String[] userArr=tweeterActionVo.getRssCountryCode().split(",");
				String userToFilter="";
				for(String user : userArr) 
				{
					userToFilter+="\""+user.trim()+"\",";
				}
				userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				rssCountryCodeFilter= TwitterConstant.getJsonForEs("rssCountryCode", userToFilter);
			}
								
			//ARTICLE News Catyegory			
            if(CommonUtils.stringNotEmpty(tweeterActionVo.getArticleNewsCategory()))  //Multiple News Source
			{
				String[] userArr=tweeterActionVo.getArticleNewsCategory().split(",");
				String userToFilter="";
				for(String user : userArr) 
				{
					userToFilter+="\""+user.trim()+"\",";
				}
				userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				
				if(tweeterActionVo.getArticleNewsCategory().equals("main_news"))
				{
					articleNewsCategory= TwitterConstant.getJsonForEs("articleNewsCategory", userToFilter);
				}
				else
				{				
					articleNewsOtherCategory = TwitterConstant.getJsonForEs("articleNewsCategory", "\"main_news\""); 
				}				
			}
			
			//ARTICLE News Source
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getArticleNewsSource()))  //Multiple News Source
			{
				String[] userArr=tweeterActionVo.getArticleNewsSource().split(",");
				String userToFilter="";
				for(String user : userArr) 
				{
					userToFilter+="\""+user.trim()+"\",";
				}
				userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				articleNewsSource= TwitterConstant.getJsonForEs("articleNewsSource", userToFilter);
			}

			//ARTICLE News Website
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getArticleNewsWebsite()))  //Multiple News Website
			{
				String[] userArr=tweeterActionVo.getArticleNewsWebsite().split(",");
				String userToFilter="";
				for(String user : userArr) 
				{
					userToFilter+="\""+user.trim()+"\",";
				}
				userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				articleNewsWebsite= TwitterConstant.getJsonForEs("articleNewsSource", userToFilter);
			}
			
			//ARTICLE News FTP
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getArticleNewsFTP()))  //Multiple News FTP
			{
				String[] userArr=tweeterActionVo.getArticleNewsFTP().split(",");
				String userToFilter="";
				for(String user : userArr) 
				{
					userToFilter+="\""+user.trim()+"\",";
				}
				userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				articleNewsFTP= TwitterConstant.getJsonForEs("articleNewsSource", userToFilter);
			}
			
			
			//ARTICLE News FEDERATED
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getArticleNewsFederated()))  //Multiple News FEDERATED
			{
				String[] userArr=tweeterActionVo.getArticleNewsFederated().split(",");
				String userToFilter="";
				for(String user : userArr) 
				{
					userToFilter+="\""+user.trim()+"\",";
				}
				userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				articleNewsFederated= TwitterConstant.getJsonForEs("keywordIds", userToFilter);
			}
			
			//ARTICLE SOURCE 
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getSourceFilter()))  //Multiple Source Filter
			{
				ArrayList<String> lstSource=new ArrayList<>();
				if(tweeterActionVo.getProfileGlobalFilter() != null && tweeterActionVo.getProfileGlobalFilter().size() > 0) 
				{
					for(Map<String, String> map :  tweeterActionVo.getProfileGlobalFilter()) 
					{
						String sourceType=map.values().toArray()[1].toString();		
						if(!lstSource.contains(sourceType.toLowerCase()))
						{
						   lstSource.add(sourceType.toLowerCase().trim());
						}
					}
					String userToFilter="";
					for(String user : lstSource) 
					{
						userToFilter+="\""+user.trim()+"\",";
					}
					if(userToFilter.length()>0)
					{
					   userToFilter=userToFilter.substring(0, userToFilter.length()-1);
					   sourceFilter = TwitterConstant.getJsonForEs("articleSource", userToFilter);
					}
				}
				else
				{
				
				String[] userArr=tweeterActionVo.getSourceFilter().split(",");
				String userToFilter="";
				for(String user : userArr) 
				{
					/*if(lstSource.size()>0)
					{
						if(lstSource.contains(user))
						{
							userToFilter+="\""+user.trim()+"\",";
						}
					}
					else
					{*/
				     	userToFilter+="\""+user.trim()+"\",";
					//}
				}
				
				System.out.println("userToFilter:------------ "+userToFilter);
				if(userToFilter.length()>0)
				{
				   userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				   sourceFilter = TwitterConstant.getJsonForEs("articleSource", userToFilter);
				}
				}
			}
			
			
			
			//if(!globalProfileFilter.isEmpty() || !keywordFilter.isEmpty() || !globalLocationFilter.isEmpty())
			{
				switch(tweeterActionVo.getProfileBool().toLowerCase())
				{
				case "and":
					globalFilter="\n,{\n\"bool\":\n{"+
							"\"must\":[\n{}\n" +globalProfileFilter + 
							globalLocationFilter + 
							rssCountryCodeFilter +
							"\n]\n"
							+ "}\n}\n";
					break;

				case "or":
					globalFilter="\n,{\n\"bool\":\n{"+
							"\"should\":[\n{}\n"  ;
					
							//globalLocationFilter ;
							if(!globalProfileFilter.trim().isEmpty())
							{
								globalFilter+="\n,{\n\"bool\":\n{"+
										"\"must\":[\n{}"
										+globalProfileFilter
										+globalLocationFilter
										+sourceFilter
										+ "\n]}}";
								
							}
							else
							{
								if(!globalLocationFilter.trim().isEmpty())
								{
									globalFilter+="\n,{\n\"bool\":\n{"+
											"\"must\":[\n{}"
											+globalLocationFilter 
											+sourceFilter
											+ "\n]}}";
								}
								else
								{
									globalFilter += sourceFilter;
								}
							}

					        globalFilter+=rssCountryCodeFilter +														
							articleNewsSource + 
							articleNewsWebsite + 
							articleNewsFTP + 
							articleNewsFederated + "\n]\n"
							+ "}\n}\n";
					break;
				}
			}			
			
			//*************Only For Target Views**********
			String targetView="";
			if(tweeterActionVo.getIsView().equals("y"))
			{				
				globalFilter="";
					targetView="\n,{\n\"bool\":\n{"+
					"\"should\":[\n{}\n"  +
					keywordFilter + 
					globalProfileFilter+
					"\n]\n"
					+ "}\n}\n";
			
				keywordFilter="";
				globalProfileFilter="";
			}
			
			
			if(type!=5) //TimeLineGraph
			{

				boolean dateFlag = false;
				if(CommonUtils.stringNotEmpty(tweeterActionVo.getDateFromGrph()) &&	CommonUtils.stringNotEmpty(tweeterActionVo.getDateToGrph()))  
				{
					dateFlag=true;
					dateFrom=TwitterConstant.convertDateToTimeStamp(tweeterActionVo.getDateFromGrph());
					dateTo=TwitterConstant.convertDateToTimeStamp(tweeterActionVo.getDateToGrph());
				}
				else if(CommonUtils.stringNotEmpty(tweeterActionVo.getDateFrom()) && CommonUtils.stringNotEmpty(tweeterActionVo.getDateTo()))  
				{
					dateFlag=true;
					dateFrom=TwitterConstant.convertDateToTimeStamp(tweeterActionVo.getDateFrom());
					dateTo=TwitterConstant.convertDateToTimeStamp(tweeterActionVo.getDateTo());
				}

				if(dateFlag)
				{	
					//dateFrom = dateFrom + 19800000l;
					if(CommonUtils.stringNotEmpty(tweeterActionVo.getDateTypeFilter()))
					{
						dateTypeFilter=tweeterActionVo.getDateTypeFilter();
						if(dateTypeFilter.equalsIgnoreCase("publishedDate"))
						{
							dateFilter=	",{\n"+
									"\"range\": {\n"+
									"\"articlePublishDate\": {\n"+
									"\"gte\": "+dateFrom+",\n"+
									"\"lte\": "+dateTo+"\n"+
									"}\n"+
									"}\n"+ 
									"}\n";
						}
						else if(dateTypeFilter.equalsIgnoreCase("insertDate"))
						{
							dateFilter=	",{\n"+
									"\"range\": {\n"+
									"\"articleInsertedDate\": {\n"+
									"\"gte\": "+dateFrom+",\n"+
									"\"lte\": "+dateTo+"\n"+
									"}\n"+
									"}\n"+ 
									"}\n";
						}
					}
					else
					{
						dateFilter=	",{\n"+
								"\"range\": {\n"+
								"\"articlePublishDate\": {\n"+
								"\"gte\": "+dateFrom+",\n"+
								"\"lte\": "+dateTo+"\n"+
								"}\n"+
								"}\n"+ 
								"}\n";
					}
				}
			}

			if(CommonUtils.stringNotEmpty(tweeterActionVo.getUserFilter1()))  //Multiple UserName Report
			{
				String[] userArr = tweeterActionVo.getUserFilter1().split(",");
				String userToFilter="";
				for(String user : userArr) 
				{
					userToFilter+="\""+user.trim()+"\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length()-1);
				userIdFilter = TwitterConstant.getJsonForEs("articleAuthorId", userToFilter);
			}

			if(CommonUtils.stringNotEmpty(tweeterActionVo.getUserIdFilter()))  //Multiple UserName Id Report
			{
				String[] userArr=tweeterActionVo.getUserIdFilter().split(",");
				String userToFilter="";
				for(String user : userArr)
				{
					userToFilter+="\""+user.trim()+"\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length()-1);
				userIdFilter = TwitterConstant.getJsonForEs("articleAuthorId", userToFilter);
			}			
			
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getFbUserProfileFilter()))  //Facebook Profile Report
			{
			
				
				String[] userArr=tweeterActionVo.getFbUserProfileFilter().split(",");
				String userToFilter="";
				for(String user : userArr)
				{
					userToFilter+="\""+user.trim()+"\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length()-1);
				//fbUserProfileFilter = TwitterConstant.getJsonForEs("facebook.fbPostPageId", userToFilter);
				fbUserProfileFilter = TwitterConstant.getJsonForEs("articleAuthorId", userToFilter);		
			}

			if(CommonUtils.stringNotEmpty(tweeterActionVo.getUserFilter()))  //Multiple UserName
			{
				String[] userArr=tweeterActionVo.getUserFilter().split(",");
				String userToFilter="";
				for(String user : userArr) 
				{
					userToFilter+=" articleAuthor:"+user.trim()+" OR articleAuthorId:"+user.trim()+" OR";
				}
				
				userToFilter=userToFilter.substring(0, userToFilter.length()-2);
				//userToFilter=userToFilter+"";
				//userFilter=  TwitterConstant.getJsonForEs("articleAuthor",userToFilter);
				userFilter=TwitterConstant.getJsonForEsQueryStringWithOutField(userToFilter);
			}

			if(CommonUtils.stringNotEmpty(tweeterActionVo.getUserNotFilter()))  //Multiple UserName Not
			{
				String[] userArr=tweeterActionVo.getUserNotFilter().split(",");
				String userToFilter="";
				for(String user : userArr) 
				{
					userToFilter+=" articleAuthor:"+user.trim()+" OR articleAuthorId:"+user.trim()+" OR";
				}
				
				userToFilter=userToFilter.substring(0, userToFilter.length()-2);
				userNotFilter=TwitterConstant.getJsonForEsQueryStringWithOutField(userToFilter);
				
				}

			
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getRetweetUserFilter()))  //Multiple Retweeted User UserName
			{
				String[] userArr=tweeterActionVo.getRetweetUserFilter().split(",");
				String userToFilter="";
				for(String user : userArr) 
				{
					userToFilter+="\""+user.trim()+"\",";
				}
				userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				retweetedUserFilter=  TwitterConstant.getJsonForEs("tweet.tweetRetweetUserScreenName",userToFilter);
			}

			if(CommonUtils.stringNotEmpty(tweeterActionVo.getRetweetUserNotFilter()))  //Multiple Retweeted User Not
			{
				String[] userArr=tweeterActionVo.getRetweetUserNotFilter().split(",");
				String userToFilter="";
				for(String user : userArr) 
				{
					userToFilter+="\""+user.trim()+"\",";
				}
				userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				retweetedUserNotFilter=  TwitterConstant.getJsonForEs("tweet.tweetRetweetUserScreenName",userToFilter);
			}

			if(CommonUtils.stringNotEmpty(tweeterActionVo.getTimeZoneFilter()))  //Multiple TimeZone Filter
			{
				String[] userArr=tweeterActionVo.getTimeZoneFilter().split(",");
				String userToFilter="";
				for(String user : userArr) 
				{
					userToFilter+="\""+user.trim()+"\",";
				}
				userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				timeZoneFilter=  TwitterConstant.getJsonForEs("user.timeZone",userToFilter);
			}

			if(CommonUtils.stringNotEmpty(tweeterActionVo.getTimeZoneNotFilter()))  //Multiple TimeZone Not Filter
			{
				String[] userArr=tweeterActionVo.getTimeZoneNotFilter().split(",");
				String userToFilter="";
				for(String user : userArr) 
				{
					userToFilter+="\""+user.trim()+"\",";
				}
				userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				timeZoneNotFilter=  TwitterConstant.getJsonForEs("user.timeZone",userToFilter);
			}

			//HASHTAG FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getHashTagFilter()))  //Multiple Hashtag
			{
				String[] userArr=tweeterActionVo.getHashTagFilter().split(",");
				String userToFilter="";
				for(String user : userArr)
				{
					userToFilter+="\""+user.trim().substring(1)+"\",";
				}
				userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				hashTagFilter=  TwitterConstant.getJsonForEs("articleHashTag",userToFilter);
			}

			//HASHTAG NOT FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getHashTagNotFilter()))  //Multiple Hashtag Not
			{
				String[] userArr=tweeterActionVo.getHashTagNotFilter().split(",");
				String userToFilter="";
				for(String user : userArr) 
				{
					userToFilter+="\""+user.trim().substring(1)+"\",";
				}
				userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				hashTagNotFilter=  TwitterConstant.getJsonForEs("articleHashTag",userToFilter);
			}

			//PHONE FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getMobileFilter()))  //Multiple Phone
			{
				String[] userArr=tweeterActionVo.getMobileFilter().split(",");
				String userToFilter="";
				for(String user : userArr) 
				{
					userToFilter+="\""+user.trim()+"\",";
				}
				userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				mobileFilter=  TwitterConstant.getJsonForEs("articleMobile",userToFilter);
			}

			//PHONE NOT FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getMobileNotFilter()))  //Multiple Phone Not
			{
				String[] userArr=tweeterActionVo.getMobileNotFilter().split(",");
				String userToFilter="";
				for(String user : userArr) 
				{
					userToFilter+="\""+user.trim()+"\",";
				}
				userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				mobileNotFilter=  TwitterConstant.getJsonForEs("articleMobile",userToFilter);
			}

			//EVENT FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getEventFilter()))  //Multiple Event
			{
				String[] userArr = tweeterActionVo.getEventFilter().split(",");
				String userToFilter="";
				for(String user : userArr) 
				{
					userToFilter+="\""+user.trim()+"\",";
				}
				userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				eventFilter = TwitterConstant.getJsonForEs("articleEvent.keyword", userToFilter);
			}

			//EVENT NOT FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getEventNotFilter()))  //Multiple Event Not
			{
				String[] userArr=tweeterActionVo.getEventNotFilter().split(",");
				String userToFilter="";
				for(String user : userArr) 
				{
					userToFilter+="\""+user.trim()+"\",";
				}
				userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				eventNotFilter = TwitterConstant.getJsonForEs("articleEvent.keyword", userToFilter);
			}

			//TAXONOMY FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getTaxonomyFilter()))  //Multiple Taxonomy
			{
				String[] userArr = tweeterActionVo.getTaxonomyFilter().split(",");
				String userToFilter="";
				for(String user : userArr) 
				{
					userToFilter+="\""+user.trim()+"\",";
				}
				userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				taxonomyFilter = TwitterConstant.getJsonForEs("taxonomy", userToFilter);
			}

			//TAXONOMY NOT FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getTaxonomyNotFilter()))  //Multiple Taxonomy Not
			{
				String[] userArr=tweeterActionVo.getTaxonomyNotFilter().split(",");
				String userToFilter="";
				for(String user : userArr) 
				{
					userToFilter+="\""+user.trim()+"\",";
				}
				userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				taxonomyNotFilter = TwitterConstant.getJsonForEs("taxonomy", userToFilter);
			}

			//AUTHOR COUNTRY FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getAuthorCountryFilter()))  //Multiple Author Country
			{
				String[] userArr = tweeterActionVo.getAuthorCountryFilter().split("&&&");
				String userToFilter="";
				for(String user : userArr) 
				{
					userToFilter+="\""+user.trim()+"\",";
				}
				userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				authorCountryFilter = TwitterConstant.getJsonForEs("tweet.tweetUser.tweetUserLocation", userToFilter);
			}

			//AUTHOR COUNTRY NOT FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getAuthorCountryNotFilter()))  //Multiple Author Country Not
			{
				String[] userArr = tweeterActionVo.getAuthorCountryNotFilter().split("&&&");
				String userToFilter="";
				for(String user : userArr) 
				{
					userToFilter+="\""+user.trim()+"\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length()-1);
				authorCountryNotFilter = TwitterConstant.getJsonForEs("tweet.tweetUser.tweetUserLocation", userToFilter);
			}

			//AUTHOR CITY FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getAuthorCityFilter()))  //Multiple Author City
			{
				String[] userArr = tweeterActionVo.getAuthorCityFilter().split(",");
				String userToFilter="";
				for(String user : userArr) 
				{
					userToFilter+="\""+user.trim()+"\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length()-1);
				authorCityFilter = TwitterConstant.getJsonForEs("tweet.tweetUser.tweetUserLocation", userToFilter);
			}

			//AUTHOR CITY NOT FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getAuthorCityNotFilter()))  //Multiple Author City Not
			{
				String[] userArr = tweeterActionVo.getAuthorCityNotFilter().split(",");
				String userToFilter="";
				for(String user : userArr) 
				{
					userToFilter+="\""+user.trim()+"\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length()-1);
				authorCityNotFilter = TwitterConstant.getJsonForEs("tweet.tweetUser.tweetUserLocation", userToFilter);
			}

			//EMAIL FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getEmailFilter()))  //Multiple Email
			{
				String[] userArr=tweeterActionVo.getEmailFilter().split(",");
				String userToFilter="";
				for(String user : userArr) 
				{
					userToFilter+="\""+user.trim()+"\",";
				}
				userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				emailFilter=  TwitterConstant.getJsonForEs("articleEmail",userToFilter);
			}

			//EMAIL NOT FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getEmailNotFilter()))  //Multiple Email Not
			{
				String[] userArr=tweeterActionVo.getEmailNotFilter().split(",");
				String userToFilter="";
				for(String user : userArr) 
				{
					userToFilter+="\""+user.trim()+"\",";
				}
				userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				emailNotFilter=  TwitterConstant.getJsonForEs("articleEmail",userToFilter);
			}

			//THEMES FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getThemeFilter()))  //Multiple Theme
			{
				String[] userArr=tweeterActionVo.getThemeFilter().split(",");
				String userToFilter="";
				for(String user : userArr)
				{
					userToFilter+="\""+user.trim()+"\",";
				}
				userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				themeFilter=  TwitterConstant.getJsonForEs("articleThemes",userToFilter);
			}

			//THEMES NOT FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getThemeNotFilter()))  //Multiple Theme Not
			{
				String[] userArr=tweeterActionVo.getThemeNotFilter().split(",");
				String userToFilter="";
				for(String user : userArr) 
				{
					userToFilter+="\""+user.trim()+"\",";
				}
				userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				themeNotFilter = TwitterConstant.getJsonForEs("articleThemes",userToFilter);
			}

			//IMAGE FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getImgFilter()))  //Multiple Image
			{				
				String[] userArr=tweeterActionVo.getImgFilter().split(",");
				String userToFilter="";
				for(String user : userArr) 
				{
					userToFilter+="\""+user.trim()+"\",";
				}
				userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				//imgFilter = TwitterConstant.getJsonForEs("articleMedia.mediaUrl",userToFilter);
				imgFilter = TwitterConstant.getJsonForEs("articleMedia.mediaThumbnail",userToFilter);
			}

			//IMAGE NOT FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getImgNotFilter()))  //Multiple Image not 
			{				
				String[] userArr=tweeterActionVo.getImgNotFilter().split(",");
				String userToFilter="";
				for(String user : userArr) 
				{
					userToFilter+="\""+user.trim()+"\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length()-1);
				//imgNotFilter = TwitterConstant.getJsonForEs("articleMedia.mediaUrl",userToFilter);
				imgNotFilter = TwitterConstant.getJsonForEs("articleMedia.mediaThumbnail", userToFilter);
			}

			//VIDEO FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getVideoFilter()))  //Multiple Video
			{
				String[] userArr=tweeterActionVo.getVideoFilter().split(",");
				String userToFilter="";
				for(String user : userArr)
				{
					userToFilter+="\""+user.trim()+"\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length()-1);
				//videoFilter = TwitterConstant.getJsonForEs("articleMedia.mediaUrl",userToFilter);
				videoFilter = TwitterConstant.getJsonForEs("articleMedia.mediaThumbnail",userToFilter);
			}

			//VIDEO NOT FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getVideoNotFilter()))  //Multiple Video not 
			{
				String[] userArr=tweeterActionVo.getVideoNotFilter().split(",");
				String userToFilter="";
				for(String user : userArr) 
				{
					userToFilter+="\""+user.trim()+"\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length()-1);
				//videoNotFilter = TwitterConstant.getJsonForEs("articleMedia.mediaUrl",userToFilter);
				videoNotFilter = TwitterConstant.getJsonForEs("articleMedia.mediaThumbnail",userToFilter);
			}
			
						
			
			//PERSON FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getPersonFilter()))  //Multiple Person
			{  
				String[] userArr=tweeterActionVo.getPersonFilter().split(",");
				String userToFilter="";
				for(String user : userArr) 
				{
					userToFilter+="\""+user.trim()+"\",";
				}
				if(userToFilter.length() > 0)	
					userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				personFilter = TwitterConstant.getJsonForEsNested("articlePersonNer", "articlePersonNer.keyword", userToFilter);
			}

			//PERSON NOT FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getPersonNotFilter()))  //Multiple Person Not
			{
				String[] userArr=tweeterActionVo.getPersonNotFilter().split(",");
				String userToFilter="";
				for(String user : userArr)
				{
					userToFilter+="\""+user.trim()+"\",";
				}
				userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				personNotFilter= TwitterConstant.getJsonForEsNested("articlePersonNer", "articlePersonNer.keyword", userToFilter);
			}

			//DATE FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getNerDateFilter()))  //Multiple NerDate calender
			{
				String[] userArr=tweeterActionVo.getNerDateFilter().split(",");
				String userToFilter="";
				for(String user : userArr) 
				{
					userToFilter+="\""+user.trim()+"\",";
				}
				userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				//nerDateFilter= TwitterConstant.getJsonForEsNested("articleDateNer", "articleDateNer.keyword", userToFilter);
				nerDateFilter= TwitterConstant.getJsonForEs("articleDateNer.keyword", userToFilter);
				
			}

			//DATE NOT FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getNerDateNotFilter()))  //Multiple NerDate calender Not
			{
				String[] userArr=tweeterActionVo.getNerDateNotFilter().split(",");
				String userToFilter="";
				for(String user : userArr) 
				{
					userToFilter+="\""+user.trim()+"\",";
				}
				userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				//nerDateNotFilter= TwitterConstant.getJsonForEsNested("articleDateNer", "articleDateNer.keyword", userToFilter);
				nerDateNotFilter= TwitterConstant.getJsonForEs("articleDateNer.keyword", userToFilter);
			}

			//PLACE FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getLocationFilter()))  //Multiple Place
			{
				String[] userArr=tweeterActionVo.getLocationFilter().split(",");
				String userToFilter="";
				for(String user : userArr)
				{
					userToFilter+="\""+user.trim()+"\",";
				}
				userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				placeFilter= TwitterConstant.getJsonForEsNested("articleLocationNer", "articleLocationNer.keyword", userToFilter);
			}

			//PLACE NOT FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getLocationNotFilter()))  //Multiple Place Not
			{
				String[] userArr=tweeterActionVo.getLocationNotFilter().split(",");
				String userToFilter="";
				for(String user : userArr) 
				{
					userToFilter+="\""+user.trim()+"\",";
				}
				userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				placeNotFilter= TwitterConstant.getJsonForEsNested("articleLocationNer", "articleLocationNer.keyword", userToFilter);
			}

			//ORGANIZATION FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getOrgFilter()))  //Multiple Organization
			{
				String[] userArr=tweeterActionVo.getOrgFilter().split(",");
				String userToFilter="";
				for(String user : userArr)
				{
					userToFilter+="\""+user.trim()+"\",";
				}
				userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				orgFilter= TwitterConstant.getJsonForEsNested("articleOrganizationNer", "articleOrganizationNer.keyword", userToFilter);
			}

			//ORGANIZATION NOT FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getOrgNotFilter()))  //Multiple Organization Not
			{
				String[] userArr=tweeterActionVo.getOrgNotFilter().split(",");
				String userToFilter="";
				for(String user : userArr)
				{
					userToFilter+="\""+user.trim()+"\",";
				}
				userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				orgNotFilter= TwitterConstant.getJsonForEsNested("articleOrganizationNer", "articleOrganizationNer.keyword", userToFilter);
			}

			//MENTIONS FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getMentionFilter()))  //Multiple Mentions
			{
				String[] userArr=tweeterActionVo.getMentionFilter().split(",");
				String userToFilter="";
				for(String user : userArr)
				{
					userToFilter+="\""+user.trim().substring(1)+"\",";
				}
				userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				mentionFilter= TwitterConstant.getJsonForEs("articleMention", userToFilter);
			}

			//MENTIONS NOT FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getMentionNotFilter()))  //Multiple Mentions Not
			{
				String[] userArr=tweeterActionVo.getMentionNotFilter().split(",");
				String userToFilter="";
				for(String user : userArr) 
				{ 
					userToFilter+="\""+user.trim().substring(1)+"\",";   
				}  
				userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				mentionNotFilter= TwitterConstant.getJsonForEs("articleMention",userToFilter);
			}

			//LANGUAGE FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getLangFilter()))  //Multiple Language
			{
				String[] userArr=tweeterActionVo.getLangFilter().split(",");
				String userToFilter="";
				for(String user : userArr)
				{
					userToFilter+="\""+user.trim()+"\",";
				}
				userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				langFilter= TwitterConstant.getJsonForEs("articleLanguage",userToFilter);
			}

			//LANGUAGE NOT FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getLangNotFilter()))  //Multiple Language Not
			{
				String[] userArr=tweeterActionVo.getLangNotFilter().split(",");
				String userToFilter="";
				for(String user : userArr) 
				{
					userToFilter+="\""+user.trim()+"\",";
				}  
				userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				langNotFilter= TwitterConstant.getJsonForEs("articleLanguage",userToFilter);
			}

			//COUNTRY FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getCountryFilter()))  //Multiple Country
			{
				String[] userArr=tweeterActionVo.getCountryFilter().split(",");
				String userToFilter="";
				for(String user : userArr)
				{
					userToFilter+="\""+user.trim()+"\",";
				}
				userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				countryFilter= TwitterConstant.getJsonForEs("articleLocationCountry", userToFilter);
			}

			//COUNTRY NOT FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getCountryNotFilter()))  //Multiple Country Not
			{
				String[] userArr=tweeterActionVo.getCountryNotFilter().split(",");
				String userToFilter="";
				for(String user : userArr)
				{
					userToFilter+="\""+user.trim()+"\",";
				}  
				userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				countryNotFilter= TwitterConstant.getJsonForEs("articleLocationCountry", userToFilter);
			}

			//CITY FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getCityFilter()))  //Multiple City
			{
				String[] userArr=tweeterActionVo.getCityFilter().split(",");
				String userToFilter="";
				for(String user : userArr) 
				{
					userToFilter+="\""+user.trim()+"\",";
				}
				userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				cityFilter= TwitterConstant.getJsonForEs("articleLocationCity",userToFilter);
			}

			//CITY NOT FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getCityNotFilter()))  //Multiple City Not
			{
				String[] userArr=tweeterActionVo.getCityNotFilter().split(",");
				String userToFilter="";
				for(String user : userArr) 
				{
					userToFilter+="\""+user.trim()+"\",";
				}  
				userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				cityNotFilter= TwitterConstant.getJsonForEs("articleLocationCity",userToFilter);
			}

			//DOMAINS FILTER	 		
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getDomainFilter()))  //Multiple Domain
			{
				String[] userArr=tweeterActionVo.getDomainFilter().split(",");
				String userToFilter="";
				for(String user : userArr) 
				{
					userToFilter+="\""+user.trim()+"\",";
				}
				userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				domainFilter= TwitterConstant.getJsonForEs("articleMedia.mediaUrl",userToFilter);
			}

			//DOMAINS NOT FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getDomainNotFilter()))  //Multiple Domain Not
			{
				String[] userArr=tweeterActionVo.getDomainNotFilter().split(",");
				String userToFilter="";
				for(String user : userArr) 
				{
					userToFilter+="\""+user.trim()+"\",";
				}
				userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				domainNotFilter= TwitterConstant.getJsonForEs("articleMedia.mediaUrl",userToFilter);
			}

			//URL LINK FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getLinkFilter()))  //Multiple URL
			{
				String[] userArr=tweeterActionVo.getLinkFilter().split(",");
				String userToFilter="";
				for(String user : userArr)
				{
					userToFilter+="\""+user.trim()+"\",";
				}
				userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				urlFilter= TwitterConstant.getJsonForEs("articleMedia.mediaUrl", userToFilter);
			}

			//URL LINK NOT FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getLinkNotFilter()))  //Multiple URL Not
			{
				String[] userArr=tweeterActionVo.getLinkNotFilter().split(",");
				String userToFilter="";
				for(String user : userArr) 
				{
					userToFilter+="\""+user.trim()+"\",";
				}
				userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				urlNotFilter= TwitterConstant.getJsonForEs("articleMedia.mediaUrl", userToFilter);
			}

			//ADVANCE FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getAdvFilter()))  //Advance Filter
			{
				advFilter= TwitterConstant.getJsonForEsQueryStringWithOutField(tweeterActionVo.getAdvFilter().trim());
			}

			/*if(CommonUtils.stringNotEmpty(tweeterActionVo.getKeywordFilter()))  //Search By Keyword
			{
				keywordFilter=  TwitterConstant.getJsonForEsQueryString("articleTitle",tweeterActionVo.getKeywordFilter().trim());
			}
			 */
			
			//REPORT KEYWORD FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getKeywordFilter1()))  //Search By Report Keyword
			{
				keywordFilter1= TwitterConstant.getJsonForEsQueryString("articleTitle", tweeterActionVo.getKeywordFilter1().trim());
			}

			//ALL TWEET FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getAllTweetFilter()))
			{				
				if(tweeterActionVo.getAllTweetFilter().equals("0") || tweeterActionVo.getAllTweetFilter().equals("1"))
				{
					tweetFlagFilter= TwitterConstant.getJsonForEsTerm("tweet.tweetIsRetweetFlag","\""+tweeterActionVo.getAllTweetFilter()+"\"");
				}
				else
				{
					mediaTypeFilter= TwitterConstant.getJsonForEsTerm("articleMedia.mediaType", "\""+tweeterActionVo.getAllTweetFilter()+"\"");
				}
			}

			//Tweet PRIORITY FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getArticlePriority()))
			{
				/*switch (tweeterActionVo.getArticlePriority()) {
				case "0":
					articlePriority=	",{\n"+
							"\"range\": {\n"+
							"\"articlePriority\": {\n"+
							"\"lte\":0\n"+
							"}\n"+
							"}\n"+ 
							"}\n";
					break;
				case "0.5":
					articlePriority=	",{\n"+
							"\"range\": {\n"+
							"\"articlePriority\": {\n"+
							"\"gt\":0,\n"+
							"\"lt\":1\n"+
							"}\n"+
							"}\n"+ 
							"}\n";
					break;
				case "1":
					articlePriority=	",{\n"+
							"\"range\": {\n"+
							"\"articlePriority\": {\n"+
							"\"gte\":1\n"+
							"}\n"+
							"}\n"+ 
							"}\n";
					break;

				default:
					break;
				}*/

				//0= not important ,1=most important ,3= less important
				articlePriority= TwitterConstant.getJsonForEsTerm("articlePriority",""+tweeterActionVo.getArticlePriority()+"");
			}

			//SENTIMENT FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getSentimentFilter())) //-2,-1,0,1,2
			{
				String[] userArr = tweeterActionVo.getSentimentFilter().split(",");
				String userToFilter="";
				for(String user : userArr) 
				{
					userToFilter+="\""+user.trim()+"\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length()-1);
				sentimentFilter = TwitterConstant.getJsonForEs("articleSentiment", userToFilter);

				//sentimentFilter= TwitterConstant.getJsonForEsTerm("articleSentiment","\""+tweeterActionVo.getSentimentFilter()+"\"");
			}

			//EMOTION FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getEmotionFilter())) //Emotion Filter
			{
				String[] userArr = tweeterActionVo.getEmotionFilter().split(",");
				String userToFilter="";
				for(String user : userArr) 
				{
					userToFilter+="\""+user.trim()+"\",";
				}
				userToFilter = userToFilter.substring(0, userToFilter.length()-1);
				emotionFilter = TwitterConstant.getJsonForEs("articleEmotion", userToFilter);
				//emotionFilter= TwitterConstant.getJsonForEsTerm("articleEmotion","\""+tweeterActionVo.getEmotionFilter()+"\"");
			}
			
			//TWITTER USER VERIFIED FILTER			
			String userType = tweeterActionVo.getTwUserType();
			if(userType != null) 
			{
				if(userType.equals("verified"))
				{
					twUserTypeFilter= TwitterConstant.getJsonForEs("tweet.tweetUser.tweetUserVerified", "true");
				}
				else if(userType.equals("notVerified"))
				{
					twUserTypeFilter= TwitterConstant.getJsonForEs("tweet.tweetUser.tweetUserVerified", "false");
				}
			}			
			
			/*if(CommonUtils.stringNotEmpty(tweeterActionVo.getTwUserType()))
			{
				String[] userArr=tweeterActionVo.getClassificationFilter().split(",");
				String userToFilter="";
				for(String user : userArr) 
				{
					userToFilter+="\""+user+"\",";
				}
				userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				
				classificationFilter= TwitterConstant.getJsonForEs("articleClassification",userToFilter);
			}*/

			//MEDIA FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getMediaType())) //image,video,url,domain
			{
				mediaFilter= TwitterConstant.getJsonForEsTerm("articleMedia.mediaType","\""+tweeterActionVo.getMediaType()+"\"");
			}

			//USER CREATION DATE FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getUserCreatedDateFrom()) && CommonUtils.stringNotEmpty(tweeterActionVo.getUserCreatedDateTo()))  //User Creation Date
			{
				long dateUserFrom=TwitterConstant.convertDateToTimeStamp(tweeterActionVo.getUserCreatedDateFrom());
				long dateUserTo=TwitterConstant.convertDateToTimeStamp(tweeterActionVo.getUserCreatedDateTo());
				userCreatedDate= ",{\n"+
						"\"range\": {\n"+
						"\"tweet.tweetUser.tweetUserCreatedTime\": {\n"+
						"\"from\": "+dateUserFrom+",\n"+
						"\"to\": "+dateUserTo+"\n"+
						"}\n"+
						"}\n"+ 
						"}\n";
			}

			//PRIORITY FILTER
			/*String loginUserId=(String)httpSession.getAttribute(ApplicationConstants.LOGINUSERID);
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getPriorityFilter()) && tweeterActionVo.getPriorityFilter().equals("1"))     //0,1
			{
				priorityFilter=TwitterConstant.getJsonForEsTerm("articleMarked", "\""+loginUserId+"\"");			
			}*/

			//LATITUDE FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getLatitude()) && CommonUtils.stringNotEmpty(tweeterActionVo.getLongitude()))  //tweet latitute and longitud
			{
				latitudeFilter= TwitterConstant.getJsonForEsTermLatLong("\""+tweeterActionVo.getLatitude()+"\"","\""+tweeterActionVo.getLongitude()+"\"");
			}

			//COUNTRY CODE FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getCountryCode()))
			{
				countryCodeFilter= TwitterConstant.getJsonForEsTerm("articleLocationCountryCode","\""+tweeterActionVo.getCountryCode()+"\"");
			}

			//TWITTER USER COUNTRY FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getTwUserCountryCode()))
			{
				twUserCountryCode= TwitterConstant.getJsonForEsTerm("tweet.tweetUser.tweetUserCountryCode","\""+tweeterActionVo.getTwUserCountryCode()+"\"");
			}

			//GEO SEARCH FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getIsMap()))
			{
				geoSearch= TwitterConstant.getJsonForEsForExist("articleLocation");
			}

			//GEO SEARCH USER FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getIsUserMap()))
			{
				geoSearch= TwitterConstant.getJsonForEsForExist("articleUserLocation");
			}

			//COMPONENT TYPE FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getIsComponent()) && CommonUtils.stringNotEmpty(tweeterActionVo.getComponentType()))
			{
				switch(tweeterActionVo.getComponentType().trim().toLowerCase()) 
				{
				case "hashtag":
					isComponentFilter = TwitterConstant.getJsonForEsForExist("articleHashTag");
					break;
				case "mention":
					isComponentFilter = TwitterConstant.getJsonForEsForExist("articleMention");
					break; 
				case "user": 
					isComponentFilter = TwitterConstant.getJsonForEsForExist("articleAuthor");
					break; 
				case "place":
					isComponentFilter = TwitterConstant.getJsonForEsForExist("articleLocationNer");
					break;
				case "person":
					isComponentFilter = TwitterConstant.getJsonForEsForExist("articlePersonNer");
					break;
				case "org":
					isComponentFilter = TwitterConstant.getJsonForEsForExist("articleOrganizationNer");
					break;
				case "date":
					isComponentFilter = TwitterConstant.getJsonForEsForExist("articleDateNer");
					break;
				case "language":
					isComponentFilter = TwitterConstant.getJsonForEsForExist("articleLanguage");
					break;
				case "country":
					isComponentFilter = TwitterConstant.getJsonForEsForExist("articleLocationCountry");
					break;
				case "themes":
					isComponentFilter = TwitterConstant.getJsonForEsForExist("articleThemes");
					break;
				case "city":
					isComponentFilter = TwitterConstant.getJsonForEsForExist("articleLocationCity");
					break;
				case "phone":
					isComponentFilter = TwitterConstant.getJsonForEsForExist("articleMobile");
					break;
				case "email":
					isComponentFilter = TwitterConstant.getJsonForEsForExist("articleEmail");
					break;
				case "event":
					isComponentFilter = TwitterConstant.getJsonForEsForExist("articleEvent.keyword");
					break;
				case "taxonomy":
					isComponentFilter = TwitterConstant.getJsonForEsForExist("taxonomy");
					break;
				case "authorCountry":
					isComponentFilter = TwitterConstant.getJsonForEsForExist("tweet.tweetUser.tweetUserCountry");
					break;
				case "authorCity":
					isComponentFilter = TwitterConstant.getJsonForEsForExist("tweet.tweetUser.tweetUserLocation");
					break;
				default:
					break;
				}
			}

			//REPORT FILTER*************
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getIsRpt()))
			{
				if(CommonUtils.stringNotEmpty(tweeterActionVo.getTweetId()))
				{
					String[] userArr=tweeterActionVo.getTweetId().split(",");
					String userToFilter="";
					for(String user : userArr) 
					{
						userToFilter+="\""+user+"\",";
					}
					userToFilter=userToFilter.substring(0, userToFilter.length()-1);
					tweetIdFilter=  TwitterConstant.getJsonForEs("articleId",userToFilter);
				}
			}

			//GEO POLYGON FILTER
			if(tweeterActionVo.getGeoPolygon()!=null && tweeterActionVo.getGeoPolygon().size()>0)
			{
				geoPolygonFilter=TwitterConstant.getJsonForEsPolygon(tweeterActionVo.getGeoPolygon(), "articleLocation");				
			}

			//GEO POLYGON NOT FILTER
			if(tweeterActionVo.getGeoPolygonNot()!=null)
			{ 
				geoPolygonNotFilter=TwitterConstant.getJsonForEsPolygon(tweeterActionVo.getGeoPolygonNot(), "articleLocation");				
			}

			//GEO USER POLYGON FILTER
			if(tweeterActionVo.getGeoUserPolygon()!=null && tweeterActionVo.getGeoUserPolygon().size()>0)
			{
				geoUserPolygonFilter=TwitterConstant.getJsonForEsPolygon(tweeterActionVo.getGeoUserPolygon(), "articleUserLocation");				
			}

			//GEO USER POLYGON NOT FILTER
			if(tweeterActionVo.getGeoUserPolygonNot()!=null && tweeterActionVo.getGeoUserPolygonNot().size()>0)
			{
				geoUserPolygonNotFilter=TwitterConstant.getJsonForEsPolygon(tweeterActionVo.getGeoUserPolygonNot(), "articleUserLocation");				
			}

			//COMPONENT KEYWORD FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getComponentKeyword()) && CommonUtils.stringNotEmpty(tweeterActionVo.getComponentType()))
			{  
				/*If User Filter Tweet & Retweet only then it Wont Work.
				 */
				/*if(!CommonUtils.stringNotEmpty(tweeterActionVo.getAllTweetFilter()))
				{
					if(CommonUtils.stringNotEmpty(tweeterActionVo.getSourceFilter()))  //Multiple Source Filter
					{
						String[] userArr=tweeterActionVo.getSourceFilter().split(",");
						boolean found = Arrays.stream(userArr).anyMatch(x -> "tw".equals(x));
						if(found)
						{
							String val="0";
							componentTweetFilter=  TwitterConstant.getJsonForEsTerm("tweet.tweetIsRetweetFlag","\""+val+"\"");
						}
					} 
				}*/  

				String keyword="\""+tweeterActionVo.getComponentKeyword()+"\"";
				switch(tweeterActionVo.getComponentType().trim().toLowerCase()) 
				{
				case "hashtag":
					componentFilter = TwitterConstant.getJsonForEs("articleHashTag", keyword);
					break;
				case "mention":
					componentFilter = TwitterConstant.getJsonForEs("articleMention", keyword);
					break;
				case "user":
					componentFilter = TwitterConstant.getJsonForEs("articleAuthor", keyword);
					break; 
				case "place":
					componentFilter = TwitterConstant.getJsonForEsNested("articleLocationNer", "articleLocationNer.keyword", keyword);
					break;
				case "person":
					componentFilter = TwitterConstant.getJsonForEsNested("articlePersonNer", "articlePersonNer.keyword", keyword);
					break;
				case "org": 
					componentFilter = TwitterConstant.getJsonForEsNested("articleOrganizationNer", "articleOrganizationNer.keyword", keyword);
					break; 
				case "date": 
					componentFilter = TwitterConstant.getJsonForEsNested("articleDateNer", "articleDateNer.keyword", keyword);
					break; 
				case "language":
					componentFilter = TwitterConstant.getJsonForEs("articleLanguage", keyword);
					break;
				case "country":
					componentFilter = TwitterConstant.getJsonForEs("articleLocationCountry", keyword);
					break;
				case "themes":
					componentFilter = TwitterConstant.getJsonForEs("articleThemes", keyword);
					break;
				case "city":
					componentFilter = TwitterConstant.getJsonForEs("articleLocationCity", keyword);
					break;
				case "phone":
					componentFilter = TwitterConstant.getJsonForEs("articleMobile", keyword);
					break;
				case "email":
					componentFilter = TwitterConstant.getJsonForEs("articleEmail", keyword);
					break;
				case "event":
					componentFilter = TwitterConstant.getJsonForEs("articleEvent.keyword", keyword);
					break;					 
				case "taxonomy":
					componentFilter = TwitterConstant.getJsonForEs("taxonomy", keyword);
					break;
				case "authorCountry":
					componentFilter = TwitterConstant.getJsonForEs("tweet.tweetUser.tweetUserCountry", keyword);
					break;
				case "authorCity":
					componentFilter = TwitterConstant.getJsonForEs("tweet.tweetUser.tweetUserLocation", keyword);
					break;
				default:
					break;
				}
			}

			//CLASSIFICATION FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getClassificationFilter()))
			{
				String[] userArr=tweeterActionVo.getClassificationFilter().split(",");
				String userToFilter="";
				for(String user : userArr) 
				{
					userToFilter+="\""+user+"\",";
				}
				userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				classificationFilter=  TwitterConstant.getJsonForEs("articleClassification",userToFilter);
			}

			//CLASSIFICATION NOT FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getClassificationNotFilter()))
			{
				String[] userArr=tweeterActionVo.getClassificationNotFilter().split(",");
				String userToFilter="";
				for(String user : userArr) 
				{
					userToFilter+="\""+user+"\",";
				}
				userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				classificationNotFilter=  TwitterConstant.getJsonForEs("articleClassification",userToFilter);
			}

			//THREAT CLASSIFICATION FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getThreatClassificationFilter()))
			{
				System.out.println("ThreatClassificationFilter: "+tweeterActionVo.getThreatClassificationFilter());
				String[] userArr=tweeterActionVo.getThreatClassificationFilter().split(",");
				String userToFilter="";
				for(String user : userArr) 
				{
					userToFilter+="\""+user+"\",";
				}
				userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				threatClassificationFilter=TwitterConstant.getJsonForEs("articleThreatClassification", userToFilter);
			}

			//THREAT CLASSIFICATION NOT FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getThreatClassificationNotFilter()))
			{
				String[] userArr=tweeterActionVo.getThreatClassificationNotFilter().split(",");
				String userToFilter="";
				for(String user : userArr) 
				{
					userToFilter+="\""+user+"\",";
				}
				userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				threatClassificationNotFilter=TwitterConstant.getJsonForEs("articleThreatClassification",userToFilter);
			}
			
			//ARTICLE ID FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getArticleIdFilter())) 
			{
				String[] userArr=tweeterActionVo.getArticleIdFilter().split(",");
				String userToFilter="";
				for(String user : userArr)
				{
					userToFilter+="\""+user.trim()+"\",";
				}
				userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				articleIdFilter= TwitterConstant.getJsonForEs("articleId", userToFilter);				
			}

			//ARTICLE TITLE HASH FILTER
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getArticleTitleHash())) 
			{
				String[] userArr=tweeterActionVo.getArticleTitleHash().split(",");
				String userToFilter="";
				for(String user : userArr)
				{
					userToFilter+="\""+user.trim()+"\",";
				}
				userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				articleTitleHashFilter= TwitterConstant.getJsonForEs("articleTitleHash", userToFilter);				
			}

			//only for whats up word cloud
			if(type==91) 
			{
				String selectQuery=" SELECT keyword FROM tbl_wordcloud ";					   					
				System.out.println("selectQuery: "+selectQuery);			
				List<Map<String, Object>> rows = jdbcTemplate.queryForList(selectQuery);
				String userToFilter="";
				for(Map<String,Object> rs :rows) 
				{
					userToFilter+="\""+rs.get("keyword").toString().trim()+"\",";
				}

				userToFilter=userToFilter.substring(0, userToFilter.length()-1);
				wordCloudNotFilter = TwitterConstant.getJsonForEs("articleTitle", userToFilter);
			}

			/*Avoid Sentiment value 9 */
			if(type==19) 
			{
				sentimentNotFilter=TwitterConstant.getJsonForEsTerm("articleSentiment", "9");
			}

			joinQuery=""+
					"\"query\":{\n"+
					"\"bool\":{\n"+
					"\"filter\": {\n"+
					"\"bool\": {\n"+
					"\"must\": [\n"+
					"{}"+
					fbUserProfileFilter+
					targetView+					
					articleNewsCategory+
					//globalProfileFilter+
					globalProfileFilterLinkAnalysis+
					//globalLocationFilter+
					retweetedUserFilter+

					articlePriority+
					dateFilter+
					threatClassificationFilter+
					entityId+
					userIdFilter+
					userFilter+
					timeZoneFilter+
					hashTagFilter+
					themeFilter+
					mentionFilter+
					domainFilter+
					urlFilter+
					advFilter+
					twUserTypeFilter+
					keywordFilter+
					keywordFilter1+
					exactMatchKeyword+
					tweetFlagFilter+
					mediaTypeFilter+
					sentimentFilter+
					latitudeFilter+
					//priorityFilter+
					countryCodeFilter+
					tweetIdFilter+
					personFilter+
					orgFilter+
					placeFilter+
					mediaFilter+
					imgFilter+
					videoFilter+
					audioFilter+
					groupFilter+
					viralTextFilter+
					docTypeFilter+
					
					geoSearch+ 
					geoPolygonFilter+
					geoUserPolygonFilter+
					componentFilter+
					componentTweetFilter+
					isComponentFilter+
					classificationFilter+
					
					//emotionFilter+
					langFilter+
					countryFilter+
					cityFilter+
					nerDateFilter+
					mobileFilter+
					eventFilter+
					taxonomyFilter+
					authorCountryFilter+
					authorCityFilter+
					emailFilter+
					userCreatedDate+
					userSearch+
					globalFilter+
					articleIdFilter+
					articleTitleHashFilter+
					phoneNo+
					wtGroupNo+
					contactNo
					+ "],\n"+
							"\"must_not\": [\n"
							+ "{}"+
							articleNewsOtherCategory+
							retweetedUserNotFilter+

							userNotFilter+
							timeZoneNotFilter+
							hashTagNotFilter+
							themeNotFilter+
							mentionNotFilter+
							domainNotFilter+
							urlNotFilter+
							personNotFilter+
							orgNotFilter+
							placeNotFilter+
							imgNotFilter+
							videoNotFilter+							
							audioNotFilter+
							groupNotFilter+
							viralTextNotFilter+
							docTypeNotFilter+	
							
							sentimentNotFilter+
							geoPolygonNotFilter+
							geoUserPolygonNotFilter+
							classificationNotFilter+
							threatClassificationNotFilter+
							langNotFilter+
							cityNotFilter+
							countryNotFilter+
							nerDateNotFilter+
							mobileNotFilter+
							emailNotFilter+
							eventNotFilter+
							taxonomyNotFilter+
							authorCountryNotFilter+
							authorCityNotFilter+
							wordCloudNotFilter
							+ "]\n"
							+ "}\n"
							+ "}\n"
							+ "}\n"
							+ "}\n";

		} 
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return joinQuery;
	}

	public String rtnLimit(TweeterActionVo tweeterActionVo)
	{
		String joinQuery =" 0,6 " ;
		if(!tweeterActionVo.getIsDashBord().toLowerCase().trim().equals("y"))
		{
			joinQuery=tweeterActionVo.getRowNum()+",50";
		}
		return joinQuery;
	}

	public String rtnTweetLimit(TweeterActionVo tweeterActionVo)
	{
		String  joinQuery="" ;
		if(CommonUtils.stringNotEmpty(tweeterActionVo.getIsRpt()))
		{
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getNoTweet()))
			{
				joinQuery=" limit 0,"+tweeterActionVo.getNoTweet();
			}
		}
		else
		{
			joinQuery=" limit "+tweeterActionVo.getRowNum()+",50 ";
		}
		return joinQuery;
	}

	
	public String getTweetsSortOrder(TweeterActionVo tweeterActionVo)
	{
		String sortQuery="";
		try
		{
			switch(tweeterActionVo.getTwSortFilter().toLowerCase().trim())
			{
			case "ne":
				sortQuery="{\n"
						+"\"articlePublishDate\": {\n"
						+"\"order\": \"desc\""
						+"}\n"
						+"}\n";
				break;

			case "ol":
				sortQuery="{\n"
						+"\"articlePublishDate\": {\n"
						+"\"order\": \"asc\""
						+"}\n"
						+"}\n";
				break;

			case "inne":
				sortQuery="{\n"
						+"\"articleInsertedDate\": {\n"
						+"\"order\": \"desc\""
						+"}\n"
						+"}\n";
				break;

			case "inol":
				sortQuery="{\n"
						+"\"articleInsertedDate\": {\n"
						+"\"order\": \"asc\""
						+"}\n"
						+"}\n";
				break;

				/****Twitter**************/
			case "twde":
				sortQuery="{\n"
						+"\"tweet.tweetRetweetCount\": {\n"
						+"\"order\": \"desc\""
						+"}\n"
						+"}\n";
				break;

			case "twas":
				sortQuery="{\n"
						+"\"tweet.tweetRetweetCount\": {\n"
						+"\"order\": \"asc\""
						+"}\n"
						+"}\n";
				break;
				
			case "twlikedesc":
				sortQuery="{\n"
						+"\"tweet.tweetFavouriteCount\": {\n"
						+"\"order\": \"desc\""
						+"}\n"
						+"}\n";
				break;

			case "twlikeasc":
				sortQuery="{\n"
						+"\"tweet.tweetFavouriteCount\": {\n"
						+"\"order\": \"asc\""
						+"}\n"
						+"}\n";
				break;
				
			case "twimpressiondesc":
				sortQuery="{\n"
						+"\"tweet.tweetImpressionCount\": {\n"
						+"\"order\": \"desc\""
						+"}\n"
						+"}\n";
				break;

			case "twimpressionasc":
				sortQuery="{\n"
						+"\"tweet.tweetImpressionCount\": {\n"
						+"\"order\": \"asc\""
						+"}\n"
						+"}\n";
				break;

				/**************Instagram**********/
			case "cmins":
				sortQuery="{\n"
						+"\"instagram.instaPostCommentCount\": {\n"
						+"\"order\": \"desc\""
						+"}\n"
						+"}\n";
				break;

			case "clins":
				sortQuery="{\n"
						+"\"instagram.instaPostCommentCount\": {\n"
						+"\"order\": \"asc\""
						+"}\n"
						+"}\n";
				break;

			case "lmins":
				sortQuery="{\n"
						+"\"instagram.instaPostLikeCount\": {\n"
						+"\"order\": \"desc\""
						+"}\n"
						+"}\n";
				break;

			case "llins":
				sortQuery="{\n"
						+"\"instagram.instaPostLikeCount\": {\n"
						+"\"order\": \"asc\""
						+"}\n"
						+"}\n";
				break;

				/**************Youtube**********/
			case "cmyt":
				sortQuery="{\n"
						+"\"youtube.ytCommentCount\": {\n"
						+"\"order\": \"desc\""
						+"}\n"
						+"}\n";
				break;

			case "clyt":
				sortQuery="{\n"
						+"\"youtube.ytCommentCount\": {\n"
						+"\"order\": \"asc\""
						+"}\n"
						+"}\n";
				break;

			case "lmyt":
				sortQuery="{\n"
						+"\"youtube.ytLikeCount\": {\n"
						+"\"order\": \"desc\""
						+"}\n"
						+"}\n";
				break;

			case "llyt":
				sortQuery="{\n"
						+"\"youtube.ytLikeCount\": {\n"
						+"\"order\": \"asc\""
						+"}\n"
						+"}\n";
				break;

			case "vmyt":
				sortQuery="{\n"
						+"\"youtube.ytViewCount\": {\n"
						+"\"order\": \"desc\""
						+"}\n"
						+"}\n";
				break;

			case "vlyt":
				sortQuery="{\n"
						+"\"youtube.ytViewCount\": {\n"
						+"\"order\": \"asc\""
						+"}\n"
						+"}\n";
				break;

			case "dmyt":
				sortQuery="{\n"
						+"\"youtube.ytDisLikeCount\": {\n"
						+"\"order\": \"desc\""
						+"}\n"
						+"}\n";
				break;

			case "dlyt":
				sortQuery="{\n"
						+"\"youtube.ytDisLikeCount\": {\n"
						+"\"order\": \"asc\""
						+"}\n"
						+"}\n";
				break;


			case "smfb":
				sortQuery="{\n"
						+"\"facebook.fbPostShareCount\": {\n"
						+"\"order\": \"desc\""
						+"}\n"
						+"}\n";
				break;

			case "lmfb":
				sortQuery="{\n"
						+"\"facebook.fbPostLikeCount\": {\n"
						+"\"order\": \"desc\""
						+"}\n"
						+"}\n";
				break;

			case "cmfb":
				sortQuery="{\n"
						+"\"facebook.fbPostCommentCount\": {\n"
						+"\"order\": \"desc\""
						+"}\n"
						+"}\n";
				break;

			}

			String sort=",\"sort\": [\n"
					+sortQuery
					+"]\n";
			return sort;
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			return "";
		}
		finally
		{
			sortQuery=null;
		}
	}


	//user tweet count
	public ArrayList<TwitterVo> userTweetCount(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		String user=(String)httpSession.getAttribute(ApplicationConstants.LOGIN_USER);

		//JdbcTemplate jdbcTemplate=new JdbcTemplate(dataSource);
		try
		{
			String query=null;
			query= "SELECT * FROM ( "+
					"(SELECT COUNT(tw_user.id)AS userCount FROM tw_user) AS userCount ,"+
					"(SELECT COUNT(tw_tweet.id) AS tweetCount FROM tw_tweet) AS tweetCount)";

			System.out.println("userTweetCount== "+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setUserCount(rs.get("userCount")==null?"":rs.get("userCount").toString());
				twitterVo.setTweetCount(rs.get("tweetCount")==null?"":rs.get("tweetCount").toString());
				lst.add(twitterVo);
			}	
			if(log.isInfoEnabled())
			{
				log.info("User Name------>"+user+"    method=========userTweetCount()  "+"sql============"+query);
			}

		}
		catch(Exception e) 
		{
			log.error("--------- Exception--------", e);
			e.printStackTrace();
		} 
		return lst; 
	}

	
	public ArrayList<TwitterVo> CheckQueryReport(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		String rtnString="false";
		try
		{
			String  query="{"+
					"\"query\": {\n"+
					"\"query_string\": {\n"+
					"\"query\": \""+tweeterActionVo.getAdvFilter().trim()+"\"\n"+
					"}\n"+
					"}\n"+
					"}\n";
			System.out.println("CheckQueryReport tweet== "+query);
			Validate validate=new Validate.Builder(query).index(TwitterConstant.getDbname()).type(TwitterConstant.getTypeName())
					
					//Search search = new Search.Builder(query)
					/*			.addIndex(TwitterConstant.getDbname())
			.addType(TwitterConstant.getTypeName())
					 */			
			.build();

			JestResult result=client.execute(validate);
			System.out.println(result.getJsonString());

			/*SearchResult result = client.execute(validate);
			try
			{
				System.out.println(result.getErrorMessage().length());	
			}
			catch(Exception ex)
			{
				rtnString="true";	
			}
			 */		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		TwitterVo twitterVo=new TwitterVo();
		twitterVo.setAdvFilter(rtnString);
		lst.add(twitterVo);
		return lst; 
	}

	
	public ArrayList<TwitterVo> getSentiment(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> lst = new ArrayList<TwitterVo>();
		try 
		{
			String subQuery = rtnFilterQuery(tweeterActionVo, 19);
			String query = "{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+ 
					"\"termagg\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\"articleSentiment\"\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";

			System.out.println("getSentiment:: "+query);
			Search search = new Search.Builder(query)
					// multiple index or types can be added.
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			//System.out.println("getSentiment time taken::"+result.getValue("took"));

			TermsAggregation terms = result.getAggregations().getTermsAggregation("termagg");
			if(terms !=null)
			{
				List<Entry> entry=terms.getBuckets();
				for(Entry entry2 : entry)
				{
					TwitterVo twitterVo=new TwitterVo();
					twitterVo.setSentiment(entry2.getKey());
					twitterVo.setCount(Long.toString(entry2.getCount()));
					lst.add(twitterVo);
				}
			}
		} 
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return lst; 
	}

	
	public ArrayList<TwitterVo> getMention(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		try 
		{
			int size=TwitterConstant.getSizeForEsTermAgg(tweeterActionVo, tweeterActionVo.getNoMention());	
			String sortQuery=TwitterConstant.getSortForEsTermAgg(tweeterActionVo.getMentionSortOrder().toLowerCase().trim());
			String subQuery=rtnFilterQuery(tweeterActionVo, -1);
			
			String avgAgg="";
			if(tweeterActionVo.getOnlyCount().isEmpty())
			{
			   avgAgg=TwitterConstant.getAvg("articleSentiment");
			}

			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"termagg\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\"articleMention\"\n,"+
					"\"size\":\""+size+"\"\n,"+
					sortQuery+
					"}\n"+
					avgAgg+
					"}\n"+
					"}\n"+
					"}\n";

			System.out.println("*****getMention()***** "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			TermsAggregation terms = result.getAggregations().getTermsAggregation("termagg");
			if(terms !=null) 
			{
				List<Entry> entry=terms.getBuckets();
				for(Entry entry2 : entry) 
				{
					TwitterVo twitterVo=new TwitterVo();
					twitterVo.setUserName(entry2.getKey());
					twitterVo.setUserCount(Long.toString(entry2.getCount()));
					if(tweeterActionVo.getOnlyCount().isEmpty())
					{
						AvgAggregation avg=entry2.getAvgAggregation("avg");
						twitterVo.setSentiment(Double.toString(avg.getAvg()));
					}					
					lst.add(twitterVo);
				}
			}
		} 
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return lst; 
	}

	
	public ArrayList<TwitterVo> getTwGeoMap(TweeterActionVo tweeterActionVo)
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		try
		{
			String  subQuery=rtnFilterQuery(tweeterActionVo,-1);
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"termagg\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\"countryCode\"\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";

			System.out.println("getTwGeoMap== "+query);
			Search search = new Search.Builder(query)
					// multiple index or types can be added.
					.addIndex(TwitterConstant.getDbname())
					.addType("tw_tweet")
					.build();
			SearchResult result = client.execute(search);
			TermsAggregation terms = result.getAggregations().getTermsAggregation("termagg");
			List<Entry>  entry=  terms.getBuckets();
			for(Entry entry2 : entry) 
			{
				/*System.out.println( entry2.getKey());
				System.out.println( entry2.getCount());
				 */				
				 TwitterVo twitterVo=new TwitterVo();
				 twitterVo.setGeoCode(entry2.getKey());
				 twitterVo.setTweetCount(Long.toString(entry2.getCount()));
				 lst.add(twitterVo);
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}

		return lst; 
	}


	
	public ArrayList<TwitterVo> getTwLocation(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		try
		{
			String subQuery=rtnFilterQuery(tweeterActionVo,-1);
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"termagg\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\"user.timeZone\"\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";
			System.out.println(query);
			Search search = new Search.Builder(query)
					// multiple index or types can be added.
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();
			SearchResult result = client.execute(search);
			TermsAggregation terms = result.getAggregations().getTermsAggregation("termagg");
			List<Entry> entry= terms.getBuckets();
			for(Entry entry2 : entry)
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setTimeZone(entry2.getKey());
				twitterVo.setTweetCount(Long.toString(entry2.getCount()));
				lst.add(twitterVo);
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return lst; 
	}


	
	public void getUpdatePriority(TweeterActionVo tweeterActionVo)
	{
		String user=(String)httpSession.getAttribute(ApplicationConstants.LOGINUSERID);
		try
		{
			String script = "{\n" +
					"\"script\" : {\n"+
					"\"inline\": \"if(ctx._source.articleMarked.contains(eId)) ctx._source.articleMarked-=eId; else ctx._source.articleMarked+=eId\",\n"+
					"\"params\" : {\n"+
					" \"eId\" : "+Integer.valueOf(user)+"\n" +
					"}\n"+
					"}\n"+
					"}";

			if(tweeterActionVo.getType().equals("sentiment"))
			{
				script = "{\n" +
						"\"script\" : {\n"+
						"\"inline\": \"ctx._source.articleSentiment=eId\",\n"+
						"\"params\" : {\n"+
						" \"eId\" : "+Integer.valueOf(tweeterActionVo.getPriority())+"\n" +
						"}\n"+
						"}\n"+
						"}";
			}

			if(tweeterActionVo.getType().equals("classification"))
			{
				script = "{\n" +
						"\"script\" : {\n"+
						"\"inline\": \"ctx._source.articleClassification=[] ; ctx._source.articleClassification+=eId\",\n"+
						"\"params\" : {\n"+
						" \"eId\" : \""+tweeterActionVo.getPriority()+"\"\n" +
						"}\n"+
						"}\n"+
						"}";
			}

			if(tweeterActionVo.getType().equals("articlePriority"))
			{
				script = "{\n" +
						"\"script\" : {\n"+
						"\"inline\": \"ctx._source.articlePriority=eId\",\n"+
						"\"params\" : {\n"+
						" \"eId\" : "+tweeterActionVo.getPriority()+"\n" +
						"}\n"+
						"}\n"+
						"}";
			}

			System.out.println("getUpdatePriority Twitter=="+script);
			System.out.println("ArticleId=="+tweeterActionVo.getTweetId());
			try 
			{
				client.execute(new Update.Builder(script).index(TwitterConstant.getDbname()).type(TwitterConstant.getTypeName()).id(tweeterActionVo.getTweetId()).build());
			} 
			catch(IOException e) 
			{
				e.printStackTrace();
			}

			if(tweeterActionVo.getType().equals("sentiment") && tweeterActionVo.getSource().equals("tw"))
			{
				script = "" +
						"\"script\" : {\n"+
						"\"inline\": \"ctx._source.articleSentiment=eId\",\n"+
						"\"params\" : {\n"+
						" \"eId\" : "+Integer.valueOf(tweeterActionVo.getPriority())+"\n" +
						"}\n"+
						"},\n";
				String updateByQueryStr="";//"{ "+script+" \"query\": {\"term\": {\"tweet.tweetRetweetSourceId\": \""+tweeterActionVo.getTweetId()+"\" }}}";
				if(tweeterActionVo.getTweetIdFlag().equals("0")) //if tweet is original tweet so change sentiment of all retweets
				{
					updateByQueryStr="{ "+script+" \"query\": {\"term\": {\"tweet.tweetRetweetSourceId\": \""+tweeterActionVo.getTweetId()+"\" }}}";
					System.out.println("update all retweet of original tweet::::"+updateByQueryStr);
					try 
					{
						UpdateByQuery updateByQuery = new UpdateByQuery.Builder(updateByQueryStr)
								.addIndex(TwitterConstant.getDbname())
								.addType(TwitterConstant.getTypeName())
								.build();
						client.execute(updateByQuery);
					}
					catch(IOException e)
					{
						e.printStackTrace();
					}
				}
				if(tweeterActionVo.getTweetIdFlag().equals("1")) //if tweet is Retweet so change sentiment of original tweet & all retweets.
				{
					updateByQueryStr="{ "+script+" \"query\": {\"term\": {\"tweet.tweetRetweetSourceId\": \""+tweeterActionVo.getArticleIdFilter()+"\" }}}";
					System.out.println("update all retweet of original tweet::::\n"+updateByQueryStr);
					try 
					{
						UpdateByQuery updateByQuery = new UpdateByQuery.Builder(updateByQueryStr)
								.addIndex(TwitterConstant.getDbname())
								.addType(TwitterConstant.getTypeName())
								.build();
						client.execute(updateByQuery);
					} 
					catch(IOException e) 
					{
						e.printStackTrace();
					}

					updateByQueryStr="{ "+script+" \"query\": {\"term\": {\"articleId\": \""+tweeterActionVo.getArticleIdFilter()+"\" }}}";
					System.out.println("update  original tweet::::\n"+updateByQueryStr);
					try 
					{
						UpdateByQuery updateByQuery = new UpdateByQuery.Builder(updateByQueryStr)
								.addIndex(TwitterConstant.getDbname())
								.addType(TwitterConstant.getTypeName())
								.build();
						client.execute(updateByQuery);
					} 
					catch(IOException e) 
					{
						e.printStackTrace();
					}
				}
			}


			if(tweeterActionVo.getType().equals("articlePriority")) 
			{				
				TwitterVo twitterVo= getArticleById(tweeterActionVo);
				ArticlePriority articlePriority=new ArticlePriority();
				articlePriority.setArticleId(twitterVo.getTweeterId());
				articlePriority.setTitle(twitterVo.getArticleTitle());
				articlePriority.setContent(twitterVo.getArticleBigContent());
				articlePriority.setPriority(Integer.parseInt(tweeterActionVo.getPriority()));
				articlePriority.setInsertionDate(new Date().getTime());
				articlePriority.setCountry(twitterVo.getArticleLocationCountry());

				ObjectMapper mapper = new ObjectMapper();
				String text=mapper.writeValueAsString(articlePriority); System.out.println("text :"+text);
				client.execute( new Index.Builder(text).index("articlepriority").type("articlepriority").build());
			}
		}	
		catch(Exception e) 
		{
			e.printStackTrace();
		} 		
	}

	
	public ArrayList<TwitterVo> getTimeLine(TweeterActionVo tweeterActionVo)
	{
		return getTweets(tweeterActionVo);
	}

	
	public ArrayList<TwitterVo> getHashtagWordCloud(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> lst1 = new ArrayList<TwitterVo>();
		tweeterActionVo.setIsRpt("y");
		tweeterActionVo.setHashTagSortOrder("cntdesc");
		if(tweeterActionVo.getZRptFlag().equals("no"))
		{
			tweeterActionVo.setNoHashtag("200");
		}
		else
		{
			tweeterActionVo.setNoHashtag("20");
		}
		
		try
		{
			ArrayList<TwitterVo> lst = getHashTags(tweeterActionVo);
			List<WordFrequency> wordFrequencies	= new ArrayList<WordFrequency>();
			for(TwitterVo twitterVo:lst)
			{
				wordFrequencies.add(
						new WordFrequency(twitterVo.getHashtag(),Integer.parseInt(twitterVo.getHashCount()))
						);
			}
			TwitterVo twitterVo = new TwitterVo();
			twitterVo.setWordFrequencies(wordFrequencies);
			lst1.add(twitterVo);
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		} 
		return lst1; 
	}

	
	public ArrayList<TwitterVo> getUserWordCloud(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> lst1=new ArrayList<TwitterVo>();
		try
		{
			tweeterActionVo.setIsRpt("y");
			tweeterActionVo.setNoUser("300");
			tweeterActionVo.setUserSortFilter("cntdesc");
			ArrayList<TwitterVo> lst = getUsers(tweeterActionVo);
			List<WordFrequency> wordFrequencies	= new ArrayList<WordFrequency>();
			for(TwitterVo twitterVo : lst)
			{
				wordFrequencies.add(
						new WordFrequency(twitterVo.getUserName(),Integer.parseInt(twitterVo.getUserCount().toString()))
						);   
			}
			TwitterVo twitterVo=new TwitterVo();
			twitterVo.setWordFrequencies(wordFrequencies);
			lst1.add(twitterVo);
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		} 
		return lst1; 
	}


	
	public ArrayList<TwitterVo> getMentionWordCloud(TweeterActionVo tweeterActionVo)
	{
		tweeterActionVo.setIsRpt("y");
		tweeterActionVo.setNoMention("300");
		tweeterActionVo.setMentionSortOrder("cntdesc");
		ArrayList<TwitterVo> lst1=new ArrayList<TwitterVo>();
		try
		{
			ArrayList<TwitterVo> lst = getMention(tweeterActionVo);
			List<WordFrequency> wordFrequencies	 =new ArrayList<WordFrequency>();
			for(TwitterVo  twitterVo:lst)
			{
				wordFrequencies.add(
						new WordFrequency(twitterVo.getUserName(),Integer.parseInt(twitterVo.getUserCount()))
						);
			}
			TwitterVo twitterVo=new TwitterVo();
			twitterVo.setWordFrequencies(wordFrequencies);
			lst1.add(twitterVo);
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		} 
		return lst1; 
	}

	
	
	public ArrayList<TwitterVo> getMentionUserLink(TweeterActionVo tweeterActionVo) 
	{
		String user=(String)httpSession.getAttribute(ApplicationConstants.LOGIN_USER);

		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		//JdbcTemplate jdbcTemplate=new JdbcTemplate(dataSource);
		System.out.println(tweeterActionVo.getAdvFilter()+tweeterActionVo.getMediaFilter());
		try
		{
			String query=null;
			query=" SELECT tw_mentions.username, tw_mentions.userid, tweet.user_name "+
				  "	FROM tw_mentions "+
			      "	INNER JOIN tw_tweet tweet ON tweet.id=tw_mentions.tweetid "+
				  " INNER JOIN tw_user "+
				  " ON tw_user.id = tweet.user_id "+
				  rtnJoinQuery(tweeterActionVo,false,true,false)+
				  rtnFilterQuery(tweeterActionVo,-1)+
				  " LIMIT 0, 100 ";

			System.out.println("getMentionUserLink== "+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setUserName(rs.get("username")==null?"":rs.get("username").toString());  //mention name
				twitterVo.setUserId(rs.get("user_name")==null?"":rs.get("user_name").toString()); // tweet user name
				lst.add(twitterVo);
			}
			if(log.isInfoEnabled())
			{
				log.info("User Name------>"+user+"    method=========getMentionUserLink()  "+"sql============"+query);
			}
		}
		catch(Exception e) 
		{
			log.error("--------- Exception--------", e);
			e.printStackTrace();
		} 
		return lst; 
	}

	
	public ArrayList<TwitterVo> getHashLink(TweeterActionVo tweeterActionVo)
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		String user=(String)httpSession.getAttribute(ApplicationConstants.LOGIN_USER);

		//JdbcTemplate jdbcTemplate=new JdbcTemplate(dataSource);
		try
		{
			String  query=null;
			query= " SELECT  CONCAT('#',hashtag) AS hashtag ,tweet.user_name, "+
					" hashtags.id AS hashTagId "+
					"	FROM tw_hashtags hashtags "+
					"	INNER JOIN tw_tweet tweet "+
					"	ON tweet.id=hashtags.tweet_id "+
					rtnJoinQuery(tweeterActionVo,false,true,false)+
					rtnFilterQuery(tweeterActionVo,-1)+
					" LIMIT 0,100 ";
			System.out.println("getHashLink== "+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setUserName(rs.get("user_name")==null?"":rs.get("user_name").toString());
				twitterVo.setUserId(rs.get("hashtag")==null?"":rs.get("hashtag").toString());
				lst.add(twitterVo);
			}
			if(log.isInfoEnabled())
			{
				log.info("User Name------>"+user+"    method=========getHashLink()  "+"sql============"+query);
			}
		}
		catch(Exception e) 
		{
			log.error("--------- Exception--------", e);
			e.printStackTrace();
		} 
		return lst; 
	}

	
	
	public ArrayList<TwitterVo> getTweetDomainLink(TweeterActionVo tweeterActionVo)
	{
		String user=(String)httpSession.getAttribute(ApplicationConstants.LOGIN_USER);
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		//JdbcTemplate jdbcTemplate=new JdbcTemplate(dataSource);
		try
		{
			String query=null;
			query= " SELECT "+
					"	links.domain AS link,"+
					"	tweet.user_name "+
					"	FROM tw_links links "+
					"   INNER JOIN tw_tweet tweet "+
					"	ON links.tweet_id = tweet.id "+
					rtnJoinQuery(tweeterActionVo,false,false,false)+
					rtnFilterQuery(tweeterActionVo,-1)+
					"	LIMIT 1000 "; 

			System.out.println("getTweetDomainLink== "+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setUserName(rs.get("user_name")==null?"":rs.get("user_name").toString());
				twitterVo.setUserId(rs.get("link")==null?"":rs.get("link").toString());
				lst.add(twitterVo);
			}
			if(log.isInfoEnabled())
			{
				log.info("User Name------>"+user+"    method=========getTweetDomainLink()  "+"sql============"+query);
			}

		}
		catch(Exception e) 
		{
			log.error("--------- Exception--------", e);
			e.printStackTrace();
		} 
		return lst; 
	}

	
	public ArrayList<TwitterVo> getTweetUrlLink(TweeterActionVo tweeterActionVo) {
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		String user=(String)httpSession.getAttribute(ApplicationConstants.LOGIN_USER);
		//JdbcTemplate jdbcTemplate=new JdbcTemplate(dataSource);
		try {
			String  query=null;
			query= " SELECT "+
					"	links.link as url,"+
					"	tweet.user_name "+
					"	FROM tw_links links "+
					"   INNER JOIN tw_tweet tweet "+
					"	ON links.tweet_id = tweet.id "+
					rtnJoinQuery(tweeterActionVo,false,false,false)+
					rtnFilterQuery(tweeterActionVo,-1)+
					"	LIMIT 1000 "; 
			System.out.println("getTweetDomainLink== "+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows) {
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setUserName(rs.get("user_name")==null?"":rs.get("user_name").toString());
				twitterVo.setUserId(rs.get("url")==null?"":rs.get("url").toString());
				lst.add(twitterVo);
			}
			if(log.isInfoEnabled()) {
				log.info("User Name------>"+user+"    method=========getTweetUrlLink()  "+"sql============"+query);
			}
		} catch(Exception e) {
			log.error("--------- Exception--------", e);
			e.printStackTrace();
		} 
		return lst; 
	}

	
	public ArrayList<TwitterVo> getFollFollowing(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		String user=(String)httpSession.getAttribute(ApplicationConstants.LOGIN_USER);

		//JdbcTemplate jdbcTemplate=new JdbcTemplate(dataSource);
		try
		{
			String query=null;
			query= " SELECT "+
					"followed, "+
					"follower, "+
					"followed AS followedUserName, "+
					"follower AS followerUserName "+
					"FROM twitter_followers "+
					"	LIMIT 100 "; 
			System.out.println("getFollFollowing== "+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setUserName(rs.get("followerUserName")==null?"":rs.get("followerUserName").toString());
				twitterVo.setUserId(rs.get("followedUserName")==null?"":rs.get("followedUserName").toString());
				lst.add(twitterVo);
			}
			if(log.isInfoEnabled())
			{
				log.info("User Name------>"+user+"    method=========getFollFollowing()  "+"sql============"+query);
			}

		}
		catch(Exception e) 
		{
			log.error("--------- Exception--------", e);
			e.printStackTrace();
		} 
		return lst; 
	}


	
	public ArrayList<TwitterVo> getTweetSentimentTimeLineGraph(TweeterActionVo tweeterActionVo)
	{
		String user=(String)httpSession.getAttribute(ApplicationConstants.LOGIN_USER);
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		//JdbcTemplate jdbcTemplate=new JdbcTemplate(dataSource);
		try
		{
			String  query=null;
			query= " SELECT "+
					"	DAY AS createdAt,"+
					"	COALESCE(tweetCount,0) AS tweetCount "+
					"	FROM (SELECT "+
					"	DATE(FROM_UNIXTIME(tweet.created_at)) AS createdAt,"+
					"	AVG(tweet.sentiment) AS tweetCount "+
					" FROM tw_tweet AS tweet "+
					rtnJoinQuery(tweeterActionVo,true,true,false)+
					rtnFilterQuery(tweeterActionVo,5)+ " and tweet.sentiment !=9 " +
					"	GROUP BY DATE(FROM_UNIXTIME(tweet.created_at)) , tweet.id "+
					"	ORDER BY DATE(FROM_UNIXTIME(tweet.created_at))) AS tbl "+
					"	RIGHT OUTER JOIN calendar "+
					"	ON tbl.createdAt = calendar.day "+
					"	WHERE DATE(calendar.day) >= STR_TO_DATE('"+tweeterActionVo.getDateFrom()+"','%d/%m/%Y') "+
					"	AND DATE(calendar.day) <= STR_TO_DATE('"+tweeterActionVo.getDateTo()+"','%d/%m/%Y') ";
			System.out.println("getTweetSentimentTimeLineGraph== "+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setCreatedAt(rs.get("createdAt")==null?"":rs.get("createdAt").toString());
				twitterVo.setCount(rs.get("tweetCount")==null?"":rs.get("tweetCount").toString());
				lst.add(twitterVo);
			}	
			if(log.isInfoEnabled())
			{
				log.info("User Name------>"+user+"    method=========getTweetSentimentTimeLineGraph()  "+"sql============"+query);
			}

		}
		catch(Exception e) 
		{
			log.error("--------- Exception--------", e);
			e.printStackTrace();
		} 
		return lst; 
	}


	
	public ArrayList<TwitterVo> getRetweetOfTweet(TweeterActionVo tweeterActionVo) 
	{
		String user=(String)httpSession.getAttribute(ApplicationConstants.LOGIN_USER);
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		//JdbcTemplate jdbcTemplate=new JdbcTemplate(dataSource);
		try
		{
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getTweetId()))
			{
				String query=null;
				query=" SELECT tbl.* , "+
						"  COALESCE(CAST(tces.priority AS CHAR(2)),'0') AS priority,tces.hasFollowups AS hasFollowups,"+
						" tces.followupstext AS followupsText,tces.readStatus AS readStatus"+
						"	FROM (SELECT "+
						"		tweet.entity_id AS entity_id,"+
						"	tweet.text AS tweetText,"+
						"	tweet.id  AS tweeterId,"+
						"	COALESCE(tweet.retweet_count,0) AS retweetCount,"+
						"	tw_user.id AS user_id,"+
						"	CONCAT('@',tw_user.screen_name) AS screen_name,"+
						"	tw_user.name AS user_name,"+
						"	DATE_FORMAT(FROM_UNIXTIME(tweet.created_at),'%b %d, %Y %r') AS created_at,"+
						"	DATE(FROM_UNIXTIME(tweet.created_at)) AS start,"+
						"	COALESCE( DATE_FORMAT(FROM_UNIXTIME(tw_user.created_at),'%b %d,%Y %r'),'') AS userCreatedAt,"+
						"	tw_user.profile_image_url AS avatar,"+
						"	tw_user.favourites_count,"+
						"	tw_user.followers_count,"+
						"	tw_user.friends_count,"+
						"	tw_user.statuses_count,"+
						"   CAST(tweet.retweet_flag as CHAR(2))  AS retweetFlag,CAST(tweet.sentiment as CHAR(2)) as sentiment,tweet.sentiment_score"+
						"	FROM tw_tweet tweet "+
						"  INNER JOIN tw_user "+
						" ON tw_user.id = tweet.user_id "+
						"  where tweet.retweet_source_id="+ tweeterActionVo.getTweetId().trim()+
						"  or tweet.id="+ tweeterActionVo.getTweetId().trim()+
						"   ORDER BY  "+getTweetsSortOrder(tweeterActionVo)+
						" ) "+
						"	AS tbl "+
						"	LEFT OUTER JOIN "+   
						"	tw_social_transaction  tces "+
						"	ON  tbl.tweeterId=tces.social_id ";
				if (CommonUtils.stringNotEmpty(tweeterActionVo.getCaseId()))
				{
					query+=	"	AND tces.case_id= "+tweeterActionVo.getCaseId();
				}
				System.out.println("getRetweetOfTweet== "+query);
				List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);

				for(Map<String,Object> rs :rows)
				{
					TwitterVo twitterVo=new TwitterVo();
					twitterVo.setEntityId(rs.get("entity_id")==null?"":rs.get("entity_id").toString());
					twitterVo.setTweetText(rs.get("tweetText")==null?"":rs.get("tweetText").toString());
					twitterVo.setTweeterId(rs.get("tweeterId")==null?"":rs.get("tweeterId").toString());
					twitterVo.setRetweetCount(rs.get("retweetCount")==null?"":rs.get("retweetCount").toString());
					twitterVo.setUserId(rs.get("user_id")==null?"":rs.get("user_id").toString());
					twitterVo.setScreenName(rs.get("screen_name")==null?"":rs.get("screen_name").toString());
					twitterVo.setUserName(rs.get("user_name")==null?"":rs.get("user_name").toString());
					twitterVo.setCreatedAt(rs.get("created_at")==null?"":rs.get("created_at").toString());
					twitterVo.setStart(rs.get("start")==null?"":rs.get("start").toString());
					twitterVo.setUserCreatedAt(rs.get("userCreatedAt")==null?"":rs.get("userCreatedAt").toString());
					twitterVo.setAvatar(rs.get("avatar")==null?"":rs.get("avatar").toString());
					twitterVo.setFavouritesCount(rs.get("favourites_count")==null?"":rs.get("favourites_count").toString());
					twitterVo.setFollowersCount(rs.get("followers_count")==null?"":rs.get("followers_count").toString());
					twitterVo.setFriendsCount(rs.get("friends_count")==null?"":rs.get("friends_count").toString());
					twitterVo.setRetweetFlag(rs.get("retweetFlag")==null?"":rs.get("retweetFlag").toString());
					twitterVo.setSentiment(rs.get("sentiment")==null?"":rs.get("sentiment").toString());
					twitterVo.setSentimentScore(rs.get("sentimentScore")==null?"":rs.get("sentimentScore").toString());
					twitterVo.setPriority(rs.get("priority")==null?"":rs.get("priority").toString());
					twitterVo.setHasFollowsups(rs.get("hasFollowups")==null?"":rs.get("hasFollowups").toString());
					twitterVo.setFollowupsText(rs.get("followupsText")==null?"":rs.get("followupsText").toString());
					twitterVo.setReadStatus(rs.get("readStatus")==null?"":rs.get("readStatus").toString());
					twitterVo.setTweetCount(rs.get("statuses_count")==null?"":rs.get("statuses_count").toString());
					lst.add(twitterVo);
				}
				if(log.isInfoEnabled())
				{
					log.info("User Name------>"+user+"    method=========getRetweetOfTweet()  "+"sql============"+query);
				}
			}
		}
		catch(Exception e) 
		{
			log.error("--------- Exception--------", e);
			e.printStackTrace();
		} 
		return lst; 
	}

	
	public void setTweetIdForReTweet(TweeterActionVo tweeterActionVo)
	{
		//JdbcTemplate jdbcTemplate=new JdbcTemplate(dataSource);
		String user=(String)httpSession.getAttribute(ApplicationConstants.LOGIN_USER);
		try
		{
			String  query=null;
			Object[] args=null;
			query= " INSERT ignore INTO tw_get_retweet(tweet_id,flag) VALUES(?,?)";
			args = new Object[] {
					tweeterActionVo.getTweetId(),
					"0"
			};
			jdbcTemplate.update(query, args);
			if(log.isInfoEnabled())
			{
				log.info("User Name------>"+user+"    method=========setTweetIdForReTweet()  "+"sql============"+query);
			}
		}	
		catch(Exception e) 
		{
			log.error("--------- setTweetIdForReTweet()--------", e);
		} 		
	}

	
	public ArrayList<TwitterVo> checkRetweetStatus(TweeterActionVo tweeterActionVo) 
	{
		//JdbcTemplate jdbcTemplate=new JdbcTemplate(dataSource);
		String user=(String)httpSession.getAttribute(ApplicationConstants.LOGIN_USER);
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		try
		{
			String  query=null;
			Object[] args=null;
			query= " Select tweet_id from tw_get_retweet where tweet_id=? and flag=?";
			args = new Object[] {
					tweeterActionVo.getTweetId(),
					"0"
			};
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query,args);
			for(Map<String,Object> rs :rows)
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setTweeterId(rs.get("tweet_id")==null?"":rs.get("tweet_id").toString());
				lst.add(twitterVo);
			}
			if(log.isInfoEnabled())
			{
				log.info("User Name------>"+user+"  method=========checkRetweetStatus() "+"sql============"+query);
			}
		}	
		catch(Exception e)
		{
			log.error("--------- checkRetweetStatus()--------", e);
		} 		
		return lst;
	}

	
	public ArrayList<TwitterVo> getTwitterApi(String type)
	{
		//JdbcTemplate jdbcTemplate=new JdbcTemplate(dataSource);
		String user=(String)httpSession.getAttribute(ApplicationConstants.LOGIN_USER);
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		try
		{
			String query=" SELECT CONCAT(consumer_key,',',consumer_secret,',',access_token,',',access_token_secret) as apikey "
					   + " FROM api_keys "
					   + " ORDER BY id DESC ";
			System.out.println("search api queyr :"+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setApiKeys(rs.get("apikey")==null?"":rs.get("apikey").toString());
				lst.add(twitterVo);
			}
			if(log.isInfoEnabled())
			{
				log.info("User Name------>"+user+"    method=========getTwitterApi()  "+"sql============"+query);
			}
		}	
		catch(Exception e)
		{
			log.error("--------- getTwitterApi()--------", e);
		} 		
		return lst;
	}

	
	public void crawlAllTweetsOfUser(ArrayList<TweetTblVo> tweetTblVos,
			ArrayList<TweetHashTagsTblVo> hashTagsTblVos,
			ArrayList<TweetMentionTblVo> mentionTblVos,
			ArrayList<TweetLinksTblVo> tweetLinksTblVos,
			ArrayList<TweetUserTblVo> tweetUserTblVos, int entityId)
	{

		Object[] args=null;
		String query=null;
		try
		{
			if(tweetTblVos.size()==0){return;}
			// Tweets
			List<Object[]> inputListTweet = new ArrayList<Object[]>();
			List<Object[]> inputListHashtag = new ArrayList<Object[]>();
			List<Object[]> inputListUser = new ArrayList<Object[]>();
			List<Object[]> inputListMention = new ArrayList<Object[]>();
			List<Object[]> inputListLink = new ArrayList<Object[]>();
			for (TweetTblVo tweetTblVo : tweetTblVos) 
			{
				args= new Object[] {tweetTblVo.getId().trim(),entityId,tweetTblVo.getCreatedAt().toString(),tweetTblVo.getInReplyToScreenName(),tweetTblVo.getInReplyToStatusId(),tweetTblVo.getInReplyToUserId(),
						tweetTblVo.getLang(),tweetTblVo.getRetweetFlag(),tweetTblVo.getRetweetSourceId(),tweetTblVo.getSource(),tweetTblVo.getText(),tweetTblVo.getUserId(),tweetTblVo.getUserScreenName(),tweetTblVo.getRetweetCount(),tweetTblVo.getLatitude(),tweetTblVo.getLongitude(),
						tweetTblVo.getGeoLevel(),tweetTblVo.getPlace(),tweetTblVo.getCity(),tweetTblVo.getCountry(),tweetTblVo.getCountryCode(),
						tweetTblVo.getFavouriteCount(),tweetTblVo.getPosibleSensitive(),tweetTblVo.getIsTruncated(),
						tweetTblVo.getRetweetCount(),tweetTblVo.getFavouriteCount()
				};
				inputListTweet.add(args);
			}

			//Hashtag
			for (TweetHashTagsTblVo tweetHashTagsTblVo : hashTagsTblVos)
			{
				args= new Object[] {tweetHashTagsTblVo.getHashTag().trim(),tweetHashTagsTblVo.getTweetId()};
				inputListHashtag.add(args);
			}

			//Mention
			for (TweetMentionTblVo tweetMentionTblVo : mentionTblVos) 
			{
				args= new Object[] {tweetMentionTblVo.getUserId().trim(),tweetMentionTblVo.getUserName().trim(),tweetMentionTblVo.getTweetId().trim()};
				inputListMention.add(args);
			}

			//Links
			for (TweetLinksTblVo tweetLinksTblVo : tweetLinksTblVos) 
			{
				args= new Object[] {tweetLinksTblVo.getLink().trim(),tweetLinksTblVo.getTweetId().trim(),tweetLinksTblVo.getType().trim(),
						tweetLinksTblVo.getDomain().trim(),tweetLinksTblVo.getShortLink().trim(),tweetLinksTblVo.getExpandedUrl().trim()
				};
				inputListLink.add(args);
			}

			//User
			for (TweetUserTblVo tweetUserTblVo : tweetUserTblVos) 
			{
				args= new Object[] {tweetUserTblVo.getId().trim(),tweetUserTblVo.getCreatedAt().trim(),tweetUserTblVo.getDescription().trim(),tweetUserTblVo.getFavouritesCount().trim(),tweetUserTblVo.getFollowersCount().trim(),tweetUserTblVo.getFriendsCount().trim(),
						tweetUserTblVo.getGeoEnabled().trim(),tweetUserTblVo.getLang().trim(),tweetUserTblVo.getListedCount().trim(),tweetUserTblVo.getLocation().trim(),tweetUserTblVo.getScreenName().trim(),tweetUserTblVo.getName().trim(),
						tweetUserTblVo.getProfileImageUrl().trim(),tweetUserTblVo.getProfileImageUrlHttps(),tweetUserTblVo.getScreenName().trim(),tweetUserTblVo.getStatusesCount().trim(),tweetUserTblVo.getTimeZone().trim(),tweetUserTblVo.getUrl(),tweetUserTblVo.getUtcOffset(),
						tweetUserTblVo.getFavouritesCount(),tweetUserTblVo.getFollowersCount(),tweetUserTblVo.getFriendsCount(),tweetUserTblVo.getListedCount(),tweetUserTblVo.getProfileImageUrl(),tweetUserTblVo.getStatusesCount()
				};
				inputListUser.add(args);
			}


			if(inputListTweet.size()>0)
			{
				query=" insert ignore into tw_tweet(id,entity_id,created_at,in_reply_to_screen_name,in_reply_to_status_id,in_reply_to_user_id,"
						+ " lang,retweet_flag,retweet_source_id,source,text,user_id,user_name,retweet_count,latitude,longitude,"
						+ " geoLevel,geoPlace,city,country,country_code,favourite_count,posible_sensitive,isTruncated) "
						+ " values(?,?,?,?,?,?, "
						+ " ?,?,?,?,?,?,?,?,?,?, "
						+ " ?,?,?,?,?,?,?,? ) on duplicate key update  retweet_count=?,favourite_count=? ";
				jdbcTemplate.batchUpdate(query,inputListTweet);
			}

			if(inputListHashtag.size()>0)
			{
				query=" insert ignore into tw_hashtags(hashtag,tweet_id)"
						+ " values(?,?)";
				jdbcTemplate.batchUpdate(query,inputListHashtag);
			}

			if(inputListMention.size()>0)
			{
				query=" insert ignore into tw_mentions(userid,username,tweetid)"
						+ " values(?,?,?)";
				jdbcTemplate.batchUpdate(query,inputListMention);
			}

			if(inputListLink.size()>0)
			{
				query=" insert ignore into tw_links(link,tweet_id,link_type,domain,media_text,expanded_url)"
						+ " values(?,?,?,?,?,?)";
				jdbcTemplate.batchUpdate(query,inputListLink);
			}

			if(inputListUser.size()>0)
			{
				query=" insert ignore into tw_user"
						+ "(id,created_at,description,favourites_count,followers_count,friends_count,geo_enabled,lang,listed_count,location,"
						+ "username,name,profile_image_url,profile_image_url_https,screen_name,statuses_count,time_zone,url,utc_offset)"
						+ "  values("
						+ "?,?,?,?,?,?,?,?,?,?,"
						+ "?,?,?,?,?,?,?,?,?"
						+ ") on duplicate key update favourites_count=?,followers_count=?,friends_count=?,listed_count=?,profile_image_url=?,statuses_count=?  ";
				jdbcTemplate.batchUpdate(query,inputListUser);
			}
		}	
		catch (Exception e) 
		{
			log.error(e.getMessage());
		} 		
	}

	
	public ArrayList<String> getAllTweetsByProfileEntity(String screenName) 
	{
		//JdbcTemplate jdbcTemplate=new JdbcTemplate(dataSource);
		String user=(String)httpSession.getAttribute(ApplicationConstants.LOGIN_USER);
		ArrayList<String> lst=new ArrayList<String>();
		try
		{
			String query=" select distinct id as tweetId from tw_tweet where user_name=? ";
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query,new Object[] {screenName});
			for(Map<String,Object> rs :rows)
			{
				lst.add(rs.get("tweetId")==null?"":rs.get("tweetId").toString());
			}
			if(log.isInfoEnabled())
			{
				log.info("User Name------>"+user+"    method=========getAllTweetsByProfileEntity()  "+"sql============"+query);
			}
		}	
		catch(Exception e) 
		{
			log.error("--------- getAllTweetsByProfileEntity()--------", e);
		} 		
		return lst;
	}

	
	public void crawlAllFolowerFollowingOfUser(ArrayList<TweetUserTblVo> tweetUserTblVos, String screenName,String userId, String type) 
	{
		//JdbcTemplate jdbcTemplate=new JdbcTemplate(dataSource);
		String user=(String)httpSession.getAttribute(ApplicationConstants.LOGIN_USER);
		Object[] args=null;
		String query=null;
		List<Object[]> inputList1 = new ArrayList<Object[]>();
		List<Object[]> inputList2 = new ArrayList<Object[]>();
		List<Object[]> inputList3 = new ArrayList<Object[]>();

		try
		{
			if(tweetUserTblVos.size()==0){return;}
			//User
			for(TweetUserTblVo tweetUserTblVo : tweetUserTblVos)
			{
				args= new Object[] {tweetUserTblVo.getId().trim(),tweetUserTblVo.getCreatedAt().trim(),tweetUserTblVo.getDescription().trim(),tweetUserTblVo.getFavouritesCount().trim(),tweetUserTblVo.getFollowersCount().trim(),tweetUserTblVo.getFriendsCount().trim(),
						tweetUserTblVo.getGeoEnabled().trim(),tweetUserTblVo.getLang().trim(),tweetUserTblVo.getListedCount().trim(),tweetUserTblVo.getLocation().trim(),tweetUserTblVo.getScreenName().trim(),tweetUserTblVo.getName().trim(),
						tweetUserTblVo.getProfileImageUrl().trim(),tweetUserTblVo.getProfileImageUrlHttps(),tweetUserTblVo.getScreenName().trim(),tweetUserTblVo.getStatusesCount().trim(),tweetUserTblVo.getTimeZone().trim(),tweetUserTblVo.getUrl(),tweetUserTblVo.getUtcOffset(),
						tweetUserTblVo.getFavouritesCount(),tweetUserTblVo.getFollowersCount(),tweetUserTblVo.getFriendsCount(),tweetUserTblVo.getListedCount(),tweetUserTblVo.getProfileImageUrl(),tweetUserTblVo.getStatusesCount()
				};
				inputList1.add(args);
				if(type.equals("following"))
				{
					args= new Object[]{tweetUserTblVo.getId(),tweetUserTblVo.getScreenName(),userId,screenName};
					inputList2.add(args);
				}
				else if(type.equals("follower"))
				{
					args= new Object[]{userId,screenName,tweetUserTblVo.getId(),tweetUserTblVo.getScreenName()};
					inputList3.add(args);
				}
			}

			if(inputList1.size()>0)
			{
				query=" insert ignore into tw_user(id,created_at,description,favourites_count,followers_count,friends_count,"
						+ " geo_enabled,lang,listed_count,location,username,name,"
						+ " profile_image_url,profile_image_url_https,screen_name,statuses_count,time_zone,url,utc_offset)"
						+ " values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) on duplicate key update favourites_count=?,followers_count=?,friends_count=?,listed_count=?,profile_image_url=?,statuses_count=?";
				jdbcTemplate.batchUpdate(query, inputList1);
				query="insert ignore into twitter_followers (followed,followed_name,follower,follower_name)values(?,?,?,?)";
				if(type.equals("following"))
				{
					jdbcTemplate.batchUpdate(query, inputList2);
				}
				else if(type.equals("follower"))
				{
					jdbcTemplate.batchUpdate(query, inputList3);
				}
			}
			if(log.isInfoEnabled())
			{
				log.info("User Name------>"+user+"    method=========crawlAllFolowerFollowingOfUser()  "+"sql============"+query);
			}
		}	
		catch(Exception e) 
		{
			log.error("--------- crawlAllFolowerFollowingOfUser()--------", e);
			e.printStackTrace();
		} 		
	}

	
	public ArrayList<TwitterVo> getUserIdByScreenName(String screenName)
	{
		ArrayList<TwitterVo> lst=new  ArrayList<TwitterVo>();
		String user=(String)httpSession.getAttribute(ApplicationConstants.LOGIN_USER);
		try
		{
			String subQuery=  "\"query\": {\n"+
					"\"term\": {\n"+
					"\"user.userName\": {\n"+
					"\"value\": \""+screenName+"\"\n"+
					"}\n"+
					"}\n"+
					"}\n";
			String query="{\n"
					+subQuery
					+ "}\n";
			System.out.println("getUserIdByScreenName**********"+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType("tw_tweet")
					.build();
			SearchResult result = client.execute(search);
			List<Tw_Tweet> testLst= result.getSourceAsObjectList(Tw_Tweet.class);
			for (Tw_Tweet tw_Tweet : testLst)
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setName(tw_Tweet.getUserName());
				twitterVo.setUserId(tw_Tweet.getUserId());
				twitterVo.setAvatar(tw_Tweet.getUser().getProfileImageUrl());
				lst.add(twitterVo);
			}
			if(log.isInfoEnabled())
			{
				log.info("User Name------>"+user+"    method=========getUserIdByScreenName()  "+"sql============"+query);
			}
		}	
		catch(Exception e) 
		{
			log.error("--------- getUserIdByScreenName()--------", e);
		} 		
		return lst;
	}

	
	public void crawlAllListOfUser(ArrayList<TwitterUserListVo> twitterUserListVos) 
	{
		String user=(String)httpSession.getAttribute(ApplicationConstants.LOGIN_USER);
		try
		{
			if(twitterUserListVos.size()>0)
			{
				for(TwitterUserListVo twitterUserListVo : twitterUserListVos)
				{
					//*******tw_list*********
					String query=" insert  into tw_list(id,"
							+ "slug,"
							+ "name,"
							+ "created_at,"
							+ "uri,"
							+ "subscriber_count,"
							+ "id_str,"
							+ "member_count,"
							+ "description,"
							+ "full_name,"
							+ ") "
							+ " values(?,?,?,?,?,?,?,?,?,?) on duplicate key update subscriber_count='"+twitterUserListVo.getSubscriber_count()+"',member_count='"+twitterUserListVo.getMember_count()+"' ";
					jdbcTemplate.update(query, new Object[] {
							twitterUserListVo.getId(),
							twitterUserListVo.getSlug(),
							twitterUserListVo.getName(),
							twitterUserListVo.getCreated_at(),
							twitterUserListVo.getUri(),
							twitterUserListVo.getSubscriber_count(),
							twitterUserListVo.getId_str(),
							twitterUserListVo.getMember_count(),
							twitterUserListVo.getDescription(),
							twitterUserListVo.getFull_name()
					});
					log.info("User Name------>"+user+"    method=========crawlAllListOfUser() tw_list  "+"sql============"+query);

					//********************tw_list_subscriber*******************
					query=" insert ignore  into tw_list_subscriber(user_name,"
							+ "list_id,"
							+ "list_name)"
							+ " values(?,?,?) ";
					jdbcTemplate.update(query, new Object[] {
							twitterUserListVo.getUserName(),
							twitterUserListVo.getId(),
							twitterUserListVo.getName()
					});
					log.info("User Name------>"+user+"    method=========crawlAllListOfUser() tw_list_subscriber  "+"sql============"+query);
				}
			}
		}	
		catch (Exception e) 
		{
			log.error("--------- crawlAllListOfUser()--------", e);
		} 		
	}

	private String rtnQueryStringForUserDetalReport(TweeterActionVo tweeterActionVo) 
	{
		String dateFilter="";
		if(tweeterActionVo.getDateFrom().equals("") || tweeterActionVo.getDateTo().equals(""))
		{		
			dateFilter="";	
		}
		else
		{
			Long dateFrom=TwitterConstant.convertDateToTimeStamp(tweeterActionVo.getDateFrom());
			Long dateTo=TwitterConstant.convertDateToTimeStamp(tweeterActionVo.getDateTo());
			dateFilter=	",{\n"+
					"\"range\": {\n"+
					"\"articlePublishDate\": {\n"+
					"\"gte\": "+dateFrom+",\n"+
					"\"lte\": "+dateTo+"\n"+
					"}\n"+
					"}\n"+ 
					"}\n";
		}
		
		String userFilter= ",{\n"+
				"\"term\": {\n"+
				"\"articleAuthor\": {\n"+
				"\"value\": \""+tweeterActionVo.getUserName()+"\"\n"+
				"}\n"+
				"}\n"+
				"}\n";

		String srcFilter= ",{\n"+
				"\"term\": {\n"+
				"\"articleSource\": {\n"+
				"\"value\": \"tw\"\n"+
				"}\n"+
				"}\n"+
				"}\n";

		String joinQuery=""+
				"\"query\":{\n"+
				"\"bool\":{\n"+
				"\"filter\": {\n"+
				"\"bool\": {\n"+
				"\"must\": [\n"+
				"{}"+
				dateFilter+
				srcFilter+
				userFilter
				+ "],\n"+
				"\"must_not\": [\n"
				+ "{}"
				+ "]\n"
				+ "}\n"
				+ "}\n"
				+ "}\n"
				+ "}\n";	
		return joinQuery;
	}

	
	public ArrayList<TwitterVo> getTweetsUsrDtlRpt(TweeterActionVo tweeterActionVo)
	{
		ArrayList<TwitterVo> list=new ArrayList<TwitterVo>();
		try
		{
			int from=0;
			int size=1000;	
			if(CommonUtils.stringNotEmpty(tweeterActionVo.getIsRpt()))
			{
				if(CommonUtils.stringNotEmpty(tweeterActionVo.getNoTweet()))
				{
					from=0;
					size=Integer.parseInt(tweeterActionVo.getNoTweet());
				}
			}
			else
			{
				from=Integer.parseInt(tweeterActionVo.getRowNum());
				size=50;
			}

			String sortQuery="{\n"
					+"\"articlePublishDate\": {\n"
					+"\"order\": \"desc\""
					+"}\n"
					+"}\n";

			String sort=",\"sort\": [\n"
					+sortQuery
					+"]\n";	

			String query="{\n"
					+ "      \"from\":"+from+",\n"
					+ "      \"size\":"+size+",\n"
					+rtnQueryStringForUserDetalReport(tweeterActionVo)+
					sort
					+ "}\n";
			System.out.println("**getTweetsUsrDtlRpt()***** "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();
			SearchResult result = client.execute(search);
			List<Article_Datacollection_New> testLst = result.getSourceAsObjectList(Article_Datacollection_New.class);
			for(Article_Datacollection_New article_Datacollection_New : testLst) 
			{
				TwitterVo twitterVo=new TwitterVo();
				String link=article_Datacollection_New.getArticleLinkUrl();;

				switch(article_Datacollection_New.getArticleSource()) 
				{
				case "tw":
					link="https://twitter.com/"+article_Datacollection_New.getArticleAuthor()+"/status/"+article_Datacollection_New.getArticleId();
					break;
				case "yt":
					link=article_Datacollection_New.getArticleLinkUrl();
					break;
				case "fb":
					break;
				case "insta":
					break;
				case "dm":
					break;
				
				case "wp":
					break;
				case "tm":
					break;
				case "wb":
					break;
				case "article":
					link=article_Datacollection_New.getArticleLinkUrl();
					break;
				

				default:
					break;
				}
				//System.out.println("Long.toString(result.getTotal()):==== "+Long.toString(result.getTotal()));

				twitterVo.setLink(link);
				//twitterVo.setTotalTweetCount(Integer.toString(result.getTotal()));
				twitterVo.setTotalTweetCount(Long.toString(result.getTotal()));
				twitterVo.setArticleId(article_Datacollection_New.getArticleId());
				twitterVo.setArticleAuthor(article_Datacollection_New.getArticleAuthor());
				twitterVo.setArticleAuthorId(article_Datacollection_New.getArticleAuthorId());
				twitterVo.setArticleAuthorImage(article_Datacollection_New.getArticleAuthorImage());
				twitterVo.setArticleAuthorImageUrlLocal(article_Datacollection_New.getArticleAuthorImageUrlLocal());
				twitterVo.setArticlePublishDate(CommonUtils.convertUnixTimeToDateDisplayFormat((article_Datacollection_New.getArticlePublishDate())));
				twitterVo.setArticleTitle(article_Datacollection_New.getArticleTitle());
				twitterVo.setArticleSubTitle(article_Datacollection_New.getArticleSubTitle());
				twitterVo.setArticleSentiment(article_Datacollection_New.getArticleSentiment());
				twitterVo.setArticleClassification(article_Datacollection_New.getArticleClassification());
				twitterVo.setPriority("0");

				if(article_Datacollection_New.getArticleMarked() !=null)
				{
					if(article_Datacollection_New.getArticleMarked().size()>0)
					{
						String user=(String)httpSession.getAttribute(ApplicationConstants.LOGINUSERID);
						if(article_Datacollection_New.getArticleMarked().indexOf(Integer.parseInt(user))>-1)
						{
							twitterVo.setPriority("1");
						}
					}
				}

				twitterVo.setTweet(article_Datacollection_New.getTweet());
				twitterVo.setYoutube(article_Datacollection_New.getYoutube());
				twitterVo.setDailymotion(article_Datacollection_New.getDailymotion());
				twitterVo.setInstagram(article_Datacollection_New.getInstagram());
				twitterVo.setFacebook(article_Datacollection_New.getFacebook());
				twitterVo.setWordpress(article_Datacollection_New.getWordpress());
				twitterVo.setBlogger(article_Datacollection_New.getBlogger());
				twitterVo.setArticleSource(article_Datacollection_New.getArticleSource());
				twitterVo.setArticleType(article_Datacollection_New.getArticleType());
				twitterVo.setArticleMedia(article_Datacollection_New.getArticleMedia());
				list.add(twitterVo);
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		} 
		System.out.println("list.size():----- "+list.size());
		System.out.println("list:------------ "+list);
		return list; 
		
	}


	
	public ArrayList<TwitterVo> getHashTagsUsrDtlRpt(TweeterActionVo tweeterActionVo)
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		try
		{
			int size=50;	
			String sortQuery=TwitterConstant.getSortForEsTermAgg("cntdesc");
			String subQuery=rtnQueryStringForUserDetalReport(tweeterActionVo);
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"termagg\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\"articleHashTag\"\n,"+
					"\"size\":\""+size+"\"\n,"+
					sortQuery+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";
			System.out.println("*****getHashTagsUsrDtlRpt()***** "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			TermsAggregation terms = result.getAggregations().getTermsAggregation("termagg");
			List<Entry>  entry=  terms.getBuckets();
			for (Entry entry2 : entry) 
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setHashtag(entry2.getKey());
				twitterVo.setHashCount(Long.toString(entry2.getCount()));
				twitterVo.setHashTagId(entry2.getKey());
				lst.add(twitterVo);
			}
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		} 
		return lst; 
	}

	
	public ArrayList<TwitterVo> getLinkUsrDtlRpt(TweeterActionVo tweeterActionVo)
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		try
		{
			int size=200;
			String linkType="domain";
			if(tweeterActionVo.getMediaType().equals("do"))
			{
			}
			else 
			{
				linkType="url";
			}
			String sortQuery=null;
			if(!tweeterActionVo.getMediaType().equals("do"))
			{
				sortQuery=TwitterConstant.getSortForEsTermAgg("cntdesc");
			}
			else
			{
				sortQuery=TwitterConstant.getSortForEsTermAgg("cntdesc");
			}

			String subQuery=rtnQueryStringForUserDetalReport(tweeterActionVo);
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"termagg\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\""+linkType+"\"\n,"+
					"\"size\":\""+size+"\"\n,"+
					sortQuery+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";
			System.out.println(" getLinkUsrDtlRpt "+linkType+"********* "+query);
			Search search = new Search.Builder(query)
					// multiple index or types can be added.
					.addIndex(TwitterConstant.getDbname())
					.addType("tw_tweet")
					.build();

			SearchResult result = client.execute(search);
			TermsAggregation terms = result.getAggregations().getTermsAggregation("termagg");
			List<Entry>  entry=  terms.getBuckets();
			for (Entry entry2 : entry) {
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setLink(entry2.getKey());
				twitterVo.setLinkCount(Long.toString(entry2.getCount()));
				twitterVo.setUrl(entry2.getKey());
				lst.add(twitterVo);
			}
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		} 
		return lst; 
	}

	
	public ArrayList<TwitterVo> getMediaUsrDtlRpt(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		try
		{
			int size=100;	
			String sortQuery=TwitterConstant.getSortForEsTermAgg("cntdesc");
			String linkType="image";
			if(tweeterActionVo.getMediaType().equals("i"))
			{
				linkType="image";	
			}
			else 
			{
				linkType="video";
			}
			String subQuery=rtnQueryStringForUserDetalReport(tweeterActionVo);
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"termagg\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\""+linkType+"\"\n,"+
					"\"size\":\""+size+"\"\n,"+
					sortQuery+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";

			System.out.println("linkType:======= "+query);
			Search search = new Search.Builder(""+query)
					// multiple index or types can be added.
					.addIndex(TwitterConstant.getDbname())
					.addType("tw_tweet")
					.build();

			SearchResult result = client.execute(search);
			TermsAggregation terms = result.getAggregations().getTermsAggregation("termagg");
			List<Entry>  entry=  terms.getBuckets();
			for (Entry entry2 : entry) 
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setLink(entry2.getKey());
				twitterVo.setLinkCount(Long.toString(entry2.getCount()));
				twitterVo.setUrl(entry2.getKey());
				twitterVo.setTweeterId(entry2.getKey());
				lst.add(twitterVo);
			}
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		} 
		return lst; 
	}


	public ArrayList<TwitterVo> userDetailReportFollowers(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		try
		{
			String query=" SELECT follower, follower_name, follower_screen_name, follower_img, follower_localImagePath from twitter_followers WHERE followed_screen_name='"+tweeterActionVo.getUserName()+"' LIMIT 400";
			System.out.println("userDetailReportFollowers== "+query);
			List<Map<String, Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String, Object> rs :rows)
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setName(rs.get("follower_name")==null?"":rs.get("follower_name").toString());
				twitterVo.setUserName(rs.get("follower_screen_name")==null?"":rs.get("follower_screen_name").toString());
				twitterVo.setUserId(rs.get("follower")==null?"":rs.get("follower").toString());
				twitterVo.setArticleAuthorImage(rs.get("follower_img")==null?"":rs.get("follower_img").toString());
				twitterVo.setArticleAuthorImageUrlLocal(rs.get("follower_localImagePath")==null?"":rs.get("follower_localImagePath").toString());
				lst.add(twitterVo);
			}
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		} 
		return lst; 
	}


	
	public ArrayList<TwitterVo> userDetailReportFollowing(TweeterActionVo tweeterActionVo)
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		try
		{
			String query=" SELECT followed, followed_name, followed_screen_name, followed_img, followed_localImagePath from twitter_followers where follower_screen_name='"+tweeterActionVo.getUserName()+"' LIMIT 400";
			System.out.println("userDetailReportFollowing== "+query);
			List<Map<String, Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String, Object> rs :rows)
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setName(rs.get("followed_name")==null?"":rs.get("followed_name").toString());
				twitterVo.setUserName(rs.get("followed_screen_name")==null?"":rs.get("followed_screen_name").toString());
				twitterVo.setUserId(rs.get("followed")==null?"":rs.get("followed").toString());
				twitterVo.setArticleAuthorImage(rs.get("followed_img")==null?"":rs.get("followed_img").toString());
				twitterVo.setArticleAuthorImageUrlLocal(rs.get("followed_localImagePath")==null?"":rs.get("followed_localImagePath").toString());
				lst.add(twitterVo);
			}
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		} 
		return lst; 
	}


	public ArrayList<TwitterVo> userInfluerncerInfluencee(TweeterActionVo tweeterActionVo) 
	{
		String user=(String)httpSession.getAttribute(ApplicationConstants.LOGIN_USER);
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		//JdbcTemplate jdbcTemplate=new JdbcTemplate(dataSource);
		try
		{
			String  query=null;
			if(tweeterActionVo.getInfluenceType().equals("influencer"))
			{
				query= "SELECT tw_influence.influencer as user FROM tw_influence  where  tw_influence.influence='"+tweeterActionVo.getUserName()+"' ";
			}
			else if(tweeterActionVo.getInfluenceType().equals("influence"))
			{
				query= "SELECT tw_influence.influence as user FROM tw_influence  where  tw_influence.influencer='"+tweeterActionVo.getUserName()+"' ";
			}
			System.out.println("userInfluerncerInfluencee== "+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setUserName(rs.get("user")==null?"":rs.get("user").toString());
				lst.add(twitterVo);
			}	
			if(log.isInfoEnabled())
			{
				log.info("User Name------>"+user+"    method=========userInfluerncerInfluencee()  "+"sql============"+query);
			}

		}
		catch(Exception e) 
		{
			log.error("--------- Exception--------", e);
			e.printStackTrace();
		} 
		return lst; 
	}


	public ArrayList<TwitterVo> userTopRetweet(TweeterActionVo tweeterActionVo)
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		try
		{
			int size=50;
			String sortQuery=TwitterConstant.getSortForEsTermAgg("cntdesc");
			String subQuery="\"query\": {\n"+
					"\"bool\": {\n"+
					"\"filter\": {\n"+
					"\"bool\": {\n"+
					"\"must\": [\n"+
					"{},"+
					"{\n"+
					"\"term\": {\n"+
					"\"articleSource\": {\n"+
					"\"value\": \"tw\"\n"+
					"}\n"+
					"}\n"+
					"},\n"+

			            "{\n"+
			            "\"term\": {\n"+
			            "\"articleAuthor\": {\n"+
			            "\"value\": \""+tweeterActionVo.getUserName()+"\"\n"+
			            "}\n"+
			            "}\n"+
			            "},\n"+

			            "{\n"+
			            "\"exists\": {\n"+
			            "\"field\": \"tweet.tweetRetweetUserScreenName\"\n"+
			            "}\n"+
			            "}\n"+
			            "]\n"+

			        "}\n"+
			        "}\n"+
			        "}\n"+
			        "}\n";

			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"termagg\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\"tweet.tweetRetweetUserScreenName\"\n,"+
					"\"size\":\""+size+"\"\n,"+
					sortQuery+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";
			System.out.println("*****userTopRetweet()***** "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			TermsAggregation terms = result.getAggregations().getTermsAggregation("termagg");
			List<Entry>  entry=  terms.getBuckets();
			for (Entry entry2 : entry) 
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setUserName(entry2.getKey());
				twitterVo.setUserCount(Long.toString(entry2.getCount()));
				lst.add(twitterVo);
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return lst; 
	}

	public ArrayList<TwitterVo> userTopReply(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		try
		{
			int size=50;
			//TwitterConstant.getSizeForEsTermAgg(tweeterActionVo, tweeterActionVo.getNoHashtag());	
			String sortQuery=TwitterConstant.getSortForEsTermAgg("cntdesc");
			String subQuery="\"query\": {\n"+
					"\"bool\": {\n"+
					"\"filter\": {\n"+
					"\"bool\": {\n"+
					"\"must\": [\n"+
					"{},"+
					"{\n"+
					"\"term\": {\n"+
					"\"articleSource\": {\n"+
					"\"value\": \"tw\"\n"+
					"}\n"+
					"}\n"+
					"},\n"+

			            "{\n"+
			            "\"term\": {\n"+
			            "\"articleAuthor\": {\n"+
			            "\"value\": \""+tweeterActionVo.getUserName()+"\"\n"+
			            "}\n"+
			            "}\n"+
			            "},\n"+

			            "{\n"+
			            "\"exists\": {\n"+
			            "\"field\": \"tweet.tweetInReplyToScreenName\"\n"+
			            "}\n"+
			            "}\n"+
			            "]\n"+

			        "}\n"+
			        "}\n"+
			        "}\n"+
			        "}\n";

			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"termagg\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\"tweet.tweetInReplyToScreenName\"\n,"+
					"\"size\":\""+size+"\"\n,"+
					sortQuery+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";

			System.out.println("*****userTopReply()***** "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			TermsAggregation terms = result.getAggregations().getTermsAggregation("termagg");
			List<Entry>  entry=  terms.getBuckets();
			for (Entry entry2 : entry) 
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setUserName(entry2.getKey());
				twitterVo.setUserCount(Long.toString(entry2.getCount()));
				lst.add(twitterVo);
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return lst; 
	}


	public ArrayList<TwitterVo> userTopSource(TweeterActionVo tweeterActionVo)
	{
		ArrayList<TwitterVo> list=new ArrayList<TwitterVo>();
		try
		{
			int size=50;	
			String sortQuery=TwitterConstant.getSortForEsTermAgg("cntdesc");
			String subQuery=rtnQueryStringForUserDetalReport(tweeterActionVo);
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"termagg\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\"tweet.tweetSource\"\n,"+
					"\"size\":\""+size+"\"\n,"+
					sortQuery+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";

			System.out.println("*****userTopSource()***** "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			TermsAggregation terms = result.getAggregations().getTermsAggregation("termagg");
			List<Entry>  entry=  terms.getBuckets();
			for(Entry entry2 : entry) 
			{
				TwitterVo twitterVo=new TwitterVo();
				Document doc = Jsoup.parse(entry2.getKey());
				Element source = doc.select("a").first();
				twitterVo.setUserName(source.text());
				twitterVo.setUserCount(Long.toString(entry2.getCount()));
				list.add(twitterVo);
			}
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		} 
		return list; 
	}

	
	public ArrayList<TwitterVo> userTopList(TweeterActionVo tweeterActionVo) 
	{
		String user=(String)httpSession.getAttribute(ApplicationConstants.LOGIN_USER);
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		//JdbcTemplate jdbcTemplate=new JdbcTemplate(dataSource);
		try
		{
			String query=null;
			query=" SELECT * FROM tw_list_subscriber WHERE user_name='"+tweeterActionVo.getUserName()+"' " ;
			System.out.println("userTopList== "+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setUserName(rs.get("list_name")==null?"":rs.get("list_name").toString());
				lst.add(twitterVo);
			}	
			if(log.isInfoEnabled())
			{
				log.info("User Name------>"+user+"    method=========userTopList()  "+"sql============"+query);
			}
		}
		catch(Exception e) 
		{
			log.error("--------- Exception--------", e);
			e.printStackTrace();
		} 
		return lst; 
	}

	
	public ArrayList<TwitterVo> getMentionUsrDtlRpt(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		try
		{
			int size=50;	
			String sortQuery=TwitterConstant.getSortForEsTermAgg("cntdesc");
			String subQuery=rtnQueryStringForUserDetalReport(tweeterActionVo);
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"termagg\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\"articleMention\"\n,"+
					"\"size\":\""+size+"\"\n,"+
					sortQuery+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";

			System.out.println("*****getMentionUsrDtlRpt()***** "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			TermsAggregation terms = result.getAggregations().getTermsAggregation("termagg");
			List<Entry>  entry=  terms.getBuckets();
			for (Entry entry2 : entry) 
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setUserName(entry2.getKey());
				twitterVo.setUserCount(Long.toString(entry2.getCount()));
				twitterVo.setUserId(entry2.getKey());
				lst.add(twitterVo);
			}
		}
		catch(Exception e) 
		{
			log.error("--------- Exception--------", e);
			e.printStackTrace();
		} 
		return lst; 
	}


	
	public ArrayList<TwitterVo> getTweetGraphUsrDtlRpt(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		try
		{
			String joinQuery=rtnQueryStringForUserDetalReport(tweeterActionVo);
			String query="{\n"+
					"\"size\": 0,\n" +
					joinQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"dateHistogram\":{\n"+
					"\"date_histogram\":{\n"+
					"\"field\":\"articlePublishDate\",\n"+
					"\"interval\": \"day\",\n"+
					"\"min_doc_count\": 0,\n"+
					"\"extended_bounds\" : {\n"+ 
					"\"min\" : \""+TwitterConstant.convertStrToDate_yyyy_MM_dd(tweeterActionVo.getDateFrom())+"\",\n"+
					"\"max\" : \""+TwitterConstant.convertStrToDate_yyyy_MM_dd(tweeterActionVo.getDateTo())+"\"\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";

			System.out.println("getTweetGraphUsrDtlRpt()==== "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			DateHistogramAggregation  terms = result.getAggregations().getDateHistogramAggregation("dateHistogram");
			List<DateHistogram>  entry=  terms.getBuckets();
			for(DateHistogram dateHistogram : entry) 
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setCreatedAt(CommonUtils.convertUnixTimeToDate_yyyy_mm_dd((dateHistogram.getKey())));
				twitterVo.setCount(Long.toString(dateHistogram.getCount()));
				lst.add(twitterVo);
			}
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		} 
		return lst; 
	}


	
	public ArrayList<TwitterVo> getTimeLineDayOfWeek(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		try
		{					
			String subQuery=rtnFilterQuery(tweeterActionVo, -1);
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"termagg\":{\n"+
					"\"terms\": {\n"+ 
					"\"order\": { \"_term\": \"desc\" },\n"+
					"\"script\" : {"+
					"\"inline\": \"Date date = new Date(doc[date_field].value); date.format(format);\","+
					"\"params\" : {"+
					" \"date_field\" :\"articlePublishDate\", "+
					" \"format\" :\"EEE\" "+
					"}\n"+
					"}\n"
					+ "}\n"+
					"}\n"+
					"}\n"+
					"}\n";

			System.out.println("*****getTimeLineDayOfWeek()***** "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			TermsAggregation terms = result.getAggregations().getTermsAggregation("termagg");
			List<Entry>  entry=  terms.getBuckets();
			for(Entry entry2 : entry)
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setCreatedAt(entry2.getKey());
				twitterVo.setCount(Long.toString(entry2.getCount()));
				lst.add(twitterVo);
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		} 
		return lst; 
	}


	
	public ArrayList<TwitterVo> getTimeLineDayOfHour(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		try
		{
			String subQuery=rtnFilterQuery(tweeterActionVo, -1);
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"termagg\":{\n"+
					"\"terms\": {\n"+ 
					"\"order\": { \"_term\": \"desc\" },\n"+
					"\"size\":24,\n"+
					"\"script\" : {"+
					"\"inline\": \"Date date = new Date(doc[date_field].value); date.format(format);\","+
					"\"params\" : {"+
					" \"date_field\" :\"articlePublishDate\", "+
					" \"format\" :\"HH\" "+
					"}\n"+
					"}\n"
					+ "}\n"+
					"}\n"+
					"}\n"+
					"}\n";

			System.out.println("*****getTimeLineDayOfHour()***** "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			TermsAggregation terms = result.getAggregations().getTermsAggregation("termagg");
			List<Entry>  entry=  terms.getBuckets();
			for(Entry entry2 : entry) 
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setCreatedAt(entry2.getKey());
				twitterVo.setCount(Long.toString(entry2.getCount()));
				lst.add(twitterVo);
			}
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		} 
		return lst; 
	}


	public String gettweetStatsOffLineFun(TweeterActionVo tweeterActionVo, String type)
	{
		String rtnVal="0";
		try
		{
			String subQuery=rtnQueryStringForUserDetalReport(tweeterActionVo);
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					twitterConstant.getESValueCountAggs(type)+
					"}\n";

			System.out.println("*****gettweetStatsOffLineFun()*****"+type+"***** "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			ValueCountAggregation terms = result.getAggregations().getValueCountAggregation("types_count");
			rtnVal= Long.toString(terms.getValueCount());
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return rtnVal;
	}


	public ArrayList<TwitterVo> gettweetStatsOffLine(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> list = new ArrayList<TwitterVo>();
		try
		{
			String dateFrom=TwitterConstant.dateFormatMMDDYY(TwitterConstant.convertStrToDate(tweeterActionVo.getDateFrom()));
			String dateTo=TwitterConstant.dateFormatMMDDYY(TwitterConstant.convertStrToDate(tweeterActionVo.getDateTo()));
			Date dateFrom1=TwitterConstant.convertStrToDate(tweeterActionVo.getDateFrom());
			Date dateTo1=TwitterConstant.convertStrToDate(tweeterActionVo.getDateTo());
			TwitterVo twitterVo=new TwitterVo();
			twitterVo.setStatsDateFrom(dateFrom);
			twitterVo.setStatsDateTo(dateTo);

			if(!tweeterActionVo.getNoTweet().equals("0"))
			{
				twitterVo.setMentionCount(gettweetStatsOffLineFun(tweeterActionVo,"articleMention"));
				//twitterVo.setTotalReTweetCount(rs.get("totalReTweet")==null?"":rs.get("totalReTweet").toString());
				//twitterVo.setTotalReply(rs.get("totalReply")==null?"":rs.get("totalReply").toString());
				twitterVo.setLinkCount(gettweetStatsOffLineFun(tweeterActionVo,"articleMedia.mediaUrl"));
				twitterVo.setHashCount(gettweetStatsOffLineFun(tweeterActionVo,"articleHashTag"));
				twitterVo.setTweetRatio(Double.parseDouble(tweeterActionVo.getNoTweet())/TwitterConstant.getNoOfDaysBetweenDates(dateFrom1, dateTo1));				
			}
			else 
			{
				twitterVo.setMentionCount("0");
				twitterVo.setLinkCount("0");
				twitterVo.setHashCount("0");
				twitterVo.setTweetRatio(0);
			}
			list.add(twitterVo);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		} 
		return list; 
	}


	
	public void crawlKloutDataOfUser(ArrayList<TwitterKloutVo> lstInfluencer,
			ArrayList<TwitterKloutVo> lstInfluencee, String screenName) 
	{
		//JdbcTemplate jdbcTemplate=new JdbcTemplate(dataSource);
		String user=(String)httpSession.getAttribute(ApplicationConstants.LOGIN_USER);
		try
		{
			if(lstInfluencer.size()>0)
			{
				for(TwitterKloutVo twitterKloutVo : lstInfluencer) 
				{
					String query=" insert ignore into tw_influence(influencer,influence)values(?,?)   ";
					jdbcTemplate.update(query, new Object[] {
							twitterKloutVo.getNick(),
							screenName,
					});
					log.info("User Name------>"+user+"    method=========crawlKloutDataOfUser()  "+"sql============"+query);
				}
			}

			if(lstInfluencee.size()>0)
			{
				for (TwitterKloutVo twitterKloutVo : lstInfluencee)
				{
					String query=" insert  ignore   into tw_influence(influencer,influence)values(?,?)   ";
					jdbcTemplate.update(query, new Object[] {
							screenName,
							twitterKloutVo.getNick()
					});
					log.info("User Name------>"+user+"    method=========crawlKloutDataOfUser()  "+"sql============"+query);
				}
			}
		}	
		catch(Exception e)
		{
			log.error("--------- crawlKloutDataOfUser()--------", e);
		} 		

	}


	
	public String checkUserEntity(String screenName) 
	{
		String strToReturn="noEntity";
		if(!CommonUtils.stringNotEmpty(screenName))
		{
			log.error("Twitter user Screen Name is Blank in checkUserEntity");
			return strToReturn;
		}
		//JdbcTemplate jdbcTemplate=new JdbcTemplate(dataSource);
		try
		{
			String query=" SELECT activation_flag FROM tbl_entity WHERE entity_id=? and activation_flag=1";
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query,new Object[]{screenName});
			if(rows.size()>0)
			{
				strToReturn="entityActive";
			}
		}	
		catch(Exception e) 
		{
			log.error("--------- checkUserEntity()--------", e);
		} 
		return strToReturn;
	}


	
	public ArrayList<TwitterVo> getTwProfileEntityWithFollowers(TweeterActionVo tweeterActionVo)
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		//JdbcTemplate jdbcTemplate=new JdbcTemplate(dataSource);
		String user=(String)httpSession.getAttribute(ApplicationConstants.LOGIN_USER);
		String retLimit=tweeterActionVo.getRowNum()+",50";
		try
		{
			String  query=null;
			query= " SELECT entity_name,entity_id,tw_id,tw_user.followers_count,tw_user.favourites_count,tw_user.friends_count,tw_user.statuses_count,entity_img "+
					" FROM tbl_entity LEFT OUTER JOIN tw_user ON tbl_entity.tw_id=tw_user.id WHERE entity_type='P' AND entity_source_type='Tw' and (entity_name like '%"+tweeterActionVo.getUserName()+"%'  or entity_id like '%"+tweeterActionVo.getUserName()+"%' )"+
					" limit "+retLimit;

			System.out.println("getTwProfileEntityWithFollowers== "+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setName(rs.get("entity_name")==null?"":rs.get("entity_name").toString());
				twitterVo.setUserName(rs.get("entity_id")==null?"":rs.get("entity_id").toString());
				twitterVo.setUserId(rs.get("tw_id")==null?"":rs.get("tw_id").toString());
				twitterVo.setAvatar(rs.get("entity_img")==null?"":rs.get("entity_img").toString());
				twitterVo.setFavouritesCount(rs.get("favourites_count")==null?"0":rs.get("favourites_count").toString());
				twitterVo.setFollowersCount(rs.get("followers_count")==null?"0":rs.get("followers_count").toString());
				twitterVo.setFriendsCount(rs.get("friends_count")==null?"0":rs.get("friends_count").toString());
				twitterVo.setStatusesCount(rs.get("statuses_count")==null?"0":rs.get("statuses_count").toString());
				lst.add(twitterVo);
			}
			if(log.isInfoEnabled())
			{
				log.info("User Name------>"+user+"    method=========getTwProfileEntityWithFollowers()  "+"sql============"+query);
			}

		}
		catch(Exception e) 
		{
			log.error("--------- Exception--------", e);
			e.printStackTrace();
		} 
		return lst; 
	}

	
	public ArrayList<TwitterVo> getCommonFollower_Following(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		//JdbcTemplate jdbcTemplate=new JdbcTemplate(dataSource);
		String user=(String)httpSession.getAttribute(ApplicationConstants.LOGIN_USER);
		String retLimit=tweeterActionVo.getRowNum()+",50";
		try
		{
			String  query=null;
			String suQuery=" where cnt >1 ";
			/*if(CommonUtils.stringNotEmpty(tweeterActionVo.getMax()) && CommonUtils.stringNotEmpty(tweeterActionVo.getMin()))
			{
				suQuery=" where cnt >="+tweeterActionVo.getMin()+" and cnt <= "+tweeterActionVo.getMax();
			}*/
			if(tweeterActionVo.getType().equals("fo"))
			{
				query= " SELECT * FROM ( "+
						" SELECT follower id,follower_name as name,COUNT(*) cnt FROM twitter_followers "+ 
						" WHERE followed IN ("+tweeterActionVo.getUserFilter()+")  GROUP BY follower "+ 
						" ) AS tbl "+suQuery+"  ORDER BY  cnt DESC LIMIT  "+retLimit;
			}
			else if(tweeterActionVo.getType().equals("fr"))
			{
				query= " SELECT * FROM ( "+
						" SELECT followed as id ,followed_name as name,COUNT(*) cnt FROM twitter_followers "+ 
						" WHERE follower IN ("+tweeterActionVo.getUserFilter()+")  GROUP BY followed "+ 
						" ) AS tbl "+suQuery+" ORDER BY  cnt DESC LIMIT  "+retLimit;
			}

			else if(tweeterActionVo.getType().equals("ment"))
			{

				query= "  SELECT * FROM ( "+
						" SELECT username as name,userid as id,COUNT(*) cnt FROM "+ 
						" ( " +
						" SELECT  tw_mentions.username  ,tw_mentions.userid ,tw_tweet.entity_id FROM tw_mentions "+
						" INNER JOIN tw_tweet ON tw_tweet.id=tw_mentions.tweetid "+
						" INNER JOIN  tbl_entity ON tbl_entity.id=tw_tweet.entity_id "+
						" WHERE tbl_entity.tw_id "+ 
						" IN("+tweeterActionVo.getUserFilter()+") "+
						" GROUP BY tw_mentions.username,tw_tweet.entity_id " +
						" ) AS tbl GROUP BY username ) AS tbl2 WHERE cnt > 1 ORDER BY cnt DESC LIMIT  "+retLimit;
			}

			else if(tweeterActionVo.getType().equals("hash"))
			{
				query=" SELECT * FROM( "
						+ " SELECT hashtag as name,hashtag as id,COUNT(*) AS cnt FROM "
						+ " ( "
						+ " SELECT tw_hashtags.hashtag,tw_tweet.entity_id "
						+ " FROM tw_hashtags INNER JOIN tw_tweet ON tw_tweet.id=tw_hashtags.tweet_id "
						+ " INNER JOIN  tbl_entity ON tbl_entity.id=tw_tweet.entity_id	"
						+ " WHERE tbl_entity.tw_id  in("+tweeterActionVo.getUserFilter()+")"
						+ " GROUP BY tw_hashtags.hashtag,tw_tweet.entity_id "
						+ " ) AS tbl  GROUP BY hashtag "
						+ " ) AS tbl WHERE cnt>1 ORDER BY cnt DESC LIMIT "+retLimit;
			}

			else if(tweeterActionVo.getType().equals("repu"))
			{
				query=" SELECT * FROM( "
						+ " SELECT in_reply_to_screen_name as name,in_reply_to_screen_name as id,COUNT(*) AS cnt FROM "
						+ " ( "
						+ " SELECT in_reply_to_screen_name,tw_tweet.entity_id "
						+ " FROM tw_tweet  "
						+ " INNER JOIN  tbl_entity ON tbl_entity.id=tw_tweet.entity_id	"
						+ " WHERE in_reply_to_screen_name IS NOT NULL AND in_reply_to_screen_name !='' and tbl_entity.tw_id  in("+tweeterActionVo.getUserFilter()+")"
						+ " GROUP BY in_reply_to_screen_name,entity_id "
						+ " ) AS tbl  GROUP BY in_reply_to_screen_name  "
						+ " ) AS tbl WHERE cnt>1 ORDER BY cnt DESC LIMIT "+retLimit;
			}

			else if(tweeterActionVo.getType().equals("rtu"))
			{
				query=" SELECT * FROM( "
						+ " SELECT user_name as name,user_name as id,COUNT(*) AS cnt FROM "
						+ " ( "
						+ " SELECT DISTINCT tw_tweet.entity_id,tw_tweet.user_name "
						+ " FROM tw_tweet WHERE tw_tweet.id IN ( "
						+ " SELECT tw_tweet.retweet_source_id FROM tw_tweet  "
						+ " INNER JOIN  tbl_entity ON tbl_entity.id=tw_tweet.entity_id	"
						+ " WHERE tw_tweet.retweet_flag='1' and tbl_entity.tw_id  in("+tweeterActionVo.getUserFilter()+")"
						+ " )) AS tbl  GROUP BY user_name  "
						+ " ) AS tbl2 WHERE cnt>1 ORDER BY cnt DESC LIMIT "+retLimit;
			}

			else if(tweeterActionVo.getType().equals("fav"))
			{
				query=" SELECT * FROM( "
						+ " SELECT user_name as name,user_id as id,COUNT(*) AS cnt FROM "
						+ " ( "
						+ " SELECT tw_tweet.user_name,tw_tweet.user_id,tw_tweet.entity_id FROM tw_tweet  "
						+ " INNER JOIN  tbl_entity ON tbl_entity.id=tw_tweet.entity_id	"
						+ " WHERE tw_tweet.user_id != tbl_entity.tw_id  and  tbl_entity.tw_id  in("+tweeterActionVo.getUserFilter()+")"
						+ " GROUP BY tw_tweet.entity_id,tw_tweet.user_name ) AS tbl  GROUP BY user_name  "
						+ " ) AS tbl2 WHERE cnt>1 ORDER BY cnt DESC LIMIT "+retLimit;
			}

			System.out.println("getCommonFollower_Following== "+tweeterActionVo.getType()+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);

			for(Map<String,Object> rs :rows)
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setName(rs.get("name")==null?"":rs.get("name").toString());
				twitterVo.setUserId(rs.get("id")==null?"":rs.get("id").toString());
				twitterVo.setCount(rs.get("cnt")==null?"0":rs.get("cnt").toString());
				lst.add(twitterVo);
			}
			if(log.isInfoEnabled())
			{
				log.info("User Name------>"+user+"    method=========getCommonFollower_Following()  "+tweeterActionVo.getType()+"sql============"+query);
			}
		}
		catch(Exception e) 
		{
			log.error("--------- Exception--------", e);
			e.printStackTrace();
		} 
		return lst;
	}


	
	public ArrayList<TwitterVo> getTwProfileEntityWithFollowersFin(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		//JdbcTemplate jdbcTemplate=new JdbcTemplate(dataSource);
		String user=(String)httpSession.getAttribute(ApplicationConstants.LOGIN_USER);
		try
		{
			String  query=null;
			if(tweeterActionVo.getType().equals("fo"))
			{
				query= " SELECT entity_name,entity_id,tw_id,tw_user.followers_count,tw_user.favourites_count,tw_user.friends_count,tw_user.statuses_count,entity_img "+
						" FROM tbl_entity INNER JOIN twitter_followers ON tbl_entity.tw_id=twitter_followers.followed LEFT OUTER JOIN tw_user ON tbl_entity.tw_id=tw_user.id WHERE entity_type='P' AND entity_source_type='Tw' AND  follower='"+tweeterActionVo.getUserName()+"' AND followed IN ("+tweeterActionVo.getUserFilter()+")";
			}
			else if(tweeterActionVo.getType().equals("fr"))
			{
				query= " SELECT entity_name,entity_id,tw_id,tw_user.followers_count,tw_user.favourites_count,tw_user.friends_count,tw_user.statuses_count,entity_img "+
						" FROM tbl_entity INNER JOIN twitter_followers ON tbl_entity.tw_id=twitter_followers.follower LEFT OUTER JOIN tw_user ON tbl_entity.tw_id=tw_user.id WHERE entity_type='P' AND entity_source_type='Tw' AND  followed='"+tweeterActionVo.getUserName()+"' AND follower IN ("+tweeterActionVo.getUserFilter()+")";

			}

			else if(tweeterActionVo.getType().equals("ment"))
			{
				query= " SELECT tbl_entity.entity_name,tbl_entity.entity_id,tw_id,tw_user.followers_count,tw_user.favourites_count,tw_user.friends_count,tw_user.statuses_count,entity_img "+
						" FROM  tw_mentions"
						+ " INNER JOIN tw_tweet ON tw_tweet.id=tw_mentions.tweetid "
						+ " INNER JOIN  tbl_entity ON tbl_entity.id=tw_tweet.entity_id "
						+ " INNER  JOIN tw_user ON tbl_entity.tw_id=tw_user.id "
						+ " WHERE tbl_entity.tw_id  in("+tweeterActionVo.getUserFilter()+")"
						+ " AND tw_mentions.userid='"+tweeterActionVo.getUserName()+"'"
						+ " GROUP BY tw_id ";
			}

			else if(tweeterActionVo.getType().equals("hash"))
			{
				query= " SELECT tbl_entity.entity_name,tbl_entity.entity_id,tw_id,tw_user.followers_count,tw_user.favourites_count,tw_user.friends_count,tw_user.statuses_count,entity_img "+
						" FROM  tw_hashtags"
						+ " INNER JOIN tw_tweet ON tw_tweet.id=tw_hashtags.tweet_id "
						+ " INNER JOIN  tbl_entity ON tbl_entity.id=tw_tweet.entity_id "
						+ " INNER  JOIN tw_user ON tbl_entity.tw_id=tw_user.id "
						+ " WHERE tbl_entity.tw_id  in("+tweeterActionVo.getUserFilter()+")"
						+ " AND tw_hashtags.hashtag='"+tweeterActionVo.getUserName()+"'"
						+ " GROUP BY tw_id ";
			}

			else if(tweeterActionVo.getType().equals("repu"))
			{
				query= " SELECT tbl_entity.entity_name,tbl_entity.entity_id,tw_id,tw_user.followers_count,tw_user.favourites_count,tw_user.friends_count,tw_user.statuses_count,entity_img "+
						" FROM  tw_tweet "
						+ " INNER JOIN  tbl_entity ON tbl_entity.id=tw_tweet.entity_id "
						+ " INNER  JOIN tw_user ON tbl_entity.tw_id=tw_user.id "
						+ " WHERE tbl_entity.tw_id  in("+tweeterActionVo.getUserFilter()+")"
						+ " AND in_reply_to_screen_name='"+tweeterActionVo.getUserName()+"'"
						+ " GROUP BY tw_id ";
			}

			else if(tweeterActionVo.getType().equals("rtu"))
			{
				query= " SELECT tbl_entity.entity_name,tbl_entity.entity_id,tw_id,tw_user.followers_count,tw_user.favourites_count,tw_user.friends_count,tw_user.statuses_count,entity_img "+
						" FROM  tw_tweet "
						+ " INNER JOIN  tbl_entity ON tbl_entity.id=tw_tweet.entity_id "
						+ " INNER  JOIN tw_user ON tbl_entity.tw_id=tw_user.id "
						+ " WHERE tbl_entity.tw_id  in("+tweeterActionVo.getUserFilter()+")"
						+ "  AND tw_tweet.retweet_flag='0' AND tw_tweet.user_name='"+tweeterActionVo.getUserName()+"'"
						+ " GROUP BY tw_id ";
			}

			else if(tweeterActionVo.getType().equals("fav"))
			{
				query= " SELECT tbl_entity.entity_name,tbl_entity.entity_id,tw_id,tw_user.followers_count,tw_user.favourites_count,tw_user.friends_count,tw_user.statuses_count,entity_img "+
						" FROM  tw_tweet "
						+ " INNER JOIN  tbl_entity ON tbl_entity.id=tw_tweet.entity_id "
						+ " INNER  JOIN tw_user ON tbl_entity.tw_id=tw_user.id "
						+ " WHERE tbl_entity.tw_id  in("+tweeterActionVo.getUserFilter()+")"
						+ "  AND tw_tweet.user_id != tbl_entity.tw_id AND tw_tweet.user_id='"+tweeterActionVo.getUserName()+"'"
						+ " GROUP BY tw_id ";
			}

			else if(tweeterActionVo.getType().equals("src"))
			{
				query= " SELECT tbl_entity.entity_name,tbl_entity.entity_id,tw_id,tw_user.followers_count,tw_user.favourites_count,tw_user.friends_count,tw_user.statuses_count,entity_img "+
						" FROM  tw_tweet "
						+ " INNER JOIN  tbl_entity ON tbl_entity.id=tw_tweet.entity_id "
						+ " INNER  JOIN tw_user ON tbl_entity.tw_id=tw_user.id "
						+ " WHERE tbl_entity.tw_id  in("+tweeterActionVo.getUserFilter()+")"
						+ "  AND tw_tweet.source like '%"+tweeterActionVo.getUserName()+"%'"
						+ " GROUP BY tw_id ";
			}

			System.out.println("getTwProfileEntityWithFollowersFin== "+tweeterActionVo.getType()+"   "+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);

			for(Map<String,Object> rs :rows)
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setName(rs.get("entity_name")==null?"":rs.get("entity_name").toString());
				twitterVo.setUserName(rs.get("entity_id")==null?"":rs.get("entity_id").toString());
				twitterVo.setUserId(rs.get("tw_id")==null?"":rs.get("tw_id").toString());
				twitterVo.setAvatar(rs.get("entity_img")==null?"":rs.get("entity_img").toString());
				twitterVo.setFavouritesCount(rs.get("favourites_count")==null?"0":rs.get("favourites_count").toString());
				twitterVo.setFollowersCount(rs.get("followers_count")==null?"0":rs.get("followers_count").toString());
				twitterVo.setFriendsCount(rs.get("friends_count")==null?"0":rs.get("friends_count").toString());
				twitterVo.setStatusesCount(rs.get("statuses_count")==null?"0":rs.get("statuses_count").toString());
				lst.add(twitterVo);
			}
			if(log.isInfoEnabled())
			{
				log.info("User Name------>"+user+"    method=========getTwProfileEntityWithFollowersFin()  "+"sql============"+query);
			}
		}
		catch(Exception e) 
		{
			log.error("--------- Exception--------", e);
			e.printStackTrace();
		} 
		return lst; 
	}

	
	public ArrayList<TwitterVo> getCommonFollower_FollowingMaxMin(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		//JdbcTemplate jdbcTemplate=new JdbcTemplate(dataSource);
		String user=(String)httpSession.getAttribute(ApplicationConstants.LOGIN_USER);
		try
		{
			String  query=null;
			if(tweeterActionVo.getType().equals("fo"))
			{

				query= " SELECT MIN(cnt) AS minVal,MAX(cnt) AS maxVal  FROM ( "+
						" SELECT follower id,follower_name as name,COUNT(*) cnt FROM twitter_followers "+ 
						" WHERE followed IN ("+tweeterActionVo.getUserFilter()+")  GROUP BY follower "+ 
						" )  AS tbl  "; 
			}
			else 
			{
				query= " SELECT MIN(cnt) AS minVal,MAX(cnt) AS maxVal  FROM ( "+
						" SELECT followed as id ,followed_name as name,COUNT(*) cnt FROM twitter_followers "+ 
						" WHERE follower IN ("+tweeterActionVo.getUserFilter()+")  GROUP BY followed "+ 
						" ) AS tbl  ";
			}

			System.out.println("getCommonFollower_FollowingMaxMin== "+tweeterActionVo.getType()+" "+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setMax(rs.get("maxVal")==null?"0":rs.get("maxVal").toString());
				twitterVo.setMin(rs.get("minVal")==null?"0":rs.get("minVal").toString());
				lst.add(twitterVo);
			}
			if(log.isInfoEnabled())
			{
				log.info("User Name------>"+user+"    method=========getCommonFollower_FollowingMaxMin()  "+tweeterActionVo.getType()+"sql============"+query);
			}
		}
		catch(Exception e) 
		{
			log.error("--------- Exception--------", e);
			e.printStackTrace();
		} 
		return lst;
	}

	
	public void updateTwitterFollower_Following(ArrayList<TweetUserTblVo> tweetUserTblVos) 
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		//JdbcTemplate jdbcTemplate=new JdbcTemplate(dataSource);
		try
		{
			for (TwitterVo twitterVo : lst) 
			{
				String query=" UPDATE twitter_followers SET followed_name=?  WHERE followed=? ";
				System.out.println("updateTwitterFollower_Following=="+query);
				jdbcTemplate.update(query, new Object[] {
						twitterVo.getScreenName(),
						twitterVo.getUserId()
				});
			}
		}
		catch(Exception e) 
		{
			log.error("--------- Exception--------", e);
			e.printStackTrace();
		}
	}


	
	public ArrayList<TwitterVo> getTwitterLinkAnalysis(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		String fbImgLocalAddress="";
		try
		{
			String query=null;
			if(tweeterActionVo.getType().equals("fo")) //follower
			{
				query=" SELECT twitter_followers.followed_name AS nodeName1, "
						+ " twitter_followers.followed_screen_name AS nodeScreenName1, "
						+ " twitter_followers.followed AS nodeId1, "
						+ " twitter_followers.followed_img AS nodeImg1, "			
						+ " 'follower' AS TYPE, "
						+ " twitter_followers.follower_name AS nodeName2, "
						+ " twitter_followers.follower_screen_name AS nodeScreenName2, "
						+ " twitter_followers.follower AS nodeId2, "
						+ " twitter_followers.follower_img AS nodeImg2 "
						+ " FROM twitter_followers  "
						+ " WHERE twitter_followers.followed IN("+tweeterActionVo.getUserFilter()+") ";

				   query+=" UNION SELECT collection_profile.profile_name AS nodeName1,"
				   		+ " collection_profile.profile_user_name AS nodeScreenName1, "
				   		+ " collection_profile.profile_id AS nodeId1, "
				   		+ " collection_profile.profile_image_url AS nodeImg1, "
				   		+ " 'follower' AS TYPE, "
				   		+ " collection_profile.profile_name AS nodeName2, "
				   		+ " collection_profile.profile_user_name AS nodeScreenName2, "
				   		+ " collection_profile.profile_id AS nodeId2, "
				   		+ " collection_profile.profile_image_url AS nodeImg2 "
				   		+ " FROM collection_profile "
				   		+ " WHERE collection_profile.profile_id IN("+tweeterActionVo.getUserFilter()+") ";
				   
				
				//=======================================================================
				/*query=" SELECT twitter_followers.followed_name AS nodeName1, "
						+ " twitter_followers.followed_screen_name AS nodeScreenName1, "
						+ " twitter_followers.followed AS nodeId1, "
						+ " twitter_followers.followed_img AS nodeImg1, "			
						+ " 'follower' AS TYPE, "
						+ " twitter_followers.follower_name AS nodeName2, "
						+ " twitter_followers.follower_screen_name AS nodeScreenName2, "
						+ " twitter_followers.follower AS nodeId2, "
						+ " twitter_followers.follower_img AS nodeImg2 "
						+ " FROM twitter_followers  "
						+ " WHERE twitter_followers.followed IN("+tweeterActionVo.getUserFilter()+") ";

				   query+=" UNION SELECT tbl_entity.entity_name AS nodeName1,"
				   		+ " tbl_entity.entity_id AS nodeScreenName1, "
				   		+ " tbl_entity.tw_id AS nodeId1, "
				   		+ " tbl_entity.entity_img AS nodeImg1, "
				   		+ " 'follower' AS TYPE, "
				   		+ " tbl_entity.entity_name AS nodeName2, "
				   		+ " tbl_entity.entity_id AS nodeScreenName2, "
				   		+ " tbl_entity.tw_id AS nodeId2, "
				   		+ " tbl_entity.entity_img AS nodeImg2 "
				   		+ " FROM tbl_entity "
				   		+ " WHERE tbl_entity.tw_id IN("+tweeterActionVo.getUserFilter()+") ";
				   */
				   //====================================================================
				
			}			
			else if(tweeterActionVo.getType().equals("fw")) // following
			{

				query=" SELECT twitter_followers.follower_name AS nodeName1, "
						+ " twitter_followers.follower_screen_name AS nodeScreenName1, "
						+ " twitter_followers.follower AS nodeId1, "
						+ " twitter_followers.follower_img AS nodeImg1, "
						+ " 'follower' AS TYPE, "
						+ " twitter_followers.followed_name AS nodeName2, "
						+ " twitter_followers.followed_screen_name AS nodeScreenName2, "
						+ " twitter_followers.followed AS nodeId2, "
						+ " twitter_followers.followed_img AS nodeImg2 "
						+ " FROM twitter_followers "
						+ " WHERE twitter_followers.follower IN("+tweeterActionVo.getUserFilter()+") ";

				query+=" UNION SELECT collection_profile.profile_name AS nodeName1, "
						+ " collection_profile.profile_user_name AS nodeScreenName1, "
						+ " collection_profile.profile_id AS nodeId1, "
						+ " collection_profile.profile_image_url AS nodeImg1, "
						+ " 'follower' AS TYPE, "
						+ " collection_profile.profile_name AS nodeName2, "
						+ " collection_profile.profile_user_name AS nodeScreenName2, "
						+ " collection_profile.profile_id AS nodeId2, "
						+ " collection_profile.profile_image_url AS nodeImg2 "
						+ " FROM collection_profile "
						+ " WHERE collection_profile.profile_id IN("+tweeterActionVo.getUserFilter()+") ";
				
				//========================================================================
				/*
				query=" SELECT twitter_followers.follower_name AS nodeName1, "
						+ " twitter_followers.follower_screen_name AS nodeScreenName1, "
						+ " twitter_followers.follower AS nodeId1, "
						+ " twitter_followers.follower_img AS nodeImg1, "
						+ " 'follower' AS TYPE, "
						+ " twitter_followers.followed_name AS nodeName2, "
						+ " twitter_followers.followed_screen_name AS nodeScreenName2, "
						+ " twitter_followers.followed AS nodeId2, "
						+ " twitter_followers.followed_img AS nodeImg2 "
						+ " FROM twitter_followers "
						+ " WHERE twitter_followers.follower IN("+tweeterActionVo.getUserFilter()+") ";

				query+=" UNION SELECT tbl_entity.entity_name AS nodeName1, "
						+ " tbl_entity.entity_id AS nodeScreenName1, "
						+ " tbl_entity.tw_id AS nodeId1, "
						+ " tbl_entity.entity_img AS nodeImg1, "
						+ " 'follower' AS TYPE, "
						+ " tbl_entity.entity_name AS nodeName2, "
						+ " tbl_entity.entity_id AS nodeScreenName2, "
						+ " tbl_entity.tw_id AS nodeId2, "
						+ " tbl_entity.entity_img AS nodeImg2 "
						+ " FROM tbl_entity "
						+ " WHERE tbl_entity.tw_id IN("+tweeterActionVo.getUserFilter()+") ";
				*/
				//==============================================================
			}			
			else if(tweeterActionVo.getType().equals("fbfw")) // facebook Friends
			{
				String fbImgFlag = TwitterConstant.getInnsightImageFlag();
				fbImgLocalAddress = TwitterConstant.getFacebookLocalImageUrl();
				String imgNode1="";
				String imgNode2="";
				System.out.println("fbImgFlag: "+fbImgFlag);
				System.out.println("fbImgLocalAddress: "+fbImgLocalAddress);

				if(fbImgFlag.equals("web"))
				{
					//imgNode1 = "tbl_entity.entity_img AS nodeImg1";
					imgNode1 = "collection_profile.profile_image_url AS nodeImg1";
					imgNode2 = "fb_scrap_user_friends.friend_photo AS nodeImg2";
				}
				else if(fbImgFlag.equals("local"))
				{
					//imgNode1 = "tbl_entity.entity_img AS nodeImg1";
					imgNode1 = "collection_profile.profile_image_url AS nodeImg1";
					imgNode2 = "fb_scrap_user_friends.localImagePath AS nodeImg2";
				}
				
				query=" SELECT fb_scrap_user_friends.fb_userId AS nodeId1, "
				    	+ " collection_profile.profile_name AS nodeScreenName1, "
						+ " collection_profile.profile_name AS nodeName1, "
						+ " collection_profile.profile_image_url AS nodeImg1, "
						//+ " fb_scrap_user_friends.fb_userId AS nodeName1 , '"+imgNode1+"' , "
						+ " 'friend' AS TYPE, "
						+ " fb_scrap_user_friends.friendsAll_userId AS nodeId2, "
						+ " fb_scrap_user_friends.friendsAll_userName AS nodeScreenName2, "
					    + " fb_scrap_user_friends.friendsAll_userName AS nodeName2, "
					    + " fb_scrap_user_friends.friend_photo AS nodeImg2 "
					  //+ " fb_scrap_user_friends.friendsAll_userName AS nodeName2,  '"+imgNode2+"' "
					  
					    + " FROM fb_scrap_user_friends "
					    + " INNER JOIN collection_profile "
					    + " ON collection_profile.profile_id=fb_scrap_user_friends.fb_userId "
					  //+ " AND  entity_id IN("+tweeterActionVo.getUserFilter()+") ";

	                    + " WHERE friendsAll_userId IN ( " 
	                    + " SELECT friendsAll_userId FROM ("
	                    + " SELECT COUNT(*) AS cnt, "
	                    + " fb_scrap_user_friends.friendsAll_userId "
	                    + " FROM fb_scrap_user_friends  "
	                    + " WHERE fb_scrap_user_friends.fb_userId"
	                    + " IN("+tweeterActionVo.getUserFilter()+")  "
	                    + " GROUP BY fb_scrap_user_friends.friendsAll_userId ) AS tbl)"
	                    //+ " GROUP BY fb_scrap_user_friends.friendsAll_userId ) AS tbl WHERE cnt >1)"
	                    + " AND profile_id IN("+tweeterActionVo.getUserFilter()+") order by nodeId2 ";
				    
                //======================================================================
			    /*query=" SELECT fb_scrap_user_friends.fb_userId AS nodeId1, "
			    	+ " tbl_entity.entity_name AS nodeScreenName1, "
					+ " tbl_entity.entity_name AS nodeName1, "
					+ " tbl_entity.entity_img AS nodeImg1, "
					//+ " fb_scrap_user_friends.fb_userId AS nodeName1 , '"+imgNode1+"' , "
					+ " 'friend' AS TYPE, "
					+ " fb_scrap_user_friends.friendsAll_userId AS nodeId2, "
					+ " fb_scrap_user_friends.friendsAll_userName AS nodeScreenName2, "
				    + " fb_scrap_user_friends.friendsAll_userName AS nodeName2, "
				    + " fb_scrap_user_friends.friend_photo AS nodeImg2 "
				  //+ " fb_scrap_user_friends.friendsAll_userName AS nodeName2,  '"+imgNode2+"' "
				  
				    + " FROM fb_scrap_user_friends "
				    + " INNER JOIN  tbl_entity "
				    + " ON tbl_entity.entity_id=fb_scrap_user_friends.fb_userId "
				  //+ " AND  entity_id IN("+tweeterActionVo.getUserFilter()+") ";

                    + " WHERE friendsAll_userId IN ( " 
                    + " SELECT friendsAll_userId FROM ("
                    + " SELECT COUNT(*)  AS cnt ,fb_scrap_user_friends.friendsAll_userId FROM "
                    + " fb_scrap_user_friends  "
                    + " WHERE fb_scrap_user_friends.fb_userId"
                    + " IN("+tweeterActionVo.getUserFilter()+")  "
                    + " GROUP BY fb_scrap_user_friends.friendsAll_userId ) AS tbl)"
                    //+ " GROUP BY fb_scrap_user_friends.friendsAll_userId ) AS tbl WHERE cnt >1)"
                    + " AND entity_id IN("+tweeterActionVo.getUserFilter()+") order by nodeId2 ";
			    */

			}
			else if(tweeterActionVo.getType().equals("lnkdfriend")) // Linkedin Friends
			{
				System.out.println("tweeterActionVo.getUserFilter()======= "+tweeterActionVo.getUserFilter());
				    query=" SELECT collection_profile.profile_id AS nodeId1, "
				    	+ " collection_profile.profile_user_name AS nodeScreenName1, "
						+ " collection_profile.profile_name AS nodeName1, "
						+ " collection_profile.profile_image_url AS nodeImg1, "
						+ " 'friend' AS TYPE, "
						+ " linkedin_connection.connected_user_id AS nodeId2, "
						+ " linkedin_connection.connected_user_screen_name AS nodeScreenName2, "
					    + " linkedin_connection.connected_user_name AS nodeName2, "
					    + " linkedin_connection.connected_user_img AS nodeImg2 "					  
					    + " FROM linkedin_connection "
					    + " INNER JOIN collection_profile "
					    + " ON collection_profile.profile_id=linkedin_connection.userId "

	                    + " WHERE connected_user_id IN ( " 
	                    + " SELECT connected_user_id FROM ("
	                    + " SELECT COUNT(*) AS cnt, "
	                    + " linkedin_connection.connected_user_id "
	                    + " FROM linkedin_connection "
	                    + " WHERE linkedin_connection.userId"
	                    + " IN("+tweeterActionVo.getUserFilter()+")  "
	                    + " GROUP BY linkedin_connection.connected_user_id ) AS tbl)"
	                    + " AND profile_id IN("+tweeterActionVo.getUserFilter()+") order by nodeId2 ";
			}
			

			System.out.println("getTwitterLinkAnalysis== "+tweeterActionVo.getType()+ query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setNodeName1(rs.get("nodeName1")==null?"":rs.get("nodeName1").toString());
				twitterVo.setNodeName2(rs.get("nodeName2")==null?"":rs.get("nodeName2").toString());
				twitterVo.setNodeId1(rs.get("nodeId1")==null?"":rs.get("nodeId1").toString());				
				twitterVo.setNodeId2(rs.get("nodeId2")==null?"":rs.get("nodeId2").toString());
				twitterVo.setNodeType(rs.get("type")==null?"":rs.get("type").toString());
				twitterVo.setNodeScreenName1(rs.get("nodeScreenName1")==null?"":rs.get("nodeScreenName1").toString());
				twitterVo.setNodeScreenName2(rs.get("nodeScreenName2")==null?"":rs.get("nodeScreenName2").toString());

				/*if(tweeterActionVo.getType().equals("fbfw")) // facebook Friends
				{
					twitterVo.setNodeImg1(rs.get("nodeImg1")==null?fbImgLocalAddress:fbImgLocalAddress+rs.get("nodeImg1").toString());
					twitterVo.setNodeImg2(rs.get("nodeImg2")==null?fbImgLocalAddress:fbImgLocalAddress+rs.get("nodeImg2").toString());
				}
				else
				{
					twitterVo.setNodeImg1(rs.get("nodeImg1")==null?"":rs.get("nodeImg1").toString());
					twitterVo.setNodeImg2(rs.get("nodeImg2")==null?"":rs.get("nodeImg2").toString());
				}*/

				twitterVo.setNodeImg1(rs.get("nodeImg1")==null?"":rs.get("nodeImg1").toString());
				twitterVo.setNodeImg2(rs.get("nodeImg2")==null?"":rs.get("nodeImg2").toString());

				lst.add(twitterVo);
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		} 
		return lst;
	}
	
	
	
	public ArrayList<TwitterVo> getFBExcelCommonLinkAnalysis(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		//String fbImgLocalAddress="";
		try
		{
			String query=null;			
			if(tweeterActionVo.getType().equals("fbfw")) // facebook Friends
			{
				    query=" SELECT nodeId2, nodeName2, GROUP_CONCAT(nodeId1) AS rootNodeId, "
						+ " GROUP_CONCAT(nodeName1) AS rootNodeName, COUNT(nodeId2) AS count1 "
						+ " FROM ((SELECT "
						        + " fb_scrap_user_friends.friendsAll_userId AS nodeId2, "
						        + " fb_scrap_user_friends.friendsAll_userName AS nodeName2, "
						        + " fb_scrap_user_friends.fb_userId AS nodeId1, "
						        + " fb_scrap_user_friends.fb_username AS nodeName1 "
						        + " FROM fb_scrap_user_friends "
						        + " INNER JOIN collection_profile "
						        + " ON collection_profile.profile_id = fb_scrap_user_friends.fb_userId"
						        + " WHERE friendsAll_userId IN(SELECT friendsAll_userId "
						                                   + " FROM (SELECT COUNT(*) AS cnt, fb_scrap_user_friends.friendsAll_userId, "
						                                         + " fb_scrap_user_friends.fb_userId, fb_scrap_user_friends.fb_username "
						                                         + " FROM fb_scrap_user_friends "
						                                         + " WHERE fb_scrap_user_friends.fb_userId IN("+tweeterActionVo.getUserFilter()+") "
						                                         + " GROUP BY fb_scrap_user_friends.friendsAll_userId) AS tbl "
						                                   + " WHERE cnt > 0) "
						                                   + " AND profile_id IN("+tweeterActionVo.getUserFilter()+") "
						 + " ORDER BY nodeId2) AS tbl2) "
						 + " GROUP BY nodeId2 "
						 + " ORDER BY count1 DESC";
					
				
				/*query=" SELECT nodeId2, nodeName2, GROUP_CONCAT(nodeId1) AS rootNodeId, "
					+ " GROUP_CONCAT(nodeName1) AS rootNodeName, COUNT(nodeId2) AS count1 "
					+ " FROM ((SELECT "
					        + " fb_scrap_user_friends.friendsAll_userId AS nodeId2, "
					        + " fb_scrap_user_friends.friendsAll_userName AS nodeName2, "
					        + " fb_scrap_user_friends.fb_userId AS nodeId1, "
					        + " fb_scrap_user_friends.fb_username AS nodeName1 "
					        + " FROM fb_scrap_user_friends "
					        + " INNER JOIN tbl_entity "
					        + " ON tbl_entity.entity_id = fb_scrap_user_friends.fb_userId"
					        + " WHERE friendsAll_userId IN(SELECT friendsAll_userId "
					                                   + " FROM (SELECT COUNT(*) AS cnt, fb_scrap_user_friends.friendsAll_userId, "
					                                         + " fb_scrap_user_friends.fb_userId, fb_scrap_user_friends.fb_username "
					                                         + " FROM fb_scrap_user_friends "
					                                         + " WHERE fb_scrap_user_friends.fb_userId IN("+tweeterActionVo.getUserFilter()+") "
					                                         + " GROUP BY fb_scrap_user_friends.friendsAll_userId) AS tbl "
					                                   + " WHERE cnt > 0) "
					                                   + " AND entity_id IN("+tweeterActionVo.getUserFilter()+") "
					 + " ORDER BY nodeId2) AS tbl2) "
					 + " GROUP BY nodeId2 "
					 + " ORDER BY count1 DESC";
				*/
			}			

			System.out.println("getFBExcelCommonLinkAnalysis== "+tweeterActionVo.getType()+ query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setNodeId2(rs.get("nodeId2")==null?"":rs.get("nodeId2").toString());
				twitterVo.setNodeName2(rs.get("nodeName2")==null?"":rs.get("nodeName2").toString());
				twitterVo.setNodeId1(rs.get("rootNodeId")==null?"":rs.get("rootNodeId").toString());
				twitterVo.setNodeName1(rs.get("rootNodeName")==null?"":rs.get("rootNodeName").toString());
				twitterVo.setLinkCount(rs.get("count1")==null?"":rs.get("count1").toString());
				lst.add(twitterVo);
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		} 
		return lst;
	}
	
	
	
	public ArrayList<TwitterVo> getLinkedinExcelCommonLinkAnalysis(TweeterActionVo tweeterActionVo)
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();

		try
		{
			String query=null;			
			if(tweeterActionVo.getType().equals("lnkdfriend")) // Linkedin Friends
			{
				    query=" SELECT nodeId2, nodeName2, GROUP_CONCAT(nodeId1) AS rootNodeId, "
						+ " GROUP_CONCAT(nodeName1) AS rootNodeName, COUNT(nodeId2) AS count1 "
						+ " FROM ((SELECT "
						        + " linkedin_connection.connected_user_id AS nodeId2, "
						        + " linkedin_connection.connected_user_name AS nodeName2, "
						        + " linkedin_connection.userId AS nodeId1, "
						        + " linkedin_connection.user_name AS nodeName1 "
						        + " FROM linkedin_connection "
						        + " INNER JOIN collection_profile "
						        + " ON collection_profile.profile_id = linkedin_connection.userId"
						        + " WHERE connected_user_id IN(SELECT connected_user_id "
						                                   + " FROM (SELECT COUNT(*) AS cnt, linkedin_connection.connected_user_id, "
						                                         + " linkedin_connection.userId, linkedin_connection.user_name "
						                                         + " FROM linkedin_connection "
						                                         + " WHERE linkedin_connection.userId IN("+tweeterActionVo.getUserFilter()+") "
						                                         + " GROUP BY linkedin_connection.connected_user_id) AS tbl "
						                                   + " WHERE cnt > 0) "
						                                   + " AND profile_id IN("+tweeterActionVo.getUserFilter()+") "
						 + " ORDER BY nodeId2) AS tbl2) "
						 + " GROUP BY nodeId2 "
						 + " ORDER BY count1 DESC";
			}			

			System.out.println("getLinkedinExcelCommonLinkAnalysis== "+tweeterActionVo.getType()+ query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setNodeId2(rs.get("nodeId2")==null?"":rs.get("nodeId2").toString());
				twitterVo.setNodeName2(rs.get("nodeName2")==null?"":rs.get("nodeName2").toString());
				twitterVo.setNodeId1(rs.get("rootNodeId")==null?"":rs.get("rootNodeId").toString());
				twitterVo.setNodeName1(rs.get("rootNodeName")==null?"":rs.get("rootNodeName").toString());
				twitterVo.setLinkCount(rs.get("count1")==null?"":rs.get("count1").toString());
				lst.add(twitterVo);
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		} 
		return lst;
	}
	
	
	
	
	public ArrayList<TwitterVo> getTwitterExcelCommonLinkAnalysis(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> list=new ArrayList<TwitterVo>();
		try
		{
			String query=" SELECT nodeId2, nodeScreenName2, nodeName2, "
					   + " GROUP_CONCAT(nodeId1) AS rootNodeId, "
					   + " GROUP_CONCAT(nodeScreenName1) AS rootNodeScreenName, "
					   + " GROUP_CONCAT(nodeName1) AS rootNodeName, "
					   + " COUNT(nodeId2) AS count1 "
					   + " FROM ((SELECT "
			           + " twitter_followers.follower AS nodeId2, "
			           + " twitter_followers.follower_screen_name  AS nodeScreenName2,"
			           + " twitter_followers.follower_name AS nodeName2, "
			           + " twitter_followers.followed AS nodeId1, "
			           + " twitter_followers.followed_screen_name  AS nodeScreenName1, "
			           + " twitter_followers.followed_name AS nodeName1 "
			           + " FROM twitter_followers "
			           + " INNER JOIN collection_profile "
			           + " ON collection_profile.profile_id = twitter_followers.followed"
			           + " WHERE follower IN(SELECT follower "
					                                   + " FROM (SELECT COUNT(*) AS cnt, twitter_followers.follower, "
					                                         + " twitter_followers.followed, twitter_followers.followed_name "
					                                         + " FROM twitter_followers "
					                                         + " WHERE twitter_followers.followed IN("+tweeterActionVo.getUserFilter()+") "
					                                         + " GROUP BY twitter_followers.follower) AS tbl "
					                                   + " WHERE cnt > 0) "
					                                   + " AND collection_profile.profile_id IN("+tweeterActionVo.getUserFilter()+") "
					 + " ORDER BY nodeId2) AS tbl2) "
					 + " GROUP BY nodeId2 "
					 + " ORDER BY count1 DESC";	
			
			
			/*String query=" SELECT nodeId2, nodeScreenName2, nodeName2, "
					   + " GROUP_CONCAT(nodeId1) AS rootNodeId, "
					   + " GROUP_CONCAT(nodeScreenName1) AS rootNodeScreenName, "
					   + " GROUP_CONCAT(nodeName1) AS rootNodeName, "
					   + " COUNT(nodeId2) AS count1 "
					   + " FROM ((SELECT "
			           + " twitter_followers.follower AS nodeId2, "
			           + " twitter_followers.follower_screen_name  AS nodeScreenName2,"
			           + " twitter_followers.follower_name AS nodeName2, "
			           + " twitter_followers.followed AS nodeId1, "
			           + " twitter_followers.followed_screen_name  AS nodeScreenName1, "
			           + " twitter_followers.followed_name AS nodeName1 "
			           + " FROM twitter_followers "
			           + " INNER JOIN tbl_entity "
			           + " ON tbl_entity.tw_id = twitter_followers.followed"
			           + " WHERE follower IN(SELECT follower "
					                                   + " FROM (SELECT COUNT(*) AS cnt, twitter_followers.follower, "
					                                         + " twitter_followers.followed, twitter_followers.followed_name "
					                                         + " FROM twitter_followers "
					                                         + " WHERE twitter_followers.followed IN("+tweeterActionVo.getUserFilter()+") "
					                                         + " GROUP BY twitter_followers.follower) AS tbl "
					                                   + " WHERE cnt > 0) "
					                                   + " AND tbl_entity.tw_id IN("+tweeterActionVo.getUserFilter()+") "
					 + " ORDER BY nodeId2) AS tbl2) "
					 + " GROUP BY nodeId2 "
					 + " ORDER BY count1 DESC";	
			*/

			System.out.println("getTwitterExcelCommonLinkAnalysis== "+tweeterActionVo.getType()+ query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setNodeId2(rs.get("nodeId2")==null?"":rs.get("nodeId2").toString());
				twitterVo.setNodeScreenName2(rs.get("nodeScreenName2")==null?"":rs.get("nodeScreenName2").toString());
				twitterVo.setNodeName2(rs.get("nodeName2")==null?"":rs.get("nodeName2").toString());
				twitterVo.setNodeId1(rs.get("rootNodeId")==null?"":rs.get("rootNodeId").toString());
				twitterVo.setNodeScreenName1(rs.get("rootNodeScreenName")==null?"":rs.get("rootNodeScreenName").toString());
				twitterVo.setNodeName1(rs.get("rootNodeName")==null?"":rs.get("rootNodeName").toString());
				twitterVo.setLinkCount(rs.get("count1")==null?"":rs.get("count1").toString());
				list.add(twitterVo);
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		} 
		return list;
	}

	
	
	public ArrayList<TwitterVo> getTwitterExcelCommonFriendsLinkAnalysis(TweeterActionVo tweeterActionVo)
	{
		ArrayList<TwitterVo> list=new ArrayList<TwitterVo>();
		try
		{
			String query=" SELECT nodeId2, nodeScreenName2, nodeName2, "
					   + " GROUP_CONCAT(nodeId1) AS rootNodeId, "
					   + " GROUP_CONCAT(nodeScreenName1) AS rootNodeScreenName, "
					   + " GROUP_CONCAT(nodeName1) AS rootNodeName, "
					   + " COUNT(nodeId2) AS count1 "
					   + " FROM ((SELECT "
			           + " twitter_followers.followed AS nodeId2, "
			           + " twitter_followers.followed_screen_name AS nodeScreenName2,"
			           + " twitter_followers.followed_name AS nodeName2, "
			           + " twitter_followers.follower AS nodeId1, "
			           + " twitter_followers.follower_screen_name AS nodeScreenName1,"
			           + " twitter_followers.follower_name AS nodeName1 "
			           + " FROM twitter_followers "
			           + " INNER JOIN collection_profile "
			           + " ON collection_profile.profile_id = twitter_followers.follower"
			           + " WHERE followed IN(SELECT followed "
					                                   + " FROM (SELECT COUNT(*) AS cnt, twitter_followers.follower, "
					                                         + " twitter_followers.followed, twitter_followers.followed_name "
					                                         + " FROM twitter_followers "
					                                         + " WHERE twitter_followers.follower IN("+tweeterActionVo.getUserFilter()+") "
					                                         + " GROUP BY twitter_followers.followed) AS tbl "
					                                   + " WHERE cnt > 0) "
					                                   + " AND collection_profile.profile_id IN("+tweeterActionVo.getUserFilter()+") "
					 + " ORDER BY nodeId2) AS tbl2) "
					 + " GROUP BY nodeId2 "
					 + " ORDER BY count1 DESC";	
			
			/*String query=" SELECT nodeId2, nodeScreenName2, nodeName2, "
					   + " GROUP_CONCAT(nodeId1) AS rootNodeId, "
					   + " GROUP_CONCAT(nodeScreenName1) AS rootNodeScreenName, "
					   + " GROUP_CONCAT(nodeName1) AS rootNodeName, "
					   + " COUNT(nodeId2) AS count1 "
					   + " FROM ((SELECT "
			           + " twitter_followers.followed AS nodeId2, "
			           + " twitter_followers.followed_screen_name AS nodeScreenName2,"
			           + " twitter_followers.followed_name AS nodeName2, "
			           + " twitter_followers.follower AS nodeId1, "
			           + " twitter_followers.follower_screen_name AS nodeScreenName1,"
			           + " twitter_followers.follower_name AS nodeName1 "
			           
			           + " FROM twitter_followers "
			           + " INNER JOIN tbl_entity "
			           + " ON tbl_entity.tw_id = twitter_followers.follower"
			           + " WHERE followed IN(SELECT followed "
					                                   + " FROM (SELECT COUNT(*) AS cnt, twitter_followers.follower, "
					                                         + " twitter_followers.followed, twitter_followers.followed_name "
					                                         + " FROM twitter_followers "
					                                         + " WHERE twitter_followers.follower IN("+tweeterActionVo.getUserFilter()+") "
					                                         + " GROUP BY twitter_followers.followed) AS tbl "
					                                   + " WHERE cnt > 0) "
					                                   + " AND tbl_entity.tw_id IN("+tweeterActionVo.getUserFilter()+") "
					 + " ORDER BY nodeId2) AS tbl2) "
					 + " GROUP BY nodeId2 "
					 + " ORDER BY count1 DESC";	
			*/

			System.out.println("getTwitterExcelCommonFriendsLinkAnalysis== "+tweeterActionVo.getType()+ query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setNodeId2(rs.get("nodeId2")==null?"":rs.get("nodeId2").toString());
				twitterVo.setNodeScreenName2(rs.get("nodeScreenName2")==null?"":rs.get("nodeScreenName2").toString());
				twitterVo.setNodeName2(rs.get("nodeName2")==null?"":rs.get("nodeName2").toString());
				twitterVo.setNodeId1(rs.get("rootNodeId")==null?"":rs.get("rootNodeId").toString());
				twitterVo.setNodeScreenName1(rs.get("rootNodeScreenName")==null?"":rs.get("rootNodeScreenName").toString());
				twitterVo.setNodeName1(rs.get("rootNodeName")==null?"":rs.get("rootNodeName").toString());
				twitterVo.setLinkCount(rs.get("count1")==null?"":rs.get("count1").toString());
				list.add(twitterVo);
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		} 
		return list;
	}
	
	
	public ArrayList<TwitterVo> getTwitterExcelCommonLinkAnalysisTrendsData(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> list=new ArrayList<TwitterVo>();
		try
		{				

			/*for(Map<String,Object> rs :rows)
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setNodeId2(rs.get("nodeId2")==null?"":rs.get("nodeId2").toString());
				twitterVo.setNodeName2(rs.get("nodeName2")==null?"":rs.get("nodeName2").toString());
				twitterVo.setNodeId1(rs.get("rootNodeId")==null?"":rs.get("rootNodeId").toString());
				twitterVo.setNodeName1(rs.get("rootNodeName")==null?"":rs.get("rootNodeName").toString());
				twitterVo.setLinkCount(rs.get("count1")==null?"":rs.get("count1").toString());
				list.add(twitterVo);
			}*/
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		} 
		return list;
	}
	
	
	
	public ArrayList<TwitterVo> getCommonFollower_Following_Source(TweeterActionVo tweeterActionVo)
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		//JdbcTemplate jdbcTemplate=new JdbcTemplate(dataSource);
		String user=(String)httpSession.getAttribute(ApplicationConstants.LOGIN_USER);
		String retLimit=tweeterActionVo.getRowNum()+",50";
		try
		{
			String  query=null;
			/*if(CommonUtils.stringNotEmpty(tweeterActionVo.getMax()) && CommonUtils.stringNotEmpty(tweeterActionVo.getMin()))
			{
				suQuery=" where cnt >="+tweeterActionVo.getMin()+" and cnt <= "+tweeterActionVo.getMax();
			}*/
			if(tweeterActionVo.getType().equals("src"))
			{
				query=" SELECT * FROM( "
						+ " SELECT source as name,source as id,COUNT(*) AS cnt FROM "
						+ " ( "
						+ " SELECT tw_tweet.entity_id,tw_tweet.source FROM tw_tweet  "
						+ " INNER JOIN  tbl_entity ON tbl_entity.id=tw_tweet.entity_id	"
						+ " WHERE  tbl_entity.tw_id  in("+tweeterActionVo.getUserFilter()+")"
						+ " GROUP BY tw_tweet.entity_id,tw_tweet.source ) AS tbl  GROUP BY source  "
						+ " ) AS tbl2 WHERE cnt>1 ORDER BY cnt DESC LIMIT "+retLimit;
			}

			System.out.println("getCommonFollower_Following_Source== "+tweeterActionVo.getType()+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				TwitterVo twitterVo=new TwitterVo();
				String source=rs.get("name")==null?"":rs.get("name").toString();
				if(!source.isEmpty())
				{
					Document doc = Jsoup.parse(source);
					Element link = doc.select("a").first();
					source=link.text();
				}
				twitterVo.setName(source);
				twitterVo.setUserId(source);
				twitterVo.setCount(rs.get("cnt")==null?"0":rs.get("cnt").toString());
				lst.add(twitterVo);
			}
			if(log.isInfoEnabled())
			{
				log.info("User Name------>"+user+" method=========getCommonFollower_Following_Source()  "+tweeterActionVo.getType()+"sql============"+query);
			}
		}
		catch (Exception e) 
		{
			log.error("--------- Exception--------", e);
			e.printStackTrace();
		} 
		return lst;
	}


	
	public ArrayList<TwitterVo> getTimeLineDayOfWeekCmnProfile(TweeterActionVo tweeterActionVo)
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		String user=(String)httpSession.getAttribute(ApplicationConstants.LOGIN_USER);

		//JdbcTemplate jdbcTemplate=new JdbcTemplate(dataSource);
		try
		{
			String query= " SELECT * FROM ( "
					+ " SELECT created_at,COUNT(*) tweetCount FROM  "
					+ " ( "
					+ " SELECT DISTINCT DAYOFWEEK(FROM_UNIXTIME(tw_tweet.created_at))-1 AS created_at,tw_tweet.entity_id FROM tw_tweet"
					+ " INNER JOIN tbl_entity     ON tbl_entity.id = tw_tweet.entity_id "
					+ " WHERE  tbl_entity.tw_id  in("+tweeterActionVo.getUserFilter()+")"
					+ " ) as  tbl GROUP BY created_at) AS tbl2 ORDER BY created_at asc ";
			System.out.println("getTimeLineDayOfWeekCmnProfile== "+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);

			for(Map<String,Object> rs :rows)
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setCreatedAt(rs.get("created_at")==null?"":rs.get("created_at").toString());
				twitterVo.setCount(rs.get("tweetCount")==null?"":rs.get("tweetCount").toString());
				lst.add(twitterVo);
			}	
			if(log.isInfoEnabled())
			{
				log.info("User Name------>"+user+"    method=========getTimeLineDayOfWeekCmnProfile()  "+"sql============"+query);
			}

		}
		catch (Exception e)
		{
			log.error("--------- Exception--------", e);
			e.printStackTrace();
		} 
		return lst; 	
	}


	
	public ArrayList<TwitterVo> getTimeLineDayOfHourCmnProfile(TweeterActionVo tweeterActionVo)
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		String user=(String)httpSession.getAttribute(ApplicationConstants.LOGIN_USER);

		//JdbcTemplate jdbcTemplate=new JdbcTemplate(dataSource);
		try
		{
			String query= " SELECT * FROM ( "
					+ " SELECT created_at,COUNT(*) tweetCount FROM  "
					+ " ( "
					+ " SELECT DISTINCT HOUR(FROM_UNIXTIME(tw_tweet.created_at)) AS created_at,tw_tweet.entity_id FROM tw_tweet"
					+ " INNER JOIN tbl_entity     ON tbl_entity.id = tw_tweet.entity_id "
					+ " WHERE  tbl_entity.tw_id  in("+tweeterActionVo.getUserFilter()+")"
					+ " ) as  tbl GROUP BY created_at) AS tbl2 ORDER BY created_at asc ";
			System.out.println("getTimeLineDayOfHourCmnProfile== "+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);

			for(Map<String,Object> rs :rows)
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setCreatedAt(rs.get("created_at")==null?"":rs.get("created_at").toString());
				twitterVo.setCount(rs.get("tweetCount")==null?"":rs.get("tweetCount").toString());
				lst.add(twitterVo);
			}	
			if(log.isInfoEnabled())
			{
				log.info("User Name------>"+user+"    method=========getTimeLineDayOfHourCmnProfile()  "+"sql============"+query);
			}

		}
		catch (Exception e)
		{
			log.error("--------- Exception--------", e);
			e.printStackTrace();
		} 
		return lst; 
	}


	public ArrayList<TwitterVo> geoTweetsByLoc(TweeterActionVo tweeterActionVo) 
	{

		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		try
		{
			String subQuery=rtnFilterQuery(tweeterActionVo,-1);
			String fieldName="articleLocationCountryCode";
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"termagg\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\""+fieldName+"\"\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";

			System.out.println(" geoTweetsByLoc()==== "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			TermsAggregation terms = result.getAggregations().getTermsAggregation("termagg");
			List<Entry>  entry=  terms.getBuckets();
			for (Entry entry2 : entry) 
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setGeoCode(entry2.getKey());
				twitterVo.setTweetCount(Long.toString(entry2.getCount()));
				lst.add(twitterVo);
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return lst;

		/*		
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		JdbcTemplate jdbcTemplate=new JdbcTemplate(dataSource);
		try{
			String	query="  Select country_code as code,COUNT(*) as sm  "+
					"	FROM tw_tweet tweet "+
					rtnJoinQuery(tweeterActionVo,true,true,false)+
					rtnFilterQuery(tweeterActionVo,-1)+
					"  and   (tweet.country_code <> '' and  tweet.country_code is not null)"
					+ " GROUP BY country_code " ;
			System.out.println("geoTweetsByLoc Geo Map== "+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows){
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setGeoCode(rs.get("CODE")==null?"":rs.get("CODE").toString());
				twitterVo.setTweetCount(rs.get("sm")==null?"":rs.get("sm").toString());
				lst.add(twitterVo);
			}
		}
		catch (Exception e) {
			log.error("--------- Exception--------", e);
			e.printStackTrace();
		} 
		return lst; 
		 */	
	}


	
	public ArrayList<TwitterVo> geoProfileTwitter(TweeterActionVo tweeterActionVo)
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		try
		{
			String  subQuery=rtnFilterQuery(tweeterActionVo,-1);
			String fieldName="tweet.tweetUser.tweetUserCountryCode";
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"termagg\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\""+fieldName+"\"\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";

			System.out.println(" geoProfileTwitter()==== "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			TermsAggregation terms = result.getAggregations().getTermsAggregation("termagg");
			List<Entry>  entry=  terms.getBuckets();
			for (Entry entry2 : entry) 
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setGeoCode(entry2.getKey());
				twitterVo.setTweetCount(Long.toString(entry2.getCount()));
				lst.add(twitterVo);
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return lst;
	}

	/*	public ArrayList<TwitterVo> geoTweetsLatLong(TweeterActionVo tweeterActionVo) {
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		try
		{
			List<Article_Datacollection_New>  testLst;
			int size=500;	
			int from=0;
			do
			{
				String subQuery=rtnFilterQuery(tweeterActionVo,19);
				String query="{\n"
						+ "\"from\":"+(from*500)+",\n"
						+ "\"size\":"+size+",\n"
						+subQuery+
						getTweetsSortOrder(tweeterActionVo)
						+ "}\n";
				System.out.println("**geoTweetsLatLong()*****"+query);
				Search search = new Search.Builder(query)
						.addIndex(TwitterConstant.getDbname())
						.addType(TwitterConstant.getTypeName())
						.build();
				SearchResult result = client.execute(search);
				 testLst=   result.getSourceAsObjectList(Article_Datacollection_New.class);
				for (Article_Datacollection_New article_Datacollection_New : testLst) {
					TwitterVo twitterVo=new TwitterVo();
					twitterVo.setArticleSentiment(article_Datacollection_New.getArticleSentiment());
					String articleLocation=article_Datacollection_New.getArticleLocation();
					if(articleLocation !=null && !articleLocation.isEmpty())
					{
						twitterVo.setLatitude(articleLocation.split(",")[0]);
						twitterVo.setLongitude(articleLocation.split(",")[1]);
					}
					twitterVo.setSentiment(Integer.toString(article_Datacollection_New.getArticleSentiment()));
					lst.add(twitterVo);
				}
				from++;
			}
			while(testLst.size()>0);
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		return lst; 
	}
	 */


	public ArrayList<TwitterVo> geoTweetsLatLong(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		try 
		{
			int size=1;	
			String subQuery=rtnFilterQuery(tweeterActionVo, 19);
			String query="{\n"
					+ "\"size\":"+size+",\n"
					+subQuery+
					getTweetsSortOrder(tweeterActionVo)
					+ "}\n";

			System.out.println("**geoTweetsLatLong()***** "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.setParameter(Parameters.SIZE,1000)
					.setParameter(Parameters.SCROLL, "1m")
					.build();

			SearchResult result = client.execute(search);
			LinkedHashSet<String> lsttt=new LinkedHashSet<>();
			List<Article_Datacollection_New> testLst=   result.getSourceAsObjectList(Article_Datacollection_New.class);

			for(Article_Datacollection_New article_Datacollection_New : testLst) 
			{
				lsttt.add(article_Datacollection_New.getArticleId());
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setArticleSentiment(article_Datacollection_New.getArticleSentiment());
				String articleLocation=article_Datacollection_New.getArticleLocation();
				if(articleLocation !=null && !articleLocation.isEmpty()) 
				{
					twitterVo.setLatitude(articleLocation.split(",")[0]);
					twitterVo.setLongitude(articleLocation.split(",")[1]);
				}
				twitterVo.setSentiment(Integer.toString(article_Datacollection_New.getArticleSentiment()));
				lst.add(twitterVo);
			}

			//Get More Result by Scrolling
			if(result.getTotal()>0) 
			{
				String scrolllId=result.getJsonObject().get("_scroll_id").getAsString();
				while(true) 
				{
					System.out.println("Total Document in List::"+lsttt.size());
					if(lsttt.size()==50000)
					{
						break;
					}
					JestResult resultJest= twitterConstant.readMoreFromSearch(scrolllId,10l,client);	
					scrolllId=result.getJsonObject().get("_scroll_id").getAsString();
					testLst=   resultJest.getSourceAsObjectList(Article_Datacollection_New.class);
					if(testLst.size()==0) 
					{
						break;
					}
					for(Article_Datacollection_New article_Datacollection_New : testLst)
					{
						lsttt.add(article_Datacollection_New.getArticleId());
						TwitterVo twitterVo=new TwitterVo();
						twitterVo.setArticleSentiment(article_Datacollection_New.getArticleSentiment());
						String articleLocation=article_Datacollection_New.getArticleLocation();
						if(articleLocation !=null && !articleLocation.isEmpty()) 
						{
							twitterVo.setLatitude(articleLocation.split(",")[0]);
							twitterVo.setLongitude(articleLocation.split(",")[1]);
						}
						twitterVo.setSentiment(Integer.toString(article_Datacollection_New.getArticleSentiment()));
						lst.add(twitterVo);
					}						
				}
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return lst; 
	}

	public ArrayList<TwitterVo> getTweetsUserLocation(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		try 
		{
			int size=1;	
			String subQuery=rtnFilterQuery(tweeterActionVo, 19);
			String query="{\n"
					+ "\"size\":"+size+",\n"
					+subQuery+
					getTweetsSortOrder(tweeterActionVo)
					+ "}\n";

			System.out.println("**getTweetsUserLocation()***** "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.setParameter(Parameters.SIZE,1000)
					.setParameter(Parameters.SCROLL, "1m")
					.build();

			SearchResult result = client.execute(search);
			LinkedHashSet<String> lsttt=new LinkedHashSet<>();
			List<Article_Datacollection_New> testLst = result.getSourceAsObjectList(Article_Datacollection_New.class);

			for(Article_Datacollection_New article_Datacollection_New : testLst) 
			{
				lsttt.add(article_Datacollection_New.getArticleId());
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setArticleSentiment(article_Datacollection_New.getArticleSentiment());
				String articleLocation=article_Datacollection_New.getArticleUserLocation();
				if(articleLocation !=null && !articleLocation.isEmpty()) 
				{
					twitterVo.setLatitude(articleLocation.split(",")[0]);
					twitterVo.setLongitude(articleLocation.split(",")[1]);
				}
				twitterVo.setSentiment(Integer.toString(article_Datacollection_New.getArticleSentiment()));
				lst.add(twitterVo);
			}

			//Get More Result by Scrolling
			if(result.getTotal()>0)
			{
				String scrolllId=result.getJsonObject().get("_scroll_id").getAsString();
				while(true) 
				{
					System.out.println("Total Document in List:: "+lsttt.size());
					if(lsttt.size()==50000) 
					{
						break;
					}
					JestResult resultJest = twitterConstant.readMoreFromSearch(scrolllId,10l,client);	
					scrolllId = result.getJsonObject().get("_scroll_id").getAsString();
					testLst = resultJest.getSourceAsObjectList(Article_Datacollection_New.class);
					if(testLst.size()==0) 
					{
						break;
					}
					for(Article_Datacollection_New article_Datacollection_New : testLst) 
					{
						lsttt.add(article_Datacollection_New.getArticleId());
						TwitterVo twitterVo=new TwitterVo();
						twitterVo.setArticleSentiment(article_Datacollection_New.getArticleSentiment());
						String articleLocation=article_Datacollection_New.getArticleUserLocation();
						if(articleLocation !=null && !articleLocation.isEmpty()) 
						{
							twitterVo.setLatitude(articleLocation.split(",")[0]);
							twitterVo.setLongitude(articleLocation.split(",")[1]);
						}
						twitterVo.setSentiment(Integer.toString(article_Datacollection_New.getArticleSentiment()));
						lst.add(twitterVo);
					}						
				}
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return lst; 
	}


	
	public ArrayList<TwitterVo> geoRptLatLongRetweetUser(TweeterActionVo tweeterActionVo)
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		JdbcTemplate jdbcTemplate=new JdbcTemplate(dataSource);
		try
		{
			String  query=null;
			query="	SELECT "+
					"	tweet.latitude AS latitude,"+
					"	tweet.longitude AS longitude,"+
					"	COUNT(tweet.id)"+
					"	FROM tw_tweet tweet "+
					//			rtnJoinQuery(tweeterActionVo,true,true,false)+
					//rtnFilterQuery(tweeterActionVo,-1)+
					" where   (tweet.latitude <> '0' and tweet.latitude <> '' and  tweet.longitude <> '0' and tweet.longitude <> '')" +
					" Group By latitude,longitude,tweet.id limit 0,10" ;

			System.out.println("geoRptLatLong== "+query);

			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setLatitude(rs.get("latitude")==null?"":rs.get("latitude").toString());
				twitterVo.setLongitude(rs.get("longitude")==null?"":rs.get("longitude").toString());

				lst.add(twitterVo);
			}
		}
		catch (Exception e) 
		{
			log.error("--------- Exception--------", e);
			e.printStackTrace();
		} 
		return lst; 
	}
	
	
	public ArrayList<TwitterVo> getSentimentcounty(TweeterActionVo tweeterActionVo) {
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		try {
			//19 for exclude sentiment having 9
			String subQuery=rtnFilterQuery(tweeterActionVo,19);
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"termaggs\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\"articleLocationCountryCode\"\n"+
					"},\n"+
					"\"aggs\": {\n"+
					"\"sentiment\": {\n"+
					"\"avg\": {\n"+
					"\"field\": \"articleSentiment\"\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";

			System.out.println("getSentimentcounty ::: "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			JSONObject obj = new JSONObject(result.getJsonString());
			if(obj.has("aggregations")) {
				JSONArray bucketArr = obj.getJSONObject("aggregations").getJSONObject("termaggs").getJSONArray("buckets");
				for(int i = 0; i < bucketArr.length(); i++) {
					if(!bucketArr.getJSONObject(i).getJSONObject("sentiment").isNull("value")) {
						String countryCode=bucketArr.getJSONObject(i).getString("key");
						Double sentiment=bucketArr.getJSONObject(i).getJSONObject("sentiment").getDouble("value");
						/*						System.out.println("country code::"+countryCode);
						System.out.println("sentiment::"+sentiment+"*******");
						System.out.println("sentiment 1234::"+CommonUtils.isNegative(sentiment)+"*******");
						 */		

						TwitterVo twitterVo=new TwitterVo();
						twitterVo.setGeoCode(countryCode);
						twitterVo.setTweetCount(Integer.toString(CommonUtils.isNegative(sentiment)));

						/*switch (CommonUtils.isNegative(sentiment)) {
						case -1:
							twitterVo.setTweetCount("1");
							break;
						case 1:
							twitterVo.setTweetCount("2");
							break;
						case 0:
							twitterVo.setTweetCount("3");
							break;
						default:
							break;
						}
						 */						
						lst.add(twitterVo);
					}
				}
			}
		} catch(Exception ex) {
			ex.printStackTrace();
		}
		return lst;
	}

	
	public ArrayList<TwitterVo> geoProfileDetails(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		try
		{
			int size=TwitterConstant.getSizeForEsTermAgg(tweeterActionVo, tweeterActionVo.getRowNum());	
			String  subQuery=rtnFilterQuery(tweeterActionVo,-1);
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"termagg\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\"tweet.tweetUser.tweetUserScreenName\"\n,"+
					"\"size\":\""+size+"\"\n"+
					"},\n"+

         "\"aggs\": {\n"+
         "\"myagg1\": {\n"+
         "\"top_hits\": {"+

         /*         "\"sort\": ["+
         "{"+
         "\"articlePublishDate\": {"+
         "\"order\": \"desc\""+
         "}"+
         "}"+
         "],"+*/

         "\"_source\": {"+
         "\"include\": ["+
         "\"tweet.tweetUser.tweetUserFavouriteCount\","+
         "\"tweet.tweetUser.tweetUserFollowersCount\","+
         "\"tweet.tweetUser.tweetUserFriendsCount\","+
         "\"tweet.tweetUser.tweetUserImageUrl\","+
         "\"tweet.tweetUser.tweetUserName\","+
         "\"tweet.tweetUser.tweetUserStatusCount\","+
         "\"tweet.tweetUser.tweetUserId\""+
         "]"+
         "},"+
         "\"size\" : 1"+
         "}"+
         "}"+
         "}"+

						"}\n"+
						"}\n"+
						"}\n";

			System.out.println("*****geoProfileDetails()***** "+query);
			Search search = new Search.Builder(query)
					// multiple index or types can be added.
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			JSONObject obj = new JSONObject(result.getJsonString());

			if(obj.has("aggregations"))
			{
				JSONArray bucketArr = obj.getJSONObject("aggregations").getJSONObject("termagg").getJSONArray("buckets");
				for (int i = 0; i < bucketArr.length(); i++)
				{
					TwitterVo twitterVo=new TwitterVo();
					String userScreenName=bucketArr.getJSONObject(i).getString("key");
					//	twitterVo.setTweetCount(Integer.toString(bucketArr.getJSONObject(i).getString("key")));
					JSONArray hitsArr=bucketArr.getJSONObject(i).getJSONObject("myagg1").getJSONObject("hits").getJSONArray("hits");
					for (int ii = 0; ii < hitsArr.length(); ii++)
					{
						JSONObject objUser=hitsArr.getJSONObject(ii).getJSONObject("_source").getJSONObject("tweet").getJSONObject("tweetUser");
						twitterVo.setName(objUser.getString("tweetUserName"));
						twitterVo.setUserName(userScreenName);
						twitterVo.setUserId(objUser.getString("tweetUserId"));
						twitterVo.setAvatar(objUser.getString("tweetUserImageUrl"));
						twitterVo.setStatusesCount(Integer.toString(objUser.getInt("tweetUserStatusCount")));
						twitterVo.setFavouritesCount(Integer.toString(objUser.getInt("tweetUserFavouriteCount")));
						twitterVo.setFollowersCount(Integer.toString(objUser.getInt("tweetUserFollowersCount")));
						twitterVo.setFriendsCount(Integer.toString(objUser.getInt("tweetUserFriendsCount")));
					}
					lst.add(twitterVo);
				}
			}

		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return lst; 
	}


	
	public ArrayList<TwitterVo> geoTweetRetweetsLatLong(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		JdbcTemplate jdbcTemplate=new JdbcTemplate(dataSource);
		try
		{
			String query=null;
			query="	SELECT "+
					"	tweet.latitude AS latitude,"+
					"	tweet.longitude AS longitude,"+
					"	'T' AS type "+
					"	FROM tw_tweet tweet "+
					" where   (tweet.latitude <> '0' and tweet.latitude <> '' and  tweet.longitude <> '0' and tweet.longitude <> '')" +
					" and tweet.id='"+tweeterActionVo.getTweetId()+"'"
					+ " union   " +
					"SELECT "+
					"	tweet.latitude AS latitude,"+
					"	tweet.longitude AS longitude,"+
					"	'RT' AS type "+
					"	FROM tw_tweet tweet "+
					" where   (tweet.latitude <> '0' and tweet.latitude <> '' and  tweet.longitude <> '0' and tweet.longitude <> '')" +
					" and tweet.retweet_source_id='"+tweeterActionVo.getTweetId()+"'" ;

			System.out.println("geoRptLatLong== "+query);

			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setLatitude(rs.get("latitude")==null?"":rs.get("latitude").toString());
				twitterVo.setLongitude(rs.get("longitude")==null?"":rs.get("longitude").toString());
				twitterVo.setType(rs.get("type")==null?"":rs.get("type").toString());
				lst.add(twitterVo);
			}
		}
		catch (Exception e) 
		{
			log.error("--------- Exception--------", e);
			e.printStackTrace();
		} 
		return lst; 
	}

	
	public CommonFbVo getCommonSocialData(TweeterActionVo tweeterActionVo, String type)
	{
		String query = ""; 
		CommonFbVo vo = new CommonFbVo();
		HashMap<String,String> imageMap = new HashMap<String,String>(); 
		HashSet<String> uniqueSet = new HashSet<String>();		
		LinkedHashMap<String, HashSet<String>> keyUniqueSet= new LinkedHashMap<String, HashSet<String>>();    

		try
		{
			int count=tweeterActionVo.getUserFilter().split(",").length;
			String userIds=twitterConstant.splitCommonValues(tweeterActionVo.getUserFilter());

			if(userIds.length()==0)		
			{
				System.out.println("No User Found");
				return null;
			}
			else
			{
				query = getQueryByType(type, userIds);
			}

			System.out.println("Common social media data "+type +" "+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				uniqueSet.add(rs.get("name").toString());
				imageMap.put(rs.get("name").toString(),rs.get("img").toString()); 
			}
			String[] users = tweeterActionVo.getUserFilter().split(",");
			for(String user:users)
			{
				keyUniqueSet.put(user, uniqueSet);	
			}
			vo.setUniqueSet(uniqueSet);
			vo.setKeyUniqueSet(keyUniqueSet);
			vo.setImageMap(imageMap);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return vo;
	}


	private String getQueryByType(String type, String param) 
	{
		String query = "";
		switch(type)
		{
		case "getCommonFriendFacebook":
			query= " SELECT * FROM ("
					+ "  SELECT *,COUNT(*) AS cnt FROM ( "
					+ " SELECT fb_scrap_user_friends.friendsAll_userName as name,fb_scrap_user_friends.friendsAll_userId AS id "+
					" FROM fb_scrap_user_friends  "+
					"  WHERE fb_scrap_user_friends.fb_userId IN ("+param+") "
					+ " )AS tbl  GROUP BY id ORDER BY cnt DESC "
					+ " ) AS tbl2 WHERE cnt >1 ";//+count;				
			break;

		case "getCommonGroupFacebook":
			query= " SELECT * FROM ("
					+ "  SELECT *,COUNT(*) AS cnt FROM ( "
					+ " SELECT fb_scrap_group.gp_name as name,fb_scrap_group.gp_Id AS id "+
					" FROM fb_scrap_group   "+
					"  WHERE fb_scrap_group.user_id IN ("+param+") "
					+ " )AS tbl  GROUP BY id ORDER BY cnt DESC "
					+ " ) AS tbl2 WHERE cnt >1 ";//+count;				
			break;

		case "getCommonEventFacebook":
			query= " SELECT * FROM ("
					+ "  SELECT *,COUNT(*) AS cnt FROM ( "
					+ " SELECT fb_scrap_user_event.event_text as name,fb_scrap_user_event.event_id AS id "+
					" FROM fb_scrap_user_event   "+
					"  WHERE fb_scrap_user_event.user_id IN ("+param+") "
					+ " )AS tbl  GROUP BY id ORDER BY cnt DESC "
					+ " ) AS tbl2 WHERE cnt >1 ";//+count;				
			break;

		case "getCommonLikesFacebook":
			query= " SELECT * FROM ("
					+ "  SELECT *,COUNT(*) AS cnt FROM ( "
					+ " SELECT fb_scrap_user_like_detail.liked_screenName as name,fb_scrap_user_like_detail.liked_userId AS id "+
					" FROM fb_scrap_user_like_detail   "+
					"  WHERE fb_scrap_user_like_detail.fb_user_id IN ("+param+") "
					+ " )AS tbl  GROUP BY id ORDER BY cnt DESC "
					+ " ) AS tbl2 WHERE cnt >1 ";//+count;				
			break;

		case "getCommonCheckinsFacebook":
			query= " SELECT * FROM ("
					+ "  SELECT *,COUNT(*) AS cnt FROM ( "
					+ " SELECT fb_scrap_user_check_in.check_in_name as name,fb_scrap_user_check_in.check_in_url AS id "+
					" FROM fb_scrap_user_check_in   "+
					"  WHERE fb_scrap_user_check_in.fb_user_id IN ("+param+") "
					+ " )AS tbl  GROUP BY id ORDER BY cnt DESC "
					+ " ) AS tbl2 WHERE cnt >1 ";//+count;				
			break;

		case "getCommonFollowerFollowingFO":
			query= " SELECT * FROM ("
					+ "  SELECT *,COUNT(*) AS cnt FROM ( "
					+ " SELECT twitter_followers.follower_name as name,twitter_followers.follower_screen_name  as screenName,twitter_followers.follower AS id ,twitter_followers.follower_img as img "+
					" FROM twitter_followers   "+
					"  WHERE twitter_followers.followed IN ("+param+") "
					+ " )AS tbl  GROUP BY id ORDER BY cnt DESC "
					+ " ) AS tbl2 WHERE cnt >1 limit 5000 ";//+count;				
			break;

		case "getCommonFollowerFollowingFR":
			query= " SELECT * FROM ("
					+ "  SELECT *,COUNT(*) AS cnt FROM ( "
					+ " SELECT twitter_followers.followed_name as name,twitter_followers.followed_screen_name  as screenName,twitter_followers.followed AS id,twitter_followers.followed_img as img  "+
					" FROM twitter_followers   "+
					"  WHERE twitter_followers.follower IN ("+param+") "
					+ " )AS tbl  GROUP BY id ORDER BY cnt DESC "
					+ " ) AS tbl2 WHERE cnt >1 limit 5000 ";//+count;				
			break;						
		}
		return query;
	}


	
	public ArrayList<TwitterVo> getCommonFollower_Following_Report(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> lst=new ArrayList <TwitterVo>();
		try
		{
			int count=tweeterActionVo.getUserFilter().split(",").length;
			String userIds=twitterConstant.splitCommonValues(tweeterActionVo.getUserFilter());
			if(userIds.length()==0)		
			{
				System.out.println("No User Found");
				return null;
			}
			String query="";
			if(tweeterActionVo.getType().equals("fo"))
			{
				query= " SELECT * FROM ("
						+ "  SELECT *,COUNT(*) AS cnt FROM ( "
						+ " SELECT twitter_followers.follower_name as name,twitter_followers.follower AS id "+
						" FROM twitter_followers   "+
						"  WHERE twitter_followers.followed IN ("+userIds+") "
						+ " )AS tbl  GROUP BY id ORDER BY cnt DESC "
						+ " ) AS tbl2 WHERE cnt >1 limit 200 ";//+count;
			}
			else if(tweeterActionVo.getType().equals("fr"))
			{
				query= " SELECT * FROM ("
						+ "  SELECT *,COUNT(*) AS cnt FROM ( "
						+ " SELECT twitter_followers.followed_name as name,twitter_followers.followed AS id "+
						" FROM twitter_followers   "+
						"  WHERE twitter_followers.follower IN ("+userIds+") "
						+ " )AS tbl  GROUP BY id ORDER BY cnt DESC "
						+ " ) AS tbl2 WHERE cnt >1 limit 200 ";//+count;
			}
			System.out.println("getCommonFollower_Following== "+tweeterActionVo.getType()+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				TwitterVo twitterVo=new  TwitterVo();
				twitterVo.setUserId(rs.get("id")==null?"":rs.get("id").toString());
				twitterVo.setUserName(rs.get("name")==null?"":rs.get("name").toString());
				lst.add(twitterVo);
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return lst;
	}


	
	public ArrayList<TwitterVo> getCommonFollower_Following_Source_Report(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		//JdbcTemplate jdbcTemplate=new JdbcTemplate(dataSource);
		String user=(String)httpSession.getAttribute(ApplicationConstants.LOGIN_USER);
		try
		{
			String  query=null;
			if(tweeterActionVo.getType().equals("src"))
			{
				query=" SELECT * FROM( "
						+ " SELECT source as name,source as id,COUNT(*) AS cnt FROM "
						+ " ( "
						+ " SELECT tw_tweet.entity_id,tw_tweet.source FROM tw_tweet  "
						+ " INNER JOIN  tbl_entity ON tbl_entity.id=tw_tweet.entity_id	"
						+ " WHERE  tbl_entity.tw_id  in("+tweeterActionVo.getUserFilter()+")"
						+ " GROUP BY tw_tweet.entity_id,tw_tweet.source ) AS tbl  GROUP BY source  "
						+ " ) AS tbl2 WHERE cnt>1 ORDER BY cnt DESC ";
			}

			System.out.println("getCommonFollower_Following_Source== "+tweeterActionVo.getType()+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);

			for(Map<String,Object> rs :rows)
			{
				TwitterVo twitterVo=new TwitterVo();
				String source=rs.get("name")==null?"":rs.get("name").toString();
				if(!source.isEmpty())
				{
					Document doc = Jsoup.parse(source);
					Element link = doc.select("a").first();
					source=link.text();
				}
				twitterVo.setName(source);
				twitterVo.setUserId(source);
				twitterVo.setCount(rs.get("cnt")==null?"0":rs.get("cnt").toString());
				lst.add(twitterVo);
			}
		}
		catch (Exception e) 
		{
			log.error("--------- Exception--------", e);
			e.printStackTrace();
		} 
		return lst;
	}


	
	public ArrayList<TwitterVo> getTweetDetailByParam(TweeterActionVo tweeterActionVo)
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		try
		{
			String subQuery= 
					"\"size\": 1,\n"+
							"\"query\": {\n"+
							"\"term\": {\n"+
							"\"articleId\": {\n"+
							"\"value\": \""+tweeterActionVo.getTweetId().trim()+"\"\n"+
							"}\n"+
							"}\n"+
							"}\n";
			String query="{\n"
					+subQuery
					+ "}\n";

			System.out.println("getTweetDetailByParam********** "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			List<Article_Datacollection_New> testLst = result.getSourceAsObjectList(Article_Datacollection_New.class);

			for (Article_Datacollection_New article_Datacollection_New : testLst) 
			{
				TwitterVo twitterVo=new TwitterVo();
				//twitterVo.setTotalTweetCount(Integer.toString(result.getTotal()));
				twitterVo.setTotalTweetCount(Long.toString(result.getTotal()));
				twitterVo.setArticleId(article_Datacollection_New.getArticleId());
				twitterVo.setArticleAuthor(article_Datacollection_New.getArticleAuthor());
				twitterVo.setArticleAuthorId(article_Datacollection_New.getArticleAuthorId());
				twitterVo.setArticleAuthorImage(article_Datacollection_New.getArticleAuthorImage());
				twitterVo.setArticlePublishDate(CommonUtils.convertUnixTimeToDateDisplayFormat((article_Datacollection_New.getArticlePublishDate())));
				twitterVo.setArticleTitle(article_Datacollection_New.getArticleTitle());
				twitterVo.setArticleSubTitle(article_Datacollection_New.getArticleSubTitle());
				twitterVo.setArticleSentiment(article_Datacollection_New.getArticleSentiment());
				twitterVo.setPriority("0");
				if(article_Datacollection_New.getArticleMarked() !=null)
				{
					if(article_Datacollection_New.getArticleMarked().size()>0)
					{
						String user=(String)httpSession.getAttribute(ApplicationConstants.LOGINUSERID);
						if(article_Datacollection_New.getArticleMarked().contains(user))
						{
							twitterVo.setPriority("1");
						}
					}
				}
				twitterVo.setTweet(article_Datacollection_New.getTweet());
				twitterVo.setYoutube(article_Datacollection_New.getYoutube());
				twitterVo.setDailymotion(article_Datacollection_New.getDailymotion());
				twitterVo.setInstagram(article_Datacollection_New.getInstagram());
				twitterVo.setFacebook(article_Datacollection_New.getFacebook());
				twitterVo.setWordpress(article_Datacollection_New.getWordpress());
				twitterVo.setBlogger(article_Datacollection_New.getBlogger());
				twitterVo.setArticleSource(article_Datacollection_New.getArticleSource());
				twitterVo.setArticleType(article_Datacollection_New.getArticleType());
				lst.add(twitterVo);
			}
		}
		catch (Exception e)
		{
			log.error("--------- Exception--------", e);
			e.printStackTrace();
		} 
		return lst; 
	}


	
	public ArrayList<CountryCode> getCountryCode()
	{
		ArrayList<CountryCode> lst=new ArrayList<CountryCode>();
		try
		{
			String query=" select * from countrycodes ";
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for (Map<String, Object> rs : rows) 
			{
				CountryCode code=new CountryCode();
				code.setCode(rs.get("code").toString());
				code.setCountry(rs.get("country").toString());
				code.setLat(rs.get("lat").toString());
				code.setLon(rs.get("lon").toString());
				code.setTimeZone(rs.get("timezone").toString());
				lst.add(code);
			}
		}	
		catch (Exception e) 
		{
			log.error(e);
		} 		
		return lst;
	}

	
	public ArrayList<TwitterVo> getMetaTags(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> lst=new ArrayList <TwitterVo>();
		try 
		{
			String rptCount="0";
			String path="articleLocationNer";
			String userLog="";
			switch(tweeterActionVo.getType().toLowerCase().trim()) 
			{
			case "person":
				rptCount=tweeterActionVo.getNoPer();
				path="articlePersonNer";
				userLog = "Fetching Person, Global Keyword Filter: "+tweeterActionVo.getKeywordFilter();
				commonUtils.insertUserActivityLogs(userLog);
				break;

			case "location":
				rptCount=tweeterActionVo.getNoPlace();
				path="articleLocationNer";
				userLog = "Fetching Place, Global Keyword Filter: "+tweeterActionVo.getKeywordFilter();
				commonUtils.insertUserActivityLogs(userLog);
				break;

			case "organization":
				rptCount=tweeterActionVo.getNoOrg();
				path="articleOrganizationNer";
				userLog = "Fetching Organization, Global Keyword Filter: "+tweeterActionVo.getKeywordFilter();
				commonUtils.insertUserActivityLogs(userLog);
				break;

			case "date":
				rptCount=tweeterActionVo.getNoNerDate();
				path="articleDateNer";
				break;
			}

			int size=TwitterConstant.getSizeForEsTermAgg(tweeterActionVo, rptCount);
			String sortQuery=TwitterConstant.getSortForEsTermAggNested(tweeterActionVo.getNerSortOrder().toLowerCase().trim(),"_count");
			String subQuery=rtnFilterQuery(tweeterActionVo, -1);
			String avgAgg="";
			if(tweeterActionVo.getOnlyCount().isEmpty())
			{
			    avgAgg=TwitterConstant.getAvg("articleSentiment");
			}

			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"termagg\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\""+path+".keyword\"\n,"+
					"\"size\":\""+size+"\"\n,"+
					sortQuery+
					"}\n"+
					avgAgg+
					"}\n"+
					"}\n"+
					"}\n";
			System.out.println("*****getMetatags()**"+path+"*** "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			TermsAggregation terms = result.getAggregations().getTermsAggregation("termagg");
			if(terms != null)
			{
				List<Entry> entry = terms.getBuckets();
				HashMap<String, ArrayList<String>> nerIgnoreKeyword = twitterConstant.getNerIgnoreKeywordsFromSession();
				
				ArrayList<String> persons = nerIgnoreKeyword.get("persons");
				ArrayList<String> places = nerIgnoreKeyword.get("places");
				ArrayList<String> organizations = nerIgnoreKeyword.get("organizations");
				
				for(Entry entry2 : entry) 
				{
					TwitterVo twitterVo=new TwitterVo();
					String key = entry2.getKey();
					Long count = entry2.getCount();
					
					if(twitterConstant.checkBlacklistKeyword(key)) 
					{
						switch(tweeterActionVo.getType().toLowerCase().trim())
						{
							case "person":
								if(persons != null && !persons.contains(key))
								{
									twitterVo.setHashtag(key);
									twitterVo.setHashCount(Long.toString(count));

									if(tweeterActionVo.getOnlyCount().isEmpty())
									{
										AvgAggregation avg=	entry2.getAvgAggregation("avg");
										twitterVo.setSentiment(Double.toString(avg.getAvg()));
									}
									lst.add(twitterVo);	
								}								
								break;	
							case "location":
								if(places != null && !places.contains(key))
								{
									twitterVo.setHashtag(key);
									twitterVo.setHashCount(Long.toString(count));

									if(tweeterActionVo.getOnlyCount().isEmpty())
									{
										AvgAggregation avg=	entry2.getAvgAggregation("avg");
										twitterVo.setSentiment(Double.toString(avg.getAvg()));
									}
									lst.add(twitterVo);
								}
								break;	
							case "organization":
								if(organizations != null && !organizations.contains(key))
								{
									twitterVo.setHashtag(key);
									twitterVo.setHashCount(Long.toString(count));
									if(tweeterActionVo.getOnlyCount().isEmpty())
									{
										AvgAggregation avg=	entry2.getAvgAggregation("avg");
										twitterVo.setSentiment(Double.toString(avg.getAvg()));
									}
									lst.add(twitterVo);
								}
								break;
						}
					}					
				}
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return lst; 
	}

	
	public ArrayList<TwitterVo> getMetaTags_withNested(TweeterActionVo tweeterActionVo)
	{
		ArrayList<TwitterVo> reportList=new ArrayList <TwitterVo>();
		try
        {
			String rptCount="0";
			String path="articleLocationNer";
			switch(tweeterActionVo.getType().toLowerCase().trim())
			{
			case "person":
				rptCount=tweeterActionVo.getNoPer();
				path="articlePersonNer";
				break;

			case "location":
				rptCount=tweeterActionVo.getNoPlace();
				path="articleLocationNer";
				break;

			case "organization":
				rptCount=tweeterActionVo.getNoOrg();
				path="articleOrganizationNer";
				break;

			case "date":
				rptCount=tweeterActionVo.getNoNerDate();
				path="articleDateNer";
				break;
			}
			int size=TwitterConstant.getSizeForEsTermAgg(tweeterActionVo,rptCount);	
			String sortQuery=TwitterConstant.getSortForEsTermAggNested(tweeterActionVo.getNerSortOrder().toLowerCase().trim(),"_count");
			String  subQuery=rtnFilterQuery(tweeterActionVo,-1);

			//With SUM
			/*			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\": {\n"+
					"\"termagg\": {\n"+ 
					"\"nested\": {\n"+
					"\"path\": \""+path+"\"\n"+
					"},\n"+
					"\"aggs\" : {\n"+
					"\"genres\" : {\n"+
					"\"terms\" : {\"field\" : \""+path+".keyword\" ,\n"+
					"\"size\":\""+size+"\"\n,"+
					sortQuery+
					"},\"aggs\": {\n"+
					"\"total_sum\": {\n"+
					"\"sum\": {\n"+
					"\"field\": \""+path+".count\"\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";
			 */	

			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\": {\n"+
					"\"termagg\": {\n"+ 
					"\"nested\": {\n"+
					"\"path\": \""+path+"\"\n"+
					"},\n"+
					"\"aggs\" : {\n"+
					"\"genres\" : {\n"+
					"\"terms\" : {\"field\" : \""+path+".keyword\" ,\n"+
					"\"size\":\""+size+"\"\n,"+
					sortQuery+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";

			System.out.println("*****getMetatags()**"+path+"*** "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			JsonElement jsonElement=result.getJsonObject().get("aggregations");
			JsonElement jsonElement1=jsonElement.getAsJsonObject().get("termagg").getAsJsonObject().get("genres").getAsJsonObject().get("buckets");
			JsonArray array=jsonElement1.getAsJsonArray();
			if(array.size()>0) 
			{
				for(int i = 0; i < array.size(); i++) 
				{
					TwitterVo twitterVo=new TwitterVo();
					if(twitterConstant.checkBlacklistKeyword(array.get(i).getAsJsonObject().get("key").getAsString()))
					{
						twitterVo.setHashtag(array.get(i).getAsJsonObject().get("key").getAsString());
						twitterVo.setHashCount(Integer.toString(array.get(i).getAsJsonObject().get("doc_count").getAsInt()));
						reportList.add(twitterVo);
					}					
				}
			}
		} 
		catch(Exception e) 
		{
			e.printStackTrace();
		}
		return reportList;
	}

	
	public ArrayList<TwitterVo> dashEntityCount(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		try 
		{
			String subQuery = rtnFilterQuery(tweeterActionVo,-1);
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\": {\n"+
					"\"sourceType\": {\n"+
					"\"terms\": {\n"+
					"\"field\": \"articleSource\"\n"+
					"}\n"+
					",\"aggs\":\n"+
					"{\n"+
					"\"dateHistogram\":{\n"+
					"\"date_histogram\":{\n"+
					"\"field\":\"articlePublishDate\",\n"+
					"\"interval\": \"day\",\n"+
					"\"min_doc_count\": 0,\n"+
					"\"extended_bounds\" : {\n"+ 
					"\"min\" : \""+TwitterConstant.convertStrToDate_yyyy_MM_dd(tweeterActionVo.getDateFrom())+"\",\n"+
					"\"max\" : \""+TwitterConstant.convertStrToDate_yyyy_MM_dd(tweeterActionVo.getDateTo())+"\"\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";   

			System.out.println("dashEntityCount()==== "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			JsonObject mainObj=result.getJsonObject();
			if(mainObj.has("aggregations")) 
			{
				JsonObject  aggObj=mainObj.getAsJsonObject("aggregations");
				if(aggObj.has("sourceType")) 
				{
					JsonObject  sourceTypeObj=aggObj.getAsJsonObject("sourceType");
					if(sourceTypeObj.has("buckets")) 
					{
						JsonArray bucketsArry=sourceTypeObj.getAsJsonArray("buckets");
						for(JsonElement jsonElement : bucketsArry)
						{
							TwitterVo twitterVo=new TwitterVo();
							twitterVo.setType(jsonElement.getAsJsonObject().get("key").getAsString());
							twitterVo.setCount(jsonElement.getAsJsonObject().get("doc_count").getAsString());
							ArrayList<TwitterChartVo> chartVoLst=new ArrayList<TwitterChartVo>();
							if(jsonElement.getAsJsonObject().has("dateHistogram")) 
							{
								JsonObject dthistogramObj=jsonElement.getAsJsonObject().getAsJsonObject("dateHistogram");
								if(dthistogramObj.has("buckets")) 
								{
									JsonArray innerBucketsArry=dthistogramObj.getAsJsonArray("buckets");  
									for(JsonElement jsonElement2 : innerBucketsArry)
									{
										TwitterChartVo chartVo2=new TwitterChartVo();
										chartVo2.setCreatedAt(CommonUtils.convertUnixTimeToDate_yyyy_mm_dd((jsonElement2.getAsJsonObject().get("key").getAsLong())));
										chartVo2.setCount(jsonElement2.getAsJsonObject().get("doc_count").getAsString());
										chartVoLst.add(chartVo2);
									}
								}
							}
							twitterVo.setTwitterChartVo(chartVoLst);
							lst.add(twitterVo);
						}
					}
				}
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return lst;
	}

	
	
	public ArrayList<TwitterVo> dashTimeLine(TweeterActionVo tweeterActionVo) 
	{
		System.out.println("1--------DateFrom-------------------- "+tweeterActionVo.getDateFrom());
		System.out.println("2--------DateTo---------------------- "+tweeterActionVo.getDateTo());
		
		
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		try 
		{
			//19 for exclude sentiment having 9
			String subQuery=rtnFilterQuery(tweeterActionVo, 19);
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"dateHistogram\":{\n"+
					"\"date_histogram\":{\n"+
					"\"field\":\"articlePublishDate\",\n"+
					"\"interval\": \"day\",\n"+
					"\"min_doc_count\": 0,\n"+
					"\"extended_bounds\" : {\n"+ 
					"\"min\" : \""+TwitterConstant.convertStrToDate_yyyy_MM_dd(tweeterActionVo.getDateFrom())+"\",\n"+
					"\"max\" : \""+TwitterConstant.convertStrToDate_yyyy_MM_dd(tweeterActionVo.getDateTo())+"\"\n"+
					"}\n"+
					"},\n"+
					"\"aggs\": {\n"+
					"\"sentiment\": {\n"+
					"\"avg\": {\n"+
					"\"field\": \"articleSentiment\"\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";

			System.out.println("dashTimeLine()==== "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			JSONObject obj = new JSONObject(result.getJsonString());
			if(obj.has("aggregations")) 
			{
				JSONArray bucketArr = obj.getJSONObject("aggregations").getJSONObject("dateHistogram").getJSONArray("buckets");
				for(int i = 0; i < bucketArr.length(); i++)
				{
					if(!bucketArr.getJSONObject(i).getJSONObject("sentiment").isNull("value"))
					{
						Long dateKey=bucketArr.getJSONObject(i).getLong("key");
						Double sentiment=bucketArr.getJSONObject(i).getJSONObject("sentiment").getDouble("value");
						TwitterVo twitterVo=new TwitterVo();
						twitterVo.setCreatedAt(CommonUtils.convertUnixTimeToDate_yyyy_mm_dd((dateKey)));
						twitterVo.setCount(Double.toString(sentiment));
						twitterVo.setTotalTweetCount(Long.toString(bucketArr.getJSONObject(i).getLong("doc_count")));

						if(Double.toString(bucketArr.getJSONObject(i).getJSONObject("sentiment").getDouble("value")).equals("0"))
						{
							System.out.println(bucketArr.getJSONObject(i).getJSONObject("sentiment").getDouble("value"));
						}

						switch(CommonUtils.isNegative(sentiment)) 
						{
						case 1:
							twitterVo.setType("positive");
							break;
						case 0:
							twitterVo.setType("neutral");
							break;
						case -1:
							twitterVo.setType("negative");
							break;
						default:
							break;
						}
						lst.add(twitterVo);
					}
				}
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return lst; 
	}

	
	
	public ArrayList<TwitterVo> dashTwTrends(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		return lst;
	}

	
	
	public ArrayList<TwitterVo> dashGeoMap(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		try 
		{
			String subQuery=rtnFilterQuery(tweeterActionVo,-1);
			String fieldName="articleLocationCountryCode";
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"termagg\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\""+fieldName+"\"\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";

			System.out.println(" dashGeoMap()==== "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			TermsAggregation terms = result.getAggregations().getTermsAggregation("termagg");
			List<Entry>  entry=  terms.getBuckets();
			for (Entry entry2 : entry) 
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setHashtag(entry2.getKey());
				twitterVo.setHashCount(Long.toString(entry2.getCount()));
				lst.add(twitterVo);
			}
		} 
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return lst;
	}

	
	public ArrayList<TwitterVo> dashActiveEntity(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> list = new ArrayList<TwitterVo>();
		ArrayList<String> lstCache = new ArrayList<String>();
		try 
		{
			String fieldName="";
			switch(tweeterActionVo.getType()) 
			{
			case "hashtag":
				fieldName="articleHashTag";
				break;
			case "user":
				fieldName="articleAuthor";
				break;
			case "mention":
				fieldName="articleMention";
				break;
			case "theme":
				fieldName="articleThemes";
				break;
			case "classification":
				fieldName="articleClassification";
				break;
			case "articletype":
				fieldName="articleType";
				break;
			case "place":
				fieldName="articleLocationNer.keyword";
				break;
			case "person":
				fieldName="articlePersonNer.keyword";
				break;
			case "org":
				fieldName="articleOrganizationNer.keyword";
				break;
			case "event":
				fieldName="articleEvent.keyword";
				break;
			case "mobile":
				fieldName="articleMobile";
				break;
			case "email":
				fieldName="articleEmail";
				break;
			default:
				break;
			}

			String subQuery=rtnFilterQuery(tweeterActionVo, -1);
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\": {\n"+
					"\"sourceType\": {\n"+
					"\"terms\": {\n"+
					"\"field\": \"articleSource\"\n"+
					"}\n"+
					",\"aggs\":\n"+
					"{\n"+
					"\"termaggs\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\""+fieldName+"\",\n"+
					"\"size\": \"10\"\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";

			System.out.println(tweeterActionVo.getType()+" dashActiveEntity()====:   "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			JsonObject mainObj=result.getJsonObject();
			if(mainObj.has("aggregations")) 
			{
				JsonObject  aggObj=mainObj.getAsJsonObject("aggregations");
				if(aggObj.has("sourceType"))
				{
					JsonObject  sourceTypeObj=aggObj.getAsJsonObject("sourceType");
					if(sourceTypeObj.has("buckets"))
					{
						JsonArray bucketsArry=sourceTypeObj.getAsJsonArray("buckets");
						for(JsonElement jsonElement : bucketsArry) 
						{
							TwitterVo twitterVo=new TwitterVo();
							twitterVo.setType(jsonElement.getAsJsonObject().get("key").getAsString());
							twitterVo.setCount(jsonElement.getAsJsonObject().get("doc_count").getAsString());
							ArrayList<TwitterChartVo> chartVoLst=new ArrayList<TwitterChartVo>();
							if(jsonElement.getAsJsonObject().has("termaggs"))
							{
								JsonObject dthistogramObj=jsonElement.getAsJsonObject().getAsJsonObject("termaggs");
								if(dthistogramObj.has("buckets")) 
								{
									JsonArray innerBucketsArry=dthistogramObj.getAsJsonArray("buckets");  
									for(JsonElement jsonElement2 : innerBucketsArry) 
									{
										if(twitterConstant.checkBlacklistKeyword(jsonElement2.getAsJsonObject().get("key").getAsString())) 
										{
											TwitterChartVo chartVo2=new TwitterChartVo();
											if(lstCache.indexOf(jsonElement2.getAsJsonObject().get("key").getAsString().trim())==-1) 
											{
												lstCache.add(jsonElement2.getAsJsonObject().get("key").getAsString().trim());
												chartVo2.setKey((jsonElement2.getAsJsonObject().get("key").getAsString()));
												chartVo2.setCount(jsonElement2.getAsJsonObject().get("doc_count").getAsString());
												chartVoLst.add(chartVo2);
											}
										}										
									}
								}
								twitterVo.setTwitterChartVo(chartVoLst);
								list.add(twitterVo);
							}
						}
					}
				}
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return list;
	}

	
	
	public ArrayList<TwitterVo> dashODSImage(TweeterActionVo tweeterActionVo)
	{
		ArrayList<TwitterVo> list = new ArrayList<TwitterVo>();
		try
		{
			String fieldName="";
			switch(tweeterActionVo.getType()) 
			{
			case "odsProfileImage":
				fieldName="profileImageOds";
				break;

			case "odsPostImage":
				fieldName="postImageOds";
				break;

			default:
				break;
			}
			
			String subQuery = rtnFilterQuery(tweeterActionVo, -1);
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"termaggODS\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\""+fieldName+"\"\n,"+
					"\"size\":\"100\"\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";

			System.out.println(tweeterActionVo.getType()+" dashODSImage()==== "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);			
			TermsAggregation terms = result.getAggregations().getTermsAggregation("termaggODS");
			List<Entry> entry = terms.getBuckets();
			for(Entry entry2 : entry) 
			{				
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setHashtag(entry2.getKey());
				twitterVo.setHashCount(Long.toString(entry2.getCount()));
				list.add(twitterVo);
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return list;
	}

	
	
	public ArrayList<TwitterVo> dashOCRImage(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> list = new ArrayList<TwitterVo>();
		try
		{
			String fieldName="postImageOcrAggs";
			String subQuery = rtnFilterQuery(tweeterActionVo, -1);
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"termaggOCR\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\""+fieldName+"\"\n,"+
					"\"size\":\"100\"\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";

			System.out.println("dashOCRImage()==== "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);			
			TermsAggregation terms = result.getAggregations().getTermsAggregation("termaggOCR");
			List<Entry> entry = terms.getBuckets();
			for(Entry entry2 : entry) 
			{				
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setHashtag(entry2.getKey());
				twitterVo.setHashCount(Long.toString(entry2.getCount()));
				list.add(twitterVo);
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return list;
	}
	
	
	
	public ArrayList<TwitterVo> dashActiveMedia(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> list=new ArrayList<TwitterVo>();
		
		try 
		{
			String subAggs=",\n"+
					"\"aggs\": {\n"+
					"\"myaggs\": {\n"+
					"\"top_hits\": {\n"+
					"\"_source\": {\n"+
					"\"include\": [\n"+
					"\"articleMedia\"\n"+
					"]"+
					"},"+
					"\"size\": 1\n"+
					"}"+
					"}"+
					"}";

			String fieldName="articleMedia.mediaUrl";
			switch(tweeterActionVo.getType()) 
			{
			case "image":
				fieldName="articleMedia.mediaThumbnail";
				break;
			case "video":
				fieldName="articleMedia.mediaThumbnail";
				break;
			case "url":
				fieldName="articleMedia.mediaUrl";
				break;
			case "domain":
				fieldName="articleMedia.mediaUrl";
				break;
		
			default:
				break;
			}
			
			String subQuery=rtnFilterQuery(tweeterActionVo, -1);
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\": {\n"+
					"\"sourceType\": {\n"+
					"\"terms\": {\n"+
					"\"field\": \"articleSource\"\n"+
					"}\n"+
					",\"aggs\":\n"+
					"{\n"+
					"\"termaggs\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\""+fieldName+"\",\n"+
					"\"size\": \"10\"\n"+
					"}\n"+subAggs+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";

			System.out.println(tweeterActionVo.getType()+" dashActiveMedia()==== "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			JsonObject mainObj=result.getJsonObject();
			if(mainObj.has("aggregations")) 
			{
				JsonObject aggObj=mainObj.getAsJsonObject("aggregations");
				if(aggObj.has("sourceType")) 
				{
					JsonObject  sourceTypeObj=aggObj.getAsJsonObject("sourceType");
					if(sourceTypeObj.has("buckets"))
					{
						JsonArray bucketsArry=sourceTypeObj.getAsJsonArray("buckets");
						for(JsonElement jsonElement : bucketsArry) 
						{
							TwitterVo twitterVo=new TwitterVo();
							twitterVo.setType(jsonElement.getAsJsonObject().get("key").getAsString());
							twitterVo.setCount(jsonElement.getAsJsonObject().get("doc_count").getAsString());
							ArrayList<TwitterChartVo> chartVoLst=new ArrayList<TwitterChartVo>();
							
							if(jsonElement.getAsJsonObject().has("termaggs")) 
							{
								JsonObject dthistogramObj=jsonElement.getAsJsonObject().getAsJsonObject("termaggs");
								if(dthistogramObj.has("buckets")) 
								{
									JsonArray innerBucketsArry=dthistogramObj.getAsJsonArray("buckets");  
									for(JsonElement jsonElement2 : innerBucketsArry) 
									{
										String key=(jsonElement2.getAsJsonObject().get("key").getAsString());
										String count=jsonElement2.getAsJsonObject().get("doc_count").getAsString();
										
										TwitterChartVo chartVo5=new TwitterChartVo();
										chartVo5.setMediaKey(key);
										chartVo5.setKey1(TwitterConstant.convertStringToMd5Image(chartVo5.getMediaKey()));								
										chartVo5.setMediaCount(count);

										chartVoLst.add(chartVo5);
										
										if(jsonElement2.getAsJsonObject().has("myaggs"))
										{
											if(jsonElement2.getAsJsonObject().getAsJsonObject("myaggs").has("hits")) 
											{
												if(jsonElement2.getAsJsonObject().getAsJsonObject("myaggs").getAsJsonObject("hits").has("hits")) 
												{
													JsonArray hits=	jsonElement2.getAsJsonObject().getAsJsonObject("myaggs").getAsJsonObject("hits").getAsJsonArray("hits");
													for(JsonElement jsonElement3 : hits) 
													{
														if(jsonElement3.getAsJsonObject().has("_source"))
														{
															if(jsonElement3.getAsJsonObject().getAsJsonObject("_source").has("articleMedia")) 
															{
																JsonArray articleMedia=jsonElement3.getAsJsonObject().getAsJsonObject("_source").getAsJsonArray("articleMedia"); 

																for(JsonElement jsonElement4 : articleMedia)
																{
																	if(jsonElement4.getAsJsonObject().get("mediaType").getAsString().equals(tweeterActionVo.getType())) 
																	{
																		TwitterChartVo chartVo2=new TwitterChartVo();
																		//twitterVo.setArticleAuthorImageUrlLocal(jsonElement4.getAsJsonObject().get("mediaThumbnailLocal").isJsonNull()?"": jsonElement4.getAsJsonObject().get("mediaThumbnailLocal").getAsString());
																		chartVo5.setLocalMediaKey(jsonElement4.getAsJsonObject().get("mediaThumbnailLocal").isJsonNull()?"": jsonElement4.getAsJsonObject().get("mediaThumbnailLocal").getAsString());
																		/*chartVo2.setKey(key);
																		chartVo2.setCount(count);
																		chartVo2.setKey1(jsonElement4.getAsJsonObject().get("mediaUrl").isJsonNull()?key: jsonElement4.getAsJsonObject().get("mediaUrl").getAsString());
																		chartVo2.setKey2(jsonElement4.getAsJsonObject().get("mediaThumbnailLocal").isJsonNull()?"": jsonElement4.getAsJsonObject().get("mediaThumbnailLocal").getAsString());
																		chartVoLst.add(chartVo2);*/																	
																	}
																}
																
															}
														}
													}
												}
											}
										}
										
										chartVoLst.add(chartVo5);
									}
								}
							}
							twitterVo.setTwitterChartVo(chartVoLst);
							list.add(twitterVo);
						}
					}
				}
			}
		} 
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return list;
	}
	

	
	
	public ArrayList<TwitterVo> dashArticles(TweeterActionVo tweeterActionVo)
	{
		ArrayList<TwitterVo> lst = new ArrayList<TwitterVo>();
		int size=Integer.parseInt(tweeterActionVo.getNoTweet());
		try 
		{
			String subAggs=",\n"+
					"\"aggs\": {\n"+
					"\"myaggs\": {\n"+
					"\"top_hits\": {\n"+
					"\"_source\": {\n"+
					"\"include\": [\n"+
					"\"*\"\n"+
					"]"+
					"},"+
					"\"size\": "+size+"\n"+
					getTweetsSortOrder(tweeterActionVo)
					+
					"}"+
					"}"+
					"}";
			
			String subQuery=rtnFilterQuery(tweeterActionVo, -1);
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\": {\n"+
					"\"sourceType\": {\n"+
					"\"terms\": {\n"+
					"\"field\": \"articleSource\"\n"+
					"}\n"+
					subAggs+
					"}\n"+
					"}\n"+
					"}\n";

			System.out.println("dashArticles()==== "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);

			JsonObject mainObj=result.getJsonObject();
			if(mainObj.has("aggregations"))
			{
				JsonObject aggObj=mainObj.getAsJsonObject("aggregations");
				if(aggObj.has("sourceType")) 
				{
					JsonObject  sourceTypeObj=aggObj.getAsJsonObject("sourceType");
					if(sourceTypeObj.has("buckets"))
					{
						JsonArray bucketsArry=sourceTypeObj.getAsJsonArray("buckets");
						for(JsonElement jsonElement : bucketsArry) 
						{
							String sourceType=jsonElement.getAsJsonObject().get("key").getAsString();
							String totalCount=jsonElement.getAsJsonObject().get("doc_count").getAsString();
							if(jsonElement.getAsJsonObject().has("myaggs")) 
							{
								JsonObject dthistogramObj=jsonElement.getAsJsonObject().getAsJsonObject("myaggs");
								if(dthistogramObj.has("hits")) 
								{
									JsonArray innerBucketsArry=dthistogramObj.getAsJsonObject("hits").getAsJsonArray("hits");  
									for(JsonElement jsonElement2 : innerBucketsArry)
									{
										TwitterVo twitterVo=new TwitterVo();
										twitterVo.setType(sourceType);
										twitterVo.setCount(totalCount);
										ObjectMapper mapper = new ObjectMapper();
										String source = jsonElement2.getAsJsonObject().get("_source").toString();

										Article_Datacollection_New article_Datacollection_New=mapper.readValue(source, Article_Datacollection_New.class);
										String link=article_Datacollection_New.getArticleLinkUrl();

										switch(article_Datacollection_New.getArticleSource()) 
										{
										case "tw":
											link="https://twitter.com/"+article_Datacollection_New.getArticleAuthor()+"/status/"+article_Datacollection_New.getArticleId();
											break;
										case "yt":
											link=article_Datacollection_New.getArticleLinkUrl();
											break;
										case "fb":
											break;
										case "insta":
											break;
										case "dm":
											break;
										case "gp":
											break;
										case "wp":
											break;
										case "tm":
											break;
										case "wb":
											break;
										case "article":
											link=article_Datacollection_New.getArticleLinkUrl();
											break;
										default:
											break;
										}

										twitterVo.setLink(link);
										twitterVo.setArticleId(article_Datacollection_New.getArticleId());
										twitterVo.setArticleAuthor(article_Datacollection_New.getArticleAuthor());
										twitterVo.setArticleAuthorId(article_Datacollection_New.getArticleAuthorId());
										twitterVo.setArticleAuthorImage(article_Datacollection_New.getArticleAuthorImage());
										twitterVo.setArticleAuthorImageUrlLocal(article_Datacollection_New.getArticleAuthorImageUrlLocal());
										twitterVo.setArticlePublishDate(CommonUtils.convertUnixTimeToDateDisplayFormat((article_Datacollection_New.getArticlePublishDate())));
										twitterVo.setArticleTitle(article_Datacollection_New.getArticleTitle());
										twitterVo.setArticleSubTitle(article_Datacollection_New.getArticleSubTitle());
										twitterVo.setArticleSentiment(article_Datacollection_New.getArticleSentiment());
										twitterVo.setArticleClassification(article_Datacollection_New.getArticleClassification());
										twitterVo.setArticleNewsSource(article_Datacollection_New.getArticleNewsSource());
										twitterVo.setPriority("0");

										if(article_Datacollection_New.getArticleMarked() !=null)
										{
											if(article_Datacollection_New.getArticleMarked().size()>0)
											{
												String user=(String)httpSession.getAttribute(ApplicationConstants.LOGINUSERID);
												for(int a : article_Datacollection_New.getArticleMarked()) 
												{
													System.out.println("----"+a);
												}
												if(article_Datacollection_New.getArticleMarked().indexOf(Integer.parseInt(user))>-1)
												{
													twitterVo.setPriority("1");
												}
											}
										}

										twitterVo.setTweet(article_Datacollection_New.getTweet());
										twitterVo.setYoutube(article_Datacollection_New.getYoutube());
										twitterVo.setDailymotion(article_Datacollection_New.getDailymotion());
										
										twitterVo.setInstagram(article_Datacollection_New.getInstagram());
										twitterVo.setFacebook(article_Datacollection_New.getFacebook());
										twitterVo.setWordpress(article_Datacollection_New.getWordpress());
										twitterVo.setBlogger(article_Datacollection_New.getBlogger());
										twitterVo.setArticleSource(article_Datacollection_New.getArticleSource());
										twitterVo.setArticleType(article_Datacollection_New.getArticleType());
										twitterVo.setArticleMedia(article_Datacollection_New.getArticleMedia());
																				
										lst.add(twitterVo);
									}
								}
							}
						}
					}
				}
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return lst;
	}
	
	
	
	public ArrayList<TwitterVo> dashActiveUser(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		try 
		{
			String subAggs=",\n"+
					"\"aggs\": {\n"+
					"\"myaggs\": {\n"+
					"\"top_hits\": {\n"+
					"\"_source\": {\n"+
					"\"include\": [\n"+
					"\"articleAuthorId\",\"articleAuthorImage\",\"articleAuthorImageUrlLocal\" \n"+
					"]"+
					"},"+
					"\"size\": 1\n"+
					"}"+
					"}"+
					"}";

			String fieldName="articleAuthor";
			String subQuery=rtnFilterQuery(tweeterActionVo,-1);
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\": {\n"+
					"\"sourceType\": {\n"+
					"\"terms\": {\n"+
					"\"field\": \"articleSource\"\n"+
					"}\n"+
					",\"aggs\":\n"+
					"{\n"+
					"\"termaggs\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\""+fieldName+"\",\n"+
					"\"size\": \"10\"\n"+
					"}\n"+subAggs+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";

			System.out.println(" dashActiveUser()==== "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			JsonObject mainObj=result.getJsonObject();
			if(mainObj.has("aggregations")) 
			{
				JsonObject  aggObj=mainObj.getAsJsonObject("aggregations");
				if(aggObj.has("sourceType")) 
				{
					JsonObject  sourceTypeObj=aggObj.getAsJsonObject("sourceType");
					if(sourceTypeObj.has("buckets"))
					{
						JsonArray bucketsArry=sourceTypeObj.getAsJsonArray("buckets");
						for (JsonElement jsonElement : bucketsArry) 
						{
							TwitterVo twitterVo=new TwitterVo();
							twitterVo.setType(jsonElement.getAsJsonObject().get("key").getAsString());
							twitterVo.setCount(jsonElement.getAsJsonObject().get("doc_count").getAsString());
							ArrayList<TwitterChartVo> chartVoLst=new ArrayList<TwitterChartVo>();
							
							if(jsonElement.getAsJsonObject().has("termaggs")) 
							{
								JsonObject dthistogramObj=jsonElement.getAsJsonObject().getAsJsonObject("termaggs");
								if(dthistogramObj.has("buckets")) 
								{
									JsonArray innerBucketsArry=dthistogramObj.getAsJsonArray("buckets");  
									for (JsonElement jsonElement2 : innerBucketsArry) 
									{
										String key=(jsonElement2.getAsJsonObject().get("key").getAsString());
										String count=jsonElement2.getAsJsonObject().get("doc_count").getAsString();
										if(jsonElement2.getAsJsonObject().has("myaggs")) 
										{
											if(jsonElement2.getAsJsonObject().getAsJsonObject("myaggs").has("hits")) 
											{
												if( jsonElement2.getAsJsonObject().getAsJsonObject("myaggs").getAsJsonObject("hits").has("hits")) 
												{
													JsonArray hits=	jsonElement2.getAsJsonObject().getAsJsonObject("myaggs").getAsJsonObject("hits").getAsJsonArray("hits");
													for (JsonElement jsonElement3 : hits) 
													{
														if (jsonElement3.getAsJsonObject().has("_source")) 
														{
															/***************************/
															TwitterChartVo chartVo2=new TwitterChartVo();
															chartVo2.setKey(key);
															chartVo2.setCount(count);

															if(jsonElement3.getAsJsonObject().getAsJsonObject("_source").has("articleAuthorId"))
															{
																if(!jsonElement3.getAsJsonObject().getAsJsonObject("_source").get("articleAuthorId").isJsonNull())
																{
																	chartVo2.setKey1(jsonElement3.getAsJsonObject().getAsJsonObject("_source").get("articleAuthorId").getAsString());
																} 
																else 
																{
																	chartVo2.setKey1("");
																}
															}

															if(jsonElement3.getAsJsonObject().getAsJsonObject("_source").has("articleAuthorImage")) 
															{
																if(!jsonElement3.getAsJsonObject().getAsJsonObject("_source").get("articleAuthorImage").isJsonNull()) 
																{
																	chartVo2.setKey2(jsonElement3.getAsJsonObject().getAsJsonObject("_source").get("articleAuthorImage").getAsString());
																}
																else
																{
																	chartVo2.setKey2("");
																}
															}

															if(jsonElement3.getAsJsonObject().getAsJsonObject("_source").has("articleAuthorImageUrlLocal")) {
																if(!jsonElement3.getAsJsonObject().getAsJsonObject("_source").get("articleAuthorImageUrlLocal").isJsonNull()) {
																	chartVo2.setKey3(jsonElement3.getAsJsonObject().getAsJsonObject("_source").get("articleAuthorImageUrlLocal").getAsString());
																} else {
																	chartVo2.setKey3("");
																}

															}																													
															chartVoLst.add(chartVo2);
															/**************************/
														}
													}
												}
											}
										}
									}
								}
							}
							twitterVo.setTwitterChartVo(chartVoLst);
							lst.add(twitterVo);
						}
					}
				}
			}
		} catch(Exception ex) {
			ex.printStackTrace();
		}
		return lst;
	}
	
	
	public ArrayList<TwitterVo> getTwWordCloud(TweeterActionVo tweeterActionVo)
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		try
		{
			String subAggs=",\n"+
					"\"aggs\": {\n"+
					"\"myaggs\": {\n"+
					"\"top_hits\": {\n"+
					"\"_source\": {\n"+
					"\"include\": [\n"+
					"\"articleTitle\",\"articleSubTitle\",\"articleBigContent\"\n"+
					"]"+
					"},"+
					"\"size\": "+tweeterActionVo.getRowNum()+"\n"+
					getTweetsSortOrder(tweeterActionVo)
					+
					"}"+
					"}"+
					"}";
			String subQuery=rtnFilterQuery(tweeterActionVo,19);
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\": {\n"+
					"\"sourceType\": {\n"+
					"\"terms\": {\n"+
					"\"field\": \"articleSource\"\n"+
					"}\n"+
					subAggs+
					"}\n"+
					"}\n"+
					"}\n";

			System.out.println("getTwWordCloud()==== "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			JsonObject mainObj=result.getJsonObject();
			ArrayList<String> lstWc=new ArrayList<String>();
			if(mainObj.has("aggregations"))
			{
				JsonObject  aggObj=mainObj.getAsJsonObject("aggregations");
				if(aggObj.has("sourceType"))
				{
					JsonObject  sourceTypeObj=aggObj.getAsJsonObject("sourceType");
					if(sourceTypeObj.has("buckets"))
					{
						JsonArray bucketsArry=sourceTypeObj.getAsJsonArray("buckets");
						for (JsonElement jsonElement : bucketsArry) 
						{
							if(jsonElement.getAsJsonObject().has("myaggs"))
							{
								JsonObject dthistogramObj=jsonElement.getAsJsonObject().getAsJsonObject("myaggs");
								if(dthistogramObj.has("hits"))
								{
									JsonArray innerBucketsArry=dthistogramObj.getAsJsonObject("hits").getAsJsonArray("hits");  
									for (JsonElement jsonElement2 : innerBucketsArry) 
									{
										ObjectMapper mapper = new ObjectMapper();
										if( !jsonElement2.getAsJsonObject().getAsJsonObject("_source").get("articleTitle").isJsonNull())
										{
											lstWc.add(jsonElement2.getAsJsonObject().getAsJsonObject("_source").get("articleTitle").toString().trim());
										}

										if( !jsonElement2.getAsJsonObject().getAsJsonObject("_source").get("articleSubTitle").isJsonNull())
										{
											lstWc.add(jsonElement2.getAsJsonObject().getAsJsonObject("_source").get("articleSubTitle").toString().trim());
										}
										if( !jsonElement2.getAsJsonObject().getAsJsonObject("_source").get("articleBigContent").isJsonNull())
										{
											lstWc.add(jsonElement2.getAsJsonObject().getAsJsonObject("_source").get("articleBigContent").toString().trim());
										}
									}
								}
							}
						}
					}
				}
			}
			if(lstWc.size()>0)     
			{ 
				final FrequencyAnalyzer frequencyAnalyzer = new FrequencyAnalyzer();  //It Calculate the word frequency
				frequencyAnalyzer.setWordFrequencesToReturn(300);
				frequencyAnalyzer.setMinWordLength(4);
				frequencyAnalyzer.setStopWords(TwitterConstant.loadStopWords());
				TwitterVo twitterVo=new TwitterVo();
				List<WordFrequency> wordFrequencies	 = frequencyAnalyzer.load(lstWc);
				if(wordFrequencies.size()>100)
				{
					wordFrequencies=wordFrequencies.subList(0, 20);
				}
				twitterVo.setWordFrequencies(wordFrequencies);
				lst.add(twitterVo);
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return lst; 
	}


	
	public ArrayList<TwitterVo> getPersonWordCloud(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> lst1=new ArrayList<TwitterVo>();
		tweeterActionVo.setIsRpt("y");
		tweeterActionVo.setType("person");
		tweeterActionVo.setNerSortOrder("cntdesc");
		if(tweeterActionVo.getZRptFlag().equals("no"))
		{
			tweeterActionVo.setNoPer("200");
		}
		else
		{
			tweeterActionVo.setNoPer("20");
		}
		
		try {
			ArrayList<TwitterVo> lst = getMetaTags(tweeterActionVo);
			List<WordFrequency> wordFrequencies	= new ArrayList<WordFrequency>();
			for(TwitterVo twitterVo:lst) {
				wordFrequencies.add(
						new WordFrequency(twitterVo.getHashtag(),Integer.parseInt(twitterVo.getHashCount()))
						);
			}
			TwitterVo twitterVo = new TwitterVo();
			twitterVo.setWordFrequencies(wordFrequencies);
			lst1.add(twitterVo);
		} catch(Exception e) {
			e.printStackTrace();
		}
		return lst1; 
	}

	
	public ArrayList<TwitterVo> getPlaceWordCloud(TweeterActionVo tweeterActionVo) 
	{
		tweeterActionVo.setIsRpt("y");
		tweeterActionVo.setType("location");
		tweeterActionVo.setNoPlace("300");
		tweeterActionVo.setNerSortOrder("cntdesc");
		ArrayList<TwitterVo> lst1=new ArrayList<TwitterVo>();
		try
		{
			ArrayList<TwitterVo> lst = getMetaTags(tweeterActionVo);
			List<WordFrequency> wordFrequencies	= new ArrayList<WordFrequency>();
			for(TwitterVo twitterVo:lst)
			{
				wordFrequencies.add(
						new WordFrequency(twitterVo.getHashtag(),Integer.parseInt(twitterVo.getHashCount()))
						);
			}
			TwitterVo twitterVo = new TwitterVo();
			twitterVo.setWordFrequencies(wordFrequencies);
			lst1.add(twitterVo);
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		} 
		return lst1; 
	}


	
	public ArrayList<TwitterVo> getOrganizationWordCloud(TweeterActionVo tweeterActionVo) 
	{
		tweeterActionVo.setIsRpt("y");
		tweeterActionVo.setType("organization");
		tweeterActionVo.setNoOrg("300");
		tweeterActionVo.setNerSortOrder("cntdesc");
		ArrayList<TwitterVo> lst1 = new ArrayList<TwitterVo>();
		try
		{
			ArrayList<TwitterVo> lst = getMetaTags(tweeterActionVo);
			List<WordFrequency> wordFrequencies	= new ArrayList<WordFrequency>();
			for(TwitterVo twitterVo:lst)
			{
				wordFrequencies.add(
						new WordFrequency(twitterVo.getHashtag(),Integer.parseInt(twitterVo.getHashCount()))
						);
			}
			TwitterVo twitterVo = new TwitterVo();
			twitterVo.setWordFrequencies(wordFrequencies);
			lst1.add(twitterVo);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		} 
		return lst1; 
	}


	
	public ArrayList<TwitterVo> getEventsWordCloud(TweeterActionVo tweeterActionVo) 
	{
		tweeterActionVo.setIsRpt("y");
		tweeterActionVo.setNoMention("300");
		tweeterActionVo.setMentionSortOrder("cntdesc");
		ArrayList<TwitterVo> lst1 = new ArrayList<TwitterVo>();
		try
		{
			ArrayList<TwitterVo> lst = getMention(tweeterActionVo);
			List<WordFrequency> wordFrequencies	= new ArrayList<WordFrequency>();
			for(TwitterVo twitterVo:lst)
			{
				wordFrequencies.add(
						new WordFrequency(twitterVo.getUserName(),Integer.parseInt(twitterVo.getUserCount()))
						);
			}
			TwitterVo twitterVo = new TwitterVo();
			twitterVo.setWordFrequencies(wordFrequencies);
			lst1.add(twitterVo);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		} 
		return lst1; 
	}


	
	public ArrayList<TwitterVo> geoCloud(TweeterActionVo tweeterActionVo)
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		try
		{
			int size=1;	
			String subQuery=rtnFilterQuery(tweeterActionVo, 19);
			String query="{\n"
					+ "\"size\":"+size+",\n"
					+subQuery+
					getTweetsSortOrder(tweeterActionVo)
					+ "}\n";
			System.out.println("**geoCloud()*****"+query);

			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.setParameter(Parameters.SIZE, 100)
					.setParameter(Parameters.SCROLL, "1m")
					.build();

			SearchResult result = client.execute(search);
			LinkedHashSet<String> lsttt=new LinkedHashSet<>();
			List<Article_Datacollection_New> testLst=   result.getSourceAsObjectList(Article_Datacollection_New.class);

			for(Article_Datacollection_New article_Datacollection_New : testLst) 
			{
				lsttt.add(article_Datacollection_New.getArticleId());
				TwitterVo twitterVo = new TwitterVo();
				String articleLocation=article_Datacollection_New.getArticleLocation();
				if(articleLocation !=null && !articleLocation.isEmpty())
				{
					twitterVo.setLatitude(articleLocation.split(",")[0]);
					twitterVo.setLongitude(articleLocation.split(",")[1]);
				}

				switch(tweeterActionVo.getComponentType().trim().toLowerCase()) 
				{
				case "hashtag":
					twitterVo.setArticleHashTag(article_Datacollection_New.getArticleHashTag());
					break;

				case "mention":
					twitterVo.setArticleMention(article_Datacollection_New.getArticleMention());
					break;

				case "user":
					twitterVo.setArticleAuthor(article_Datacollection_New.getArticleAuthor());
					break;

				case "place":
					twitterVo.setArticleLocationNer(article_Datacollection_New.getArticleLocationNer());
					break;

				case "person":
					twitterVo.setArticlePersonNer(article_Datacollection_New.getArticlePersonNer());
					break;

				case "org":
					twitterVo.setArticleOrganizationNer(article_Datacollection_New.getArticleOrganizationNer());
					break;

				case "themes":
					twitterVo.setArticleThemes(article_Datacollection_New.getArticleThemes());
					break;

				case "date":
					//twitterVo.setArticleDateNer(article_Datacollection_New.getArticleDateNer());
					break;

				case "language":
					twitterVo.setArticleLanguage(article_Datacollection_New.getArticleLanguage());
					break;

				case "country":
					twitterVo.setArticleLocationCountry(article_Datacollection_New.getArticleLocationCountry());
					break;

				case "city":
					twitterVo.setArticleLocationCity(article_Datacollection_New.getArticleLocationCity());
					break;

				case "phone":
					twitterVo.setArticleMobile(article_Datacollection_New.getArticleMobile());
					break;

				case "email":
					twitterVo.setArticleEmail(article_Datacollection_New.getArticleEmail());
					break;

				default:
					break;
				}
				lst.add(twitterVo);
			}

			//Get More Result by Scrolling
			if(result.getTotal()>0)
			{
				String scrolllId=result.getJsonObject().get("_scroll_id").getAsString();
				while(true)
				{
					System.out.println("Total Document in List::"+lsttt.size());
					if(lsttt.size()==1000)
					{
						break;
					}
					JestResult resultJest= twitterConstant.readMoreFromSearch(scrolllId,10l,client);	
					scrolllId=result.getJsonObject().get("_scroll_id").getAsString();
					testLst=   resultJest.getSourceAsObjectList(Article_Datacollection_New.class);
					if(testLst.size()==0)
					{
						break;
					}
					for(Article_Datacollection_New article_Datacollection_New : testLst) 
					{
						lsttt.add(article_Datacollection_New.getArticleId());
						TwitterVo twitterVo = new TwitterVo();
						twitterVo.setArticleSentiment(article_Datacollection_New.getArticleSentiment());
						String articleLocation=article_Datacollection_New.getArticleLocation();
						if(articleLocation !=null && !articleLocation.isEmpty())
						{
							twitterVo.setLatitude(articleLocation.split(",")[0]);
							twitterVo.setLongitude(articleLocation.split(",")[1]);
						}
						twitterVo.setSentiment(Integer.toString(article_Datacollection_New.getArticleSentiment()));

						switch(tweeterActionVo.getComponentType().trim().toLowerCase())
						{
						case "hashtag":
							twitterVo.setArticleHashTag(article_Datacollection_New.getArticleHashTag());
							break;

						case "mention":
							twitterVo.setArticleMention(article_Datacollection_New.getArticleMention());
							break;

						case "user":
							twitterVo.setArticleAuthor(article_Datacollection_New.getArticleAuthor());
							break;							

						case "place":
							twitterVo.setArticleLocationNer(article_Datacollection_New.getArticleLocationNer());
							break;

						case "person":
							twitterVo.setArticlePersonNer(article_Datacollection_New.getArticlePersonNer());
							break;

						case "org":
							twitterVo.setArticleOrganizationNer(article_Datacollection_New.getArticleOrganizationNer());
							break;	

						case "themes":
							twitterVo.setArticleThemes(article_Datacollection_New.getArticleThemes());
							break;

						case "date":
							//twitterVo.setArticleDateNer(article_Datacollection_New.getArticleDateNer());
							break;

						case "language":
							twitterVo.setArticleLanguage(article_Datacollection_New.getArticleLanguage());
							break;

						case "country":
							twitterVo.setArticleLocationCountry(article_Datacollection_New.getArticleLocationCountry());
							break;

						case "city":
							twitterVo.setArticleLocationCity(article_Datacollection_New.getArticleLocationCity());
							break;

						case "phone":
							twitterVo.setArticleMobile(article_Datacollection_New.getArticleMobile());
							break;

						case "email":
							twitterVo.setArticleEmail(article_Datacollection_New.getArticleEmail());
							break;

						default:
							break;
						}
						lst.add(twitterVo);
					}						
				}
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return lst; 
	}


	
	public ArrayList<TwitterVo> dashSourceCount(TweeterActionVo tweeterActionVo)
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		try
		{
			String  subQuery=rtnFilterQuery(tweeterActionVo,-1);
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\": {\n"+
					"\"sourceType\": {\n"+
					"\"terms\": {\n"+
					"\"field\": \"articleSource\"\n"+
					"}\n"+
					"}\n"+  
					"}\n"+ 
					"}\n";

			System.out.println("dashSourceCount()==== "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build(); 

			SearchResult result = client.execute(search);
			TermsAggregation terms = result.getAggregations().getTermsAggregation("sourceType");
			List<Entry>  entry=  terms.getBuckets();
			for (Entry entry2 : entry) 
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setType(entry2.getKey());
				twitterVo.setCount(Long.toString(entry2.getCount()));
				lst.add(twitterVo);
			}
		} 
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return lst;
	}


	public ArrayList<TwitterVo> timelineTrends_BySource(TweeterActionVo tweeterActionVo)
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		try
		{
			String fieldName="";
			switch (tweeterActionVo.getType()) 
			{
			case "hashtag":
				fieldName="articleHashTag";
				break;
			case "user":
				fieldName="articleAuthor";
				break;
			case "mention":
				fieldName="articleMention";
				break;
			case "theme":
				fieldName="articleThemes";
				break;
			case "classification":
				fieldName="articleClassification";
				break;
			case "articletype":
				fieldName="articleType";
				break;
			case "place":
				fieldName="articleLocationNer.keyword";
				break;
			case "person":
				fieldName="articlePersonNer.keyword";
				break;
			case "org":
				fieldName="articleOrganizationNer.keyword";
				break;
			default:
				break;
			}
			String  subQuery=rtnFilterQuery(tweeterActionVo,-1);

			String aggQuery=",\n"+
					"\"aggs\": {\n"+
					"\"sourceType\": {\n"+
					"\"terms\": {\n"+
					"\"field\": \"articleSource\"\n"+
					"}\n"+
					",\"aggs\":\n"+
					"{\n"+
					"\"termaggs\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\""+fieldName+"\",\n"+
					"\"size\": \"5\"\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";

			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"dateHistogram\":{\n"+
					"\"date_histogram\":{\n"+
					"\"field\":\"articlePublishDate\",\n"+
					"\"interval\": \"day\",\n"+
					"\"min_doc_count\": 0,\n"+
					"\"extended_bounds\" : {\n"+ 
					"\"min\" : \""+TwitterConstant.convertStrToDate_yyyy_MM_dd(tweeterActionVo.getDateFrom())+"\",\n"+
					"\"max\" : \""+TwitterConstant.convertStrToDate_yyyy_MM_dd(tweeterActionVo.getDateTo())+"\"\n"+
					"}\n"+
					"}\n"+
					aggQuery+
					"}\n"+
					"}\n"+
					"}\n";

			System.out.println(tweeterActionVo.getType()+" timelineTrends()==== "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			//System.out.println(result.getJsonString());
			JsonObject mainObj=result.getJsonObject();
			if(mainObj.has("aggregations"))
			{
				JsonObject  aggObj=mainObj.getAsJsonObject("aggregations");
				if(aggObj.has("dateHistogram"))
				{
					JsonObject  objHistogram=aggObj.getAsJsonObject("dateHistogram");
					if(objHistogram.has("buckets"))
					{
						JsonArray bucketsArryHisto=objHistogram.getAsJsonArray("buckets");
						for (JsonElement jsonElementHisto : bucketsArryHisto)
						{
							if(jsonElementHisto.getAsJsonObject().has("sourceType"))
							{
								JsonObject  sourceTypeObj=jsonElementHisto.getAsJsonObject().get("sourceType").getAsJsonObject();
								if(sourceTypeObj.has("buckets"))
								{
									JsonArray bucketsArry=sourceTypeObj.getAsJsonArray("buckets");
									for (JsonElement jsonElement : bucketsArry) 
									{
										if(jsonElement.getAsJsonObject().has("termaggs"))
										{
											JsonObject dthistogramObj=jsonElement.getAsJsonObject().getAsJsonObject("termaggs");
											if(dthistogramObj.has("buckets"))
											{
												JsonArray innerBucketsArry=dthistogramObj.getAsJsonArray("buckets");  
												for (JsonElement jsonElement2 : innerBucketsArry) 
												{
													// Hasthag,mention etc
													TwitterVo twitterVo=new TwitterVo();
													//date
													twitterVo.setCreatedAt(CommonUtils.convertUnixTimeToDate_yyyy_mm_dd(jsonElementHisto.getAsJsonObject().get("key").getAsLong()));
													//Source Type
													twitterVo.setType(jsonElement.getAsJsonObject().get("key").getAsString());
													twitterVo.setHashtag(jsonElement2.getAsJsonObject().get("key").getAsString());
													//Source Type Document Count
													twitterVo.setCount(jsonElement2.getAsJsonObject().get("doc_count").getAsString());
													lst.add(twitterVo);
												}
											}
										}
									}
								}
							}							

						}					
					}			
				}
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return lst;
	}



	
	public ArrayList<TwitterVo> timelineTrends(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> lst = new ArrayList<TwitterVo>();
		try
		{
			String fieldName="";
			switch (tweeterActionVo.getType()) 
			{
			case "hashtag":
				fieldName="articleHashTag";
				break;

			case "user":
				fieldName="articleAuthor";
				break;

			case "mention":
				fieldName="articleMention";
				break;

			case "theme":
				fieldName="articleThemes";
				break;

			case "classification":
				fieldName="articleClassification";
				break;

			case "articletype":
				fieldName="articleType";
				break;

			case "place":
				fieldName="articleLocationNer.keyword";
				break;

			case "person":
				fieldName="articlePersonNer.keyword";
				break;

			case "org":
				fieldName="articleOrganizationNer.keyword";
				break;

			default:
				break;
			}
			String subQuery=rtnFilterQuery(tweeterActionVo,-1);
			String aggQuery=",\n"+
					"\"aggs\": {\n"+
					"\"sourceType\": {\n"+
					"\"terms\": {\n"+
					"\"field\":\""+fieldName+"\",\n"+
					"\"size\": \"5\"\n"+
					"}\n"+
					",\"aggs\":\n"+
					"{\n"+
					"\"termaggs\":{\n"+
					"\"avg\":{\n"+
					"\"field\":\"articleSentiment\"\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";

			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"dateHistogram\":{\n"+
					"\"date_histogram\":{\n"+
					"\"field\":\"articlePublishDate\",\n"+
					"\"interval\": \"day\",\n"+
					"\"min_doc_count\": 0,\n"+
					"\"extended_bounds\" : {\n"+ 
					"\"min\" : \""+TwitterConstant.convertStrToDate_yyyy_MM_dd(tweeterActionVo.getDateFrom())+"\",\n"+
					"\"max\" : \""+TwitterConstant.convertStrToDate_yyyy_MM_dd(tweeterActionVo.getDateTo())+"\"\n"+
					"}\n"+
					"}\n"+
					aggQuery+
					"}\n"+
					"}\n"+
					"}\n";

			System.out.println(tweeterActionVo.getType()+" timelineTrends()==== "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			//System.out.println(result.getJsonString());
			JsonObject mainObj=result.getJsonObject();
			if(mainObj.has("aggregations"))
			{
				JsonObject  aggObj=mainObj.getAsJsonObject("aggregations");
				if(aggObj.has("dateHistogram"))
				{
					JsonObject  objHistogram=aggObj.getAsJsonObject("dateHistogram");
					if(objHistogram.has("buckets"))
					{
						JsonArray bucketsArryHisto=objHistogram.getAsJsonArray("buckets");
						for (JsonElement jsonElementHisto : bucketsArryHisto)
						{
							if(jsonElementHisto.getAsJsonObject().has("sourceType"))
							{
								JsonObject  sourceTypeObj=jsonElementHisto.getAsJsonObject().get("sourceType").getAsJsonObject();
								if(sourceTypeObj.has("buckets"))
								{
									JsonArray bucketsArry=sourceTypeObj.getAsJsonArray("buckets");
									for (JsonElement jsonElement : bucketsArry) 
									{
										// Hasthag,mention etc
										TwitterVo twitterVo=new TwitterVo();
										//date
										twitterVo.setCreatedAt(CommonUtils.convertUnixTimeToDate_yyyy_mm_dd(jsonElementHisto.getAsJsonObject().get("key").getAsLong()));
										//Source Type
										//twitterVo.setType(jsonElement.getAsJsonObject().get("key").getAsString());
										twitterVo.setHashtag(jsonElement.getAsJsonObject().get("key").getAsString());
										//Source Type Document Count
										twitterVo.setCount(jsonElement.getAsJsonObject().get("doc_count").getAsString());
										twitterVo.setType("neutral");
										if(jsonElement.getAsJsonObject().has("termaggs"))
										{
											JsonObject obj=	jsonElement.getAsJsonObject().get("termaggs").getAsJsonObject();
											if(obj.get("value").getAsFloat()>0)
											{
												twitterVo.setType("positive");
											}
											else if(obj.get("value").getAsFloat()==0)
											{
												twitterVo.setType("neutral");
											}
											else if(obj.get("value").getAsFloat()<0)
											{
												twitterVo.setType("negative");
											}
										}
										lst.add(twitterVo);
									}
								}
							}							

						}					
					}			
				}
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return lst;
	}


	
	public ArrayList<TwitterVo> mostCommentedUser(TweeterActionVo tweeterActionVo)
	{
		ArrayList<TwitterVo> reportList=new ArrayList <TwitterVo>();
		try
		{
			String subAggs=",\n"+
					"\"aggs\": {\n"+
					"\"myaggs\": {\n"+
					"\"top_hits\": {\n"+
					"\"_source\": {\n"+
					"\"include\": [\n"+
					"\"articleCommentUserName\"\n"+
					"]"+
					"},"+
					"\"size\": 1\n"+
					"}"+
					"}"+
					"}";

			String path="articleComment";
			int size=TwitterConstant.getSizeForEsTermAgg(tweeterActionVo,tweeterActionVo.getRowNum());	
			String sortQuery="";//TwitterConstant.getSortForEsTermAggNested(tweeterActionVo.getNerSortOrder().toLowerCase().trim(),"total_sum");
			String subQuery=rtnFilterQuery(tweeterActionVo,-1);
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\": {\n"+
					"\"termagg\": {\n"+ 
					"\"nested\": {\n"+
					"\"path\": \""+path+"\"\n"+
					"},\n"+
					"\"aggs\" : {\n"+
					"\"genres\" : {\n"+
					"\"terms\" : {\"field\" : \""+path+".articleCommentUserId\" ,\n"+
					"\"size\":\""+size+"\"\n"+
					sortQuery+
					"}\n"+subAggs+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";

			System.out.println("*****mostCommentedUser :: "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			JsonElement jsonElement=result.getJsonObject().get("aggregations");
			JsonElement jsonElement1=jsonElement.getAsJsonObject().get("termagg").getAsJsonObject().get("genres").getAsJsonObject().get("buckets");
			JsonArray array=jsonElement1.getAsJsonArray();

			for (JsonElement jsonBucket : array) 
			{
				String userId=jsonBucket.getAsJsonObject().get("key").getAsString();
				int count=jsonBucket.getAsJsonObject().get("doc_count").getAsInt();
				JsonObject	jsonMyAggs=jsonBucket.getAsJsonObject().get("myaggs").getAsJsonObject();
				JsonObject	jsonMyAggsHits=jsonMyAggs.getAsJsonObject().get("hits").getAsJsonObject();
				JsonArray	jsonHitsArray=jsonMyAggsHits.getAsJsonObject().get("hits").getAsJsonArray();

				for (JsonElement jsonHits : jsonHitsArray) 
				{
					JsonObject	jsonSource = jsonHits.getAsJsonObject().get("_source").getAsJsonObject();
					String articleCommentUserName=jsonSource.get("articleCommentUserName").getAsString();
					TwitterVo twitterVo=new TwitterVo();
					twitterVo.setUserName(articleCommentUserName);
					twitterVo.setUserId(userId);
					twitterVo.setUserCount(Integer.toString(count));
					reportList.add(twitterVo);
				}		   
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return reportList;
	}


	
	public ArrayList<TwitterVo> mostFbLikedUser(TweeterActionVo tweeterActionVo)
	{
		ArrayList<TwitterVo> reportList=new ArrayList <TwitterVo>();
		try 
		{
			String subAggs=",\n"+
					"\"aggs\": {\n"+
					"\"myaggs\": {\n"+
					"\"top_hits\": {\n"+
					"\"_source\": {\n"+
					"\"include\": [\n"+
					"\"fbFbUserName\"\n"+
					"]"+
					"},"+
					"\"size\": 1\n"+
					"}"+
					"}"+
					"}";

			String path="facebook.fbPostLikeUser";
			int size=TwitterConstant.getSizeForEsTermAgg(tweeterActionVo,tweeterActionVo.getRowNum());	
			String sortQuery="";//TwitterConstant.getSortForEsTermAggNested(tweeterActionVo.getNerSortOrder().toLowerCase().trim(),"total_sum");
			String subQuery=rtnFilterQuery(tweeterActionVo, -1);
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\": {\n"+
					"\"termagg\": {\n"+ 
					"\"nested\": {\n"+
					"\"path\": \""+path+"\"\n"+
					"},\n"+
					"\"aggs\" : {\n"+
					"\"genres\" : {\n"+
					"\"terms\" : {\"field\" : \""+path+".fbFbUserId\" ,\n"+
					"\"size\":\""+size+"\"\n"+
					sortQuery+
					"}\n"+subAggs+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";

			System.out.println("*****mostFbLikedUser ::  "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			JsonElement jsonElement=result.getJsonObject().get("aggregations");
			JsonElement jsonElement1=jsonElement.getAsJsonObject().get("termagg").getAsJsonObject().get("genres").getAsJsonObject().get("buckets");
			JsonArray array=jsonElement1.getAsJsonArray();
			for (JsonElement jsonBucket : array) 
			{
				String userId=jsonBucket.getAsJsonObject().get("key").getAsString();
				int count=jsonBucket.getAsJsonObject().get("doc_count").getAsInt();
				JsonObject	jsonMyAggs=jsonBucket.getAsJsonObject().get("myaggs").getAsJsonObject();
				JsonObject	jsonMyAggsHits=jsonMyAggs.getAsJsonObject().get("hits").getAsJsonObject();
				JsonArray	jsonHitsArray=jsonMyAggsHits.getAsJsonObject().get("hits").getAsJsonArray();
				for(JsonElement jsonHits : jsonHitsArray) 
				{
					JsonObject	jsonSource = jsonHits.getAsJsonObject().get("_source").getAsJsonObject();
					String articleCommentUserName=jsonSource.get("fbFbUserName").getAsString();
					TwitterVo twitterVo=new TwitterVo();
					twitterVo.setUserName(articleCommentUserName);
					twitterVo.setUserId(userId);
					twitterVo.setUserCount(Integer.toString(count));
					reportList.add(twitterVo);
				}		   
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return reportList;	
	}


	public ArrayList<TwitterVo> getAllDataForCommon_old(TweeterActionVo tweeterActionVo) 
	{
		try
		{
			int i=1;
			ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
			LinkedHashMap<String,TwitterVo> hsmap=new LinkedHashMap<String,TwitterVo>(); 
			ArrayList<MultipleEntryVo> multipleEntityList=tweeterActionVo.getMultipleEntityId();
			for (MultipleEntryVo multipleEntryVo : multipleEntityList) 
			{
				tweeterActionVo.setEntityIds(multipleEntryVo.getType2());
				int size=1;	
				String subQuery=rtnFilterQuery(tweeterActionVo,-1);
				String query="{\n"
						+ "\"size\":"+size+",\n"
						+ subQuery+
						getTweetsSortOrder(tweeterActionVo)
						+ "}\n";

				System.out.println("**geoAllDataForCommon()***** "+query);
				Search search = new Search.Builder(query)
						.addIndex(TwitterConstant.getDbname())
						.addType(TwitterConstant.getTypeName())
						.setParameter(Parameters.SIZE,1000)
						.setParameter(Parameters.SCROLL, "1m")
						.build();

				SearchResult result = client.execute(search);
				List<Article_Datacollection_New> lstArticleDatacollectionNew=new ArrayList<>();
				TwitterVo twitterVo=new TwitterVo();
				List<Article_Datacollection_New> testLst=   result.getSourceAsObjectList(Article_Datacollection_New.class);
				lstArticleDatacollectionNew.addAll(testLst);
				//Get More Result by Scrolling

				if(result.getTotal()>0)
				{
					String scrolllId=result.getJsonObject().get("_scroll_id").getAsString();
					while(true)
					{
						System.out.println("Total Document in List::"+lstArticleDatacollectionNew.size());
						if(lstArticleDatacollectionNew.size()>=Integer.parseInt(tweeterActionVo.getRowNum()))
						{
							break;
						}
						JestResult resultJest= twitterConstant.readMoreFromSearch(scrolllId,10l,client);	
						scrolllId=result.getJsonObject().get("_scroll_id").getAsString();
						testLst=   resultJest.getSourceAsObjectList(Article_Datacollection_New.class);
						if(testLst.size()==0)
						{
							break;
						}
						lstArticleDatacollectionNew.addAll(testLst);
					}
				}
				twitterVo.setLstArticleDatacollectionNew(lstArticleDatacollectionNew);
				hsmap.put(multipleEntryVo.getType1()+i, twitterVo);
				System.out.println("Data Fetching Complete for "+multipleEntryVo.getType1());
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return null; 
	}


	
	public CommonArticleVo getAllDataForCommon(TweeterActionVo tweeterActionVo)
	{		
		CommonArticleVo cvo = new CommonArticleVo();

		Set<Set<String>> cImages = new HashSet<Set<String>>();
		Set<Set<String>> cVideos = new HashSet<Set<String>>();		
		Set<Set<String>> cArticleCountry = new HashSet<Set<String>>();
		Set<Set<String>> cSource = new HashSet<Set<String>>();
		Set<Set<String>> cHashtag = new HashSet<Set<String>>();
		Set<Set<String>> cMention = new HashSet<Set<String>>();
		Set<Set<String>> cPersonNER = new HashSet<Set<String>>();
		Set<Set<String>> cOrgNER = new HashSet<Set<String>>();		
		Set<Set<String>> cLocationNER = new HashSet<Set<String>>();
		//LinkedHashMap<String,String> latLongLocationMap = new LinkedHashMap<String,String>();		
		Set<Set<String>> cDateNER = new HashSet<Set<String>>();
		Set<Set<String>> cThemes = new HashSet<Set<String>>();
		Set<Set<String>> cClass = new HashSet<Set<String>>();
		Set<Set<String>> cMobile = new HashSet<Set<String>>();
		Set<Set<String>> cEmail = new HashSet<Set<String>>();		
		Set<Set<String>> cLanguage = new HashSet<Set<String>>();
		Set<Set<String>> cLinkUrl = new HashSet<Set<String>>();
		Set<Set<String>> cCity = new HashSet<Set<String>>();		
		Set<Set<String>> cComment = new HashSet<Set<String>>();
		//LinkedHashMap<String,String> userIdNameMap = new LinkedHashMap<String,String>(); 		
		Set<Set<String>> cAuthor = new HashSet<Set<String>>();
		Set<Set<String>> cEmotion = new HashSet<Set<String>>();
		Set<Set<String>> cCountry = new HashSet<Set<String>>();
		Set<Set<String>> cCountryCode = new HashSet<Set<String>>();

		/*		LinkedHashMap<String, HashSet<String>> cvoImages= new LinkedHashMap<String, HashSet<String>>();
		LinkedHashMap<String, HashSet<String>> cvoVideos= new LinkedHashMap<String, HashSet<String>>();

		LinkedHashMap<String, HashSet<String>> cvoArticleCountry= new LinkedHashMap<String, HashSet<String>>();
		LinkedHashMap<String, HashSet<String>> cvoSource= new LinkedHashMap<String, HashSet<String>>();
		LinkedHashMap<String, HashSet<String>> cvoHashTags= new LinkedHashMap<String, HashSet<String>>();
		LinkedHashMap<String, HashSet<String>> cvoMentions= new LinkedHashMap<String, HashSet<String>>();
		LinkedHashMap<String, HashSet<String>> cvoPersons= new LinkedHashMap<String, HashSet<String>>();
		LinkedHashMap<String, HashSet<String>> cvoOrgs= new LinkedHashMap<String, HashSet<String>>();
		LinkedHashMap<String, HashSet<String>> cvoLocations= new LinkedHashMap<String, HashSet<String>>();
		LinkedHashMap<String, HashSet<String>> cvoDates= new LinkedHashMap<String, HashSet<String>>();
		LinkedHashMap<String, HashSet<String>> cvoThemes= new LinkedHashMap<String, HashSet<String>>();
		LinkedHashMap<String, HashSet<String>> cvoClassifications= new LinkedHashMap<String, HashSet<String>>();
		LinkedHashMap<String, HashSet<String>> cvoMobiles= new LinkedHashMap<String, HashSet<String>>();
		LinkedHashMap<String, HashSet<String>> cvoEmails= new LinkedHashMap<String, HashSet<String>>();
		LinkedHashMap<String, HashSet<String>> cvoComments= new LinkedHashMap<String, HashSet<String>>();
		LinkedHashMap<String, HashSet<String>> cvoAuthors= new LinkedHashMap<String, HashSet<String>>();
		LinkedHashMap<String, HashSet<String>> cvoEmotions= new LinkedHashMap<String, HashSet<String>>();
		LinkedHashMap<String, HashSet<String>> cvoCountries= new LinkedHashMap<String, HashSet<String>>();
		LinkedHashMap<String, HashSet<String>> cvoCountryCodes= new LinkedHashMap<String, HashSet<String>>();
		 */		
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		LinkedHashMap<String,TwitterVo> hsmap=new LinkedHashMap<String,TwitterVo>();
		LinkedHashMap<String,List<Article_Datacollection_New>> cMap=new LinkedHashMap<String,List<Article_Datacollection_New>>();

		try
		{
			int i=1;
			ArrayList<MultipleEntryVo> multipleEntityList=tweeterActionVo.getMultipleEntityId();
			for (MultipleEntryVo multipleEntryVo : multipleEntityList) 
			{
				tweeterActionVo.setUserSearchKeyword(multipleEntryVo.getType2().get(0));
				int size=1;	
				String subQuery=rtnFilterQuery(tweeterActionVo,-1);
				String query="{\n"
						+ "\"size\":"+size+",\n"
						+ subQuery+
						getTweetsSortOrder(tweeterActionVo)
						+ "}\n";

				System.out.println("**geoAllDataForCommon()***** "+query);
				Search search = new Search.Builder(query)
						.addIndex(TwitterConstant.getDbname())
						.addType(TwitterConstant.getTypeName())
						.setParameter(Parameters.SIZE,1000)
						.setParameter(Parameters.SCROLL, "1m")
						.build();

				SearchResult result = client.execute(search);
				List<Article_Datacollection_New> lstArticleDatacollectionNew=new ArrayList<>();
				TwitterVo twitterVo=new TwitterVo();
				List<Article_Datacollection_New> testLst=   result.getSourceAsObjectList(Article_Datacollection_New.class);
				lstArticleDatacollectionNew.addAll(testLst);
				//Get More Result by Scrolling
				if(result.getTotal()>0)
				{
					String scrolllId=result.getJsonObject().get("_scroll_id").getAsString();
					while(true)
					{
						System.out.println("Total Document in List::"+lstArticleDatacollectionNew.size());
						if(lstArticleDatacollectionNew.size()>=Integer.parseInt(tweeterActionVo.getRowNum()))
						{
							break;
						}
						JestResult resultJest= twitterConstant.readMoreFromSearch(scrolllId,10l,client);	
						scrolllId=result.getJsonObject().get("_scroll_id").getAsString();
						testLst=   resultJest.getSourceAsObjectList(Article_Datacollection_New.class);
						if(testLst.size()==0)
						{
							break;
						}
						lstArticleDatacollectionNew.addAll(testLst);
					}
				}

				twitterVo.setLstArticleDatacollectionNew(lstArticleDatacollectionNew);
				hsmap.put(multipleEntryVo.getType1()+i, twitterVo);
				System.out.println("Data Fetching Complete for "+multipleEntryVo.getType1());
				cMap.put(multipleEntryVo.getType1()+i, lstArticleDatacollectionNew);
			}

			for(java.util.Map.Entry<String, List<Article_Datacollection_New>> entry : cMap.entrySet())
			{
				String key = entry.getKey();
				List<Article_Datacollection_New> values = entry.getValue();

				HashSet<String> imageList = new HashSet<String>();
				HashSet<String> videoList = new HashSet<String>();			    
				HashSet<String> articleCountryList = new HashSet<String>();
				HashSet<String> sourceList = new HashSet<String>();
				HashSet<String> hashTagList = new HashSet<String>(); 
				HashSet<String> mentionList = new HashSet<String>();
				HashSet<String> themeList = new HashSet<String>();
				HashSet<String> classList = new HashSet<String>();
				HashSet<String> mobileList = new HashSet<String>();
				HashSet<String> emailList = new HashSet<String>();
				HashSet<String> commentList2 = new HashSet<String>();
				HashSet<String> emotionList = new HashSet<String>();
				HashSet<String> authorList = new HashSet<String>();
				HashSet<String> persons = new HashSet<String>(); 
				HashSet<String> orgs = new HashSet<String>();
				HashSet<String> locs = new HashSet<String>();
				HashSet<String> dats = new HashSet<String>();
				HashSet<String> countryList = new HashSet<String>();
				HashSet<String> countryCodeList = new HashSet<String>();			    
				HashSet<String> languageList = new HashSet<String>();
				HashSet<String> linkUrlList = new HashSet<String>();
				HashSet<String> cityList = new HashSet<String>();

				for(Article_Datacollection_New adn:values)
				{
					if(adn.getArticleId()!=null && adn.getArticleId().trim().length()>0)
					{
						if(adn.getArticleMedia()!=null && adn.getArticleMedia().size()>0)
						{
							ArrayList<Article_Media> xList= adn.getArticleMedia();
							for(Article_Media x:xList)
							{
								if(x.getMediaType()!=null && x.getMediaType().trim().length()>0)
								{
									if(x.getMediaType().equalsIgnoreCase("image"))
									{
										imageList.add(x.getMediaThumbnail());
									}

									if(x.getMediaType().equalsIgnoreCase("video"))
									{
										videoList.add(x.getMediaThumbnail());
									}			    					
								}
							}
						}
					}

					if(adn.getArticleLocation()!=null && adn.getArticleLocation().trim().length()>0)
					{
						articleCountryList.add(adn.getArticleLocation());
					}

					if(adn.getArticleSource()!=null && adn.getArticleSource().trim().length()>0)
					{
						sourceList.add(adn.getArticleSource());
					}

					if(adn.getArticleHashTag()!=null && adn.getArticleHashTag().size()>0)
					{
						hashTagList.addAll(adn.getArticleHashTag());
					}

					if(adn.getArticleMention()!=null && adn.getArticleMention().size()>0)
					{
						mentionList.addAll(adn.getArticleMention());
					}

					if(adn.getArticleThemes()!=null && adn.getArticleThemes().size()>0)
					{
						themeList.addAll(adn.getArticleThemes());
					}

					if(adn.getArticleClassification()!=null && adn.getArticleClassification().size()>0)
					{
						classList.addAll(adn.getArticleClassification());
					}

					if(adn.getArticleMobile()!=null && adn.getArticleMobile().size()>0)
					{
						mobileList.addAll(adn.getArticleMobile());
					}

					if(adn.getArticleEmail()!=null && adn.getArticleEmail().size()>0)
					{
						emailList.addAll(adn.getArticleEmail());
					}

					if(adn.getArticleEmotion()!=null && adn.getArticleEmotion().trim().length()>0)
					{
						emotionList.add(adn.getArticleEmotion());
					}

					if(adn.getArticleLanguage()!=null && adn.getArticleLanguage().trim().length()>0)
					{
						languageList.add(adn.getArticleLanguage());
					}

					if(adn.getArticleLinkUrl()!=null && adn.getArticleLinkUrl().trim().length()>0)
					{
						linkUrlList.add(adn.getArticleLinkUrl());
					}

					ArrayList<Articel_Comment> commentList = adn.getArticleComment();
					if(commentList!=null)
					{
						for(Articel_Comment c:commentList)
						{
							commentList2.add(c.getArticleCommentUserName());
							//userIdNameMap.put(c.getArticleCommentUserName(), c.getArticleCommentUserId());
						}
					}

					ArrayList<Articel_Ner> personNERList = adn.getArticlePersonNer();			    	
					if(personNERList!=null)
					{
						for(Articel_Ner p:personNERList)
						{
							persons.add(p.getKeyword());
						}
					}

					ArrayList<Articel_Ner> orgNERList = adn.getArticleOrganizationNer();
					if(orgNERList!=null)
					{
						for(Articel_Ner o:orgNERList)
						{
							orgs.add(o.getKeyword());
						}
					}

					ArrayList<Article_NerLocation> locationNERList = adn.getArticleLocationNer();
					if(locationNERList!=null)
					{
						for(Article_NerLocation l:locationNERList)
						{
							//latLongLocationMap.put(l.getKeyword(),l.getNerCountry()+"_"+l.getNerLatLong());
							locs.add(l.getKeyword());
						}
					}

					ArrayList<Artilcle_Ner_Date> dateNERList = adn.getArticleDateNer();
					if(dateNERList!=null)
					{
						for(Artilcle_Ner_Date d:dateNERList)
						{
							dats.add(d.getKeyword());
						}
					}

					if(adn.getArticleAuthor()!=null && adn.getArticleAuthor().trim().length()>0)
					{
						authorList.add(adn.getArticleAuthor());
					}

					if(adn.getArticleLocationCountry()!=null && adn.getArticleLocationCountry().trim().length()>0)
					{
						countryList.add(adn.getArticleLocationCountry());
					}

					if(adn.getArticleLocationCountryCode()!=null && adn.getArticleLocationCountryCode().trim().length()>0)
					{
						countryCodeList.add(adn.getArticleLocationCountryCode());
					}

					if(adn.getArticleLocationCity()!=null && adn.getArticleLocationCity().trim().length()>0)
					{
						cityList.add(adn.getArticleLocationCity());
					}

				}

				cImages.add(imageList);
				//cvoImages.put(key, imageList);

				cVideos.add(videoList);
				//cvoVideos.put(key, videoList);

				cArticleCountry.add(articleCountryList);
				//cvoArticleCountry.put(key, articleCountryList);

				cSource.add(sourceList);
				//cvoSource.put(key, sourceList);

				cHashtag.add(hashTagList);
				//cvoHashTags.put(key, hashTagList);

				cMention.add(mentionList);
				//cvoMentions.put(key, mentionList);

				cPersonNER.add(persons);
				//cvoPersons.put(key, persons);

				cOrgNER.add(orgs);
				//cvoOrgs.put(key, orgs);

				cLocationNER.add(locs);
				//cvoLocations.put(key, locs);

				cDateNER.add(dats);
				//cvoDates.put(key, dats);

				cThemes.add(themeList);
				//cvoThemes.put(key, themeList);

				cClass.add(classList);
				//cvoClassifications.put(key, classList);

				cMobile.add(mobileList);
				//cvoMobiles.put(key, mobileList);

				cEmail.add(emailList);
				//cvoEmails.put(key, emailList);

				cComment.add(commentList2);
				//cvoComments.put(key, commentList2);

				cAuthor.add(authorList);
				//cvoAuthors.put(key, authorList);

				cEmotion.add(emotionList);
				//cvoEmotions.put(key, emotionList);

				cLanguage.add(languageList);			    
				cLinkUrl.add(linkUrlList);
				cCity.add(cityList);

				cCountry.add(countryList);
				//cvoCountries.put(key, countryList);

				cCountryCode.add(countryCodeList);
				//cvoCountryCodes.put(key, countryCodeList);
			}

			Set<String> cimg = CollectionUtil.getCommonElements(cImages);
			cvo.setImage(cimg);
			//cvo.setImages(cvoImages);

			Set<String> cvid = CollectionUtil.getCommonElements(cVideos);
			cvo.setVideo(cvid);
			//cvo.setVideos(cvoVideos);

			Set<String> cac = CollectionUtil.getCommonElements(cArticleCountry);
			cvo.setArticleCountry(cac);
			//cvo.setArticleCountries(cvoArticleCountry);			

			Set<String> cs = CollectionUtil.getCommonElements(cSource);
			cvo.setSource(cs);
			//cvo.setSources(cvoSource);

			Set<String> ch = CollectionUtil.getCommonElements(cHashtag);
			cvo.setHashTag(ch);
			//cvo.setHashTags(cvoHashTags);

			Set<String> cm = CollectionUtil.getCommonElements(cMention);
			cvo.setMention(cm);
			//cvo.setMentions(cvoMentions);

			Set<String> cp = CollectionUtil.getCommonElements(cPersonNER);
			cvo.setPerson(cp);
			//cvo.setPersons(cvoPersons);

			Set<String> co = CollectionUtil.getCommonElements(cOrgNER);
			cvo.setOrg(co);
			//cvo.setOrgs(cvoOrgs);

			Set<String> cl = CollectionUtil.getCommonElements(cLocationNER);
			cvo.setLocation(cl);
			//cvo.setLocations(cvoLocations);

			Set<String> cd = CollectionUtil.getCommonElements(cDateNER);
			cvo.setDate(cd);
			//cvo.setDates(cvoDates);

			Set<String> ct = CollectionUtil.getCommonElements(cThemes);
			cvo.setTheme(ct);
			//cvo.setThemes(cvoThemes);

			Set<String> cc = CollectionUtil.getCommonElements(cClass);
			cvo.setClassification(cc);
			//cvo.setClassifications(cvoClassifications);

			Set<String> cmo = CollectionUtil.getCommonElements(cMobile);
			cvo.setMobile(cmo);
			//cvo.setMobiles(cvoMobiles);

			Set<String> ce = CollectionUtil.getCommonElements(cEmail);
			cvo.setEmail(ce);
			//cvo.setEmails(cvoEmails);

			Set<String> ccom = CollectionUtil.getCommonElements(cComment);
			cvo.setComment(ccom);
			//cvo.setComments(cvoComments);

			Set<String> ca = CollectionUtil.getCommonElements(cAuthor);
			cvo.setAuthor(ca);
			//cvo.setAuthors(cvoAuthors);

			Set<String> cem = CollectionUtil.getCommonElements(cEmotion);
			cvo.setEmotion(cem);
			//cvo.setEmotions(cvoEmotions);

			Set<String> lng = CollectionUtil.getCommonElements(cLanguage);
			cvo.setLanguage(lng);

			Set<String> url = CollectionUtil.getCommonElements(cLinkUrl);
			cvo.setLink(url);

			Set<String> ccitys = CollectionUtil.getCommonElements(cCity);
			cvo.setCity(ccitys);

			Set<String> cco = CollectionUtil.getCommonElements(cCountry);
			cvo.setCountry(cco);
			//cvo.setCountries(cvoCountries);

			Set<String> ccocode = CollectionUtil.getCommonElements(cCountryCode);
			cvo.setCountryCode(ccocode);
			//cvo.setCountryCodes(cvoCountryCodes);

			//cvo.setLatlongLocationMap(latLongLocationMap);
			//cvo.setUserIdNameMap(userIdNameMap);
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return cvo; 
	}



	
	public ArrayList<TwitterVo> getCommonFriendFacebook(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> lst=new ArrayList <TwitterVo>();
		try
		{
			int count=tweeterActionVo.getUserFilter().split(",").length;
			String userIds=twitterConstant.splitCommonValues(tweeterActionVo.getUserFilter());
			System.out.println("----00"+userIds);

			if(userIds.length()==0)		
			{
				System.out.println("No User Found");
				return null;
			}
			String query= " SELECT * FROM ("
					+ "  SELECT *,COUNT(*) AS cnt FROM ( "
					+ " SELECT fb_scrap_user_friends.friendsAll_userName as name,fb_scrap_user_friends.friendsAll_userId AS id "+
					" FROM fb_scrap_user_friends  "+
					"  WHERE fb_scrap_user_friends.fb_userId IN ("+userIds+") "
					+ " )AS tbl  GROUP BY id ORDER BY cnt DESC "
					+ " ) AS tbl2 WHERE cnt >1 ";//+count;

			System.out.println("getCommonFriendFacebook:: "+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				TwitterVo twitterVo=new  TwitterVo();
				twitterVo.setUserId(rs.get("id")==null?"":rs.get("id").toString());
				twitterVo.setUserName(rs.get("name")==null?"":rs.get("name").toString());
				lst.add(twitterVo);
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return lst;
	}


	
	public ArrayList<TwitterVo> getCommonGroupFacebook(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> lst=new ArrayList <TwitterVo>();
		try
		{
			int count=tweeterActionVo.getUserFilter().split(",").length;
			String userIds=twitterConstant.splitCommonValues(tweeterActionVo.getUserFilter());
			if(userIds.length()==0)		
			{
				System.out.println("No User Found");
				return null;
			}
			String	query= " SELECT * FROM ("
					+ "  SELECT *,COUNT(*) AS cnt FROM ( "
					+ " SELECT fb_scrap_group.gp_name as name,fb_scrap_group.gp_Id AS id "+
					" FROM fb_scrap_group   "+
					"  WHERE fb_scrap_group.user_id IN ("+userIds+") "
					+ " )AS tbl  GROUP BY id ORDER BY cnt DESC "
					+ " ) AS tbl2 WHERE cnt >1 ";//+count;

			System.out.println("getCommonGroupFacebook:: "+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				TwitterVo twitterVo=new  TwitterVo();
				twitterVo.setUserId(rs.get("id")==null?"":rs.get("id").toString());
				twitterVo.setUserName(rs.get("name")==null?"":rs.get("name").toString());
				lst.add(twitterVo);
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return lst;
	}


	
	public ArrayList<TwitterVo> getCommonLikesFacebook(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> lst=new ArrayList <TwitterVo>();
		try
		{
			int count=tweeterActionVo.getUserFilter().split(",").length;
			String userIds=twitterConstant.splitCommonValues(tweeterActionVo.getUserFilter());
			if(userIds.length()==0)		
			{
				System.out.println("No User Found");
				return null;
			}
			String query= " SELECT * FROM ("
					+ "  SELECT *,COUNT(*) AS cnt FROM ( "
					+ " SELECT fb_scrap_user_like_detail.liked_screenName as name,fb_scrap_user_like_detail.liked_userId AS id "+
					" FROM fb_scrap_user_like_detail   "+
					"  WHERE fb_scrap_user_like_detail.fb_user_id IN ("+userIds+") "
					+ " )AS tbl  GROUP BY id ORDER BY cnt DESC "
					+ " ) AS tbl2 WHERE cnt >1 ";//+count;

			System.out.println("getCommonLikesFacebook:: "+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				TwitterVo twitterVo=new  TwitterVo();
				twitterVo.setUserId(rs.get("id")==null?"":rs.get("id").toString());
				twitterVo.setUserName(rs.get("name")==null?"":rs.get("name").toString());
				lst.add(twitterVo);
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return lst;
	}


	
	public ArrayList<TwitterVo> getCommonCheckinsFacebook(TweeterActionVo tweeterActionVo)
	{
		ArrayList<TwitterVo> lst=new ArrayList <TwitterVo>();
		try
		{
			int count=tweeterActionVo.getUserFilter().split(",").length;
			String userIds=twitterConstant.splitCommonValues(tweeterActionVo.getUserFilter());
			if(userIds.length()==0)		
			{
				System.out.println("No User Found");
				return null;
			}
			String query= " SELECT * FROM ("
					+ "  SELECT *,COUNT(*) AS cnt FROM ( "
					+ " SELECT fb_scrap_user_check_in.check_in_name as name,fb_scrap_user_check_in.check_in_url AS id "+
					" FROM fb_scrap_user_check_in   "+
					"  WHERE fb_scrap_user_check_in.fb_user_id IN ("+userIds+") "
					+ " )AS tbl  GROUP BY id ORDER BY cnt DESC "
					+ " ) AS tbl2 WHERE cnt >1 ";//+count;
			System.out.println("getCommonCheckinsFacebook:: "+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);

			for(Map<String,Object> rs :rows)
			{
				TwitterVo twitterVo=new  TwitterVo();
				twitterVo.setUserId(rs.get("id")==null?"":rs.get("id").toString());
				twitterVo.setUserName(rs.get("name")==null?"":rs.get("name").toString());
				lst.add(twitterVo);
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return lst;
	}


	
	public ArrayList<TwitterVo> getCommonEventFacebook(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> lst=new ArrayList <TwitterVo>();
		try
		{
			int count=tweeterActionVo.getUserFilter().split(",").length;
			String userIds=twitterConstant.splitCommonValues(tweeterActionVo.getUserFilter());
			if(userIds.length()==0)		
			{
				System.out.println("No User Found");
				return null;
			}
			String query= " SELECT * FROM ("
					+ "  SELECT *,COUNT(*) AS cnt FROM ( "
					+ " SELECT fb_scrap_user_event.event_text as name,fb_scrap_user_event.event_id AS id "+
					" FROM fb_scrap_user_event   "+
					"  WHERE fb_scrap_user_event.user_id IN ("+userIds+") "
					+ " )AS tbl  GROUP BY id ORDER BY cnt DESC "
					+ " ) AS tbl2 WHERE cnt >1 ";//+count;

			System.out.println("getCommonEventFacebook:: "+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				TwitterVo twitterVo=new  TwitterVo();
				twitterVo.setUserId(rs.get("id")==null?"":rs.get("id").toString());
				twitterVo.setUserName(rs.get("name")==null?"":rs.get("name").toString());
				lst.add(twitterVo);
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return lst;
	}


	
	public ArrayList<TwitterVo> getThemes(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> lst = new ArrayList<TwitterVo>();
		try 
		{
			int size = TwitterConstant.getSizeForEsTermAgg(tweeterActionVo, tweeterActionVo.getNoThemes());	
			String sortQuery = TwitterConstant.getSortForEsTermAgg(tweeterActionVo.getThemeSortOrder().toLowerCase().trim());
			String subQuery = rtnFilterQuery(tweeterActionVo, -1);

			String avgAgg="";
			if(tweeterActionVo.getOnlyCount().isEmpty())
			{
			   avgAgg=TwitterConstant.getAvg("articleSentiment");
			}
			
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"termagg\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\"articleThemes\"\n,"+
					"\"size\":\""+size+"\"\n,"+
					sortQuery+
					"}\n"+
					//TwitterConstant.getAvg("articleSentiment")+
					avgAgg+
					"}\n"+
					"}\n"+
					"}\n";
			System.out.println("*****getThemes()***** "+query);

			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			TermsAggregation terms = result.getAggregations().getTermsAggregation("termagg");
			if(terms !=null) {
				List<Entry> entry = terms.getBuckets();
				for(Entry entry2 : entry) {
					if(twitterConstant.checkBlacklistKeyword(entry2.getKey())) {						
						TwitterVo twitterVo=new TwitterVo();
						twitterVo.setHashtag(entry2.getKey());
						twitterVo.setHashCount(Long.toString(entry2.getCount()));
						if(tweeterActionVo.getOnlyCount().isEmpty())
						{
							AvgAggregation avg=	entry2.getAvgAggregation("avg");
							twitterVo.setSentiment(Double.toString(avg.getAvg()));
						}
						lst.add(twitterVo);
					}				
				}
			}
		} catch(Exception ex) {
			ex.printStackTrace();
		}
		return lst; 
	}

	
	public ArrayList<TwitterVo> getWordCloudFromMsgData(TweeterActionVo tweeterActionVo) {
		ArrayList<TwitterVo> lst = new ArrayList<TwitterVo>();
		try	{

			int size = TwitterConstant.getSizeForEsTermAgg(tweeterActionVo, tweeterActionVo.getNoThemes());	
			String sortQuery = TwitterConstant.getSortForEsTermAgg(tweeterActionVo.getThemeSortOrder().toLowerCase().trim());
			String subQuery = rtnFilterQuery(tweeterActionVo, -1);
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"termagg\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\"articleTitle\"\n,"+
					"\"size\":\""+size+"\"\n,"+
					sortQuery+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";

			System.out.println("*****getWordCloudFromMsgData()***** "+query);			
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			TermsAggregation terms = result.getAggregations().getTermsAggregation("termagg");
			List<Entry> entry= terms.getBuckets();

			for(Entry entry2 : entry) {
				if(twitterConstant.checkBlacklistKeyword(entry2.getKey())) {
					TwitterVo twitterVo=new TwitterVo();
					twitterVo.setHashtag(entry2.getKey());
					twitterVo.setHashCount(Long.toString(entry2.getCount()));				
					lst.add(twitterVo);
				}				
			}
		} catch(Exception ex) {
			ex.printStackTrace();
		}
		return lst; 
	}


	
	public ArrayList<Object> fb_scrapy_basic_info(TweeterActionVo fbInputVo)
	{
		ArrayList<Object> lst = new ArrayList<Object>();
		List<Map<String, Object>> rows = null;
		try 
		{
			String query=" SELECT * FROM fb_scrap_profile_overview "
					   + " WHERE fb_user_id='"+fbInputVo.getUserFilter()+"' "
					   + " OR fb_user_id='"+fbInputVo.getUserName()+"' ";
			System.out.println(query);

			rows = jdbcTemplate.queryForList(query);
			for(Map<String, Object> rs :rows) 
			{
				Fb_OutputVo fbOutputVo=new Fb_OutputVo();
				fbOutputVo.setFb_user_id(rs.get("fb_user_id")==null?"":rs.get("fb_user_id").toString());
				fbOutputVo.setProfile_overview(rs.get("profile_overview")==null?"":rs.get("profile_overview").toString());
				lst.add(fbOutputVo);
			}
 
			query=" SELECT user_id, user_name, user_picture, user_cover_photo, "
				+ " user_picture_local, user_cover_local "
				+ " FROM fb_user "
				+ " WHERE user_id='"+fbInputVo.getUserFilter()+"' "
				+ " OR user_id='"+fbInputVo.getUserName()+"' ";
			System.out.println(query);

			rows = jdbcTemplate.queryForList(query);
			for(Map<String, Object> rs :rows) {
				Fb_OutputVo fbOutputVo=new Fb_OutputVo();
				fbOutputVo.setFb_user_id(rs.get("user_id")==null?"":rs.get("user_id").toString());
				fbOutputVo.setUser_name(rs.get("user_name")==null?"":rs.get("user_name").toString());
				fbOutputVo.setUser_picture(rs.get("user_picture")==null?"":rs.get("user_picture").toString());
				fbOutputVo.setUser_cover_photo(rs.get("user_cover_photo")==null?"":rs.get("user_cover_photo").toString());
				fbOutputVo.setImageName(rs.get("user_picture_local")==null?"":rs.get("user_picture_local").toString());
				fbOutputVo.setCoverImageName(rs.get("user_cover_local")==null?"":rs.get("user_cover_local").toString());	
				lst.add(fbOutputVo);
			}

			query=" SELECT education_work, edu_type "
				+ " FROM fb_scrap_profile_work_education "
				+ " WHERE fb_user_id='"+fbInputVo.getUserFilter()+"' "
				+ " OR fb_user_id='"+fbInputVo.getUserName()+"' ";
			System.out.println(query);
			rows = jdbcTemplate.queryForList(query);
			for(Map<String, Object> rs :rows) {
				Fb_OutputVo fbOutputVo=new Fb_OutputVo();
				fbOutputVo.setEducation_work(rs.get("education_work")==null?"":rs.get("education_work").toString());
				fbOutputVo.setEdu_type(rs.get("edu_type")==null?"":rs.get("edu_type").toString());
				lst.add(fbOutputVo);
			}

			query=" SELECT place_lived, palce_type "
				+ " FROM fb_scrap_profile_place_lived "
				+ " WHERE fb_user_id='"+fbInputVo.getUserFilter()+"' "
				+ " OR fb_user_id='"+fbInputVo.getUserName()+"' ";
			rows = jdbcTemplate.queryForList(query);
			System.out.println(query);
			for(Map<String, Object> rs :rows) {
				Fb_OutputVo fbOutputVo=new Fb_OutputVo();
				fbOutputVo.setPlace(rs.get("place_lived")==null?"":rs.get("place_lived").toString());
				fbOutputVo.setPalce_type(rs.get("palce_type")==null?"":rs.get("palce_type").toString());
				lst.add(fbOutputVo);
			}

			query=" SELECT basic_info, contact_type, head "
				+ " FROM fb_scrap_profile_contact_info "
				+ " WHERE fb_user_id='"+fbInputVo.getUserFilter()+"' "
				+ " OR fb_user_id='"+fbInputVo.getUserName()+"' ";
			rows = jdbcTemplate.queryForList(query);
			System.out.println(query);
			for(Map<String, Object> rs :rows) {
				Fb_OutputVo fbOutputVo = new Fb_OutputVo();
				fbOutputVo.setBasic_info(rs.get("basic_info")==null?"":rs.get("basic_info").toString());
				fbOutputVo.setContactType(rs.get("contact_type")==null?"":rs.get("contact_type").toString());
				fbOutputVo.setHead(rs.get("head")==null?"":rs.get("head").toString());
				lst.add(fbOutputVo);
			}

			query=" SELECT family_info, member_rel, member_img, localImagePath, family_member_id "
				+ " FROM fb_scrap_profile_family_info  "
				+ " WHERE fb_user_id='"+fbInputVo.getUserFilter()+"' "
				+ " OR fb_user_id='"+fbInputVo.getUserName()+"' ";
			rows = jdbcTemplate.queryForList(query);
			System.out.println(query);
			for(Map<String, Object> rs :rows) {
				Fb_OutputVo fbOutputVo=new Fb_OutputVo();
				fbOutputVo.setFamily_info(rs.get("family_info")==null?"":rs.get("family_info").toString());
				fbOutputVo.setMember_rel(rs.get("member_rel")==null?"":rs.get("member_rel").toString());
				fbOutputVo.setMember_img(rs.get("member_img")==null?"":rs.get("member_img").toString());
				fbOutputVo.setImageName(rs.get("localImagePath")==null?"":rs.get("localImagePath").toString());
				fbOutputVo.setFb_user_id(rs.get("family_member_id")==null?"":rs.get("family_member_id").toString());
				lst.add(fbOutputVo);
			}

			query=" SELECT * FROM fb_scrap_profile_event "
				+ " WHERE fb_user_id='"+fbInputVo.getUserFilter()+"' OR"
				+ " fb_user_id='"+fbInputVo.getUserName()+"'";
			System.out.println(query);
			rows = jdbcTemplate.queryForList(query);
			for(Map<String, Object> rs :rows) {
				Fb_OutputVo fbOutputVo=new Fb_OutputVo();
				fbOutputVo.setFb_user_id(rs.get("fb_user_id")==null?"":rs.get("fb_user_id").toString());
				fbOutputVo.setLife_events(rs.get("life_events")==null?"":rs.get("life_events").toString());
				fbOutputVo.setUser_event(rs.get("event_year")==null?"":rs.get("event_year").toString());
				lst.add(fbOutputVo);
			}

			query=" SELECT * FROM fb_scrap_profile_about "
				+ " WHERE fb_user_id='"+fbInputVo.getUserFilter()+"' OR"
				+ " fb_user_id='"+fbInputVo.getUserName()+"'";
			System.out.println(query);
			rows = jdbcTemplate.queryForList(query);
			for(Map<String, Object> rs :rows) {
				Fb_OutputVo fbOutputVo=new Fb_OutputVo();
				fbOutputVo.setFb_user_id(rs.get("fb_user_id")==null?"":rs.get("fb_user_id").toString());
				fbOutputVo.setUser_detail_about(rs.get("about")==null?"":rs.get("about").toString());
				lst.add(fbOutputVo);
			}
		} catch(Exception ex) {
			ex.printStackTrace();
		} 
		return lst;
	}


	
	public ArrayList<Fb_OutputVo> fb_scrapy_user_media(TweeterActionVo fbInputVo) 
	{
		ArrayList<Fb_OutputVo> list = new ArrayList<Fb_OutputVo>();
		List<Map<String, Object>> rows = null;

		try
		{
			if(fbInputVo.getMediaType().equals("photo"))
			{
				String query=" select user_photo_url, user_post_url, localImagePath "
						+ " from fb_scrap_user_photo "
						+ " where fb_user_id='"+fbInputVo.getUserFilter()+"' "
						+ " OR fb_user_id='"+fbInputVo.getUserName()+"' ";
				System.out.println(query);

				rows = jdbcTemplate.queryForList(query);
				for(Map<String,Object> rs :rows)
				{
					Fb_OutputVo fbOutputVo = new Fb_OutputVo();
					fbOutputVo.setUser_photo_url(rs.get("user_photo_url")==null?"":rs.get("user_photo_url").toString());
					fbOutputVo.setUser_post_url(rs.get("user_post_url")==null?"":rs.get("user_post_url").toString());
					fbOutputVo.setImageName(rs.get("localImagePath")==null?"":rs.get("localImagePath").toString());
					list.add(fbOutputVo);
				}
			}
			else
			{
				String query=" select video_thumnail, video_url, localImagePath from fb_scrap_user_video "
						   + " where fb_user_id='"+fbInputVo.getUserFilter()+"' "
						   + " OR fb_user_id='"+fbInputVo.getUserName()+"' ";
				System.out.println(query);

				rows = jdbcTemplate.queryForList(query);
				for(Map<String,Object> rs :rows)
				{  
					Fb_OutputVo fbOutputVo=new Fb_OutputVo();
					fbOutputVo.setVideo_thubmail(rs.get("video_thumnail")==null?"":rs.get("video_thumnail").toString());
					fbOutputVo.setUser_post_url(rs.get("video_url")==null?"":rs.get("video_url").toString());
					fbOutputVo.setImageName(rs.get("localImagePath")==null?"":rs.get("localImagePath").toString());
					list.add(fbOutputVo);
				} 
			}  
		}
		catch(Exception ex)
		{
			ex.printStackTrace(); 
		} 
		System.out.println("list: "+list);
		return list;
	}


	
	public ArrayList<Fb_groupVo> fb_scrapy_user_gp(TweeterActionVo fbInputVo) 
	{
		ArrayList<Fb_groupVo> lst=new ArrayList<Fb_groupVo>();
		List<Map<String,Object>> rows=null;
		try
		{
			String query=" select gp_name, gp_memebers, gp_photo, gp_Id, localImagePath "
					+ " from fb_scrap_group "
					+ " where user_id='"+fbInputVo.getUserFilter()+"' "
					+ " OR user_id='"+fbInputVo.getUserName()+"' ";
			System.out.println(query);

			rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				Fb_groupVo fbOutputVo=new Fb_groupVo();
				fbOutputVo.setGp_name(rs.get("gp_name")==null?"":rs.get("gp_name").toString());
				fbOutputVo.setGp_memebers(rs.get("gp_memebers")==null?"":rs.get("gp_memebers").toString());
				fbOutputVo.setGp_photo(rs.get("gp_photo")==null?"":rs.get("gp_photo").toString());
				fbOutputVo.setGp_Id(rs.get("gp_Id")==null?"":rs.get("gp_Id").toString());
				fbOutputVo.setLocalImgName(rs.get("localImagePath")==null?"":rs.get("localImagePath").toString());
				lst.add(fbOutputVo);
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		} 
		return lst;
	}


	
	public ArrayList<Fb_groupVo> fb_scrapy_user_check_ins(TweeterActionVo fbInputVo) 
	{
		ArrayList<Fb_groupVo> lst = new ArrayList<Fb_groupVo>();
		List<Map<String, Object>> rows=null;

		try
		{
			String query=" SELECT check_in_img, check_in_name, check_in_url, localImagePath "
					   + " FROM fb_scrap_user_check_in "
					   + " WHERE fb_user_id='"+fbInputVo.getUserFilter()+"' "
					   + " OR fb_user_id='"+fbInputVo.getUserName()+"' ";
			System.out.println("fb_scrapy_user_check_ins: "+query);

			rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				Fb_groupVo fbOutputVo=new Fb_groupVo();
				fbOutputVo.setGp_photo(rs.get("check_in_img")==null?"":rs.get("check_in_img").toString());
				fbOutputVo.setGp_name(rs.get("check_in_name")==null?"":rs.get("check_in_name").toString());
				fbOutputVo.setGp_url(rs.get("check_in_url")==null?"":rs.get("check_in_url").toString());
				fbOutputVo.setLocalImgName(rs.get("localImagePath")==null?"":rs.get("localImagePath").toString());
				lst.add(fbOutputVo);
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		} 
		return lst;
	}


	public ArrayList<Fb_groupVo> fb_scrapy_user_friends_old(TweeterActionVo fbInputVo) 
	{
		ArrayList<Fb_groupVo> lst=new ArrayList<Fb_groupVo>();
		List<Map<String,Object>> rows=null;
		try
		{
			String query =" select friendsAll_userName,friend_photo,friendsAll_userId "
					+ " from fb_scrap_user_friends  "
					+ " where fb_userId='"+fbInputVo.getUserFilter()+"' ";
			System.out.println(query);

			rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				Fb_groupVo fbOutputVo=new Fb_groupVo();
				fbOutputVo.setGp_name(rs.get("friendsAll_userName")==null?"":rs.get("friendsAll_userName").toString());
				fbOutputVo.setGp_photo(rs.get("friend_photo")==null?"":rs.get("friend_photo").toString());
				fbOutputVo.setGp_Id(rs.get("friendsAll_userId")==null?"":rs.get("friendsAll_userId").toString());
				lst.add(fbOutputVo);
			}
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		} 
		return lst;
	}


	
	public ArrayList<Fb_groupVo> fb_scrapy_user_likes(TweeterActionVo fbInputVo) 
	{
		ArrayList<Fb_groupVo> lst=new ArrayList<Fb_groupVo>();
		List<Map<String,Object>> rows=null;
		try
		{
			String query=" select liked_screenName, liked_user_profession, "
					   + " liked_user_img, liked_userId, localImagePath "
					   + " from fb_scrap_user_like_detail "
					   + " where fb_user_id='"+fbInputVo.getUserFilter()+"' "
					   + " OR fb_user_id='"+fbInputVo.getUserName()+"' ";
			System.out.println(query);

			rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				Fb_groupVo fbOutputVo=new Fb_groupVo();
				fbOutputVo.setGp_name(rs.get("liked_screenName")==null?"":rs.get("liked_screenName").toString());
				fbOutputVo.setGp_memebers(rs.get("liked_user_profession")==null?"":rs.get("liked_user_profession").toString());
				fbOutputVo.setGp_photo(rs.get("liked_user_img")==null?"":rs.get("liked_user_img").toString());
				fbOutputVo.setGp_Id(rs.get("liked_userId")==null?"":rs.get("liked_userId").toString());
				fbOutputVo.setLocalImgName(rs.get("localImagePath")==null?"":rs.get("localImagePath").toString());
				lst.add(fbOutputVo);
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		} 
		return lst;
	}
	
	
	
	public ArrayList<String> fbUserODS(TweeterActionVo fbInputVo)
	{
		ArrayList<String> list=new ArrayList<String>();
		List<Map<String,Object>> rows=null;
		try
		{
			String query=" SELECT * FROM test_ods WHERE profile_id='"+fbInputVo.getUserFilter()+"' ";
			System.out.println("fbUserODS: "+query);

			rows = jdbcTemplate.queryForList(query);
			for(Map<String, Object> rs :rows)
			{
				Fb_groupVo fbOutputVo=new Fb_groupVo();				
				fbOutputVo.setUser_id(rs.get("profile_id")==null?"":rs.get("profile_id").toString());
				fbOutputVo.setGp_name(rs.get("objects_name")==null?"":rs.get("objects_name").toString());
				fbOutputVo.setGp_photo(rs.get("image_urls")==null?"":rs.get("image_urls").toString());
				String[] str = fbOutputVo.getGp_photo().split(",");
				list.add(fbOutputVo.getGp_name());
				for(String s : str){
					list.add(s);
				}			
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		} 
		return list;
	}


	
	public ArrayList<Fb_groupVo> fbUserFRS(TweeterActionVo fbInputVo)
	{
		ArrayList<Fb_groupVo> list=new ArrayList<Fb_groupVo>();
		List<Map<String,Object>> rows=null;
		try
		{
			String query=" SELECT * FROM test_frs WHERE profile_id='"+fbInputVo.getUserFilter()+"' ";
			System.out.println("fbUserFRS: "+query);

			rows = jdbcTemplate.queryForList(query);
			for(Map<String, Object> rs :rows)
			{
				Fb_groupVo fbOutputVo=new Fb_groupVo();				
				fbOutputVo.setUser_id(rs.get("profile_id")==null?"":rs.get("profile_id").toString());
				fbOutputVo.setGp_name(rs.get("suspect_name")==null?"":rs.get("suspect_name").toString());
				fbOutputVo.setGp_photo(rs.get("suspect_image_url")==null?"":rs.get("suspect_image_url").toString());		
				list.add(fbOutputVo);
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		} 
		return list;
	}
	
	
		
	public ArrayList<TwitterVo> getLanguage(TweeterActionVo tweeterActionVo) {
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		try {
			int size=TwitterConstant.getSizeForEsTermAgg(tweeterActionVo, tweeterActionVo.getNoLanguage());
			String sortQuery=TwitterConstant.getSortForEsTermAgg(tweeterActionVo.getLangSortOrder().toLowerCase().trim());
			String subQuery=rtnFilterQuery(tweeterActionVo,-1);
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"termagg\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\"articleLanguage\"\n,"+
					"\"size\":\""+size+"\"\n,"+
					sortQuery+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";

			System.out.println("*****getLanguage()***** "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			TermsAggregation terms = result.getAggregations().getTermsAggregation("termagg");
			if(terms !=null) {
				List<Entry>  entry=  terms.getBuckets();
				for(Entry entry2 : entry) {
					TwitterVo twitterVo=new TwitterVo();
					twitterVo.setHashtag(entry2.getKey());
					twitterVo.setHashCount(Long.toString(entry2.getCount()));
					lst.add(twitterVo);
				}
			}
		} catch(Exception ex) {
			ex.printStackTrace(); 
		}
		return lst; 
	}

	
	public ArrayList<TwitterVo> getCountry(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		try 
		{
			int size=TwitterConstant.getSizeForEsTermAgg(tweeterActionVo, tweeterActionVo.getNoCountry());	
			String sortQuery=TwitterConstant.getSortForEsTermAgg(tweeterActionVo.getCountrySortOrder().toLowerCase().trim());
			String subQuery=rtnFilterQuery(tweeterActionVo,-1);
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"termagg\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\"articleLocationCountry\"\n,"+
					"\"size\":\""+size+"\"\n,"+
					sortQuery+
					"}\n"+
					TwitterConstant.getAvg("articleSentiment")+

					"}\n"+
					"}\n"+
					"}\n";

			System.out.println("*****getCountry()***** "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			TermsAggregation terms = result.getAggregations().getTermsAggregation("termagg");
			if(terms !=null) 
			{
				List<Entry>  entry=  terms.getBuckets();
				for (Entry entry2 : entry) 
				{
					TwitterVo twitterVo=new TwitterVo();
					twitterVo.setHashtag(entry2.getKey());
					twitterVo.setHashCount(Long.toString(entry2.getCount()));
					AvgAggregation avg=	entry2.getAvgAggregation("avg");
					twitterVo.setSentiment(Double.toString(avg.getAvg()));

					if(entry2.getKey() != null && !entry2.getKey().equalsIgnoreCase(""))
					lst.add(twitterVo);
				}
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return lst; 
	}

	
	public ArrayList<TwitterVo> getCity(TweeterActionVo tweeterActionVo)
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		try
		{
			int size=TwitterConstant.getSizeForEsTermAgg(tweeterActionVo, tweeterActionVo.getNoCity());	
			String sortQuery=TwitterConstant.getSortForEsTermAgg(tweeterActionVo.getCitySortOrder().toLowerCase().trim());
			String  subQuery=rtnFilterQuery(tweeterActionVo,-1);
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"termagg\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\"articleLocationCity\"\n,"+
					"\"size\":\""+size+"\"\n,"+
					sortQuery+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";

			System.out.println("*****getCity()***** "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			TermsAggregation terms = result.getAggregations().getTermsAggregation("termagg");
			if(terms !=null)
			{
				List<Entry>  entry=  terms.getBuckets();
				for (Entry entry2 : entry)
				{
					TwitterVo twitterVo=new TwitterVo();
					twitterVo.setHashtag(entry2.getKey());
					twitterVo.setHashCount(Long.toString(entry2.getCount()));
					lst.add(twitterVo);
				}
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return lst; 
	}


	
	public ArrayList<TwitterVo> getClassification(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		try
		{
			String subQuery=rtnFilterQuery(tweeterActionVo, -1);
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"termagg\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\"articleClassification\"\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";

			System.out.println("*****getClassification()***** "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			TermsAggregation terms = result.getAggregations().getTermsAggregation("termagg");
			List<Entry>  entry=  terms.getBuckets();
			for(Entry entry2 : entry) 
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setHashtag(entry2.getKey());
				twitterVo.setHashCount(Long.toString(entry2.getCount()));
				lst.add(twitterVo);
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return lst; 
	}

	
	public ArrayList<TwitterVo> getEmotions(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> lst = new ArrayList<TwitterVo>();
		try
		{
			String subQuery=rtnFilterQuery(tweeterActionVo,-1);
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"termagg\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\"articleEmotion\"\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";

			System.out.println("*****getEmotions()***** "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			TermsAggregation terms = result.getAggregations().getTermsAggregation("termagg");
			List<Entry> entry=  terms.getBuckets();
			for (Entry entry2 : entry) 
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setHashtag(entry2.getKey());
				twitterVo.setHashCount(Long.toString(entry2.getCount()));
				lst.add(twitterVo);
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return lst; 
	}


	
	public ArrayList<TwitterVo> getEmailId(TweeterActionVo tweeterActionVo)
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		try
		{
			int size=TwitterConstant.getSizeForEsTermAgg(tweeterActionVo, tweeterActionVo.getNoEmail());	
			String sortQuery=TwitterConstant.getSortForEsTermAgg(tweeterActionVo.getEmailSortOrder().toLowerCase().trim());
			String subQuery=rtnFilterQuery(tweeterActionVo,-1);
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"termagg\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\"articleEmail\"\n,"+
					"\"size\":\""+size+"\"\n,"+
					sortQuery+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";

			System.out.println("*****getEmailId()***** "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			TermsAggregation terms = result.getAggregations().getTermsAggregation("termagg");
			List<Entry>  entry=  terms.getBuckets();
			for (Entry entry2 : entry) 
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setHashtag(entry2.getKey());
				twitterVo.setHashCount(Long.toString(entry2.getCount()));
				lst.add(twitterVo);
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return lst; 
	}


	
	public ArrayList<TwitterVo> getPhoneNo(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		try
		{
			int size=TwitterConstant.getSizeForEsTermAgg(tweeterActionVo, tweeterActionVo.getNoMobile());	
			String sortQuery=TwitterConstant.getSortForEsTermAgg(tweeterActionVo.getMobileSortOrder().toLowerCase().trim());
			String subQuery=rtnFilterQuery(tweeterActionVo,-1);
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"termagg\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\"articleMobile\"\n,"+
					"\"size\":\""+size+"\"\n,"+
					sortQuery+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";

			System.out.println("*****getPhoneNo()***** "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			TermsAggregation terms = result.getAggregations().getTermsAggregation("termagg");
			List<Entry>  entry=  terms.getBuckets();
			for (Entry entry2 : entry) 
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setHashtag(entry2.getKey());
				twitterVo.setHashCount(Long.toString(entry2.getCount()));
				lst.add(twitterVo);
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return lst; 
	}


	
	public ArrayList<TwitterVo> getThemeWordCloud(TweeterActionVo tweeterActionVo) 
	{
		tweeterActionVo.setIsRpt("y");
		tweeterActionVo.setThemeSortOrder("cntdesc");
		if(tweeterActionVo.getZRptFlag().equals("no"))
		{
			tweeterActionVo.setNoThemes("200");
		}
		else
		{
			tweeterActionVo.setNoThemes("20");
		}
		ArrayList<TwitterVo> lst1 = new ArrayList<TwitterVo>();
		try
		{
			ArrayList<TwitterVo> lst = getThemes(tweeterActionVo);
			List<WordFrequency> wordFrequencies	= new ArrayList<WordFrequency>();
			for(TwitterVo  twitterVo:lst)
			{
				wordFrequencies.add(
						new WordFrequency(twitterVo.getHashtag(), Integer.parseInt(twitterVo.getHashCount()))
						);
			}
			TwitterVo twitterVo = new TwitterVo();
			twitterVo.setWordFrequencies(wordFrequencies);
			lst1.add(twitterVo);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		} 
		return lst1; 
	}

	public ArrayList<TwitterVo> getThemesWordCloudWithoutJunkKeyword(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> lst = new ArrayList<TwitterVo>();
		try
		{
			int size = TwitterConstant.getSizeForEsTermAgg(tweeterActionVo, tweeterActionVo.getNoThemes());	
			String sortQuery = TwitterConstant.getSortForEsTermAgg(tweeterActionVo.getThemeSortOrder().toLowerCase().trim());
			String subQuery = rtnFilterQuery(tweeterActionVo, 91);

			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"termagg\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\"articleThemes\"\n,"+
					"\"size\":\""+size+"\"\n,"+
					sortQuery+
					"}\n"+
					TwitterConstant.getAvg("articleSentiment")+
					"}\n"+
					"}\n"+
					"}\n";
			System.out.println("*****getThemesWordCloudWithoutJunkKeyword()***** "+query);

			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			TermsAggregation terms = result.getAggregations().getTermsAggregation("termagg");
			List<Entry>  entry=  terms.getBuckets();
			for(Entry entry2 : entry) 
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setHashtag(entry2.getKey());
				twitterVo.setHashCount(Long.toString(entry2.getCount()));
				AvgAggregation avg=	entry2.getAvgAggregation("avg");
				twitterVo.setSentiment(Double.toString(avg.getAvg()));
				lst.add(twitterVo);
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return lst; 
	}


	
	public ArrayList<TwitterVo> getAllAttriubuteCount(TweeterActionVo tweeterActionVo)
	{
		ArrayList<TwitterVo> list = new ArrayList<TwitterVo>();
		try
		{
			String subQuery = rtnFilterQuery(tweeterActionVo, -1);
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"distinctVal\":{\n"+
					"\"cardinality\":{\n"+
					"\"field\":\""+tweeterActionVo.getAttrName()+"\"\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";
			
			System.out.println("*****getAllAttriubuteCount()***** "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			CardinalityAggregation terms = result.getAggregations().getCardinalityAggregation("distinctVal");
			Long value = terms.getCardinality();

			TwitterVo vo = new TwitterVo();
			vo.setHashCount(String.valueOf(value));
			vo.setDescription(tweeterActionVo.getAttrName());

			if(tweeterActionVo.getAttrName().equalsIgnoreCase("articleMedia.mediaUrl"))
			{
				vo.setDescription(tweeterActionVo.getMediaType());
				if(tweeterActionVo.getMediaType().equals("image"))
				{
					vo.setDescription("photo");
				}
			}
			list.add(vo);
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return list; 
	}


	
	public ArrayList<TwitterVo> getAllAttriubuteCountNER(TweeterActionVo tweeterActionVo)
	{
		ArrayList<TwitterVo> reportList=new ArrayList <TwitterVo>();
		try 
		{
			String path="articleLocationNer";
			switch(tweeterActionVo.getAttrName().toLowerCase().trim())
			{
			case "person":
				path="articlePersonNer";
				break;
			case "location":
				path="articleLocationNer";
				break;
			case "organization":
				path="articleOrganizationNer";
				break;
			case "date":
				path="articleDateNer";
				break;
			}
			String  subQuery=rtnFilterQuery(tweeterActionVo,-1);
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\": {\n"+
					"\"termagg\": {\n"+ 
					"\"nested\": {\n"+
					"\"path\": \""+path+"\"\n"+
					"},\n"+
					"\"aggs\" : {\n"+
					"\"genres\" : {\n"+
					"\"cardinality\" : {\"field\" : \""+path+".keyword\" \n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";

			System.out.println("*****getAllAttriubuteCountNER()**"+path+"*** "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			JsonElement jsonElement=result.getJsonObject().get("aggregations");
			String val=Integer.toString(jsonElement.getAsJsonObject().get("termagg").getAsJsonObject().get("genres").getAsJsonObject().get("value").getAsInt());

			TwitterVo vo = new TwitterVo();
			vo.setHashCount(String.valueOf(val));
			vo.setDescription(tweeterActionVo.getAttrName());			
			reportList.add(vo);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return reportList;
	}


	
	public ArrayList<LinkedTreeMap> getAllInfluencerUser360(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<LinkedTreeMap> d =null;
		try
		{
			String subAggs=",\n"+
					"\"aggs\": {\n"+

					"\"max_follower_count\": {\n"+
					"\"max\":{\n"+
					"\"field\":\"tweet.tweetUser.tweetUserFollowersCount\"\n"+
					"}\n"+
					"},"+

					"\"myaggs\": {\n"+
					"\"top_hits\": {\n"+
					"\"_source\": {\n"+
					"\"include\": [\n"+
					"\"articleAuthorId\",\"articleAuthorImage\",\"articleAuthorImageUrlLocal\" \n"+
					"]"+
					"},"+
					"\"size\": 1\n"+
					"}"+
					"},"+

					"\"themeaggs\": {\n"+
					"\"terms\":{\n"+
					"\"field\":\"articleHashTag\",\n"+
					"\"size\": \"5\"\n"+
					"}\n"+
					"},"+

					"\"classiaggs\": {\n"+
					"\"terms\":{\n"+
					"\"field\":\"articleClassification\"\n"+
					"}\n"+
					"},"+

					"\"sentiaggs\": {\n"+
					"\"terms\":{\n"+
					"\"field\":\"articleSentiment\"\n"+
					"}\n"+
					"}"+
					"}";

			String fieldName="articleAuthor";
			String  subQuery=rtnFilterQuery(tweeterActionVo,-1);
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+

					",\"aggs\":\n"+
					"{\n"+
					"\"termaggs\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\""+fieldName+"\",\n"+
					"\"size\": \"5\"\n"+
					//",\"order\": {\"max_follower_count\": \"desc\"}"+

					"}\n"+subAggs+
					"}\n"+
					"}\n"+
					"}\n";

			System.out.println(" getAllInfluencerUser360 ==== "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			Gson gson = new Gson();
			//System.out.println(result.getJsonObject().toString());
			LinkedTreeMap a = gson.fromJson(result.getJsonObject().toString(), LinkedTreeMap.class);
			LinkedTreeMap b = (LinkedTreeMap)a.get("aggregations");
			LinkedTreeMap c = (LinkedTreeMap)b.get("termaggs");
			d = (ArrayList<LinkedTreeMap>)c.get("buckets");	
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return d;
	}


	public ArrayList<LinkedTreeMap> getAllInfluencerUser360_withSource(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<LinkedTreeMap> d =null;
		try
		{
			String subAggs=",\n"+
					"\"aggs\": {\n"+

					"\"myaggs\": {\n"+
					"\"top_hits\": {\n"+
					"\"_source\": {\n"+
					"\"include\": [\n"+
					"\"articleAuthorId\",\"articleAuthorImage\"\n"+
					"]"+
					"},"+
					"\"size\": 1\n"+
					"}"+
					"},"+

					"\"themeaggs\": {\n"+
					"\"terms\":{\n"+
					"\"field\":\"articleThemes\",\n"+
					"\"size\": \"10\"\n"+
					"}\n"+
					"},"+

					"\"classiaggs\": {\n"+
					"\"terms\":{\n"+
					"\"field\":\"articleClassification\"\n"+
					"}\n"+
					"}"+

					"}";

			String fieldName="articleAuthor";
			String  subQuery=rtnFilterQuery(tweeterActionVo,-1);
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\": {\n"+
					"\"sourceType\": {\n"+
					"\"terms\": {\n"+
					"\"field\": \"articleSource\"\n"+
					"}\n"+
					",\"aggs\":\n"+
					"{\n"+
					"\"termaggs\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\""+fieldName+"\",\n"+
					"\"size\": \"5\"\n"+
					"}\n"+subAggs+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";

			System.out.println(" getAllInfluencerUser360 ==== "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			Gson gson = new Gson();
			//System.out.println(result.getJsonObject().toString());
			LinkedTreeMap a = gson.fromJson(result.getJsonObject().toString(), LinkedTreeMap.class);
			LinkedTreeMap b = (LinkedTreeMap)a.get("aggregations");
			LinkedTreeMap c = (LinkedTreeMap)b.get("sourceType");
			d = (ArrayList<LinkedTreeMap>)c.get("buckets");	
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return d;
	}


	
	public ArrayList<KeyMapVo> getAllTredingDateWithTheme360(TweeterActionVo tweeterActionVo)
	{
		ArrayList<KeyMapVo> list=new ArrayList <KeyMapVo>();
		try
		{
			String path="articleLocationNer";
			switch(tweeterActionVo.getType().toLowerCase().trim()) 
			{
			case "person":
				path="articlePersonNer";
				break;
			case "location":
				path="articleLocationNer";
				break;
			case "organization":
				path="articleOrganizationNer";
				break;
			case "date":
				path="articleDateNer";
				break;
			}
			
			int size=100;	
			//String sortQuery=TwitterConstant.getSortForEsTermAggNested(tweeterActionVo.getNerSortOrder().toLowerCase().trim(),"_count");
			String subQuery=rtnFilterQuery(tweeterActionVo,-1);
			String subAggs=",\n"+
					"\"aggs\": {\n"+
					"\"themeaggs\": {\n"+
					"\"terms\":{\n"+
					"\"field\":\"articleDateNer.nerDateTheme1\",\n"+
					"\"size\": \"5\"\n"+
					"}\n"+
					"}"+
					"}";

			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\": {\n"+
					"\"termagg\": {\n"+ 
					"\"nested\": {\n"+
					"\"path\": \""+path+"\"\n"+
					"},\n"+
					"\"aggs\" : {\n"+
					"\"genres\" : {\n"+
					"\"terms\" : {\"field\" : \""+path+".keyword\" ,\n"+
					"\"size\":\""+size+"\"\n"+
					//sortQuery+
					"}\n"+subAggs+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";

			System.out.println("*****getAllTredingDateWithTheme360()**"+path+"*** "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			JsonElement jsonElement=result.getJsonObject().get("aggregations");

			Gson gson = new Gson();
			LinkedTreeMap a = gson.fromJson(jsonElement.toString(), LinkedTreeMap.class);
			LinkedTreeMap b = (LinkedTreeMap)a.get("termagg");
			LinkedTreeMap c = (LinkedTreeMap)b.get("genres");
			ArrayList<LinkedTreeMap> d = (ArrayList<LinkedTreeMap>)c.get("buckets");

			for(LinkedTreeMap o : d) 
			{
				KeyMapVo vo = new KeyMapVo();

				if(o.get("key_as_string") instanceof String) 
				{
					SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
					//SimpleDateFormat outputFormat = new SimpleDateFormat("dd-MM-yyyy");
					SimpleDateFormat outputFormat = new SimpleDateFormat("yyyy-MM-dd");
					Date date = inputFormat.parse((String)o.get("key_as_string"));
					String formattedDate = outputFormat.format(date);
					vo.setKey(formattedDate);
				}
				
				vo.setCount(o.get("doc_count").toString());

				//LinkedTreeMap e = (LinkedTreeMap)o.get("themeaggs1");
				LinkedTreeMap f = (LinkedTreeMap)o.get("themeaggs");
				ArrayList<LinkedTreeMap> g = (ArrayList<LinkedTreeMap>)f.get("buckets");	

				HashMap<String, String> map = new HashMap<String,String>();

				for(LinkedTreeMap h : g) 
				{
					String key = (String)h.get("key");
					String doc_count = h.get("doc_count").toString();
					map.put(key, doc_count);
				}
                
                if(!map.isEmpty())
                {
                	vo.setMap(map);
    				list.add(vo);
                }
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		System.out.println("list:--->> "+list);
		return list;
	}

	
	public ArrayList<TwitterVo> getAllTwitterUserCreatiedBetweenDates(TweeterActionVo tweeterActionVo)
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		try 
		{
			tweeterActionVo.setSourceFilter("tw");
			tweeterActionVo.setDateFrom("");
			tweeterActionVo.setDateFromGrph("");
			tweeterActionVo.setDateTo("");
			tweeterActionVo.setDateToGrph("");
			String subQuery=rtnFilterQuery(tweeterActionVo, -1);
			
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"distinctAuthor\":{\n"+
					"\"cardinality\":{\n"+
					"\"field\":\"articleAuthor\"\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";
			
			System.out.println("unique tw user query: "+query);

			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			//System.out.println(result.getJsonString());
			CardinalityAggregation cardiAgg = result.getAggregations().getCardinalityAggregation("distinctAuthor");
		    long l=cardiAgg.getCardinality();
			System.out.println("unique user: "+l);
			
		    query="{\n"+
				"\"size\": 0,\n" +
				subQuery+
				",\"aggs\":\n"+
				"{\n"+
				"\"dateHistogram\":{\n"+
				"\"date_histogram\":{\n"+
				"\"field\":\"tweet.tweetUser.tweetUserCreatedTime\",\n"+
				"\"interval\": \"day\",\n"+
				"\"min_doc_count\": 1,\n"+
				"\"extended_bounds\" : {\n"+ 
				"\"min\" : \""+TwitterConstant.convertStrToDate_yyyy_MM_dd(tweeterActionVo.getUserCreatedDateFrom())+"\",\n"+
				"\"max\" : \""+TwitterConstant.convertStrToDate_yyyy_MM_dd(tweeterActionVo.getUserCreatedDateTo())+"\"\n"+
				"}\n"+
				"}\n"+
				"}\n"+
				"}\n"+
				"}\n";

			System.out.println("getAllTwitterUserCreatiedBetweenDates: "+query);
		    search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			result = client.execute(search);
			DateHistogramAggregation terms = result.getAggregations().getDateHistogramAggregation("dateHistogram");
			List<DateHistogram> entry = terms.getBuckets();
			for(DateHistogram dateHistogram : entry) 
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setCreatedAt(CommonUtils.convertUnixTimeToDate_yyyy_mm_dd((dateHistogram.getKey())));
				twitterVo.setCount(Long.toString(dateHistogram.getCount()));
				twitterVo.setUserCount(Long.toString(l));
				lst.add(twitterVo);
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return lst;
	}
	
	
	public ArrayList<TwitterVo> getLatestPostByParameter(TweeterActionVo tweeterActionVo) 
	{
		return null;
	}

	
	public ArrayList<TwitterVo> topDashActiveEntity(TweeterActionVo tweeterActionVo)
	{
		ArrayList<TwitterVo> list = new ArrayList<TwitterVo>();
		try 
		{
			String fieldName="";
			switch(tweeterActionVo.getType()) {
			case "hashtag":
				fieldName="articleHashTag";
				break;
			case "user":
				fieldName="articleAuthor";
				break;
			case "mention":
				fieldName="articleMention";
				break;
			case "theme":
				fieldName="articleThemes";
				break;
			case "classification":
				fieldName="articleClassification";
				break;
			case "articletype":
				fieldName="articleType";
				break;
			case "place":
				fieldName="articleLocationNer.keyword";
				break;
			case "person":
				fieldName="articlePersonNer.keyword";
				break;
			case "org":
				fieldName="articleOrganizationNer.keyword";
				break;
			case "mobile":
				fieldName="articleMobile";
				break;
			case "email":
				fieldName="articleEmail";
				break;
			default:
				break;
			}
			
			String subQuery = rtnFilterQuery(tweeterActionVo, -1);
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"termagg\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\""+fieldName+"\"\n,"+
					"\"size\":\"10\"\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";

			System.out.println(tweeterActionVo.getType()+" dashActiveEntity()==== : "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			TermsAggregation terms = result.getAggregations().getTermsAggregation("termagg");
			if(terms != null) {
				List<Entry> entry = terms.getBuckets();
				for(Entry entry2 : entry) {
					//System.out.println("entry2.getKey() : "+entry2.getKey());
					if(twitterConstant.checkBlacklistKeyword(entry2.getKey())) {
						TwitterVo twitterVo=new TwitterVo();
						twitterVo.setHashtag(entry2.getKey());
						twitterVo.setHashCount(Long.toString(entry2.getCount()));
						list.add(twitterVo);
					}
				}
			}			
		} catch(Exception ex) {
			ex.printStackTrace();
		}
		return list;
	}
	
	
	public ArrayList<TwitterVo> docCountWithSentiment(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		Gson gson = new Gson();
		try
		{
			String  subQuery=rtnFilterQuery(tweeterActionVo,-1);
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"dateHistogram\":{\n"+
					"\"date_histogram\":{\n"+
					"\"field\":\"articlePublishDate\",\n"+
					"\"interval\": \"day\",\n"+
					"\"min_doc_count\": 0,\n"+
					"\"extended_bounds\" : {\n"+ 
					"\"min\" : \""+TwitterConstant.convertStrToDate_yyyy_MM_dd(tweeterActionVo.getDateFrom())+"\",\n"+
					"\"max\" : \""+TwitterConstant.convertStrToDate_yyyy_MM_dd(tweeterActionVo.getDateTo())+"\"\n"+
					"}\n"+
					"},\n"+
					"\"aggs\": {\n"+
					"\"sentiment\": {\n"+
					"\"terms\":{\n"+
					"\"field\":\"articleSentiment\"\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";

			System.out.println("docCountWithSentiment()==== "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);

			LinkedTreeMap ltm1 = (LinkedTreeMap)gson.fromJson(result.getJsonString(), Object.class);
			LinkedTreeMap ltm2 = (LinkedTreeMap)ltm1.get("aggregations");
			LinkedTreeMap ltm3 = (LinkedTreeMap)ltm2.get("dateHistogram");
			ArrayList<LinkedTreeMap> list1 = (ArrayList)ltm3.get("buckets");

			for(LinkedTreeMap ltm4:list1)
			{
				TwitterVo twitterVo=new TwitterVo();

				Double dateKey = (Double)ltm4.get("key");
				twitterVo.setCreatedAt(CommonUtils.convertUnixTimeToDate_yyyy_mm_dd((dateKey.longValue())));
				twitterVo.setTotalTweetCount(String.valueOf(ltm4.get("doc_count")));
				String temp="";

				LinkedTreeMap ltm5 = (LinkedTreeMap)ltm4.get("sentiment");
				ArrayList<LinkedTreeMap> list3 = (ArrayList<LinkedTreeMap>)ltm5.get("buckets");
				for(LinkedTreeMap ltm6:list3)
				{
					int sentiment = ((Double)ltm6.get("key")).intValue();
					int sentimentCount = ((Double)ltm6.get("doc_count")).intValue();

					switch(sentiment)
					{
					case 1:
						temp+="Positive#"+sentimentCount+"_";
						break;

					case 0:
						temp+="Neutral#"+sentimentCount+"_";
						break;

					case -1:
						temp+="Negative#"+sentimentCount+"_";
						break;
					}
				}

				if(temp.length()>0)
					temp = temp.substring(0,temp.length()-1);

				twitterVo.setSentiment(temp);
				lst.add(twitterVo);
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return lst; 
	}


	public ArrayList<LinkedTreeMap> getFieldTypeData(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<LinkedTreeMap> d = null;		
		Gson gson = new Gson();

		try 
		{
			String subQuery = rtnFilterQuery(tweeterActionVo, -1);
			String fieldName = tweeterActionVo.getType();
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"termagg\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\""+fieldName+"\"\n,"+
					"\"size\":\"50\"\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";

			//String query = "{\"size\":0,\"aggs\":{\"termaggs\":{\"terms\":{\"field\":\"articleAuthorGender\"}}}}";
			System.out.println("getFieldTypeData()==== "+fieldName+" :  "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			LinkedTreeMap a = gson.fromJson(result.getJsonObject().toString(), LinkedTreeMap.class);
			LinkedTreeMap b = (LinkedTreeMap)a.get("aggregations");
			LinkedTreeMap c = (LinkedTreeMap)b.get("termagg");
			d = (ArrayList<LinkedTreeMap>)c.get("buckets");
		} 
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return d; 		
	}

	
	public ArrayList<TwitterVo> getUserNodeDetail(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		try
		{
			String query="SELECT * FROM twitter_followers "
					+ " WHERE followed_screen_name ='"+tweeterActionVo.getUserFilter()+"' "
					+ " OR follower_screen_name='"+tweeterActionVo.getUserFilter()+"' LIMIT 1";
			//SELECT * FROM twitter_followers WHERE followed_screen_name='umashankarsingh' OR follower_screen_name='umashankarsingh' LIMIT 1

			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs : rows)
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setFollowed(rs.get("followed")==null?"":rs.get("followed").toString());
				twitterVo.setFollowed_name(rs.get("followed_name")==null?"":rs.get("followed_name").toString());
				twitterVo.setFollowed_screen_name(rs.get("followed_screen_name")==null?"":rs.get("followed_screen_name").toString());
				twitterVo.setFollowed_img(rs.get("followed_img")==null?"":rs.get("followed_img").toString());
				lst.add(twitterVo);
			}
		}
		catch (Exception e) 
		{
			log.error("--------- Exception--------", e);
			e.printStackTrace();
		} 
		return lst; 
	}


	
	public ArrayList<TwitterVo> getAllDataForLinkAnalysis(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> list = new ArrayList<TwitterVo>();
		try
		{
			String fieldName="";
			String iconImage="";
			String iconImagePath=TwitterConstant.getLinkAnalysisImageUrl();
			switch(tweeterActionVo.getType()) 
			{
			case "hashtag":
				fieldName="articleHashTag";
				iconImage="hashtagIcon.png";
				iconImagePath=iconImagePath+iconImage;
				break;
			case "user":
				fieldName="articleAuthor";
				break;
			case "mention":
				fieldName="articleMention";
				iconImage="mentionIcon.png";
				iconImagePath=iconImagePath+iconImage;
				break;
			case "theme":
				fieldName="articleThemes";
				break;
			case "classification":
				fieldName="articleClassification";
				break;
			case "articletype":
				fieldName="articleType";
				break;
			case "place":
				fieldName="articleLocationNer.keyword";
				iconImage="placeIcon.png";
				iconImagePath=iconImagePath+iconImage;
				break;
			case "person":
				fieldName="articlePersonNer.keyword";
				iconImage="personIcon.png";
				iconImagePath=iconImagePath+iconImage;
				break;
			case "org":
				fieldName="articleOrganizationNer.keyword";
				iconImage="orgIcon.png";
				iconImagePath=iconImagePath+iconImage;
				break;
			case "mobile":
				fieldName="articleMobile";
				iconImage="mobileIcon.png";
				iconImagePath=iconImagePath+iconImage;
				break;
			case "email":
				fieldName="articleEmail";
				iconImage="messageIcon.png";
				iconImagePath=iconImagePath+iconImage;
				break;
			case "language":
				fieldName="articleLanguage";
				iconImage="languageIcon.png";
				iconImagePath=iconImagePath+iconImage;
				break;
			default:
				break;
			}

			ArrayList<MultipleEntryVo> multipleEntityList = tweeterActionVo.getMultipleEntityId();
			for(MultipleEntryVo multipleEntryVo : multipleEntityList)
			{
				LinkedHashMap<String, String> map = new LinkedHashMap<>();
				map.put("key", multipleEntryVo.getType2().get(0));
				map.put("val", "tw");
				ArrayList<LinkedHashMap<String, String>> lstProfileGlobalFilter = new ArrayList<>(); 
				lstProfileGlobalFilter.add(map);				
				//tweeterActionVo.setProfileGlobalFilter(lstProfileGlobalFilter);
				tweeterActionVo.setProfileGlobalFilterLinkAnalysis(lstProfileGlobalFilter);				 
				String subQuery=rtnFilterQuery(tweeterActionVo, -1);
								
				String query="{\n"+
						"\"size\": 0,\n" +
						subQuery+
						",\"aggs\":\n"+
						"{\n"+
						"\"termagg\":{\n"+
						"\"terms\":{\n"+
						"\"field\":\""+fieldName+"\"\n,"+
						"\"size\":\"100\"\n"+
						"}\n"+
						"}\n"+
						"}\n"+
						"}\n";

				System.out.println(tweeterActionVo.getType()+" getAllDataForLinkAnalysis()==== "+query);
				Search search = new Search.Builder(query)
						.addIndex(TwitterConstant.getDbname())
						.addType(TwitterConstant.getTypeName())
						.build();

				SearchResult result = client.execute(search);
				TermsAggregation terms = result.getAggregations().getTermsAggregation("termagg");
				List<Entry> entry = terms.getBuckets();
				for(Entry entry2 : entry) 
				{
					TwitterVo twitterVo = new TwitterVo();
					LinkAnalysisDataVo dataVo = new LinkAnalysisDataVo();
					
					twitterVo.setNodeName2(entry2.getKey());
					twitterVo.setNodeId2(entry2.getKey());
					twitterVo.setNodeScreenName2(entry2.getKey());
					twitterVo.setDocumentCount(Long.toString(entry2.getCount()));
					twitterVo.setNodeImg2(iconImagePath);
					
					/*
					twitterVo.setNodeName1(entry2.getKey());
					twitterVo.setNodeId1(entry2.getKey());
					twitterVo.setNodeScreenName1(entry2.getKey());
					twitterVo.setNodeImg1(iconImagePath);
					//twitterVo.setNodeImg1(entry2.getKey());
					*/
									
										
					twitterVo.setType(tweeterActionVo.getType());					
					twitterVo.setNodeName1(multipleEntryVo.getType1());
					twitterVo.setNodeId1(multipleEntryVo.getType1());
					twitterVo.setNodeScreenName1(multipleEntryVo.getType1());
					twitterVo.setNodeImg1(multipleEntryVo.getType3());  //For Image	
					
					/*=======>> 
					twitterVo.setNodeName2(multipleEntryVo.getType1());
					twitterVo.setNodeId2(multipleEntryVo.getType1());
					twitterVo.setNodeScreenName2(multipleEntryVo.getType1());
					twitterVo.setNodeImg2(multipleEntryVo.getType3());  //For Image	
					//twitterVo.setNodeImg2(multipleEntryVo.getType1());
					*/
					/*twitterVo.setNodeName2(multipleEntryVo.getType2().get(0));
					twitterVo.setNodeId2(multipleEntryVo.getType2().get(0));
					twitterVo.setNodeScreenName2(multipleEntryVo.getType2().get(0));
					twitterVo.setNodeImg2(multipleEntryVo.getType2().get(0));*/
					
					list.add(twitterVo);
					
					//System.out.println("NodeName1:============== "+twitterVo.getNodeName1());
					//System.out.println("NodeScreenName1:======== "+twitterVo.getNodeScreenName1());
					//System.out.println("NodeName2:============== "+twitterVo.getNodeName2());
					//System.out.println("NodeScreenName2:======== "+twitterVo.getNodeScreenName2());
					//System.out.println("-------------------------------------------------------");
				}
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		} 
		return list;
	}

	
	
	
	
	public ArrayList<TwitterVo> getAllDataForLinkAnalysis123456789(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> list = new ArrayList<TwitterVo>();
		try
		{
			String fieldName="";
			String iconImage="";
			String iconImagePath=TwitterConstant.getLinkAnalysisImageUrl();
			switch(tweeterActionVo.getType()) 
			{
			case "hashtag":
				fieldName="articleHashTag";
				iconImage="hashtagIcon.png";
				iconImagePath=iconImagePath+iconImage;
				break;
			case "user":
				fieldName="articleAuthor";
				break;
			case "mention":
				fieldName="articleMention";
				iconImage="mentionIcon.png";
				iconImagePath=iconImagePath+iconImage;
				break;
			case "theme":
				fieldName="articleThemes";
				break;
			case "classification":
				fieldName="articleClassification";
				break;
			case "articletype":
				fieldName="articleType";
				break;
			case "place":
				fieldName="articleLocationNer.keyword";
				iconImage="placeIcon.png";
				iconImagePath=iconImagePath+iconImage;
				break;
			case "person":
				fieldName="articlePersonNer.keyword";
				iconImage="personIcon.png";
				iconImagePath=iconImagePath+iconImage;
				break;
			case "org":
				fieldName="articleOrganizationNer.keyword";
				iconImage="orgIcon.png";
				iconImagePath=iconImagePath+iconImage;
				break;
			case "mobile":
				fieldName="articleMobile";
				iconImage="mobileIcon.png";
				iconImagePath=iconImagePath+iconImage;
				break;
			case "email":
				fieldName="articleEmail";
				iconImage="messageIcon.png";
				iconImagePath=iconImagePath+iconImage;
				break;
			case "language":
				fieldName="articleLanguage";
				iconImage="languageIcon.png";
				iconImagePath=iconImagePath+iconImage;
				break;
			default:
				break;
			}

			ArrayList<MultipleEntryVo> multipleEntityList = tweeterActionVo.getMultipleEntityId();
			for(MultipleEntryVo multipleEntryVo : multipleEntityList)
			{
				LinkedHashMap<String, String> map = new LinkedHashMap<>();
				map.put("key", multipleEntryVo.getType2().get(0));
				map.put("val", "tw");
				ArrayList<LinkedHashMap<String, String>> lstProfileGlobalFilter = new ArrayList<>(); 
				lstProfileGlobalFilter.add(map);				
				//tweeterActionVo.setProfileGlobalFilter(lstProfileGlobalFilter);
				tweeterActionVo.setProfileGlobalFilterLinkAnalysis(lstProfileGlobalFilter);				 
				String subQuery=rtnFilterQuery(tweeterActionVo,-1);
								
				String query="{\n"+
						"\"size\": 0,\n" +
						subQuery+
						",\"aggs\":\n"+
						"{\n"+
						"\"termagg\":{\n"+
						"\"terms\":{\n"+
						"\"field\":\""+fieldName+"\"\n,"+
						"\"size\":\"100\"\n"+
						"}\n"+
						"}\n"+
						"}\n"+
						"}\n";

				System.out.println(tweeterActionVo.getType()+" getAllDataForLinkAnalysis()==== "+query);
				Search search = new Search.Builder(query)
						.addIndex(TwitterConstant.getDbname())
						.addType(TwitterConstant.getTypeName())
						.build();

				SearchResult result = client.execute(search);
				TermsAggregation terms = result.getAggregations().getTermsAggregation("termagg");
				List<Entry> entry = terms.getBuckets();
				for(Entry entry2 : entry) 
				{
					TwitterVo twitterVo = new TwitterVo();
					twitterVo.setNodeName2(entry2.getKey());
					twitterVo.setNodeId2(entry2.getKey());
					twitterVo.setNodeScreenName2(entry2.getKey());
					twitterVo.setDocumentCount(Long.toString(entry2.getCount()));
					twitterVo.setNodeImg2(iconImagePath);
					
					/*
					twitterVo.setNodeName1(entry2.getKey());
					twitterVo.setNodeId1(entry2.getKey());
					twitterVo.setNodeScreenName1(entry2.getKey());
					twitterVo.setNodeImg1(iconImagePath);
					//twitterVo.setNodeImg1(entry2.getKey());
					*/
									
										
					twitterVo.setType(tweeterActionVo.getType());
					
					twitterVo.setNodeName1(multipleEntryVo.getType1());
					twitterVo.setNodeId1(multipleEntryVo.getType1());
					twitterVo.setNodeScreenName1(multipleEntryVo.getType1());
					twitterVo.setNodeImg1(multipleEntryVo.getType3());  //For Image	
					
					/*=======>> 
					twitterVo.setNodeName2(multipleEntryVo.getType1());
					twitterVo.setNodeId2(multipleEntryVo.getType1());
					twitterVo.setNodeScreenName2(multipleEntryVo.getType1());
					twitterVo.setNodeImg2(multipleEntryVo.getType3());  //For Image	
					//twitterVo.setNodeImg2(multipleEntryVo.getType1());
					*/
					
					
				
					
					/*twitterVo.setNodeName2(multipleEntryVo.getType2().get(0));
					twitterVo.setNodeId2(multipleEntryVo.getType2().get(0));
					twitterVo.setNodeScreenName2(multipleEntryVo.getType2().get(0));
					twitterVo.setNodeImg2(multipleEntryVo.getType2().get(0));*/
					
					list.add(twitterVo);
					
					//System.out.println("NodeName1:============== "+twitterVo.getNodeName1());
					//System.out.println("NodeScreenName1:======== "+twitterVo.getNodeScreenName1());
					//System.out.println("NodeName2:============== "+twitterVo.getNodeName2());
					//System.out.println("NodeScreenName2:======== "+twitterVo.getNodeScreenName2());
					//System.out.println("-------------------------------------------------------");
				}
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		} 
		return list;
	}
	
	

	
	public ArrayList<TwitterVo> getEvent(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		try
		{
			int size = TwitterConstant.getSizeForEsTermAgg(tweeterActionVo, tweeterActionVo.getNoEvent());	
			String sortQuery = TwitterConstant.getSortForEsTermAgg(tweeterActionVo.getEventSortOrder().toLowerCase().trim());
			String subQuery = rtnFilterQuery(tweeterActionVo, -1);
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"termagg\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\"articleEvent.keyword\"\n,"+
					"\"size\":\""+size+"\"\n,"+
					sortQuery+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";

			System.out.println("*****getEvent()***** "+query);

			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			TermsAggregation terms = result.getAggregations().getTermsAggregation("termagg");
			List<Entry>  entry=  terms.getBuckets();
			for (Entry entry2 : entry) 
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setHashtag(entry2.getKey());
				twitterVo.setHashCount(Long.toString(entry2.getCount()));
				lst.add(twitterVo);
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return lst; 
	}


	
	public ArrayList<TwitterVo> getTaxonomy(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> lst=new ArrayList<TwitterVo>();
		try
		{
			int size = TwitterConstant.getSizeForEsTermAgg(tweeterActionVo, tweeterActionVo.getNoTaxonomy());
			String sortQuery = TwitterConstant.getSortForEsTermAgg(tweeterActionVo.getTaxonomySortOrder().toLowerCase().trim());
			String subQuery = rtnFilterQuery(tweeterActionVo, -1);
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"termagg\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\"taxonomy\"\n,"+
					"\"size\":\""+size+"\"\n,"+
					sortQuery+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";

			System.out.println("*****getTaxonomy()***** "+query);

			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			TermsAggregation terms = result.getAggregations().getTermsAggregation("termagg");
			List<Entry>  entry=  terms.getBuckets();
			for(Entry entry2 : entry) 
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setHashtag(entry2.getKey());
				twitterVo.setHashCount(Long.toString(entry2.getCount()));
				lst.add(twitterVo);
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return lst; 
	}	

	
	public ArrayList<TwitterVo> getAuthorCountry(TweeterActionVo tweeterActionVo)
	{
		ArrayList<TwitterVo> list = new ArrayList<TwitterVo>();
		try
		{
			int size = TwitterConstant.getSizeForEsTermAgg(tweeterActionVo, tweeterActionVo.getNoCountry());	
			//String sortQuery = TwitterConstant.getSortForEsTermAgg(tweeterActionVo.getCountrySortOrder().toLowerCase().trim());
			String sortQuery = TwitterConstant.getSortForEsTermAgg(tweeterActionVo.getAuthorCountrySortOrder().toLowerCase().trim());
			String subQuery = rtnFilterQuery(tweeterActionVo, -1);
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"termagg\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\"tweet.tweetUser.tweetUserLocation\"\n,"+
					"\"size\":\""+size+"\"\n,"+
					sortQuery+
					"}\n"+
					TwitterConstant.getAvg("articleSentiment")+
					"}\n"+
					"}\n"+
					"}\n";

			System.out.println("*****getAuthorCountry()***** "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			TermsAggregation terms = result.getAggregations().getTermsAggregation("termagg");
			if(terms !=null) {
				List<Entry> entry = terms.getBuckets();
				for(Entry entry2 : entry) {
					if(entry2.getKey()!=null && entry2.getKey().length() > 0) {
						TwitterVo twitterVo=new TwitterVo();
						twitterVo.setHashtag(entry2.getKey());
						twitterVo.setHashCount(Long.toString(entry2.getCount()));
						AvgAggregation avg = entry2.getAvgAggregation("avg");
						twitterVo.setSentiment(Double.toString(avg.getAvg()));
						list.add(twitterVo);
					}
				}
			}
		} catch(Exception ex) {
			ex.printStackTrace();
		}
		return list; 
	}

	
	public ArrayList<TwitterVo> getAuthorCity(TweeterActionVo tweeterActionVo)
	{
		ArrayList<TwitterVo> list = new ArrayList<TwitterVo>();
		try
		{
			int size = TwitterConstant.getSizeForEsTermAgg(tweeterActionVo, tweeterActionVo.getNoCity());	
			String sortQuery = TwitterConstant.getSortForEsTermAgg(tweeterActionVo.getCitySortOrder().toLowerCase().trim());
			String subQuery = rtnFilterQuery(tweeterActionVo, -1);
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"termagg\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\"tweet.tweetUser.tweetUserLocation\"\n,"+
					"\"size\":\""+size+"\"\n,"+
					sortQuery+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";

			System.out.println("*****getAuthorCity()***** "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			TermsAggregation terms = result.getAggregations().getTermsAggregation("termagg");
			List<Entry>  entry=  terms.getBuckets();
			for (Entry entry2 : entry) 
			{
				TwitterVo twitterVo=new TwitterVo();
				twitterVo.setHashtag(entry2.getKey());
				twitterVo.setHashCount(Long.toString(entry2.getCount()));
				list.add(twitterVo);
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return list;
	}


	
	public ArrayList<Fb_groupVo> fb_scrapy_user_friends(TweeterActionVo fbInputVo)
	{
		ArrayList<Fb_groupVo> lst=new ArrayList<Fb_groupVo>();
		List<Map<String,Object>> rows=null;
		try
		{
			String query =" select friendsAll_userName, friend_photo, friendsAll_userId, localImagePath "
					+ " from fb_scrap_user_friends  "
					+ " where fb_userId='"+fbInputVo.getUserFilter()+"'  ";

			int countryFilterSize = fbInputVo.getFbFriendsByCountry().size();
			int cityFilterSize = fbInputVo.getFbFriendsByCity().size();
			String country = "";
			String countryFilter = "";
			String city = "";
			String cityFilter = "";

			if(countryFilterSize > 0)
			{
				for(int i=0; i<countryFilterSize; i++)
				{
					country = fbInputVo.getFbFriendsByCountry().get(i);
					countryFilter+="'"+country+"',";
				}
				countryFilter=countryFilter.substring(0, countryFilter.length()-1);				
				query+=" and country in ("+countryFilter+") ";
			}

			if(cityFilterSize > 0)
			{
				for(int i=0; i<cityFilterSize; i++)
				{
					city = fbInputVo.getFbFriendsByCity().get(i);
					cityFilter+="'"+city+"',";
				}
				cityFilter=cityFilter.substring(0, cityFilter.length()-1);				
				query+=" and city in ("+cityFilter+")  ";
			}

			System.out.println("fb_scrapy_user_friends: "+query);

			rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				Fb_groupVo fbOutputVo=new Fb_groupVo();
				fbOutputVo.setGp_name(rs.get("friendsAll_userName")==null?"":rs.get("friendsAll_userName").toString());
				fbOutputVo.setGp_photo(rs.get("friend_photo")==null?"":rs.get("friend_photo").toString());
				fbOutputVo.setGp_Id(rs.get("friendsAll_userId")==null?"":rs.get("friendsAll_userId").toString());
				fbOutputVo.setLocalImgName(rs.get("localImagePath")==null?"":rs.get("localImagePath").toString());
				lst.add(fbOutputVo);
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		} 
		return lst;
	}


	
	public ArrayList<Fb_groupVo> fbTopMostUserReacted(TweeterActionVo fbInputVo)
	{
		ArrayList<Fb_groupVo> lst=new ArrayList<Fb_groupVo>();
		List<Map<String,Object>> rows=null;
		try
		{
			String query =" SELECT friend_user_id, friend_user_name, friend_user_display_name, "
					+ " friend_user_img, localImagePath, COUNT(*) AS cnt "
					+ " FROM fb_post_like_comment_user "
					+ " where fb_user_id='"+fbInputVo.getUserFilter()+"' "
					+ " OR fb_user_id='"+fbInputVo.getUserName()+"' "
					+ " AND action_type='like' "+
					" GROUP BY friend_user_id ORDER BY cnt DESC limit 300 ";

			System.out.println("fbTopMostUserReacted::"+query);
			rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				Fb_groupVo fbOutputVo=new Fb_groupVo();
				fbOutputVo.setGp_name(rs.get("friend_user_display_name")==null?"":rs.get("friend_user_display_name").toString());
				fbOutputVo.setGp_photo(rs.get("friend_user_img")==null?"":rs.get("friend_user_img").toString());
				fbOutputVo.setGp_Id(rs.get("friend_user_id")==null?"":rs.get("friend_user_id").toString());
				fbOutputVo.setUser_name(rs.get("friend_user_name")==null?"":rs.get("friend_user_name").toString());
				fbOutputVo.setLocalImgName(rs.get("localImagePath")==null?"":rs.get("localImagePath").toString());			
				fbOutputVo.setCount(Integer.parseInt(rs.get("cnt").toString()));
				lst.add(fbOutputVo);
			}
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		} 
		return lst;
	}


	
	public ArrayList<Fb_groupVo> fbTopMostUserCommented(TweeterActionVo fbInputVo) 
	{
		ArrayList<Fb_groupVo> lst=new ArrayList<Fb_groupVo>();
		List<Map<String,Object>> rows=null;
		try
		{
			String query =" SELECT friend_user_id, friend_user_name, friend_user_display_name, "
					+ " friend_user_img, localImagePath, COUNT(*) AS cnt "
					+ " FROM fb_post_like_comment_user "
					+ " where fb_user_id='"+fbInputVo.getUserFilter()+"' "
					+ " OR fb_user_id='"+fbInputVo.getUserName()+"' "
					+ " AND action_type='comment' "+
					" GROUP BY friend_user_id ORDER BY cnt DESC limit 300  ";

			System.out.println("fbTopMostUserCommented::"+query);

			rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				Fb_groupVo fbOutputVo=new Fb_groupVo();
				fbOutputVo.setGp_name(rs.get("friend_user_display_name")==null?"":rs.get("friend_user_display_name").toString());
				fbOutputVo.setGp_photo(rs.get("friend_user_img")==null?"":rs.get("friend_user_img").toString());
				fbOutputVo.setGp_Id(rs.get("friend_user_id")==null?"":rs.get("friend_user_id").toString());
				fbOutputVo.setUser_name(rs.get("friend_user_name")==null?"":rs.get("friend_user_name").toString());
				fbOutputVo.setLocalImgName(rs.get("localImagePath")==null?"":rs.get("localImagePath").toString());
				fbOutputVo.setCount(Integer.parseInt(rs.get("cnt").toString()));
				lst.add(fbOutputVo);
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		} 
		return lst;
	}


	
	public ArrayList<Fb_groupVo> fbTopMostUserStrongConnection(TweeterActionVo fbInputVo)
	{
		ArrayList<Fb_groupVo> list=new ArrayList<Fb_groupVo>();
		List<Map<String,Object>> rows=null;
		try
		{
			String query =" SELECT friend_user_id, friend_user_name, friend_user_display_name, "
					    + " friend_user_img, COUNT(*) AS cnt, localImagePath "
					    + " FROM fb_post_like_comment_user "
					    + " WHERE fb_user_id='"+fbInputVo.getUserFilter()+"' "
					    + " OR fb_user_id='"+fbInputVo.getUserName()+"' "
					    + " GROUP BY friend_user_id ORDER BY cnt DESC limit 200  ";

			System.out.println("fbTopMostUserStrongConnection: "+query);

			rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				Fb_groupVo fbOutputVo=new Fb_groupVo();
				fbOutputVo.setGp_name(rs.get("friend_user_display_name")==null?"":rs.get("friend_user_display_name").toString());
				fbOutputVo.setGp_photo(rs.get("friend_user_img")==null?"":rs.get("friend_user_img").toString());
				fbOutputVo.setGp_Id(rs.get("friend_user_id")==null?"":rs.get("friend_user_id").toString());
				fbOutputVo.setCount(Integer.parseInt(rs.get("cnt").toString()));
				fbOutputVo.setLocalImgName(rs.get("localImagePath")==null?"":rs.get("localImagePath").toString());
				list.add(fbOutputVo);
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		} 
		return list;
	}


	
	public ArrayList<Fb_groupVo> fbTopMostReactionChart(TweeterActionVo fbInputVo)
	{
		ArrayList<Fb_groupVo> lst=new ArrayList<Fb_groupVo>();
		List<Map<String,Object>> rows=null;
		try
		{
			/*			String query =" SELECT fb_post_like_comment_user.reaction_type,COUNT(*) AS cnt FROM fb_post_like_comment_user "
					+ " where fb_user_id='"+fbInputVo.getUserFilter()+"' "+
			         " GROUP BY  reaction_type ORDER BY cnt DESC  ";
			 */
			String query =" SELECT COALESCE(country, 'No Country') AS country, COUNT(*) AS cnt   "
					+ " FROM fb_scrap_user_friends "
					+ " where fb_userId='"+fbInputVo.getUserFilter()+"' "
					+ " OR fb_userId='"+fbInputVo.getUserName()+"' "
					+ " GROUP BY COALESCE(country,'No Country') ORDER BY cnt DESC  ";
			System.out.println("fbTopMostReactionChart: "+query);

			rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				Fb_groupVo fbOutputVo=new Fb_groupVo();
				fbOutputVo.setGp_name(rs.get("country")==null?"":rs.get("country").toString());
				fbOutputVo.setCount(Integer.parseInt(rs.get("cnt").toString()));
				lst.add(fbOutputVo);
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		} 
		return lst;
	}


	
	public ArrayList<Fb_groupVo> fbTopMosCityOfFriend(TweeterActionVo fbInputVo)
	{
		ArrayList<Fb_groupVo> lst = new ArrayList<Fb_groupVo>();
		List<Map<String,Object>> rows=null;
		try
		{
			/*			String query =" SELECT fb_post_like_comment_user.reaction_type,COUNT(*) AS cnt FROM fb_post_like_comment_user "
					+ " where fb_user_id='"+fbInputVo.getUserFilter()+"' "+
			         " GROUP BY  reaction_type ORDER BY cnt DESC  ";
			 */
			String query =" SELECT COALESCE(city, 'No City') AS city, COUNT(*) AS cnt "
					+ " FROM fb_scrap_user_friends "
					+ " where fb_userId='"+fbInputVo.getUserFilter()+"' "
					+ " OR fb_userId='"+fbInputVo.getUserName()+"'"
					+ "  GROUP BY  COALESCE(city, 'No City') ORDER BY cnt DESC  ";
			System.out.println("fbTopMosCityOfFriend: "+query);

			rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				Fb_groupVo fbOutputVo=new Fb_groupVo();
				fbOutputVo.setGp_name(rs.get("city")==null?"":rs.get("city").toString());
				fbOutputVo.setCount(Integer.parseInt(rs.get("cnt").toString()));
				lst.add(fbOutputVo);
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		} 
		return lst;
	}


	
	public ArrayList<TwitterVo> getHashtagViewBasicInformation(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> list = new ArrayList<TwitterVo>();
		try
		{	
			String hashtag = tweeterActionVo.getHashTagFilter().trim();			
			String hashtagFilter = hashtag.substring(1);

			String query = "{ \"size\": 1, \"query\": { \"bool\": { \"filter\": { \"bool\": { \"must\": [ { \"terms\": { \"articleSource\": [ \"tw\" ] } }, { \"terms\": { \"articleHashTag\": [ \""+hashtagFilter+"\" ] } } ], \"must_not\": [ {} ] } } } }, \"sort\": [ { \"articlePublishDate\": { \"order\": \"asc\" } } ] }";

			System.out.println("*****getHashtagViewBasicInformation()***** "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);			
			List<Article_Datacollection_New> testLst = result.getSourceAsObjectList(Article_Datacollection_New.class);
			JsonArray arry = null;
			if(testLst.size()>0)
			{
				arry=result.getJsonObject().get("hits").getAsJsonObject().get("hits").getAsJsonArray();
			}

			int i=0;
			for(Article_Datacollection_New article_Datacollection_New : testLst) 
			{
				TwitterVo twitterVo = new TwitterVo();
				String link ="https://twitter.com/"+article_Datacollection_New.getArticleAuthor()+"/status/"+article_Datacollection_New.getArticleId();

				twitterVo.setLink(link);
				//twitterVo.setTotalTweetCount(Integer.toString(result.getTotal()));
				twitterVo.setTotalTweetCount(Long.toString(result.getTotal()));
				twitterVo.setArticleId(article_Datacollection_New.getArticleId());
				twitterVo.setArticleAuthor(article_Datacollection_New.getArticleAuthor());
				twitterVo.setArticleAuthorId(article_Datacollection_New.getArticleAuthorId());
				twitterVo.setArticleAuthorImage(article_Datacollection_New.getArticleAuthorImage());
				twitterVo.setArticleAuthorImageUrlLocal(article_Datacollection_New.getArticleAuthorImageUrlLocal());
				twitterVo.setArticlePublishDate(CommonUtils.convertUnixTimeToDateDisplayFormat((article_Datacollection_New.getArticlePublishDate())));
				twitterVo.setArticleTitle(article_Datacollection_New.getArticleTitle());
				twitterVo.setArticleSubTitle(article_Datacollection_New.getArticleSubTitle());
				twitterVo.setArticleSentiment(article_Datacollection_New.getArticleSentiment());
				twitterVo.setPriority("0");

				if(article_Datacollection_New.getArticleMarked() !=null)
				{
					if(article_Datacollection_New.getArticleMarked().size()>0)
					{
						String user = (String)httpSession.getAttribute(ApplicationConstants.LOGINUSERID);					   	
						if(article_Datacollection_New.getArticleMarked().indexOf(Integer.parseInt(user))>-1)
						{
							twitterVo.setPriority("1");
						}
					}
				}

				twitterVo.setTweet(article_Datacollection_New.getTweet());
				twitterVo.setYoutube(article_Datacollection_New.getYoutube());
				twitterVo.setDailymotion(article_Datacollection_New.getDailymotion());
				twitterVo.setInstagram(article_Datacollection_New.getInstagram());
				twitterVo.setFacebook(article_Datacollection_New.getFacebook());
				twitterVo.setWordpress(article_Datacollection_New.getWordpress());
				twitterVo.setBlogger(article_Datacollection_New.getBlogger());
				twitterVo.setArticleSource(article_Datacollection_New.getArticleSource());
				twitterVo.setArticleType(article_Datacollection_New.getArticleType());
				twitterVo.setArticleMedia(article_Datacollection_New.getArticleMedia());
				twitterVo.setArticleEmotion(article_Datacollection_New.getArticleEmotion());
				twitterVo.setArticleEmotionScore(article_Datacollection_New.getArticleEmotionScore());
				twitterVo.setArticleSummary(article_Datacollection_New.getArticleSummary());
				twitterVo.setArticleClassification(article_Datacollection_New.getArticleClassification());

				if(arry.get(i).getAsJsonObject().has("highlight"))
				{
					JsonObject highlightObj = arry.get(i).getAsJsonObject().get("highlight").getAsJsonObject();
					if(highlightObj.has("articleTitle"))
					{
						try 
						{
							twitterVo.setArticleTitle(highlightObj.get("articleTitle").getAsJsonArray().getAsString());
						} 
						catch(Exception e) 
						{ 
							e.printStackTrace();
						}
					}
				}
				list.add(twitterVo);
				i++;
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return list; 			
	}


	
	public ArrayList<TwitterVo> getMaxAndMinDateOfFacebookUserProfilePost(TweeterActionVo tweeterActionVo)
	{
		ArrayList<TwitterVo> list = new ArrayList<TwitterVo>();
		try
		{
			String subQuery = rtnFilterQuery(tweeterActionVo, -1);

			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"termagg\":{\n"+
					"\"stats\":{\n"+
					"\"field\":\"articlePublishDate\"\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";

			System.out.println("*****getMaxAndMinDateOfFacebookUserProfilePost()***** "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);					
			StatsAggregation terms = result.getAggregations().getStatsAggregation("termagg");

			Double maxDate = terms.getMax();
			Double minDate = terms.getMin();

			if(maxDate != null || minDate != null)
			{
				BigDecimal bd1 = new BigDecimal(maxDate);
				BigDecimal bd2 = new BigDecimal(minDate);
				long max = bd1.longValue();
				long min = bd2.longValue();
				System.out.println("max date: "+max);
				System.out.println("min date: "+min);
				TwitterVo twitterVo = new TwitterVo();
				twitterVo.setStatsDateFrom(TwitterConstant.convertTimeStampToDate(min));
				twitterVo.setStatsDateTo(TwitterConstant.convertTimeStampToDate(max));
				list.add(twitterVo);
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return list; 
	}


	
	public ArrayList<TwitterVo> getMaxAndMinDateOfLinkedinProfilePost(TweeterActionVo tweeterActionVo)
	{
		ArrayList<TwitterVo> list = new ArrayList<TwitterVo>();
		try
		{
			String subQuery = rtnFilterQuery(tweeterActionVo, -1);

			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"termagg\":{\n"+
					"\"stats\":{\n"+
					"\"field\":\"articlePublishDate\"\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";

			System.out.println("*****getMaxAndMinDateOfLinkedinProfilePost()***** "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);					
			StatsAggregation terms = result.getAggregations().getStatsAggregation("termagg");

			Double maxDate = terms.getMax();
			Double minDate = terms.getMin();

			if(maxDate != null || minDate != null)
			{
				BigDecimal bd1 = new BigDecimal(maxDate);
				BigDecimal bd2 = new BigDecimal(minDate);
				long max = bd1.longValue() + 86400000;
				long min = bd2.longValue() - 86400000;
				System.out.println("max date: "+max);
				System.out.println("min date: "+min);
				TwitterVo twitterVo = new TwitterVo();
				twitterVo.setStatsDateFrom(TwitterConstant.convertTimeStampToDate(min));
				twitterVo.setStatsDateTo(TwitterConstant.convertTimeStampToDate(max));
				list.add(twitterVo);
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return list;
	}

	
	public ArrayList<EntityVo> getFacebookUserProfileFromNewAnalysis(EntityVo entityVo) 
	{
		System.out.println("SnapshortId: "+entityVo.getSnapshotId());
		ArrayList<EntityVo> lstEntity = new ArrayList<>();
		List<Map<String, Object>> rows = null;

		try
		{	
			String query=" SELECT entity_id, entity_name "
					+ " FROM tbl_case_profile "
					+ " WHERE snapshot_id = '"+entityVo.getSnapshotId()+"' "
					+ " AND entity_source_type = 'fb' ";

			System.out.println("getFacebookUserProfileFromNewAnalysis: "+query);
			rows = jdbcTemplate.queryForList(query);

			for(Map<String, Object> rs : rows)
			{					
				EntityVo entity = new EntityVo();
				entity.setEntitySocialId(rs.get("entity_id")==null?"":rs.get("entity_id").toString().trim());
				entity.setEntityName(rs.get("entity_name")==null?"":rs.get("entity_name").toString().trim());					
				lstEntity.add(entity);
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace(); 
		} 
		return lstEntity;
	}



	public void updateClassification(TweeterActionVo tweeterActionVo)
	{
		String content = "";				
		try
		{
			String subQuery= "\"query\": {\n"+
					"\"term\": {\n"+
					"\"articleId\": {\n"+
					"\"value\": \""+tweeterActionVo.getTweetId().trim()+"\"\n"+
					"}\n"+
					"}\n"+
					"}\n";

			String query="{\n"
					+subQuery
					+ "}\n";

			System.out.println("updateClassification********** "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			List<Article_Datacollection_New> testLst = result.getSourceAsObjectList(Article_Datacollection_New.class);
			for (Article_Datacollection_New article_Datacollection_New : testLst)
			{					    			    
				content+= article_Datacollection_New.getArticleTitle();
				if(article_Datacollection_New.getArticleSubTitle() != null)
				{
					content+= article_Datacollection_New.getArticleSubTitle();
				}

				if(article_Datacollection_New.getArticleBigContent() != null)
				{
					content+= article_Datacollection_New.getArticleBigContent();
				}
			}

			//Update to mysql
			Object[] obj = null;
			String sqlQuery= "INSERT ignore INTO tbl_update_classification(old_classification, new_classification, article_id, document, source_type) VALUES(?,?,?,?,?)" ;
			obj=new Object[]{
					tweeterActionVo.getKeywordFilter().trim(), 
					tweeterActionVo.getKeywordFilter1().trim(), 
					tweeterActionVo.getTweetId().trim(),
					content, 
					tweeterActionVo.getSourceFilter().trim()											
			};
			jdbcTemplate.update(sqlQuery, obj);				
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}


	
	public void updateSentiment(TweeterActionVo tweeterActionVo) 
	{
		String content = "";				
		try
		{
			String subQuery= "\"query\": {\n"+
					"\"term\": {\n"+
					"\"articleId\": {\n"+
					"\"value\": \""+tweeterActionVo.getTweetId().trim()+"\"\n"+
					"}\n"+
					"}\n"+
					"}\n";

			String query="{\n"
					+subQuery
					+ "}\n";

			System.out.println("updateSentiment********** "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			List<Article_Datacollection_New> testLst = result.getSourceAsObjectList(Article_Datacollection_New.class);

			for(Article_Datacollection_New article_Datacollection_New : testLst)
			{
				content+= article_Datacollection_New.getArticleTitle();
				if(article_Datacollection_New.getArticleSubTitle() != null)
				{
					content+= article_Datacollection_New.getArticleSubTitle();
				}

				if(article_Datacollection_New.getArticleBigContent() != null)
				{
					content+= article_Datacollection_New.getArticleBigContent();
				}
			}

			//Update to mysql
			Object[] obj = null;
			String sqlQuery= "INSERT ignore INTO tbl_update_sentiment(old_sentiment, new_sentiment, article_id, document, source_type) VALUES(?,?,?,?,?)" ;
			obj=new Object[]{
					tweeterActionVo.getKeywordFilter().trim(), 
					tweeterActionVo.getKeywordFilter1().trim(), 
					tweeterActionVo.getTweetId().trim(),
					content, 
					tweeterActionVo.getSourceFilter().trim()											
			};
			jdbcTemplate.update(sqlQuery, obj);				
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}		
	}


	
	public ArrayList<Fb_groupVo> getFBPeopleProfileWithSameGroup(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<Fb_groupVo> list = new ArrayList<Fb_groupVo>();
		List<Map<String, Object>> rows=null;

		try
		{
			String query=" SELECT DISTINCT user_id, user_name FROM fb_scrap_group "
					+" WHERE gp_id IN(SELECT gp_id FROM fb_scrap_group WHERE user_id='"+tweeterActionVo.getUserFilter()+"' OR user_id='"+tweeterActionVo.getUserName()+"') "
					+" AND user_id!='"+tweeterActionVo.getUserFilter()+"' AND user_id!='"+tweeterActionVo.getUserName()+"' ";
			System.out.println("getFBPeopleProfileWithSameGroup: "+query);

			rows = jdbcTemplate.queryForList(query);
			for(Map<String, Object> rs :rows)
			{
				Fb_groupVo fbOutputVo=new Fb_groupVo();
				fbOutputVo.setUser_id(rs.get("user_id")==null?"":rs.get("user_id").toString());
				fbOutputVo.setUser_name(rs.get("user_name")==null?"":rs.get("user_name").toString());				
				list.add(fbOutputVo);
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		} 
		return list;
	}


	
	public ArrayList<Fb_groupVo> getFBPeopleProfileWithSameLikes(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<Fb_groupVo> list = new ArrayList<Fb_groupVo>();
		List<Map<String, Object>> rows=null;

		try
		{
			String query=" SELECT DISTINCT fb_user_id, fb_user_name FROM fb_scrap_user_like_detail "
					+" WHERE liked_userId IN (SELECT fb_scrap_user_like_detail.liked_userId FROM fb_scrap_user_like_detail WHERE fb_user_id='"+tweeterActionVo.getUserFilter()+"' OR fb_user_id='"+tweeterActionVo.getUserName()+"') "    
					+" AND fb_user_id !='"+tweeterActionVo.getUserFilter()+"' AND fb_user_id !='"+tweeterActionVo.getUserName()+"'";
			System.out.println("getFBPeopleProfileWithSameLikes: "+query);

			rows = jdbcTemplate.queryForList(query);
			for(Map<String, Object> rs :rows)
			{
				Fb_groupVo fbOutputVo=new Fb_groupVo();
				fbOutputVo.setUser_id(rs.get("fb_user_id")==null?"":rs.get("fb_user_id").toString());
				fbOutputVo.setUser_name(rs.get("fb_user_name")==null?"":rs.get("fb_user_name").toString());				
				list.add(fbOutputVo);
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		} 
		System.out.println(list);
		return list;

	}


	
	public ArrayList<Fb_groupVo> getFBPeopleProfileWithSameCheckIn(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<Fb_groupVo> list = new ArrayList<Fb_groupVo>();
		List<Map<String, Object>> rows=null;

		try
		{
			String query=" SELECT DISTINCT fb_user_id, fb_user_name FROM fb_scrap_user_check_in  "
					+" WHERE check_in_name IN (SELECT check_in_name FROM fb_scrap_user_check_in  WHERE fb_user_id='"+tweeterActionVo.getUserFilter()+"' OR fb_user_id='"+tweeterActionVo.getUserName()+"' ) "
					+" AND fb_user_id !='"+tweeterActionVo.getUserFilter()+"' AND fb_user_id !='"+tweeterActionVo.getUserName()+"'";
			System.out.println("getFBPeopleProfileWithSameCheckIn: "+query);

			rows = jdbcTemplate.queryForList(query);
			for(Map<String, Object> rs :rows)
			{
				Fb_groupVo fbOutputVo=new Fb_groupVo();
				fbOutputVo.setUser_id(rs.get("fb_user_id")==null?"":rs.get("fb_user_id").toString());
				fbOutputVo.setUser_name(rs.get("fb_user_name")==null?"":rs.get("fb_user_name").toString());				
				list.add(fbOutputVo);
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		} 
		return list;
	}


	
	public ArrayList<Fb_groupVo> getFBPeopleProfileWithSameLocation(TweeterActionVo tweeterActionVo) 
	{
		String locationStr = "";
		int i;
		if(tweeterActionVo.getLocationGlobalFilter().size() > 0)
		{
			for(i = 0; i< tweeterActionVo.getLocationGlobalFilter().size(); i++)
			{
				String location = tweeterActionVo.getLocationGlobalFilter().get(i);
				if(i==0)
				{
					locationStr+= "place_lived LIKE "+ "'"+"%"+location+"%"+"'" ;
				}
				else
				{
					locationStr+= " OR place_lived LIKE "+ "'"+"%"+location+"%"+"'" ;
				}			
			}
		}
		else
		{
			locationStr+= "place_lived LIKE '%11111%' ";
		}

		ArrayList<Fb_groupVo> list = new ArrayList<Fb_groupVo>();
		List<Map<String, Object>> rows=null;

		try
		{			
			String query=" SELECT DISTINCT fb_user_id, profile_id "
					+ " FROM fb_scrap_profile_place_lived "
					+ " INNER JOIN collection_profile "
					+ " ON collection_profile.profile_id=fb_scrap_profile_place_lived.fb_user_id "
					+ " WHERE "+locationStr+" AND fb_scrap_profile_place_lived.fb_user_id !='"+tweeterActionVo.getUserFilter()+"' ";

			System.out.println("getFBPeopleProfileWithSameLocation: "+query);

			rows = jdbcTemplate.queryForList(query);
			for(Map<String, Object> rs :rows)
			{
				Fb_groupVo fbOutputVo=new Fb_groupVo();
				fbOutputVo.setUser_id(rs.get("fb_user_id")==null?"":rs.get("fb_user_id").toString());
				fbOutputVo.setUser_name(rs.get("entity_name")==null?"":rs.get("entity_name").toString());
				list.add(fbOutputVo);
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		} 
		return list;
	}

	
	public ArrayList<Fb_OutputVo> getFBPageBasicInfo(TweeterActionVo fbInputVo) 
	{
		ArrayList<Fb_OutputVo> list = new ArrayList<Fb_OutputVo>();
		List<Map<String, Object>> rows = null;

		try
		{
			String query=" SELECT fb_pageid, fb_page_name, about, page_pro_pic, page_cover_pic "
					+ " FROM fb_scrap_page_about"
					+ " WHERE fb_pageid='"+fbInputVo.getUserFilter()+"' ";					
			System.out.println("getFBPageBasicInfo: "+query);

			rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				Fb_OutputVo fbOutputVo = new Fb_OutputVo();
				fbOutputVo.setFb_user_id(rs.get("fb_pageid")==null?"":rs.get("fb_pageid").toString());
				fbOutputVo.setUser_name(rs.get("fb_page_name")==null?"":rs.get("fb_page_name").toString());
				fbOutputVo.setBasic_info(rs.get("about")==null?"":rs.get("about").toString());				
				fbOutputVo.setUser_photo_url(rs.get("page_pro_pic")==null?"":rs.get("page_pro_pic").toString());
				fbOutputVo.setUser_cover_photo(rs.get("page_cover_pic")==null?"":rs.get("page_cover_pic").toString());
				list.add(fbOutputVo);
			}			  
		}
		catch(Exception ex)
		{
			ex.printStackTrace(); 
		} 
		return list;
	}



	//FOR DEMO WORK==============================================//FOR DEMO WORK
	
	public ArrayList<TwitterVo> strongFollowersOfAPC(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> list = new ArrayList<TwitterVo>();
		List<Map<String, Object>> rows = null;
		try 
		{
			String query = " SELECT twUserScreenName, followersCount FROM demo_strong_followers_of_APC "; 
			System.out.println("strongFollowersOfAPC: "+query);

			rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				TwitterVo twitterVo = new TwitterVo();
				twitterVo.setHashtag(rs.get("twUserScreenName")==null?"":rs.get("twUserScreenName").toString());
				twitterVo.setFollowersCount(rs.get("followersCount")==null?"":rs.get("followersCount").toString());
				list.add(twitterVo);
			}
		} 
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return list;
	}

	
	public ArrayList<TwitterVo> strongFollowersOfAPCImage(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> list = new ArrayList<TwitterVo>();
		List<Map<String, Object>> rows = null;
		try 
		{
			String query = " SELECT twUserScreenName, followersCount FROM demo_strong_followers_of_APC_image "; 
			System.out.println("strongFollowersOfAPCImage: "+query);

			rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				TwitterVo twitterVo = new TwitterVo();
				twitterVo.setHashtag(rs.get("twUserScreenName")==null?"":rs.get("twUserScreenName").toString());
				twitterVo.setFollowersCount(rs.get("followersCount")==null?"":rs.get("followersCount").toString());
				list.add(twitterVo);
			}
		} 
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return list;
	}

	
	public ArrayList<TwitterVo> suspectedBOTsOfAPC(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> list = new ArrayList<TwitterVo>();
		List<Map<String, Object>> rows = null;
		try 
		{
			String query = " SELECT twUserScreenName, score, followersCount FROM demo_suspected_BOTs_of_APC "; 
			System.out.println("suspectedBOTsOfAPC: "+query);

			rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				TwitterVo twitterVo = new TwitterVo();
				twitterVo.setHashtag(rs.get("twUserScreenName")==null?"":rs.get("twUserScreenName").toString());
				twitterVo.setHashCount(rs.get("score")==null?"":rs.get("score").toString());
				twitterVo.setFollowersCount(rs.get("followersCount")==null?"":rs.get("followersCount").toString());
				list.add(twitterVo);
			}
		} 
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return list;
	}

	
	public ArrayList<TwitterVo> strongFollowersOfPDP(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> list = new ArrayList<TwitterVo>();
		List<Map<String, Object>> rows = null;
		try 
		{
			String query = " SELECT twUserScreenName, followersCount FROM demo_strong_followers_of_PDP "; 
			System.out.println("strongFollowersOfPDP: "+query);

			rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				TwitterVo twitterVo = new TwitterVo();
				twitterVo.setHashtag(rs.get("twUserScreenName")==null?"":rs.get("twUserScreenName").toString());
				twitterVo.setFollowersCount(rs.get("followersCount")==null?"":rs.get("followersCount").toString());
				list.add(twitterVo);
			}
		} 
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return list;
	}

	
	public ArrayList<TwitterVo> suspectedBOTsOfPDP(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> list = new ArrayList<TwitterVo>();
		List<Map<String, Object>> rows = null;
		try 
		{
			String query = " SELECT twUserScreenName, score, followersCount FROM demo_suspected_BOTs_of_PDP "; 
			System.out.println("suspectedBOTsOfPDP: "+query);

			rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				TwitterVo twitterVo = new TwitterVo();
				twitterVo.setHashtag(rs.get("twUserScreenName")==null?"":rs.get("twUserScreenName").toString());
				twitterVo.setHashCount(rs.get("score")==null?"":rs.get("score").toString());
				twitterVo.setFollowersCount(rs.get("followersCount")==null?"":rs.get("followersCount").toString());
				list.add(twitterVo);
			}
		} 
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return list;
	}
	//================================================================//

	public TwitterVo getArticleById(TweeterActionVo tweeterActionVo) {
		TwitterVo twitterVo = new  TwitterVo();
		try {
			String subQuery=  "\"query\": {\n"+
					"\"term\": {\n"+
					"\"articleId\": {\n"+
					"\"value\": \""+tweeterActionVo.getTweetId().trim()+"\"\n"+
					"}\n"+
					"}\n"+
					"}\n";

			String query="{\n"
					+subQuery
					+ "}\n";

			System.out.println("getArticleById**********"+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();
			SearchResult result = client.execute(search);
			List<Article_Datacollection_New> testLst = result.getSourceAsObjectList(Article_Datacollection_New.class);

			for(Article_Datacollection_New article_Datacollection_New : testLst) {
				twitterVo.setArticleTitle(article_Datacollection_New.getArticleTitle());
				twitterVo.setArticleBigContent(article_Datacollection_New.getArticleBigContent());
				twitterVo.setTweeterId(article_Datacollection_New.getArticleId());
				twitterVo.setArticleLocationCountry(article_Datacollection_New.getRssCountryCode());
			}
		} catch(Exception ex) {
			ex.printStackTrace();
		} 
		return twitterVo;
	}


	//==================FB PAGE RPT======================================//
	
	public ArrayList<TwitterVo> fbPageBasicInfoRpt(TweeterActionVo fbInputVo) 
	{
		ArrayList<TwitterVo> list = new ArrayList<TwitterVo>();
		List<Map<String, Object>> rows = null;
		try 
		{
			String selectQuery = " SELECT fb_pageid, fb_page_name, about, page_story, page_cover_pic, page_pro_pic, "
					           + " user_picture_local, user_cover_local, page_like, page_follow "
					           + " FROM fb_scrap_page_about "
					           + " WHERE fb_pageid='"+fbInputVo.getUserIdFilter()+"' "; 
			System.out.println("fbPageBasicInfoRpt: "+selectQuery);

			rows = jdbcTemplate.queryForList(selectQuery);
			for(Map<String,Object> rs :rows)
			{
				TwitterVo twitterVo = new TwitterVo();
				twitterVo.setUserId(rs.get("fb_pageid")==null?"":rs.get("fb_pageid").toString());
				twitterVo.setUserName(rs.get("fb_page_name")==null?"":rs.get("fb_page_name").toString());
				twitterVo.setDescription(rs.get("about")==null?"":rs.get("about").toString());
				twitterVo.setArticleSummary(rs.get("page_story")==null?"":rs.get("page_story").toString());								
				twitterVo.setNodeImg1(rs.get("page_cover_pic")==null?"":rs.get("page_cover_pic").toString());
				twitterVo.setNodeImg2(rs.get("page_pro_pic")==null?"":rs.get("page_pro_pic").toString());
				twitterVo.setProfileLocalImage(rs.get("user_picture_local")==null?"":rs.get("user_picture_local").toString());
				twitterVo.setCoverLocalImage(rs.get("user_cover_local")==null?"":rs.get("user_cover_local").toString());
				twitterVo.setFavouritesCount(rs.get("page_like")==null?"":rs.get("page_like").toString());
				twitterVo.setFollowersCount(rs.get("page_follow")==null?"":rs.get("page_follow").toString());
				twitterVo.setAbsPathLocal(TwitterConstant.getFacebookLocalImageUrl());
				list.add(twitterVo);
			}
		} 
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return list;
	}
	
	
	
	public ArrayList<TwitterVo> fbPageBasicInformationsDetailsRpt(TweeterActionVo fbInputVo) 
	{
		ArrayList<TwitterVo> list = new ArrayList<TwitterVo>();
		List<Map<String, Object>> rows = null;
		try 
		{
			String selectQuery = " SELECT fb_pageid, page_allinfo, info_type "
					           + " FROM fb_page_complete_about "
					           + " WHERE fb_pageid='"+fbInputVo.getUserIdFilter()+"' "; 
			System.out.println("fbPageBasicInformationsDetailsRpt: "+selectQuery);

			rows = jdbcTemplate.queryForList(selectQuery);
			for(Map<String,Object> rs :rows)
			{
				TwitterVo twitterVo = new TwitterVo();
				twitterVo.setUserId(rs.get("fb_pageid")==null?"":rs.get("fb_pageid").toString());
				twitterVo.setDescription(rs.get("page_allinfo")==null?"":rs.get("page_allinfo").toString());
				twitterVo.setArticleType(rs.get("info_type")==null?"":rs.get("info_type").toString());
				list.add(twitterVo);
			}
		} 
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return list;
	}
	

	
	public ArrayList<TwitterVo> fbPageMediaImageRpt(TweeterActionVo fbInputVo) 
	{
		ArrayList<TwitterVo> list = new ArrayList<TwitterVo>();
		List<Map<String, Object>> rows = null;
		try 
		{
			String selectQuery = " SELECT fb_user_id, fb_user_name, user_photo_url, user_post_url, localImagePath "
					+ " FROM fb_scrap_user_photo "
					+ " WHERE fb_user_id='"+fbInputVo.getUserIdFilter()+"' "; 
			System.out.println("fbPageMediaImageRpt: "+selectQuery);

			rows = jdbcTemplate.queryForList(selectQuery);
			for(Map<String,Object> rs :rows)
			{
				TwitterVo twitterVo = new TwitterVo();
				twitterVo.setUserId(rs.get("fb_user_id")==null?"":rs.get("fb_user_id").toString());
				twitterVo.setUserName(rs.get("fb_user_name")==null?"":rs.get("fb_user_name").toString());
				twitterVo.setArticleAuthorImage(rs.get("user_photo_url")==null?"":rs.get("user_photo_url").toString());
				twitterVo.setLink(rs.get("user_post_url")==null?"":rs.get("user_post_url").toString());
				twitterVo.setMediaLocalImage(rs.get("localImagePath")==null?"":rs.get("localImagePath").toString());
				twitterVo.setAbsPathLocal(TwitterConstant.getFacebookLocalImageUrl());
				list.add(twitterVo);
			}
		} 
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return list;
	}

	
	public ArrayList<TwitterVo> fbPageMediaVideoRpt(TweeterActionVo fbInputVo) 
	{
		ArrayList<TwitterVo> list = new ArrayList<TwitterVo>();
		List<Map<String, Object>> rows = null;
		try 
		{
			String selectQuery = " SELECT fb_user_id, fb_user_name, video_thumnail, video_url, localImagePath "
					           + " FROM fb_scrap_user_video "
					           + " WHERE fb_user_id='"+fbInputVo.getUserIdFilter()+"' "; 
			System.out.println("fbPageMediaVideoRpt: "+selectQuery);

			rows = jdbcTemplate.queryForList(selectQuery);
			for(Map<String,Object> rs :rows)
			{
				TwitterVo twitterVo = new TwitterVo();
				twitterVo.setUserId(rs.get("fb_user_id")==null?"":rs.get("fb_user_id").toString());
				twitterVo.setUserName(rs.get("fb_user_name")==null?"":rs.get("fb_user_name").toString());
				twitterVo.setArticleAuthorImage(rs.get("video_thumnail")==null?"":rs.get("video_thumnail").toString());
				twitterVo.setLink(rs.get("video_url")==null?"":rs.get("video_url").toString());
				twitterVo.setMediaLocalImage(rs.get("localImagePath")==null?"":rs.get("localImagePath").toString());
				twitterVo.setAbsPathLocal(TwitterConstant.getFacebookLocalImageUrl());
				list.add(twitterVo);
			}
		} 
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return list;
	}

	
	public ArrayList<Fb_groupVo> fbPageTopMostUserStrongConnection(TweeterActionVo fbInputVo) 
	{
		ArrayList<Fb_groupVo> list=new ArrayList<Fb_groupVo>();
		List<Map<String,Object>> rows=null;
		try
		{
			String query =" SELECT friend_user_id, friend_user_name, friend_user_display_name, friend_user_img, localImagePath, COUNT(*) AS cnt  "
					+ " FROM fb_post_like_comment_user "
					+ " where fb_user_id='"+fbInputVo.getUserFilter()+"' "
					+ " GROUP BY friend_user_id ORDER BY cnt DESC LIMIT 300 ";
			System.out.println("fbPageTopMostUserStrongConnection: "+query);

			rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				Fb_groupVo fbOutputVo=new Fb_groupVo();
				fbOutputVo.setGp_Id(rs.get("friend_user_id")==null?"":rs.get("friend_user_id").toString());
				fbOutputVo.setGp_memebers(rs.get("friend_user_name")==null?"":rs.get("friend_user_name").toString());
				fbOutputVo.setGp_name(rs.get("friend_user_display_name")==null?"":rs.get("friend_user_display_name").toString());
				fbOutputVo.setGp_photo(rs.get("friend_user_img")==null?"":rs.get("friend_user_img").toString());
				fbOutputVo.setLocalImgName(rs.get("localImagePath")==null?"":rs.get("localImagePath").toString());
				fbOutputVo.setAbsPathLocal(TwitterConstant.getFacebookLocalImageUrl());
				fbOutputVo.setCount(Integer.parseInt(rs.get("cnt").toString()));
				list.add(fbOutputVo);
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		} 
		return list;
	}


	
	public ArrayList<Fb_groupVo> fbPageAllPeoplesLikesThePage(TweeterActionVo fbInputVo)
	{
		ArrayList<Fb_groupVo> list=new ArrayList<Fb_groupVo>();
		List<Map<String,Object>> rows=null;
		try
		{
			String query =" SELECT page_id, page_name, user_id, user_name, user_image, localImagePath "
					+ " FROM fb_page_liked_by_this_page "
					+ " WHERE page_id='"+fbInputVo.getUserFilter()+"' ";
			System.out.println("fbPageAllPeoplesLikesThePage: "+query);

			rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				Fb_groupVo fbOutputVo=new Fb_groupVo();
				fbOutputVo.setUser_id(rs.get("page_id")==null?"":rs.get("page_id").toString());								
				fbOutputVo.setUser_name(rs.get("page_name")==null?"":rs.get("page_name").toString());
				fbOutputVo.setGp_Id(rs.get("user_id")==null?"":rs.get("user_id").toString());
				fbOutputVo.setGp_name(rs.get("user_name")==null?"":rs.get("user_name").toString());
				fbOutputVo.setGp_photo(rs.get("user_image")==null?"":rs.get("user_image").toString());
				fbOutputVo.setLocalImgName(rs.get("localImagePath")==null?"":rs.get("localImagePath").toString());
				fbOutputVo.setAbsPathLocal(TwitterConstant.getFacebookLocalImageUrl());
				list.add(fbOutputVo);
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		} 
		return list;
	}
	
	
	
	public ArrayList<Fb_groupVo> fbPageTopFan(TweeterActionVo fbInputVo)
	{
		ArrayList<Fb_groupVo> list=new ArrayList<Fb_groupVo>();
		List<Map<String,Object>> rows=null;
		try
		{
			String query =" SELECT page_id, page_name, page_liked_id, page_liked_name, page_liked_img, localImagePath "
					+ " FROM fb_page_top_fan "
					+ " WHERE page_id='"+fbInputVo.getUserFilter()+"' ";
			System.out.println("fb_page_top_fan: "+query);

			rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				Fb_groupVo fbOutputVo=new Fb_groupVo();
				fbOutputVo.setUser_id(rs.get("page_id")==null?"":rs.get("page_id").toString());								
				fbOutputVo.setUser_name(rs.get("page_name")==null?"":rs.get("page_name").toString());
				fbOutputVo.setGp_Id(rs.get("page_liked_id")==null?"":rs.get("page_liked_id").toString());
				fbOutputVo.setGp_name(rs.get("page_liked_name")==null?"":rs.get("page_liked_name").toString());
				fbOutputVo.setGp_photo(rs.get("page_liked_img")==null?"":rs.get("page_liked_img").toString());
				fbOutputVo.setLocalImgName(rs.get("localImagePath")==null?"":rs.get("localImagePath").toString());
				fbOutputVo.setAbsPathLocal(TwitterConstant.getFacebookLocalImageUrl());
				list.add(fbOutputVo);
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		} 
		return list;
	}



	//==================FB GROUP RPT======================================//
	
	public ArrayList<TwitterVo> fbGroupBasicInfoRpt(TweeterActionVo fbInputVo) 
	{
		ArrayList<TwitterVo> list = new ArrayList<TwitterVo>();
		List<Map<String, Object>> rows = null;
		try 
		{
			String selectQuery = " SELECT fb_group_id, fb_group_name, about, creation_date, "
					+ " groupLocation, totalMemberCount, group_cover_pic, user_cover_local "
					+ " FROM fb_scrap_group_about "
					+ " WHERE fb_group_id='"+fbInputVo.getUserIdFilter()+"' "; 
			System.out.println("fbGroupBasicInfoRpt: "+selectQuery);

			rows = jdbcTemplate.queryForList(selectQuery);
			for(Map<String,Object> rs :rows)
			{
				TwitterVo twitterVo = new TwitterVo();
				twitterVo.setUserId(rs.get("fb_group_id")==null?"":rs.get("fb_group_id").toString());
				twitterVo.setUserName(rs.get("fb_group_name")==null?"":rs.get("fb_group_name").toString());
				twitterVo.setDescription(rs.get("about")==null?"":rs.get("about").toString());
				twitterVo.setCreationDate(rs.get("creation_date")==null?"":rs.get("creation_date").toString());
				
				twitterVo.setLocation(rs.get("about")==null?"":rs.get("about").toString());
				twitterVo.setCount(rs.get("about")==null?"":rs.get("about").toString());
				
				twitterVo.setArticleAuthorImage(rs.get("group_cover_pic")==null?"":rs.get("group_cover_pic").toString());
				twitterVo.setCoverLocalImage(rs.get("user_cover_local")==null?"":rs.get("user_cover_local").toString());
				twitterVo.setAbsPathLocal(TwitterConstant.getFacebookLocalImageUrl());
				list.add(twitterVo);
			}
		} 
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return list;
	}

	
	public ArrayList<TwitterVo> fbGroupMediaImageRpt(TweeterActionVo fbInputVo) 
	{
		ArrayList<TwitterVo> list = new ArrayList<TwitterVo>();
		List<Map<String, Object>> rows = null;
		try 
		{
			String selectQuery = " SELECT fb_user_id, user_photo_url, user_post_url, localImagePath "
					+ " FROM fb_scrap_user_photo "
					+ " WHERE fb_user_id='"+fbInputVo.getUserIdFilter()+"' "; 
			System.out.println("fbGroupMediaImageRpt: "+selectQuery);

			rows = jdbcTemplate.queryForList(selectQuery);
			for(Map<String,Object> rs :rows)
			{
				TwitterVo twitterVo = new TwitterVo();
				twitterVo.setUserId(rs.get("fb_user_id")==null?"":rs.get("fb_user_id").toString());
				twitterVo.setArticleAuthorImage(rs.get("user_photo_url")==null?"":rs.get("user_photo_url").toString());
				twitterVo.setLink(rs.get("user_post_url")==null?"":rs.get("user_post_url").toString());
				twitterVo.setMediaLocalImage(rs.get("localImagePath")==null?"":rs.get("localImagePath").toString());
				twitterVo.setFacebookLocalImageUrl(TwitterConstant.getFacebookLocalImageUrl());
				list.add(twitterVo);
			}
		} 
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return list;
	}

	
	public ArrayList<TwitterVo> fbGroupMediaVideoRpt(TweeterActionVo fbInputVo) 
	{
		ArrayList<TwitterVo> list = new ArrayList<TwitterVo>();
		List<Map<String, Object>> rows = null;
		try 
		{
			String selectQuery = " SELECT fb_user_id, video_thumnail, video_url, localImagePath "
					+ " FROM fb_scrap_user_video "
					+ " WHERE fb_user_id='"+fbInputVo.getUserIdFilter()+"' "; 
			System.out.println("fbGroupMediaVideoRpt: "+selectQuery);

			rows = jdbcTemplate.queryForList(selectQuery);
			for(Map<String,Object> rs :rows)
			{
				TwitterVo twitterVo = new TwitterVo();
				twitterVo.setUserId(rs.get("fb_user_id")==null?"":rs.get("fb_user_id").toString());
				twitterVo.setArticleAuthorImage(rs.get("video_thumnail")==null?"":rs.get("video_thumnail").toString());
				twitterVo.setLink(rs.get("video_url")==null?"":rs.get("video_url").toString());
				twitterVo.setMediaLocalImage(rs.get("localImagePath")==null?"":rs.get("localImagePath").toString());
				twitterVo.setFacebookLocalImageUrl(TwitterConstant.getFacebookLocalImageUrl());
				list.add(twitterVo);
			}
		} 
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return list;
	}

	
	public ArrayList<Fb_groupVo> fbGroupTopMostUserStrongConnection(TweeterActionVo fbInputVo) 
	{
		ArrayList<Fb_groupVo> list=new ArrayList<Fb_groupVo>();
		List<Map<String,Object>> rows=null;
		try
		{
			String query =" SELECT friend_user_id, friend_user_name, friend_user_display_name, "
					    + " friend_user_img, COUNT(*) AS cnt, localImagePath  "
					    + " FROM fb_post_like_comment_user "
					    + " WHERE fb_user_id='"+fbInputVo.getUserFilter()+"' "
					    //+ " OR fb_user_id='"+fbInputVo.getUserName()+"' "
					    + " GROUP BY friend_user_id "
					    + " ORDER BY cnt DESC LIMIT 200  ";

			System.out.println("fbGroupTopMostUserStrongConnection: "+query);

			rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				Fb_groupVo fbGroupVo=new Fb_groupVo();
				fbGroupVo.setGp_Id(rs.get("friend_user_id")==null?"":rs.get("friend_user_id").toString());
				fbGroupVo.setGp_memebers(rs.get("friend_user_name")==null?"":rs.get("friend_user_name").toString());
				fbGroupVo.setGp_name(rs.get("friend_user_display_name")==null?"":rs.get("friend_user_display_name").toString());
				fbGroupVo.setGp_photo(rs.get("friend_user_img")==null?"":rs.get("friend_user_img").toString());
				fbGroupVo.setCount(Integer.parseInt(rs.get("cnt").toString()));
				fbGroupVo.setLocalImgName(rs.get("localImagePath")==null?"":rs.get("localImagePath").toString());
				//fbGroupVo.setLocalLargeImgName(rs.get("fbUserLargeImage")==null?"":rs.get("fbUserLargeImage").toString());
				fbGroupVo.setAbsPathLocal(TwitterConstant.getFacebookLocalImageUrl());
				list.add(fbGroupVo);
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		} 
		return list;
	}

	
	public ArrayList<Fb_groupVo> fbGroupAllMembersRpt(TweeterActionVo fbInputVo) 
	{
		ArrayList<Fb_groupVo> list=new ArrayList<Fb_groupVo>();
		List<Map<String,Object>> rows=null;
		try
		{
			String query=" SELECT friendsAll_userId, friendsAll_userName, friend_photo, localImagePath "
					+ " FROM fb_scrap_user_friends "
					+ " WHERE fb_userId='"+fbInputVo.getUserFilter()+"' ";
			System.out.println("fbGroupAllMembersRpt: "+query);

			rows = jdbcTemplate.queryForList(query);
			for(Map<String, Object> rs :rows)
			{
				Fb_groupVo fbGroupVo=new Fb_groupVo();
				fbGroupVo.setGp_Id(rs.get("friendsAll_userId")==null?"":rs.get("friendsAll_userId").toString());
				fbGroupVo.setGp_name(rs.get("friendsAll_userName")==null?"":rs.get("friendsAll_userName").toString());
				fbGroupVo.setGp_photo(rs.get("friend_photo")==null?"":rs.get("friend_photo").toString());
				fbGroupVo.setLocalImgName(rs.get("localImagePath")==null?"":rs.get("localImagePath").toString());
				fbGroupVo.setAbsPathLocal(TwitterConstant.getFacebookLocalImageUrl());
				list.add(fbGroupVo);
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		} 
		return list;
	}

	
	public ArrayList<Fb_groupVo> fbGroupNewMembersRpt(TweeterActionVo fbInputVo) 
	{
		ArrayList<Fb_groupVo> list=new ArrayList<Fb_groupVo>();
		List<Map<String,Object>> rows=null;
		try
		{
			String query=" SELECT friendsAll_userId, friendsAll_userName, friend_photo, localImagePath "
					+ " FROM fb_scrap_user_friends "
					+ " WHERE fb_userId='"+fbInputVo.getUserFilter()+"' ";
			System.out.println("fbGroupNewMembersRpt: "+query);

			rows = jdbcTemplate.queryForList(query);
			for(Map<String, Object> rs :rows)
			{
				Fb_groupVo fbGroupVo=new Fb_groupVo();
				fbGroupVo.setGp_Id(rs.get("friendsAll_userId")==null?"":rs.get("friendsAll_userId").toString());
				fbGroupVo.setGp_name(rs.get("friendsAll_userName")==null?"":rs.get("friendsAll_userName").toString());
				fbGroupVo.setGp_photo(rs.get("friend_photo")==null?"":rs.get("friend_photo").toString());
				fbGroupVo.setLocalImgName(rs.get("localImagePath")==null?"":rs.get("localImagePath").toString());
				fbGroupVo.setAbsPathLocal(TwitterConstant.getFacebookLocalImageUrl());
				list.add(fbGroupVo);
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		} 
		return list;
	}

	
	
	public ArrayList<Fb_groupVo> fbGroupEventsRpt(TweeterActionVo fbInputVo) 
	{
		ArrayList<Fb_groupVo> list=new ArrayList<Fb_groupVo>();
		List<Map<String,Object>> rows=null;
		try
		{
			String query=" SELECT friendsAll_userId, friendsAll_userName, friend_photo, localImagePath "
					+ " FROM fb_scrap_user_friends "
					+ " WHERE fb_userId='"+fbInputVo.getUserFilter()+"' ";
			System.out.println("fbGroupEventsRpt: "+query);

			rows = jdbcTemplate.queryForList(query);
			/*for(Map<String, Object> rs :rows)
			{
				Fb_groupVo fbGroupVo=new Fb_groupVo();
				fbGroupVo.setGp_Id(rs.get("friendsAll_userId")==null?"":rs.get("friendsAll_userId").toString());
				fbGroupVo.setGp_name(rs.get("friendsAll_userName")==null?"":rs.get("friendsAll_userName").toString());
				fbGroupVo.setGp_photo(rs.get("friend_photo")==null?"":rs.get("friend_photo").toString());
				fbGroupVo.setLocalImgName(rs.get("localImagePath")==null?"":rs.get("localImagePath").toString());
				fbGroupVo.setAbsPathLocal(TwitterConstant.getFacebookLocalImageUrl());
				list.add(fbGroupVo);
			}*/
			
			
			/*Fb_groupVo fbGroupVo=new Fb_groupVo();
			fbGroupVo.setGp_name(rs.get("liked_screenName")==null?"":rs.get("liked_screenName").toString());
			fbGroupVo.setGp_memebers(rs.get("liked_user_profession")==null?"":rs.get("liked_user_profession").toString());
			fbGroupVo.setGp_photo(rs.get("liked_user_img")==null?"":rs.get("liked_user_img").toString());
			fbGroupVo.setGp_Id(rs.get("liked_userId")==null?"":rs.get("liked_userId").toString());
			fbGroupVo.setLocalImgName(rs.get("localImagePath")==null?"":rs.get("localImagePath").toString());
			lst.add(fbGroupVo);*/
			
			Fb_groupVo fbGroupVo=new Fb_groupVo();
			fbGroupVo.setGp_name("मिशन राम मंदिर निर्माण");
			fbGroupVo.setCreationDate("MON, MAY 27, 2019");;
			fbGroupVo.setGp_photo(":https://scontent.fdel3-1.fna.fbcdn.net/v/t1.6435-0/s206x206/61565934_2477021962329617_426536182873063424_n.jpg?_nc_cat=100&ccb=1-3&_nc_sid=340051&_nc_ohc=7SIKSfn_vCMAX9GU-Z6&_nc_ht=scontent.fdel3-1.fna&tp=7&oh=76d0990a79aa4027c5029bc70af155ac&oe=60C27AA6");
			fbGroupVo.setGp_memebers("Lalit Kaushik");
			fbGroupVo.setGp_memebers_image(":https://scontent.fdel3-1.fna.fbcdn.net/v/t1.6435-1/cp0/p24x24/38451006_2037273706304447_8152750463645646848_n.jpg?_nc_cat=104&ccb=1-3&_nc_sid=7206a8&_nc_ohc=sPtWeUNJR0MAX9TrdMN&_nc_ht=scontent.fdel3-1.fna&tp=27&oh=c95a6312f7dd88b73b7f395b34b1e2ee&oe=60C21754");
			list.add(fbGroupVo);
			
			fbGroupVo=new Fb_groupVo();
			fbGroupVo.setGp_name("मिशन राम मंदिर निर्माण");
			fbGroupVo.setCreationDate("MON, MAY 27, 2019");;
			fbGroupVo.setGp_photo(":https://scontent.fdel3-1.fna.fbcdn.net/v/t1.6435-0/s206x206/61565934_2477021962329617_426536182873063424_n.jpg?_nc_cat=100&ccb=1-3&_nc_sid=340051&_nc_ohc=7SIKSfn_vCMAX9GU-Z6&_nc_ht=scontent.fdel3-1.fna&tp=7&oh=76d0990a79aa4027c5029bc70af155ac&oe=60C27AA6");
			fbGroupVo.setGp_memebers("Lalit Kaushik");
			fbGroupVo.setGp_memebers_image(":https://scontent.fdel3-1.fna.fbcdn.net/v/t1.6435-1/cp0/p24x24/38451006_2037273706304447_8152750463645646848_n.jpg?_nc_cat=104&ccb=1-3&_nc_sid=7206a8&_nc_ohc=sPtWeUNJR0MAX9TrdMN&_nc_ht=scontent.fdel3-1.fna&tp=27&oh=c95a6312f7dd88b73b7f395b34b1e2ee&oe=60C21754");
			list.add(fbGroupVo);
			
			fbGroupVo=new Fb_groupVo();
			fbGroupVo.setGp_name("मिशन राम मंदिर निर्माण");
			fbGroupVo.setCreationDate("MON, MAY 27, 2019");;
			fbGroupVo.setGp_photo(":https://scontent.fdel3-1.fna.fbcdn.net/v/t1.6435-0/s206x206/61565934_2477021962329617_426536182873063424_n.jpg?_nc_cat=100&ccb=1-3&_nc_sid=340051&_nc_ohc=7SIKSfn_vCMAX9GU-Z6&_nc_ht=scontent.fdel3-1.fna&tp=7&oh=76d0990a79aa4027c5029bc70af155ac&oe=60C27AA6");
			fbGroupVo.setGp_memebers("Lalit Kaushik");
			fbGroupVo.setGp_memebers_image(":https://scontent.fdel3-1.fna.fbcdn.net/v/t1.6435-1/cp0/p24x24/38451006_2037273706304447_8152750463645646848_n.jpg?_nc_cat=104&ccb=1-3&_nc_sid=7206a8&_nc_ohc=sPtWeUNJR0MAX9TrdMN&_nc_ht=scontent.fdel3-1.fna&tp=27&oh=c95a6312f7dd88b73b7f395b34b1e2ee&oe=60C21754");
			list.add(fbGroupVo);
			
			fbGroupVo=new Fb_groupVo();
			fbGroupVo.setGp_name("मिशन राम मंदिर निर्माण");
			fbGroupVo.setCreationDate("MON, MAY 27, 2019");;
			fbGroupVo.setGp_photo(":https://scontent.fdel3-1.fna.fbcdn.net/v/t1.6435-0/s206x206/61565934_2477021962329617_426536182873063424_n.jpg?_nc_cat=100&ccb=1-3&_nc_sid=340051&_nc_ohc=7SIKSfn_vCMAX9GU-Z6&_nc_ht=scontent.fdel3-1.fna&tp=7&oh=76d0990a79aa4027c5029bc70af155ac&oe=60C27AA6");
			fbGroupVo.setGp_memebers("Lalit Kaushik");
			fbGroupVo.setGp_memebers_image(":https://scontent.fdel3-1.fna.fbcdn.net/v/t1.6435-1/cp0/p24x24/38451006_2037273706304447_8152750463645646848_n.jpg?_nc_cat=104&ccb=1-3&_nc_sid=7206a8&_nc_ohc=sPtWeUNJR0MAX9TrdMN&_nc_ht=scontent.fdel3-1.fna&tp=27&oh=c95a6312f7dd88b73b7f395b34b1e2ee&oe=60C21754");
			list.add(fbGroupVo);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		} 
		return list;
	}
	
	
	
	public ArrayList<Fb_groupVo> fbGroupAllAdminRpt(TweeterActionVo fbInputVo) 
	{
		ArrayList<Fb_groupVo> list=new ArrayList<Fb_groupVo>();
		List<Map<String,Object>> rows=null;
		try
		{
			String query=" SELECT admin_id, admin_name, admin_image, localImagePath "
					+ " FROM fb_scrap_group_admin  "
					+ " WHERE group_id='"+fbInputVo.getUserIdFilter()+"' ";
			System.out.println("fbGroupAllAdminRpt: "+query);

			rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				Fb_groupVo fbGroupVo=new Fb_groupVo();
				fbGroupVo.setGp_Id(rs.get("admin_id")==null?"":rs.get("admin_id").toString());
				fbGroupVo.setGp_name(rs.get("admin_name")==null?"":rs.get("admin_name").toString());
				fbGroupVo.setGp_photo(rs.get("admin_image")==null?"":rs.get("admin_image").toString());
				fbGroupVo.setLocalImgName(rs.get("localImagePath")==null?"":rs.get("localImagePath").toString());
				fbGroupVo.setAbsPathLocal(TwitterConstant.getFacebookLocalImageUrl());
				list.add(fbGroupVo);
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		} 
		return list;
	}

	
	public ArrayList<InnsightTrends> getCitiesForTrends()
	{
		ArrayList<InnsightTrends> innsightTrendsList = new  ArrayList<InnsightTrends>();
		try 
		{
			String query = "{\r\n" + 
					"  \"size\": 0,\r\n" + 
					"  \"aggs\": {\r\n" + 
					"    \"genres\": {\r\n" + 
					"      \"terms\": {\r\n" + 
					"        \"field\": \"city\",\r\n" + 
					"        \"size\": 1000\r\n" + 
					"      }\r\n" + 
					"    }\r\n" + 
					"  }\r\n" + 
					"}";

			System.out.println("getCitiesForTrends**********"+query);
			Search search = new Search.Builder(query)
					.addIndex("innsight_trends")
					.addType("trends_collection")
					.build();
			SearchResult result = client.execute(search);

			TermsAggregation terms = result.getAggregations().getTermsAggregation("genres");
			if(terms !=null)
			{
				List<Entry> entry = terms.getBuckets();
				for(Entry entry2 : entry)
				{
					InnsightTrends innsightTrends = new InnsightTrends();
					innsightTrends.setCity(entry2.getKey());
					innsightTrendsList.add(innsightTrends);
				}
			}
			System.out.println("Size : "+innsightTrendsList.size());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

		return innsightTrendsList;
	}

	
	public ArrayList<InnsightTrends> getTrendsByLocation(InnsightTrends innsightTrends) 
	{
		System.out.println(innsightTrends.getCountry()+"====="+innsightTrends.getCountryCode());
		ArrayList<InnsightTrends> innsightTrendsList = new  ArrayList<InnsightTrends>();
		try
		{
			long dateFrom=TwitterConstant.convertDateToTimeStamp(innsightTrends.getCountry());
			long dateTo=TwitterConstant.convertDateToTimeStamp(innsightTrends.getCountryCode());

			String subQuery = ",{\n"+
					"\"range\": {\n"+
					"\"insertedDate\": {\n"+
					"\"from\": "+dateFrom+",\n"+
					"\"to\": "+dateTo+"\n"+
					"}\n"+
					"}\n"+
					"}\n";

			String query="{\r\n" + 
					"  \"from\": 0,\r\n" + 
					"  \"size\": 50,\r\n" + 
					"  \"query\": {\r\n" + 
					"    \"bool\": {\r\n" + 
					"      \"must\": [\r\n" + 
					"        {\r\n" + 
					"          \"term\": {\r\n" + 
					"            \"city\": \""+innsightTrends.getCity()+"\"\r\n" + 
					"          }\r\n" + 
					"        },\r\n" + 
					"        {\r\n" + 
					"          \"term\": {\r\n" + 
					"            \"countryCode\": \"in\"\r\n" + 
					"          }\r\n" + 
					"        }\r\n" +
					subQuery +					 
					"      ]\r\n" + 
					"    }\r\n" + 
					"  },\r\n" + 
					"  \"sort\": [\r\n" + 
					"    {\r\n" + 
					"      \"insertedDate\": \"desc\"\r\n" + 
					"    }"+
					
				   /*	+ ",\r\n" + 
					"    {\r\n" + 
					"      \"tweetVolume\": \"desc\"\r\n" + 
					"    }\r\n" +
					*/
					
					
					"  ]\r\n" + 
					"}";

			System.out.println("getTrendsByLocation**********   "+query);
			Search search = new Search.Builder(query)
					.addIndex("innsight_trends")
					.addType("trends_collection")
					.build();
			
			SearchResult result = client.execute(search);
			List<InnsightTrends> innsightTrendsList2 = result.getSourceAsObjectList(InnsightTrends.class);

			for(InnsightTrends innsightTrends2 : innsightTrendsList2) 
			{
				InnsightTrends innsightTrends3 = innsightTrends2;
				innsightTrends3.setCountry(CommonUtils.convertUnixTimeToDate_dd_mm_yyyy((innsightTrends2.getInsertedDate())));
				innsightTrendsList.add(innsightTrends3);
			}
			System.out.println("Size : "+innsightTrendsList.size());

		} 
		catch(Exception ex) 
		{
			ex.printStackTrace();
		} 
		return innsightTrendsList;
	}

	
	
	public TwitterVo updateTweetRealTimeByTweetId(TweeterActionVo tweeterActionVo)
	{
		TwitterVo twitterVo=new TwitterVo();
		try
		{
			ConfigurationBuilder cb = new ConfigurationBuilder();
			cb.setDebugEnabled(true)
			.setOAuthConsumerKey(TwitterConstant.getTwitterConsumerKey())
			.setOAuthConsumerSecret(TwitterConstant.getTwitterConsumerSecret())
			.setOAuthAccessToken(TwitterConstant.getTwitterAccessToken())
			.setOAuthAccessTokenSecret(TwitterConstant.getTwitterAccessTokenSecret());
			TwitterFactory tf = new TwitterFactory(cb.build());
			Twitter twitter = tf.getInstance();

			if(tweeterActionVo.getTweetId() !=null && !tweeterActionVo.getTweetId().trim().isEmpty())
			{
				long[] id = {Long.parseLong(tweeterActionVo.getTweetId().trim())};
				ResponseList<Status> lst=	twitter.lookup(id);
				for(Status status : lst)
				{
					long originalTweetId=status.getId();				
					twitterVo.setRetweetCount(Integer.toString(status.getRetweetCount()));
					twitterVo.setFavouritesCount(Integer.toString(status.getFavoriteCount()));
					twitterVo.setUserCount(Integer.toString(status.getUser().getStatusesCount()));
					twitterVo.setFollowersCount(Integer.toString(status.getUser().getFollowersCount()));
					twitterVo.setFriendsCount(Integer.toString(status.getUser().getFriendsCount()));
					

					if(status.getRetweetedStatus()!=null)
					{
						originalTweetId=status.getRetweetedStatus().getId();
						twitterVo.setRetweetCount(Integer.toString(status.getRetweetedStatus().getRetweetCount()));
						twitterVo.setFavouritesCount(Integer.toString(status.getRetweetedStatus().getFavoriteCount()));
						twitterVo.setImpressionCount(Integer.toString(status.getRetweetedStatus().getRetweetCount() + status.getRetweetedStatus().getFavoriteCount()));
	
						//Update Original Tweet 
						String script = "" +
								"\"script\" : {\n"+
								"\"inline\": \"ctx._source.tweet.tweetRetweetCount=tweetRetweetCount;ctx._source.tweet.tweetFavouriteCount=tweetFavouriteCount;ctx._source.tweet.tweetImpressionCount=tweetImpressionCount;"
								+ " ctx._source.tweet.tweetUser.tweetUserStatusCount=tweetUserStatusCount;ctx._source.tweet.tweetUser.tweetUserFollowersCount=tweetUserFollowersCount;ctx._source.tweet.tweetUser.tweetUserFriendsCount=tweetUserFriendsCount;\",\n"+
								"\"params\" : {\n"+
								" \"tweetRetweetCount\" : "+twitterVo.getRetweetCount()+",\n" +
								" \"tweetFavouriteCount\" : "+twitterVo.getFavouritesCount()+",\n" +																
                                " \"tweetImpressionCount\" : "+twitterVo.getImpressionCount()+",\n" +
								" \"tweetUserStatusCount\" : "+status.getRetweetedStatus().getUser().getStatusesCount()+",\n" +
								" \"tweetUserFollowersCount\" : "+status.getRetweetedStatus().getUser().getFollowersCount()+",\n" +
								" \"tweetUserFriendsCount\" : "+status.getRetweetedStatus().getUser().getFriendsCount()+"\n" +
								"}\n"+
								"},\n";

						String updateByQueryStr="{ "+script+" \"query\": {\"term\": {\"articleId\": \""+originalTweetId+"\" }}}";
						System.out.println("update original tweet in Retweet:==== "+updateByQueryStr);
						UpdateByQuery updateByQuery = new UpdateByQuery.Builder(updateByQueryStr).addIndex(TwitterConstant.getDbname()).addType(TwitterConstant.getTypeName()).build();
						client.execute(updateByQuery);
					}
				
					//Update Original Tweet / Retweet
					twitterVo.setImpressionCount(Integer.toString(Integer.parseInt(twitterVo.getRetweetCount())+Integer.parseInt(twitterVo.getFavouritesCount())));					
					String script = "" +
							"\"script\" : {\n"+
							"\"inline\": \"ctx._source.tweet.tweetRetweetCount=tweetRetweetCount;ctx._source.tweet.tweetFavouriteCount=tweetFavouriteCount;ctx._source.tweet.tweetImpressionCount=tweetImpressionCount;"
							+ " ctx._source.tweet.tweetUser.tweetUserStatusCount=tweetUserStatusCount;ctx._source.tweet.tweetUser.tweetUserFollowersCount=tweetUserFollowersCount;ctx._source.tweet.tweetUser.tweetUserFriendsCount=tweetUserFriendsCount;\",\n"+
							"\"params\" : {\n"+
							" \"tweetRetweetCount\" : "+twitterVo.getRetweetCount()+",\n" +
							" \"tweetFavouriteCount\" : "+twitterVo.getFavouritesCount()+",\n" +														
                            " \"tweetImpressionCount\" : "+twitterVo.getImpressionCount()+",\n" +
							" \"tweetUserStatusCount\" : "+status.getUser().getStatusesCount()+",\n" +
							" \"tweetUserFollowersCount\" : "+status.getUser().getFollowersCount()+",\n" +
							" \"tweetUserFriendsCount\" : "+status.getUser().getFriendsCount()+"\n" +
							"}\n"+
							"},\n";

					String updateByQueryStr="{ "+script+" \"query\": {\"term\": {\"articleId\": \""+tweeterActionVo.getTweetId()+"\" }}}";
					System.out.println("update original tweet::::"+updateByQueryStr);
					try {
						UpdateByQuery updateByQuery = new UpdateByQuery.Builder(updateByQueryStr).addIndex(TwitterConstant.getDbname()).addType(TwitterConstant.getTypeName()).build();
						client.execute(updateByQuery);
					} catch(IOException ex) {
						ex.printStackTrace();
					}

					//Update all reweets of tweet
					script = "" +
							"\"script\" : {\n"+
							"\"inline\": \"ctx._source.tweet.tweetRetweetCount=tweetRetweetCount;ctx._source.tweet.tweetFavouriteCount=tweetFavouriteCount;ctx._source.tweet.tweetImpressionCount=tweetImpressionCount;"
							+ "\",\n"+
							"\"params\" : {\n"+
							" \"tweetRetweetCount\" : "+twitterVo.getRetweetCount()+", \n" +
							" \"tweetFavouriteCount\" : "+twitterVo.getFavouritesCount()+", \n" +														
                            " \"tweetImpressionCount\" : "+twitterVo.getImpressionCount()+" \n" +																			
							"}\n"+
							"},\n";

					updateByQueryStr="{ "+script+" \"query\": {\"term\": {\"tweet.tweetRetweetSourceId\": \""+originalTweetId+"\" }}}";
					System.out.println("update all retweet of original tweet:====== "+updateByQueryStr);
						UpdateByQuery updateByQuery = new UpdateByQuery.Builder(updateByQueryStr)
								.addIndex(TwitterConstant.getDbname())
								.addType(TwitterConstant.getTypeName())
								.build();
						client.execute(updateByQuery);
				}
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return twitterVo;
	}

	
	public LinkedHashMap<String, ArrayList<TwitterTrendsVo>> timelineChipsTrends(TweeterActionVo tweeterActionVo) 
    {
		LinkedHashMap<String, ArrayList<TwitterTrendsVo>> sortedMap = new LinkedHashMap<String, ArrayList<TwitterTrendsVo>>();
		LinkedHashMap<String, ArrayList<TwitterTrendsVo>> map = new LinkedHashMap<String, ArrayList<TwitterTrendsVo>>();
		try
		{
			String interval="day";
			String fieldName="";
			switch (tweeterActionVo.getType()) 
			{
			case "hashtag":
				fieldName="articleHashTag";
				interval=tweeterActionVo.getTimeFilter();
				break;
			case "user":
				fieldName="articleAuthor";
				break;
			case "mention":
				fieldName="articleMention";
				break;
			case "theme":
				fieldName="articleThemes";
				break;
			case "classification":
				fieldName="articleClassification";
				break;
			case "articletype":
				fieldName="articleType";
				break;
			case "place":
				fieldName="articleLocationNer.keyword";
				break;
			case "person":
				fieldName="articlePersonNer.keyword";
				interval=tweeterActionVo.getTimeFilter();
				break;
			case "org":
				fieldName="articleOrganizationNer.keyword";
				break;
			default:
				break;
			}
			String  subQuery=rtnFilterQuery(tweeterActionVo,-1);

			String aggQuery=",\n"+
					"\"aggs\": {\n"+
					"\"sourceType\": {\n"+
					"\"terms\": {\n"+
					"\"field\":\""+fieldName+"\",\n"+
					"\"size\": \"5\"\n"+
					"}\n"+
					",\"aggs\":\n"+
					"{\n"+
					"\"termaggs\":{\n"+
					"\"avg\":{\n"+
					"\"field\":\"articleSentiment\"\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";

			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"dateHistogram\":{\n"+
					"\"date_histogram\":{\n"+
					"\"field\":\"articlePublishDate\",\n"+
					"\"interval\": \""+interval+"\",\n"+
					"\"min_doc_count\": 0,\n"+
					"\"extended_bounds\" : {\n"+ 
					"\"min\" : \""+TwitterConstant.convertStrToDate_yyyy_MM_dd(tweeterActionVo.getDateFrom())+"\",\n"+
					"\"max\" : \""+TwitterConstant.convertStrToDate_yyyy_MM_dd(tweeterActionVo.getDateTo())+"\"\n"+
					"}\n"+
					"}\n"+
					aggQuery+
					"}\n"+
					"}\n"+
					"}\n";
			System.out.println(tweeterActionVo.getType()+" timelineTrends()==== "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			//System.out.println(result.getJsonString());
			JsonObject mainObj=result.getJsonObject();
			
			if(mainObj.has("aggregations"))
			{
				JsonObject  aggObj=mainObj.getAsJsonObject("aggregations");
				if(aggObj.has("dateHistogram"))
				{
					JsonObject  objHistogram=aggObj.getAsJsonObject("dateHistogram");
					if(objHistogram.has("buckets"))
					{
						JsonArray bucketsArryHisto=objHistogram.getAsJsonArray("buckets");
						for (JsonElement jsonElementHisto : bucketsArryHisto)
						{
							if(jsonElementHisto.getAsJsonObject().has("sourceType"))
							{
								JsonObject  sourceTypeObj=jsonElementHisto.getAsJsonObject().get("sourceType").getAsJsonObject();
								if(sourceTypeObj.has("buckets"))
								{
									JsonArray bucketsArry=sourceTypeObj.getAsJsonArray("buckets");
									for (JsonElement jsonElement : bucketsArry) 
									{
										// Hasthag,mention etc
										TwitterTrendsVo twitterVo=new TwitterTrendsVo();
										//date
										twitterVo.setCreatedAt(CommonUtils.convertUnixTimeToDate_yyyy_mm_dd(jsonElementHisto.getAsJsonObject().get("key").getAsLong()));
										//Source Type
										//twitterVo.setType(jsonElement.getAsJsonObject().get("key").getAsString());
										twitterVo.setHashtag(jsonElement.getAsJsonObject().get("key").getAsString());
										//Source Type Document Count
										twitterVo.setCount(jsonElement.getAsJsonObject().get("doc_count").getAsString());
										twitterVo.setType("neutral");
										if(jsonElement.getAsJsonObject().has("termaggs"))
										{
											JsonObject obj=	jsonElement.getAsJsonObject().get("termaggs").getAsJsonObject();
											if(obj.get("value").getAsFloat()>0)
											{
												twitterVo.setType("positive");
											}
											else if(obj.get("value").getAsFloat()==0)
											{
												twitterVo.setType("neutral");
											}
											else if(obj.get("value").getAsFloat()<0)
											{
												twitterVo.setType("negative");
											}
										}
										if(map.containsKey(twitterVo.getCreatedAt())) {
											ArrayList<TwitterTrendsVo> twitterVoList = map.get(twitterVo.getCreatedAt());
											twitterVoList.add(twitterVo);
											map.put(twitterVo.getCreatedAt(), twitterVoList);
										} else {
											ArrayList<TwitterTrendsVo> twitterVoList = new ArrayList<TwitterTrendsVo>();
											twitterVoList.add(twitterVo);
											map.put(twitterVo.getCreatedAt(), twitterVoList);
										}
									}
								}
							}							
						}					
					}			
				}
			}
			if(tweeterActionVo.getUserSortFilter().equals("asc")){
				//ascending
				sortedMap.putAll(map);
			} else {
				//descending
				map.entrySet().stream().sorted(Collections.reverseOrder(Map.Entry.comparingByKey())).forEachOrdered(entry -> sortedMap.put(entry.getKey(), entry.getValue()));
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return sortedMap;
	}


	
	public Long getTweetReach(String tweetId) {
		
		Long totalReach=0l;
		
		String query ="{\r\n" + 
					  "  \"size\": 1,\r\n" + 
					  "  \"query\": {\r\n" + 
					  "    \"term\": {\r\n" + 
					  "      \"articleId\": \""+tweetId+"\"\r\n" + 
					  "    }\r\n" + 
					  "  },\r\n" + 
					  "  \"sort\": [\r\n" + 
					  "    {\r\n" + 
					  "      \"articleInsertedDate\": {\r\n" + 
					  "        \"order\": \"desc\"\r\n" + 
					  "      }\r\n" + 
					  "    }\r\n" + 
					  "  ]\r\n" + 
					  "}";
		System.out.println("getTweetReach 1::::"+query);
		try{
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();
			SearchResult result = client.execute(search);
			List<Article_Datacollection_New> testLst = result.getSourceAsObjectList(Article_Datacollection_New.class);
                 if(testLst.size()>0)
                 {
                     totalReach=totalReach + Long.valueOf(testLst.get(0).getTweet().getTweetUser().getTweetUserFollowersCount());                  	 
                 }
		}
		catch(Exception ex){
			ex.printStackTrace();
		}

		query="{\r\n" + 
				"  \"query\": {\r\n" + 
				"    \"term\": {\r\n" + 
				"      \"tweet.tweetRetweetSourceId\": \""+tweetId+"\"\r\n" + 
				"    }\r\n" + 
				"  },\r\n" + 
				"  \"aggs\": {\r\n" + 
				"    \"totalReach\": {\r\n" + 
				"      \"sum\": {\r\n" + 
				"        \"field\": \"tweet.tweetUser.tweetUserFavouriteCount\"\r\n" + 
				"      }\r\n" + 
				"    }\r\n" + 
				"  }\r\n" + 
				"}";

		System.out.println("getTweetReach::::"+query);
		try{
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();
			SearchResult result = client.execute(search);
			SumAggregation aggrega = result.getAggregations().getSumAggregation("totalReach");
			if(aggrega !=null) 
			{
				Double d = aggrega.getSum();
				totalReach =totalReach + (new Double(d)).longValue();
			}
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		return totalReach;
	}


	
	public ArrayList<ArticleDataExportVo> exportFBProfilePostJsonDataReport(TweeterActionVo tweeterActionVo) 
	{				
		ArrayList<ArticleDataExportVo> dataList = new ArrayList<ArticleDataExportVo>();
		try 
		{
			int from=0;
			int size=1000;
						
			String subQuery = rtnFilterQuery(tweeterActionVo, -1);
			String query="{\n"
					+ "      \"from\":"+from+",\n"
					+ "      \"size\":"+size+",\n"
					+subQuery+
					getTweetsSortOrder(tweeterActionVo)
					+getHighlightFields()
					+ "}\n";

			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			System.out.println("exportFBProfilePostJsonDataReport: "+query);

			List<Article_Datacollection_New> testLst = result.getSourceAsObjectList(Article_Datacollection_New.class);
			for(Article_Datacollection_New article_Datacollection_New : testLst) 
			{
				 ArticleDataExportVo article = new ArticleDataExportVo();
				 article.setArticleId(article_Datacollection_New.getArticleId());
				 article.setArticleEmotion(article_Datacollection_New.getArticleEmotion());
				 article.setArticleSource(article_Datacollection_New.getArticleSource());
				 article.setArticleType(article_Datacollection_New.getArticleType());
				 article.setArticleTitle(article_Datacollection_New.getArticleTitle());
				 article.setArticleSubTitle(article_Datacollection_New.getArticleSubTitle());
				 article.setArticleBigContent(article_Datacollection_New.getArticleBigContent());
				 article.setArticleAuthor(article_Datacollection_New.getArticleAuthor());
				 article.setArticleAuthorId(article_Datacollection_New.getArticleAuthorId());
				 article.setArticleAuthorGender(article_Datacollection_New.getArticleAuthorGender());
				 article.setArticleAuthorReligion(article_Datacollection_New.getArticleAuthorReligion());
				 article.setArticleAuthorImage(article_Datacollection_New.getArticleAuthorImage());
				 article.setArticleLanguage(article_Datacollection_New.getArticleLanguage());
				 article.setArticleSentiment(Integer.toString(article_Datacollection_New.getArticleSentiment()));
				 String strDate=Long.toString(article_Datacollection_New.getArticlePublishDate());
				 //strDate=strDate.substring(0, 10);				 
				 article.setArticlePublishDate(Long.parseLong(strDate));
				 
				 /*article.setArticleAuthorImageUrlLocal(article_Datacollection_New.getArticleAuthorImageUrlLocal());
				 article.setArticleLocation(article_Datacollection_New.getArticleLocation());
				 article.setArticleLocationCity(article_Datacollection_New.getArticleLocationCity());
				 article.setArticleLocationCountry(article_Datacollection_New.getArticleLocationCountry());
				 article.setArticleLocationCountryCode(article_Datacollection_New.getArticleLocationCountryCode());
				 article.setArticleUserLocation(article_Datacollection_New.getArticleUserLocation());				 
				 article.setArticleUserLocationName(article_Datacollection_New.getArticleUserLocationName());
				 article.setArticleUserLocationCountry(article_Datacollection_New.getArticleUserLocationCountry());
				 article.setArticleUserLocationCountryCode(article_Datacollection_New.getArticleUserLocationCountryCode());
				 article.setArticleLocationPlace(article_Datacollection_New.getArticleLocationPlace());
				 */
								 					 
				 article.setArticleHashTag(article_Datacollection_New.getArticleHashTag());
				 article.setArticleMention(article_Datacollection_New.getArticleMention());
				 article.setArticleThemes(article_Datacollection_New.getArticleThemes());
				 article.setArticleClassification(article_Datacollection_New.getArticleClassification());
				 article.setArticleMobile(article_Datacollection_New.getArticleMobile());
				 article.setArticleEmail(article_Datacollection_New.getArticleEmail());
				 article.setArticleIp(article_Datacollection_New.getArticleIp());
				 article.setArticlePinCode(article_Datacollection_New.getArticlePinCode());
				 article.setVehicleNo(article_Datacollection_New.getVehicleNo());
				 article.setMobileImeiNo(article_Datacollection_New.getMobileImeiNo());
				 article.setArticleTimeNer(article_Datacollection_New.getArticleTimeNer());
				 article.setDebitCreditCardNo(article_Datacollection_New.getDebitCreditCardNo());
				 article.setBankAccountNo(article_Datacollection_New.getBankAccountNo());
				 article.setTaxonomy(article_Datacollection_New.getTaxonomy());
				 
				 //article.setPostImageOds(article_Datacollection_New.getPostImageOds());
				 //article.setPostImageOcrAggs(article_Datacollection_New.getPostImageOcrAggs());
				 //article.setPostImageFrs(article_Datacollection_New.getPostImageFrs());
				 //article.setArticleMedia(article_Datacollection_New.getArticleMedia());
				 
				 article.setArticlePersonNer(article_Datacollection_New.getArticlePersonNer());
				 article.setArticleOrganizationNer(article_Datacollection_New.getArticleOrganizationNer());
				 article.setArticleLocationNer(article_Datacollection_New.getArticleLocationNer());	
				 article.setArticleEvent(article_Datacollection_New.getArticleEvent());
				 article.setArticleDateNer(article_Datacollection_New.getArticleDateNer());
								 
				 article.setFbUserId(article_Datacollection_New.getFacebook().getFbPage().getPageId());
				 article.setFbUserName(article_Datacollection_New.getFacebook().getFbPage().getPageName());
				 //article.setFbProfilePicture(article_Datacollection_New.getFacebook().getFbPage().getPagePicture());
				 article.setFbCoverPicture(article_Datacollection_New.getFacebook().getFbPage().getPageCoverSource());
				 article.setFbPageLink(article_Datacollection_New.getFacebook().getFbPage().getPageLink());
				 article.setFbPostShareCount(Integer.toString(article_Datacollection_New.getFacebook().getFbPostShareCount()));
				 article.setFbPostLikeCount(Integer.toString(article_Datacollection_New.getFacebook().getFbPostLikeCount()));
				 article.setFbPostCommentCount(Integer.toString(article_Datacollection_New.getFacebook().getFbPostCommentCount()));
				 article.setFbPostViewerCount(Integer.toString(article_Datacollection_New.getFacebook().getFbPostViewerCount()));					 
				 dataList.add(article);				 
			}
		} 
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return dataList;
	}


	
	public ArrayList<UserProfileConnectionExportVo> exportFBProfileConnectionJsonDataReport(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<UserProfileConnectionExportVo> connectionList = new ArrayList<UserProfileConnectionExportVo>();
		String facebookType=tweeterActionVo.getFbType();
		String fbType="fbProfile";
		String connectionType="Friend";
		
		switch(facebookType)
		{
		case "profile":
			 fbType="fbProfile";
			 connectionType="Friend";
			 break;
		case "page":
			 fbType="fbPage";
			 connectionType="Like User";
			 break;
		case "group":
			 fbType="fbGroup";
			 connectionType="Group Member";
			 break;					 
		}
		
		try
		{
			String sql=" SELECT friends.id, fb_userId, fb_username, profile_image_url, friendsAll_userId, friendsAll_userName, friend_photo "
					 + " FROM fb_scrap_user_friends AS friends "
					 + " INNER JOIN collection_profile "
					 + " ON collection_profile.profile_id=friends.fb_userId "
					 + " WHERE source='facebook' AND fb_userId='"+tweeterActionVo.getFbUserProfileFilter()+"' ";
			System.out.println("exportFBProfileConnectionJsonDataReport query: "+sql);		
			List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql);
			
			if(! facebookType.equals("page"))
			{
				if(rows.size() !=0)
			    {
					 for(Map<String, Object> rs : rows)   
					 {
						 UserProfileConnectionExportVo connection = new UserProfileConnectionExportVo();
						 connection.setFbUserId(rs.get("fb_userId")==null?"":rs.get("fb_userId").toString());
						 connection.setFbUserName(rs.get("fb_username")==null?"":rs.get("fb_username").toString());												
						 connection.setFbUserImage(rs.get("profile_image_url")==null?"":rs.get("profile_image_url").toString());
						 connection.setFbUserFriendId(rs.get("friendsAll_userId")==null?"":rs.get("friendsAll_userId").toString());
						 connection.setFbUserFriendName(rs.get("friendsAll_userName")==null?"":rs.get("friendsAll_userName").toString());
						 connection.setFbUserFriendImage(rs.get("friend_photo")==null?"":rs.get("friend_photo").toString());
						 connection.setConnectionType(connectionType);		 
						 connectionList.add(connection);											
					 }																
			     }
			     else
			     {
				     System.out.println("No Post Found Found..");
			     }
			}
									
			//Like Comment Users
		    String sql2=" SELECT likeUser.id, fb_user_id, fb_username, profile_image_url, friend_user_id, friend_user_display_name, friend_user_img, reaction_type "
			          + " FROM fb_post_like_comment_user AS likeUser "
					  + " INNER JOIN collection_profile "
					  + " ON collection_profile.profile_id=likeUser.fb_user_id "
					  + " WHERE source='facebook' AND fb_user_id='"+tweeterActionVo.getFbUserProfileFilter()+"' ";
			log.info("fb_post_like_comment_user query: "+sql2);
			System.out.println("fb_post_like_comment_user query: "+sql2);
			
			List<Map<String, Object>> rows2 = jdbcTemplate.queryForList(sql2);	
			if(rows2.size() !=0)
		    {			 				 
				 for(Map<String, Object> rs : rows2)   
				 {   					
					 UserProfileConnectionExportVo connection = new UserProfileConnectionExportVo();
					 connection.setFbUserId(rs.get("fb_user_id")==null?"":rs.get("fb_user_id").toString());
					 connection.setFbUserName(rs.get("fb_username")==null?"":rs.get("fb_username").toString());												
					 connection.setFbUserImage(rs.get("profile_image_url")==null?"":rs.get("profile_image_url").toString());
					 connection.setFbUserFriendId(rs.get("friend_user_id")==null?"":rs.get("friend_user_id").toString());
					 connection.setFbUserFriendName(rs.get("friend_user_display_name")==null?"":rs.get("friend_user_display_name").toString());
					 connection.setFbUserFriendImage(rs.get("friend_user_img")==null?"":rs.get("friend_user_img").toString());						
					 connection.setConnectionType("Like User");
					 connectionList.add(connection);
				 } 																
		     }
		     else
		     {
			     log.info("No Post Like Comment User Connection Found..");
			     System.out.println("No Post Like Comment User Connection Found..");
		     }
			
			if(facebookType.equals("profile"))
			{
				String query=" SELECT fb_user_id, fb_user_name, profile_image_url, liked_userId, liked_screenName, liked_user_profession, liked_user_img "
						   + " FROM fb_scrap_user_like_detail AS likes "
						   + " INNER JOIN collection_profile "
						   + " ON collection_profile.profile_id=likes.fb_user_id "
						   + " WHERE source='facebook' AND fb_user_id='"+tweeterActionVo.getFbUserProfileFilter()+"' ";
				System.out.println("exportFbLikesReportData: "+query);				
				rows = jdbcTemplate.queryForList(query);
				
				if(rows.size() !=0)
				{
					for(Map<String,Object> rs :rows)
					{
						 UserProfileConnectionExportVo connection = new UserProfileConnectionExportVo();
						 connection.setFbUserId(rs.get("fb_user_id")==null?"":rs.get("fb_user_id").toString());
						 connection.setFbUserName(rs.get("fb_user_name")==null?"":rs.get("fb_user_name").toString());												
						 connection.setFbUserImage(rs.get("profile_image_url")==null?"":rs.get("profile_image_url").toString());
						 connection.setFbUserFriendId(rs.get("liked_userId")==null?"":rs.get("liked_userId").toString());
						 connection.setFbUserFriendName(rs.get("liked_screenName")==null?"":rs.get("liked_screenName").toString());
						 connection.setFbUserFriendProfession(rs.get("liked_user_profession")==null?"":rs.get("liked_user_profession").toString());
						 connection.setFbUserFriendImage(rs.get("liked_user_img")==null?"":rs.get("liked_user_img").toString());						
						 connection.setConnectionType("User Likes");
						 connectionList.add(connection);
					}
				}
								
				query=" SELECT fb_user_id, profile_name, profile_image_url, family_member_id, family_info, member_img, member_rel "
					+ " FROM fb_scrap_profile_family_info AS family "
					+ " INNER JOIN collection_profile "
					+ " ON collection_profile.profile_id=family.fb_user_id "
					+ " WHERE source='facebook' AND fb_user_id='"+tweeterActionVo.getFbUserProfileFilter()+"' ";
					System.out.println("Family member: "+query);
					rows = jdbcTemplate.queryForList(query);
					
					if(rows.size() !=0)
					{
						for(Map<String, Object> rs :rows)
						{
							 UserProfileConnectionExportVo connection = new UserProfileConnectionExportVo();
							 connection.setFbUserId(rs.get("fb_user_id")==null?"":rs.get("fb_user_id").toString());
							 connection.setFbUserName(rs.get("profile_name")==null?"":rs.get("profile_name").toString());												
							 connection.setFbUserImage(rs.get("profile_image_url")==null?"":rs.get("profile_image_url").toString());
							 connection.setFbUserFriendId(rs.get("family_member_id")==null?"":rs.get("family_member_id").toString());
							 connection.setFbUserFriendName(rs.get("family_info")==null?"":rs.get("family_info").toString());
							 connection.setFbUserFriendImage(rs.get("member_img")==null?"":rs.get("member_img").toString());						
							 connection.setConnectionType(rs.get("member_rel")==null?"Family member":rs.get("member_rel").toString());
							 connectionList.add(connection);
						}
					}													
			}
			
			if(facebookType.equals("page"))
			{
				 String sql3=" SELECT likes.id, page_id, page_name, profile_image_url, user_id, user_name, user_image "
						   + " FROM fb_page_liked_by_this_page AS likes "
						   + " INNER JOIN collection_profile "
						   + " ON collection_profile.profile_id=likes.page_id "
						   + " WHERE source='facebook' AND page_id='"+tweeterActionVo.getFbUserProfileFilter()+"' ";				
				 System.out.println("fb_page_liked_by_this_page query: "+sql3);				
				 List<Map<String, Object>> rows3 = jdbcTemplate.queryForList(sql3);	
				 
				 if(rows3.size() !=0)
			     {			 				 
					 for(Map<String, Object> rs : rows3)   
					 {   
						 UserProfileConnectionExportVo connection = new UserProfileConnectionExportVo();
						 connection.setFbUserId(rs.get("page_id")==null?"":rs.get("page_id").toString());
						 connection.setFbUserName(rs.get("page_name")==null?"":rs.get("page_name").toString());												
						 connection.setFbUserImage(rs.get("profile_image_url")==null?"":rs.get("profile_image_url").toString());
						 connection.setFbUserFriendId(rs.get("user_id")==null?"":rs.get("user_id").toString());
						 connection.setFbUserFriendName(rs.get("user_name")==null?"":rs.get("user_name").toString());
						 connection.setFbUserFriendImage(rs.get("user_image")==null?"":rs.get("user_image").toString());						
						 connection.setConnectionType("Pages liked by this Page");
						 connectionList.add(connection);
					 } 																
			     }
			     else
			     {
				     System.out.println("No Pages liked by this Page User Connection Found..");
			     }
				 				 
				 //Pages liked by this Page
				 String sql4=" SELECT page_id, page_name, profile_image_url, page_liked_id, page_liked_name, page_liked_img "
						   + " FROM fb_page_top_fan AS likes "
						   + " INNER JOIN collection_profile "
						   + " ON collection_profile.profile_id=likes.page_id "
						   + " WHERE source='facebook' AND page_id='"+tweeterActionVo.getFbUserProfileFilter()+"' ";				
				 System.out.println("Pages liked by this Page: "+sql4);				
				 List<Map<String, Object>> rows4 = jdbcTemplate.queryForList(sql4);	
				 
				 if(rows4.size() !=0)
			     {			 				 
					 for(Map<String, Object> rs : rows4)   
					 {   
						 UserProfileConnectionExportVo connection = new UserProfileConnectionExportVo();
						 connection.setFbUserId(rs.get("page_id")==null?"":rs.get("page_id").toString());
						 connection.setFbUserName(rs.get("page_name")==null?"":rs.get("page_name").toString());												
						 connection.setFbUserImage(rs.get("profile_image_url")==null?"":rs.get("profile_image_url").toString());
						 connection.setFbUserFriendId(rs.get("page_liked_id")==null?"":rs.get("page_liked_id").toString());
						 connection.setFbUserFriendName(rs.get("page_liked_name")==null?"":rs.get("page_liked_name").toString());
						 connection.setFbUserFriendImage(rs.get("page_liked_img")==null?"":rs.get("page_liked_img").toString());						
						 connection.setConnectionType("Top Fan");
						 connectionList.add(connection);
					 } 																
			     }
			     else
			     {
				     System.out.println("No Top Fan User Connection Found..");
			     }
			}
						
			if(facebookType.equals("group"))
			{	
				 //Group Admin
				 String sql5=" SELECT group_id, group_name, profile_image_url, admin_id, admin_name, admin_image "
						   + " FROM fb_scrap_group_admin AS admin "
						   + " INNER JOIN collection_profile "
						   + " ON collection_profile.profile_id=admin.group_id "
						   + " WHERE source='facebook' AND group_id='"+tweeterActionVo.getFbUserProfileFilter()+"' ";			
				 System.out.println("Group Admin: "+sql5);			
				 List<Map<String, Object>> rows5 = jdbcTemplate.queryForList(sql5);	
				 
				 if(rows5.size() !=0)
			     {			 				 
					 for(Map<String, Object> rs : rows5)   
					 {   
						 UserProfileConnectionExportVo connection = new UserProfileConnectionExportVo();
						 connection.setFbUserId(rs.get("group_id")==null?"":rs.get("group_id").toString());
						 connection.setFbUserName(rs.get("group_name")==null?"":rs.get("group_name").toString());												
						 connection.setFbUserImage(rs.get("profile_image_url")==null?"":rs.get("profile_image_url").toString());
						 connection.setFbUserFriendId(rs.get("admin_id")==null?"":rs.get("admin_id").toString());
						 connection.setFbUserFriendName(rs.get("admin_name")==null?"":rs.get("admin_name").toString());
						 connection.setFbUserFriendImage(rs.get("admin_image")==null?"":rs.get("admin_image").toString());						
						 connection.setConnectionType("Group Admin");
						 connectionList.add(connection);
					 } 																
			     }
			     else
			     {
				     System.out.println("No Group Admin User Connection Found..");
			     }
			 }			
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return connectionList;
	}


	
	public ArrayList<UserProfileExportVo> exportFBBasicInfoJsonDataReport(TweeterActionVo tweeterActionVo)
	{
		ArrayList<UserProfileExportVo> profileList = new ArrayList<UserProfileExportVo>();
		List<Map<String, Object>> rows = null;
		String query="";
		
		//FACEBOOK PROFILE
		if(tweeterActionVo.getFbType().equals("profile"))
		{
			try 
			{
				query=" SELECT fb_user_id, profile_name, profile_overview "
					+ " FROM fb_scrap_profile_overview AS about "
					+ " INNER JOIN collection_profile "
				    + " ON collection_profile.profile_id=about.fb_user_id "
					+ " WHERE source='facebook' AND fb_user_id="+tweeterActionVo.getFbUserProfileFilter()+" ";       
				System.out.println("fb_scrap_profile_overview: "+query);
				rows = jdbcTemplate.queryForList(query);
				for(Map<String, Object> rs :rows) 
				{
					UserProfileExportVo profile = new UserProfileExportVo();
					profile.setFbUserId(rs.get("fb_user_id")==null?"":rs.get("fb_user_id").toString());
					profile.setFbUserName(rs.get("profile_name")==null?"":rs.get("profile_name").toString());
					profile.setInformation(rs.get("profile_overview")==null?"":rs.get("profile_overview").toString());
					profile.setInformationType("Profile Overview");
					profileList.add(profile);
				}

				query=" SELECT user_id, user_name, user_picture, user_cover_photo "
					+ " FROM fb_user "
					+ " WHERE user_id='"+tweeterActionVo.getFbUserProfileFilter()+"' ";
				System.out.println("Profile Image fb_user: "+query);
				rows = jdbcTemplate.queryForList(query);
				for(Map<String, Object> rs :rows)
				{
					UserProfileExportVo profile1 = new UserProfileExportVo();
					profile1.setFbUserId(rs.get("user_id")==null?"":rs.get("user_id").toString());
					profile1.setFbUserName(rs.get("user_name")==null?"":rs.get("user_name").toString());
					profile1.setInformation(rs.get("user_picture")==null?"":rs.get("user_picture").toString());
					profile1.setInformationType("User Profile Image");
					profileList.add(profile1);
					
					UserProfileExportVo profile2 = new UserProfileExportVo();
					profile2.setFbUserId(rs.get("user_id")==null?"":rs.get("user_id").toString());
					profile2.setFbUserName(rs.get("user_name")==null?"":rs.get("user_name").toString());
					profile2.setInformation(rs.get("user_cover_photo")==null?"":rs.get("user_cover_photo").toString());
					profile2.setInformationType("User Cover Image");
					profileList.add(profile2);
				}

				query=" SELECT fb_user_id, profile_name, education_work, edu_type "
					+ " FROM fb_scrap_profile_work_education AS education "
					+ " INNER JOIN collection_profile "
					+ " ON collection_profile.profile_id=education.fb_user_id "
					+ " WHERE source='facebook' AND fb_user_id='"+tweeterActionVo.getFbUserProfileFilter()+"' ";
				System.out.println("Work and education: "+query);
				rows = jdbcTemplate.queryForList(query);  
				for(Map<String, Object> rs :rows)
				{
					String type="";
					if(rs.get("edu_type")!=null)
					{
						if(rs.get("edu_type").toString().equals("0"))
						{
							type="Work";
						}
						else if(rs.get("edu_type").toString().equals("1"))
						{
							type="Education";
						}
					}
					UserProfileExportVo profile = new UserProfileExportVo();
					profile.setFbUserId(rs.get("fb_user_id")==null?"":rs.get("fb_user_id").toString());
					profile.setFbUserName(rs.get("profile_name")==null?"":rs.get("profile_name").toString());
					profile.setInformation(rs.get("education_work")==null?"":rs.get("education_work").toString());
					profile.setInformationType(type);
					profileList.add(profile);
				}

				query=" SELECT fb_user_id, profile_name, place_lived, palce_type "
					+ " FROM fb_scrap_profile_place_lived AS place "
					+ " INNER JOIN collection_profile "
					+ " ON collection_profile.profile_id=place.fb_user_id "
					+ " WHERE source='facebook' AND fb_user_id='"+tweeterActionVo.getFbUserProfileFilter()+"' ";
				System.out.println("place: "+query);
				rows = jdbcTemplate.queryForList(query);			
				for(Map<String, Object> rs :rows)
				{
					String type="";
					if(rs.get("palce_type")!=null)
					{
						if(rs.get("palce_type").toString().equals("0"))
						{
							type="Current City";
						}
						else if(rs.get("palce_type").toString().equals("1"))
						{
							type="Home Town";
						}
					}
					UserProfileExportVo profile = new UserProfileExportVo();
					profile.setFbUserId(rs.get("fb_user_id")==null?"":rs.get("fb_user_id").toString());
					profile.setFbUserName(rs.get("profile_name")==null?"":rs.get("profile_name").toString());
					profile.setInformation(rs.get("place_lived")==null?"":rs.get("place_lived").toString());
					profile.setInformationType(type);
					profileList.add(profile);
				}

				query=" SELECT fb_user_id, profile_name, basic_info, head "
					+ " FROM fb_scrap_profile_contact_info AS contact "
				    + " INNER JOIN collection_profile "
					+ " ON collection_profile.profile_id=contact.fb_user_id "
					+ " WHERE source='facebook' AND fb_user_id='"+tweeterActionVo.getFbUserProfileFilter()+"' ";
				System.out.println("Contact: "+query);
				rows = jdbcTemplate.queryForList(query);			
				for(Map<String, Object> rs :rows)
				{
					UserProfileExportVo profile = new UserProfileExportVo();
					profile.setFbUserId(rs.get("fb_user_id")==null?"":rs.get("fb_user_id").toString());
					profile.setFbUserName(rs.get("profile_name")==null?"":rs.get("profile_name").toString());
					profile.setInformation(rs.get("basic_info")==null?"":rs.get("basic_info").toString());
					profile.setInformationType(rs.get("head")==null?"":rs.get("head").toString());
					profileList.add(profile);
				}

				query=" SELECT fb_user_id, profile_name, family_member_id, family_info, member_rel "
					+ " FROM fb_scrap_profile_family_info AS family "
					+ " INNER JOIN collection_profile "
					+ " ON collection_profile.profile_id=family.fb_user_id "
					+ " WHERE source='facebook' AND fb_user_id='"+tweeterActionVo.getFbUserProfileFilter()+"' ";
				System.out.println("Family member: "+query);
				rows = jdbcTemplate.queryForList(query);
				for(Map<String, Object> rs :rows)
				{
					UserProfileExportVo profile = new UserProfileExportVo();
					profile.setFbUserId(rs.get("fb_user_id")==null?"":rs.get("fb_user_id").toString());
					profile.setFbUserName(rs.get("profile_name")==null?"":rs.get("profile_name").toString());
					profile.setInformation(rs.get("family_member_id")==null?"":rs.get("family_member_id").toString());
					profile.setInformationName(rs.get("family_info")==null?"":rs.get("family_info").toString());
					profile.setInformationType(rs.get("member_rel")==null?"":rs.get("member_rel").toString());
					profileList.add(profile);
				}

				query=" SELECT fb_user_id, profile_name, life_events, event_year "
					+ " FROM fb_scrap_profile_event AS event "
					+ " INNER JOIN collection_profile "
					+ " ON collection_profile.profile_id=event.fb_user_id "
					+ " WHERE source='facebook' AND fb_user_id="+tweeterActionVo.getFbUserProfileFilter()+" "; 
				System.out.println("Event: "+query);
				rows = jdbcTemplate.queryForList(query);
				for(Map<String, Object> rs :rows)
				{
					String life_events=rs.get("life_events")==null?"":rs.get("life_events").toString();
					String event_year=rs.get("event_year")==null?"":rs.get("event_year").toString();
					String eventName= event_year+" ,"+life_events;				
					UserProfileExportVo profile = new UserProfileExportVo();
					profile.setFbUserId(rs.get("fb_user_id")==null?"":rs.get("fb_user_id").toString());
					profile.setFbUserName(rs.get("profile_name")==null?"":rs.get("profile_name").toString());
					profile.setInformation(eventName);
					profile.setInformationType("Event");
					profileList.add(profile);
				}

				query=" SELECT fb_user_id, profile_name, about "
					+ " FROM fb_scrap_profile_about AS about "
				    + " INNER JOIN collection_profile "
					+ " ON collection_profile.profile_id=about.fb_user_id "
					+ " WHERE source='facebook' AND fb_user_id="+tweeterActionVo.getFbUserProfileFilter()+" ";
				System.out.println("Event: "+query);
				rows = jdbcTemplate.queryForList(query);
				
				for(Map<String, Object> rs :rows)
				{
					UserProfileExportVo profile = new UserProfileExportVo();
					profile.setFbUserId(rs.get("fb_user_id")==null?"":rs.get("fb_user_id").toString());
					profile.setFbUserName(rs.get("profile_name")==null?"":rs.get("profile_name").toString());
					profile.setInformation(rs.get("about")==null?"":rs.get("about").toString());
					profile.setInformationType("About");
					profileList.add(profile);
				}
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
			} 
		}
		
		//FACEBOOK PAGE
		else if(tweeterActionVo.getFbType().equals("page"))
		{
			try 
			{
				    query=" SELECT fb_pageid, fb_page_name, page_allinfo, info_type "
						+ " FROM fb_page_complete_about "
						+ " WHERE fb_pageid="+tweeterActionVo.getFbUserProfileFilter()+" ";       
					System.out.println("fb_page_complete_about: "+query);
					rows = jdbcTemplate.queryForList(query);
					for(Map<String, Object> rs :rows) 
					{
						UserProfileExportVo profile = new UserProfileExportVo();
						profile.setFbUserId(rs.get("fb_pageid")==null?"":rs.get("fb_pageid").toString());
						profile.setFbUserName(rs.get("fb_page_name")==null?"":rs.get("fb_page_name").toString());
						profile.setInformation(rs.get("page_allinfo")==null?"":rs.get("page_allinfo").toString());
						profile.setInformationType(rs.get("info_type")==null?"":rs.get("info_type").toString());
						profileList.add(profile);
					}
					
				    query=" SELECT fb_pageid, fb_page_name, about, page_story, page_cover_pic, page_pro_pic, page_like, page_follow "
						+ " FROM fb_scrap_page_about "
						+ " WHERE fb_pageid="+tweeterActionVo.getFbUserProfileFilter()+" ORDER BY id DESC LIMIT 1";       
					System.out.println("fb_scrap_page_about: "+query);
					rows = jdbcTemplate.queryForList(query);
					for(Map<String, Object> rs :rows) 
					{
						UserProfileExportVo profile1 = new UserProfileExportVo();
						profile1.setFbUserId(rs.get("fb_pageid")==null?"":rs.get("fb_pageid").toString());
						profile1.setFbUserName(rs.get("fb_page_name")==null?"":rs.get("fb_page_name").toString());
						profile1.setInformation(rs.get("about")==null?"":rs.get("about").toString());
						profile1.setInformationType("About");
						profileList.add(profile1);
						
						UserProfileExportVo profile2 = new UserProfileExportVo();
						profile2.setFbUserId(rs.get("fb_pageid")==null?"":rs.get("fb_pageid").toString());
						profile2.setFbUserName(rs.get("fb_page_name")==null?"":rs.get("fb_page_name").toString());
						profile2.setInformation(rs.get("page_story")==null?"":rs.get("page_story").toString());
						profile2.setInformationType("Page Story");
						profileList.add(profile2);
						
						UserProfileExportVo profile3 = new UserProfileExportVo();
						profile3.setFbUserId(rs.get("fb_pageid")==null?"":rs.get("fb_pageid").toString());
						profile3.setFbUserName(rs.get("fb_page_name")==null?"":rs.get("fb_page_name").toString());
						profile3.setInformation(rs.get("page_like")==null?"":rs.get("page_like").toString());
						profile3.setInformationType("Page Like Count");
						profileList.add(profile3);
						
						UserProfileExportVo profile4 = new UserProfileExportVo();
						profile4.setFbUserId(rs.get("fb_pageid")==null?"":rs.get("fb_pageid").toString());
						profile4.setFbUserName(rs.get("fb_page_name")==null?"":rs.get("fb_page_name").toString());
						profile4.setInformation(rs.get("page_follow")==null?"":rs.get("page_follow").toString());
						profile4.setInformationType("Page Follow Count");
						profileList.add(profile4);
						
						UserProfileExportVo profile5 = new UserProfileExportVo();
						profile5.setFbUserId(rs.get("fb_pageid")==null?"":rs.get("fb_pageid").toString());
						profile5.setFbUserName(rs.get("fb_page_name")==null?"":rs.get("fb_page_name").toString());
						profile5.setInformation(rs.get("page_pro_pic")==null?"":rs.get("page_pro_pic").toString());
						profile5.setInformationType("Page Profile Image");
						profileList.add(profile5);
						
						UserProfileExportVo profile6 = new UserProfileExportVo();
						profile6.setFbUserId(rs.get("fb_pageid")==null?"":rs.get("fb_pageid").toString());
						profile6.setFbUserName(rs.get("fb_page_name")==null?"":rs.get("fb_page_name").toString());
						profile6.setInformation(rs.get("page_cover_pic")==null?"":rs.get("page_cover_pic").toString());
						profile6.setInformationType("Page Cover Image");
						profileList.add(profile6);
					}  
			} 
			catch(Exception ex) 
			{
				ex.printStackTrace();
			}
		}
		
		//FACEBOOK GROUP
		else if(tweeterActionVo.getFbType().equals("group"))
		{
			try 
			{
				  query = " SELECT fb_group_id, fb_group_name, group_cover_pic, about, creation_date "
						+ " FROM fb_scrap_group_about "
						+ " WHERE fb_group_id='"+tweeterActionVo.getFbUserProfileFilter()+"' "; 
				System.out.println("fb_scrap_group_about: "+query);
				rows = jdbcTemplate.queryForList(query);
				for(Map<String,Object> rs :rows)
				{
					UserProfileExportVo profile1 = new UserProfileExportVo();
					profile1.setFbUserId(rs.get("fb_group_id")==null?"":rs.get("fb_group_id").toString());
					profile1.setFbUserName(rs.get("fb_group_name")==null?"":rs.get("fb_group_name").toString());
					profile1.setInformation(rs.get("group_cover_pic")==null?"":rs.get("group_cover_pic").toString());
					profile1.setInformationType("Group Cover Image");
					profileList.add(profile1);
					
					UserProfileExportVo profile2 = new UserProfileExportVo();
					profile2.setFbUserId(rs.get("fb_group_id")==null?"":rs.get("fb_group_id").toString());
					profile2.setFbUserName(rs.get("fb_group_name")==null?"":rs.get("fb_group_name").toString());
					profile2.setInformation(rs.get("about")==null?"":rs.get("about").toString());
					profile2.setInformationType("Group Description");
					profileList.add(profile2);
					
					UserProfileExportVo profile3 = new UserProfileExportVo();
					profile3.setFbUserId(rs.get("fb_group_id")==null?"":rs.get("fb_group_id").toString());
					profile3.setFbUserName(rs.get("fb_group_name")==null?"":rs.get("fb_group_name").toString());
					profile3.setInformation(rs.get("creation_date")==null?"":rs.get("creation_date").toString());
					profile3.setInformationType("Group Creation Date");
					profileList.add(profile3);
				}
			}
			catch(Exception ex) 
			{
				ex.printStackTrace();
			}
		}
		return profileList;
	}

	
	
	public String exportFbTotalDocumentCount(TweeterActionVo tweeterActionVo) 
	{
		String totalCount="";
		try 
		{
			String subQuery = rtnFilterQuery(tweeterActionVo, -1);
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"distinctVal\":{\n"+
					"\"cardinality\":{\n"+
					"\"field\":\"articleId\" \n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";
			
			System.out.println("exportFbTotalDocumentCount: "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			CardinalityAggregation terms = result.getAggregations().getCardinalityAggregation("distinctVal");
			Long value = terms.getCardinality();
			totalCount=String.valueOf(value);
			System.out.println("totalCount: "+totalCount);		
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return totalCount;
	}
	
	
	
	public ArrayList<HashMap<String, String>> exportFbOverallSentimentReportData(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<HashMap<String, String>> sentimentdata = new ArrayList<HashMap<String, String>>();

		try 
		{
			String subQuery = rtnFilterQuery(tweeterActionVo, 19);
			String query = "{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+ 
					"\"termagg\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\"articleSentiment\"\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";

			System.out.println("geexportFbOverallSentimentReportData: "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			TermsAggregation terms = result.getAggregations().getTermsAggregation("termagg");
			if(terms !=null)
			{
				List<Entry> entry = terms.getBuckets();
				for(Entry entry2 : entry)
				{
					HashMap<String, String> map = new HashMap<String, String>();
					String key = entry2.getKey();
					Long count = entry2.getCount();
					if (key.equals("1")) 
					{
						map.put("positive", Long.toString(count));
					}
					else if(key.equals("-1")) 
					{
						map.put("negative", Long.toString(count));
					} 
					else if(key.equals("0"))
					{
						map.put("neutral", Long.toString(count));
					}
					sentimentdata.add(map);
				}
			}
		} 
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return sentimentdata;
	}


	
	public ArrayList<HashMap<String, String>> exportFbClassificationReportData(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<HashMap<String, String>> classificationData = new ArrayList<HashMap<String, String>>();

		try 
		{
			String subQuery=rtnFilterQuery(tweeterActionVo, -1);
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"termagg\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\"articleClassification\"\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";

			System.out.println("exportFbClassificationReportData: "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			TermsAggregation terms = result.getAggregations().getTermsAggregation("termagg");
			if(terms != null) 
			{
				List<Entry> entry = terms.getBuckets();
				for (Entry entry2 : entry) 
				{
					HashMap<String, String> map = new HashMap<String, String>();
					map.put("key", entry2.getKey());
					map.put("count", Long.toString(entry2.getCount()));
					classificationData.add(map);
				}
			}
		} 
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return classificationData;
	}


	
	public ArrayList<HashMap<String, String>> exportFbPersonReportData(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<HashMap<String, String>> personData = new ArrayList<HashMap<String, String>>();

		try 
		{
			String sortQuery=TwitterConstant.getSortForEsTermAggNested(tweeterActionVo.getNerSortOrder().toLowerCase().trim(),"_count");
			String subQuery=rtnFilterQuery(tweeterActionVo, -1);
			String path="articlePersonNer";
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"termagg\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\""+path+".keyword\"\n,"+
					"\"size\": 25 \n,"+
					sortQuery+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";
			System.out.println("exportFbPersonReportData: "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			TermsAggregation terms = result.getAggregations().getTermsAggregation("termagg");
			if(terms != null) 
			{
				List<Entry> entry = terms.getBuckets();
				for(Entry entry2 : entry)
				{
					HashMap<String, String> map = new HashMap<String, String>();
					map.put("key", entry2.getKey());
					map.put("count", Long.toString(entry2.getCount()));
					personData.add(map);
				}
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return personData;
	}


	
	public ArrayList<HashMap<String, String>> exportFbPlaceReportData(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<HashMap<String, String>> placeData = new ArrayList<HashMap<String, String>>();
		
		try 
		{
			String sortQuery=TwitterConstant.getSortForEsTermAggNested(tweeterActionVo.getNerSortOrder().toLowerCase().trim(),"_count");
			String subQuery=rtnFilterQuery(tweeterActionVo, -1);
			String path="articleLocationNer";
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"termagg\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\""+path+".keyword\"\n,"+
					"\"size\": 25 \n,"+
					sortQuery+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";
			System.out.println("exportFbPlaceReportData: "+query);
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			TermsAggregation terms = result.getAggregations().getTermsAggregation("termagg");
			if(terms != null) 
			{
				List<Entry> entry = terms.getBuckets();
				for(Entry entry2 : entry) 
				{
					HashMap<String, String> map = new HashMap<String, String>();
					map.put("key", entry2.getKey());
					map.put("count", Long.toString(entry2.getCount()));
					placeData.add(map);
				}
			}
		} 
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return placeData;
	}


	
	public ArrayList<HashMap<String, String>> exportFbOrgReportData(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<HashMap<String, String>> orgData = new ArrayList<HashMap<String, String>>();

		try 
		{
			String sortQuery=TwitterConstant.getSortForEsTermAggNested(tweeterActionVo.getNerSortOrder().toLowerCase().trim(),"_count");
			String subQuery=rtnFilterQuery(tweeterActionVo, -1);
			String path="articleOrganizationNer";
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"termagg\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\""+path+".keyword\"\n,"+
					"\"size\": 25 \n,"+
					sortQuery+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";
			System.out.println("exportFbOrgReportData: "+query);
			
			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();
			SearchResult result = client.execute(search);
			TermsAggregation terms = result.getAggregations().getTermsAggregation("termagg");
			if(terms != null) 
			{
				List<Entry> entry = terms.getBuckets();
				for(Entry entry2 : entry) 
				{
					HashMap<String, String> map = new HashMap<String, String>();
					map.put("key", entry2.getKey());
					map.put("count", Long.toString(entry2.getCount()));
					orgData.add(map);
				}
			}
		} 
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return orgData;
	}

	
	
	public ArrayList<HashMap<String, String>> exportFbThemesReportData(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<HashMap<String, String>> themeData = new ArrayList<HashMap<String, String>>();

		try 
		{
			String sortQuery = TwitterConstant.getSortForEsTermAgg(tweeterActionVo.getThemeSortOrder().toLowerCase().trim());
			String subQuery = rtnFilterQuery(tweeterActionVo, -1);

			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"termagg\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\"articleThemes\"\n,"+
					"\"size\": 25 \n,"+
					sortQuery+
					"}\n"+
					TwitterConstant.getAvg("articleSentiment")+
					"}\n"+
					"}\n"+
					"}\n";
			System.out.println("exportFbThemesReportData: "+query);

			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			TermsAggregation terms = result.getAggregations().getTermsAggregation("termagg");

			if(terms != null) 
			{
				List<Entry> entry = terms.getBuckets();
				for(Entry entry2 : entry) 
				{
					HashMap<String, String> map = new HashMap<String, String>();
					map.put("key", entry2.getKey());
					map.put("count", Long.toString(entry2.getCount()));
					themeData.add(map);
				}
			}
		} 
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return themeData;
	}


	
	public ArrayList<String> exportFbPhotoReportData(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<String> photoData = new ArrayList<String>();
		List<Map<String, Object>> rows = null;
		try 
		{
			String query=" SELECT user_photo_url "
					   + " FROM fb_scrap_user_photo "
					   + " where fb_user_id='"+tweeterActionVo.getFbUserProfileFilter()+"' ";
			System.out.println("exportFbPhotoReportData: "+query);
			
			rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				photoData.add(rs.get("user_photo_url")==null?"":rs.get("user_photo_url").toString());
			}
		} 
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return photoData;
	}


	
	public ArrayList<String> exportFbVideoReportData(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<String> videoData = new ArrayList<String>();
		List<Map<String, Object>> rows = null;
		try 
		{
			String query=" SELECT video_thumnail "
					   + " FROM fb_scrap_user_video "
					   + " where fb_user_id='"+tweeterActionVo.getFbUserProfileFilter()+"' ";
			System.out.println("exportFbVideoReportData: "+query);
			
			rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				videoData.add(rs.get("video_thumnail")==null?"":rs.get("video_thumnail").toString());
			}
		} 
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return videoData;
	}


	
	public ArrayList<HashMap<String, String>> exportFbCheckinsReportData(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<HashMap<String, String>> checkinsData = new ArrayList<HashMap<String, String>>();
		List<Map<String, Object>> rows = null;
		try 
		{
			String query=" SELECT check_in_name, check_in_img "
					   + " FROM fb_scrap_user_check_in "
					   + " where fb_user_id='"+tweeterActionVo.getFbUserProfileFilter()+"' ";
			System.out.println("exportFbCheckinsReportData: "+query);
			
			rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				HashMap<String, String> map = new HashMap<String, String>();
				map.put("checkinsName", rs.get("check_in_name")==null?"":rs.get("check_in_name").toString());
				map.put("checkinsImage", rs.get("check_in_img")==null?"":rs.get("check_in_img").toString());
				checkinsData.add(map);
			}
		} 
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return checkinsData;
	}


	
	public ArrayList<HashMap<String, String>> exportFbLikesReportData(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<HashMap<String, String>> likesData = new ArrayList<HashMap<String, String>>();
		List<Map<String, Object>> rows = null;
		try 
		{
			String query=" SELECT liked_userId, liked_screenName, liked_user_profession, liked_user_img "
					   + " FROM fb_scrap_user_like_detail "
					   + " where fb_user_id='"+tweeterActionVo.getFbUserProfileFilter()+"' ";
			System.out.println("exportFbLikesReportData: "+query);
			
			rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				HashMap<String, String> map = new HashMap<String, String>();
				map.put("likedUserId", rs.get("liked_userId")==null?"":rs.get("liked_userId").toString());
				map.put("likedUserName", rs.get("liked_screenName")==null?"":rs.get("liked_screenName").toString());
				map.put("likedUserProfession", rs.get("liked_user_profession")==null?"":rs.get("liked_user_profession").toString());
				map.put("likedUserImage", rs.get("liked_user_img")==null?"":rs.get("liked_user_img").toString());
				likesData.add(map);
			}
		} 
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return likesData;
	}


	
	public ArrayList<SaveFilterVo> getAllAnalysisName(SaveFilterVo saveFilterVo) 
	{
		ArrayList<SaveFilterVo> caseList = new ArrayList<SaveFilterVo>();
		List<Map<String, Object>> rows = null;
		try 
		{
			String query=" SELECT id, case_name, login_id, case_type "
					   + " FROM tbl_case "
					   + " ORDER BY case_name ASC ";
					   //+ " WHERE login_id='"+saveFilterVo.getLoginId()+"' ";
			System.out.println("getAllAnalysisName: "+query);
			
			rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				SaveFilterVo filterVo=new SaveFilterVo();
				filterVo.setCaseId(Integer.parseInt(rs.get("id").toString()));
				filterVo.setLoginId(rs.get("login_id")==null?0:Integer.parseInt(rs.get("login_id").toString()));			
				filterVo.setCaseName(rs.get("case_name")==null?"":rs.get("case_name").toString());
				filterVo.setCaseType(rs.get("case_type")==null?"":rs.get("case_type").toString());
				caseList.add(filterVo);
			}
		} 
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return caseList;
	}


	
	public ArrayList<SaveFilterVo> getAllRequiredSnapshotName(SaveFilterVo saveFilterVo) 
	{
		ArrayList<SaveFilterVo> snapList = new ArrayList<SaveFilterVo>();
		List<Map<String, Object>> rows = null;
		String subQuery="";
		if(saveFilterVo.getCaseId() != 0)
		{
			subQuery=" WHERE case_id='"+saveFilterVo.getCaseId()+"' ";
		}
			
		try 
		{
			String query=" SELECT id, search_name "
					   + " FROM tbl_save_filter "
					   + " "+subQuery+" ";
			System.out.println("getAllRequiredSnapshotNames: "+query);
			
			rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs :rows)
			{
				SaveFilterVo filterVo=new SaveFilterVo();
				filterVo.setSnapShotId(Integer.parseInt(rs.get("id").toString()));
				filterVo.setSnapshotName(rs.get("search_name")==null?"":rs.get("search_name").toString());
				snapList.add(filterVo);
			}
		} 
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return snapList;
	}


	
	public ArrayList<TwitterVo> getAllUniqueTWBoatsUser(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> list=new ArrayList<TwitterVo>();
		try 
		{
			tweeterActionVo.setUserCreatedDateFrom(tweeterActionVo.getDateFrom());
			tweeterActionVo.setUserCreatedDateTo(tweeterActionVo.getDateTo());
			tweeterActionVo.setSourceFilter("tw");
			tweeterActionVo.setDateFrom("");
			tweeterActionVo.setDateFromGrph("");
			tweeterActionVo.setDateTo("");
			tweeterActionVo.setDateToGrph("");
			String subQuery=rtnFilterQuery(tweeterActionVo, -1);
			
			String query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"distinctAuthor\":{\n"+
					"\"cardinality\":{\n"+
					"\"field\":\"articleAuthor\"\n"+
					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";
			
			System.out.println("getAllUniqueTWBoatsUser: unique tw user query: "+query);

			Search search = new Search.Builder(query)
					.addIndex(TwitterConstant.getDbname())
					.addType(TwitterConstant.getTypeName())
					.build();

			SearchResult result = client.execute(search);
			CardinalityAggregation cardiAgg = result.getAggregations().getCardinalityAggregation("distinctAuthor");
		    long l=cardiAgg.getCardinality();
			System.out.println("unique user: "+l);
			
			TwitterVo twitterVo=new TwitterVo();
			twitterVo.setUserCount(Long.toString(l));
			list.add(twitterVo);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return list;
	}


	
	public ArrayList<TwitterVo> getFBUserPostComment(TweeterActionVo tweeterActionVo)
	{
		ArrayList<TwitterVo> list = new ArrayList<TwitterVo>();
		try
		{
			TwitterVo twitterVo = new TwitterVo();
			twitterVo.setArticleAuthorImage("https://scontent.fdel46-1.fna.fbcdn.net/v/t1.6435-1/cp0/p60x60/183968774_304451404536536_7446592650679257523_n.jpg?_nc_cat=104&amp;ccb=1-3&amp;_nc_sid=7206a8&amp;_nc_ohc=Xm1KohzqPToAX_UGxrn&amp;_nc_ht=scontent.fdel46-1.fna&amp;tp=27&amp;oh=c38c8d7e8200ef6fb96c37c50345afb7&amp;oe=60C4F47A");
			twitterVo.setArticleAuthor("Dileep Tripathi");
			twitterVo.setArticleAuthorId("");
			twitterVo.setArticleTitle("SonuSood is truly a gem of a person! He steps out of his house and serves juice to the media clan as they were waiting outside his house to click few pictures in this hot weather");
			twitterVo.setCount("100");
			list.add(twitterVo);
			
			twitterVo = new TwitterVo();
			twitterVo.setArticleAuthorImage("https://scontent.fdel46-1.fna.fbcdn.net/v/t1.6435-1/cp0/p60x60/183968774_304451404536536_7446592650679257523_n.jpg?_nc_cat=104&amp;ccb=1-3&amp;_nc_sid=7206a8&amp;_nc_ohc=Xm1KohzqPToAX_UGxrn&amp;_nc_ht=scontent.fdel46-1.fna&amp;tp=27&amp;oh=c38c8d7e8200ef6fb96c37c50345afb7&amp;oe=60C4F47A");
			twitterVo.setArticleAuthor("Dileep Tripathi");
			twitterVo.setArticleAuthorId("");
			twitterVo.setArticleTitle("SonuSood is truly a gem of a person! He steps out of his house and serves juice to the media clan as they were waiting outside his house to click few pictures in this hot weather");
			twitterVo.setCount("100");
			list.add(twitterVo);
			
			twitterVo = new TwitterVo();
			twitterVo.setArticleAuthorImage("https://scontent.fdel46-1.fna.fbcdn.net/v/t1.6435-1/cp0/p60x60/183968774_304451404536536_7446592650679257523_n.jpg?_nc_cat=104&amp;ccb=1-3&amp;_nc_sid=7206a8&amp;_nc_ohc=Xm1KohzqPToAX_UGxrn&amp;_nc_ht=scontent.fdel46-1.fna&amp;tp=27&amp;oh=c38c8d7e8200ef6fb96c37c50345afb7&amp;oe=60C4F47A");
			twitterVo.setArticleAuthor("Dileep Tripathi");
			twitterVo.setArticleAuthorId("");
			twitterVo.setArticleTitle("SonuSood is truly a gem of a person! He steps out of his house and serves juice to the media clan as they were waiting outside his house to click few pictures in this hot weather");
			twitterVo.setCount("100");
			list.add(twitterVo);
			
			twitterVo = new TwitterVo();
			twitterVo.setArticleAuthorImage("https://scontent.fdel46-1.fna.fbcdn.net/v/t1.6435-1/cp0/p60x60/183968774_304451404536536_7446592650679257523_n.jpg?_nc_cat=104&amp;ccb=1-3&amp;_nc_sid=7206a8&amp;_nc_ohc=Xm1KohzqPToAX_UGxrn&amp;_nc_ht=scontent.fdel46-1.fna&amp;tp=27&amp;oh=c38c8d7e8200ef6fb96c37c50345afb7&amp;oe=60C4F47A");
			twitterVo.setArticleAuthor("Dileep Tripathi");
			twitterVo.setArticleAuthorId("");
			twitterVo.setArticleTitle("SonuSood is truly a gem of a person! He steps out of his house and serves juice to the media clan as they were waiting outside his house to click few pictures in this hot weather");
			twitterVo.setCount("100");
			list.add(twitterVo);
		}	
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return list; 
	}


	
	public ArrayList<TwitterVo> getArticleDetailsById(TweeterActionVo tweeterActionVo) 
	{
		ArrayList<TwitterVo> list = new ArrayList<TwitterVo>();

		try 
		{
			TwitterVo twitterVo=new TwitterVo();
			ArrayList<Article_Media> mediaList= new ArrayList<Article_Media>();
			Article_Media media=new Article_Media();
			media.setMediaType("image");
			media.setMediaThumbnail("http://pbs.twimg.com/media/E60PjyDVUAMIdfi.jpg");
			media.setMediaUrl("https://twitter.com/KhushnumaKashm1/status/1417806572445597698");
			mediaList.add(media);
			
			twitterVo.setTweetText("A Khairiyat Patrol was carried out by #IndianArmy in the village #Haripora, with the aim of spreading awareness amongst the locals with respect to the ongoing #COVID19 pandemic. Kashmir #Kashmir https://t.co/PlSMji5tT5");
			twitterVo.setTweeterId("1417806572445597698");
			twitterVo.setUserId("1278740960919207937");
			twitterVo.setScreenName("KhushnumaKashm1");
			twitterVo.setCreatedAt(CommonUtils.convertUnixTimeToDateDisplayFormat(1626866403000L));
			twitterVo.setArticleAuthorImage("http://pbs.twimg.com/profile_images/1278750805470752768/9-IbGxZ-.jpg");
			twitterVo.setSentiment(Integer.toString(1));
			twitterVo.setArticleAuthor("Khushnuma Kashmir");
			twitterVo.setArticleMedia(mediaList);
			
			
			
			
			list.add(twitterVo);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		
		
		return list; 
	}


	




	


	
	
}