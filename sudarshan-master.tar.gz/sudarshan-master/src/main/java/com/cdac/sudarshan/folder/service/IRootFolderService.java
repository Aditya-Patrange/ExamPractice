package com.cdac.sudarshan.folder.service;

import com.cdac.sudarshan.dto.UserFolderDTO;
import com.cdac.sudarshan.folder.dto.RootFolderDto;
import com.cdac.sudarshan.folder.model.RootFolder;
import org.springframework.http.ResponseEntity;

import java.util.List;
import java.util.Map;

public interface IRootFolderService {

	RootFolder saveRootFolder(List<String> path);

	List<RootFolder> listOfRootFolders();

	UserFolderDTO getAllSubFolderAndUrlPathsOfRootFolderOfUser();

	List<RootFolderDto> getRootFolderOfUser();

	public Map<String , Integer> getUrlCount(String rootFolderName);

	public Map<String , Integer>  getItemCount(String path);

    ResponseEntity<?> deleteFolderAllData(String rootPath);

	//delete multiple folders at a time apis
	ResponseEntity<?> deleteFolderAllData2(Map<String, List<String>> map);

	ResponseEntity<?> renameFolderName(Map<String,String> map);

	ResponseEntity<?> copyRootFolderAndData(List<String> Sourcepaths, String destinationPath);
}
