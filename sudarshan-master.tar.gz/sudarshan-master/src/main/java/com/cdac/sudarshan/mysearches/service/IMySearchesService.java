package com.cdac.sudarshan.mysearches.service;

import java.util.HashMap;
import java.util.List;

import com.cdac.sudarshan.mysearches.dto.MySearchesDto;
import com.cdac.sudarshan.mysearches.model.MySearches;

public interface IMySearchesService {
	public HashMap<String,Object> findByUserId(MySearchesDto searchDto);
	
	public void saveOrUpdate(MySearches search);
	
	public void delete(List<Integer> ids);
	
	//public void update(MySearches search, int id);
	
	public MySearches getSearchDataById(Integer id);
}
