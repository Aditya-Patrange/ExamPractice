package com.cdac.sudarshan.discover.common;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class InstaInputVo {
	private String priority;
	private  String rowNum,postId;
	private String keywordFilter;
	private  String hashTagFilter;
	private  String hashTagNotFilter;
	private  String dateFrom,dateTo,dateFromGrph,dateToGrph,advFilter;
	private  String isMap;
	private  String userFilter;
	private  String userNotFilter;
	private String mentionFilter;
	private String mentionNotFilter;
	private String sentimentFilter;
	private String  priorityFilter;
	private  String instaSortFilter;
	private  String userSortFilter;
	private String keywordFilter2;
	private String isDashBord,mediaType,geoFilter,mediaTypeFilter,caseId;
	private ArrayList<String> entityIds;
	private String isRpt;
	private String hashTagSortOrder,mentionSortOrder;
    private String noTweet;
	
	
	public String getHashTagSortOrder() {
		return hashTagSortOrder;
	}
	public void setHashTagSortOrder(String hashTagSortOrder) {
		this.hashTagSortOrder = hashTagSortOrder;
	}
	public String getMentionSortOrder() {
		return mentionSortOrder;
	}
	public void setMentionSortOrder(String mentionSortOrder) {
		this.mentionSortOrder = mentionSortOrder;
	}
	public String getNoTweet() {
		return noTweet;
	}
	public void setNoTweet(String noTweet) {
		this.noTweet = noTweet;
	}
	public String getIsRpt() {
		return isRpt;
	}
	public void setIsRpt(String isRpt) {
		this.isRpt = isRpt;
	}
	public ArrayList<String> getEntityIds() {
		return entityIds;
	}
	public void setEntityIds(ArrayList<String> entityIds) {
		this.entityIds = entityIds;
	}
	public String getCaseId() {
		return caseId;
	}
	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}
	public String getMediaTypeFilter() {
		return mediaTypeFilter;
	}
	public void setMediaTypeFilter(String mediaTypeFilter) {
		this.mediaTypeFilter = mediaTypeFilter;
	}
	public String getGeoFilter() {
		return geoFilter;
	}
	public void setGeoFilter(String geoFilter) {
		this.geoFilter = geoFilter;
	}
	public String getPostId() {
		return postId;
	}
	public void setPostId(String postId) {
		this.postId = postId;
	}
	public String getMediaType() {
		return mediaType;
	}
	public void setMediaType(String mediaType) {
		this.mediaType = mediaType;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	public String getRowNum() {
		return rowNum;
	}
	public void setRowNum(String rowNum) {
		this.rowNum = rowNum;
	}
	public String getKeywordFilter() {
		return keywordFilter;
	}
	public void setKeywordFilter(String keywordFilter) {
		this.keywordFilter = keywordFilter;
	}
	public String getHashTagFilter() {
		return hashTagFilter;
	}
	public void setHashTagFilter(String hashTagFilter) {
		this.hashTagFilter = hashTagFilter;
	}
	public String getHashTagNotFilter() {
		return hashTagNotFilter;
	}
	public void setHashTagNotFilter(String hashTagNotFilter) {
		this.hashTagNotFilter = hashTagNotFilter;
	}
	public String getDateFrom() {
		return dateFrom;
	}
	public void setDateFrom(String dateFrom) {
		this.dateFrom = dateFrom;
	}
	public String getDateTo() {
		return dateTo;
	}
	public void setDateTo(String dateTo) {
		this.dateTo = dateTo;
	}
	public String getDateFromGrph() {
		return dateFromGrph;
	}
	public void setDateFromGrph(String dateFromGrph) {
		this.dateFromGrph = dateFromGrph;
	}
	public String getDateToGrph() {
		return dateToGrph;
	}
	public void setDateToGrph(String dateToGrph) {
		this.dateToGrph = dateToGrph;
	}
	public String getAdvFilter() {
		return advFilter;
	}
	public void setAdvFilter(String advFilter) {
		this.advFilter = advFilter;
	}
	public String getIsMap() {
		return isMap;
	}
	public void setIsMap(String isMap) {
		this.isMap = isMap;
	}
	public String getUserFilter() {
		return userFilter;
	}
	public void setUserFilter(String userFilter) {
		this.userFilter = userFilter;
	}
	public String getUserNotFilter() {
		return userNotFilter;
	}
	public void setUserNotFilter(String userNotFilter) {
		this.userNotFilter = userNotFilter;
	}
	public String getMentionFilter() {
		return mentionFilter;
	}
	public void setMentionFilter(String mentionFilter) {
		this.mentionFilter = mentionFilter;
	}
	public String getMentionNotFilter() {
		return mentionNotFilter;
	}
	public void setMentionNotFilter(String mentionNotFilter) {
		this.mentionNotFilter = mentionNotFilter;
	}
	public String getSentimentFilter() {
		return sentimentFilter;
	}
	public void setSentimentFilter(String sentimentFilter) {
		this.sentimentFilter = sentimentFilter;
	}
	public String getPriorityFilter() {
		return priorityFilter;
	}
	public void setPriorityFilter(String priorityFilter) {
		this.priorityFilter = priorityFilter;
	}
	public String getInstaSortFilter() {
		return instaSortFilter;
	}
	public void setInstaSortFilter(String instaSortFilter) {
		this.instaSortFilter = instaSortFilter;
	}
	public String getUserSortFilter() {
		return userSortFilter;
	}
	public void setUserSortFilter(String userSortFilter) {
		this.userSortFilter = userSortFilter;
	}
	public String getKeywordFilter2() {
		return keywordFilter2;
	}
	public void setKeywordFilter2(String keywordFilter2) {
		this.keywordFilter2 = keywordFilter2;
	}
	public String getIsDashBord() {
		return isDashBord;
	}
	public void setIsDashBord(String isDashBord) {
		this.isDashBord = isDashBord;
	}

}

