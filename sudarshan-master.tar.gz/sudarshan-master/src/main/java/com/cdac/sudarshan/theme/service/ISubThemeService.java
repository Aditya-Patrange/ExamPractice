
package com.cdac.sudarshan.theme.service;

import com.cdac.sudarshan.theme.dto.SubThemeDto;
import com.cdac.sudarshan.theme.model.SubTheme;

import java.util.List;

public interface ISubThemeService {

    //add sub theme to root theme
    List<SubThemeDto> addSubThemeToRootTheme(String path);

    List<SubTheme> getAllSubThemeOfRootTheme(String path);
}
