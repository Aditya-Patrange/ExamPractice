package com.cdac.sudarshan.discover.model;

import java.io.Serializable;
import java.util.ArrayList;

public class LinkAnalysisVo implements Serializable 
{
	private static final long serialVersionUID = 1L;
	private ArrayList<NodeVo> nodes;
	private ArrayList<EdgeVo> links;
	public ArrayList<NodeVo> getNodes() {
		return nodes;
	}
	public void setNodes(ArrayList<NodeVo> nodes) {
		this.nodes = nodes;
	}
	public ArrayList<EdgeVo> getLinks() {
		return links;
	}
	public void setLinks(ArrayList<EdgeVo> links) {
		this.links = links;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() 
	{
		return "LinkAnalysisVo [nodes=" + nodes + ", links=" + links + "]";
	}
}
