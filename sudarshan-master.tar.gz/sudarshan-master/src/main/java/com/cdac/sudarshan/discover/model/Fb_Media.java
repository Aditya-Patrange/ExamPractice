package com.cdac.sudarshan.discover.model;

import java.io.Serializable;

public class Fb_Media implements Serializable 
{
	private static final long serialVersionUID = 1L;
	private String fbImageId;
	private String fbSubAttImgTitle;
	private String fbSubAttImgDesc;
	private String fbSubAttImgType;
	private String fbSubAttImgUrl;
	private String fbSubAttImgSrc;
	private String imgMd5;

	public String getImgMd5() {
		return imgMd5;
	}

	public void setImgMd5(String imgMd5) {
		this.imgMd5 = imgMd5;
	}

	public String getFbImageId() {
		return fbImageId;
	}

	public void setFbImageId(String fbImageId) {
		this.fbImageId = fbImageId;
	}

	public String getFbSubAttImgTitle() {
		return fbSubAttImgTitle;
	}

	public void setFbSubAttImgTitle(String fbSubAttImgTitle) {
		this.fbSubAttImgTitle = fbSubAttImgTitle;
	}

	public String getFbSubAttImgDesc() {
		return fbSubAttImgDesc;
	}

	public void setFbSubAttImgDesc(String fbSubAttImgDesc) {
		this.fbSubAttImgDesc = fbSubAttImgDesc;
	}

	public String getFbSubAttImgType() {
		return fbSubAttImgType;
	}

	public void setFbSubAttImgType(String fbSubAttImgType) {
		this.fbSubAttImgType = fbSubAttImgType;
	}

	public String getFbSubAttImgUrl() {
		return fbSubAttImgUrl;
	}

	public void setFbSubAttImgUrl(String fbSubAttImgUrl) {
		this.fbSubAttImgUrl = fbSubAttImgUrl;
	}

	public String getFbSubAttImgSrc() {
		return fbSubAttImgSrc;
	}

	public void setFbSubAttImgSrc(String fbSubAttImgSrc) {
		this.fbSubAttImgSrc = fbSubAttImgSrc;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "Fb_Media [fbImageId=" + fbImageId + ", fbSubAttImgTitle=" + fbSubAttImgTitle + ", fbSubAttImgDesc="
				+ fbSubAttImgDesc + ", fbSubAttImgType=" + fbSubAttImgType + ", fbSubAttImgUrl=" + fbSubAttImgUrl
				+ ", fbSubAttImgSrc=" + fbSubAttImgSrc + ", imgMd5=" + imgMd5 + "]";
	}
	
}
