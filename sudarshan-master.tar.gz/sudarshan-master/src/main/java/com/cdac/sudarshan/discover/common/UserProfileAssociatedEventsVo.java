package com.cdac.sudarshan.discover.common;

import java.io.Serializable;
import java.sql.Date;

public class UserProfileAssociatedEventsVo implements Serializable
{
	private static final long serialVersionUID = 1L;
	
	private int eventId;
	private int profileId;
	private String eventName;
	private String eventDate;
	private String eventType;
	private String sentimentOfEvent;
	
	public int getEventId() 
	{
		return eventId;
	}
	public void setEventId(int eventId)
	{
		this.eventId = eventId;
	}
	public int getProfileId() 
	{
		return profileId;
	}
	public void setProfileId(int profileId) 
	{
		this.profileId = profileId;
	}
	public String getEventName() 
	{
		return eventName;
	}
	public void setEventName(String eventName) 
	{
		this.eventName = eventName;
	}
	public String getEventDate() 
	{
		return eventDate;
	}
	public void setEventDate(String eventDate) 
	{
		this.eventDate = eventDate;
	}
	public String getEventType() 
	{
		return eventType;
	}
	public void setEventType(String eventType) 
	{
		this.eventType = eventType;
	}
	public String getSentimentOfEvent() 
	{
		return sentimentOfEvent;
	}
	public void setSentimentOfEvent(String sentimentOfEvent) 
	{
		this.sentimentOfEvent = sentimentOfEvent;
	}
	public static long getSerialversionuid() 
	{
		return serialVersionUID;
	}
	
	@Override
	public String toString() 
	{
		return "UserProfileAssociatedEventsVo [eventId=" + eventId + ", profileId=" + profileId + ", eventName="
				+ eventName + ", eventDate=" + eventDate + ", eventType=" + eventType + ", sentimentOfEvent="
				+ sentimentOfEvent + "]";
	}
	
}
