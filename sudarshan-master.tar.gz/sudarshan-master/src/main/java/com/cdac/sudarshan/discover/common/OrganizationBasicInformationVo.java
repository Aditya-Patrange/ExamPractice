package com.cdac.sudarshan.discover.common;

import java.io.Serializable;
import java.util.Arrays;


public class OrganizationBasicInformationVo implements Serializable
{
	private static final long serialVersionUID = 1L;
	
	private int organizationId;
	private String organizationName;
	private String primaryHeadquarter;
	private String leaderName;
	private String dateOfCreation;
	private String primaryLocation;
	private long primaryPhoneNo;
	private String primaryEmailId;
	private String primaryTwitterId;
	private String primaryFacebookId;
	private long bankAccountNo;
	private String userDescription;
	private String loginId;
	private String orgAlias;
	private int profilePhotoId;
	private int profileCoverPhotoId;
	private String searchOrgStr;
	private String orgProfilePhotoId;
	private String orgCoverPhotoId;
	
	public int getOrganizationId() 
	{
		return organizationId;
	}
	public void setOrganizationId(int organizationId) 
	{
		this.organizationId = organizationId;
	}
	
	public String getOrganizationName()
	{
		return organizationName;
	}
	public void setOrganizationName(String organizationName)
	{
		this.organizationName = organizationName;
	}
	
	public String getPrimaryHeadquarter() 
	{
		return primaryHeadquarter;
	}
	public void setPrimaryHeadquarter(String primaryHeadquarter)
	{
		this.primaryHeadquarter = primaryHeadquarter;
	}
	
	public String getLeaderName() 
	{
		return leaderName;
	}
	public void setLeaderName(String leaderName)
	{
		this.leaderName = leaderName;
	}
	
	public String getDateOfCreation() 
	{
		return dateOfCreation;
	}
	public void setDateOfCreation(String dateOfCreation)
	{
		this.dateOfCreation = dateOfCreation;
	}
	
	public String getPrimaryLocation() 
	{
		return primaryLocation;
	}
	public void setPrimaryLocation(String primaryLocation) 
	{
		this.primaryLocation = primaryLocation;
	}
	
	public long getPrimaryPhoneNo()
	{
		return primaryPhoneNo;
	}
	public void setPrimaryPhoneNo(long primaryPhoneNo) 
	{
		this.primaryPhoneNo = primaryPhoneNo;
	}
	
	public String getPrimaryEmailId() 
	{
		return primaryEmailId;
	}
	public void setPrimaryEmailId(String primaryEmailId) 
	{
		this.primaryEmailId = primaryEmailId;
	}
	
	public String getPrimaryTwitterId()
	{
		return primaryTwitterId;
	}
	public void setPrimaryTwitterId(String primaryTwitterId) 
	{
		this.primaryTwitterId = primaryTwitterId;
	}
	
	public String getPrimaryFacebookId()
	{
		return primaryFacebookId;
	}
	public void setPrimaryFacebookId(String primaryFacebookId) 
	{
		this.primaryFacebookId = primaryFacebookId;
	}
	
	public long getBankAccountNo() 
	{
		return bankAccountNo;
	}
	public void setBankAccountNo(long bankAccountNo)
	{
		this.bankAccountNo = bankAccountNo;
	}
	
	public String getUserDescription()
	{
		return userDescription;
	}
	public void setUserDescription(String userDescription)
	{
		this.userDescription = userDescription;
	}
	
	public String getLoginId() 
	{
		return loginId;
	}
	public void setLoginId(String loginId)
	{
		this.loginId = loginId;
	}
	
	public String getOrgAlias()
	{
		return orgAlias;
	}
	public void setOrgAlias(String orgAlias) 
	{
		this.orgAlias = orgAlias;
	}
	
	public int getProfilePhotoId() 
	{
		return profilePhotoId;
	}
	public void setProfilePhotoId(int profilePhotoId) 
	{
		this.profilePhotoId = profilePhotoId;
	}
	
	public int getProfileCoverPhotoId() 
	{
		return profileCoverPhotoId;
	}
	public void setProfileCoverPhotoId(int profileCoverPhotoId) 
	{
		this.profileCoverPhotoId = profileCoverPhotoId;
	}
	
	public String getSearchOrgStr()
	{
		return searchOrgStr;
	}
	public void setSearchOrgStr(String searchOrgStr)
	{
		this.searchOrgStr = searchOrgStr;
	}
	
	public String getOrgProfilePhotoId() {
		return orgProfilePhotoId;
	}
	public void setOrgProfilePhotoId(String orgProfilePhotoId) {
		this.orgProfilePhotoId = orgProfilePhotoId;
	}
	public String getOrgCoverPhotoId() {
		return orgCoverPhotoId;
	}
	public void setOrgCoverPhotoId(String orgCoverPhotoId) {
		this.orgCoverPhotoId = orgCoverPhotoId;
	}
	public static long getSerialversionuid()
	{
		return serialVersionUID;
	}
	@Override
	public String toString() 
	{
		return "OrganizationBasicInformationVo [organizationId=" + organizationId + ", organizationName="
				+ organizationName + ", primaryHeadquarter=" + primaryHeadquarter + ", leaderName=" + leaderName
				+ ", dateOfCreation=" + dateOfCreation + ", primaryLocation=" + primaryLocation + ", primaryPhoneNo="
				+ primaryPhoneNo + ", primaryEmailId=" + primaryEmailId + ", primaryTwitterId=" + primaryTwitterId
				+ ", primaryFacebookId=" + primaryFacebookId + ", bankAccountNo=" + bankAccountNo + ", userDescription="
				+ userDescription + ", loginId=" + loginId + ", orgAlias=" + orgAlias + ", profilePhotoId="
				+ profilePhotoId + ", profileCoverPhotoId=" + profileCoverPhotoId + ", searchOrgStr=" + searchOrgStr
				+ ", orgProfilePhotoId=" + orgProfilePhotoId + ", orgCoverPhotoId="
				+ orgCoverPhotoId + "]";
	}
	
}
