package com.cdac.sudarshan.folderManagement.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class FolderRequestDto {
    @NotBlank(message = "Folder name can not be empty.")
    private String folderName;
    @NotNull(message = "Folder ID can not be empty.")
    private Long parentfolderId;
    private Integer status;
    private Long userId;
    private Integer statusRef;
}
