package com.cdac.sudarshan.folder.service;

import com.cdac.sudarshan.authentication.model.User;
import com.cdac.sudarshan.authentication.service.IUserService;
import com.cdac.sudarshan.exception.PathNotFoundException;
import com.cdac.sudarshan.exception.ResourceNotFoundException;
import com.cdac.sudarshan.folder.dto.RequestDto;
import com.cdac.sudarshan.folder.dto.UrlResponseDto;
import com.cdac.sudarshan.folder.model.Analytics;
import com.cdac.sudarshan.folder.model.RootFolder;
import com.cdac.sudarshan.folder.model.SubFolderPaths;
import com.cdac.sudarshan.folder.model.UrlsPath;
import com.cdac.sudarshan.folder.repository.AnalyticsRepository;
import com.cdac.sudarshan.folder.repository.RootFolderRepo;
import com.cdac.sudarshan.folder.repository.SubFolderPathsRepo;
import com.cdac.sudarshan.folder.repository.UrlsPathRepo;
import com.cdac.sudarshan.utils.Data;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.ObjectWriter;
import org.codehaus.jackson.type.TypeReference;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class UrlsPathServiceImpl implements IUrlsPathService {

    @Autowired
    private UrlsPathRepo urlsPathRepo;
    @Autowired
    private IUserService userService;
    @Autowired
    private RootFolderRepo rootFolderRepo;
    @Autowired
    private SubFolderPathsRepo subFolderPathsRepo;
    @Autowired
    private RestTemplate template;
    @Value("${Media_Download}")
    private String mediaDownloadUrl;

//    @Value("${kafka_Service}")
//    private String kafkaService;

    @Autowired
    private AnalyticsRepository analyticsRepository;
    int offset = 0;

    @Override
    public List<UrlResponseDto> addUrls(String path, List<Data> urlAndSource) throws IOException {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        User loggedInUser = userService.getUserByUserName(authentication.getName());

        if (loggedInUser == null) {
            throw new ResourceNotFoundException("Please Login first For adding add url");
        }

        List<UrlsPath> listOfUrls = new ArrayList<>();
        List<Data> duplicateUrlList = new ArrayList<>();
        //
        List<String> articleIdList = new ArrayList<>();

        String[] folderNames = path.split("/");
        List<String> subFolderNames = new ArrayList<>();
        for (String folder : folderNames) {
            if (!folder.equals("")) {
                subFolderNames.add(folder);
            }
        }

        // checking input path having root folder exists or not
        RootFolder rootFolder = rootFolderRepo.findByRootFolderNameAndUser(subFolderNames.get(0), loggedInUser);
        if (rootFolder == null) {
            throw new ResourceNotFoundException("No root Folder for this given path");
        }


        List<UrlsPath> saveAllData = new ArrayList<UrlsPath>();

        List<UrlResponseDto> urlsAndSource = new ArrayList<UrlResponseDto>();

        Long databaseUserId = rootFolder.getUser().getId();

        if (Objects.equals(databaseUserId, loggedInUser.getId())) {

            // check input is root folder or not
            if (subFolderNames.size() == 1) {
                for (Data data : urlAndSource) {
                    UrlsPath urlObj = urlsPathRepo.findByRootFolderIdAndUrl(rootFolder.getId(), data.getUrl());
                    if (urlObj == null) {
                        //for (Data data : urlAndSource) {
                        UrlsPath urlsPath = new UrlsPath();
                        urlsPath.setRootFolderId(rootFolder.getId());
                        urlsPath.setSubFolderPaths(null);
                        urlsPath.setUrl(data.getUrl());
                        urlsPath.setSource(data.getSource());
                        urlsPath.setStatus(true);
                        //adding tag of data
                        urlsPath.setTag(data.getTag());
                        listOfUrls.add(urlsPath);

                    } else {
                        duplicateUrlList.add(data);
                        continue;
                    }
                }
            } else {

//                SubFolderPaths subFolderPath = subFolderPathsRepo.findBySubFolderPathAndFolderPath(path, rootFolder);
                SubFolderPaths subFolderPath = subFolderPathsRepo.findBySubFolderPathAndFolderPathAndStatus(path, rootFolder, true);


                if (subFolderPath == null || !subFolderPath.isStatus()) {
                    throw new ResourceNotFoundException("No Sub Folder for this given path");
                }

                for (Data data : urlAndSource) {

                    // Check urls is already present or not
                    UrlsPath urlObj = urlsPathRepo.findBySubFolderIdAndUrl(subFolderPath.getId(), data.getUrl());

                    if (urlObj == null) {
                        UrlsPath urlsPath = new UrlsPath();
                        urlsPath.setSubFolderPaths(subFolderPath);
                        //urlsPath.setRootFolderId(rootFolder.getId());
                        urlsPath.setUrl(data.getUrl());
                        urlsPath.setStatus(true);
                        //adding tag of data
                        urlsPath.setTag(data.getTag());
                        urlsPath.setSource(data.getSource());
                        listOfUrls.add(urlsPath);
                    } else {
                        duplicateUrlList.add(data);
                        continue;
                    }

                }
            }

//            for (UrlsPath urlPath : listOfUrls) {
//                articleIdList.add(urlPath.getUrl());
//            }
//
//            List<Analytics> analyticList = analyticsRepository.findByArticleIdIn(articleIdList);
//            for(Analytics analytics:analyticList){
//                //add those analytics ony that analytics failed
//                if(!(analytics.getNer().equalsIgnoreCase("failed") || !analytics.getCoref().equalsIgnoreCase("failed")
//                        || !analytics.getSummary().equalsIgnoreCase("failed")||
//                        !analytics.getSentiment().equalsIgnoreCase("failed")
//                        || !analytics.getDomain_identification().equalsIgnoreCase("failed") || !analytics.getRelation_extraction().equalsIgnoreCase("failed"))){
//                    articleIdList.removeIf(analytics.getArticleId()::contains);
//                }
//            }
//            //call kafka service to store articleIds is kafka queue
//            if (!articleIdList.isEmpty()) {
//                ResponseEntity<String> stringResponseEntity = template.postForEntity(kafkaService + "/kafka/publish", articleIdList, String.class);
//            }

            //after successfully saved article id into kafka queue finally call db service to save urls in db

            saveAllData = urlsPathRepo.saveAll(listOfUrls);

        }
        if (!saveAllData.isEmpty()) {
            for (int i = 0; i < saveAllData.size(); i++) {
                UrlResponseDto data = new UrlResponseDto();
                data.setUrl(saveAllData.get(i).getUrl());
                data.setSource(saveAllData.get(i).getSource());
                data.setTag(saveAllData.get(i).getTag());
                if (i == 0) {
                    data.setDuplicateUrlCount(duplicateUrlList.size());
                    data.setTotalUrlCount(urlAndSource.size());
                }
                urlsAndSource.add(data);
            }
        } else {
            UrlResponseDto data = new UrlResponseDto();
            data.setDuplicateUrlCount(duplicateUrlList.size());
            data.setTotalUrlCount(urlAndSource.size());
            urlsAndSource.add(data);
        }
        return urlsAndSource;

    }

    /***
     * @Ajay
     * Method to SAVE IMAGE and VIDEO in urls_paths.
     * @param path
     * @param urlAndSource
     * @return
     */
    public List<UrlResponseDto> addMediaUrls(String path, List<Data> urlAndSource) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        User loggedInUser = userService.getUserByUserName(authentication.getName());

        if (loggedInUser == null) {
            throw new ResourceNotFoundException("Please Login first For adding add url");
        }

        List<Data> duplicateMediaUrlList = new ArrayList<>();
        List<UrlsPath> listOfUrls = new ArrayList<>();

        String[] folderNames = path.split("/");
        List<String> subFolderNames = new ArrayList<>();
        for (String folder : folderNames) {
            if (!folder.equals("")) {
                subFolderNames.add(folder);
            }
        }

        // checking input path having root folder exists or not
        RootFolder rootFolder = rootFolderRepo.findByRootFolderNameAndUser(subFolderNames.get(0), loggedInUser);
        if (rootFolder == null) {
            throw new ResourceNotFoundException("No root Folder for this given path");
        }

        List<UrlsPath> saveAllData = new ArrayList<UrlsPath>();

        List<UrlResponseDto> urlsAndSource = new ArrayList<>();

        Long databaseUserId = rootFolder.getUser().getId();

        if (databaseUserId == loggedInUser.getId()) {

            // check input is root folder or not
            if (subFolderNames.size() == 1) {
                for (int j = 0; j < urlAndSource.size(); j++) {
                    UrlsPath urlObj = urlsPathRepo.findByRootFolderIdAndUrl(rootFolder.getId(), urlAndSource.get(j).getUrl());
                    if (urlObj == null) {
                        //for (Data data : urlAndSource) {
                        UrlsPath urlsPath = new UrlsPath();
                        urlsPath.setRootFolderId(rootFolder.getId());
                        urlsPath.setSubFolderPaths(null);
                        urlsPath.setUrl(urlAndSource.get(j).getUrl());
                        urlsPath.setSource(urlAndSource.get(j).getSource());
                        urlsPath.setTag(urlAndSource.get(j).getTag());
                        urlsPath.setStatus(true);
                        String mediaLocalPath = downloadMedia(urlAndSource.get(j), loggedInUser);
                        if (mediaLocalPath.isEmpty() || mediaLocalPath.isBlank()) {
                            throw new ResourceNotFoundException("Facing issues to download media...!!!");
                        }
                        urlsPath.setResourcePath(mediaLocalPath);
                        listOfUrls.add(urlsPath);

                    } else {
                        duplicateMediaUrlList.add(urlAndSource.get(j));
                        continue;
                    }
                }
            } else {

//                SubFolderPaths subFolderPath = subFolderPathsRepo.findBySubFolderPathAndFolderPath(path, rootFolder);
                SubFolderPaths subFolderPath = subFolderPathsRepo.findBySubFolderPathAndFolderPathAndStatus(path, rootFolder, true);


                if (subFolderPath == null) {
                    throw new ResourceNotFoundException("No Sub Folder for this given path");
                }

                for (Data data : urlAndSource) {

                    // Check urls is already present or not
                    UrlsPath urlObj = urlsPathRepo.findBySubFolderIdAndUrl(subFolderPath.getId(), data.getUrl());

                    if (urlObj == null) {
                        UrlsPath urlsPath = new UrlsPath();
                        urlsPath.setSubFolderPaths(subFolderPath);
                        urlsPath.setUrl(data.getUrl());
                        urlsPath.setTag(data.getTag());
                        urlsPath.setSource(data.getSource());
                        String mediaLocalPath = downloadMedia(data, loggedInUser);
                        if (mediaLocalPath.isEmpty() || mediaLocalPath.isBlank()) {
                            throw new ResourceNotFoundException("Facing issues to download media...!!!");
                        }
                        urlsPath.setResourcePath(mediaLocalPath);
                        urlsPath.setStatus(true);
                        listOfUrls.add(urlsPath);
                    } else {
                        duplicateMediaUrlList.add(data);
                        continue;
                    }

                }
            }
            if (!listOfUrls.isEmpty()) {
                saveAllData = urlsPathRepo.saveAll(listOfUrls);
            }

        }

        if (!saveAllData.isEmpty()) {
            for (int i = 0; i < saveAllData.size(); i++) {
                UrlResponseDto data = new UrlResponseDto();
                data.setUrl(saveAllData.get(i).getUrl());
                data.setSource(saveAllData.get(i).getSource());
                data.setTag(saveAllData.get(i).getTag());
                data.setResourcePath(saveAllData.get(i).getResourcePath());
                if (i == 0) {
                    data.setDuplicateUrlCount(duplicateMediaUrlList.size());
                    data.setTotalUrlCount(urlAndSource.size());
                }
                urlsAndSource.add(data);
            }
        } else {
            UrlResponseDto data = new UrlResponseDto();
            data.setDuplicateUrlCount(duplicateMediaUrlList.size());
            data.setTotalUrlCount(urlAndSource.size());
            urlsAndSource.add(data);
        }


        return urlsAndSource;

    }

    //@Ajay
    private String downloadMedia(Data urlAndSource, User loggedInUser) {
        HashMap<String, Object> data = new HashMap<>();

        data.put("user", loggedInUser.getId().toString());
        data.put("link", urlAndSource.getLink());
        data.put("source", urlAndSource.getSource());
        data.put("articleId", urlAndSource.getUrl());

        //checking tag is img or vid
        if (urlAndSource.getTag().equals("img")) {
            data.put("imageName", urlAndSource.getImageName());
            data.put("image_type", urlAndSource.getTag());
        } else {
            data.put("videoName", urlAndSource.getImageName());
            data.put("video_type", urlAndSource.getTag());
        }
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<>(data, headers);
        ResponseEntity<Object> result = template.exchange(mediaDownloadUrl,
                HttpMethod.POST, entity, Object.class);

        // convert into jasonArray
        Gson gson = new GsonBuilder().serializeNulls().create();
        String path = gson.toJson(result.getBody());

/*		JsonArray jsonArray = (JsonArray) new JsonParser().parse(stringJson);

		for(int j=0;j<jsonArray.size();j++){
			String path = jsonArray.get(0).getAsJsonObject().get("path").getAsString();
			return path;
		}*/

        return path.replace("\"", "");
    }

    public List<UrlResponseDto> addProfileUrls(String path, List<Data> urlAndSource) {

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication.getName() == null) {
            throw new ResourceNotFoundException("Please Login first For adding folder");
        }
        User loggedInUser = userService.getUserByUserName(authentication.getName());

        List<UrlsPath> listOfUrls = new ArrayList<>();
        List<Data> duplicateUrlList = new ArrayList<>();

        String[] folderNames = path.split("/");
        List<String> subFolderNames = new ArrayList<>();
        for (String folder : folderNames) {
            if (!folder.equals("")) {
                subFolderNames.add(folder);
            }
        }

        // checking input path having root folder exists or not
        RootFolder rootFolder = rootFolderRepo.findByRootFolderNameAndUser(subFolderNames.get(0), loggedInUser);
        if (rootFolder == null) {
            throw new ResourceNotFoundException("No root Folder for this given path");
        }


        List<UrlsPath> saveAllData = new ArrayList<UrlsPath>();

        List<UrlResponseDto> urlsAndSource = new ArrayList<UrlResponseDto>();

        Long databaseUserId = rootFolder.getUser().getId();

        if (databaseUserId == loggedInUser.getId()) {

            // check input is root folder or not
            if (subFolderNames.size() == 1) {
                for (int j = 0; j < urlAndSource.size(); j++) {
                    // Check urls is already present or not
                    UrlsPath urlObj = urlsPathRepo.findByRootFolderIdAndProfileId(rootFolder.getId(), urlAndSource.get(j).getProfileId());
                    if (urlObj == null) {
                        //for (Data data : urlAndSource) {
                        UrlsPath urlsPath = new UrlsPath();
                        urlsPath.setRootFolderId(rootFolder.getId());
                        urlsPath.setSubFolderPaths(null);
                        urlsPath.setUrl(null);
                        urlsPath.setSource(urlAndSource.get(j).getSource());
                        urlsPath.setStatus(true);
                        //adding tag of data
                        urlsPath.setTag(urlAndSource.get(j).getTag());
                        urlsPath.setProfileId(urlAndSource.get(j).getProfileId());
                        listOfUrls.add(urlsPath);
                    } else {
                        duplicateUrlList.add(urlAndSource.get(j));
                        continue;
                    }
                }
            } else {

//                SubFolderPaths subFolderPath = subFolderPathsRepo.findBySubFolderPathAndFolderPath(path, rootFolder);
                SubFolderPaths subFolderPath = subFolderPathsRepo.findBySubFolderPathAndFolderPathAndStatus(path, rootFolder, true);


                if (subFolderPath == null) {
                    throw new ResourceNotFoundException("No Sub Folder for this given path");
                }

                for (int i = 0; i < urlAndSource.size(); i++) {

                    // Check urls is already present or not
                    UrlsPath urlObj = urlsPathRepo.findBySubFolderIdAndProfileId(subFolderPath.getId(), urlAndSource.get(i).getProfileId());

                    if (urlObj == null) {
                        UrlsPath urlsPath = new UrlsPath();
                        urlsPath.setSubFolderPaths(subFolderPath);
                        //urlsPath.setRootFolderId(rootFolder.getId());
                        urlsPath.setUrl(null);
                        urlsPath.setStatus(true);
                        //adding tag of data
                        urlsPath.setTag(urlAndSource.get(i).getTag());
                        urlsPath.setProfileId(urlAndSource.get(i).getProfileId());
                        urlsPath.setSource(urlAndSource.get(i).getSource());
                        listOfUrls.add(urlsPath);
                    } else {
                        duplicateUrlList.add(urlAndSource.get(i));
                        continue;
                    }

                }
            }
            saveAllData = urlsPathRepo.saveAll(listOfUrls);
        }


        if (!saveAllData.isEmpty()) {
            for (int i = 0; i < saveAllData.size(); i++) {
                UrlResponseDto data = new UrlResponseDto();
                data.setSource(saveAllData.get(i).getSource());
                data.setTag(saveAllData.get(i).getTag());
                data.setProfileId(saveAllData.get(i).getProfileId());
                if (i == 0) {
                    data.setDuplicateUrlCount(duplicateUrlList.size());
                    data.setTotalUrlCount(urlAndSource.size());
                }
                urlsAndSource.add(data);
            }
        } else {
            UrlResponseDto data = new UrlResponseDto();
            data.setDuplicateUrlCount(duplicateUrlList.size());
            data.setTotalUrlCount(urlAndSource.size());
            urlsAndSource.add(data);
        }

        return urlsAndSource;

    }


    public List<UrlsPath> getBySubfolderId(Long subFolderId) {

        SubFolderPaths subFolderPath = subFolderPathsRepo.findById(subFolderId)
                .orElseThrow(() -> new ResourceNotFoundException("Subfolder not found with given path"));
        List<UrlsPath> listOfUrls = urlsPathRepo.findBySubFolderPaths(subFolderPath);

        return listOfUrls;
    }

    @Override
    public ResponseEntity<?> deleteUrlsData(RequestDto requestDto) {

        Map<String, Object> response = new HashMap<>();

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication.getName() == null) {
            throw new ResourceNotFoundException("Please Login first For deleting data");
        }
        User loggedInUser = userService.getUserByUserName(authentication.getName());

        String msg = "";

        String[] folderNames = requestDto.getPath().split("/");
        List<String> subFolderNames = new ArrayList<>();
        for (String folder : folderNames) {
            if (!folder.equals("")) {
                subFolderNames.add(folder);
            }
        }

        RootFolder rootFolder = rootFolderRepo.findByRootFolderNameAndUser(subFolderNames.get(0), loggedInUser);

        if (rootFolder == null) {
            throw new PathNotFoundException("Root folder is not exists for given path...!");
        }

        SubFolderPaths subFolder = subFolderPathsRepo.findBySubFolderPath(requestDto.getPath());

        List<UrlsPath> urlsPathList = new ArrayList<>();

        if (subFolderNames.size() == 1) {
            //for root-folder
            if (requestDto.getTag().equals("pr")) {
                //deleting operation for for profile data
                urlsPathList = urlsPathRepo.findByProfileAndRooFolderId(requestDto.getProfileIds(), rootFolder.getId());
            } else {
                //deleting operation for post and article data
                urlsPathList = urlsPathRepo.findByUrlsAndRooFolderId(requestDto.getUrls(), rootFolder.getId());
            }
        } else if (subFolder != null) {
            // for subfolder
            if (requestDto.getTag().equals("pr")) {
                //deleting operation for for profile data
                urlsPathList = urlsPathRepo.findByProfileIdAndSubFolderId(requestDto.getProfileIds(), subFolder.getId());
            } else {
                //deleting operation for post and article data
                urlsPathList = urlsPathRepo.findByUrlsAndSubFolderId(requestDto.getUrls(), subFolder.getId());
            }
        } else {
            throw new PathNotFoundException("Subfolder is not exists for given path...!");
        }

        //updating state of url data
        if (!urlsPathList.isEmpty()) {
            List<UrlsPath> deactivatedUrlPathList = urlsPathList.stream().map(urlPath -> {
                urlPath.setStatus(false);
                return urlPath;
            }).collect(Collectors.toList());
            //saved the updated state of urls-path to db
            urlsPathRepo.saveAll(deactivatedUrlPathList);
            msg = "Data deleted Successfully";
        }

        response.put("message", msg);
        response.put("success", true);
        response.put("statusCode", HttpStatus.OK.value());

        return ResponseEntity.status(HttpStatus.OK).body(response);

    }


    //  calling kafka consumer service in time interval
//    @Scheduled(fixedRate = 20000L)
//    public void saveAnalysisDataToDB() throws IOException, InterruptedException {
//
//        //List<Analytics> analyticsList = new ArrayList<>();
//        ResponseEntity<Object> entity = template.getForEntity(kafkaService + "/kafka/consume", Object.class);
//        ObjectMapper mapper = new ObjectMapper();
//        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
//        String json = ow.writeValueAsString(entity.getBody());
//
//        Map<String, Object> map = mapper.readValue(json, new TypeReference<HashMap<String, Object>>() {
//        });
//        List<Analytics> analyticsList = null;
//        //for converting object to int for comparision in if statement
//        int value = mapper.convertValue(map.get("offset"), new TypeReference<Integer>() {
//        });
//
//        if (offset != value) {
//            offset = value;
//            analyticsList = mapper.convertValue(map.get("analytics"), new TypeReference<List<Analytics>>() {
//            });
//        }
//
//        if (analyticsList != null) {
//            analyticsRepository.saveAll(analyticsList);
//        }
//        analyticsList = null;
//
//        Thread.sleep(5000);
//
//    }


    private static String sqlFormatedList(List<String> list) {
        StringBuilder sb = new StringBuilder();
        sb.append("('");
        for (String i : list) {
            sb.append(i).append("','");
        }
        sb.deleteCharAt(sb.length() - 1);
        sb.deleteCharAt(sb.lastIndexOf(","));
        sb.append(")");
        return sb.toString();
    }


}
