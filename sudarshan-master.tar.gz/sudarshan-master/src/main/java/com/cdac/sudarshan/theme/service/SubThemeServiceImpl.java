package com.cdac.sudarshan.theme.service;

import com.cdac.sudarshan.authentication.model.User;
import com.cdac.sudarshan.authentication.service.IUserService;
import com.cdac.sudarshan.exception.DataAlreadyFoundException;
import com.cdac.sudarshan.exception.PathNotFoundException;
import com.cdac.sudarshan.exception.ResourceNotFoundException;
import com.cdac.sudarshan.theme.dto.SubThemeDto;
import com.cdac.sudarshan.theme.model.SubTheme;
import com.cdac.sudarshan.theme.model.Theme;
import com.cdac.sudarshan.theme.repository.ISubThemeRepository;
import com.cdac.sudarshan.theme.repository.IThemeRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class SubThemeServiceImpl implements ISubThemeService {

    @Autowired
    private IUserService userService;

    @Autowired
    private ISubThemeRepository subThemeRepository;

    @Autowired
    private IThemeRepository themeRepository;

    @Autowired
    private ModelMapper modelMapper;


    @Override
    public List<SubThemeDto> addSubThemeToRootTheme(String path) {

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication.getName() == null) {
            throw new ResourceNotFoundException("Please Login first For adding sub theme");
        }

        User loggedInUser = userService.getUserByUserName(authentication.getName());

        //getting path of sub-theme
        String subThemePath = path;
        String pathFilter = subThemePath.replaceAll("/", "");

        if (subThemePath.isEmpty() || pathFilter.isEmpty() || !subThemePath.endsWith("/")) {
            throw new PathNotFoundException("Please enter valid path or path is empty");
        }

        String[] themesNames = subThemePath.split("/");
        List<String> subThemes = new ArrayList<>();
        for (String theme : themesNames) {
            if (!theme.equals("")) {
                subThemes.add(theme);
            }
        }

        // Check root theme exist or not
        Theme rootTheme = themeRepository.findByThemePathAndUser(subThemes.get(0), loggedInUser);
        if (rootTheme == null) {
            throw new PathNotFoundException("Please add theme first then add sub-theme");
        }

        // Check sub-theme is already exist or not
        List<SubTheme> subThemeList = subThemeRepository.findByTheme(rootTheme);
        for (int i = 0; i < subThemeList.size(); i++) {
            String subThemeName = subThemeList.get(i).getSubThemePath();
            if (subThemeName.equalsIgnoreCase(subThemePath)
                    && subThemeList.get(i).getTheme().getId() == rootTheme.getId()) {
                throw new DataAlreadyFoundException("Sub theme already exist for given theme");
            }
        }

        int i = 1;
        int size = subThemes.size() - 1;
        String mainPath = "/" + subThemes.get(0) + "/";
        List<SubTheme> subThemes1 = new ArrayList<>();

        for (String s : subThemes) {
            if (i > size) {
                break;
            }
            SubTheme subTheme = new SubTheme();
            subTheme.setTheme(rootTheme);
            mainPath = mainPath + subThemes.get(i) + "/";
            subTheme.setSubThemePath(mainPath);
            String[] subTh = mainPath.split("/");

            if (subTh.length < 4) {
                String[] spl = mainPath.split("/");
                String s2 = spl[1];
                Theme rootThemeObj = themeRepository.findByThemePathAndUser(s2, loggedInUser);
                subTheme.setParentSubThemeId(rootThemeObj.getId());
            } else {
                SubTheme subThemeObj = getParentSubThemeByName(mainPath);
                subTheme.setParentSubThemeId(subThemeObj.getId());
            }
            subThemes1.add(subTheme);
            i++;
        }

        List<SubTheme> uniqueSubThemes = new ArrayList<>();
        for (int j = 0; j < subThemes1.size(); j++) {
            Long rootThemeId = subThemes1.get(j).getTheme().getId();
            SubTheme uniqueData = subThemeRepository
                    .findBySubThemePathAndRootThemeId(subThemes1.get(j).getSubThemePath(), rootThemeId);
            if (uniqueData == null) {
                uniqueSubThemes.add(subThemes1.get(j));
            }
        }

        List<SubTheme> savedSubThemes = subThemeRepository.saveAll(uniqueSubThemes);


        return savedSubThemes.stream().map(subTheme -> modelMapper.map(subTheme, SubThemeDto.class)).collect(Collectors.toList());
    }

    public List<SubTheme> getAllSubThemeOfRootTheme(String path) {

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication.getName() == null) {
            throw new ResourceNotFoundException("Please Login first For adding sub theme");
        }

        //getting path of sub-theme
        String subThemePath = path;
        String pathFilter = subThemePath.replaceAll("/", "");

        if (subThemePath.isEmpty() || pathFilter.isEmpty() || !subThemePath.startsWith("/") || !subThemePath.endsWith("/")) {
            throw new PathNotFoundException("Please enter valid path or path is empty");
        }

        List<SubTheme> subThemeList = null;
        SubTheme subThemeByRootTheme = null;
        List<Map<String, String>> dtos = new ArrayList<>();


        String[] themesNames = subThemePath.split("/");
        List<String> subThemes = new ArrayList<>();
        for (String theme : themesNames) {
            if (!theme.equals("")) {
                subThemes.add(theme);
            }
        }

        String rootThemePathName = path.replace("/", "");

        List<Theme> rootThemes = themeRepository.findByThemePath(subThemes.get(0));

        if (rootThemes.isEmpty()) {
            throw new PathNotFoundException(subThemes.get(0) + " Theme is not present");
        }

        if (!rootThemes.isEmpty() && subThemes.size() > 1) {

            List<Theme> rootThemes1 = themeRepository.findByThemePath(subThemes.get(0));

            if (rootThemes1.isEmpty()) {
                throw new PathNotFoundException("Please Enter valid Path...!");
            }

            subThemeByRootTheme = subThemeRepository.findBySubThemePathAndRootThemeId(path,
                    rootThemes1.get(0).getId());

            if (subThemeByRootTheme == null) {
                throw new PathNotFoundException("Please Enter valid Path...!");
            }

            Long subThemeId = subThemeByRootTheme.getId();

            subThemeList = subThemeRepository.findByParentSubThemeId(subThemeId);

        } else {
            //  Long rootThemeID = rootThemes.get(0).getId();
            subThemeList = subThemeRepository.findByParentSubThemeId(rootThemes.get(0).getId());
        }

        return subThemeList;

    }

    private SubTheme getParentSubThemeByName(String subThemeName) {
        String replacedOutput = subThemeName.replace("[a-zA-Z0-9\\s]+/$", "");
        String result = replacedOutput.replace("/$", "");
        String s1 = subThemeName.substring(0,
                subThemeName.substring(0, subThemeName.lastIndexOf("/")).lastIndexOf("/") + 1);
        return subThemeRepository.findBySubThemePath(s1);

        // return subFolderPathsRepo.findBySubFolderPathName(s1[0]);

    }

}
