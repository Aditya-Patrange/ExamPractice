package com.cdac.sudarshan.discover.controller;

import java.util.HashMap;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.cdac.sudarshan.discover.model.TweeterActionVo;
import com.cdac.sudarshan.discover.service.KISourceService;

@ResponseStatus(HttpStatus.OK)
@Controller
@RequestMapping("/eva")
@CrossOrigin("*")
public class ReportController {
	@Autowired
	private KISourceService sourceService;
	
	@PostMapping("/exportExcelDashboardWidgetData")
	public HttpEntity<?> exportExcelDashboardWidgetData(@RequestBody TweeterActionVo tweeterActionVo, HttpServletResponse response) throws Exception
	{
		return sourceService.exportExcelDashboardWidgetData(tweeterActionVo, response);
	}
	
	
	@PostMapping("/ExportITextMediasRpt")
	public HttpEntity<?> ExportITextMediasRpt(@RequestBody TweeterActionVo tweeterActionVo) throws Exception
	{
		return new ResponseEntity<>(sourceService.ExportITextMediasRpt(tweeterActionVo), HttpStatus.OK);
	}
	
}
