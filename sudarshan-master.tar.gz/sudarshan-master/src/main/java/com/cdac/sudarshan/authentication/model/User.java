package com.cdac.sudarshan.authentication.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.cdac.sudarshan.code.model.Code;
import com.cdac.sudarshan.folder.model.RootFolder;
import com.cdac.sudarshan.theme.model.Theme;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

@Entity
@Table(name = "app_user")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
//@ToString
public class User {

	@Id
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "username", unique = true, nullable = false)
	private String username;

	@Column(name = "password_hash")
	private String passwordHash;

	@Column(name = "secret", length = 20)
	private String secret;

	@Column(name = "enabled", nullable = false)
	private Boolean enabled;

	@Column(name = "additional_security", nullable = false)
	private Boolean additionalSecurity;

	@Column(name = "back_up_codes")
	@OneToMany(mappedBy = "user")
	@JsonIgnore
	private List<Code> codes = new ArrayList<>();

	@OneToMany(mappedBy = "user")
	@JsonIgnore
	private List<RootFolder> rootFolders = new ArrayList<RootFolder>();

	@OneToMany(mappedBy = "user")
	@JsonIgnore
	private List<Theme> themes = new ArrayList<>();

	@Transient
	private boolean totp;

	@Transient
	private String password;

	@Transient
	private String captcha;

	@Transient
	private String hiddenCaptcha;

	@Transient
	private String realCaptcha;

	@CreationTimestamp
	private LocalDateTime creationDate;

	@UpdateTimestamp
	private LocalDateTime lastUpdatedDate;

	public User(String username, String passwordHash, String secret, Boolean enabled, Boolean additionalSecurity) {
		this.username = username;
		this.passwordHash = passwordHash;
		this.secret = secret;
		this.enabled = enabled;
		this.additionalSecurity = additionalSecurity;
	}

	public User(String username, String passwordHash, String secret, Boolean enabled, Boolean additionalSecurity,
			List<Code> codes) {
		this.username = username;
		this.passwordHash = passwordHash;
		this.secret = secret;
		this.enabled = enabled;
		this.additionalSecurity = additionalSecurity;
		this.codes = codes;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", username=" + username + ", passwordHash=" + passwordHash + ", secret=" + secret
				+ ", enabled=" + enabled + ", additionalSecurity=" + additionalSecurity + ", totp=" + totp
				+ ", password=" + password + ", captcha=" + captcha + ", hiddenCaptcha=" + hiddenCaptcha
				+ ", realCaptcha=" + realCaptcha + "]";
	}
	
	

}
