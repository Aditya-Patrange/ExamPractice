package com.cdac.sudarshan.code.service;

import java.util.List;

import com.cdac.sudarshan.authentication.model.User;
import com.cdac.sudarshan.code.model.Code;

public interface ICodeService {

	void saveCode(List<Code> code);

	List<Code> getSecurityCode(User user)throws Exception;

	List<Code> getScurityCodeOfUser(String username);

}
