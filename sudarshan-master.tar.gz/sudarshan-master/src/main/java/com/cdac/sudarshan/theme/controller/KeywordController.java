package com.cdac.sudarshan.theme.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cdac.sudarshan.theme.service.IKeywordService;

import java.util.Map;

@RestController
@RequestMapping("keywords")
public class KeywordController {

    @Autowired
    private IKeywordService keywordService;

    @PostMapping("/saveKeyword")
    public ResponseEntity<?> saveKeywords(@RequestBody Map<String,Object> map) {
        return ResponseEntity.ok(keywordService.saveKeywords(map.get("keywords"), String.valueOf(map.get("path"))));
    }

    @PostMapping("/getKeywords")
    public ResponseEntity<?> getKeywords(@RequestBody Map<String,String> map) {
        return ResponseEntity.ok(keywordService.getKeywords(map.get("path")));
    }



}
