package com.cdac.sudarshan.discover.common;

import java.io.Serializable;

public class UserProfileContactVo implements Serializable
{
	private static final long serialVersionUID = 1L;
	
	private int contactId;
	private int profileId; 
	private String contact;
	private String contactType;
	private String contactPrimary;
	
	public int getContactId() 
	{
		return contactId;
	}
	public void setContactId(int contactId)
	{
		this.contactId = contactId;
	}
	public int getProfileId()
	{
		return profileId;
	}
	public void setProfileId(int profileId) 
	{
		this.profileId = profileId;
	}
	public String getContact() 
	{
		return contact;
	}
	public void setContact(String contact) 
	{
		this.contact = contact;
	}
	public String getContactType() 
	{
		return contactType;
	}
	public void setContactType(String contactType) 
	{
		this.contactType = contactType;
	}
	public String getContactPrimary()
	{
		return contactPrimary;
	}
	public void setContactPrimary(String contactPrimary) 
	{
		this.contactPrimary = contactPrimary;
	}
	public static long getSerialversionuid() 
	{
		return serialVersionUID;
	}
	
	@Override
	public String toString() 
	{
		return "UserProfileContactVo [contactId=" + contactId + ", profileId=" + profileId + ", contact=" + contact
				+ ", contactType=" + contactType + ", contactPrimary=" + contactPrimary + "]";
	}
	
}
