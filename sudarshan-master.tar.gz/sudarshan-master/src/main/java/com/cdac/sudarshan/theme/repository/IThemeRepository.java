package com.cdac.sudarshan.theme.repository;

import com.cdac.sudarshan.authentication.model.User;
import com.cdac.sudarshan.theme.model.Theme;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IThemeRepository extends JpaRepository<Theme,Long> {

    Theme findByThemePathAndUser(String themePath, User user);
    List<Theme> findByUser(User user);
    // Its Not userSpecific
    List<Theme> findByThemePath(String themePath);
}
