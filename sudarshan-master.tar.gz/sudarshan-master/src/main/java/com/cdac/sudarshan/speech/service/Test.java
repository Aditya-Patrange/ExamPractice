package com.cdac.sudarshan.speech.service;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.springframework.core.io.FileSystemResource;

public class Test {

	public static void main(String[] args) {
//		
//		newfile = (new FileSystemResource(
//				youTubeStoragePath + (new StringBuffer((file.getFilename().replaceAll("[^a-zA-Z0-9.]", "_"))).setCharAt(indexes.get(indexes.size()-1), '.')))).getFile();
//		
//		(new StringBuffer((file.getFilename().replaceAll("[^a-zA-Z0-9.]", "_"))).setCharAt(indexes.get(indexes.size()-1), '.'));
//		
		String word = "abc.pq.sttj...txt";
		char search = '.';
		//To get List of indexes:
		List<Integer> indexes = IntStream.range(0, word.length())
		        .filter(i -> word.charAt(i) == search).boxed()
		        .collect(Collectors.toList());

		String d = word.replaceAll("[^a-zA-Z0-9]", "_");
		
//        StringBuffer string = new StringBuffer(d);
//        string.setCharAt(indexes.get(indexes.size()-1), '.');
		
//		String fileName = file.getFilename().replaceAll("[^a-zA-Z0-9.]", "_");
//		fileName = fileName.substring(0, indexes.get(indexes.size()-1)) + '.'+ fileName.substring(indexes.get(indexes.size()-1) + 1);
		
		d = d.substring(0, indexes.get(indexes.size()-1)) + '.'
	              + d.substring(indexes.get(indexes.size()-1) + 1);


		
	}

}
