package com.cdac.sudarshan.discover.model;

import java.io.Serializable;

public class Article_GoogleBlogger implements Serializable 
{
	private static final long serialVersionUID = 1L;
	private int blogCommentCount;
	private String bloggerIdBg;
	private String bloggerNameBg;
	private String bloggerDescriptionBg;
	private String bloggerPublishedBg;
	private String bloggerUpdatedBg;
	private String bloggerUrlBg;
	private String bloggerSelfLinkBg;
	private String bloggerLanguageBg;
	private String bloggerCountryBg;
	private int bloggerPostCntBg;
	private int bloggerPageCntBg;
	
	public void setBloggerLanguageBg(String bloggerLanguageBg) {
		this.bloggerLanguageBg = bloggerLanguageBg;
	}
	public void setBloggerCountryBg(String bloggerCountryBg) {
		this.bloggerCountryBg = bloggerCountryBg;
	}
	public int getBlogCommentCount() {
		return blogCommentCount;
	}
	public void setBlogCommentCount(int blogCommentCount) {
		this.blogCommentCount = blogCommentCount;
	}
	public String getBloggerIdBg() {
		return bloggerIdBg;
	}
	public void setBloggerIdBg(String bloggerIdBg) {
		this.bloggerIdBg = bloggerIdBg;
	}
	public String getBloggerNameBg() {
		return bloggerNameBg;
	}
	public void setBloggerNameBg(String bloggerNameBg) {
		this.bloggerNameBg = bloggerNameBg;
	}
	public String getBloggerDescriptionBg() {
		return bloggerDescriptionBg;
	}
	public void setBloggerDescriptionBg(String bloggerDescriptionBg) {
		this.bloggerDescriptionBg = bloggerDescriptionBg;
	}
	public String getBloggerPublishedBg() {
		return bloggerPublishedBg;
	}
	public void setBloggerPublishedBg(String bloggerPublishedBg) {
		this.bloggerPublishedBg = bloggerPublishedBg;
	}
	public String getBloggerUpdatedBg() {
		return bloggerUpdatedBg;
	}
	public void setBloggerUpdatedBg(String bloggerUpdatedBg) {
		this.bloggerUpdatedBg = bloggerUpdatedBg;
	}
	public String getBloggerUrlBg() {
		return bloggerUrlBg;
	}
	public void setBloggerUrlBg(String bloggerUrlBg) {
		this.bloggerUrlBg = bloggerUrlBg;
	}
	public String getBloggerSelfLinkBg() {
		return bloggerSelfLinkBg;
	}
	public void setBloggerSelfLinkBg(String bloggerSelfLinkBg) {
		this.bloggerSelfLinkBg = bloggerSelfLinkBg;
	}
	public int getBloggerPostCntBg() {
		return bloggerPostCntBg;
	}
	public void setBloggerPostCntBg(int bloggerPostCntBg) {
		this.bloggerPostCntBg = bloggerPostCntBg;
	}
	public int getBloggerPageCntBg() {
		return bloggerPageCntBg;
	}
	public void setBloggerPageCntBg(int bloggerPageCntBg) {
		this.bloggerPageCntBg = bloggerPageCntBg;
	}
	public String getBloggerLanguageBg() {
		return bloggerLanguageBg;
	}
	public String getBloggerCountryBg() {
		return bloggerCountryBg;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "Article_GoogleBlogger [blogCommentCount=" + blogCommentCount + ", bloggerIdBg=" + bloggerIdBg
				+ ", bloggerNameBg=" + bloggerNameBg + ", bloggerDescriptionBg=" + bloggerDescriptionBg
				+ ", bloggerPublishedBg=" + bloggerPublishedBg + ", bloggerUpdatedBg=" + bloggerUpdatedBg
				+ ", bloggerUrlBg=" + bloggerUrlBg + ", bloggerSelfLinkBg=" + bloggerSelfLinkBg + ", bloggerLanguageBg="
				+ bloggerLanguageBg + ", bloggerCountryBg=" + bloggerCountryBg + ", bloggerPostCntBg="
				+ bloggerPostCntBg + ", bloggerPageCntBg=" + bloggerPageCntBg + "]";
	}
	
}
