package com.cdac.sudarshan.discover.service;

import java.util.Arrays;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

@Service
public class ReportServiceImpl implements SReportService{
	
	
	@Autowired
	private RestTemplate template;
	
	@Value("${localInnefuUrl}")
	private String localInnefuUrl;

    @Override
	public ResponseEntity<?> getHashtagWordCloud(HashMap<String, Object> data) {
    	
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<Object>(data, headers);
		
		ResponseEntity<Object>result= template.exchange(localInnefuUrl + "/getHashtagWordCloud", HttpMethod.POST, entity,
				Object.class);
		String bodyData=result.getBody().toString();
		bodyData=bodyData.replace("word","text");
		bodyData=bodyData.replace("frequency","weight" );
		Gson gson = new Gson();  
		Object body  =  gson.fromJson(bodyData, Object.class); 	
		ResponseEntity<Object> changedJsonData = new ResponseEntity<Object>(body,result.getHeaders(),HttpStatus.OK);
		return changedJsonData;
		
	}
    


	@Override
	public ResponseEntity<?> getMentionWordCloud(HashMap<String, Object> data) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<Object>(data, headers);
		ResponseEntity<Object>result=template.exchange(localInnefuUrl + "/getMentionWordCloud", HttpMethod.POST, entity,
				Object.class);
		String bodyData=result.getBody().toString();
		bodyData=bodyData.replace("word","text");
		bodyData=bodyData.replace("frequency","weight");
		Gson gson=new Gson();
		Object body=gson.fromJson(bodyData, Object.class);
		ResponseEntity<Object> changedJsonData = new ResponseEntity<Object>(body,result.getHeaders(),HttpStatus.OK);
		return changedJsonData;
	}


	@Override
	public ResponseEntity<?> getPersonWordCloud(HashMap<String, Object> data) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<Object>(data, headers);
		
		ResponseEntity<Object>result= template.exchange(localInnefuUrl + "/getPersonWordCloud", HttpMethod.POST, entity,
				Object.class);
		Gson gson = new GsonBuilder().serializeNulls().create();
		String bodyData = gson.toJson(result.getBody());

		bodyData=bodyData.replace("word", "text");
		bodyData=bodyData.replace("frequency", "weight");
		Object body  =  gson.fromJson(bodyData, Object.class); 	 
		ResponseEntity<Object> changedJsonData = new ResponseEntity<Object>(body,result.getHeaders(),HttpStatus.OK);
		return changedJsonData;
		
	}


	@Override
	public ResponseEntity<?> getPlaceWordCloud(HashMap<String, Object> data) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<Object>(data, headers);
		ResponseEntity<Object>result= template.exchange(localInnefuUrl + "/getPlaceWordCloud", HttpMethod.POST, entity,
				Object.class);
		Gson gson = new GsonBuilder().serializeNulls().create();
		String bodyData = gson.toJson(result.getBody());

		bodyData=bodyData.replace("word", "text");
		bodyData=bodyData.replace("frequency", "weight");
		Object body  =  gson.fromJson(bodyData, Object.class); 	 
		ResponseEntity<Object> changedJsonData = new ResponseEntity<Object>(body,result.getHeaders(),HttpStatus.OK);
		return changedJsonData;
		
		
	}



	

}
