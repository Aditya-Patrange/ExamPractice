package com.cdac.sudarshan.discover.model;

public class Fb_OutputVo
{
	private String fb_user_id;
	private String basic_info,profile_overview,life_events;
	private String contactType,head;
	private String education_work;
	private String edu_type;
	private String family_info;
	private String family_type;
	private String member_rel;
	private String member_img;
	private String place;
	private String palce_type;
	private String user_name;
	private String user_picture;
	private String user_cover_photo;
	private String user_photo_url;
	private String video_thubmail;
	private String user_post_url;
	private String imageName;
	private String coverImageName;
	private String user_event;
	private String user_detail_about;
	
	public String getUser_detail_about() {
		return user_detail_about;
	}
	public void setUser_detail_about(String user_detail_about) {
		this.user_detail_about = user_detail_about;
	}
	public String getUser_event() {
		return user_event;
	}
	public void setUser_event(String user_event) {
		this.user_event = user_event;
	}
	public String getLife_events() {
		return life_events;
	}
	public void setLife_events(String life_events) {
		this.life_events = life_events;
	}
	public String getProfile_overview() {
		return profile_overview;
	}
	public void setProfile_overview(String profile_overview) {
		this.profile_overview = profile_overview;
	}
	public String getUser_post_url() {
		return user_post_url;
	}
	public void setUser_post_url(String user_post_url) {
		this.user_post_url = user_post_url;
	}
	public String getVideo_thubmail() {
		return video_thubmail;
	}
	public void setVideo_thubmail(String video_thubmail) {
		this.video_thubmail = video_thubmail;
	}
	public String getUser_photo_url() {
		return user_photo_url;
	}
	public void setUser_photo_url(String user_photo_url) {
		this.user_photo_url = user_photo_url;
	}

	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getUser_picture() {
		return user_picture;
	}
	public void setUser_picture(String user_picture) {
		this.user_picture = user_picture;
	}
	public String getUser_cover_photo() {
		return user_cover_photo;
	}
	public void setUser_cover_photo(String user_cover_photo) {
		this.user_cover_photo = user_cover_photo;
	}
	public String getFb_user_id() {
		return fb_user_id;
	}
	public void setFb_user_id(String fb_user_id) {
		this.fb_user_id = fb_user_id;
	}
	public String getBasic_info() {
		return basic_info;
	}
	public void setBasic_info(String basic_info) {
		this.basic_info = basic_info;
	}
	public String getContactType() {
		return contactType;
	}
	public void setContactType(String contactType) {
		this.contactType = contactType;
	}
	public String getHead() {
		return head;
	}
	public void setHead(String head) {
		this.head = head;
	}
	public String getEducation_work() {
		return education_work;
	}
	public void setEducation_work(String education_work) {
		this.education_work = education_work;
	}
	public String getEdu_type() {
		return edu_type;
	}
	public void setEdu_type(String edu_type) {
		this.edu_type = edu_type;
	}
	public String getFamily_info() {
		return family_info;
	}
	public void setFamily_info(String family_info) {
		this.family_info = family_info;
	}
	public String getFamily_type() {
		return family_type;
	}
	public void setFamily_type(String family_type) {
		this.family_type = family_type;
	}
	public String getMember_rel() {
		return member_rel;
	}
	public void setMember_rel(String member_rel) {
		this.member_rel = member_rel;
	}
	public String getMember_img() {
		return member_img;
	}
	public void setMember_img(String member_img) {
		this.member_img = member_img;
	}
	public String getPlace() {
		return place;
	}
	public void setPlace(String place) {
		this.place = place;
	}
	public String getPalce_type() {
		return palce_type;
	}
	public void setPalce_type(String palce_type) {
		this.palce_type = palce_type;
	}
	public String getImageName() {
		return imageName;
	}
	public void setImageName(String imageName) {
		this.imageName = imageName;
	}
	
	public String getCoverImageName() {
		return coverImageName;
	}
	public void setCoverImageName(String coverImageName) {
		this.coverImageName = coverImageName;
	}
	@Override
	public String toString() 
	{
		return "Fb_OutputVo [fb_user_id=" + fb_user_id + ", basic_info=" + basic_info + ", contactType=" + contactType
				+ ", head=" + head + ", education_work=" + education_work + ", edu_type=" + edu_type + ", family_info="
				+ family_info + ", family_type=" + family_type + ", member_rel=" + member_rel + ", member_img="
				+ member_img + ", place=" + place + ", palce_type=" + palce_type + ", user_name=" + user_name
				+ ", user_picture=" + user_picture + ", user_cover_photo=" + user_cover_photo + ", user_photo_url="
				+ user_photo_url + ", video_thubmail=" + video_thubmail + ", user_post_url=" + user_post_url
				+ ", imageName=" + imageName + ", coverImageName=" + coverImageName + "]";
	}
	
}

