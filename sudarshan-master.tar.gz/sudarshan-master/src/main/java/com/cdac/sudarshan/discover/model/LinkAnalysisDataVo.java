package com.cdac.sudarshan.discover.model;

import java.io.Serializable;
import java.util.ArrayList;
public class LinkAnalysisDataVo implements Serializable 
{
	private static final long serialVersionUID = 1L;
	private String item;
	private ArrayList<String> targetName;
	private int strength;
	private int count;
	public String getItem() {
		return item;
	}
	public void setItem(String item) {
		this.item = item;
	}
	public ArrayList<String> getTargetName() {
		return targetName;
	}
	public void setTargetName(ArrayList<String> targetName) {
		this.targetName = targetName;
	}
	public int getStrength() {
		return strength;
	}
	public void setStrength(int strength) {
		this.strength = strength;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() 
	{
		return "LinkAnalysisDataVo [item=" + item + ", targetName=" + targetName + ", strength=" + strength + ", count="
				+ count + "]";
	}
}
