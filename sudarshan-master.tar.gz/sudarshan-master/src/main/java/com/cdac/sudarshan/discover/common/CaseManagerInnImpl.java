package com.cdac.sudarshan.discover.common;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;

//import org.python.antlr.PythonParser.return_stmt_return;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;


@Service
public class CaseManagerInnImpl implements CaseManagerInn 
{
	@Autowired
	CaseInnDao caseInnDao;
	
	@Autowired
	CaseInnService caseInnService;
	
	@Override
	public boolean validateOTP(String username, String otp) {
		return caseInnService.validateOTP(username, otp);
	}
	
	@Override
	public LoginDetails validateUser(String userName, String password) {
		return caseInnDao.validateUser(userName, password);
	}
	
	@Override
	public boolean validateLDAP(String username, String password, String ldapHostname, String ldapDomainName) {
		return caseInnService.validateLDAP(username, password, ldapHostname, ldapDomainName);
	}
	
	@Override
	public ArrayList<CaseVo> caseCrud(CaseVo caseVo) {
		return caseInnDao.caseCrud(caseVo);
	}
	@Override
	public void entityCurd(CaseVo caseVo) {
		caseInnDao.entityCurd(caseVo);
	}
	@Override
	public ArrayList<EntityVo> entitySelect(CaseVo caseVo) {
		return caseInnDao.entitySelect(caseVo);
	}
	@Override
	public ArrayList<CaseVo> selectCase(CaseVo caseVo) {
		return caseInnDao.selectCase(caseVo);
	}
	@Override
	public void markCase(CaseVo caseVo) {
		caseInnDao.markCase(caseVo);
	}
	@Override
	public void actDeactivate(CaseVo caseVo) {
		caseInnDao.actDeactivate(caseVo);
	}
	@Override
	public ArrayList<EntityVo> entitySelectAll(CaseVo caseVo) {
		return caseInnDao.entitySelectAll(caseVo);
	}
	@Override
	public ArrayList<EntityVo> caseEntitySelectById(CaseVo caseVo) {
		return caseInnDao.caseEntitySelectById(caseVo);
	}
	@Override
	public void analysisCurd(CaseVo caseVo) {
		caseInnDao.analysisCurd(caseVo);
	}
	@Override
	public ArrayList<CaseVo> selectAnalysisForEdit(CaseVo caseVo) { 
		return caseInnDao.selectAnalysisForEdit(caseVo); 
	}
	@Override
	public ArrayList<LoginDetails> createUser(LoginDetails loginDetails) {
		return caseInnDao.createUser(loginDetails);
	}  
	@Override
	public LoginDetails selectUserById(LoginDetails loginDetails) {
		return caseInnDao.selectUserById(loginDetails);
	}
	@Override
	public void setCaseForAnalysis(CaseVo caseVo) 
	{
		caseInnDao.setCaseForAnalysis(caseVo);
	}
	@Override
	public ArrayList<CaseVo> getCaseForAnalysis() 
	{
		return caseInnDao.getCaseForAnalysis();
	}
	@Override
	public int setTwProfileEntity(EntityVo entityVo) 
	{
		return caseInnDao.setTwProfileEntity(entityVo);
	}
	@Override
	public String activateDeActivateEntity(EntityVo entityVo) 
	{
		return caseInnDao.activateDeActivateEntity(entityVo);
	}
	@Override
	public ArrayList<LoginDetails> createFbUser(LoginDetails loginDetails) 
	{
		return caseInnDao.createFbUser(loginDetails);
	}
	@Override
	public ArrayList<LoginDetails> createFbUserProf(LoginDetails loginDetails) 
	{
		return caseInnDao.createFbUserProf(loginDetails);
	}
	@Override
	public ArrayList<LoginDetails> selectFbUserById(LoginDetails loginDetails) 
	{
		return caseInnDao.selectFbUserById(loginDetails);
	}
	@Override
	public void mapFbProfileToAccount(LoginDetails loginDetails)
    {
		caseInnDao.mapFbProfileToAccount(loginDetails);
	}
	@Override
	public void apiUrl(CaseVo caseVo) 
	{
		caseInnDao.apiUrl(caseVo);
	}
	@Override
	public ArrayList<CaseVo> apiSelectUrl(CaseVo caseVo) 
	{
		return caseInnDao.apiSelectUrl(caseVo); 
	}
	@Override
	public ArrayList<CaseVo> apiDltUrl(CaseVo caseVo) 
	{ 
		return caseInnDao.apiDltUrl(caseVo);
	}
	@Override
	public ArrayList<LoginDetails> slctAccountFb(LoginDetails loginDetails) 
	{
		return caseInnDao.slctAccountFb(loginDetails);
	}
	
	@Override
	public ArrayList<LoginDetails> innsightUserLoginLimit(LoginDetails loginDetails) 
	{
		return caseInnDao.innsightUserLoginLimit(loginDetails);
	}
	@Override
	public ArrayList<CaseVo> getUserAccessTemplate(CaseVo caseVo) 
	{
		return caseInnDao.getUserAccessTemplate(caseVo);
	}
	
	@Override
	public boolean editMaxInnsightUserLoginConnection(LoginDetails loginDetails) 
	{
		return caseInnDao.editMaxInnsightUserLoginConnection(loginDetails);
	}
	
	@Override
	public void insertManageCrawler(ManageCrawlerVo manageCrawlerVo) 
	{ 
		caseInnDao.insertManageCrawler(manageCrawlerVo);
	}
	@Override
	public ArrayList<ManageCrawlerVo> getManageCrawler(ManageCrawlerVo manageCrawlerVo)
	{
		return caseInnDao.getManageCrawler(manageCrawlerVo);
	}
	@Override
	public void deleteManageCrawler(ManageCrawlerVo manageCrawlerVo) 
	{
		caseInnDao.deleteManageCrawler(manageCrawlerVo);
	}
	@Override
	public ArrayList<CrawlerSourceVo> getCrawlerSources(ManageCrawlerVo manageCrawlerVo) 
	{
		return caseInnDao.getCrawlerSources(manageCrawlerVo);
	}
	@Override
	public LinkedHashMap<String, String> setFilter(SaveFilterVo saveFilterVo)
	{
       return caseInnDao.setFilter(saveFilterVo);
	}
	@Override
	public boolean saveFilterForTrackTwKeyword(SaveFilterVo saveFilterVo) 
	{
		return caseInnDao.saveFilterForTrackTwKeyword(saveFilterVo);
	}
	
	@Override
	public ArrayList<SaveFilterVo> getSaveFilter(SaveFilterVo saveFilterVo)
	{
		return caseInnDao.getSaveFilter(saveFilterVo);
	}
	@Override
	public void deleteSaveFilter(SaveFilterVo saveFilterVo) 
	{
		caseInnDao.deleteSaveFilter(saveFilterVo);		
	}
	@Override
	public ArrayList<SaveFilterVo> getFilterValues(SaveFilterVo saveFilterVo) 
	{
		return	caseInnDao.getFilterValues(saveFilterVo);
	}
	@Override
	public void accountinsrt(AccountAliasVo accountAliasVo) 
	{  
		caseInnDao.accountinsrt(accountAliasVo);
	}
	@Override
	public ArrayList<EntityVo> entitySelectByFilter(CaseVo caseVo) 
	{
	 return	caseInnDao.entitySelectByFilter(caseVo);
	}
	@Override
	public ArrayList<CaseVo> selectAllCase(CaseVo caseVo)
	{ 
		return caseInnDao.selectAllCase(caseVo);
	}
	@Override
	public ArrayList<EntityVo> getEntityNameIdFromCase(CaseVo caseVo) 
	{
		return caseInnDao.getEntityNameIdFromCase(caseVo);
	}
	@Override
	public ArrayList<CaseVo> getProxyAvatar(CaseVo caseVo) 
	{
		return caseInnDao.getProxyAvatar(caseVo);
	}
	@Override
	public void addProxyAvatar(CaseVo caseVo) 
	{
		caseInnDao.addProxyAvatar(caseVo);
	}
	@Override
	public ArrayList<CaseVo> dltProxyIP(CaseVo caseVo) 
	{
		return caseInnDao.dltProxyIP(caseVo);
	}
	@Override
	public ArrayList<CaseVo> getProxyCountry(CaseVo caseVo) 
	{
		return caseInnDao.getProxyCountry(caseVo);
	}
	
	//*********USER PROFILR VIEW REPORT**********************************//
	//ADD
	@Override
	public boolean addUserProfileBasicInformations(UserProfileBasicInformationVo basicInformationVo) throws FileNotFoundException    
	{	
		return caseInnDao.addUserProfileBasicInformations(basicInformationVo);
	}
	
	@Override
	public boolean addUsersProfilePhotoForUpload(MultipartFile file) 
	{		
		return caseInnDao.addUsersProfilePhotoForUpload(file);
	}
	
	@Override
	public boolean addSuspectPhotoForUpload(MultipartFile file, String profileId) {		
		return caseInnDao.addSuspectPhotoForUpload(file, profileId);
	}
	
	@Override
	public boolean addUsersProfileCoverPhotoForUpload(MultipartFile file) 
	{
		return caseInnDao.addUsersProfileCoverPhotoForUpload(file);
	}
	
	@Override
	public boolean addUserProfileAlias(UserProfileAliasVo aliasVo) 
	{	
		return caseInnDao.addUserProfileAlias(aliasVo);
	}
	
	@Override
	public boolean addUserProfileContact(UserProfileContactVo contactVo) 
	{	
		return caseInnDao.addUserProfileContact(contactVo);
	}
	
	@Override
	public boolean addUserProfileSocialAccount(UserProfileSocialAccountVo socialAccountVo) 
	{	
		return caseInnDao.addUserProfileSocialAccount(socialAccountVo);
	}
	
	@Override
	public boolean addUserProfileAssociatedFriends(UserProfileAssociatedFriendsVo associatedFriendsVo) 
	{	
		return caseInnDao.addUserProfileAssociatedFriends(associatedFriendsVo);
	}
	
	@Override
	public boolean addUserProfileAssociatedHandles(UserProfileAssociatedHandlesVo associatedHandlesVo) 
	{	
		return caseInnDao.addUserProfileAssociatedHandles(associatedHandlesVo);
	}
	
	@Override
	public boolean addUserProfileAssociatedEvents(UserProfileAssociatedEventsVo associatedEventsVo) 
	{		
		return caseInnDao.addUserProfileAssociatedEvents(associatedEventsVo);
	}
	
	@Override
	public boolean addUserProfileAssociatedLocations(UserProfileAssociatedLocationsVo associatedLocationsVo) 
	{		
		return caseInnDao.addUserProfileAssociatedLocations(associatedLocationsVo);
	}
	
	@Override
	public boolean addUserProfileAssociatedOrganizations(UserProfileAssociatedOrganizationsVo associatedOrganizationsVo)
	{	
		return caseInnDao.addUserProfileAssociatedOrganizations(associatedOrganizationsVo);
	}

	@Override
	public void addSrcUserAvatar(CaseVo caseVo) 
	{
		caseInnDao.addSrcUserAvatar(caseVo); 
	}
	@Override
	public String addSrcUserCentralAvatar(CaseVo caseVo) 
	{
		return caseInnDao.addSrcUserCentralAvatar(caseVo);
	}
	
	@Override
	public ArrayList<CaseVo> getSourcesAvatar(CaseVo caseVo) 
	{
		return caseInnDao.getSourcesAvatar(caseVo);
	}
	@Override
	public ArrayList<CaseVo> getSourcesCentralAvatar(CaseVo caseVo) {
		return caseInnDao.getSourcesCentralAvatar(caseVo);
	}
	
	@Override
	public ArrayList<CentralAvatarVo> getAvatarToSyncCentralCrawlerServer(CentralAvatarVo centralAvatarVo) {
		return caseInnDao.getAvatarToSyncCentralCrawlerServer(centralAvatarVo);
	}

	@Override
	public ArrayList<CaseVo> dltSrcAvatar(CaseVo caseVo) {
		return caseInnDao.dltSrcAvatar(caseVo);
	}
	
	@Override
	public boolean dltSrcCentralAvatar(CaseVo caseVo) 
	{
		return caseInnDao.dltSrcCentralAvatar(caseVo);
	}
	
	
	//Central Ceawling
	@Override
	public ArrayList<CentralAvatarVo> getActiveAvatarForCentralCrawling(CentralAvatarVo centralAvatarVo) 
	{
		return caseInnDao.getActiveAvatarForCentralCrawling(centralAvatarVo);
	}
	@Override
	public String addDataCollectionJobsCnf(CaseVo caseVo) 
	{
		return caseInnDao.addDataCollectionJobsCnf(caseVo);
	}
	
	
	
	
	
	
	
	
	//SELECT
	@Override
	public ArrayList<UserProfileBasicInformationVo> getUserProfileBasicInformationsDetails(UserProfileBasicInformationVo basicInformationVo) {
		return caseInnDao.getUserProfileBasicInformationsDetails(basicInformationVo);
	}
	
	@Override
	public ArrayList<UserProfileBasicInformationVo> getTargetCurrentAddedUserProfileBasicInfo(UserProfileBasicInformationVo basicInformationVo) 
	{
		return caseInnDao.getTargetCurrentAddedUserProfileBasicInfo(basicInformationVo);
	}
	
	@Override
	public ArrayList<UserProfileBasicInformationVo> getTargetUserProfileBasicInfo(UserProfileBasicInformationVo basicInformationVo) {
		return caseInnDao.getTargetUserProfileBasicInfo(basicInformationVo);
	}
	
	@Override
	public ArrayList<UserProfileAliasVo> getUserProfileAliasDetails(UserProfileAliasVo aliasVo) 
	{
		return caseInnDao.getUserProfileAliasDetails(aliasVo);
	}
	
	@Override
	public ArrayList<UserProfileContactVo> getUserProfileContactDetails(UserProfileContactVo contactVo)
	{
		return caseInnDao.getUserProfileContactDetails(contactVo);
	}
	
	@Override
	public ArrayList<UserProfileContactVo> getTargetProfileContactDetailsForEdit(UserProfileContactVo contactVo)
	{
		return caseInnDao.getTargetProfileContactDetailsForEdit(contactVo);
	}
	
	@Override
	public ArrayList<UserProfileSocialAccountVo> getUserProfileSocialAccountDetails(UserProfileSocialAccountVo socialAccountVo) 
	{
		return caseInnDao.getUserProfileSocialAccountDetails(socialAccountVo);
	}
	
	@Override
	public ArrayList<UserProfileAssociatedFriendsVo> getUserProfileAssociatedFriendsDetails(UserProfileAssociatedFriendsVo associatedFriendsVo)
	{
		return caseInnDao.getUserProfileAssociatedFriendsDetails(associatedFriendsVo);
	}
	
	@Override
	public ArrayList<UserProfileAssociatedHandlesVo> getUserProfileAssociatedHandlesDetails(UserProfileAssociatedHandlesVo associatedHandlesVo) 
	{
		return caseInnDao.getUserProfileAssociatedHandlesDetails(associatedHandlesVo);
	}
	
	@Override
	public ArrayList<UserProfileAssociatedEventsVo> getUserProfileAssociatedEventsDetails(UserProfileAssociatedEventsVo associatedEventsVo) 
	{
		return caseInnDao.getUserProfileAssociatedEventsDetails(associatedEventsVo);
	}
	
	@Override
	public ArrayList<UserProfileAssociatedLocationsVo> getUserProfileAssociatedLocationsDetails(UserProfileAssociatedLocationsVo associatedLocationsVo) 
	{
		return caseInnDao.getUserProfileAssociatedLocationsDetails(associatedLocationsVo);
	}
	
	@Override
	public ArrayList<UserProfileAssociatedOrganizationsVo> getUserProfileAssociatedOrganizationsDetails(UserProfileAssociatedOrganizationsVo associatedOrganizationsVo) 
	{
		return caseInnDao.getUserProfileAssociatedOrganizationsDetails(associatedOrganizationsVo);
	}
	
	//DELETE
	@Override
	public ArrayList<UserProfileBasicInformationVo> deleteUserProfileBasicInformations(
			UserProfileBasicInformationVo basicInformationVo) 
	{
		return caseInnDao.deleteUserProfileBasicInformations(basicInformationVo);
	}
	
	@Override
	public ArrayList<UserProfileAliasVo> deleteUserProfileAlias(UserProfileAliasVo aliasVo) 
	{
		return caseInnDao.deleteUserProfileAlias(aliasVo);
	}
	
	@Override
	public ArrayList<UserProfileContactVo> deleteUserProfileContact(UserProfileContactVo contactVo) 
	{
		return caseInnDao.deleteUserProfileContact(contactVo);
	}
	
	@Override
	public ArrayList<UserProfileSocialAccountVo> deleteUserProfileSocialAccount(
			UserProfileSocialAccountVo socialAccountVo) 
	{
		return caseInnDao.deleteUserProfileSocialAccount(socialAccountVo);
	}
	
	@Override
	public ArrayList<UserProfileAssociatedFriendsVo> deleteUserProfileAssociatedFriends(
			UserProfileAssociatedFriendsVo associatedFriendsVo)
	{
		return caseInnDao.deleteUserProfileAssociatedFriends(associatedFriendsVo);
	}
	
	@Override
	public ArrayList<UserProfileAssociatedHandlesVo> deleteUserProfileAssociatedHandles(
			UserProfileAssociatedHandlesVo associatedHandlesVo) 
	{
		return caseInnDao.deleteUserProfileAssociatedHandles(associatedHandlesVo);
	}
	
	@Override
	public ArrayList<UserProfileAssociatedEventsVo> deleteUserProfileAssociatedEvents(
			UserProfileAssociatedEventsVo associatedEventsVo) 
	{
		return caseInnDao.deleteUserProfileAssociatedEvents(associatedEventsVo);
	}
	
	@Override
	public ArrayList<UserProfileAssociatedLocationsVo> deleteUserProfileAssociatedLocations(
			UserProfileAssociatedLocationsVo associatedLocationsVo) 
	{
		return caseInnDao.deleteUserProfileAssociatedLocations(associatedLocationsVo);
	}
	
	@Override
	public ArrayList<UserProfileAssociatedOrganizationsVo> deleteUserProfileAssociatedOrganizations(
			UserProfileAssociatedOrganizationsVo associatedOrganizationsVo) 
	{
		return caseInnDao.deleteUserProfileAssociatedOrganizations(associatedOrganizationsVo);
	}
	
	//UPDATE
	@Override
	public boolean editUserProfileBasicInformations(UserProfileBasicInformationVo basicInformationVo) 
	{
		return caseInnDao.editUserProfileBasicInformations(basicInformationVo);
	}
	
	@Override
	public boolean editUserProfileAlias(UserProfileAliasVo aliasVo)
	{
		return caseInnDao.editUserProfileAlias(aliasVo);
	}
	
	@Override
	public boolean editUserProfileContact(UserProfileContactVo contactVo) 
	{
		return caseInnDao.editUserProfileContact(contactVo);
	}
	
	@Override
	public boolean editUserProfileSocialAccount(UserProfileSocialAccountVo socialAccountVo) 
	{
		return caseInnDao.editUserProfileSocialAccount(socialAccountVo);
	}
	
	@Override
	public boolean editUserProfileAssociatedFriends(UserProfileAssociatedFriendsVo associatedFriendsVo)
	{
		return caseInnDao.editUserProfileAssociatedFriends(associatedFriendsVo);
	}
	
	@Override
	public boolean editUserProfileAssociatedHandles(UserProfileAssociatedHandlesVo associatedHandlesVo) 
	{
		return caseInnDao.editUserProfileAssociatedHandles(associatedHandlesVo);
	}
	
	@Override
	public boolean editUserProfileAssociatedEvents(UserProfileAssociatedEventsVo associatedEventsVo) 
	{
		return caseInnDao.editUserProfileAssociatedEvents(associatedEventsVo);
	}
	
	@Override
	public boolean editUserProfileAssociatedLocations(UserProfileAssociatedLocationsVo associatedLocationsVo)
	{
		return caseInnDao.editUserProfileAssociatedLocations(associatedLocationsVo);
	}
	
	@Override
	public boolean editUserProfileAssociatedOrganizations(UserProfileAssociatedOrganizationsVo associatedOrganizationsVo)
	{
		return caseInnDao.editUserProfileAssociatedOrganizations(associatedOrganizationsVo);
	}
	
	@Override
	public ArrayList<UserProfilePhotoVo> getUserProfileCoverPhoto(UserProfilePhotoVo photoVo) 
	{
		return caseInnDao.getUserProfileCoverPhoto(photoVo);
	}
	
	@Override
	public ArrayList<UserProfilePhotoVo> getUserProfilePhoto(UserProfilePhotoVo photoVo) 
	{
		return caseInnDao.getUserProfilePhoto(photoVo);
	}
	
	@Override
	public void saveSocialAccountToTargetView(CaseVo caseVo) 
	{
		caseInnDao.saveSocialAccountToTargetView(caseVo);	
	}
	
	@Override
	public void saveSocialMediaAccountToTargetProfileView(CaseVo caseVo) 
	{
		caseInnDao.saveSocialMediaAccountToTargetProfileView(caseVo);	
	}
	
	@Override
	public ArrayList<UserProfileBasicInformationVo> getTargetProfileBasicInformationsDetailsReport(UserProfileBasicInformationVo basicInformationVo)
	{
		return caseInnDao.getTargetProfileBasicInformationsDetailsReport(basicInformationVo);	
	}
	
	@Override
	public ArrayList<UserProfilePhotoVo> getTargetProfileCoverPhotoReport(UserProfilePhotoVo photoVo) 
	{
		return caseInnDao.getTargetProfileCoverPhotoReport(photoVo);
	}
	
	@Override
	public ArrayList<UserProfilePhotoVo> getTargetProfilePhotoReport(UserProfilePhotoVo photoVo)
	{
		return caseInnDao.getTargetProfilePhotoReport(photoVo);
	}

	@Override
	public ArrayList<UserProfileContactVo> getTargetProfileContactDetailsReport(UserProfileContactVo contactVo)
	{
		return caseInnDao.getTargetProfileContactDetailsReport(contactVo);
	}
	
	@Override
	public ArrayList<CaseVo> getMappedProxy(CaseVo caseVo) {
		return caseInnDao.getMappedProxy(caseVo);
	}
	@Override
	public ArrayList<CaseVo> getMappedProxyByCntry(CaseVo caseVo) {
		return caseInnDao.getMappedProxyByCntry(caseVo);
	}
	@Override
	public ArrayList<CaseVo> getMenuCountry(CaseVo caseVo) {
		return caseInnDao.getMenuCountry(caseVo);
	}
	@Override
	public ArrayList<CaseVo> getCountryRssMap(CaseVo caseVo) {
		return caseInnDao.getCountryRssMap(caseVo);
	}
	@Override
	public void addUserAlerts(CaseVo caseVo) {
		caseInnDao.addUserAlerts(caseVo);
	}
	@Override
	public ArrayList<CaseVo> getAlertByUsers(CaseVo caseVo) {
		return caseInnDao.getAlertByUsers(caseVo);
	}
	@Override
	public ArrayList<CaseVo> dltUserAlerts(CaseVo caseVo) {
		return caseInnDao.dltUserAlerts(caseVo);
	}
	@Override
	public void actDactAlertValue(CaseVo caseVo) {
		 caseInnDao.actDactAlertValue(caseVo);
	}
	@Override
	public ArrayList<CaseVo> getAlertByUsersId(CaseVo caseVo) {
		return caseInnDao.getAlertByUsersId(caseVo);
	}
	
	@Override
	public boolean addOrganizationViewBasicInformationDetails(OrganizationBasicInformationVo orgBasicInfo)
	{
		return caseInnDao.addOrganizationViewBasicInformationDetails(orgBasicInfo);
	}
	
	@Override
	public ArrayList<OrganizationBasicInformationVo> getTargetOrganizationBasicInformationsDetails(OrganizationBasicInformationVo orgBasicInfo) 
	{
		return caseInnDao.getTargetOrganizationBasicInformationsDetails(orgBasicInfo);
	}
	
	@Override
	public ArrayList<OrganizationBasicInformationVo> getTargetOrganizationBasicInformationsForEdit(OrganizationBasicInformationVo orgBasicInfo) 
	{
		return caseInnDao.getTargetOrganizationBasicInformationsForEdit(orgBasicInfo);
	}
	
	@Override
	public ArrayList<OrganizationBasicInformationVo> deleteTargetOrganizationBasicInformations(OrganizationBasicInformationVo orgBasicInfo) 
	{
		return caseInnDao.deleteTargetOrganizationBasicInformations(orgBasicInfo);
	}
	
	@Override
	public boolean addOrganizationProfilePhotoForUpload(MultipartFile file)
	{
		return caseInnDao.addOrganizationProfilePhotoForUpload(file);
	}
	@Override
	public boolean addOrganizationProfileCoverPhotoForUpload(MultipartFile file)
	{
		return caseInnDao.addOrganizationProfileCoverPhotoForUpload(file);
	}
	
	@Override
	public ArrayList<OrganizationPhotoVo> getOrganizationCoverPhoto(OrganizationPhotoVo photoVo)
	{
		return caseInnDao.getOrganizationCoverPhoto(photoVo);
	}
	
	@Override
	public ArrayList<OrganizationPhotoVo> getOrganizationProfilePhoto(OrganizationPhotoVo photoVo) 
	{
		return caseInnDao.getOrganizationProfilePhoto(photoVo);
	}
	
	@Override
	public boolean editOrganizationBasicInformationsDetails(OrganizationBasicInformationVo orgBasicInfo)
	{
		return caseInnDao.editOrganizationBasicInformationsDetails(orgBasicInfo);
	}

	@Override
	public ArrayList<OrganizationBasicInformationVo> getTargetOrganizationBasicInformationsDetailsReport(OrganizationBasicInformationVo orgInfoVo)
	{
		return caseInnDao.getTargetOrganizationBasicInformationsDetailsReport(orgInfoVo);
	}
	
	@Override
	public ArrayList<OrganizationPhotoVo> getTargetOrganizationCoverPhotoReport(OrganizationPhotoVo photoVo)
	{
		return caseInnDao.getTargetOrganizationCoverPhotoReport(photoVo);
	}
	
	@Override
	public ArrayList<OrganizationPhotoVo> getTargetOrganizationProfilePhotoReport(OrganizationPhotoVo photoVo)
	{
		return caseInnDao.getTargetOrganizationProfilePhotoReport(photoVo);
	}
	
	@Override
	public ArrayList<UserProfileBasicInformationVo> getTargetProfileBasicInformationsForEdit(UserProfileBasicInformationVo basicInformationVo) 
	{
		return caseInnDao.getTargetProfileBasicInformationsForEdit(basicInformationVo);
	}


	@Override
	public ArrayList<CaseVo> getAlertWorkDaysById(CaseVo caseVo) {
		return caseInnDao.getAlertWorkDaysById(caseVo);
	}
	@Override
	public ArrayList<CaseVo> getAlertDetails(CaseVo caseVo) {
		return caseInnDao.getAlertDetails(caseVo);
	}
	@Override
	public ArrayList<CaseVo> getAlertCounts(CaseVo caseVo) {
		return caseInnDao.getAlertCounts(caseVo);
	}
	@Override
	public void updateAlertReadStatus(CaseVo caseVo) {
		caseInnDao.updateAlertReadStatus(caseVo);
		
	}
	@Override
	public void updateAlertStatusRead(CaseVo caseVo) {
		caseInnDao.updateAlertStatusRead(caseVo);
		
	}
	@Override
	public ArrayList<CaseVo> getAlertByStatusType(CaseVo caseVo) {
		return caseInnDao.getAlertByStatusType(caseVo);
	}
	
	@Override
	public ArrayList<CaseVo> setViewbyAlertId(CaseVo caseVo) {
		return caseInnDao.setViewbyAlertId(caseVo);
	}
	
	@Override
	public int getTargetUserProfileSocialAccountSize(UserProfileSocialAccountVo accountVo)
	{
		return caseInnDao.getTargetUserProfileSocialAccountSize(accountVo);
	}
	
	@Override
	public ArrayList<EntityVo> getTargetProfileRelatedSocialMediaAccountsDetails(EntityVo entityVo) 
	{
		return caseInnDao.getTargetProfileRelatedSocialMediaAccountsDetails(entityVo);
	}
	
	@Override
	public void saveSocialMediaAccountToTargetOrganizationView(CaseVo caseVo) 
	{
		caseInnDao.saveSocialMediaAccountToTargetOrganizationView(caseVo);
	}
	
	@Override
	public ArrayList<EntityVo> getTargetOrganizationRelatedSocialMediaAccountsDetails(EntityVo entityVo)
	{
		return caseInnDao.getTargetOrganizationRelatedSocialMediaAccountsDetails(entityVo);
	}
	@Override
	public ArrayList<OrganizationBasicInformationVo> getCurrentAddedTargetOrganizationBasicInfo(
			OrganizationBasicInformationVo basicInformationVo) 
	{
		return caseInnDao.getCurrentAddedTargetOrganizationBasicInfo(basicInformationVo);
	}
	
	@Override
	public void addTargetOrganizationContact(OrganizationContactVo contactVo)
	{
		caseInnDao.addTargetOrganizationContact(contactVo);
	}
	@Override
	public void editTargetOrganizationContact(OrganizationContactVo contactVo)
	{
		caseInnDao.editTargetOrganizationContact(contactVo);
	}
	@Override
	public void deleteTargetOrganizationContact(OrganizationContactVo contactVo)
	{
		caseInnDao.deleteTargetOrganizationContact(contactVo);
	}
	@Override
	public ArrayList<OrganizationContactVo> getTargetOrganizationContactList(OrganizationContactVo contactVo) 
	{
		return caseInnDao.getTargetOrganizationContactList(contactVo);
	}
	
	//SEARCH ANALYSIS PROFILE FROM SYSTEM:======================================
	@Override
	public ArrayList<EntityVo> searchTwitterUserFromSystems(EntityVo twUser) 
	{
		return caseInnDao.searchTwitterUserFromSystems(twUser);
	}
	@Override
	public ArrayList<EntityVo> searchFbPageFromSystems(EntityVo fbPage) 
	{
		return caseInnDao.searchFbPageFromSystems(fbPage);
	}
	@Override
	public ArrayList<EntityVo> searchFbGroupFromSystems(EntityVo fbGroup)
	{
		return caseInnDao.searchFbGroupFromSystems(fbGroup);
	}
	@Override
	public ArrayList<EntityVo> searchFbProfileFromSystems(EntityVo fbProfile) 
	{
		return caseInnDao.searchFbProfileFromSystems(fbProfile);
	}
	@Override
	public ArrayList<EntityVo> searchInstaUserFromSystems(EntityVo instaUser) 
	{
		return caseInnDao.searchInstaUserFromSystems(instaUser);
	}
	@Override
	public ArrayList<EntityVo> searchYoutubeChannleFromSystems(EntityVo ytUser) 
	{
		return caseInnDao.searchYoutubeChannleFromSystems(ytUser);
	}
	@Override
	public ArrayList<EntityVo> searchGbUsersFromSystems(EntityVo gbUser) 
	{
		return caseInnDao.searchGbUsersFromSystems(gbUser);
	}
	
	@Override
	public ArrayList<EntityVo> searchTmUsersFromSystems(EntityVo tmUser)
	{
		return caseInnDao.searchTmUsersFromSystems(tmUser);
	}
	@Override
	public ArrayList<EntityVo> searchDMUserFromSystems(EntityVo dmUser)
	{
		return caseInnDao.searchDMUserFromSystems(dmUser);
	}
	@Override
	public ArrayList<EntityVo> searchRedditUsersFromSystems(EntityVo redditUser) 
	{
		return caseInnDao.searchRedditUsersFromSystems(redditUser);
	}

	@Override
	public ArrayList<EntityVo> searchFlickrUsersFromSystems(EntityVo flickrUser) 
	{
		return caseInnDao.searchFlickrUsersFromSystems(flickrUser);
	}

	@Override
	public ArrayList<EntityVo> searchLinkedinUsersFromSystems(EntityVo linkedinUser) 
	{
		return caseInnDao.searchLinkedinUsersFromSystems(linkedinUser);
	}
	
	
	@Override
	public ArrayList<CaseVo> getCountryState(CaseVo caseVo) {
		return caseInnDao.getCountryState(caseVo);
	}
	@Override
	public ArrayList<CaseVo> getStateCity(CaseVo caseVo) {
		return caseInnDao.getStateCity(caseVo);
	}
	@Override
	public void actDeactivateAvatar(CaseVo caseVo) {
		caseInnDao.actDeactivateAvatar(caseVo);
	}
	
	
	//Ner alias add/replace/
	@Override
	public void addAlias(CaseVo caseVo) {
		caseInnDao.addAlias(caseVo); 
	}
	@Override
	public ArrayList<CaseVo> getNerAlias(CaseVo caseVo) {
		return caseInnDao.getNerAlias(caseVo);
	}
	@Override
	public void addAliasIgnore(CaseVo caseVo) {
		caseInnDao.addAliasIgnore(caseVo); 
	}
	@Override
	public ArrayList<CaseVo> getAliasIgnore(CaseVo caseVo) {
		return caseInnDao.getAliasIgnore(caseVo);
	}
	@Override
	public void addAliasReplace(CaseVo caseVo) {
		caseInnDao.addAliasReplace(caseVo); 
	}
	@Override
	public ArrayList<CaseVo> getAliasReplace(CaseVo caseVo) {
		return caseInnDao.getAliasReplace(caseVo);
	}
	@Override
	public ArrayList<CaseVo> getAllDistinctAliasEntity(CaseVo caseVo) {
		return caseInnDao.getAllDistinctAliasEntity(caseVo);
	}
	@Override
	public void addFbUserToSearch(CaseVo caseVo) {
		caseInnDao.addFbUserToSearch(caseVo);
	}
	@Override
	public ArrayList<CaseVo> getFbUserAfterSearch(CaseVo caseVo) {
		return caseInnDao.getFbUserAfterSearch(caseVo);
	}
	@Override
	public void deleteFbUserToSearch(CaseVo caseVo) {
		caseInnDao.deleteFbUserToSearch(caseVo);
	}
	@Override
	public ArrayList<CaseVo> getFbUserListAfterSearch(CaseVo caseVo) {
		return caseInnDao.getFbUserListAfterSearch(caseVo);
	}
	@Override
	public void addFacebookProfileToCrawl(CaseVo caseVo) {
		caseInnDao.addFacebookProfileToCrawl(caseVo);
	}
	
	@Override
	public void hideAndUpdareFbUserAddToCrawlerFlag(CaseVo caseVo)
	{
		caseInnDao.hideAndUpdareFbUserAddToCrawlerFlag(caseVo);
	}
	@Override
	public void showAndUpdareFbUserAddToCrawlerFlag(CaseVo caseVo)
	{
		caseInnDao.showAndUpdareFbUserAddToCrawlerFlag(caseVo);
	}
	
	
	
	@Override
	public ArrayList<CaseVo> getProfileCategoryDetaisInfo(CaseVo caseVo) 
	{
		return caseInnDao.getProfileCategoryDetaisInfo(caseVo);
	}
	@Override
	public void editProfileCategory(CaseVo caseVo)
	{
		caseInnDao.editProfileCategory(caseVo);
	}
	@Override
	public void deleteProfileCategory(CaseVo caseVo) 
	{
		caseInnDao.deleteProfileCategory(caseVo);
	}
	@Override
	public ArrayList<CaseVo> totalProfileCategoryCount(CaseVo caseVo) 
	{
		return caseInnDao.totalProfileCategoryCount(caseVo);
	}
	@Override
	public String deleteEntityInnsight(CaseVo caseVo) 
	{
		 return caseInnDao.deleteEntityInnsight(caseVo);
	}
	@Override
	public String deleteMultipleEntityInnsight(CaseVo caseVo) 
	{
		return caseInnDao.deleteMultipleEntityInnsight(caseVo);
	}
	@Override
	public void addProfileCategory(CaseVo caseVo) 
	{
		caseInnDao.addProfileCategory(caseVo);
	}
	@Override
	public ArrayList<CaseVo> getCategory(CaseVo caseVo) 
	{
	    return caseInnDao.getCategory(caseVo);
	}
	@Override
	public ArrayList<CaseVo> getCollectionCategory(CaseVo caseVo) 
	{
		return caseInnDao.getCollectionCategory(caseVo);
	}
	@Override
	public ArrayList<EntityVo> getProfileDetailsForEdit(CaseVo caseVo) 
	{
		return caseInnDao.getProfileDetailsForEdit(caseVo);
	}
	@Override
	public void editProCategoryMap(EntityVo entityVo) 
	{
		caseInnDao.editProCategoryMap(entityVo);
	}
	@Override
	public void editProfileCountryCode(EntityVo entityVo) 
	{
		caseInnDao.editProfileCountryCode(entityVo);
	}
	@Override
	public ArrayList<CaseVo> checkFbProAddedValue(CaseVo caseVo) 
	{
		return caseInnDao.checkFbProAddedValue(caseVo); 
	}
	@Override
	public ArrayList<ProfileFinderResult> srchFbProfileByMobileEmail(EntityVo fbPage)
	{
		return caseInnDao.srchFbProfileByMobileEmail(fbPage);
	}
	@Override
	public void saveFbUserMobileEmail(CaseVo caseVo) 
	{
		caseInnDao.saveFbUserMobileEmail(caseVo);
	}
	@Override
	public void mobileEmailDelete(CaseVo caseVo)
	{
		 caseInnDao.mobileEmailDelete(caseVo);
	}
	@Override
	public ArrayList<ProfileFinderResult> getFinderNewResults() 
	{
		return caseInnDao.getFinderNewResults();
	}
	@Override
	public void updateFinderNewResultStatus() 
	{
		caseInnDao.updateFinderNewResultStatus();
	}
	
	@Override
	public boolean deleteSnapshot(SaveFilterVo saveFilterVo) 
	{
		return caseInnDao.deleteSnapshot(saveFilterVo);
	}
	@Override
	public ArrayList<SaveFilterVo> getSnapshotsById(SaveFilterVo saveFilterVo)
	{
		return caseInnDao.getSnapshotsById(saveFilterVo);
	}
	
	@Override
	public boolean entityNewCurd(CaseVo caseVo) 
	{
		return caseInnDao.entityNewCurd(caseVo);
	}
	
	@Override
	public ArrayList<UserProfilePhotoVo> getImagesForProfileId(UserProfilePhotoVo userProfilePhotoVo) 
	{
		return caseInnDao.getImagesForProfileId(userProfilePhotoVo);
	}
	
	@Override
	public boolean deleteSuspectPhoto(UserProfilePhotoVo userProfilePhotoVo) 
	{
		return caseInnDao.deleteSuspectPhoto(userProfilePhotoVo);
	}
	
	@Override
	public ArrayList<CaseVo> getAllLoginUsers(CaseVo caseVo) 
	{
		return caseInnDao.getAllLoginUsers(caseVo); 
	}
	
	@Override
	public ArrayList<CaseVo> getUserLogsEs(CaseVo caseVo) 
	{
		return caseInnDao.getUserLogsEs(caseVo); 
	}
	
	@Override
	public boolean updateProfileFinderMobileDeviceHealthStatus() 
	{
		return caseInnDao.updateProfileFinderMobileDeviceHealthStatus();
	}
	
	@Override
	public boolean checkLoginUserAccount(LoginDetails loginDetails) 
	{
		return caseInnDao.checkLoginUserAccount(loginDetails);
	}
	@Override
	public CaseVo searchLatLonFromES(CaseVo caseVo) 
	{
		return caseInnDao.searchLatLonFromES(caseVo);
	}
	@Override
	public boolean checkUserCreationLimit(CaseVo caseVo) 
	{
		return caseInnDao.checkUserCreationLimit(caseVo);
	}
	
	@Override
	public ArrayList<String> blacklistKeywords() {
		return caseInnDao.blacklistKeywords();
	}
	
	@Override
	public boolean saveNerToWordCloud(CaseVo caseVo)
	{
		return caseInnDao.saveNerToWordCloud(caseVo);
	}
	
	@Override
	public HashMap<String, ArrayList<String>> nerIgnoreKeywords() {
		return caseInnDao.nerIgnoreKeywords();
	}

	@Override
	public ArrayList<CaseVo> getODSObjectData(CaseVo caseVo) 
	{
		return caseInnDao.getODSObjectData(caseVo);
	}

	@Override
	public ArrayList<CaseVo> getAnalysisSnapDetails(CaseVo caseVo) 
	{
		return caseInnDao.getAnalysisSnapDetails(caseVo);
	}

	@Override
	public ArrayList<CaseVo> getAnalysisSnapDetailsById(CaseVo caseVo) 
	{
		return caseInnDao.getAnalysisSnapDetailsById(caseVo);
	}
	
	@Override
	public boolean deleteAnalysisSnap(CaseVo caseVo)
	{
		return caseInnDao.deleteAnalysisSnap(caseVo);
	}

	@Override
	public boolean editAnalysisSnapDetailsById(CaseVo caseVo) 
	{
		return caseInnDao.editAnalysisSnapDetailsById(caseVo);
	}
	@Override
	public ArrayList<CaseVo> getThreatKeyword(CaseVo caseVo) 
	{
		return caseInnDao.getThreatKeyword(caseVo);
	}
	@Override
	public ArrayList<CaseVo> getThreatScoreKeyword(CaseVo caseVo) 
	{
		return caseInnDao.getThreatScoreKeyword(caseVo);
	}

	@Override
	public boolean addThreatScoreKeyword(CaseVo caseVo) 
	{
		return caseInnDao.addThreatScoreKeyword(caseVo);
	}

	@Override
	public boolean deleteThreatScoreKeyword(CaseVo caseVo) 
	{
		return caseInnDao.deleteThreatScoreKeyword(caseVo);
	}

	@Override
	public boolean getThreatScoreFlag(CaseVo caseVo) 
	{
		return caseInnDao.getThreatScoreFlag(caseVo);
	}

	@Override
	public boolean writeThreatKeywordInSentimentService(CaseVo caseVo) 
	{
		return caseInnDao.writeThreatKeywordInSentimentService(caseVo);
	}

	@Override
	public ArrayList<CaseVo> getAnalysisDetailsByUser(CaseVo caseVo) 
	{
		return caseInnDao.getAnalysisDetailsByUser(caseVo);
	}

	@Override
	public ArrayList<CaseVo> getSnapshortDetailsByUser(CaseVo caseVo) 
	{
		return caseInnDao.getSnapshortDetailsByUser(caseVo);
	}

	@Override
	public boolean addExportReportInfo(CaseVo caseVo) 
	{
		
		return caseInnDao.addExportReportInfo(caseVo);
	}

	@Override
	public ArrayList<CaseVo> getExportReportDetails(CaseVo caseVo)
	{
		return caseInnDao.getExportReportDetails(caseVo);
	}

	

	
	

	
	
}