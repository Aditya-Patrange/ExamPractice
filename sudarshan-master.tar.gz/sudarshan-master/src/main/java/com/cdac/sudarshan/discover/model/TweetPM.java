package com.cdac.sudarshan.discover.model;

public class TweetPM {
	private int id;
	private String tweetBy;
	private String tweetText;
	private String status;
	private int isScheduled;
	private java.sql.Timestamp scheduledDatetime;
	private java.sql.Timestamp creationDate;
	private String createdBy;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTweetBy() {
		return tweetBy;
	}
	public void setTweetBy(String tweetBy) {
		this.tweetBy = tweetBy;
	}
	public String getTweetText() {
		return tweetText;
	}
	public void setTweetText(String tweetText) {
		this.tweetText = tweetText;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getIsScheduled() {
		return isScheduled;
	}
	public void setIsScheduled(int isScheduled) {
		this.isScheduled = isScheduled;
	}
	public java.sql.Timestamp getScheduledDatetime() {
		return scheduledDatetime;
	}
	public void setScheduledDatetime(java.sql.Timestamp scheduledDatetime) {
		this.scheduledDatetime = scheduledDatetime;
	}
	public java.sql.Timestamp getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(java.sql.Timestamp creationDate) {
		this.creationDate = creationDate;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	
	@Override
	public String toString() {
		return "TweetPM [id=" + id + ", tweetBy=" + tweetBy + ", tweetText=" + tweetText + ", status=" + status
				+ ", isScheduled=" + isScheduled + ", scheduledDatetime=" + scheduledDatetime + ", creationDate="
				+ creationDate + ", createdBy=" + createdBy + "]";
	}
}
