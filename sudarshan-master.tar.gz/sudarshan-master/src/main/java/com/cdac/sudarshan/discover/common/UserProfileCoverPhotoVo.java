package com.cdac.sudarshan.discover.common;

import java.io.Serializable;
import java.util.Arrays;

public class UserProfileCoverPhotoVo implements Serializable
{
	private static final long serialVersionUID = 1L;
	
	private int coverPhotoId;
	private byte[] coverPhoto;
	private int status;
	
	public int getCoverPhotoId() 
	{
		return coverPhotoId;
	}
	public void setCoverPhotoId(int coverPhotoId) 
	{
		this.coverPhotoId = coverPhotoId;
	}
	public byte[] getCoverPhoto()
	{
		return coverPhoto;
	}
	public void setCoverPhoto(byte[] coverPhoto) 
	{
		this.coverPhoto = coverPhoto;
	}
	public int getStatus()
	{
		return status;
	}
	public void setStatus(int status) 
	{
		this.status = status;
	}
	public static long getSerialversionuid()
	{
		return serialVersionUID;
	}
	
	@Override
	public String toString()
	{
		return "UserProfileCoverPhotoVo [coverPhotoId=" + coverPhotoId + ", coverPhoto=" + Arrays.toString(coverPhoto)
				+ ", status=" + status + "]";
	}

}


