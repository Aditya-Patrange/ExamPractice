package com.cdac.sudarshan.theme.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.cdac.sudarshan.authentication.model.User;
import com.cdac.sudarshan.authentication.repository.UserRepository;
import com.cdac.sudarshan.authentication.service.IUserService;
import com.cdac.sudarshan.exception.DataAlreadyFoundException;
import com.cdac.sudarshan.exception.DataNotFoundException;
import com.cdac.sudarshan.exception.ResourceNotFoundException;
import com.cdac.sudarshan.theme.dto.ThemeCountDto;
import com.cdac.sudarshan.theme.dto.ThemeDto;
import com.cdac.sudarshan.theme.model.Keyword;
import com.cdac.sudarshan.theme.model.SubTheme;
import com.cdac.sudarshan.theme.model.Theme;
import com.cdac.sudarshan.theme.repository.IKeywordRepository;
import com.cdac.sudarshan.theme.repository.ISubThemeRepository;
import com.cdac.sudarshan.theme.repository.IThemeRepository;

@Service
public class ThemeServiceImpl implements IThemeService {

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private IThemeRepository themeRepository;

    @Autowired
    private IKeywordRepository keywordRepository;

    @Autowired
    private ISubThemeRepository subThemeRepository;

    @Autowired
    private IUserService userService;

    @Autowired
    private UserRepository userRepository;


    @Override
    public ThemeDto saveTheme(ThemeDto themeDto) {

        // user authentication
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication.getName() == null) {
            throw new ResourceNotFoundException("Please Login first For adding theme");
        }

        //check user exists or not
        User loggedInUser = userService.getUserByUserName(authentication.getName());

        //check theme with given name exists or not in db
        Theme existsTheme = themeRepository.findByThemePathAndUser(themeDto.getThemePath(), loggedInUser);

        //convert themeDto into corresponding entity
        //  Theme newTheme = convertToEntity(themeDto);

        if (existsTheme == null) {
            Theme theme = new Theme();
            theme.setThemePath(themeDto.getThemePath());
            theme.setUser(loggedInUser);

            //save theme to db
            Theme savedTheme = themeRepository.save(theme);
            return this.modelMapper.map(savedTheme, ThemeDto.class);
        } else {
            throw new DataAlreadyFoundException("Theme already exists choose another name");
        }
    }


    public List<ThemeDto> getAllThemes() {
        List<Theme> themes = themeRepository.findAll();

        if (themes.isEmpty()) {
            throw new DataNotFoundException("Themes not found");
        }

        //convert theme to themeDto

        return themes.stream().map(theme -> modelMapper.map(theme, ThemeDto.class))
                .collect(Collectors.toList());
    }


//    public List<ThemeDto> getAllThemes() {
//        List<Theme> themes = themeRepository.findAll();
//
//        if (themes.isEmpty()) {
//            throw new DataNotFoundException("Themes not found");
//        }
//
//        List<SubTheme> subThemes = new ArrayList<>();
//
//        List<ThemeDto> themeDtoList = new ArrayList<>();
//        for (Theme theme : themes) {
//            ThemeDto themeDto = new ThemeDto();
//            subThemes = theme.getSubThemes();
//            themeDto.setCreationDate(theme.getCreationDate());
//            themeDto.setLastUpdatedDate(theme.getLastUpdatedDate());
//            themeDto.setThemePath(theme.getThemePath());
//            themeDto.setId(theme.getId());
//            themeDto.setSubThemeCount(subThemes.size());
//
//            List<String> keywordsList = new ArrayList<>();
//            int totalKeywordsCount = 0;
//            for (SubTheme subTheme : subThemes) {
//                List<Keyword> keywordList = subTheme.getDataList();
//                for (Keyword keyword : keywordList) {
//                    keywordsList.add(keyword.getKeyword());
//                }
//                totalKeywordsCount += keywordList.size();
//                themeDto.setKeywordsCount(totalKeywordsCount);
//                themeDto.setKeywords(keywordsList);
//            }
//            themeDtoList.add(themeDto);
//        }
//
//        return themeDtoList;
//    }

    @Override
    public List<ThemeDto> getThemesOfLoggedInUser() {

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication.getName() == null) {
            throw new ResourceNotFoundException("Please Login first");
        }

        User user = userService.getUserByUserName(authentication.getName());

        if (user == null) {
            throw new ResourceNotFoundException("User does not exist with given username");
        }

        List<Theme> listOfThemesOfUser = themeRepository.findByUser(user);

        if (listOfThemesOfUser.isEmpty()) {
            throw new DataNotFoundException("Themes does not exist");
        }

        List<ThemeDto> listOfThemesDtoOfUser = listOfThemesOfUser.stream().
                map(theme -> this.modelMapper.map(theme, ThemeDto.class)).collect(Collectors.toList());

        return listOfThemesDtoOfUser;
    }

    @Override
    public List<ThemeDto> getRootThemesOfUser(Long userId) {
        User user = userRepository.findById(userId).orElseThrow(() -> new ResourceNotFoundException("Please Enter Valid User Id...!"));

        List<Theme> themesOfUser = themeRepository.findByUser(user);

        if (themesOfUser.isEmpty()) {
            throw new DataNotFoundException("There are not root themes");
        }
        List<ThemeDto> listOfThemesDto = themesOfUser.stream()
                .map(theme -> modelMapper.map(theme, ThemeDto.class))
                .collect(Collectors.toList());

        return listOfThemesDto;
    }

//    public Map<String, Integer> getItemCount(String path) {
//        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
//
//        if (authentication.getName() == null) {
//            throw new ResourceNotFoundException("Please Login first For getting urls count");
//        }
//
//        User loggedInUser = userService.getUserByUserName(authentication.getName());
//
//        String pathFilter = path.replaceAll("/", "");
//
//        if (path.isEmpty() || pathFilter.isEmpty() || !path.endsWith("/")) {
//            throw new PathNotFoundException("Please Enter valid Path or Entered Path is Empty");
//        }
//
//        String[] folderNames = path.split("/");
//        List<String> subFolderNames = new ArrayList<>();
//        for (String folder : folderNames) {
//            if (!folder.equals("")) {
//                subFolderNames.add(folder);
//            }
//        }
//        // Check entered path is root Folder or not
//        List<Theme> themes = themeRepository.findByThemePath(pathFilter);
//        if (!themes.isEmpty()) {
//            Map<String, Integer> data = getItemCountByRootID(themes.get(0).getId(), "root", pathFilter);
//            return data;
//        } else {
//            List<Theme> themeList  = themeRepository.findByThemePath(subFolderNames.get(0));
//            Map<String, Integer> data = getItemCountByRootID(themeList.get(0).getId(), "sub", path);
//            return data;
//        }
//        //	return null;
//    }
//
//    private Map<String, Integer> getItemCountByRootID(Long rootID, String themeType, String path) {
//        List<SubTheme> subThemePath = new ArrayList<>();
//        int[] array = new int[3];
//        Map<String, Integer> map = new HashMap<>();
//
//        if (themeType.equals("root")) {
//            // For Root folder data
//            List<Keyword> themeKeywords = keywordRepository.findByRootThemeId(rootID);
//
//            subThemePath = subThemeRepository.findByParentSubThemeId(themeKeywords.get(0).getId());
//
//            array[0] = array[0] + themeKeywords.size();
//            array[1] = array[1] + subThemePath.size();
//            array[2] = array[0] + array[1];
//
//            map.put("keywords", themeKeywords.size());
//            map.put("sub-themes", subThemePath.size());
//            map.put("total", array[2]);
//
//            return map;
//        }else{
//            SubTheme subTheme = subThemeRepository.findBySubThemePathAndRootThemeId(path, rootID);
//
//
//            List<Keyword> subThemeKeywords = keywordRepository.findKeywordBySubFolderPathId(subTheme.getId());
//
//            subThemePath = subThemeRepository.findByParentSubThemeId(subThemeKeywords.get(0).getId());
//
//            array[0] = array[0] + subThemeKeywords.size();
//            array[1] = array[1] + subThemePath.size();
//            array[2] = array[0] + array[1];
//
//            map.put("keywords", subThemeKeywords.size());
//            map.put("sub-themes", subThemePath.size());
//            map.put("total", array[2]);
//
//            return map;
//        }
//    }
//
    @Override
    public List<ThemeCountDto> getThemeKeywordCount() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication.getName() == null) {
            throw new ResourceNotFoundException("Please Login first For getting keyword count");
        }
        User loggedInUser = userService.getUserByUserName(authentication.getName());

        List<Theme> allthemes = themeRepository.findAll();
        List<ThemeCountDto> themeCountDtos = new ArrayList<>();
        for (Theme theme : allthemes) {
            ThemeCountDto themeCountDto = new ThemeCountDto();

            List<SubTheme> subthemes = subThemeRepository.findByTheme(theme);
            themeCountDto.setSubThemeCount(subthemes.size());
            themeCountDto.setThemeName(theme.getThemePath());
            int count = 0;
            for (SubTheme subtheme : subthemes) {
                List<Keyword> keywords = keywordRepository.findBySubTheme(subtheme);
                count += keywords.size();
            }

            themeCountDto.setKeyWordCount(count);
            themeCountDtos.add(themeCountDto);
        }

        return themeCountDtos;

    }


}
