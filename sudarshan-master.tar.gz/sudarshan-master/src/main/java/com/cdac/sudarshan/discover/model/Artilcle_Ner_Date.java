package com.cdac.sudarshan.discover.model;

import java.io.Serializable;
import java.util.ArrayList;

public class Artilcle_Ner_Date implements Serializable 
{
	private static final long serialVersionUID = 1L;
	private String keyword;
	private String sentence;
	private int nerSentiment=9;
	private int count;
	private ArrayList<String> nerDateTheme1;
	
	public String getKeyword() {
		return keyword;
	}
	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}
	public String getSentence() {
		return sentence;
	}
	public void setSentence(String sentence) {
		this.sentence = sentence;
	}
	public int getNerSentiment() {
		return nerSentiment;
	}
	public void setNerSentiment(int nerSentiment) {
		this.nerSentiment = nerSentiment;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public ArrayList<String> getNerDateTheme1() {
		return nerDateTheme1;
	}
	public void setNerDateTheme1(ArrayList<String> nerDateTheme1) {
		this.nerDateTheme1 = nerDateTheme1;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "Artilcle_Ner_Date [keyword=" + keyword + ", sentence=" + sentence + ", nerSentiment=" + nerSentiment
				+ ", count=" + count + ", nerDateTheme1=" + nerDateTheme1 + "]";
	}
	
}
