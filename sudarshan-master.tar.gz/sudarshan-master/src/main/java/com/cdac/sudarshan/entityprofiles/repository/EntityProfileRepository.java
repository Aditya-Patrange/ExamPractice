package com.cdac.sudarshan.entityprofiles.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cdac.sudarshan.entityprofiles.model.EntityProfile;

public interface EntityProfileRepository extends JpaRepository<EntityProfile, Long>{

}
