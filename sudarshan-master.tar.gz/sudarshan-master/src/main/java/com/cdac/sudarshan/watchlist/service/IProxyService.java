package com.cdac.sudarshan.watchlist.service;

import org.springframework.stereotype.Service;

import java.util.HashMap;

@Service
public interface IProxyService {
    public HashMap<String, Object> selectProxy(HashMap<String, Object> input);
}
