package com.cdac.sudarshan.discover.model;

import java.io.Serializable;

public class ArticleUrl implements Serializable
{
	private static final long serialVersionUID = 1L;
	private String title;
	private String author;
	private String content;
	private String url;
    private long publishDate;

	public long getPublishDate() {
		return publishDate;
	}

	public void setPublishDate(long publishDate) {
		this.publishDate = publishDate;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}
	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "ArticleUrl [title=" + title + ", author=" + author + ", content=" + content + ", url=" + url
				+ ", publishDate=" + publishDate + "]";
	}
	
}
