package com.cdac.sudarshan.discover.model;

import javax.persistence.Entity;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Entity
@Setter
@Getter
@RequiredArgsConstructor
public class Country extends BaseEntity{
	private String countryCode;
	private String countryName;
	private String code;
	private String phoneCode;
public Country(String countryCode){
	this.countryCode=countryCode;
}
}
