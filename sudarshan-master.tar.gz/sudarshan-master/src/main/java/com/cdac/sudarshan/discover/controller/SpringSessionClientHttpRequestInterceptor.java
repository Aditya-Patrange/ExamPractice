package com.cdac.sudarshan.discover.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RequestCallback;
import org.springframework.web.client.ResponseExtractor;
import org.springframework.web.client.RestTemplate;

@Component
public class SpringSessionClientHttpRequestInterceptor implements ClientHttpRequestInterceptor {
	
	
	@Override
	public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution)
			throws IOException {
		
//		String user = "admin";
//		String pw = "admin@123";
//		RestTemplate template = new RestTemplate();
//		System.out.println(response.getHeaders().getFirst("Set-Cookie"));
		String sessionId = "9284A2C2CDC4410A1F3369DAD5B6F7F3";
//		request.getHeaders().add("Cookie", response.getHeaders().getFirst("Set-Cookie"));
		request.getHeaders().add("Cookie", "JSESSIONID=" + sessionId);
		return execution.execute(request, body);
	}
}
	