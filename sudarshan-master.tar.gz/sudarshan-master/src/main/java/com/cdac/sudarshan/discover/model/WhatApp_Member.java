package com.cdac.sudarshan.discover.model;

import java.io.Serializable;

public class WhatApp_Member implements Serializable
{
	private static final long serialVersionUID = 1L;
	private String memberName;
    private String memberPhone;
    private String memberImg;
    private String memberStatus;
    
	public String getMemberName() 
	{
		return memberName;
	}
	public void setMemberName(String memberName) 
	{
		this.memberName = memberName;
	}
	public String getMemberPhone() 
	{
		return memberPhone;
	}
	public void setMemberPhone(String memberPhone)
	{
		this.memberPhone = memberPhone;
	}
	public String getMemberImg() 
	{
		return memberImg;
	}
	public void setMemberImg(String memberImg)
	{
		this.memberImg = memberImg;
	}
	public String getMemberStatus()
	{
		return memberStatus;
	}
	public void setMemberStatus(String memberStatus) 
	{
		this.memberStatus = memberStatus;
	}
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString()
	{
		return "WhatApp_Member [memberName=" + memberName + ", memberPhone=" + memberPhone + ", memberImg=" + memberImg
				+ ", memberStatus=" + memberStatus + "]";
	}
}
