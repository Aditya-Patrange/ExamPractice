           package com.cdac.sudarshan.discover.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cdac.sudarshan.discover.model.TweeterActionVo;
import com.cdac.sudarshan.discover.model.TwitterVo;
import com.cdac.sudarshan.discover.service.KISourceService;


@RestController
@RequestMapping("/eva")
@CrossOrigin("*")
public class KDiscoverController {
	@Autowired
	private KISourceService sourceService;
	
	// test completed in postman	
	/** 
	 * It is used to get Tweets from twitter
	 * */
	@PostMapping("/getTweets")
	public ResponseEntity<?> getTweets(@RequestBody HashMap<String , Object> data) {
		return new ResponseEntity<>(sourceService.getTweets(data), HttpStatus.OK);
	}
	
	// test completed in postman
	/** 
	 * It is used to get Hash tags from twitter
	 * */
	@PostMapping("/getHashTags")
    public ResponseEntity<?> getHashTags(@RequestBody HashMap<String, Object> data) {
		return new ResponseEntity<>(sourceService.getHashTags(data), HttpStatus.OK);	
	}

	// test completed in postman
	/** 
	 * It is used to get Languages from twitter
	 * */
	@PostMapping("/getLanguage")
	public ResponseEntity<?> getLanguage(@RequestBody HashMap<String, Object> data) {
	    return new ResponseEntity<>(sourceService.getLanguage(data), HttpStatus.OK);
	}

	// test completed in postman
	/** 
	 * It is used to get countries from twitter
	 * */
	@PostMapping("/getCountry")
	public ResponseEntity<?> getCountry(@RequestBody HashMap<String, Object> data) {
	    return new ResponseEntity<>(sourceService.getCountry(data), HttpStatus.OK);
	}
	
	// test completed in postman
	/** 
	 * It is used to get author country from twitter
	 * */
	@PostMapping("/getAuthorCountry")
	public ResponseEntity<?> getAuthorCountry(@RequestBody HashMap<String, Object> data) {
	    return new ResponseEntity<>(sourceService.getAuthorCountry(data), HttpStatus.OK);
	}

	// test completed in postman
	/** 
	 * It is used to get Meta tags from twitter
	 * */
	@PostMapping("/getMetaTagsNer")
	public ResponseEntity<?> getMetaTagsNer(@RequestBody HashMap<String, Object> data) {	
		
	   return new ResponseEntity<>(sourceService.getMetaTagsNer(data), HttpStatus.OK);
	}
	

	// test completed in postman
	/** 
	 * It is used to get users from twitter
	 * */
	@PostMapping("/getUsers")
	public ResponseEntity<?> getUsers(@RequestBody HashMap<String, Object> data) {
	   return new ResponseEntity<>(sourceService.getUsers(data), HttpStatus.OK);
	}
	
	// test completed in postman
	/** 
	 * It is used to get users from twitter
	 * */
	@PostMapping("/getAllAttriubuteCount")
	public ResponseEntity<?> getAllAttriubuteCount(@RequestBody HashMap<String, Object> data) {
	   return new ResponseEntity<>(sourceService.getAllAttriubuteCount(data), HttpStatus.OK);
	}
	
	// test completed in postman
	/** 
	 * It is used to get users from twitter
	 * */
	@PostMapping("/getAlertCounts")
	public ResponseEntity<?> getAlertCounts(@RequestBody HashMap<String, Object> data) {
	   return new ResponseEntity<>(sourceService.getAlertCounts(data), HttpStatus.OK);
	}
	
	
	// test completed in postman
	/** 
	 * It is used to get users from twitter
	 * */
	@PostMapping("/getMedia")
	public ResponseEntity<?> getMedia(@RequestBody HashMap<String, Object> data) {
	   return new ResponseEntity<>(sourceService.getMedia(data), HttpStatus.OK);
	}
	
	
	// test completed in postman
	/** 
	 * It is used to get users from twitter
	 * */
	@PostMapping("/geoTweetsLatLong")
	public ResponseEntity<?> geoTweetsLatLong(@RequestBody HashMap<String, Object> data) {
	   return new ResponseEntity<>(sourceService.geoTweetsLatLong(data), HttpStatus.OK);
	}
	
	// test completed in postman
	/** 
	 * It is used to get users from twitter
	 * */
	@PostMapping("/getPlaceWordCloud")
	public ResponseEntity<?> getPlaceWordCloud(@RequestBody HashMap<String, Object> data) {
	   return new ResponseEntity<>(sourceService.getPlaceWordCloud(data), HttpStatus.OK);
	}
	
	// test completed in postman
	/** 
	 * It is used to get users from twitter
	 * */
	@PostMapping("/getOrganizationWordCloud")
	public ResponseEntity<?> getOrganizationWordCloud(@RequestBody HashMap<String, Object> data) {
	   return new ResponseEntity<>(sourceService.getOrganizationWordCloud(data), HttpStatus.OK);
	}
	
	
	
	// test completed in postman
	/** 
	 * It is used to get users from twitter
	 * */
	@PostMapping("/getUserWordCloud")
	public ResponseEntity<?> getUserWordCloud(@RequestBody HashMap<String, Object> data) {
	   return new ResponseEntity<>(sourceService.getUserWordCloud(data), HttpStatus.OK);
	}
	
	
	// test completed in postman
	/** 
	 * It is used to get users from twitter
	 * */
	@PostMapping("/getThemeWordCloud")
	public ResponseEntity<?> getThemeWordCloud(@RequestBody HashMap<String, Object> data) {
	   return new ResponseEntity<>(sourceService.getThemeWordCloud(data), HttpStatus.OK);
	}
	
	
	// facebook flow start
	@PostMapping("/getAllDashboard")
	public ResponseEntity<?> getAllDashboard(@RequestBody HashMap<String, Object> data) {
	   return new ResponseEntity<>(sourceService.getAllDashboard(data), HttpStatus.OK);
	}
	
	@PostMapping("/getUserCurrentDashboard")
	public ResponseEntity<?> getUserCurrentDashboard(@RequestParam("caseId") String caseId, @RequestBody HashMap<String, Object> data) {
		return new ResponseEntity<>(sourceService.getUserCurrentDashboard(caseId, data), HttpStatus.OK);
	}
	
	@PostMapping("/getWidgetsByDashboardId")
	public ResponseEntity<?> getWidgetsByDashboardId(@RequestParam("dashboardId") String dashboardId, @RequestBody HashMap<String, Object> data) {
		return new ResponseEntity<>(sourceService.getWidgetsByDashboardId(dashboardId, data), HttpStatus.OK);
	}
	
	@PostMapping("/dashActiveMedia")
	public ResponseEntity<?> dashActiveMedia(@RequestBody TweeterActionVo tweeterActionVo) {
		return new ResponseEntity<>(sourceService.dashActiveMedia(tweeterActionVo), HttpStatus.OK);
	}
	
	@PostMapping("/dashArticles")
	public ResponseEntity<?> dashArticles(@RequestBody HashMap<String, Object> data) {
		return new ResponseEntity<>(sourceService.dashArticles(data), HttpStatus.OK);
	}
	
	@PostMapping("/getAllWidget")
	public ResponseEntity<?> getAllWidget(@RequestBody HashMap<String, Object> data) {
		return new ResponseEntity<>(sourceService.getAllWidget(data), HttpStatus.OK);
	}
	
	
	@PostMapping("/getTweetDetailById")
	public ResponseEntity<?> getTweetDetailById(@RequestBody HashMap<String, Object> data) {
		return new ResponseEntity<>(sourceService.getTweetDetailById(data), HttpStatus.OK);
	}
			
	@PostMapping("/updateCollectionById")
	public ResponseEntity<?> updateCollectionDateBySourceAndKeywordMatch(@RequestBody HashMap<String, Object> data) {
		return new ResponseEntity<>(sourceService.updateCollectionDateBySourceAndKeywordMatch(data),  HttpStatus.OK);
	}
	
	@PostMapping("/getSentimentTimeline")
	public ResponseEntity<?> getSentimentTimeline(@RequestBody HashMap<String, Object> data) {
		return new ResponseEntity<>(sourceService.getSentimentTimeline(data),  HttpStatus.OK);
	}
	
	@PostMapping("/getDashEntityCount")
	public ResponseEntity<?> getDashEntityCount(@RequestBody HashMap<String, Object> data) {
		return new ResponseEntity<>(sourceService.getDashEntityCount(data),  HttpStatus.OK);
	}
	
	@PostMapping("/getDashActiveEntity")
	public ResponseEntity<?> getDashActiveEntity(@RequestBody HashMap<String, Object> data) {
		return new ResponseEntity<>(sourceService.getDashActiveEntity(data),  HttpStatus.OK);
	}
	
	@PostMapping("/getFieldTypeData")
	public ResponseEntity<?> getFieldTypeData(@RequestBody HashMap<String, Object> data) {
		return new ResponseEntity<>(sourceService.getFieldTypeData(data),  HttpStatus.OK);
	}
	
	@PostMapping("/dashActiveUser")
	public ResponseEntity<?> dashActiveUser(@RequestBody HashMap<String, Object> data) {
		return new ResponseEntity<>(sourceService.dashActiveUser(data),  HttpStatus.OK);
	}
	
	
	@PostMapping("/getSummary")
	public ResponseEntity<?> getSummary(@RequestBody HashMap<String, Object> data) {
		return new ResponseEntity<>(sourceService.getSummary(data),  HttpStatus.OK);
	}
	
	@PostMapping("/fb_scrapy_basic_info")
	public ResponseEntity<?> fbScrapyBasicInfo(@RequestBody HashMap<String, Object> data) {
		return new ResponseEntity<>(sourceService.fbScrapyBasicInfo(data),  HttpStatus.OK);
	}
	
	@PostMapping("/fb_scrapy_user_media")
	public ResponseEntity<?> fbScrapyUserMedia(@RequestBody HashMap<String, Object> data) {
		return new ResponseEntity<>(sourceService.fbScrapyUserMedia(data),  HttpStatus.OK);
	}
	
	@PostMapping("/fb_scrapy_user_check_ins")
	public ResponseEntity<?> fbScrapyUserCheckIns(@RequestBody HashMap<String, Object> data) {
		return new ResponseEntity<>(sourceService.fbScrapyUserCheckIns(data),  HttpStatus.OK);
	}
	
	@PostMapping("/fb_scrapy_user_likes")
	public ResponseEntity<?> fbScrapyUserLikes(@RequestBody HashMap<String, Object> data) {
		return new ResponseEntity<>(sourceService.fbScrapyUserLikes(data),  HttpStatus.OK);
	}
	
	@PostMapping("/fbTopMostUserStrongConnection")
	public ResponseEntity<?> fbTopMostUserStrongConnection(@RequestBody HashMap<String, Object> data) {
		return new ResponseEntity<>(sourceService.fbTopMostUserStrongConnection(data),  HttpStatus.OK);
	}
	
	@PostMapping("/fb_scrapy_user_friends")
	public ResponseEntity<?> fbScrapyUserFriends(@RequestBody HashMap<String, Object> data) {
		return new ResponseEntity<>(sourceService.fbScrapyUserFriends(data),  HttpStatus.OK);
	}
	
	@PostMapping("/getFBPeopleProfileWithSameGroup")
	public ResponseEntity<?> getFBPeopleProfileWithSameGroup(@RequestBody HashMap<String, Object> data) {
		return new ResponseEntity<>(sourceService.getFBPeopleProfileWithSameGroup(data),  HttpStatus.OK);
	}
	
	@PostMapping("/getFBPeopleProfileWithSameLikes")
	public ResponseEntity<?> getFBPeopleProfileWithSameLikes(@RequestBody HashMap<String, Object> data) {
		return new ResponseEntity<>(sourceService.getFBPeopleProfileWithSameLikes(data),  HttpStatus.OK);
	}
	
	@PostMapping("/getFBPeopleProfileWithSameCheckIn")
	public ResponseEntity<?> getFBPeopleProfileWithSameCheckIn(@RequestBody HashMap<String, Object> data) {
		return new ResponseEntity<>(sourceService.getFBPeopleProfileWithSameCheckIn(data),  HttpStatus.OK);
	}
	
	
	@PostMapping("/getFBPeopleProfileWithSameLocation")
	public ResponseEntity<?> getFBPeopleProfileWithSameLocation(@RequestBody HashMap<String, Object> data) {
		return new ResponseEntity<>(sourceService.getFBPeopleProfileWithSameLocation(data),  HttpStatus.OK);
	}
	
	@PostMapping("/getSentiment")
	public ResponseEntity<?> getSentiment(@RequestBody HashMap<String, Object> data) {
		return new ResponseEntity<>(sourceService.getSentiment(data),  HttpStatus.OK);
	}
	
	@PostMapping("/checkRetweetStatus")
	public ResponseEntity<?> checkRetweetStatus(@RequestBody HashMap<String, Object> data) {
		return new ResponseEntity<>(sourceService.checkRetweetStatus(data),  HttpStatus.OK);
	}
	
	@PostMapping("/getTweetsPostCount")
	public ResponseEntity<?> getTweetsPostCount(@RequestBody TweeterActionVo tweeterActionVo) 
	{
		return new ResponseEntity<>(sourceService.getTweetsPostCount(tweeterActionVo),  HttpStatus.OK);
	}
		
	@PostMapping("/getTweetsPostCountOnly")
	public ResponseEntity<?> getTweetsPostCountOnly(@RequestBody TweeterActionVo tweeterActionVo) 
	{
		return new ResponseEntity<>(sourceService.getTweetsPostCountOnly(tweeterActionVo),  HttpStatus.OK);
	}
	
	@PostMapping("/dashActiveMediaCount")
	public ResponseEntity<?> dashActiveMediaCount(@RequestBody TweeterActionVo tweeterActionVo) 
	{
		return new ResponseEntity<>(sourceService.dashActiveMediaCount(tweeterActionVo),  HttpStatus.OK);
	}

	@RequestMapping(value="/exportSlideWordTweets")
	public ResponseEntity<?> exportSlideTweetWord(@RequestBody HashMap<String,Object> data) {
		return new ResponseEntity<>(sourceService.exportSlideTweetWord(data),  HttpStatus.OK);
	}
	
	
	@RequestMapping(value="/collectionCountUserWise")
	public ResponseEntity<?> collectionCountUserWise(@RequestBody HashMap<String,Object> data) {
		return new ResponseEntity<>(sourceService.collectionCountUserWise(data),  HttpStatus.OK);
	}
	
	
	@RequestMapping(value="/collectionInactiveStatusCountUserWise")
	public ResponseEntity<?> collectionInactiveStatusCountUserWise(@RequestBody HashMap<String,Object> data) {
		return new ResponseEntity<>(sourceService.collectionInactiveStatusCountUserWise(data),  HttpStatus.OK);
	}
	
	@RequestMapping(value="/collectionActiveStatusCountUserWise")
	public ResponseEntity<?> collectionActiveStatusCountUserWise(@RequestBody HashMap<String,Object> data) {
		return new ResponseEntity<>(sourceService.collectionActiveStatusCountUserWise(data),  HttpStatus.OK);
	}

	@RequestMapping(value="/getProxyCountry")
	public ResponseEntity<?> getProxyCountry(@RequestBody HashMap<String,Object> data) {
		return new ResponseEntity<>(sourceService.getProxyCountry(data),  HttpStatus.OK);
	}

	@RequestMapping(value="/getNewsPaperSourceValues")
	public ResponseEntity<?> getNewsPaperSourceValues(@RequestBody HashMap<String,Object> data) {
		return new ResponseEntity<>(sourceService.getNewsPaperSourceValues(data),  HttpStatus.OK);
	}
	
	@RequestMapping(value="/getAllTagsFromThemeUserWise")
	public ResponseEntity<?> getAllTagsFromThemeUserWise() {
		return new ResponseEntity<>(sourceService.getAllTagsFromThemeUserWise(),  HttpStatus.OK);
	}
	// facebook flow end
}
