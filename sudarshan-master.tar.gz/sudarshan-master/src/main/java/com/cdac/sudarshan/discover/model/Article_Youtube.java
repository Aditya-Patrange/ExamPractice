package com.cdac.sudarshan.discover.model;

import java.io.Serializable;
import java.util.ArrayList;

public class Article_Youtube implements Serializable 
{
	private static final long serialVersionUID = 1L;
	private Integer ytViewCount;
	private Integer ytLikeCount;
	private Integer ytDisLikeCount;
	private Integer ytFavoriteCount;
	private Integer ytCommentCount;
	private long ytNextUpdatedDate;
	private String ytThumblnailUrl;
	private String ytPlayListId;
	private String ytIsActive="active";
	private ArrayList<Article_YoutubeStats> videoStats;

	public Integer getYtViewCount() {
		return ytViewCount;
	}
	public void setYtViewCount(Integer ytViewCount) {
		this.ytViewCount = ytViewCount;
	}
	public Integer getYtLikeCount() {
		return ytLikeCount;
	}
	public void setYtLikeCount(Integer ytLikeCount) {
		this.ytLikeCount = ytLikeCount;
	}
	public Integer getYtDisLikeCount() {
		return ytDisLikeCount;
	}
	public void setYtDisLikeCount(Integer ytDisLikeCount) {
		this.ytDisLikeCount = ytDisLikeCount;
	}
	public Integer getYtFavoriteCount() {
		return ytFavoriteCount;
	}
	public void setYtFavoriteCount(Integer ytFavoriteCount) {
		this.ytFavoriteCount = ytFavoriteCount;
	}
	public Integer getYtCommentCount() {
		return ytCommentCount;
	}
	public void setYtCommentCount(Integer ytCommentCount) {
		this.ytCommentCount = ytCommentCount;
	}
	public String getYtThumblnailUrl() {
		return ytThumblnailUrl;
	}
	public void setYtThumblnailUrl(String ytThumblnailUrl) {
		this.ytThumblnailUrl = ytThumblnailUrl;
	}
	public String getYtPlayListId() {
		return ytPlayListId;
	}
	public void setYtPlayListId(String ytPlayListId) {
		this.ytPlayListId = ytPlayListId;
	}

	public long getYtNextUpdatedDate() {
		return ytNextUpdatedDate;
	}
	public void setYtNextUpdatedDate(long ytNextUpdatedDate) {
		this.ytNextUpdatedDate = ytNextUpdatedDate;
	}
	public ArrayList<Article_YoutubeStats> getVideoStats() {
		return videoStats;
	}
	public void setVideoStats(ArrayList<Article_YoutubeStats> videoStats) {
		this.videoStats = videoStats;
	}
	public String getYtIsActive() {
		return ytIsActive;
	}
	public void setYtIsActive(String ytIsActive) {
		this.ytIsActive = ytIsActive;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "Article_Youtube [ytViewCount=" + ytViewCount + ", ytLikeCount=" + ytLikeCount + ", ytDisLikeCount="
				+ ytDisLikeCount + ", ytFavoriteCount=" + ytFavoriteCount + ", ytCommentCount=" + ytCommentCount
				+ ", ytThumblnailUrl=" + ytThumblnailUrl + ", ytPlayListId=" + ytPlayListId + ", ytNextUpdatedDate="
				+ ytNextUpdatedDate + ", ytIsActive=" + ytIsActive + ", videoStats=" + videoStats + "]";
	}

}
