package com.cdac.sudarshan.authentication.dto;

import com.cdac.sudarshan.authentication.model.Role;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class UserDto {

    private Long id;
    private String userName;
    private String password;
    private Boolean enabled;
    private Role role;
    private String comment;
    private String createdBy;
    private String templateId;
    private boolean totp;

}
