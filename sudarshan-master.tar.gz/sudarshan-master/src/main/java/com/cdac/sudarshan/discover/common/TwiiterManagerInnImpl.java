package com.cdac.sudarshan.discover.common;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.sudarshan.discover.model.ArticleDataExportVo;
import com.cdac.sudarshan.discover.model.CommonArticleVo;
import com.cdac.sudarshan.discover.model.CommonFbVo;
import com.cdac.sudarshan.discover.model.CountryCode;
import com.cdac.sudarshan.discover.model.Fb_OutputVo;
import com.cdac.sudarshan.discover.model.Fb_groupVo;
import com.cdac.sudarshan.discover.model.InnsightTrends;
import com.cdac.sudarshan.discover.model.KeyMapVo;
import com.cdac.sudarshan.discover.model.TweetHashTagsTblVo;
import com.cdac.sudarshan.discover.model.TweetLinksTblVo;
import com.cdac.sudarshan.discover.model.TweetMentionTblVo;
import com.cdac.sudarshan.discover.model.TweetTblVo;
import com.cdac.sudarshan.discover.model.TweetUserTblVo;
import com.cdac.sudarshan.discover.model.TweeterActionVo;
import com.cdac.sudarshan.discover.model.TwitterKloutVo;
import com.cdac.sudarshan.discover.model.TwitterTrendsVo;
import com.cdac.sudarshan.discover.model.TwitterUserListVo;
import com.cdac.sudarshan.discover.model.TwitterVo;
import com.cdac.sudarshan.discover.model.UserProfileConnectionExportVo;
import com.cdac.sudarshan.discover.model.UserProfileExportVo;
import com.google.gson.internal.LinkedTreeMap;


@Service
public class TwiiterManagerInnImpl implements TwitterManagerInn 
{
	@Autowired
	private TwitterInnDao tweetInnDao;
	
	@Override
	public ArrayList<TwitterVo> getTweets(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getTweets(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getHashTags(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getHashTags(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getUsers(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getUsers(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getAllAuthorsDetails(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getAllAuthorsDetails(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo>	getUsersOnly(TweeterActionVo tweeterActionVo)
	{
		return tweetInnDao.getUsersOnly(tweeterActionVo);
	}
	
	@Override
	public ArrayList<TwitterVo> getTwUsersDetails(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getTwUsersDetails(tweeterActionVo);
	}
	
	@Override
	public ArrayList<TwitterVo> getMedia(TweeterActionVo tweeterActionVo) {
		return tweetInnDao.getMedia(tweeterActionVo);
	}

	@Override
	public ArrayList<TwitterVo> getTweetGeo(TweeterActionVo tweeterActionVo) {
		return tweetInnDao.getTweetGeo(tweeterActionVo);
	}

	@Override
	public ArrayList<TwitterVo> getTweetGraph(TweeterActionVo tweeterActionVo) {
		return tweetInnDao.getTweetGraph(tweeterActionVo);
	}

	@Override
	public ArrayList<TwitterVo> getTweetDetailById(TweeterActionVo tweeterActionVo) {
		return tweetInnDao.getTweetDetailById(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getArticleDetailsById(TweeterActionVo tweeterActionVo)
	{
		return tweetInnDao.getArticleDetailsById(tweeterActionVo);
	}
	
	
	
	@Override
	public ArrayList<TwitterVo> getUserDetailById(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getUserDetailById(tweeterActionVo);
	}

	@Override
	public ArrayList<TwitterVo> getRetweetGraph(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getRetweetGraph(tweeterActionVo);
	}

	@Override
	public ArrayList<TwitterVo> getTweetRetweetCount(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getTweetRetweetCount(tweeterActionVo);
	}

	@Override
	public  void setTweetOperation(TweeterActionVo tweeterActionVo) 
	{
		tweetInnDao.setTweetOperation(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getLink(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getLink(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> userTweetCount(TweeterActionVo tweeterActionVo)
	{
		return tweetInnDao.userTweetCount(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> CheckQueryReport(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.CheckQueryReport(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getSentiment(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getSentiment(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getMention(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getMention(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getTwGeoMap(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getTwGeoMap(tweeterActionVo);	
	}
	@Override
	public ArrayList<TwitterVo> getTwWordCloud(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getTwWordCloud(tweeterActionVo);
	}
	@Override
	public void getUpdatePriority(TweeterActionVo tweeterActionVo)
	{
		tweetInnDao.getUpdatePriority(tweeterActionVo);
	}

	@Override
	public ArrayList<TwitterVo> getTimeLine(TweeterActionVo tweeterActionVo) 
	{

		return tweetInnDao.getTimeLine(tweeterActionVo);
	}

	@Override
	public ArrayList<TwitterVo> getMentionUserLink(TweeterActionVo tweeterActionVo)
	{
		return tweetInnDao.getMentionUserLink(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getHashLink(TweeterActionVo tweeteractionvo)
	{
		return tweetInnDao.getHashLink(tweeteractionvo);
	}

	public ArrayList<TwitterVo> getHashtagWordCloud(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getHashtagWordCloud(tweeterActionVo);
	}

	public ArrayList<TwitterVo> getUserWordCloud(TweeterActionVo tweeterActionVo)
	{
		return tweetInnDao.getUserWordCloud(tweeterActionVo);
	}

	public ArrayList<TwitterVo> getMentionWordCloud(TweeterActionVo tweeterActionVo)
	{
		return tweetInnDao.getMentionWordCloud(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getTweetDomainLink(TweeterActionVo tweeterActionVo)
	{
		return tweetInnDao.getTweetDomainLink(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getTweetUrlLink(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getTweetUrlLink(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getFollFollowing(TweeterActionVo tweeterActionVo)
	{
		return tweetInnDao.getFollFollowing(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getTweetSentimentTimeLineGraph(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getTweetSentimentTimeLineGraph(tweeterActionVo);
	}

	@Override
	public ArrayList<TwitterVo> getRetweetOfTweet(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getRetweetOfTweet(tweeterActionVo);
	}

	@Override
	public ArrayList<TwitterVo> getTimeLineDayOfWeek(TweeterActionVo tweeterActionVo)
	{
		return tweetInnDao.getTimeLineDayOfWeek(tweeterActionVo);
	}

	@Override
	public ArrayList<TwitterVo> getTimeLineDayOfHour(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getTimeLineDayOfHour(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> gettweetStatsOffLine(TweeterActionVo tweeterActionVo)
	{
		return tweetInnDao.gettweetStatsOffLine(tweeterActionVo);
	}

	@Override
	public ArrayList<TwitterVo> userDetailReportFollowers(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.userDetailReportFollowers(tweeterActionVo);
	}

	@Override
	public ArrayList<TwitterVo> userDetailReportFollowing(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.userDetailReportFollowing(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> userInfluerncerInfluencee(TweeterActionVo tweeterActionVo)
	{
		return tweetInnDao.userInfluerncerInfluencee(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> userTopRetweet(TweeterActionVo tweeterActionVo)
	{
		return tweetInnDao.userTopRetweet(tweeterActionVo);
	}

	@Override
	public ArrayList<TwitterVo> userTopReply(TweeterActionVo tweeterActionVo)
	{
		return tweetInnDao.userTopReply(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> userTopSource(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.userTopSource(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> userTopList(TweeterActionVo tweeterActionVo)
	{
		return tweetInnDao.userTopList(tweeterActionVo);
	}
	@Override
	public void setTweetIdForReTweet(TweeterActionVo tweeterActionVo) 
	{
		tweetInnDao.setTweetIdForReTweet(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> checkRetweetStatus(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.checkRetweetStatus(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getTwitterApi(String type)
	{
		return tweetInnDao.getTwitterApi(type);
	}
	@Override
	public void crawlAllTweetsOfUser(ArrayList<TweetTblVo> tweetTblVos,
			ArrayList<TweetHashTagsTblVo> hashTagsTblVos,
			ArrayList<TweetMentionTblVo> mentionTblVos,
			ArrayList<TweetLinksTblVo> tweetLinksTblVos,
			ArrayList<TweetUserTblVo> tweetUserTblVos,int entityId) 
	{
		tweetInnDao.crawlAllTweetsOfUser(tweetTblVos,
				hashTagsTblVos,
				mentionTblVos,
				tweetLinksTblVos,
				tweetUserTblVos,entityId);
	}

	@Override
	public ArrayList<String> getAllTweetsByProfileEntity(String screenName) 
	{
		return tweetInnDao.getAllTweetsByProfileEntity(screenName);
	}
	@Override
	public void crawlAllFolowerFollowingOfUser(
			ArrayList<TweetUserTblVo> tweetUserTblVos, String screenName,
			String userId, String type) 
	{
		tweetInnDao.crawlAllFolowerFollowingOfUser(tweetUserTblVos, screenName, userId, type);
	}
	@Override
	public ArrayList<TwitterVo> getUserIdByScreenName(String screenName) 
	{
		return tweetInnDao.getUserIdByScreenName(screenName);
	}
	@Override
	public void crawlAllListOfUser(ArrayList<TwitterUserListVo> twitterUserListVos) 
	{
		tweetInnDao.crawlAllListOfUser(twitterUserListVos);
	}
	@Override
	public ArrayList<TwitterVo> getTweetsUsrDtlRpt(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getTweetsUsrDtlRpt(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getHashTagsUsrDtlRpt(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getHashTagsUsrDtlRpt(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getLinkUsrDtlRpt(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getLinkUsrDtlRpt(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getMediaUsrDtlRpt(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getMediaUsrDtlRpt(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getMentionUsrDtlRpt(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getMentionUsrDtlRpt(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getTweetGraphUsrDtlRpt(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getTweetGraphUsrDtlRpt(tweeterActionVo);
	}
	@Override
	public void crawlKloutDataOfUser(ArrayList<TwitterKloutVo> lstInfluencer, ArrayList<TwitterKloutVo> lstInfluencee, String screenName)
	{
		tweetInnDao.crawlKloutDataOfUser(lstInfluencer, lstInfluencee, screenName);
	}
	@Override
	public String checkUserEntity(String screenName) 
	{
		return 	tweetInnDao.checkUserEntity(screenName);
	}
	@Override
	public ArrayList<TwitterVo> getTwProfileEntityWithFollowers(TweeterActionVo tweeterActionVo) 
	{
		return 	tweetInnDao.getTwProfileEntityWithFollowers(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getCommonFollower_Following(TweeterActionVo tweeterActionVo) 
	{
		return 	tweetInnDao.getCommonFollower_Following_Report(tweeterActionVo);//       .getCommonFollower_Following(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getTwProfileEntityWithFollowersFin(TweeterActionVo tweeterActionVo) 
	{
		return 	tweetInnDao.getTwProfileEntityWithFollowersFin(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getCommonFollower_FollowingMaxMin(TweeterActionVo tweeterActionVo) 
	{
		return 	tweetInnDao.getCommonFollower_FollowingMaxMin(tweeterActionVo);
	}
	@Override
	public void updateTwitterFollower_Following(ArrayList<TweetUserTblVo> tweetUserTblVos) 
	{
		tweetInnDao.updateTwitterFollower_Following(tweetUserTblVos);
	}
	@Override
	public ArrayList<TwitterVo> getTwitterLinkAnalysis(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getTwitterLinkAnalysis(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getFBExcelCommonLinkAnalysis(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getFBExcelCommonLinkAnalysis(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getLinkedinExcelCommonLinkAnalysis(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getLinkedinExcelCommonLinkAnalysis(tweeterActionVo);
	}
	
	@Override
	public ArrayList<TwitterVo> getTwitterExcelCommonLinkAnalysis(TweeterActionVo tweeterActionVo)
	{
		return tweetInnDao.getTwitterExcelCommonLinkAnalysis(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getTwitterExcelCommonFriendsLinkAnalysis(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getTwitterExcelCommonFriendsLinkAnalysis(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getTwitterExcelCommonLinkAnalysisTrendsData(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getTwitterExcelCommonLinkAnalysisTrendsData(tweeterActionVo);
	}
	
	@Override
	public ArrayList<TwitterVo> getCommonFollower_Following_Source(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getCommonFollower_Following_Source(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getTimeLineDayOfWeekCmnProfile(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getTimeLineDayOfWeekCmnProfile(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getTimeLineDayOfHourCmnProfile(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getTimeLineDayOfHourCmnProfile(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> geoTweetsByLoc(TweeterActionVo tweeterActionVo)
	{
	    return tweetInnDao.geoTweetsByLoc(tweeterActionVo);
	}
	public ArrayList<TwitterVo> geoProfileTwitter(TweeterActionVo tweeterActionVo)
	{
	    return tweetInnDao.geoProfileTwitter(tweeterActionVo);
	}
	public ArrayList<TwitterVo> geoTweetsLatLong(TweeterActionVo tweeterActionVo) 
	{
	    return tweetInnDao.geoTweetsLatLong(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> geoRptLatLongRetweetUser(TweeterActionVo tweeterActionVo) 
	{
	    return tweetInnDao.geoRptLatLongRetweetUser(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getSentimentcounty(TweeterActionVo tweeterActionVo) 
	{
	    return tweetInnDao.getSentimentcounty(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> geoProfileDetails(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.geoProfileDetails(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> geoTweetRetweetsLatLong(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.geoTweetRetweetsLatLong(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getCommonFollower_Following_Report(TweeterActionVo tweeterActionVo)
	{
		return tweetInnDao.getCommonFollower_Following_Report(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getCommonFollower_Following_Source_Report(TweeterActionVo tweeterActionVo)
	{
		return tweetInnDao.getCommonFollower_Following_Source_Report(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getTweetDetailByParam(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getTweetDetailByParam(tweeterActionVo);
	}
	@Override
	public ArrayList<CountryCode> getCountryCode() 
	{
		return  tweetInnDao.getCountryCode();
	}
	@Override
	public ArrayList<TwitterVo> getMetaTags(TweeterActionVo tweeterActionVo) {
		return tweetInnDao.getMetaTags(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getPersonWordCloud(TweeterActionVo tweeterActionVo)
	{
		return tweetInnDao.getPersonWordCloud(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getPlaceWordCloud(TweeterActionVo tweeterActionVo)
	{
		return tweetInnDao.getPlaceWordCloud(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getOrganizationWordCloud(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getOrganizationWordCloud(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getEventsWordCloud(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getEventsWordCloud(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> geoCloud(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.geoCloud(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> dashSourceCount(TweeterActionVo tweeterActionVo)
	{
		return tweetInnDao.dashSourceCount(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> timelineTrends(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.timelineTrends(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> mostCommentedUser(TweeterActionVo tweeterActionVo)
	{
		return tweetInnDao.mostCommentedUser(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> mostFbLikedUser(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.mostFbLikedUser(tweeterActionVo);
	}
	@Override
	public CommonArticleVo getAllDataForCommon(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getAllDataForCommon(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getCommonFriendFacebook(TweeterActionVo tweeterActionVo)
	{
		return tweetInnDao.getCommonFriendFacebook(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getCommonGroupFacebook(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getCommonGroupFacebook(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getCommonLikesFacebook(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getCommonLikesFacebook(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getCommonCheckinsFacebook(TweeterActionVo tweeterActionVo)
	{
		return tweetInnDao.getCommonCheckinsFacebook(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getCommonEventFacebook(TweeterActionVo tweeterActionVo)
	{
		return tweetInnDao.getCommonEventFacebook(tweeterActionVo);
	}

	@Override
	public CommonFbVo getCommonSocialData(TweeterActionVo tweeterActionVo, String type)
	{
		return tweetInnDao.getCommonSocialData(tweeterActionVo, type);
	}

	@Override
	public ArrayList<TwitterVo> getThemes(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getThemes(tweeterActionVo);
	}
	@Override
	public ArrayList<Object> fb_scrapy_basic_info(TweeterActionVo fbInputVo) 
	{
		return tweetInnDao.fb_scrapy_basic_info(fbInputVo);
	}
	@Override
	public ArrayList<Fb_OutputVo> fb_scrapy_user_media(TweeterActionVo fbInputVo)
	{
		return tweetInnDao.fb_scrapy_user_media(fbInputVo);
	}
	@Override
	public ArrayList<Fb_groupVo> fb_scrapy_user_gp(TweeterActionVo fbInputVo) 
	{
		return tweetInnDao.fb_scrapy_user_gp(fbInputVo);
	}
	@Override
	public ArrayList<Fb_groupVo> fb_scrapy_user_check_ins(TweeterActionVo fbInputVo)
	{
		return tweetInnDao.fb_scrapy_user_check_ins(fbInputVo);
	}
	@Override
	public ArrayList<Fb_groupVo> fb_scrapy_user_friends(TweeterActionVo fbInputVo) 
	{
		return tweetInnDao.fb_scrapy_user_friends(fbInputVo);
	}
	@Override
	public ArrayList<Fb_groupVo> fb_scrapy_user_likes(TweeterActionVo fbInputVo) 
	{
		return tweetInnDao.fb_scrapy_user_likes(fbInputVo);
	}
	
	@Override
	public ArrayList<String> fbUserODS(TweeterActionVo fbInputVo)
	{
		return tweetInnDao.fbUserODS(fbInputVo);
	}
	@Override
	public ArrayList<Fb_groupVo> fbUserFRS(TweeterActionVo fbInputVo)
	{
		return tweetInnDao.fbUserFRS(fbInputVo);
	}
	
	@Override
	public ArrayList<TwitterVo> getLanguage(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getLanguage(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getCountry(TweeterActionVo tweeterActionVo)
	{
		return tweetInnDao.getCountry(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getCity(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getCity(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getThemeWordCloud(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getThemeWordCloud(tweeterActionVo);	
	}

	@Override
	public ArrayList<TwitterVo> getClassification(TweeterActionVo tweeterActionVo)
	{
		return tweetInnDao.getClassification(tweeterActionVo);
	}

	@Override
	public ArrayList<TwitterVo> getAllAttriubuteCount(TweeterActionVo tweeterActionVo){
		return tweetInnDao.getAllAttriubuteCount(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getAllAttriubuteCountNER(TweeterActionVo tweeterActionVo) {
		return tweetInnDao.getAllAttriubuteCountNER(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> dashActiveEntity(TweeterActionVo tweeterActionVo) {
		return tweetInnDao.dashActiveEntity(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> mostInfluenceTweetUser(TweeterActionVo tweeterActionVo) {
		return tweetInnDao.mostInfluenceTweetUsers(tweeterActionVo);
	}
	@Override
	public ArrayList<KeyMapVo> getAllTredingDateWithTheme360(TweeterActionVo tweeterActionVo) {
		return tweetInnDao.getAllTredingDateWithTheme360(tweeterActionVo);
	}
	@Override
	public ArrayList<LinkedTreeMap> getAllInfluencerUser360(TweeterActionVo tweeterActionVo) {
		return tweetInnDao.getAllInfluencerUser360(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getAllTwitterUserCreatiedBetweenDates(TweeterActionVo tweeterActionVo)
	{
		return tweetInnDao.getAllTwitterUserCreatiedBetweenDates(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo>	getEmailId(TweeterActionVo tweeterActionVo){
		return tweetInnDao.getEmailId(tweeterActionVo);

	}
	@Override
	public ArrayList<TwitterVo> getPhoneNo(TweeterActionVo tweeterActionVo) {
		return tweetInnDao.getPhoneNo(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> topDashActiveEntity(TweeterActionVo tweeterActionVo) {
		return tweetInnDao.topDashActiveEntity(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getEmotions(TweeterActionVo tweeterActionVo) {
		return tweetInnDao.getEmotions(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> docCountWithSentiment(TweeterActionVo tweeterActionVo) {
		return tweetInnDao.docCountWithSentiment(tweeterActionVo);
	}
	@Override
	public ArrayList<LinkedTreeMap> getFieldTypeData(TweeterActionVo tweeterActionVo) {
		return tweetInnDao.getFieldTypeData(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getUserNodeDetail(TweeterActionVo tweeterActionVo)
	{
		return 	tweetInnDao.getUserNodeDetail(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getAllDataForLinkAnalysis(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getAllDataForLinkAnalysis(tweeterActionVo);
	}
	
	
	@Override
	public ArrayList<TwitterVo> getEvent(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getEvent(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getTaxonomy(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getTaxonomy(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getAuthorCountry(TweeterActionVo tweeterActionVo)
	{
		return tweetInnDao.getAuthorCountry(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getAuthorCity(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getAuthorCity(tweeterActionVo);
	}
	
	@Override
	public ArrayList<Fb_groupVo> fbTopMostUserReacted(TweeterActionVo tweeterActionVo) {
		return tweetInnDao.fbTopMostUserReacted(tweeterActionVo);
	}
	@Override
	public ArrayList<Fb_groupVo> fbTopMostReactionChart(TweeterActionVo tweeterActionVo) {
		return tweetInnDao.fbTopMostReactionChart(tweeterActionVo);
	}
	@Override
	public ArrayList<Fb_groupVo> fbTopMosCityOfFriend(TweeterActionVo tweeterActionVo) {
		return tweetInnDao.fbTopMosCityOfFriend(tweeterActionVo);
	}
	@Override
	public ArrayList<Fb_groupVo> fbTopMostUserCommented(TweeterActionVo tweeterActionVo) {
		return tweetInnDao.fbTopMostUserCommented(tweeterActionVo);
	}
	@Override
	public ArrayList<Fb_groupVo> fbTopMostUserStrongConnection(TweeterActionVo tweeterActionVo) {
		return tweetInnDao.fbTopMostUserStrongConnection(tweeterActionVo);
	}
	
	@Override
	public ArrayList<TwitterVo> getHashtagViewBasicInformation(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getHashtagViewBasicInformation(tweeterActionVo);
	}
	
	@Override
	public ArrayList<TwitterVo> getMaxAndMinDateOfFacebookUserProfilePost(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getMaxAndMinDateOfFacebookUserProfilePost(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getMaxAndMinDateOfLinkedinProfilePost(TweeterActionVo tweeterActionVo)
	{
		return tweetInnDao.getMaxAndMinDateOfLinkedinProfilePost(tweeterActionVo);
	}
	
	@Override
	public ArrayList<EntityVo> getFacebookUserProfileFromNewAnalysis(EntityVo entityVo) 
	{
		return tweetInnDao.getFacebookUserProfileFromNewAnalysis(entityVo);
	}
	
	
	@Override
	public void updateClassification(TweeterActionVo tweeterActionVo) 
	{
		 tweetInnDao.updateClassification(tweeterActionVo);		
	}
	@Override
	public void updateSentiment(TweeterActionVo tweeterActionVo)
	{
		tweetInnDao.updateSentiment(tweeterActionVo);		
	}
	
	@Override
	public ArrayList<Fb_groupVo> getFBPeopleProfileWithSameGroup(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getFBPeopleProfileWithSameGroup(tweeterActionVo);
	}
	@Override
	public ArrayList<Fb_groupVo> getFBPeopleProfileWithSameLikes(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getFBPeopleProfileWithSameLikes(tweeterActionVo);
	}
	@Override
	public ArrayList<Fb_groupVo> getFBPeopleProfileWithSameCheckIn(TweeterActionVo tweeterActionVo)
	{
		return tweetInnDao.getFBPeopleProfileWithSameCheckIn(tweeterActionVo);
	}
	@Override
	public ArrayList<Fb_groupVo> getFBPeopleProfileWithSameLocation(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getFBPeopleProfileWithSameLocation(tweeterActionVo);
	}
	@Override
	public ArrayList<Fb_OutputVo> getFBPageBasicInfo(TweeterActionVo fbInputVo) 
	{
		return tweetInnDao.getFBPageBasicInfo(fbInputVo);
	}
	
	//FOR DEMO WORK============================================//FOR DEMO WORK
	@Override
	public ArrayList<TwitterVo> strongFollowersOfAPC(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.strongFollowersOfAPC(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> strongFollowersOfAPCImage(TweeterActionVo tweeterActionVo)
	{
		return tweetInnDao.strongFollowersOfAPCImage(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> suspectedBOTsOfAPC(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.suspectedBOTsOfAPC(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> strongFollowersOfPDP(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.strongFollowersOfPDP(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> suspectedBOTsOfPDP(TweeterActionVo tweeterActionVo)
	{
		return tweetInnDao.suspectedBOTsOfPDP(tweeterActionVo);
	}
	
	//==========================FB PAGE RPT=======================================//
	@Override
	public ArrayList<TwitterVo> fbPageBasicInfoRpt(TweeterActionVo fbInputVo)
	{
		return tweetInnDao.fbPageBasicInfoRpt(fbInputVo);
	}
	@Override
	public ArrayList<TwitterVo> fbPageBasicInformationsDetailsRpt(TweeterActionVo fbInputVo) 
	{
		return tweetInnDao.fbPageBasicInformationsDetailsRpt(fbInputVo);
	}
	@Override
	public ArrayList<TwitterVo> fbPageMediaImageRpt(TweeterActionVo fbInputVo)
	{
		return tweetInnDao.fbPageMediaImageRpt(fbInputVo);
	}
	@Override
	public ArrayList<TwitterVo> fbPageMediaVideoRpt(TweeterActionVo fbInputVo)
	{
		return tweetInnDao.fbPageMediaVideoRpt(fbInputVo);
	}
	@Override
	public ArrayList<Fb_groupVo> fbPageTopMostUserStrongConnection(TweeterActionVo fbInputVo)
	{
		return tweetInnDao.fbPageTopMostUserStrongConnection(fbInputVo);
	}
	@Override
	public ArrayList<Fb_groupVo> fbPageAllPeoplesLikesThePage(TweeterActionVo fbInputVo) 
	{
		return tweetInnDao.fbPageAllPeoplesLikesThePage(fbInputVo);
	}
	@Override
	public ArrayList<Fb_groupVo> fbPageTopFan(TweeterActionVo fbInputVo) 
	{
		return tweetInnDao.fbPageTopFan(fbInputVo);
	}
	
	//==========================FB GROUP RPT=======================================//
	@Override
	public ArrayList<TwitterVo> fbGroupBasicInfoRpt(TweeterActionVo fbInputVo) 
	{
		return tweetInnDao.fbGroupBasicInfoRpt(fbInputVo);
	}
	@Override
	public ArrayList<TwitterVo> fbGroupMediaImageRpt(TweeterActionVo fbInputVo) 
	{
		return tweetInnDao.fbGroupMediaImageRpt(fbInputVo);
	}
	@Override
	public ArrayList<TwitterVo> fbGroupMediaVideoRpt(TweeterActionVo fbInputVo) 
	{
		return tweetInnDao.fbGroupMediaVideoRpt(fbInputVo);
	}
	@Override
	public ArrayList<Fb_groupVo> fbGroupTopMostUserStrongConnection(TweeterActionVo fbInputVo) 
	{
		return tweetInnDao.fbGroupTopMostUserStrongConnection(fbInputVo);
	}
	@Override
	public ArrayList<Fb_groupVo> fbGroupAllMembersRpt(TweeterActionVo fbInputVo)
	{
		return tweetInnDao.fbGroupAllMembersRpt(fbInputVo);
	}
	@Override
	public ArrayList<Fb_groupVo> fbGroupNewMembersRpt(TweeterActionVo fbInputVo)
	{
		return tweetInnDao.fbGroupNewMembersRpt(fbInputVo);
	}
	@Override
	public ArrayList<Fb_groupVo> fbGroupEventsRpt(TweeterActionVo fbInputVo)
	{
		return tweetInnDao.fbGroupEventsRpt(fbInputVo);
	}
	@Override
	public ArrayList<Fb_groupVo> fbGroupAllAdminRpt(TweeterActionVo fbInputVo) 
	{
		return tweetInnDao.fbGroupAllAdminRpt(fbInputVo);
	}
	
	@Override
	public ArrayList<InnsightTrends> getCitiesForTrends()
	{
		return tweetInnDao.getCitiesForTrends();
	}
	
	@Override
	public ArrayList<InnsightTrends> getTrendsByLocation(InnsightTrends innsightTrends) 
	{
		return tweetInnDao.getTrendsByLocation(innsightTrends); 
	}
	
	@Override
	public ArrayList<TwitterVo> getTweetsUserLocation(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getTweetsUserLocation(tweeterActionVo); 
	}
	@Override
	public TwitterVo updateTweetRealTimeByTweetId(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.updateTweetRealTimeByTweetId(tweeterActionVo); 
	}

	@Override
	public LinkedHashMap<String, ArrayList<TwitterTrendsVo>> timelineChipsTrends(TweeterActionVo tweeterActionVo)
	{
		return tweetInnDao.timelineChipsTrends(tweeterActionVo);
	}
	@Override
	public Long getTweetReach(String tweetId) 
	{
		return tweetInnDao.getTweetReach(tweetId);
	}
	@Override
	public ArrayList<ArticleDataExportVo> exportFBProfilePostJsonDataReport(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.exportFBProfilePostJsonDataReport(tweeterActionVo);
	}
	@Override
	public ArrayList<UserProfileConnectionExportVo> exportFBProfileConnectionJsonDataReport(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.exportFBProfileConnectionJsonDataReport(tweeterActionVo);
	}
	@Override
	public ArrayList<UserProfileExportVo> exportFBBasicInfoJsonDataReport(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.exportFBBasicInfoJsonDataReport(tweeterActionVo);
	}
	
	@Override
	public String exportFbTotalDocumentCount(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.exportFbTotalDocumentCount(tweeterActionVo);
	}
	@Override
	public ArrayList<HashMap<String, String>> exportFbOverallSentimentReportData(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.exportFbOverallSentimentReportData(tweeterActionVo);
	}
	@Override
	public ArrayList<HashMap<String, String>> exportFbClassificationReportData(TweeterActionVo tweeterActionVo)
	{
		return tweetInnDao.exportFbClassificationReportData(tweeterActionVo);
	}
	@Override
	public ArrayList<HashMap<String, String>> exportFbPersonReportData(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.exportFbPersonReportData(tweeterActionVo);
	}
	@Override
	public ArrayList<HashMap<String, String>> exportFbPlaceReportData(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.exportFbPlaceReportData(tweeterActionVo);
	}
	@Override
	public ArrayList<HashMap<String, String>> exportFbOrgReportData(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.exportFbOrgReportData(tweeterActionVo);
	}
	@Override
	public ArrayList<HashMap<String, String>> exportFbThemesReportData(TweeterActionVo tweeterActionVo)
	{
		return tweetInnDao.exportFbThemesReportData(tweeterActionVo);
	}
	@Override
	public ArrayList<String> exportFbPhotoReportData(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.exportFbPhotoReportData(tweeterActionVo);
	}
	@Override
	public ArrayList<String> exportFbVideoReportData(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.exportFbVideoReportData(tweeterActionVo);
	}
	@Override
	public ArrayList<HashMap<String, String>> exportFbCheckinsReportData(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.exportFbCheckinsReportData(tweeterActionVo);
	}
	@Override
	public ArrayList<HashMap<String, String>> exportFbLikesReportData(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.exportFbLikesReportData(tweeterActionVo);
	}
	@Override
	public ArrayList<SaveFilterVo> getAllAnalysisName(SaveFilterVo saveFilterVo) 
	{
		return tweetInnDao.getAllAnalysisName(saveFilterVo);
	}
	@Override
	public ArrayList<SaveFilterVo> getAllRequiredSnapshotName(SaveFilterVo saveFilterVo) 
	{
		return tweetInnDao.getAllRequiredSnapshotName(saveFilterVo);
	}
	@Override
	public ArrayList<TwitterVo> getAllUniqueTWBoatsUser(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getAllUniqueTWBoatsUser(tweeterActionVo);
	}
	@Override
	public ArrayList<TwitterVo> getFBUserPostComment(TweeterActionVo tweeterActionVo) 
	{
		return tweetInnDao.getFBUserPostComment(tweeterActionVo);
	}
}