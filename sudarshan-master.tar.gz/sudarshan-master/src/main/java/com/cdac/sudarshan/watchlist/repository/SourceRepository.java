package com.cdac.sudarshan.watchlist.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cdac.sudarshan.watchlist.model.Source;
@Repository
public interface SourceRepository extends JpaRepository<Source, Integer> {

}
