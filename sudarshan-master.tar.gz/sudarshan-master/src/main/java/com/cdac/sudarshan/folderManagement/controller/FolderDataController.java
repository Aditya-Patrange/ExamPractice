package com.cdac.sudarshan.folderManagement.controller;

import com.cdac.sudarshan.folderManagement.dto.FolderDataRequestDto;
import com.cdac.sudarshan.folderManagement.dto.RequestMediaDto;
import com.cdac.sudarshan.folderManagement.service.FolderDataServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/folderData")
@CrossOrigin
public class FolderDataController {

    @Autowired
    private FolderDataServiceImpl folderDataService;

    @PostMapping("/saveArticleData")
    public ResponseEntity<?> saveArticleDataToFolder(@RequestBody List<FolderDataRequestDto> dataRequestDto){
        return ResponseEntity.ok(folderDataService.saveArticleData(dataRequestDto));
    }

    @PostMapping("/saveProfileData")
    public ResponseEntity<?> saveProfileDataToFolder(@RequestBody List<FolderDataRequestDto> dataRequestDto){
        return ResponseEntity.ok(folderDataService.saveProfileData(dataRequestDto));
    }

    @PostMapping(value = "/getFolderData",produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getFolderData(@RequestBody FolderDataRequestDto dataRequestDto){
        return ResponseEntity.ok(folderDataService.getFolderData(dataRequestDto));
    }

    @PatchMapping(value = "/removeFolderData",produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> removeFolderData(@RequestBody Map<String,Object> folderData){
        return ResponseEntity.ok(folderDataService.removeFolderData(folderData));
    }

    @PostMapping(value = "/saveMediaData")
    public ResponseEntity<?> deleteFolderData(@RequestBody List<RequestMediaDto> folderData){
        return ResponseEntity.ok(folderDataService.saveMediaData(folderData));
    }

    @PostMapping(value = "/getMediaData")
    public ResponseEntity<?> getMediaData(@RequestBody @Valid RequestMediaDto mediaDto){
        return ResponseEntity.ok(folderDataService.getMedia(mediaDto));
    }

    @PostMapping(value = "/getFolderDataOfTheme",produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getFolderDataOfTheme(@RequestBody FolderDataRequestDto dataRequestDto){
        return ResponseEntity.ok(folderDataService.getFolderThemeData(dataRequestDto));
    }

    @PostMapping(value = "/getFilterDataData",produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getFilterData(@RequestBody FolderDataRequestDto dataRequestDto){
        return ResponseEntity.ok(folderDataService.getFilterData(dataRequestDto));
    }



}
