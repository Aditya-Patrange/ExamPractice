package com.cdac.sudarshan.discover.model;

public class UserProfileExportVo 
{
	private static final long serialVersionUID = 1L;
	private String fbUserId;
    private String fbUserName;
    private String fbPageLink;
    private String information;
    private String informationName;
    private String informationType;    
    
	public String getFbUserId() {
		return fbUserId;
	}
	public void setFbUserId(String fbUserId) {
		this.fbUserId = fbUserId;
	}
	public String getFbUserName() {
		return fbUserName;
	}
	public void setFbUserName(String fbUserName) {
		this.fbUserName = fbUserName;
	}
	public String getFbPageLink() {
		return fbPageLink;
	}
	public void setFbPageLink(String fbPageLink) {
		this.fbPageLink = fbPageLink;
	}
	public String getInformation() {
		return information;
	}
	public void setInformation(String information) {
		this.information = information;
	}
	public String getInformationName() {
		return informationName;
	}
	public void setInformationName(String informationName) {
		this.informationName = informationName;
	}
	public String getInformationType() {
		return informationType;
	}
	public void setInformationType(String informationType) {
		this.informationType = informationType;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "UserProfileExportVo [fbUserId=" + fbUserId + ", fbUserName=" + fbUserName + ", fbPageLink=" + fbPageLink
				+ ", information=" + information + ", informationName=" + informationName + ", informationType="
				+ informationType + "]";
	}
}
