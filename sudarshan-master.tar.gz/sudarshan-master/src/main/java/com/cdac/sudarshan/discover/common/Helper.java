package com.cdac.sudarshan.discover.common;


import java.io.File;
import java.net.URL;
import java.security.MessageDigest;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.time.DateUtils;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;


@Service
public class Helper {


//    @Value("${clientId}")
//    public String clientId;


    public static String convertArrayListOfIntToQuotedString(ArrayList<Integer> ids)
    {
        String str="";
        if(ids.size()>0)
        {
            for (int val : ids) {
                str+=val+",";
            }
            if(str.trim().length()>0)
            {
                str=str.substring(0, str.length() - 1);
            }
        }
        return null;
    }

    public static String convertArrayListOfStringToQuotedString(ArrayList<String> ids)
    {
        String str="";
        if(ids.size()>0)
        {
            for (String val : ids) {
                str+=val+",";
            }
            if(str.trim().length()>0)
            {
                str=str.substring(0, str.length() - 1);
            }
        }
        return null;
    }

    public static String convertStringToSingleQuotedString(String ids)
    {
        String str="";
        String strArray[]=ids.split(",");

        if(strArray.length>0)
        {
            for (String val : strArray) {
                str+= "'"+val+"',";
            }
            if(str.trim().length()>0)
            {
                str=str.substring(0, str.length() - 1);
            }
        }
        return str;
    }

    public static String convertStringToSingleQuotedArray(ArrayList<String> strArray)
    {
        String str="";
        if(strArray.size()>0)
        {
            for (String val : strArray) {
                str+= "'"+val+"',";
            }
            if(str.trim().length()>0)
            {
                str=str.substring(0, str.length() - 1);
            }
        }
        return str;
    }


    public static String convertStringToESORFormat(String ids)
    {
        String str="";
        String strArray[]=ids.split(",");

        if(strArray.length>0)
        {
            for (String val : strArray) {
                str+= " "+val+" OR";
            }
            if(str.trim().length()>0)
            {
                str=str.substring(0, str.length() - 2);
            }
        }
        return str;
    }

    public static boolean emptyNullCheckString(String str) {
        if(str!=null && str.trim().length()>0) {
            return true;
        } else {
            return false;
        }
    }

    public static Object keyContainsHashMap(HashMap<String, Object> input, String key) {
        return input.containsKey(key)==false?null:input.get(key);
    }

    public static String calculatePagination(int pageNumber,int limit) {
        int offset= pageNumber*limit;
        return " limit "+offset+","+limit;
    }


    public static String calculatePaginationESData(int pageNumber,int limit)
    {
        int offset= (pageNumber)*limit;
        return offset+","+limit;
    }

    public static String convertStringToMd5(String txt) {
        if (txt != null) {
            StringBuffer sb = new StringBuffer();
            try {
                MessageDigest md = MessageDigest.getInstance("MD5");
                md.update(txt.getBytes());
                byte byteData[] = md.digest();
                // convert the byte to hex format method 1
                for (int i = 0; i < byteData.length; i++) {
                    sb.append(Integer.toString((byteData[i] & 0xff) + 0x100, 16).substring(1));
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return sb.toString();
        } else {
            return "";
        }
    }


    public static String longToDateStr(long l)
    {
        Date date = new Date(l);
        SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy hh:mm a");
        String dateString = sdf.format(date);
        return dateString;
    }

    public static String longToDateStrYYYY_MM_DD(long l)
    {
        Date date = new Date(l);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        String dateString = sdf.format(date);
        return dateString;
    }


    public static long stringToLong(String l)
    {
        try {
            Date date1 = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss").parse(l);
            return date1.getTime();
        } catch (ParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return 0l;
        }
    }


    public static String convertStringToDate(String str)
    {
        String dateString=str;
        try {
            Date date1 = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").parse(str);
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
            str = sdf.format(date1);
            //return date1.getTime();
        } catch (ParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            //return 0l;
        }
        return dateString;
    }


    public static String getCurrentDate()
    {
        DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
        Date dateobj = new Date();
        return df.format(dateobj);
    }

    public static String getYoutubeBeforeDateYYYYMMDD()
    {
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        Date dateobj = new Date();
        return df.format(dateobj);
    }

    public static String getYouTubeAfterDateYYYYMMDD()
    {
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        Date dateAfter = DateUtils.addDays(new Date(),-90);
        return df.format(dateAfter);
    }

    public static String GetYotubeToCrawleDate()
    {
        Date dateBefore30Days = DateUtils.addDays(new Date(),-365);
        return Long.toString(dateBefore30Days.getTime()/1000);
    }


    public static HashMap<String, Object> getErrorMap(Exception e)
    {
        HashMap<String, Object> mp=new HashMap<String, Object>();
        mp.put("type", "error");
        mp.put("msg", "error in code");
        mp.put("error", e.getMessage());
        return  mp;
    }

    public static HashMap<String, Object> getErrorMapStatus(Exception e)
    {
        HashMap<String, Object> mp=new HashMap<String, Object>();
        mp.put("status", "error");
        mp.put("msg", "error in code");
        mp.put("error", e.getMessage());
        return  mp;
    }


    public static void parseUrl()
    {
        try
        {
            URL url3=new URL("https://www.reddit.com/user/Chodi");
            // retrive the path of URL
            String path=url3.getPath();

            String lastChar = path.substring(path.length() - 1);
            if(lastChar.equals("/"))
            {
                path= path.substring(0, path.length() - 1);
            }

            String[]  pathArr=path.split("/");
            if(pathArr.length>0)
            {
            }
            else
            {
            }

            for (int i = 0; i < pathArr.length; i++) {
                // System.out.println(pathArr[i]);
            }

            //System.out.println(url3.getPath().replace("/in/",""));
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static String getSqlCurrentDateTime()
    {
        java.util.Date dt = new java.util.Date();
        java.text.SimpleDateFormat sdf =
                new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return sdf.format(dt);
    }



    public static String getDateFrom()
    {
        String str=getCurrentDate();
        str=str+" 00:00:00";
        return str;
    }

    public static String getDateTo()
    {
        String str=getCurrentDate();
        str=str+" 23:59:59";
        return str;
    }

    public static String getBoolSearch(ArrayList<String> lstKeyword)
    {
        String searchQuery="";
        if(lstKeyword.size()>0)
        {
            for (String string : lstKeyword) {
                String[] ndArr=string.trim().split(" ");
                if(ndArr.length>1)
                {
                    String str=" (";
                    for (String string2 : ndArr) {
                        if(!string2.trim().isEmpty())
                        {
                            str+=" "+string2.trim()+" AND";
                        }
                    }
                    str=str.substring(0, str.length() - 3);
                    str+=" ) OR";
                    searchQuery+=str;
                }

                else
                {
                    searchQuery+=" "+string.trim()+" OR";
                }
            }
        }
        searchQuery=searchQuery.substring(0, searchQuery.length() - 2);
        return searchQuery;
    }



    public static String getSocialMediaFilter(ArrayList<String> lstSource)
    {
        HashMap<String,String> mp=new HashMap<String, String>();
        mp.put("twitter", "tw");
        mp.put("facebook", "fb");
        mp.put("youtube", "yt");
        mp.put("instagram", "insta");
        mp.put("dailymotion", "dm");
        mp.put("tumblr", "tm");
        mp.put("reddit", "reddit");
        mp.put("wordpress", "wp");
        mp.put("linkedin", "linkedin");
        mp.put("web", "web");
        mp.put("thinktanks", "ThinkTank");
        mp.put("flickr", "flickr");

        String str="";
        for (String string : lstSource) {
            str+=(mp.containsKey(string)?mp.get(string).toString():string)+",";
        }
        if(str.length()>2)
        {
            str=str.substring(0, str.length() - 1);
        }
        return str;
    }


//
//    public static WebDriver getWebDriver()
//    {
//        WebDriver driver=null;
//        try
//        {
//            File firefoxPath = null;
//            FirefoxOptions firefoxOptions=new  FirefoxOptions();
//            if (OSUtil.isWindows()) {
//                System.setProperty("webdriver.gecko.driver", "C:\\Users\\Ashish\\Downloads\\geckodriver.exe");
//                firefoxPath = new File("D:\\Mozila Firefox\\firefox.exe");
//                firefoxOptions.setHeadless(false);
//            } else {
//                System.setProperty("webdriver.gecko.driver", "/opt/geckodriver/geckodriver");
//                firefoxPath = new File(System.getProperty("lmportal.deploy.firefox.path", "/opt/firefox/firefox"));
//                firefoxOptions.setHeadless(true);
//            }
//            FirefoxBinary firefoxBinary = new FirefoxBinary(firefoxPath);
//            firefoxOptions.setBinary(firefoxBinary);
//            driver = new FirefoxDriver(firefoxOptions);
//            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//            Thread.sleep(5000);
//        }
//        catch (Exception e) {
//            e.printStackTrace();
//        }
//        return driver;
//    }


}
