package com.cdac.sudarshan.discover.model;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Set;

public class CommonArticleVo 
{	
	private Set<String> image;
	private Set<String> video;
	private Set<String> articleCountry;
	private Set<String> source;
	private Set<String> hashTag;
	private Set<String> mention;
	private Set<String> person;
	private Set<String> org;
	private Set<String> location;
	private Set<String> date;
	private Set<String> theme;
	private Set<String> classification;
	private Set<String> mobile;
	private Set<String> email;
	private Set<String> comment;
	private Set<String> language;
	private Set<String> link;
	private Set<String> city;
	private Set<String> author;
	private Set<String> emotion;
	private Set<String> country;
	private Set<String> countryCode;
	
	private LinkedHashMap<String,String> latlongLocationMap;
	private LinkedHashMap<String,String> userIdNameMap;
	
	private LinkedHashMap<String, HashSet<String>> images;
	private LinkedHashMap<String, HashSet<String>> videos;
	private LinkedHashMap<String, HashSet<String>> articleCountries;
	private LinkedHashMap<String, HashSet<String>> sources;
	private LinkedHashMap<String, HashSet<String>> hashTags;
	private LinkedHashMap<String, HashSet<String>> mentions;
	private LinkedHashMap<String, HashSet<String>> persons;
	private LinkedHashMap<String, HashSet<String>> orgs;
	private LinkedHashMap<String, HashSet<String>> locations;
	private LinkedHashMap<String, HashSet<String>> dates;
	private LinkedHashMap<String, HashSet<String>> themes;
	private LinkedHashMap<String, HashSet<String>> classifications;
	private LinkedHashMap<String, HashSet<String>> mobiles;
	private LinkedHashMap<String, HashSet<String>> emails;
	private LinkedHashMap<String, HashSet<String>> languages;
	private LinkedHashMap<String, HashSet<String>> links;
	private LinkedHashMap<String, HashSet<String>> citys;
	private LinkedHashMap<String, HashSet<String>> comments;
	private LinkedHashMap<String, HashSet<String>> authors;
	private LinkedHashMap<String, HashSet<String>> emotions;
	private LinkedHashMap<String, HashSet<String>> countries;
	private LinkedHashMap<String, HashSet<String>> countryCodes;
	
	public Set<String> getImage() {
		return image;
	}
	public void setImage(Set<String> image) {
		this.image = image;
	}
	public Set<String> getVideo() {
		return video;
	}
	public void setVideo(Set<String> video) {
		this.video = video;
	}
	public Set<String> getArticleCountry() {
		return articleCountry;
	}
	public void setArticleCountry(Set<String> articleCountry) {
		this.articleCountry = articleCountry;
	}
	public Set<String> getSource() {
		return source;
	}
	public void setSource(Set<String> source) {
		this.source = source;
	}
	public Set<String> getHashTag() {
		return hashTag;
	}
	public void setHashTag(Set<String> hashTag) {
		this.hashTag = hashTag;
	}
	public Set<String> getMention() {
		return mention;
	}
	public void setMention(Set<String> mention) {
		this.mention = mention;
	}
	public Set<String> getPerson() {
		return person;
	}
	public void setPerson(Set<String> person) {
		this.person = person;
	}
	public Set<String> getOrg() {
		return org;
	}
	public void setOrg(Set<String> org) {
		this.org = org;
	}
	public Set<String> getLocation() {
		return location;
	}
	public void setLocation(Set<String> location) {
		this.location = location;
	}
	public Set<String> getDate() {
		return date;
	}
	public void setDate(Set<String> date) {
		this.date = date;
	}
	public Set<String> getTheme() {
		return theme;
	}
	public void setTheme(Set<String> theme) {
		this.theme = theme;
	}
	public Set<String> getClassification() {
		return classification;
	}
	public void setClassification(Set<String> classification) {
		this.classification = classification;
	}
	public Set<String> getMobile() {
		return mobile;
	}
	public void setMobile(Set<String> mobile) {
		this.mobile = mobile;
	}
	public Set<String> getEmail() {
		return email;
	}
	public void setEmail(Set<String> email) {
		this.email = email;
	}
	public Set<String> getComment() {
		return comment;
	}
	public void setComment(Set<String> comment) {
		this.comment = comment;
	}
	public Set<String> getAuthor() {
		return author;
	}
	public void setAuthor(Set<String> author) {
		this.author = author;
	}
	public Set<String> getEmotion() {
		return emotion;
	}
	public void setEmotion(Set<String> emotion) {
		this.emotion = emotion;
	}
	public Set<String> getLanguage() {
		return language;
	}
	public void setLanguage(Set<String> language) {
		this.language = language;
	}
	public Set<String> getLink() {
		return link;
	}
	public void setLink(Set<String> link) {
		this.link = link;
	}
	public Set<String> getCity() {
		return city;
	}
	public void setCity(Set<String> city) {
		this.city = city;
	}
	public Set<String> getCountry() {
		return country;
	}
	public void setCountry(Set<String> country) {
		this.country = country;
	}
	public Set<String> getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(Set<String> countryCode) {
		this.countryCode = countryCode;
	}
	public LinkedHashMap<String, String> getLatlongLocationMap() {
		return latlongLocationMap;
	}
	public void setLatlongLocationMap(LinkedHashMap<String, String> latlongLocationMap) {
		this.latlongLocationMap = latlongLocationMap;
	}
	public LinkedHashMap<String, String> getUserIdNameMap() {
		return userIdNameMap;
	}
	public void setUserIdNameMap(LinkedHashMap<String, String> userIdNameMap) {
		this.userIdNameMap = userIdNameMap;
	}
	public LinkedHashMap<String, HashSet<String>> getImages() {
		return images;
	}
	public void setImages(LinkedHashMap<String, HashSet<String>> images) {
		this.images = images;
	}
	public LinkedHashMap<String, HashSet<String>> getVideos() {
		return videos;
	}
	public void setVideos(LinkedHashMap<String, HashSet<String>> videos) {
		this.videos = videos;
	}
	public LinkedHashMap<String, HashSet<String>> getArticleCountries() {
		return articleCountries;
	}
	public void setArticleCountries(LinkedHashMap<String, HashSet<String>> articleCountries) {
		this.articleCountries = articleCountries;
	}
	public LinkedHashMap<String, HashSet<String>> getSources() {
		return sources;
	}
	public void setSources(LinkedHashMap<String, HashSet<String>> sources) {
		this.sources = sources;
	}
	public LinkedHashMap<String, HashSet<String>> getHashTags() {
		return hashTags;
	}
	public void setHashTags(LinkedHashMap<String, HashSet<String>> hashTags) {
		this.hashTags = hashTags;
	}
	public LinkedHashMap<String, HashSet<String>> getMentions() {
		return mentions;
	}
	public void setMentions(LinkedHashMap<String, HashSet<String>> mentions) {
		this.mentions = mentions;
	}
	public LinkedHashMap<String, HashSet<String>> getPersons() {
		return persons;
	}
	public void setPersons(LinkedHashMap<String, HashSet<String>> persons) {
		this.persons = persons;
	}
	public LinkedHashMap<String, HashSet<String>> getOrgs() {
		return orgs;
	}
	public void setOrgs(LinkedHashMap<String, HashSet<String>> orgs) {
		this.orgs = orgs;
	}
	public LinkedHashMap<String, HashSet<String>> getLocations() {
		return locations;
	}
	public void setLocations(LinkedHashMap<String, HashSet<String>> locations) {
		this.locations = locations;
	}
	public LinkedHashMap<String, HashSet<String>> getDates() {
		return dates;
	}
	public void setDates(LinkedHashMap<String, HashSet<String>> dates) {
		this.dates = dates;
	}
	public LinkedHashMap<String, HashSet<String>> getThemes() {
		return themes;
	}
	public void setThemes(LinkedHashMap<String, HashSet<String>> themes) {
		this.themes = themes;
	}
	public LinkedHashMap<String, HashSet<String>> getClassifications() {
		return classifications;
	}
	public void setClassifications(LinkedHashMap<String, HashSet<String>> classifications) {
		this.classifications = classifications;
	}
	public LinkedHashMap<String, HashSet<String>> getMobiles() {
		return mobiles;
	}
	public void setMobiles(LinkedHashMap<String, HashSet<String>> mobiles) {
		this.mobiles = mobiles;
	}
	public LinkedHashMap<String, HashSet<String>> getEmails() {
		return emails;
	}
	public void setEmails(LinkedHashMap<String, HashSet<String>> emails) {
		this.emails = emails;
	}
	public LinkedHashMap<String, HashSet<String>> getComments() {
		return comments;
	}
	public void setComments(LinkedHashMap<String, HashSet<String>> comments) {
		this.comments = comments;
	}
	public LinkedHashMap<String, HashSet<String>> getAuthors() {
		return authors;
	}
	public void setAuthors(LinkedHashMap<String, HashSet<String>> authors) {
		this.authors = authors;
	}
	public LinkedHashMap<String, HashSet<String>> getEmotions() {
		return emotions;
	}
	public void setEmotions(LinkedHashMap<String, HashSet<String>> emotions) {
		this.emotions = emotions;
	}
	public LinkedHashMap<String, HashSet<String>> getCountries() {
		return countries;
	}
	public void setCountries(LinkedHashMap<String, HashSet<String>> countries) {
		this.countries = countries;
	}
	public LinkedHashMap<String, HashSet<String>> getCountryCodes() {
		return countryCodes;
	}
	public void setCountryCodes(LinkedHashMap<String, HashSet<String>> countryCodes) {
		this.countryCodes = countryCodes;
	}
	public LinkedHashMap<String, HashSet<String>> getLanguages() {
		return languages;
	}
	public void setLanguages(LinkedHashMap<String, HashSet<String>> languages) {
		this.languages = languages;
	}
	public LinkedHashMap<String, HashSet<String>> getLinks() {
		return links;
	}
	public void setLinks(LinkedHashMap<String, HashSet<String>> links) {
		this.links = links;
	}
	public LinkedHashMap<String, HashSet<String>> getCitys() {
		return citys;
	}
	public void setCitys(LinkedHashMap<String, HashSet<String>> citys) {
		this.citys = citys;
	}
	
} 
