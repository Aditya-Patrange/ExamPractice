package com.cdac.sudarshan.themeManagement.service;

import com.cdac.sudarshan.folderManagement.dto.ApiResponse;
import com.cdac.sudarshan.themeManagement.dto.KeywordRequestDto;
import com.fasterxml.jackson.core.JsonProcessingException;

public interface IKeywordService {
    ApiResponse<?> saveKeyword(KeywordRequestDto data) throws JsonProcessingException;

    ApiResponse<?> getKeyword(KeywordRequestDto data);
}
