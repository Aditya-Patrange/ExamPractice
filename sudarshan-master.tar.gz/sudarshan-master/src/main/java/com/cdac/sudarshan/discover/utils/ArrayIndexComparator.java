package com.cdac.sudarshan.discover.utils;

import java.util.Comparator;
import java.util.List;

public class ArrayIndexComparator implements Comparator<Integer>
{
	private final List<Double> array;

	public ArrayIndexComparator(List<Double> array)
	{
	    this.array = array;
	}

	public Integer[] createIndexArray()
	{
	    Integer[] indexes = new Integer[array.size()];
	    for (int i = 0; i < array.size(); i++)
	    {
		indexes[i] = i; // Autoboxing
	    }
	    return indexes;
	}

	@Override
	public int compare(Integer index1, Integer index2)
	{
		int cmp = Double.compare(array.indexOf(index2), array.indexOf(index1));
		return cmp == 0 ? Integer.compare(index1, index2) : cmp;
//	    return .compareTo(array.indexOf(index1);
	}
}

