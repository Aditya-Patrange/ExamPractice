package com.cdac.sudarshan.discover.model;

import java.io.Serializable;

public class Fb_User implements Serializable 
{
	private static final long serialVersionUID = 1L;
	private String fbPageLikeUserId;
	private String fbPageLikeUserName;
	private String fbPageLikeUserPicture;
	private String fbEmotion;

	public String getFbPageLikeUserId() {
		return fbPageLikeUserId;
	}

	public void setFbPageLikeUserId(String fbPageLikeUserId) {
		this.fbPageLikeUserId = fbPageLikeUserId;
	}

	public String getFbPageLikeUserName() {
		return fbPageLikeUserName;
	}

	public void setFbPageLikeUserName(String fbPageLikeUserName) {
		this.fbPageLikeUserName = fbPageLikeUserName;
	}

	public String getFbPageLikeUserPicture() {
		return fbPageLikeUserPicture;
	}

	public void setFbPageLikeUserPicture(String fbPageLikeUserPicture) {
		this.fbPageLikeUserPicture = fbPageLikeUserPicture;
	}

	public String getFbEmotion() {
		return fbEmotion;
	}

	public void setFbEmotion(String fbEmotion) {
		this.fbEmotion = fbEmotion;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "Fb_User [fbPageLikeUserId=" + fbPageLikeUserId + ", fbPageLikeUserName=" + fbPageLikeUserName
				+ ", fbPageLikeUserPicture=" + fbPageLikeUserPicture + ", fbEmotion=" + fbEmotion + "]";
	}
	
}
