package com.cdac.sudarshan.theme.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@Data
@NoArgsConstructor
public class ThemeCountDto {

    private String themeName;

    private int subThemeCount;

    private int keyWordCount;

}
