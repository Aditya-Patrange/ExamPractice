package com.cdac.sudarshan.discover.common;

import java.io.Serializable;

public class OrganizationAliasVo implements Serializable
{
	private static final long serialVersionUID = 1L;
	
	private int orgAliasId;
	private int organizationId;
	private String orgAlias;
	
	public int getOrgAliasId()
	{
		return orgAliasId;
	}
	public void setOrgAliasId(int orgAliasId) 
	{
		this.orgAliasId = orgAliasId;
	}
	
	public int getOrganizationId() 
	{
		return organizationId;
	}
	public void setOrganizationId(int organizationId) 
	{
		this.organizationId = organizationId;
	}
	
	public String getOrgAlias() 
	{
		return orgAlias;
	}
	public void setOrgAlias(String orgAlias) 
	{
		this.orgAlias = orgAlias;
	}
	
	public static long getSerialversionuid() 
	{
		return serialVersionUID;
	}
	@Override
	public String toString() 
	{
		return "OrganizationAliasVo [orgAliasId=" + orgAliasId + ", organizationId=" + organizationId + ", orgAlias="
				+ orgAlias + "]";
	}
}
