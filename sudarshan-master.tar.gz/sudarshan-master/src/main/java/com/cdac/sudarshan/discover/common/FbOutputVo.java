package com.cdac.sudarshan.discover.common;

import java.util.ArrayList;
import java.util.List;

import com.cdac.sudarshan.discover.model.Fb_Comment;
import com.cdac.sudarshan.discover.model.Fb_Media;
import com.cdac.sudarshan.discover.model.Fb_User;
import com.cdac.sudarshan.discover.model.WordFrequency;

//import com.innefu.innsight.modal.Fb_Comment;
//import com.innefu.innsight.modal.Fb_Media;
//import com.innefu.innsight.modal.Fb_User;
//
//import wordcloud.WordFrequency;

public class FbOutputVo 
{
	private String pageId;
	private String pageImage;
	private String pageName;
	private String pageUrl;
	private String globalBrandPageName;
	private String likes;
	private String fanCount;
	private String entity_id;
	private String post_id;
	private String post_user_id;
	private String post_user_name;
	private String post_source;
	private String post_share_count;
	private String post_caption,post_message;
	private String post_createdtime;
	private String post_link;
	private String page_id;
	private String post_like_count;
	private String post_comment_count;
	private String sentiment;
	private String post_type;
	private String post_updated_time;
	private String post_picture;
	private String latitude;
	private String longitude;
	private String country;
	private String state;
	private String city;
	private String zip;
	private String page_coverSource;
	private String page_about;
	private String page_link;
	private String page_phone;
	private String page_description;
	private String page_name_with_location_descriptor;
	private String page_website;
	private String page_category;
	private String page_likesCount;
	private String page_were_here_count;
	private String comment_id;
	private String comment_message;
	private String comment_createdtime;
	private String comment_likecount;
	private String priority;
	private String count;
	private String image_id;
	private String sub_att_img_title;
	private String sub_att_img_desc;
	private String sub_att_img_type;
	private String sub_att_img_url;
	private String sub_att_img_src;
	private String createdAt;
	private String advFilter;
	private String link_name;
	private String hashTag;
	private String tagId;
	private String user_name;
	private String user_id;
	private String nodeName1;
	private String nodeName2;
	private String nodeId1;
	private String nodeId2;
	private String nodeType;
	private String profileName;
	private String user_pic;
	private String img_md5;
	private String profileImageLocal;
    private String coverImageLocal;
    private String mediaImageLocal;
    private String absPathLocal;
	private ArrayList<String> postHashtag;
	private ArrayList<String> postMentionArray;
	private ArrayList<Fb_User> postMention;
	private ArrayList<Fb_Comment> postComment;
	private ArrayList<Fb_Media> postMedia;
	private ArrayList<Fb_User> postLike;

    
	public String getProfileImageLocal() {
		return profileImageLocal;
	}

	public void setProfileImageLocal(String profileImageLocal) {
		this.profileImageLocal = profileImageLocal;
	}

	public String getCoverImageLocal() {
		return coverImageLocal;
	}

	public void setCoverImageLocal(String coverImageLocal) {
		this.coverImageLocal = coverImageLocal;
	}

	public String getMediaImageLocal() {
		return mediaImageLocal;
	}

	public void setMediaImageLocal(String mediaImageLocal) {
		this.mediaImageLocal = mediaImageLocal;
	}

	public String getAbsPathLocal() {
		return absPathLocal;
	}

	public void setAbsPathLocal(String absPathLocal) {
		this.absPathLocal = absPathLocal;
	}

	public ArrayList<String> getPostHashtag() {
		return postHashtag;
	}

	public void setPostHashtag(ArrayList<String> postHashtag) {
		this.postHashtag = postHashtag;
	}

	public ArrayList<String> getPostMentionArray() {
		return postMentionArray;
	}

	public void setPostMentionArray(ArrayList<String> postMentionArray) {
		this.postMentionArray = postMentionArray;
	}

	public ArrayList<Fb_User> getPostMention() {
		return postMention;
	}

	public void setPostMention(ArrayList<Fb_User> postMention) {
		this.postMention = postMention;
	}

	public ArrayList<Fb_Comment> getPostComment() {
		return postComment;
	}

	public void setPostComment(ArrayList<Fb_Comment> postComment) {
		this.postComment = postComment;
	}

	public ArrayList<Fb_Media> getPostMedia() {
		return postMedia;
	}

	public void setPostMedia(ArrayList<Fb_Media> postMedia) {
		this.postMedia = postMedia;
	}

	public ArrayList<Fb_User> getPostLike() {
		return postLike;
	}

	public void setPostLike(ArrayList<Fb_User> postLike) {
		this.postLike = postLike;
	}

	public String getImg_md5() {
		return img_md5;
	}

	public void setImg_md5(String img_md5) {
		this.img_md5 = img_md5;
	}

	public String getUser_pic() {
		return user_pic;
	}

	public void setUser_pic(String user_pic) {
		this.user_pic = user_pic;
	}

	public String getProfileName() {
		return profileName;
	}

	public void setProfileName(String profileName) {
		this.profileName = profileName;
	}

	public String getNodeName1() {
		return nodeName1;
	}

	public void setNodeName1(String nodeName1) {
		this.nodeName1 = nodeName1;
	}

	public String getNodeName2() {
		return nodeName2;
	}

	public void setNodeName2(String nodeName2) {
		this.nodeName2 = nodeName2;
	}

	public String getNodeId1() {
		return nodeId1;
	}

	public void setNodeId1(String nodeId1) {
		this.nodeId1 = nodeId1;
	}

	public String getNodeId2() {
		return nodeId2;
	}

	public void setNodeId2(String nodeId2) {
		this.nodeId2 = nodeId2;
	}

	public String getNodeType() {
		return nodeType;
	}

	public void setNodeType(String nodeType) {
		this.nodeType = nodeType;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	public String getHashTag() {
		return hashTag;
	}

	public void setHashTag(String hashTag) {
		this.hashTag = hashTag;
	}

	public String getTagId() {
		return tagId;
	}

	public void setTagId(String tagId) {
		this.tagId = tagId;
	}



	public String getUser_id() {
		return user_id;
	}

	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}

	public String getLink_name() {
		return link_name;
	}

	public void setLink_name(String link_name) {
		this.link_name = link_name;
	}

	public String getAdvFilter() {
		return advFilter;
	}

	public void setAdvFilter(String advFilter) {
		this.advFilter = advFilter;
	}

	public String getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}

	private  List<WordFrequency> wordFrequencies;  //for word cloud

	public List<WordFrequency> getWordFrequencies() {
		return wordFrequencies;
	}

	public void setWordFrequencies(List<WordFrequency> wordFrequencies) {
		this.wordFrequencies = wordFrequencies;
	}

	public String getImage_id() {
		return image_id;
	}

	public void setImage_id(String image_id) {
		this.image_id = image_id;
	}

	public String getSub_att_img_title() {
		return sub_att_img_title;
	}

	public void setSub_att_img_title(String sub_att_img_title) {
		this.sub_att_img_title = sub_att_img_title;
	}

	public String getSub_att_img_desc() {
		return sub_att_img_desc;
	}

	public void setSub_att_img_desc(String sub_att_img_desc) {
		this.sub_att_img_desc = sub_att_img_desc;
	}

	public String getSub_att_img_type() {
		return sub_att_img_type;
	}

	public void setSub_att_img_type(String sub_att_img_type) {
		this.sub_att_img_type = sub_att_img_type;
	}

	public String getSub_att_img_url() {
		return sub_att_img_url;
	}

	public void setSub_att_img_url(String sub_att_img_url) {
		this.sub_att_img_url = sub_att_img_url;
	}

	public String getSub_att_img_src() {
		return sub_att_img_src;
	}

	public void setSub_att_img_src(String sub_att_img_src) {
		this.sub_att_img_src = sub_att_img_src;
	}

	public String getCount() {
		return count;
	}

	public void setCount(String count) {
		this.count = count;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public String getEntity_id() {
		return entity_id;
	}

	public void setEntity_id(String entity_id) {
		this.entity_id = entity_id;
	}

	public String getPost_id() {
		return post_id;
	}

	public void setPost_id(String post_id) {
		this.post_id = post_id;
	}

	public String getPost_user_id() {
		return post_user_id;
	}

	public void setPost_user_id(String post_user_id) {
		this.post_user_id = post_user_id;
	}

	public String getPost_user_name() {
		return post_user_name;
	}

	public void setPost_user_name(String post_user_name) {
		this.post_user_name = post_user_name;
	}

	public String getPost_source() {
		return post_source;
	}

	public void setPost_source(String post_source) {
		this.post_source = post_source;
	}

	public String getPost_share_count() {
		return post_share_count;
	}

	public void setPost_share_count(String post_share_count) {
		this.post_share_count = post_share_count;
	}

	public String getPost_caption() {
		return post_caption;
	}

	public void setPost_caption(String post_caption) {
		this.post_caption = post_caption;
	}

	public String getPost_message() {
		return post_message;
	}

	public void setPost_message(String post_message) {
		this.post_message = post_message;
	}

	public String getPost_createdtime() {
		return post_createdtime;
	}

	public void setPost_createdtime(String post_createdtime) {
		this.post_createdtime = post_createdtime;
	}

	public String getPost_link() {
		return post_link;
	}

	public void setPost_link(String post_link) {
		this.post_link = post_link;
	}

	public String getPage_id() {
		return page_id;
	}

	public void setPage_id(String page_id) {
		this.page_id = page_id;
	}

	public String getPost_like_count() {
		return post_like_count;
	}

	public void setPost_like_count(String post_like_count) {
		this.post_like_count = post_like_count;
	}

	public String getPost_comment_count() {
		return post_comment_count;
	}

	public void setPost_comment_count(String post_comment_count) {
		this.post_comment_count = post_comment_count;
	}

	public String getSentiment() {
		return sentiment;
	}

	public void setSentiment(String sentiment) {
		this.sentiment = sentiment;
	}

	public String getPost_type() {
		return post_type;
	}

	public void setPost_type(String post_type) {
		this.post_type = post_type;
	}

	public String getPost_updated_time() {
		return post_updated_time;
	}

	public void setPost_updated_time(String post_updated_time) {
		this.post_updated_time = post_updated_time;
	}

	public String getPost_picture() {
		return post_picture;
	}

	public void setPost_picture(String post_picture) {
		this.post_picture = post_picture;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public String getPage_coverSource() {
		return page_coverSource;
	}

	public void setPage_coverSource(String page_coverSource) {
		this.page_coverSource = page_coverSource;
	}

	public String getPage_about() {
		return page_about;
	}

	public void setPage_about(String page_about) {
		this.page_about = page_about;
	}

	public String getPage_link() {
		return page_link;
	}

	public void setPage_link(String page_link) {
		this.page_link = page_link;
	}

	public String getPage_phone() {
		return page_phone;
	}

	public void setPage_phone(String page_phone) {
		this.page_phone = page_phone;
	}

	public String getPage_description() {
		return page_description;
	}

	public void setPage_description(String page_description) {
		this.page_description = page_description;
	}

	public String getPage_name_with_location_descriptor() {
		return page_name_with_location_descriptor;
	}

	public void setPage_name_with_location_descriptor(
			String page_name_with_location_descriptor) {
		this.page_name_with_location_descriptor = page_name_with_location_descriptor;
	}

	public String getPage_website() {
		return page_website;
	}

	public void setPage_website(String page_website) {
		this.page_website = page_website;
	}

	public String getPage_category() {
		return page_category;
	}

	public void setPage_category(String page_category) {
		this.page_category = page_category;
	}

	public String getPage_likesCount() {
		return page_likesCount;
	}

	public void setPage_likesCount(String page_likesCount) {
		this.page_likesCount = page_likesCount;
	}

	public String getPage_were_here_count() {
		return page_were_here_count;
	}

	public void setPage_were_here_count(String page_were_here_count) {
		this.page_were_here_count = page_were_here_count;
	}

	public String getComment_id() {
		return comment_id;
	}

	public void setComment_id(String comment_id) {
		this.comment_id = comment_id;
	}

	public String getComment_message() {
		return comment_message;
	}

	public void setComment_message(String comment_message) {
		this.comment_message = comment_message;
	}

	public String getComment_createdtime() {
		return comment_createdtime;
	}

	public void setComment_createdtime(String comment_createdtime) {
		this.comment_createdtime = comment_createdtime;
	}

	public String getComment_likecount() {
		return comment_likecount;
	}

	public void setComment_likecount(String comment_likecount) {
		this.comment_likecount = comment_likecount;
	}

	public String getFanCount() {
		return fanCount;
	}

	public void setFanCount(String fanCount) {
		this.fanCount = fanCount;
	}

	public String getLikes() {
		return likes;
	}

	public void setLikes(String likes) {
		this.likes = likes;
	}

	public String getPageId() {
		return pageId;
	}

	public void setPageId(String pageId) {
		this.pageId = pageId;
	}

	public String getPageImage() {
		return pageImage;
	}

	public void setPageImage(String pageImage) {
		this.pageImage = pageImage;
	}

	public String getPageName() {
		return pageName;
	}

	public void setPageName(String pageName) {
		this.pageName = pageName;
	}

	public String getPageUrl() {
		return pageUrl;
	}

	public void setPageUrl(String pageUrl) {
		this.pageUrl = pageUrl;
	}

	public String getGlobalBrandPageName() {
		return globalBrandPageName;
	}

	public void setGlobalBrandPageName(String globalBrandPageName) {
		this.globalBrandPageName = globalBrandPageName;
	}

	@Override
	public String toString() {
		return "FbOutputVo [pageId=" + pageId + ", pageImage=" + pageImage + ", pageName=" + pageName + ", pageUrl="
				+ pageUrl + ", globalBrandPageName=" + globalBrandPageName + ", likes=" + likes + ", fanCount="
				+ fanCount + ", entity_id=" + entity_id + ", post_id=" + post_id + ", post_user_id=" + post_user_id
				+ ", post_user_name=" + post_user_name + ", post_source=" + post_source + ", post_share_count="
				+ post_share_count + ", post_caption=" + post_caption + ", post_message=" + post_message
				+ ", post_createdtime=" + post_createdtime + ", post_link=" + post_link + ", page_id=" + page_id
				+ ", post_like_count=" + post_like_count + ", post_comment_count=" + post_comment_count + ", sentiment="
				+ sentiment + ", post_type=" + post_type + ", post_updated_time=" + post_updated_time
				+ ", post_picture=" + post_picture + ", latitude=" + latitude + ", longitude=" + longitude
				+ ", country=" + country + ", state=" + state + ", city=" + city + ", zip=" + zip
				+ ", page_coverSource=" + page_coverSource + ", page_about=" + page_about + ", page_link=" + page_link
				+ ", page_phone=" + page_phone + ", page_description=" + page_description
				+ ", page_name_with_location_descriptor=" + page_name_with_location_descriptor + ", page_website="
				+ page_website + ", page_category=" + page_category + ", page_likesCount=" + page_likesCount
				+ ", page_were_here_count=" + page_were_here_count + ", comment_id=" + comment_id + ", comment_message="
				+ comment_message + ", comment_createdtime=" + comment_createdtime + ", comment_likecount="
				+ comment_likecount + ", priority=" + priority + ", count=" + count + ", image_id=" + image_id
				+ ", sub_att_img_title=" + sub_att_img_title + ", sub_att_img_desc=" + sub_att_img_desc
				+ ", sub_att_img_type=" + sub_att_img_type + ", sub_att_img_url=" + sub_att_img_url
				+ ", sub_att_img_src=" + sub_att_img_src + ", createdAt=" + createdAt + ", advFilter=" + advFilter
				+ ", link_name=" + link_name + ", hashTag=" + hashTag + ", tagId=" + tagId + ", user_name=" + user_name
				+ ", user_id=" + user_id + ", nodeName1=" + nodeName1 + ", nodeName2=" + nodeName2 + ", nodeId1="
				+ nodeId1 + ", nodeId2=" + nodeId2 + ", nodeType=" + nodeType + ", profileName=" + profileName
				+ ", user_pic=" + user_pic + ", img_md5=" + img_md5 + ", profileImageLocal=" + profileImageLocal
				+ ", coverImageLocal=" + coverImageLocal + ", mediaImageLocal=" + mediaImageLocal + ", absPathLocal="
				+ absPathLocal + ", postHashtag=" + postHashtag + ", postMentionArray=" + postMentionArray
				+ ", postMention=" + postMention + ", postComment=" + postComment + ", postMedia=" + postMedia
				+ ", postLike=" + postLike + ", wordFrequencies=" + wordFrequencies + "]";
	}
}
