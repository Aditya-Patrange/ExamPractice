package com.cdac.sudarshan.folder.model;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class SubSubFolderName {

	private String subSubFolderName;

}
