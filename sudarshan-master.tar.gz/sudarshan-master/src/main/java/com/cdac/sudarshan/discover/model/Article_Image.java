package com.cdac.sudarshan.discover.model;

import java.util.ArrayList;

public class Article_Image 
{
	private String imageType; //user, post
	private String imageUrl;
	private String imageUrlHash;
	private String guid;
	private ArrayList<String> odsObjects;
	
	public String getImageType() {
		return imageType;
	}
	public void setImageType(String imageType) {
		this.imageType = imageType;
	}
	public String getImageUrl() {
		return imageUrl;
	}
	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}
	public String getImageUrlHash() {
		return imageUrlHash;
	}
	public void setImageUrlHash(String imageUrlHash) {
		this.imageUrlHash = imageUrlHash;
	}
	public ArrayList<String> getOdsObjects() {
		return odsObjects;
	}
	public void setOdsObjects(ArrayList<String> odsObjects) {
		this.odsObjects = odsObjects;
	}
	public String getGuid() {
		return guid;
	}
	public void setGuid(String guid) {
		this.guid = guid;
	}
	@Override
	public String toString() {
		return "Article_Image [imageType=" + imageType + ", imageUrl=" + imageUrl + ", imageUrlHash=" + imageUrlHash
				+ ", odsObjects=" + odsObjects + ", guid=" + guid + "]";
	}
	
}
