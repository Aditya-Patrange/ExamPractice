package com.cdac.sudarshan.discover.common;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.cdac.sudarshan.discover.model.Fb_OutputVo;
//import com.innefu.innsight.common.ApplicationConstants;
//import com.innefu.innsight.common.CommonUtils;
//import com.innefu.innsight.common.TwitterConstant;
//import com.innefu.innsight.dashboard.dao.DashboardDAO;
//import com.innefu.innsight.dashboard.daoVo.DashInputVo;
//import com.innefu.innsight.dashboard.daoVo.DashOutputVo;
//import com.innefu.innsight.dashboard.daoVo.Dashboard;
//import com.innefu.innsight.dashboard.daoVo.DashboardWidgetVo;
//import com.innefu.innsight.dashboard.daoVo.Widget;
//import com.innefu.innsight.facebook.vo.FbOutputVo;

@Repository
public class DashboardDAOImpl implements DashboardDAO 
{
	@Autowired 
	private HttpSession httpSession;

	/*@Autowired
	private DataSource dataSource;*/
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	Logger logger = Logger.getRootLogger();

	
//	public void setDataSource(DataSource dataSource) {
//		this.jdbcTemplate = new JdbcTemplate(dataSource);
//	}


	@Override
	public ArrayList<DashOutputVo> dashEntityCount(DashInputVo dashInputVo) 
	{
		ArrayList<DashOutputVo> lst=new ArrayList<DashOutputVo>();

		try 
		{
			String joinQuery=" inner join  tbl_case_entity ON tbl_case_entity.entity_id=dboard_common_entity_count.entity_id  "
					+ " where tbl_case_entity.case_id='"+dashInputVo.getCaseId().trim()+"' and  date_of_insertion >='"+CommonUtils.convertDateFormat(dashInputVo.getFromDate().trim())+"' AND date_of_insertion <='"+CommonUtils.convertDateFormat(dashInputVo.getToDate().trim())+"' ";

			String query="SELECT SUM(dboard_common_entity_count.oneDay_total_count) as oneDay_total_count,dboard_common_entity_count.entity_type ," +
					" SUM(dboard_common_entity_count.total_count) as total_count,"
					+ " dboard_common_entity_count.date_of_insertion " +
					" FROM dboard_common_entity_count " +joinQuery+
					" GROUP BY dboard_common_entity_count.entity_type,dboard_common_entity_count.date_of_insertion order by date_of_insertion desc,dboard_common_entity_count.entity_type ASC ";
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);

			for(Map<String,Object> rs : rows)
			{
				DashOutputVo dashOutputVo=new DashOutputVo();
				dashOutputVo.setOneDay_total_count(rs.get("oneDay_total_count")==null?"0":rs.get("oneDay_total_count").toString());
				dashOutputVo.setType(rs.get("entity_type")==null?"":rs.get("entity_type").toString());
				dashOutputVo.setTotal_count(rs.get("total_count")==null?"0":rs.get("total_count").toString());
				dashOutputVo.setDate_of_insertion(rs.get("date_of_insertion")==null?"":rs.get("date_of_insertion").toString());
				lst.add(dashOutputVo);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return lst;
	}




	@Override
	public ArrayList<DashOutputVo> dashTimeLine(DashInputVo dashInputVo) 
	{
		ArrayList<DashOutputVo> lst=new ArrayList<DashOutputVo>();
		try 
		{

			String joinQuery=" inner join  tbl_case_entity ON tbl_case_entity.entity_id=dboard_common_entity_sentiment.entity_id  "
					+ " where tbl_case_entity.case_id='"+dashInputVo.getCaseId().trim()+"' and  date_of_insertion >='"+CommonUtils.convertDateFormat(dashInputVo.getFromDate().trim())+"' AND date_of_insertion <='"+CommonUtils.convertDateFormat(dashInputVo.getToDate().trim())+"' ";      

			String query="	SELECT "+ 
					" (SELECT SUM(psentiment_count) FROM dboard_common_entity_sentiment "+joinQuery+" ) AS psentiment_count, "+
					" (SELECT SUM(nesentiment_count) FROM dboard_common_entity_sentiment "+joinQuery+"   ) AS nesentiment_count, "+
					" (SELECT SUM(nusentiment_count) FROM dboard_common_entity_sentiment  "+joinQuery+"  ) AS nusentiment_count, "+
					" tbl.*  FROM ( "+
					" SELECT   AVG(dboard_common_entity_sentiment.avg_sentiment) as avg_sentiment,   dboard_common_entity_sentiment.date_of_insertion,  dboard_common_entity_sentiment.entity_type "+
					" FROM dboard_common_entity_sentiment "+joinQuery+" GROUP BY entity_type,date_of_insertion ORDER BY date_of_insertion DESC,entity_type ASC ) AS tbl ";

			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);

			for(Map<String,Object> rs : rows)
			{
				DashOutputVo dashOutputVo=new DashOutputVo();
				dashOutputVo.setAvg_sentiment(rs.get("avg_sentiment")==null?"0":rs.get("avg_sentiment").toString());
				dashOutputVo.setPsentiment_count(rs.get("psentiment_count")==null?"0":rs.get("psentiment_count").toString());
				dashOutputVo.setNesentiment_count(rs.get("nesentiment_count")==null?"0":rs.get("nesentiment_count").toString());
				dashOutputVo.setNusentiment_count(rs.get("nusentiment_count")==null?"0":rs.get("nusentiment_count").toString());
				dashOutputVo.setEntity_type(rs.get("entity_type")==null?"0":rs.get("entity_type").toString());
				dashOutputVo.setDate_of_insertion(rs.get("date_of_insertion")==null?"":rs.get("date_of_insertion").toString());
				lst.add(dashOutputVo);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return lst;
	}

	
	@Override
	public ArrayList<DashOutputVo> dashTwTrends(DashInputVo dashInputVo) {
		ArrayList<DashOutputVo> lst=new ArrayList<DashOutputVo>();
		try {
			List<Map<String,Object>> rows=null;
			String joinQuery=" inner join  tbl_case_entity ON tbl_case_entity.entity_id=dboard_common_wordcloud_sentiment.entity_id  "
					+ " where tbl_case_entity.case_id='"+dashInputVo.getCaseId().trim()+"' and  date_of_insertion >='"+CommonUtils.convertDateFormat(dashInputVo.getFromDate().trim())+"' AND date_of_insertion <='"+CommonUtils.convertDateFormat(dashInputVo.getToDate().trim())+"' ";

			//for +ve trends
			String query="SELECT dboard_common_wordcloud_sentiment.word,dboard_common_wordcloud_sentiment.senti_type,dboard_common_wordcloud_sentiment.count "+
					" FROM dboard_common_wordcloud_sentiment "+
					joinQuery + 
					"  and  dboard_common_wordcloud_sentiment.senti_type='1' "+
					"order by count desc  "+
					"LIMIT 10  ";
			rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs : rows){
				DashOutputVo dashOutputVo=new DashOutputVo();
				dashOutputVo.setWord(rs.get("word")==null?"":rs.get("word").toString());
				dashOutputVo.setType("1");
				lst.add(dashOutputVo);
			}

			//for -ve trends
			query="SELECT dboard_common_wordcloud_sentiment.word,dboard_common_wordcloud_sentiment.senti_type,dboard_common_wordcloud_sentiment.count "+
					"FROM dboard_common_wordcloud_sentiment "+
					joinQuery + 
					"  and dboard_common_wordcloud_sentiment.senti_type='-1' "+
					" order by count desc  "+
					"LIMIT 10  ";
			rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs : rows){
				DashOutputVo dashOutputVo=new DashOutputVo();
				dashOutputVo.setWord(rs.get("word")==null?"":rs.get("word").toString());
				dashOutputVo.setType("-1");
				lst.add(dashOutputVo);
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}

		return lst;
	}

	@Override
	public ArrayList<DashOutputVo> dashGeoMap(DashInputVo dashInputVo) {
		ArrayList<DashOutputVo> lst=new ArrayList<DashOutputVo>();
		try {

			String joinQuery=" inner join  tbl_case_entity ON tbl_case_entity.entity_id=dboard_common_map.entity_id  "
					+ " where tbl_case_entity.case_id='"+dashInputVo.getCaseId().trim()+"' and  date_of_insertion >='"+CommonUtils.convertDateFormat(dashInputVo.getFromDate().trim())+"' AND date_of_insertion <='"+CommonUtils.convertDateFormat(dashInputVo.getToDate().trim())+"' ";
			String query="SELECT dboard_common_map.country_code,SUM(dboard_common_map.count) cnt "+
					" FROM dboard_common_map   "+joinQuery+
					" 	GROUP BY dboard_common_map.country_code" ;
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs : rows){
				DashOutputVo dashOutputVo=new DashOutputVo();
				dashOutputVo.setCode(rs.get("country_code")==null?"":rs.get("country_code").toString().toLowerCase());
				dashOutputVo.setCount(rs.get("cnt")==null?"":rs.get("cnt").toString());
				lst.add(dashOutputVo);
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return lst;
	}

	@Override
	public ArrayList<DashOutputVo> dashRssNER(DashInputVo dashInputVo) {
		ArrayList<DashOutputVo> lst=new ArrayList<DashOutputVo>();
		try {

			List<Map<String,Object>> rows=null;
			String joinQuery=" inner join  tbl_case_entity ON tbl_case_entity.entity_id=dboard_common_ner.entity_id  "
					+ " where tbl_case_entity.case_id='"+dashInputVo.getCaseId().trim()+"' and date_of_insertion >='"+CommonUtils.convertDateFormat(dashInputVo.getFromDate().trim())+"' AND date_of_insertion <='"+CommonUtils.convertDateFormat(dashInputVo.getToDate().trim())+"' ";

			//top location
			String	query="SELECT dboard_common_ner.tagvalue,COUNT(*) AS cnt "+
					" FROM dboard_common_ner "+	joinQuery+
					" and dboard_common_ner.tagtype='Location' "+
					" GROUP BY dboard_common_ner.tagvalue "+
					" ORDER BY cnt DESC "+
					" LIMIT 10" ;
			rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs : rows){
				DashOutputVo dashOutputVo=new DashOutputVo();
				dashOutputVo.setTagValue(rs.get("tagvalue")==null?"":rs.get("tagvalue").toString());
				dashOutputVo.setCount(rs.get("cnt")==null?"":rs.get("cnt").toString());
				dashOutputVo.setType("Location");
				lst.add(dashOutputVo);
			}

			//top Person
			query="SELECT dboard_common_ner.tagvalue,COUNT(*) AS cnt "+
					" FROM dboard_common_ner "+	joinQuery+
					" and dboard_common_ner.tagtype='Person' "+
					" GROUP BY dboard_common_ner.tagvalue "+
					" ORDER BY cnt DESC "+
					" LIMIT 10" ;
			rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs : rows){
				DashOutputVo dashOutputVo=new DashOutputVo();
				dashOutputVo.setTagValue(rs.get("tagvalue")==null?"":rs.get("tagvalue").toString());
				dashOutputVo.setCount(rs.get("cnt")==null?"":rs.get("cnt").toString());
				dashOutputVo.setType("Person");
				lst.add(dashOutputVo);
			}

			//top ORGANIZATION
			query="SELECT dboard_common_ner.tagvalue,COUNT(*) AS cnt "+
					" FROM dboard_common_ner "+	joinQuery+
					" and dboard_common_ner.tagtype='ORGANIZATION' "+
					" GROUP BY dboard_common_ner.tagvalue "+
					" ORDER BY cnt DESC "+
					" LIMIT 10" ;
			rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs : rows){
				DashOutputVo dashOutputVo=new DashOutputVo();
				dashOutputVo.setTagValue(rs.get("tagvalue")==null?"":rs.get("tagvalue").toString());
				dashOutputVo.setCount(rs.get("cnt")==null?"":rs.get("cnt").toString());
				dashOutputVo.setType("ORGANIZATION");
				lst.add(dashOutputVo);
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return lst;
	}

	@Override
	public ArrayList<DashOutputVo> dashPhases(DashInputVo dashInputVo) {
		ArrayList<DashOutputVo> lst=new ArrayList<DashOutputVo>();
		try {

			String joinQuery=" inner join  tbl_case_entity ON tbl_case_entity.entity_id=dboard_common_phrases.entity_id  "
					+ " where tbl_case_entity.case_id='"+dashInputVo.getCaseId().trim()+"' and  date_of_insertion >='"+CommonUtils.convertDateFormat(dashInputVo.getFromDate().trim())+"' AND date_of_insertion <='"+CommonUtils.convertDateFormat(dashInputVo.getToDate().trim())+"' ";
			String query="SELECT word FROM dboard_common_phrases "+joinQuery +" limit 10";
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs : rows){
				DashOutputVo dashOutputVo=new DashOutputVo();
				dashOutputVo.setWord(rs.get("word")==null?"":rs.get("word").toString());
				lst.add(dashOutputVo);
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return lst;
	}

	@Override
	public ArrayList<DashOutputVo> dashActiveUser(DashInputVo dashInputVo) {
		ArrayList<DashOutputVo> lst=new ArrayList<DashOutputVo>();
		try {
			String joinQuery=" inner join  tbl_case_entity ON tbl_case_entity.entity_id=dboard_common_active_user.entity_id  "
					+ " where tbl_case_entity.case_id='"+dashInputVo.getCaseId().trim()+"' and  date_of_insertion >='"+CommonUtils.convertDateFormat(dashInputVo.getFromDate().trim())+"' AND date_of_insertion <='"+CommonUtils.convertDateFormat(dashInputVo.getToDate().trim())+"' ";
			String query=" SELECT dboard_common_active_user.userid,"
					+ " dboard_common_active_user.username,"
					+ "dboard_common_active_user.user_profile_img,"
					+ "dboard_common_active_user.entity_type,count(*) as cnt"
					+ " FROM dboard_common_active_user "+joinQuery+ " and entity_type=0 " +
					" group by dboard_common_active_user.userid order by cnt desc limit 12  ";
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs : rows){
				DashOutputVo dashOutputVo=new DashOutputVo();
				dashOutputVo.setUserid(rs.get("userid")==null?"":rs.get("userid").toString());
				dashOutputVo.setUsername(rs.get("username")==null?"":rs.get("username").toString());
				dashOutputVo.setUser_profile_img(rs.get("user_profile_img")==null?"":rs.get("user_profile_img").toString());
				dashOutputVo.setType(rs.get("entity_type")==null?"":rs.get("entity_type").toString());
				lst.add(dashOutputVo);
			}

			query=" SELECT dboard_common_active_user.userid,"
					+ " dboard_common_active_user.username,"
					+ "dboard_common_active_user.user_profile_img,"
					+ "dboard_common_active_user.entity_type,count(*) as cnt"
					+ " FROM dboard_common_active_user "+joinQuery+" and entity_type=1 " +
					" group by dboard_common_active_user.userid order by cnt desc limit 12  ";
			rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs : rows){
				DashOutputVo dashOutputVo=new DashOutputVo();
				dashOutputVo.setUserid(rs.get("userid")==null?"":rs.get("userid").toString());
				dashOutputVo.setUsername(rs.get("username")==null?"":rs.get("username").toString());
				dashOutputVo.setUser_profile_img(rs.get("user_profile_img")==null?"":rs.get("user_profile_img").toString());
				dashOutputVo.setType(rs.get("entity_type")==null?"":rs.get("entity_type").toString());
				lst.add(dashOutputVo);
			}

			query=" SELECT dboard_common_active_user.userid,"
					+ " dboard_common_active_user.username,"
					+ "dboard_common_active_user.user_profile_img,"
					+ "dboard_common_active_user.entity_type,count(*) as cnt"
					+ " FROM dboard_common_active_user "+joinQuery+" and entity_type=2 " +
					" group by dboard_common_active_user.userid order by cnt desc limit 12  ";
			rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs : rows){
				DashOutputVo dashOutputVo=new DashOutputVo();
				dashOutputVo.setUserid(rs.get("userid")==null?"":rs.get("userid").toString());
				dashOutputVo.setUsername(rs.get("username")==null?"":rs.get("username").toString());
				dashOutputVo.setUser_profile_img(rs.get("user_profile_img")==null?"":rs.get("user_profile_img").toString());
				dashOutputVo.setType(rs.get("entity_type")==null?"":rs.get("entity_type").toString());
				lst.add(dashOutputVo);
			}

			query=" SELECT dboard_common_active_user.userid,"
					+ " dboard_common_active_user.username,"
					+ "dboard_common_active_user.user_profile_img,"
					+ "dboard_common_active_user.entity_type,count(*) as cnt"
					+ " FROM dboard_common_active_user "+joinQuery+" and entity_type=3 " +
					" group by dboard_common_active_user.userid order by cnt desc limit 12  ";
			rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs : rows){
				DashOutputVo dashOutputVo=new DashOutputVo();
				dashOutputVo.setUserid(rs.get("userid")==null?"":rs.get("userid").toString());
				dashOutputVo.setUsername(rs.get("username")==null?"":rs.get("username").toString());
				dashOutputVo.setUser_profile_img(rs.get("user_profile_img")==null?"":rs.get("user_profile_img").toString());
				dashOutputVo.setType(rs.get("entity_type")==null?"":rs.get("entity_type").toString());
				lst.add(dashOutputVo);
			}

		}catch(Exception e)
		{
			e.printStackTrace();
		}

		return lst;
	}

	@Override
	public ArrayList<DashOutputVo> dashActiveHashTag(DashInputVo dashInputVo) {
		ArrayList<DashOutputVo> lst=new ArrayList<DashOutputVo>();
		try {
			String joinQuery=" inner join  tbl_case_entity ON tbl_case_entity.entity_id=dboard_common_active_hashtag.entity_id  "
					+ " where tbl_case_entity.case_id='"+dashInputVo.getCaseId().trim()+"' and  date_of_insertion >='"+CommonUtils.convertDateFormat(dashInputVo.getFromDate().trim())+"' AND date_of_insertion <='"+CommonUtils.convertDateFormat(dashInputVo.getToDate().trim())+"' ";
			String query=" SELECT dboard_common_active_hashtag.hashtag,count(*) as cnt "
					+ " FROM dboard_common_active_hashtag "+joinQuery+
					" group by dboard_common_active_hashtag.hashtag order by cnt desc limit 10 ";
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs : rows){
				DashOutputVo dashOutputVo=new DashOutputVo();
				dashOutputVo.setUsername(rs.get("hashtag")==null?"":rs.get("hashtag").toString());
				lst.add(dashOutputVo);
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return lst;
	}

	@Override
	public ArrayList<DashOutputVo> dashActiveMedia(DashInputVo dashInputVo)
	{
		ArrayList<DashOutputVo> list=new ArrayList<DashOutputVo>();
		try
		{
			List<Map<String,Object>> rows =null;
			String joinQuery=" inner join  tbl_case_entity ON tbl_case_entity.entity_id=dboard_common_trending_media.entity_id  "
					+ " where tbl_case_entity.case_id='"+dashInputVo.getCaseId().trim()+"' and  date_of_insertion >='"+CommonUtils.convertDateFormat(dashInputVo.getFromDate().trim())+"' AND date_of_insertion <='"+CommonUtils.convertDateFormat(dashInputVo.getToDate().trim())+"' ";
			//active image
			String query=" SELECT distinct dboard_common_trending_media.media FROM dboard_common_trending_media "+joinQuery+
					" AND dboard_common_trending_media.active_type='0' limit 0,30 ";

			rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs : rows)
			{
				DashOutputVo dashOutputVo=new DashOutputVo();
				dashOutputVo.setMedia(rs.get("media")==null?"":rs.get("media").toString());
				dashOutputVo.setType("0");
				list.add(dashOutputVo);
			}

			//active video
			query=" SELECT distinct dboard_common_trending_media.media FROM dboard_common_trending_media "+joinQuery+
					" AND dboard_common_trending_media.active_type='1'  limit 0,30 ";
			rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs : rows)
			{
				DashOutputVo dashOutputVo=new DashOutputVo();
				dashOutputVo.setMedia(rs.get("media")==null?"":rs.get("media").toString());
				dashOutputVo.setType("1");
				list.add(dashOutputVo);
			}

			//active link
			query=" SELECT distinct dboard_common_trending_media.media FROM dboard_common_trending_media "+joinQuery+
					" AND dboard_common_trending_media.active_type='2' limit 0,10 ";
			rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs : rows)
			{
				DashOutputVo dashOutputVo=new DashOutputVo();
				dashOutputVo.setMedia(rs.get("media")==null?"":rs.get("media").toString());
				dashOutputVo.setType("2");
				list.add(dashOutputVo);
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}

		return list;
	}

	@Override
	public ArrayList<DashOutputVo> dashTopTrendingTweets(DashInputVo dashInputVo) {
		ArrayList<DashOutputVo> lst=new ArrayList<DashOutputVo>();
		try {

			String joinQuery=" inner join  tbl_case_entity ON tbl_case_entity.entity_id=dboard_common_trending_tweet.entity_id  "
					+ " where tbl_case_entity.case_id='"+dashInputVo.getCaseId().trim()+"' and  date_of_insertion >='"+CommonUtils.convertDateFormat(dashInputVo.getFromDate().trim())+"' AND date_of_insertion <='"+CommonUtils.convertDateFormat(dashInputVo.getToDate().trim())+"' ";
			String query="SELECT  "
					+ " DATE_FORMAT(FROM_UNIXTIME(dboard_common_trending_tweet.created_at),'%b %d, %Y %r') AS created_at,"
					+ "dboard_common_trending_tweet.text ," +
					" dboard_common_trending_tweet.user_id,"
					+ "dboard_common_trending_tweet.user_name, " +
					"dboard_common_trending_tweet.retweet_count, " +
					"dboard_common_trending_tweet.favourite_count, " +
					"dboard_common_trending_tweet.user_img, " +
					"dboard_common_trending_tweet.user_follower, " +
					"dboard_common_trending_tweet.user_friend, " +
					"dboard_common_trending_tweet.user_tweet, " +
					"dboard_common_trending_tweet.user_full_name " +
					"FROM dboard_common_trending_tweet " +joinQuery+" group by dboard_common_trending_tweet.id    order by (retweet_count + favourite_count) desc limit 10 ";
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs : rows){
				DashOutputVo dashOutputVo=new DashOutputVo();
				dashOutputVo.setCreated_at(rs.get("created_at")==null?"":rs.get("created_at").toString());
				dashOutputVo.setText(rs.get("text")==null?"":rs.get("text").toString());
				dashOutputVo.setUser_id(rs.get("user_id")==null?"":rs.get("user_id").toString());
				dashOutputVo.setUser_name(rs.get("user_name")==null?"":rs.get("user_name").toString());
				dashOutputVo.setRetweet_count(rs.get("retweet_count")==null?"0":rs.get("retweet_count").toString());
				dashOutputVo.setFavourite_count(rs.get("favourite_count")==null?"0":rs.get("favourite_count").toString());
				dashOutputVo.setUser_img(rs.get("user_img")==null?"":rs.get("user_img").toString());
				dashOutputVo.setUser_follower(rs.get("user_follower")==null?"0":rs.get("user_follower").toString());
				dashOutputVo.setUser_friend(rs.get("user_friend")==null?"0":rs.get("user_friend").toString());
				dashOutputVo.setUser_tweet(rs.get("user_tweet")==null?"0":rs.get("user_tweet").toString());
				dashOutputVo.setUser_full_name(rs.get("user_full_name")==null?"":rs.get("user_full_name").toString());
				lst.add(dashOutputVo);
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return lst;
	}

	@Override
	public ArrayList<DashOutputVo> dashTopTrendingVideos(DashInputVo dashInputVo) {
		ArrayList<DashOutputVo> lst=new ArrayList<DashOutputVo>();
		try {
			String joinQuery=" inner join  tbl_case_entity ON tbl_case_entity.entity_id=dboard_common_trending_yt_video.entity_id  "
					+ " where tbl_case_entity.case_id='"+dashInputVo.getCaseId().trim()+"' and  date_of_insertion >='"+CommonUtils.convertDateFormat(dashInputVo.getFromDate().trim())+"' AND date_of_insertion <='"+CommonUtils.convertDateFormat(dashInputVo.getToDate().trim())+"' ";
			String query="SELECT "
					+ "dboard_common_trending_yt_video.thumbnails_medium_url, "
					+ "dboard_common_trending_yt_video.title, "
					+ "dboard_common_trending_yt_video.channel_title,dboard_common_trending_yt_video.channel_id, "
					+ " DATE_FORMAT(FROM_UNIXTIME(dboard_common_trending_yt_video.publishedAt),'%b %d, %Y %r') AS publishedAt,"
					+ " dboard_common_trending_yt_video.like_count, "
					+ " dboard_common_trending_yt_video.comment_count,dboard_common_trending_yt_video.view_count,"
					+ " dboard_common_trending_yt_video.dislike_count,dboard_common_trending_yt_video.favorite_count,dboard_common_trending_yt_video.videoUrl "+
					" FROM dboard_common_trending_yt_video " +joinQuery +" group by dboard_common_trending_yt_video.video_id   order by (view_count+like_count+comment_count+favorite_count+dislike_count) desc limit 10";

			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs : rows){
				DashOutputVo dashOutputVo=new DashOutputVo();
				dashOutputVo.setThumbnails_medium_url(rs.get("thumbnails_medium_url")==null?"":rs.get("thumbnails_medium_url").toString());
				dashOutputVo.setTitle(rs.get("title")==null?"":rs.get("title").toString());
				dashOutputVo.setChannel_title(rs.get("channel_title")==null?"":rs.get("channel_title").toString());
				dashOutputVo.setPublishedAt(rs.get("publishedAt")==null?"":rs.get("publishedAt").toString());
				dashOutputVo.setLike_count(rs.get("like_count")==null?"":rs.get("like_count").toString());
				dashOutputVo.setComment_count(rs.get("comment_count")==null?"":rs.get("comment_count").toString());
				dashOutputVo.setView_count(rs.get("view_count")==null?"":rs.get("view_count").toString());
				dashOutputVo.setDislike_count(rs.get("dislike_count")==null?"":rs.get("dislike_count").toString());
				dashOutputVo.setFavorite_count(rs.get("favorite_count")==null?"":rs.get("favorite_count").toString());
				dashOutputVo.setChannelId(rs.get("channel_id")==null?"":rs.get("channel_id").toString());
				dashOutputVo.setVideoUrl(rs.get("videoUrl")==null?"":rs.get("videoUrl").toString());

				lst.add(dashOutputVo);
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return lst;
	}

	@Override
	public ArrayList<DashOutputVo> dashTopTrendingInstaPost(
			DashInputVo dashInputVo) {
		ArrayList<DashOutputVo> lst=new ArrayList<DashOutputVo>();
		try {
			String joinQuery=" inner join  tbl_case_entity ON tbl_case_entity.entity_id=dboard_common_trending_insta_post.entity_id  "
					+ " where tbl_case_entity.case_id='"+dashInputVo.getCaseId().trim()+"' and  date_of_insertion >='"+CommonUtils.convertDateFormat(dashInputVo.getFromDate().trim())+"' AND date_of_insertion <='"+CommonUtils.convertDateFormat(dashInputVo.getToDate().trim())+"' ";
			String query="SELECT  "
					+ " DATE_FORMAT(FROM_UNIXTIME(dboard_common_trending_insta_post.created_time),'%b %d, %Y %r') AS created_time,"
					+ "dboard_common_trending_insta_post.insta_caption_text, "
					+ "dboard_common_trending_insta_post.standard_resolution, "
					+ "dboard_common_trending_insta_post.comments_count, "
					+ "dboard_common_trending_insta_post.likes_count, "
					+ "dboard_common_trending_insta_post.user_name ,"
					+ "dboard_common_trending_insta_post.user_img " +
					" FROM dboard_common_trending_insta_post " +joinQuery+" group by  dboard_common_trending_insta_post.media_id  order by (likes_count + comments_count) desc limit 10";

			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs : rows){
				DashOutputVo dashOutputVo=new DashOutputVo();
				dashOutputVo.setCreated_at(rs.get("created_time")==null?"":rs.get("created_time").toString());
				dashOutputVo.setText(rs.get("insta_caption_text")==null?"":rs.get("insta_caption_text").toString());
				dashOutputVo.setStandard_resolution(rs.get("standard_resolution")==null?"":rs.get("standard_resolution").toString());

				dashOutputVo.setComment_count(rs.get("comments_count")==null?"":rs.get("comments_count").toString());
				dashOutputVo.setLike_count(rs.get("likes_count")==null?"":rs.get("likes_count").toString());
				dashOutputVo.setUser_name(rs.get("user_name")==null?"":rs.get("user_name").toString());
				dashOutputVo.setUser_img(rs.get("user_img")==null?"":rs.get("user_img").toString());

				lst.add(dashOutputVo);
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}

		return lst;
	}

	//Top Trending Facebook
	@Override
	public ArrayList<FbOutputVo> dashTopTrendingFacebookPost(
			DashInputVo dashInputVo) {
		ArrayList<FbOutputVo> lst=new ArrayList<FbOutputVo>();
		try {
			String joinQuery=" inner join  tbl_case_entity ON tbl_case_entity.entity_id=fb_post.entity_id  "
					+ " where tbl_case_entity.case_id='"+dashInputVo.getCaseId().trim()+"' and "
					+ "  date_of_insertion >='"+CommonUtils.convertDateFormat(dashInputVo.getFromDate().trim())+"' "
					+ " AND date_of_insertion <='"+CommonUtils.convertDateFormat(dashInputVo.getToDate().trim())+"' ";
			String query=" SELECT  fb_post.entity_id,fb_post.post_id,fb_post.post_user_id,fb_post.post_user_name, "+
					" fb_post.post_share_count,fb_post.post_message,DATE_FORMAT(FROM_UNIXTIME(fb_post.post_createdtime),'%b %d, %Y %r') AS created_time,fb_post.post_link, "+
					" fb_post.page_id,fb_post.page_name,fb_post.post_like_count,fb_post.post_comment_count, "+
					" fb_post.sentiment,fb_post.post_type,DATE_FORMAT(FROM_UNIXTIME(fb_post.post_updated_time),'%b %d, %Y %r') AS updated_time,fb_post.post_picture,fb_post.link_name "+
					" FROM dboard_common_trending_fb_post as fb_post "+joinQuery+" group by fb_post.post_id order by (post_like_count + post_comment_count) desc limit 10 " ;

			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs : rows){
				FbOutputVo fbOutputVo=new FbOutputVo();
				fbOutputVo.setPost_id(rs.get("post_id")==null?"":rs.get("post_id").toString());
				fbOutputVo.setPost_user_id(rs.get("post_user_id")==null?"":rs.get("post_user_id").toString());
				fbOutputVo.setPost_user_name(rs.get("post_user_name")==null?"":rs.get("post_user_name").toString());
				fbOutputVo.setPost_share_count(rs.get("post_share_count")==null?"":rs.get("post_share_count").toString());
				fbOutputVo.setPost_message(rs.get("post_message")==null?"":rs.get("post_message").toString());
				fbOutputVo.setPost_createdtime(rs.get("created_time")==null?"":rs.get("created_time").toString());
				fbOutputVo.setPost_link(rs.get("post_link")==null?"":rs.get("post_link").toString());
				fbOutputVo.setPage_id(rs.get("page_id")==null?"":rs.get("page_id").toString());
				fbOutputVo.setPageName(rs.get("page_name")==null?"":rs.get("page_name").toString());
				fbOutputVo.setPost_like_count(rs.get("post_like_count")==null?"":rs.get("post_like_count").toString());
				fbOutputVo.setPost_comment_count(rs.get("post_comment_count")==null?"":rs.get("post_comment_count").toString());
				fbOutputVo.setPost_type(rs.get("post_type")==null?"":rs.get("post_type").toString());
				fbOutputVo.setPost_updated_time(rs.get("updated_time")==null?"":rs.get("updated_time").toString());
				fbOutputVo.setPost_picture(rs.get("post_picture")==null?"":rs.get("post_picture").toString());
				fbOutputVo.setLink_name(rs.get("link_name")==null?"":rs.get("link_name").toString());
				lst.add(fbOutputVo);
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return lst;
	}


	//*************edited by pankaj*****************	

	public List<Dashboard> getDashboardByUserId(String userId)
	{
		ArrayList<Dashboard> list = new ArrayList<Dashboard>();
		try 
		{
			String sql = "SELECT * FROM tbl_dashboard WHERE created_by='"+userId+"' AND is_public=1";
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(sql);
			for(Map<String,Object> rs : rows)
			{
				Dashboard dashboard = new Dashboard();
				dashboard.setDashboardName(rs.get("dashboard_name")==null?"":rs.get("dashboard_name").toString());
				dashboard.setCreatedBy(rs.get("created_by")==null?"":rs.get("created_by").toString());		    	 
				dashboard.setIsPublic((Integer)rs.get("is_public"));
				dashboard.setCreationDate(rs.get("creation_date")==null?"":rs.get("creation_date").toString());

				list.add(dashboard);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return list;

	}


	public boolean removeDashboardById(Dashboard dashboard)
	{
		boolean flag = false;	
		try
		{
			String query="DELETE from tbl_dashboard WHERE id="+dashboard.getDashboardId()+" ";
			jdbcTemplate.update(query);
			flag = true;
		} 
		catch(Exception ex)
		{
			flag = false;
			ex.printStackTrace();
		} 
		return flag;
	}


	public boolean createDashboard(Dashboard dashboard)	{
		boolean flag = false;
		String query = null;
		try {
			String userName =(String)httpSession.getAttribute(ApplicationConstants.LOGINUSERID);
			//Object[] obj=new Object[]{dashboard.getDashboardName(),userName,dashboard.getIsPublic(),TwitterConstant.getSqlCurrentDateTime()};
			Object[] obj=new Object[]{dashboard.getDashboardName(),userName,dashboard.getIsPublic()};
			query="INSERT INTO tbl_dashboard(dashboard_name, created_by, is_public) values(?,?,?)";
			jdbcTemplate.update(query,obj);
			flag = true;
		} catch(Exception exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside LoginContoller Class createDashboard() :: EXCEPTION :: "+ exception);
			logger.error(CommonUtils.getCurrentTime()+ " Inside LoginContoller Class createDashboard() :: EXCEPTION SQL:: "+ query);
		}
		return flag;
	}

	public ArrayList<Dashboard> getAllDashboard(Dashboard dashboard)
	{
		ArrayList<Dashboard> list = new ArrayList<Dashboard>();
		try
		{
			String userId =(String)httpSession.getAttribute(ApplicationConstants.LOGINUSERID);
			String userType=(String)httpSession.getAttribute(ApplicationConstants.USERROLE);
			String subQuery="";
			if(!userType.toLowerCase().equals("a"))
			{
				subQuery+=" and tbl_dashboard.created_by='"+userId+"'";
			}
			subQuery+=" and tbl_dashboard.dashboard_name like '%"+dashboard.getDashboardName()+"%'";

			String sortQuery=" order by ";
			switch(dashboard.getSort())
			{
			case "dd":
				sortQuery+=" tbl_dashboard.creation_date desc ";
				break;
			case "da":
				sortQuery+=" tbl_dashboard.creation_date asc ";
				break;
			case "na":
				sortQuery+=" tbl_dashboard.dashboard_name asc  ";
				break;
			case "nd":
				sortQuery+=" tbl_dashboard.dashboard_name desc  ";
				break;
			}


			String sql="SELECT tbl_dashboard.id,tbl_dashboard.dashboard_name,tbl_dashboard.created_by,"
					+ " tbl_dashboard.is_public,COALESCE(DATE_FORMAT((tbl_dashboard.creation_date),'%b %d,%Y %r'),'') AS dateOfCreation,login_detail.user_logon_id FROM tbl_dashboard"
					+ " inner join login_detail on login_detail.id=tbl_dashboard.created_by"
					+ " where (1=1 "+subQuery +")"+
							//+ " or is_public=1 "+
					sortQuery;
			List<Map<String,Object>> empRows1 = jdbcTemplate.queryForList(sql);
			for (Map<String, Object> rs : empRows1) {
				Dashboard dashboardObj = new Dashboard();
				dashboardObj.setDashboardId(((Long)rs.get("id")).intValue());
				dashboardObj.setDashboardName(rs.get("dashboard_name")==null?"":rs.get("dashboard_name").toString());
				dashboardObj.setCreatedBy(rs.get("created_by")==null?"":rs.get("created_by").toString());		    	 
				dashboardObj.setIsPublic((Integer)rs.get("is_public"));
				dashboardObj.setCreationDate(rs.get("dateOfCreation")==null?"":rs.get("dateOfCreation").toString());
				dashboardObj.setCreatedByName(rs.get("user_logon_id")==null?"":rs.get("user_logon_id").toString());
				
				list.add(dashboardObj);
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return list;
	}

	public boolean updateDashboardById(Dashboard dashboard)
	{
		boolean flag = false;
		try
		{
			String query=" UPDATE tbl_dashboard "
					+ " set is_public="+dashboard.getIsPublic()+" WHERE id="+dashboard.getDashboardId();
			jdbcTemplate.update(query);
			flag = true;
		} 
		catch(Exception ex)
		{
			flag = false;
			ex.printStackTrace();
		}
		return flag;
	}

	@Override
	public boolean updateWidget(Widget widget)
	{
		boolean flag = false;
		try
		{
			String sql="UPDATE tbl_widget "
					+ " set widget_name='"+widget.getWidgetName()+"' , widget_description='"+widget.getWidgetDescription()+"' , creation_date='"+widget.getCreationDate()+"' , widget_category='"+widget.getWidgetCategory()+"' , widget_image_path='"+widget.getWidgetImagePath()+"'  WHERE id="+widget.getWidgetId()+" ";      
			jdbcTemplate.update(sql);
			flag = true;
		} 
		catch(Exception ex)
		{
			flag = false;
			ex.printStackTrace();
		}
		return flag;
	}



	@Override
	public ArrayList<Widget> getAllWidget(Widget widget)
	{
		ArrayList<Widget> list=new ArrayList<Widget>();
		try
		{
			String	subQuery=" and tbl_widget.widget_name like '%"+widget.getWidgetName()+"%'";
			switch (widget.getIsAdd()) {
			case "y": // add new widget to dashboard
				subQuery+=" and tbl_widget.id not in (select widget_id from tbl_dashboad_widget where dashboard_id='"+widget.getDashId()+"')";
				break;
			case "n":  //show all widgets of dashboard
				subQuery+=" and tbl_widget.id in (select widget_id from tbl_dashboad_widget where dashboard_id='"+widget.getDashId()+"')";
				break;
			default:
				break;
			}
			if(CommonUtils.stringNotEmpty(widget.getWidgetCategory()))
			{
				subQuery+=" and tbl_widget.widget_category in("+TwitterConstant.splitCommonValues(widget.getWidgetCategory())+")";
			}
			String sql = "SELECT * FROM tbl_widget where 1=1 and tbl_widget.isActive=1   " +subQuery;
			List<Map<String,Object>> empRows1 = jdbcTemplate.queryForList(sql);
			for (Map<String, Object> rs : empRows1) {
				Widget widgetObj = new Widget();
				widgetObj.setWidgetId(((Long)rs.get("id")).intValue());
				widgetObj.setWidgetName(rs.get("widget_name")==null?"":rs.get("widget_name").toString());
				widgetObj.setWidgetImagePath(rs.get("widget_image_path")==null?"":rs.get("widget_image_path").toString());
				widgetObj.setWidgetDescription(rs.get("widget_description")==null?"":rs.get("widget_description").toString());
				widgetObj.setWidgetCategory(rs.get("widget_category")==null?"":rs.get("widget_category").toString());
				list.add(widgetObj);
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return list;
	}


	@Override
	public void addWidgetsToDashboard(Dashboard dashboard) {
		try {
			ArrayList<String> lstWidgetsId=dashboard.getWidgetIds();
			for (String widgetId : lstWidgetsId) {
				String sql="insert ignore into tbl_dashboad_widget(dashboard_id,widget_id,date_of_creation) "
						+ " values('"+dashboard.getDashboardId()+"','"+widgetId+"','"+TwitterConstant.getSqlCurrentDateTime()+"')";
				jdbcTemplate.update(sql);
			}
		} catch(Exception ex) {
			ex.printStackTrace();
		}
	}

	@Override
	public void removeWidgetsFromDashboard(Dashboard dashboard) {
		try
		{
				String sql=" delete from tbl_dashboad_widget where dashboard_id='"+dashboard.getDashboardId()+"' and widget_id='"+dashboard.getWidgetId()+"' ";
				jdbcTemplate.update(sql);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}


	@Override
	public List<DashboardWidgetVo> getWidgetsByDashboardId(Long dashboardId) {
		ArrayList<DashboardWidgetVo> list=new ArrayList<DashboardWidgetVo>();
		String query="SELECT dw.id AS dashboard_widget_id,dw.dashboard_id, dw.widget_id, dw.widget_x, dw.widget_y, d.dashboard_name,d.is_public, w.widget_name, w.widget_description, w.widget_category, w.widget_image_path, w.widget_code, w.width, w.height FROM tbl_dashboad_widget dw JOIN tbl_dashboard d ON d.id = dw.dashboard_id JOIN tbl_widget w ON w.id = dw.widget_id WHERE w.isActive='1' and dw.dashboard_id="+dashboardId;
		
		try {
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for (Map<String, Object> rs : rows) {
				DashboardWidgetVo vo = new DashboardWidgetVo();
				long dashboardWidgetId = (Long)rs.get("dashboard_widget_id");
				//int dashboardId = (Long)rs.get("dashboard_id");
				long widgetId = (Long)(rs.get("widget_id")==null ? -1:rs.get("widget_id"));
				int widgetX= (Integer)(rs.get("widget_x")==null ? -1:rs.get("widget_x"));
				int widgetY= (Integer)(rs.get("widget_y")==null ? -1:rs.get("widget_y"));
				String dashboardName= (String)rs.get("dashboard_name");
				int isPublic= (Integer)rs.get("is_public");
				String widgetName= (String)rs.get("widget_name");
				String widgetDescription= (String)(rs.get("widget_description")==null ? "":rs.get("widget_description"));
				String widgetCategory= (String)rs.get("widget_category");
				String widgetImagePath= (String)(rs.get("widget_image_path")==null ? "":rs.get("widget_image_path"));
				String widgetCode= (String)rs.get("widget_code");
				int width= (Integer)(rs.get("width")==null ? -1:rs.get("width"));
				int height= (Integer)(rs.get("height")==null ? -1:rs.get("height"));
				
				vo.setDashboardWidgetId(dashboardWidgetId);
				vo.setDashboardId(dashboardId);
				vo.setWidgetId(widgetId);
				vo.setWidgetX(widgetX);
				vo.setWidgetY(widgetY);
				vo.setDashboardName(dashboardName);
				vo.setDashboardIsPublic(isPublic);
				vo.setWidgetName(widgetName);
				vo.setWidgetDescription(widgetDescription);
				vo.setWidgetCategory(widgetCategory);
				vo.setWidgetImagePath(widgetImagePath);
				vo.setWidgetCode(widgetCode);
				vo.setWidgetWidth(width);
				vo.setWidgetHeight(height);
				list.add(vo);
			}
		} catch(Exception ex) {
			ex.printStackTrace();
		}
		return list;
	}
	
	@Override
	public int updateWidgetDashboard(List<DashboardWidgetVo> list) throws Exception 
	{
		String query="update tbl_dashboad_widget set widget_x=?,widget_y=? where dashboard_id=? and widget_id=?";
		int rows = -1;
		try
		{
			for(DashboardWidgetVo item:list)
			{
				long x = item.getWidgetX();
				long y = item.getWidgetY();
				long dashboardId = item.getDashboardId();
				long widgetId = item.getWidgetId();				
				rows = jdbcTemplate.update(query, new Object[] {x, y, dashboardId, widgetId}); 
			}
		}
		catch(Exception e)
		{
			rows = -1;
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}
		return rows;		
	}
	
	@Override
	public int deleteWidgetDashboard(List<DashboardWidgetVo> list) throws Exception
	{
		String query="delete from tbl_dashboad_widget where dashboard_id=? and widget_id=?";
		int rows = -1;
		try
		{
			for(DashboardWidgetVo item:list)
			{
				long dashboardId = item.getDashboardId();
				long widgetId = item.getWidgetId();
				rows = jdbcTemplate.update(query, new Object[] {dashboardId, widgetId}); 
			}
		}
		catch(Exception e)
		{
			rows = -1;
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}
		return rows;
	}


	@Override
	public int addWidgetDashboard(List<DashboardWidgetVo> list) throws Exception 
	{
		String query = "INSERT INTO tbl_dashboad_widget(dashboard_id,widget_id,date_of_creation,widget_x,widget_y) VALUES(?,?,current_timestamp(),?,?);";
		int rows = -1;
		try
		{
			for(DashboardWidgetVo item:list)
			{
				rows = jdbcTemplate.update(query, new Object[] { item.getDashboardId(), item.getWidgetId(), item.getWidgetX(), item.getWidgetY()});
			}
		}
		catch(Exception e)
		{
			rows = -1;
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}
		return rows;
	}	
	
	@Override
	public List<DashboardWidgetVo> getAllDashboard()
	{
		String userName =(String)httpSession.getAttribute(ApplicationConstants.LOGINUSERID);
		ArrayList<DashboardWidgetVo> list=new ArrayList<DashboardWidgetVo>();
		String query="SELECT DISTINCT(d.id) as dashboard_id, d.dashboard_name,d.is_public FROM tbl_dashboard d JOIN login_detail l ON l.id = d.created_by WHERE l.id='"+userName+"' or d.is_public=1";
		try
		{
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for (Map<String, Object> rs : rows) {
				DashboardWidgetVo vo = new DashboardWidgetVo();
				
				long dashboardId = (Long)rs.get("dashboard_id");
				String dashboardName= (String)rs.get("dashboard_name");
				int isPublic= (Integer)rs.get("is_public");
				
				vo.setDashboardId(dashboardId);
				vo.setDashboardName(dashboardName);
				vo.setDashboardIsPublic(isPublic);

				list.add(vo);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return list;
	}


	@Override
	public void markCurrentDashboard(String dashboardId,String caseId) {
		try
		{
			String loginId =(String)httpSession.getAttribute(ApplicationConstants.LOGINUSERID);
			String query="delete from tbl_dashboard_current_user where login_id='"+loginId+"' and case_id='"+caseId+"'";
			jdbcTemplate.execute(query);
			
			query="INSERT ignore INTO tbl_dashboard_current_user(login_id,dash_id,case_id) values('"+loginId+"','"+dashboardId+"','"+caseId+"')";
			jdbcTemplate.update(query);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	public ArrayList<Dashboard> getUserCurrentDashboard(String caseId)
	{
		ArrayList<Dashboard> list = new ArrayList<Dashboard>();
		try
		{
			String userId =(String)httpSession.getAttribute(ApplicationConstants.LOGINUSERID);
			String sql="SELECT login_id,dash_id,tbl_dashboard.dashboard_name from tbl_dashboard_current_user inner join  tbl_dashboard "
					+ " on tbl_dashboard.id=tbl_dashboard_current_user.dash_id where login_id='"+userId+"' and case_id='"+caseId+"'";
			List<Map<String,Object>> empRows1 = jdbcTemplate.queryForList(sql);
			for (Map<String, Object> rs : empRows1) 
			{
				Dashboard dashboardObj = new Dashboard();
				dashboardObj.setDashboardId(((Integer)rs.get("dash_id")));
				dashboardObj.setDashboardName(rs.get("dashboard_name").toString());
				list.add(dashboardObj);
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return list;
	}
	
	
	
	
	
	
}