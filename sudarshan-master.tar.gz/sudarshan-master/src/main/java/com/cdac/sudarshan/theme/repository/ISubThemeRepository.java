package com.cdac.sudarshan.theme.repository;

import com.cdac.sudarshan.theme.model.SubTheme;
import com.cdac.sudarshan.theme.model.Theme;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ISubThemeRepository extends JpaRepository<SubTheme, Long> {

    List<SubTheme> findByTheme(Theme theme);

    @Query(value = "select s from SubTheme s where s.subThemePath =:subThemePath")
    SubTheme findBySubThemePath(@Param(value = "subThemePath") String subThemePath);

    @Query(nativeQuery = true, value = "select * from sub_themes as s where s.sub_theme_path = :sub_theme_path and s.theme_id = :theme_id")
    SubTheme findBySubThemePathAndRootThemeId(@Param("sub_theme_path") String sub_theme_path, @Param("theme_id") Long theme_id);

    @Query(value = "select s from SubTheme s where s.subThemePath =:subThemePath")
    List<SubTheme> fetchBySubThemePath(@Param(value = "subThemePath") String subThemePath);

    List<SubTheme> findByParentSubThemeId(Long id);


}
