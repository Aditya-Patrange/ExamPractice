package com.cdac.sudarshan.folder.model;

import lombok.*;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class RequestDto {

    private List<String> urls;
}
