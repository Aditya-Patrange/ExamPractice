package com.cdac.sudarshan.theme.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class SubThemeDto {

    private Long id;
    private String subThemePath;
    @JsonIgnore
    private ThemeDto theme;
    @JsonIgnore
    private Long parentSubThemeId;
    private LocalDateTime creationDate;
    private LocalDateTime lastUpdatedDate;
    @JsonIgnore
    private List<KeywordDto> dataList = new ArrayList<>();


}
