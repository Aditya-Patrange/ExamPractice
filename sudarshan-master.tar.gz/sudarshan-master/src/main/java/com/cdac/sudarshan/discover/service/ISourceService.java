package com.cdac.sudarshan.discover.service;

import java.util.HashMap;
import java.util.List;

import com.cdac.sudarshan.discover.model.Trends;
import com.cdac.sudarshan.theme.dto.ThemeDto;
import com.cdac.sudarshan.theme.dto.ThemesDto;
import org.springframework.http.ResponseEntity;

import com.cdac.sudarshan.discover.dto.BaseEntityDto;
import com.cdac.sudarshan.discover.dto.DiscoverSubSourceDto;
import com.cdac.sudarshan.discover.model.Country;
import com.cdac.sudarshan.discover.model.DiscoverSources;
import com.cdac.sudarshan.discover.model.DiscoverSubSources;
import com.cdac.sudarshan.discover.projection.DiscoverSubSourcesProjection;

public interface ISourceService {

    public List<DiscoverSources> getSourceList();

    public List<DiscoverSubSourcesProjection> getSubSourceList(BaseEntityDto baseEntityDto);

    public ResponseEntity<?> searchEntity(HashMap<String, Object> data);

    public ResponseEntity<?> getLink(HashMap<String, Object> data);

    public ResponseEntity<?> getMentions(HashMap<String, Object> data);

    public ResponseEntity<?> getThemes(HashMap<String, Object> data);

    public ResponseEntity<?> getTweetGraph(HashMap<String, Object> data);

    public ResponseEntity<?> getHashtagWordCloud(HashMap<String, Object> data);

    public ResponseEntity<?> getMentionWordCloud(HashMap<String, Object> data);

    public ResponseEntity<?> getPersonWordCloud(HashMap<String, Object> data);

    public List<DiscoverSubSourcesProjection> getSubSourceAllList();

    public List<Country> getCountryList();

    public ResponseEntity<?> listCollection(HashMap<String, Object> data);

    public ResponseEntity<?> searchByName(HashMap<String, Object> data);

    public ResponseEntity<?> addNewCollectionForProfile(HashMap<String, Object> data);

    public ResponseEntity<?> updateCollectionPausedStatusById(HashMap<String, Object> data);

    public ResponseEntity<?> deleteCollection(HashMap<String, Object> data);

    public ResponseEntity<?> getCollectionById(HashMap<String, Object> data);

    public ResponseEntity<?> getTweetDetailById(HashMap<String, Object> data);

    public ResponseEntity<?> getTweetsUserLocation(HashMap<String, Object> data);

    public ResponseEntity<?> selectAllMaster(HashMap<String, Object> data);

    public ResponseEntity<?> geoTweetsLatLong(HashMap<String, Object> data);

    public ResponseEntity<?> updateNewCollectionById(HashMap<String, Object> data);

    public ResponseEntity<?> getTweetsUsrDtlRpt(HashMap<String, Object> data);

    public ResponseEntity<?> userDetailReportFollowers(HashMap<String, Object> data);

    public ResponseEntity<?> userDetailReportFollowing(HashMap<String, Object> data);

    public ResponseEntity<?> getHashTagsUsrDtlRpt(HashMap<String, Object> data);

    public ResponseEntity<?> getMentionUsrDtlRpt(HashMap<String, Object> data);

    public ResponseEntity<?> userTopRetweet(HashMap<String, Object> data);

    public ResponseEntity<?> userTopReply(HashMap<String, Object> data);

    public ResponseEntity<?> userTopSource(HashMap<String, Object> data);

    public ResponseEntity<?> getTimeLineDayOfWeek(HashMap<String, Object> data);

    public ResponseEntity<?> getTimeLineDayOfHour(HashMap<String, Object> data);

    public ResponseEntity<?> getTweetGraphUsrDtlRpt(HashMap<String, Object> data);

    public ResponseEntity<?> gettweetStatsOffLine(HashMap<String, Object> data);

    public ResponseEntity<Object> getProfileSearchDataDmFbYtInsTmLiRedTw(HashMap<String, Object> data);

    public ResponseEntity<Object> getProfileSearchDataCount(HashMap<String, Object> data);

    public ResponseEntity<Object> listKeywordOfCollection(HashMap<String, Object> data);

    public List<Trends> getTrendsList();

    public ResponseEntity<?> getPhoneCode(String countryCode);

    public HashMap<String, Object> addThemeCollection();

    public List<ThemeDto> getThemeTag();
}