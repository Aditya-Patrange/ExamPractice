package com.cdac.sudarshan.discover.common;

import java.io.Serializable;

public class UserProfileAssociatedHandlesVo implements Serializable
{
	private static final long serialVersionUID = 1L;
	
	private int handlesId;
	private int profileId;
	private String userId;
	private String userName;
	private String userScreenName;
	private String classification;
	private String photo;
	private String socialMediaType;
	
	public int getHandlesId() 
	{
		return handlesId;
	}
	public void setHandlesId(int handlesId) 
	{
		this.handlesId = handlesId;
	}
	public int getProfileId() 
	{
		return profileId;
	}
	public void setProfileId(int profileId)
	{
		this.profileId = profileId;
	}
	public String getUserId() 
	{
		return userId;
	}
	public void setUserId(String userId)
	{
		this.userId = userId;
	}
	public String getUserName() 
	{
		return userName;
	}
	public void setUserName(String userName) 
	{
		this.userName = userName;
	}
	public String getUserScreenName()
	{
		return userScreenName;
	}
	public void setUserScreenName(String userScreenName) 
	{
		this.userScreenName = userScreenName;
	}
	public String getClassification() 
	{
		return classification;
	}
	public void setClassification(String classification)
	{
		this.classification = classification;
	}
	public String getPhoto() 
	{
		return photo;
	}
	public void setPhoto(String photo) 
	{
		this.photo = photo;
	}
	public String getSocialMediaType() 
	{
		return socialMediaType;
	}
	public void setSocialMediaType(String socialMediaType) 
	{
		this.socialMediaType = socialMediaType;
	}
	public static long getSerialversionuid()
	{
		return serialVersionUID;
	}
	
	@Override
	public String toString() 
	{
		return "UserProfileAssociatedHandlesVo [handlesId=" + handlesId + ", profileId=" + profileId + ", userId="
				+ userId + ", userName=" + userName + ", userScreenName=" + userScreenName + ", classification="
				+ classification + ", photo=" + photo + ", socialMediaType=" + socialMediaType + "]";
	}
	
}
