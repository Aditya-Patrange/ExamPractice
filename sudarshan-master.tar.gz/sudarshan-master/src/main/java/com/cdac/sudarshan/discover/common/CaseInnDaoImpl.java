package com.cdac.sudarshan.discover.common;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.springframework.web.multipart.MultipartFile;

import com.cdac.sudarshan.discover.model.TweeterActionVo;
import com.google.gson.Gson;

import com.opencsv.CSVWriter;

import io.searchbox.client.JestClient;
import io.searchbox.core.Search;
import io.searchbox.core.SearchResult;

@Repository
public class CaseInnDaoImpl implements CaseInnDao {
	private Gson gson = new Gson();
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
		
	@Autowired
	private PlatformTransactionManager transactionManager;
	public void setTransactionManager(PlatformTransactionManager transactionManager) {
		this.transactionManager = transactionManager;
	}

	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	@Autowired 
	private HttpSession httpSession;	
	

	private TwitterConstant twitterConstant;	
	Logger logger = Logger.getRootLogger();
	Logger log = Logger.getRootLogger();

	@Autowired
	JestClient client;
	@Autowired
	private CommonUtils commonUtils;
	
	@Override
	public ArrayList<CaseVo> caseCrud(CaseVo caseVo){
		ArrayList<CaseVo> lst=new ArrayList<CaseVo>();
		String  sqlQuery=null;
		Object[] obj=null;
		
		try {
			if(caseVo.getActType().toLowerCase().trim().equals("delete")){
				if(caseVo.getCaseType().toLowerCase().trim().equals("a"))  { //Analysis
					sqlQuery= " DELETE FROM tbl_case_profile WHERE snapshot_id IN (SELECT tbl_save_filter.id FROM tbl_save_filter WHERE case_id=?);";
					obj=new Object[]{caseVo.getCaseId()};
					jdbcTemplate.update(sqlQuery,obj);

					sqlQuery= " DELETE FROM tbl_save_filter WHERE case_id=? " ;
					obj=new Object[]{caseVo.getCaseId()};
					jdbcTemplate.update(sqlQuery, obj);

					sqlQuery= " DELETE FROM tbl_case where id=?  " ;
					obj=new Object[]{caseVo.getCaseId()};
					jdbcTemplate.update(sqlQuery, obj);
				} else {
					sqlQuery= " DELETE FROM tbl_case where id=?  " ;
					obj=new Object[]{caseVo.getCaseId()};
					jdbcTemplate.update(sqlQuery,obj);

					sqlQuery= " DELETE FROM tbl_case_entity where case_id=? " ;
					obj=new Object[]{caseVo.getCaseId()};
					jdbcTemplate.update(sqlQuery,obj);
				}
			}
		} catch(Exception exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class caseCrud() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class caseCrud() :: EXCEPTION :: "+ exception);
		} 
		return lst;
	}
	
	@Override
	public LoginDetails validateUser(String userName, String password) {
		LoginDetails loginDetails=null;
	    int currentConn=0;
		int maximumConn=5;
		String loginLimitFlag="no";
		String sqlQuery = null;
		try {
			if(CommonUtils.stringNotEmpty(userName) && CommonUtils.stringNotEmpty(password)) {
				sqlQuery = "SELECT * FROM login_detail WHERE user_logon_id='"+userName.trim()+"'";
				List<Map<String, Object>> empRows2 = jdbcTemplate.queryForList(sqlQuery);
				
				if(empRows2.size()==0) {
					loginDetails=new LoginDetails();
					loginDetails.setMsg("User Name is incorrect.");
				} else {
					sqlQuery = " SELECT current_connections, maximum_connections, innsightUserLimitFlag FROM login_concurrent_user_info WHERE product='innsight' AND innsightUserLimitFlag='yes'";
					List<Map<String, Object>> empRows1 = jdbcTemplate.queryForList(sqlQuery);
					
					if(empRows1.size()>0) {
						for(Map<String, Object> row : empRows1) {
							currentConn=(Integer)row.get("current_connections");
							maximumConn=(Integer)row.get("maximum_connections");
							loginLimitFlag=row.get("innsightUserLimitFlag")==null?"no":row.get("innsightUserLimitFlag").toString();
						}
					}
					sqlQuery = "SELECT * FROM login_detail WHERE user_logon_id= BINARY '"+userName.trim()+"' and password= BINARY '"+password.trim()+"' ";
					List<Map<String, Object>> empRows = jdbcTemplate.queryForList(sqlQuery);
					
					if(empRows.size()>0){
						for(Map<String, Object> empRow : empRows){
							if(loginLimitFlag.equals("no"))	{
								loginDetails=new LoginDetails(empRow.get("user_logon_id")==null?"":empRow.get("user_logon_id").toString(), empRow.get("password")==null?"":empRow.get("password").toString(), empRow.get("role")==null?"":empRow.get("role").toString(), empRow.get("template_id")==null?"":empRow.get("template_id").toString(), empRow.get("id")==null?"":empRow.get("id").toString());
							} else if(loginLimitFlag.equals("yes"))	{
								if(maximumConn > currentConn) {
									loginDetails=new LoginDetails(empRow.get("user_logon_id").toString(), empRow.get("password").toString(), empRow.get("role").toString(), empRow.get("template_id").toString(), empRow.get("id").toString());
									currentConn=currentConn+1;
									sqlQuery ="UPDATE login_concurrent_user_info SET current_connections='"+currentConn+"' WHERE product='innsight' AND innsightUserLimitFlag='yes'";
									jdbcTemplate.update(sqlQuery);
								} else {
									loginDetails=new LoginDetails();
									loginDetails.setMsg("Maximum concurrent session limit reached. Please contact the administrator");
								}
							}
						}
					} else {
						loginDetails=new LoginDetails();
						loginDetails.setMsg("Invalid credentials. Please try again.");
					}
				}
			}
		} catch(Exception exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class validateUser() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class validateUser() :: EXCEPTION :: "+ exception);
		}
		return loginDetails;
	}


	//@Override
	@SuppressWarnings("unused")
	public void entityCurd123(CaseVo caseVo) {
		String userId=(String)httpSession.getAttribute(ApplicationConstants.LOGINUSERID);
		String sqlQuery=null;
		Object[] obj=null;
		try {
			if(caseVo.getActType().toLowerCase().trim().equals("new")) {
				int caseId=0;
				if(CommonUtils.stringNotEmpty(caseVo.getCaseName())) {
					//Create Case
					sqlQuery="insert ignore into tbl_case(case_name,date_of_creation,login_id,case_type)values(?,?,?,?)";
					obj=new Object[]{
							CommonUtils.removeSpaceFromTxt(caseVo.getCaseName().trim()),
							CommonUtils.getSqlCurrentDateTime(),userId,caseVo.getCaseType().trim()};
					jdbcTemplate.update(sqlQuery, obj);

					//case_entity
					caseId=jdbcTemplate.queryForObject("select id from tbl_case where case_name=? and login_id=? and case_type=?",new Object[]{CommonUtils.removeSpaceFromTxt(caseVo.getCaseName().trim()),userId,caseVo.getCaseType().trim()},Integer.class);
					if(caseId>0) {
						sqlQuery="delete from tbl_case_entity where case_id=?";
						obj=new Object[]{caseId};
						jdbcTemplate.update(sqlQuery, obj);
					}
				}
				
				for(EntityVo entityVo : caseVo.getLstEntityVos()) {
					if(CommonUtils.stringNotEmpty(entityVo.getEntityName())) {
						boolean isFlag=true;
						//check for existing entity
						if( (entityVo.getEntityType().toLowerCase().equals("p") || entityVo.getEntityType().toLowerCase().equals("l")) && (entityVo.getEntitySourceType().toLowerCase().equals("tw") || entityVo.getEntitySourceType().toLowerCase().equals("fb") || entityVo.getEntitySourceType().toLowerCase().equals("insta") || entityVo.getEntitySourceType().toLowerCase().equals("yt")
								|| entityVo.getEntitySourceType().toLowerCase().equals("gp") || entityVo.getEntitySourceType().toLowerCase().equals("dm")
								|| entityVo.getEntitySourceType().toLowerCase().equals("gb") || entityVo.getEntitySourceType().toLowerCase().equals("tm")
								)) {
							int countId=jdbcTemplate.queryForObject("select count(*) from  tbl_entity where  entity_type=? and entity_source_type=? and entity_id=?",new Object[]{entityVo.getEntityType().trim(),entityVo.getEntitySourceType().trim(),entityVo.getEntitySocialId().trim()}, Integer.class);
							if(countId>0) {
								isFlag=false;
							}
						} else if(entityVo.getEntityType().toLowerCase().equals("k") && ( entityVo.getEntitySourceType().toLowerCase().equals("insta") || entityVo.getEntitySourceType().toLowerCase().equals("yt")
								|| entityVo.getEntitySourceType().toLowerCase().equals("gp") || entityVo.getEntitySourceType().toLowerCase().equals("dm")|| entityVo.getEntitySourceType().toLowerCase().equals("google")
								|| entityVo.getEntitySourceType().toLowerCase().equals("tm") || entityVo.getEntitySourceType().toLowerCase().equals("wp")
								||  entityVo.getEntitySourceType().toLowerCase().equals("fb") ||  entityVo.getEntitySourceType().toLowerCase().equals("wb")
								)) { //check for existing entity for keyword
							int countId=jdbcTemplate.queryForObject("select count(*) from  tbl_entity where entity_name=? and entity_type=? and entity_source_type=? ",new Object[]{CommonUtils.removeSpaceFromTxt(entityVo.getEntityName().trim()),entityVo.getEntityType().trim(),entityVo.getEntitySourceType().trim()}, Integer.class);
							if(countId>0) {
								isFlag=false;
							}
						}

						sqlQuery= " insert ignore into tbl_entity(entity_name,entity_id,entity_stats,entity_type,entity_source_type,entity_url,date_of_creation,entity_img,tw_id,fbtype,yttype) values(?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY update activation_flag=1 ";
						obj=new Object[]{CommonUtils.removeSpaceFromTxt(entityVo.getEntityName().trim()),entityVo.getEntitySocialId().trim(),entityVo.getEntityStats().trim(),entityVo.getEntityType().trim(),
								entityVo.getEntitySourceType().trim(),entityVo.getEntityUrl().trim(),CommonUtils.getSqlCurrentDateTime(),entityVo.getEntityImg().trim(),entityVo.getTwId(),
								entityVo.getFbType().trim(),entityVo.getYtType().trim()	};
						
						jdbcTemplate.update(sqlQuery, obj);

						String tweetUserId1="";
						if(CommonUtils.stringNotEmpty(caseVo.getCaseName())) {
							String entityIdFb="0";
							String entityIdFbPageName="";
							String ytType="0",fbType="0";

							int entityId=0;
							List<Map<String,Object>> rows = jdbcTemplate.queryForList("select id,entity_id,tw_id,entity_name,ytType,fbType from tbl_entity where entity_name=? and entity_type=? and entity_source_type=?",new Object[]{CommonUtils.removeSpaceFromTxt(entityVo.getEntityName().trim()),entityVo.getEntityType().trim(),entityVo.getEntitySourceType().trim()});
							for(Map<String,Object> rs :rows) {
								entityId=Integer.parseInt(rs.get("id").toString());
								tweetUserId1=rs.get("tw_id")==null?"":rs.get("tw_id").toString();
								entityIdFb=(rs.get("entity_id")==null?"":rs.get("entity_id").toString());
								entityIdFbPageName=(rs.get("entity_name")==null?"":rs.get("entity_name").toString());
								ytType=rs.get("ytType")==null?"0":rs.get("ytType").toString();
								fbType=rs.get("fbType")==null?"0":rs.get("fbType").toString();
							}

							//case_entity
							if(caseId>0) {
								sqlQuery="insert ignore into tbl_case_entity(case_id,entity_id)values(?,?)";
								obj=new Object[]{caseId,entityId};
								jdbcTemplate.update(sqlQuery, obj);
							}

							//Insert into twitter_extract_data for Follower,Following,Last 3200 tweets
							if(entityVo.getEntityType().toLowerCase().equals("p") && entityVo.getEntitySourceType().toLowerCase().equals("tw")) {  
								if(isFlag) {
									sqlQuery="insert ignore into twitter_extract_data(userId,type)values(?,?)";
									obj=new Object[]{tweetUserId1,"FW"};
									jdbcTemplate.update(sqlQuery, obj);

									sqlQuery="insert ignore into twitter_extract_data(userId,type)values(?,?)";
									obj=new Object[]{tweetUserId1,"FO"};
									jdbcTemplate.update(sqlQuery, obj);

									sqlQuery="insert ignore into twitter_extract_data(userId,type)values(?,?)";
									obj=new Object[]{tweetUserId1,"TW"};
									jdbcTemplate.update(sqlQuery, obj);

									sqlQuery="insert ignore into twitter_extract_data(userId,type)values(?,?)";
									obj=new Object[]{tweetUserId1,"FAV"};
									jdbcTemplate.update(sqlQuery, obj);
								}
							} else if(entityVo.getEntityType().toLowerCase().equals("p") && entityVo.getEntitySourceType().toLowerCase().equals("fb") )	{ 	//Insert into fb_crawl_status
								if(isFlag) {
									if(entityVo.getFbType().equals("0")) {
										sqlQuery="insert ignore into fb_crawl_status(page_id,work_type,page_date,page_name)values(?,?,?,?)";
										obj=new Object[]{entityIdFb,"info",TwitterConstant.GetFbPageToCrawleDate(),entityIdFbPageName};
										jdbcTemplate.update(sqlQuery,obj);

										sqlQuery="insert ignore into fb_crawl_status(page_id,work_type,page_date,page_name)values(?,?,?,?)";
										obj=new Object[]{entityIdFb,"insight",TwitterConstant.GetFbPageToCrawleDate(),entityIdFbPageName};
										jdbcTemplate.update(sqlQuery,obj);

										sqlQuery="insert ignore into fb_crawl_status(page_id,work_type,page_date,page_name)values(?,?,?,?)";
										obj=new Object[]{entityIdFb,"like",TwitterConstant.GetFbPageToCrawleDate(),entityIdFbPageName};
										jdbcTemplate.update(sqlQuery,obj);

										sqlQuery="insert ignore into fb_crawl_status(page_id,work_type,page_date,page_name)values(?,?,?,?)";
										obj=new Object[]{entityIdFb,"post",TwitterConstant.GetFbPageToCrawleDate(),entityIdFbPageName};
										jdbcTemplate.update(sqlQuery,obj);
									} else {
										sqlQuery="insert ignore into fb_crawl_sele_profile_status(entity_id,user_id,user_name)values(?,?,?)";
										obj=new Object[]{entityId,entityIdFb,entityIdFbPageName};
										jdbcTemplate.update(sqlQuery,obj);
									}
								}
							} else if(entityVo.getEntityType().toLowerCase().equals("k") && entityVo.getEntitySourceType().toLowerCase().equals("fb") ) { //Insert into fb_crawl_status_event
								if(isFlag) {
									sqlQuery="insert ignore into fb_crawl_status_event(entity_id)values(?)";
									obj=new Object[]{entityId};
									jdbcTemplate.update(sqlQuery,obj);
								}
							} else if(entityVo.getEntitySourceType().toLowerCase().equals("insta"))	{ //Insert into insta_crawl_status
								if(isFlag) {
									switch(entityVo.getEntityType().toLowerCase()) {
									case "k":
										sqlQuery="insert ignore into insta_crawl_status(entity_id,profile_id,type,work_type,page_date)values(?,?,?,?,?)";
										obj=new Object[]{entityId,entityIdFbPageName,"k","keyword",TwitterConstant.GetInstaToCrawleDate()};
										jdbcTemplate.update(sqlQuery,obj);
										break;
										
									case "p":
										sqlQuery="insert ignore into insta_crawl_status(entity_id,profile_id,type,work_type,page_date)values(?,?,?,?,?)";
										obj=new Object[]{entityId,entityIdFb,"p","post",TwitterConstant.GetInstaToCrawleDate()};
										jdbcTemplate.update(sqlQuery,obj);

										sqlQuery="insert ignore into insta_crawl_status(entity_id,profile_id,type,work_type,page_date)values(?,?,?,?,?)";
										obj=new Object[]{entityId,entityIdFb,"p","fo",TwitterConstant.GetInstaToCrawleDate()};
										jdbcTemplate.update(sqlQuery,obj);

										sqlQuery="insert ignore into insta_crawl_status(entity_id,profile_id,type,work_type,page_date)values(?,?,?,?,?)";
										obj=new Object[]{entityId,entityIdFb,"p","fw",TwitterConstant.GetInstaToCrawleDate()};
										jdbcTemplate.update(sqlQuery,obj);
										break;
									}
								}
							} else if(entityVo.getEntitySourceType().toLowerCase().equals("yt")){ //Insert into Yt_crawl_status
								if(isFlag) {
									sqlQuery="insert ignore into yt_crawl_status(entity_id,page_date,before_date,after_date)values(?,?,?,?)";
									obj=new Object[]{entityId,TwitterConstant.GetInstaToCrawleDate(),TwitterConstant.getYoutubeBeforeDateYYYYMMDD(),TwitterConstant.getYouTubeAfterDateYYYYMMDD()};
									jdbcTemplate.update(sqlQuery,obj);
								}
							} else if(entityVo.getEntitySourceType().toLowerCase().equals("wb") && entityVo.getEntityType().toLowerCase().equals("k")) {//Insert into web_rss_crawl_status
								if(isFlag) {
									sqlQuery="insert ignore into web_rss_crawl_status(entity_id,last_date_of_updation)values(?,?)";
									obj=new Object[]{entityId,TwitterConstant.GetNewsToCrawleDate()};
									jdbcTemplate.update(sqlQuery,obj);
								}
							} else if(entityVo.getEntitySourceType().toLowerCase().equals("google") && entityVo.getEntityType().toLowerCase().equals("k")) { //Insert into web_crawl_status
								if(isFlag) {
									sqlQuery="insert ignore into web_crawl_status(entity_id, last_date_of_updation)values(?,?)";
									obj=new Object[]{entityId,TwitterConstant.getSqlCurrentDateTime()};
									jdbcTemplate.update(sqlQuery,obj);
								}
							} else if(entityVo.getEntitySourceType().toLowerCase().equals("gp")) {//Insert into gp_crawl_status
								if(isFlag) {
									sqlQuery="insert ignore into gp_crawl_status(entity_id,page_date)values(?,?)";
									obj=new Object[]{entityId,TwitterConstant.GetGpToCrawleDate()};
									jdbcTemplate.update(sqlQuery,obj);
								}
							} else if(entityVo.getEntitySourceType().toLowerCase().equals("dm")) { //Insert into dm_crawl_status
								if(isFlag) {
									sqlQuery="insert ignore into dm_crawl_status(entity_id,page_date)values(?,?)";
									obj=new Object[]{entityId,TwitterConstant.GetGpToCrawleDate()};
									jdbcTemplate.update(sqlQuery,obj);
								}
							} else if(entityVo.getEntitySourceType().toLowerCase().equals("wp") && entityVo.getEntityType().toLowerCase().equals("k")) {//Insert into wp_crawl_status
								if(isFlag) {
									sqlQuery="insert ignore into wp_crawl_status(entity_id)values(?)";
									obj=new Object[]{entityId};
									jdbcTemplate.update(sqlQuery,obj);
								}
							} else if(entityVo.getEntitySourceType().toLowerCase().equals("gb") && entityVo.getEntityType().toLowerCase().equals("p")) { //Insert into gb_crawl_status
								if(isFlag) {
									sqlQuery="insert ignore into gb_crawl_status(entity_id)values(?)";
									obj=new Object[]{entityId};
									jdbcTemplate.update(sqlQuery,obj);
								}
							} else if(entityVo.getEntitySourceType().toLowerCase().equals("tm")) { //Insert into tm_crawl_status
								if(isFlag) {
									sqlQuery="insert ignore into tm_crawl_status(entity_id)values(?)";
									obj=new Object[]{entityId};
									jdbcTemplate.update(sqlQuery,obj);
								}
							}
						}
					}
				}
			} else if(caseVo.getActType().toLowerCase().trim().equals("removefromcase")) {
				sqlQuery= " delete from tbl_case_entity where case_id=? and entity_id=? " ;	
				obj=new Object[]{caseVo.getCaseId().trim(),caseVo.getEntityId().trim()};
				jdbcTemplate.update(sqlQuery,obj);
			} else if(caseVo.getActType().toLowerCase().trim().equals("removefromuser")) {
				sqlQuery= " delete from tbl_login_entity where login_id=? and entity_id=? " ;	
				obj=new Object[]{userId,caseVo.getEntityId().trim()};
				jdbcTemplate.update(sqlQuery,obj);
			} else if(caseVo.getActType().toLowerCase().trim().equals("entocase")) {
				if(CommonUtils.stringNotEmpty(caseVo.getCaseId()) && CommonUtils.stringNotEmpty(caseVo.getEntityId())) {
					String caseArry[]=caseVo.getCaseId().split(",");
					for (String cid : caseArry) {
						if(CommonUtils.stringNotEmpty(cid)) {
							sqlQuery="insert ignore into tbl_case_entity(case_id,entity_id)values(?,?)";
							obj=new Object[]{cid.trim(),caseVo.getEntityId().trim()};
							jdbcTemplate.update(sqlQuery,obj);
						}
					}
				}
			}
		} catch (Exception exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class entityCurd123() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class entityCurd123() :: EXCEPTION :: "+ exception);
		} 
	}

	
	@Override
	public ArrayList<EntityVo> entitySelect(CaseVo caseVo) {
		ArrayList<EntityVo> lst=new ArrayList<EntityVo>();
		Object[] obj=null;
		String subQuery="";
		String query ="	SELECT tbl_entity.entity_name, tbl_entity.entity_id, tbl_entity.entity_source_type, "
			    	+ " tbl_entity.entity_stats, tbl_entity.entity_type, tbl_entity.id, "
			    	+ " COALESCE(DATE_FORMAT((tbl_entity.date_of_creation),'%b %d,%Y %r'),'') as dateOfCreation, "
					+ " entity_img, tw_id, varifiedUserFlag, fbtype, twtype, cast(tbl_entity.activation_flag as char(2)) as activation_flag, "
					+ " cast(tbl_entity.suspended_flag as char(2)) as suspended_flag, "
					+ " cast(tbl_entity.pro_flag as char(2)) as pro_flag, tbl_entity.fb_delta as fbDelta " 
					+ " FROM tbl_entity ";
		try {
			if(CommonUtils.stringNotEmpty(caseVo.getFilter())) {
				subQuery+=" AND tbl_entity.entity_source_type in("+TwitterConstant.splitCommonValues(caseVo.getFilter())+")";
				
				//Suspended Entity
				if(TwitterConstant.searchValueInArray("se", caseVo.getFilter().split(",")))	{
					subQuery+=" AND tbl_entity.suspended_flag='1' ";
				}

				//Inactive Entity
				if(TwitterConstant.searchValueInArray("ie", caseVo.getFilter().split(",")))	{
					subQuery+=" AND tbl_entity.activation_flag='0' ";
				}

				//Prophecy Activate Entity
				if(TwitterConstant.searchValueInArray("iep", caseVo.getFilter().split(","))) {
					subQuery+=" AND tbl_entity.pro_flag='1' ";
				}

				String etype="";
				//Event Entity
				if(TwitterConstant.searchValueInArray("event", caseVo.getFilter().split(","))) {
					etype+="'k',";
				}

				//profile Entity
				if(TwitterConstant.searchValueInArray("profile", caseVo.getFilter().split(","))) {
					etype+="'p',";
				}

				//location Entity
				if(TwitterConstant.searchValueInArray("location", caseVo.getFilter().split(","))) {
					etype+="'l',";
				}
				
				if(!etype.isEmpty()) {
					etype=etype.substring(0, etype.length()-1);
					subQuery+=" AND tbl_entity.entity_type in("+etype+")";
				}
								
				// Active DeActive filter
				if(caseVo.getStatusType() != null && !caseVo.getStatusType().isEmpty())	{
					subQuery+=" AND tbl_entity.activation_flag = "+caseVo.getStatusType();
				}
				
				// Entity Type Filter // Entity, Profile, Location
				if(caseVo.getEntityType() != null && !caseVo.getEntityType().isEmpty()) {
					subQuery+=" AND tbl_entity.entity_type = '"+caseVo.getEntityType()+"' ";
				}
				
				// FB Type Filter // Profile, Page, Group
				if(caseVo.getFbType() != null && !caseVo.getFbType().isEmpty())	{
					subQuery+=" AND tbl_entity.entity_type='P' AND tbl_entity.entity_source_type='fb' AND tbl_entity.fbtype = '"+caseVo.getFbType()+"' ";
				}

				// Profile Country filter
				if(caseVo.getCountryCode() != null && !caseVo.getCountryCode().isEmpty()) {
					subQuery+=" AND tbl_entity.profileCountryCode = '"+caseVo.getCountryCode()+"' ";
				}
				
				// Profile Category filter
				if(caseVo.getCategoryName() != null && !caseVo.getCategoryName().isEmpty()) {
					subQuery+=" AND tbl_entity_profile_catagory.profile_catagory_id = '"+caseVo.getCategoryName()+"' ";
				}
			}
			
			if(!caseVo.getCaseId().trim().equals("0")) {
				subQuery+=" AND tbl_case_entity.case_id='"+caseVo.getCaseId().trim()+"'";	
			}

			if(!caseVo.getCategoryName().equals("")) {
				query+=" INNER JOIN tbl_entity_profile_catagory ON tbl_entity_profile_catagory.tbl_entity_id=tbl_entity.id ";
			}
			
			if(!caseVo.getCaseId().trim().equals("0")) {
				query+=" INNER JOIN tbl_case_entity ON tbl_case_entity.entity_id=tbl_entity.id ";	
			}
			
			query+= " WHERE ( tbl_entity.entity_name like ? OR tbl_entity.entity_id like ? )"+subQuery+" ORDER BY  ";
			
			switch(caseVo.getSort().toLowerCase()) {
			case "da": // date_of_creation asc
				query+=" tbl_entity.date_of_creation asc ";
				break;
				
			case "dd": // date_of_creation desc
				query+=" tbl_entity.date_of_creation desc ";
				break;
				
			case "na": // name asc
				query+="  tbl_entity.entity_name asc ";
				break;
				
			case "nd": // name desc
				query+="  tbl_entity.entity_name desc ";
				break;
			}
			
			query+=" LIMIT "+caseVo.getRowNum()+", 50";

			obj=new Object[]{"%"+caseVo.getEntitySearch().trim()+"%","%"+caseVo.getEntitySearch().trim()+"%"};
			List<Map<String, Object>> rows = jdbcTemplate.queryForList(query, obj);
			
			for(Map<String, Object> rs : rows) {
				lst.add(new EntityVo(rs.get("entity_name")==null?"":rs.get("entity_name").toString(), 
				rs.get("entity_id")==null?"":rs.get("entity_id").toString(),
				rs.get("entity_stats")==null?"":rs.get("entity_stats").toString(),
				rs.get("entity_type")==null?"":rs.get("entity_type").toString(),
				rs.get("entity_source_type")==null?"":rs.get("entity_source_type").toString(),
				rs.get("entity_url")==null?"":rs.get("entity_url").toString(),
				rs.get("id")==null?"":rs.get("id").toString(),
				rs.get("dateOfCreation")==null?"":rs.get("dateOfCreation").toString(),
				rs.get("entity_img")==null?"":rs.get("entity_img").toString(),
				rs.get("tw_id")==null?"":rs.get("tw_id").toString(),
				rs.get("fbtype")==null?"":rs.get("fbtype").toString(),	
				rs.get("activation_flag")==null?"0":rs.get("activation_flag").toString(),
				rs.get("suspended_flag")==null?"0":rs.get("suspended_flag").toString(),
				rs.get("pro_flag")==null?"0":rs.get("pro_flag").toString(),
				rs.get("fbdelta")==null?473040000:Integer.parseInt(rs.get("fbdelta").toString()),
				rs.get("place_name")==null?"":rs.get("place_name").toString(),
				rs.get("twtype")==null?"":rs.get("twtype").toString(),
				rs.get("varifiedUserFlag")==null?"":rs.get("varifiedUserFlag").toString()));
			}
		} catch(Exception exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class entitySelect() :: EXCEPTION :: SQL :: "+ query);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class entitySelect() :: EXCEPTION :: "+ exception);
		} 
		return lst;
	}
	
	
	@Override
	public ArrayList<CaseVo> selectCase(CaseVo caseVo) {	 
		ArrayList<CaseVo> list=new ArrayList<CaseVo>();
		String userId=(String)httpSession.getAttribute(ApplicationConstants.LOGINUSERID);
		String userRole=(String)httpSession.getAttribute(ApplicationConstants.USERROLE);
		
		String query=null;
		Object[] obj=null;
		
		try {
			//Select All Cases	
			String subQuery=" ,'' as entity";   //",(SELECT GROUP_CONCAT(tbl_case_entity.entity_id) FROM tbl_case_entity WHERE tbl_case_entity.case_id=tbl_case.id) AS entity";
			String userId1=userId;
			if(CommonUtils.stringNotEmpty(caseVo.getUid()))	{
				userId1=caseVo.getUid().trim();
			}

			query=" SELECT case_name, id, (select count(entity_id) from tbl_case_entity where case_id=tbl_case.id) as entityCount,cast(mark as char(2)) as mark , "
					+ " COALESCE(DATE_FORMAT((date_of_creation),'%b %d,%Y %r'),'') as dateOfCreation,case_type   "+subQuery
					+ " from tbl_case where ";

			//Select Case of Particular user By Admin
			if(!userId1.equals(userId))	{
				query+= " login_id="+userId1+" and ";
			}

			//Case Of Particular User
			if(userRole.toLowerCase().equals("u")){
				query+= " 1=1 AND (login_id="+userId+" OR tbl_case.id IN (SELECT tbl_case_share_user.case_id FROM tbl_case_share_user WHERE tbl_case_share_user.login_id="+userId+" ) ) AND ";
			}

			query+= " case_name like ?";
			if(CommonUtils.stringNotEmpty(caseVo.getFilter())) { //if filter is aplly
				query+=" and case_type in("+TwitterConstant.splitCommonValues(caseVo.getFilter())+")";
			}

			if(CommonUtils.stringNotEmpty(caseVo.getNotFilter())) {  //if not filter is aplly 
				query+=" and case_type not in("+TwitterConstant.splitCommonValues(caseVo.getNotFilter())+")";
			}

			if(CommonUtils.stringNotEmpty(caseVo.getMark())) { // FILTER MARKED CASE
				query+=" and mark='"+caseVo.getMark()+"' ";
			}
				
			query+=" order by ";
			switch(caseVo.getSort().toLowerCase()) {
			case "da": // date_of_creation asc
				query+=" date_of_creation asc ";
				break;
				
			case "dd": // date_of_creation desc
				query+=" date_of_creation desc   ";
				break;
				
			case "na": // name asc
				query+=" case_name asc ";
				break;
				
			case "nd": // name desc
				query+=" case_name desc ";
				break;
				
			case "ena":  // entity count asc
				query+=" entityCount asc";
				break;
				
			case "end":  // entity count desc
				query+=" entityCount desc";
				break;
			}
			
			query+=" limit "+caseVo.getRowNum()+", 50";
			obj=new Object[]{"%"+caseVo.getCaseName()+"%"};
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query,obj);
				
			for(Map<String,Object> rs : rows){
				CaseVo inCaseVo=new CaseVo();
				inCaseVo.setCaseId(rs.get("id")==null?"":rs.get("id").toString());
				inCaseVo.setCaseName(rs.get("case_name")==null?"":rs.get("case_name").toString());
				inCaseVo.setNoOfEntity(rs.get("entityCount")==null?"":rs.get("entityCount").toString());
				inCaseVo.setDateOfCreation(rs.get("dateOfCreation")==null?"":rs.get("dateOfCreation").toString());
				inCaseVo.setCaseType(rs.get("case_type")==null?"":rs.get("case_type").toString());
				inCaseVo.setMark(rs.get("mark")==null?"":rs.get("mark").toString());
				inCaseVo.setEntityIdLst(rs.get("entity")==null?"":rs.get("entity").toString());
				list.add(inCaseVo);
			}
		} catch(Exception exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class selectCase() :: EXCEPTION :: SQL :: "+ query);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class selectCase() :: EXCEPTION :: "+ exception);
		} 
		return list;
	}

	@Override
	public void markCase(CaseVo caseVo) {
		String sqlQuery = null;
		try	{
			sqlQuery =" update tbl_case set mark='"+caseVo.getMark()+"' where id='"+caseVo.getCaseId()+"'";
			jdbcTemplate.execute(sqlQuery);
		} catch(Exception exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class markCase() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class markCase() :: EXCEPTION :: "+ exception);
		} 
	}

	@Override
	public ArrayList<EntityVo> entitySelectAll(CaseVo caseVo){
		ArrayList<EntityVo> lst=new ArrayList<EntityVo>();
		String sqlQuery=" SELECT distinct TRIM(tbl_entity.entity_name) as entity_name FROM tbl_entity ";
		try {
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(sqlQuery);
			ArrayList<String> chkDup=new ArrayList<String>();
			for(Map<String,Object> rs : rows) {
				String eName=CommonUtils.splitSring1(rs.get("entity_name")==null?"":(rs.get("entity_name").toString().trim()));
				if(!chkDup.contains(eName.trim())){
					EntityVo entityVo=new EntityVo();
					entityVo.setEntityName(eName.trim());
					chkDup.add(eName.trim());
					lst.add(entityVo);
				}
			}
		} catch(Exception exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class entitySelectAll() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class entitySelectAll() :: EXCEPTION :: "+ exception);
		} 
		return lst;
	}

	@Override
	public ArrayList<EntityVo> caseEntitySelectById(CaseVo caseVo) {
		//String user=(String)httpSession.getAttribute(ApplicationConstants.LOGIN_USER);
		ArrayList<EntityVo> lst=new ArrayList<EntityVo>();
		String sqlQuery = null;
		try	{
			if(CommonUtils.stringNotEmpty(caseVo.getCaseId())) {
				sqlQuery="	SELECT case_name,case_type,tbl_entity.entity_name,tbl_entity.entity_type,tbl_entity.entity_source_type "
						+ " ,tbl_entity.entity_id,entity_stats,entity_url,entity_img,tbl_entity.tw_id,tbl_entity.yttype,tbl_entity.fbtype  "+
						" FROM tbl_case"
						+ " INNER JOIN tbl_case_entity ON tbl_case.id=tbl_case_entity.case_id "
						+ " INNER JOIN tbl_entity ON tbl_entity.id=tbl_case_entity.entity_id "
						+ " WHERE tbl_case.id='"+caseVo.getCaseId()+"' ";
				
				List<Map<String,Object>> rows = jdbcTemplate.queryForList(sqlQuery);
				for(Map<String,Object> rs : rows) {
					EntityVo entityVo=new EntityVo();
					entityVo.setCaseId(caseVo.getCaseId());
					entityVo.setCaseName(rs.get("case_name")==null?"":rs.get("case_name").toString());
					entityVo.setCaseType(rs.get("case_type")==null?"":rs.get("case_type").toString());
					entityVo.setEntityName(rs.get("entity_name")==null?"":rs.get("entity_name").toString());
					entityVo.setEntityType(rs.get("entity_type")==null?"":rs.get("entity_type").toString());
					entityVo.setEntitySourceType(rs.get("entity_source_type")==null?"":rs.get("entity_source_type").toString());

					entityVo.setEntitySocialId(rs.get("entity_id")==null?"":rs.get("entity_id").toString());
					entityVo.setEntityStats(rs.get("entity_stats")==null?"":rs.get("entity_stats").toString());
					entityVo.setEntityUrl(rs.get("entity_url")==null?"":rs.get("entity_url").toString());
					entityVo.setEntityImg(rs.get("entity_img")==null?"":rs.get("entity_img").toString());
					entityVo.setTwId(rs.get("tw_id")==null?"":rs.get("tw_id").toString());
					entityVo.setYtType(rs.get("yttype")==null?"":rs.get("yttype").toString());
					entityVo.setFbType(rs.get("fbtype")==null?"":rs.get("fbtype").toString());
					lst.add(entityVo);
				}
			}
		} catch(Exception exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class caseEntitySelectById() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class caseEntitySelectById() :: EXCEPTION :: "+ exception);
		} 
		return lst;
	}

	@SuppressWarnings("deprecation")
	@Override
	public void analysisCurd(CaseVo caseVo)	{
		String userId=(String)httpSession.getAttribute(ApplicationConstants.LOGINUSERID);
		String sqlQuery = null;
		Object[] obj=null;
		
		try {
			if(caseVo.getActType().toLowerCase().trim().equals("new")){
				int caseId=0;
				if(CommonUtils.stringNotEmpty(caseVo.getCaseName())) {
					//Create Case
					sqlQuery="insert ignore into tbl_case(case_name,date_of_creation,login_id,case_type)values(?,?,?,?)";
					obj=new Object[]{CommonUtils.removeSpaceFromTxt(caseVo.getCaseName().trim()),CommonUtils.getSqlCurrentDateTime(),userId,caseVo.getCaseType().trim()};
					jdbcTemplate.update(sqlQuery,obj);

					//case_entity
					 Number number = jdbcTemplate.queryForObject("select id from tbl_case where case_name=? and login_id=? and case_type=?",new Object[]{CommonUtils.removeSpaceFromTxt(caseVo.getCaseName().trim()),userId,caseVo.getCaseType().trim()}, Integer.class);
					 caseId = number.intValue();
//					caseId=jdbcTemplate.queryForInt("select id from tbl_case where case_name=? and login_id=? and case_type=?",new Object[]{CommonUtils.removeSpaceFromTxt(caseVo.getCaseName().trim()),userId,caseVo.getCaseType().trim()});
					if(caseId>0) {
						if(CommonUtils.stringNotEmpty(caseVo.getCaseId())) {  // Add Groups to Analysis
							String arr[]=caseVo.getCaseId().trim().split(",");
							for(String id : arr) {
								sqlQuery="INSERT IGNORE INTO tbl_case_entity(case_id,entity_id)  (SELECT "+caseId+",entity_id FROM tbl_case_entity WHERE case_id="+id+")";
								jdbcTemplate.update(sqlQuery);
							}
						} else if(CommonUtils.stringNotEmpty(caseVo.getEntityId())) {  // Add Entity to Analysis
							String arr[]=caseVo.getEntityId().trim().split(",");
							for(String id : arr) {
								sqlQuery="INSERT IGNORE INTO tbl_case_entity(case_id,entity_id) values("+caseId+","+id+")";
								jdbcTemplate.update(sqlQuery);
							}
						}
					}
				}
			}
		} catch(Exception exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class analysisCurd() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class analysisCurd() :: EXCEPTION :: "+ exception);
		} 
	}

	@Override
	public ArrayList<CaseVo> selectAnalysisForEdit(CaseVo caseVo) {
		ArrayList<CaseVo> lst=new ArrayList<CaseVo>();
		String sqlQuery = null;
		
		try	{
			if(CommonUtils.stringNotEmpty(caseVo.getCaseId())) {
				sqlQuery ="	SELECT tbl_case.case_name,tbl_case_analysis.case_id "+
						" FROM tbl_case INNER JOIN tbl_case_analysis ON tbl_case_analysis.analysis_id=tbl_case.id "
						+ " WHERE tbl_case.id='"+caseVo.getCaseId()+"' ";
				List<Map<String,Object>> rows = jdbcTemplate.queryForList(sqlQuery);
				for(Map<String,Object> rs : rows) {
					CaseVo caseVoObj=new CaseVo();
					caseVoObj.setCaseName(rs.get("case_name")==null?"":rs.get("case_name").toString());
					caseVoObj.setCaseId(rs.get("case_id")==null?"":rs.get("case_id").toString());
					lst.add(caseVoObj);
				}
			}
		} catch(Exception exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class selectAnalysisForEdit() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class selectAnalysisForEdit() :: EXCEPTION :: "+ exception);
		} 
		return lst;
	}

	
	@Override
	public ArrayList<LoginDetails> createUser(LoginDetails loginDetails) {
		String userRole=(String)httpSession.getAttribute(ApplicationConstants.USERROLE);
		ArrayList<LoginDetails> list=new ArrayList<LoginDetails>();
		String sqlQuery= null ;
		
		try {
			//Insert New User
			if(CommonUtils.stringNotEmpty(userRole) && userRole.equals("A")) { //Only Admin can create/delete user 
				//Add User
				if(CommonUtils.stringNotEmpty(loginDetails.getMode()) && loginDetails.getMode().trim().equals("a"))	{
					if(CommonUtils.stringNotEmpty(loginDetails.getUserName()) && CommonUtils.stringNotEmpty(loginDetails.getPassword())) {
						sqlQuery = " Insert ignore into login_detail(user_logon_id, password, role, comment, "
							 + " date_of_creation, created_by, template_id) values(?,?,?,?,?,?,?)";
						Object[] obj=new Object[]{CommonUtils.removeSpaceFromTxt(loginDetails.getUserName().trim()),
								loginDetails.getPassword().trim(),
								loginDetails.getRole().trim(),
								loginDetails.getComment().trim(),
								CommonUtils.getSqlCurrentDateTime(),
								loginDetails.getCreatedBy(),
								loginDetails.getTemplateId()};
						jdbcTemplate.update(sqlQuery, obj);
					}
				} else if(CommonUtils.stringNotEmpty(loginDetails.getMode()) && loginDetails.getMode().trim().equals("e")) {
					if(CommonUtils.stringNotEmpty(loginDetails.getUserName()) && CommonUtils.stringNotEmpty(loginDetails.getPassword())){
						sqlQuery= "Update login_detail set password=?, role=?, comment=?, template_id=? where user_logon_id=? and id=?";
						Object[] obj=new Object[]{loginDetails.getPassword().trim(),
								loginDetails.getRole().trim(),
								loginDetails.getComment().trim(),
								loginDetails.getTemplateId().trim(),
								CommonUtils.removeSpaceFromTxt(loginDetails.getUserName().trim()),
								loginDetails.getId().trim()};
						jdbcTemplate.update(sqlQuery, obj);
					}
				} else if(CommonUtils.stringNotEmpty(loginDetails.getMode()) && loginDetails.getMode().trim().equals("d")) { //Delete User
					if(CommonUtils.stringNotEmpty(loginDetails.getId())) {
						//Dashboard
						sqlQuery= " delete from tbl_dashboad_widget where dashboard_id in (select id from tbl_dashboard  where created_by ='"+loginDetails.getId().trim()+"')" ;
						jdbcTemplate.update(sqlQuery); 

						sqlQuery= " delete from tbl_dashboard where created_by ='"+loginDetails.getId().trim()+"'" ;
						jdbcTemplate.update(sqlQuery); 

						//Cases					
						sqlQuery= " delete from tbl_save_filter where login_id ='"+loginDetails.getId().trim()+"'" ;
						jdbcTemplate.update(sqlQuery); 

						sqlQuery= " DELETE FROM tbl_case_entity WHERE case_id IN (SELECT id FROM tbl_case WHERE login_id='"+loginDetails.getId().trim()+"') " ;
						jdbcTemplate.update(sqlQuery); 

						sqlQuery= " delete from tbl_case where login_id ='"+loginDetails.getId().trim()+"'" ;
						jdbcTemplate.update(sqlQuery); 

						//Delete User
						sqlQuery= " delete from login_detail where id ='"+loginDetails.getId().trim()+"'" ;
						jdbcTemplate.update(sqlQuery); 
					}
				}
				sqlQuery="	SELECT lg.id,lg.user_logon_id,lg.password,lg.role,"
						+ " COALESCE(DATE_FORMAT((lg.date_of_creation),'%b %d,%Y %r'),'') as date_of_creation, "+
						" (SELECT COUNT(*) FROM tbl_case WHERE tbl_case.login_id=lg.id) AS caseCount, comment "
						+ " FROM login_detail lg WHERE lg.user_logon_id like '%"+loginDetails.getKeyword().trim()+"%'"
						+ " ORDER BY ";
				
				switch(loginDetails.getSort().trim()) {
				case "dd":
					sqlQuery+=" lg.id DESC ";
					break;
				case "da":
					sqlQuery+=" date_of_creation Asc ";
					break;
				case "na":
					sqlQuery+=" user_logon_id Asc ";
					break;
				case "nd":
					sqlQuery+=" user_logon_id DESC ";
					break;
				case "end":
					sqlQuery+=" caseCount DESC ";
					break;
				case "ena":
					sqlQuery+=" caseCount Asc ";
					break;
				default:
					sqlQuery+=" date_of_creation DESC ";
					break;
				}
				
				List<Map<String,Object>> rows = jdbcTemplate.queryForList(sqlQuery);
				for(Map<String,Object> rs : rows){
					LoginDetails loginDetailsObj=new LoginDetails();
					loginDetailsObj.setUserName(rs.get("user_logon_id")==null?"":rs.get("user_logon_id").toString());
					loginDetailsObj.setDateOfCreation(rs.get("date_of_creation")==null?"":rs.get("date_of_creation").toString());
					loginDetailsObj.setId(rs.get("id")==null?"":rs.get("id").toString());
					loginDetailsObj.setCnt(rs.get("caseCount")==null?"":rs.get("caseCount").toString());
					loginDetailsObj.setRole(rs.get("role")==null?"":rs.get("role").toString());
					loginDetailsObj.setComment(rs.get("comment")==null?"":rs.get("comment").toString());
					list.add(loginDetailsObj);
				}
			}
		} catch(Exception exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class createUser() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class createUser() :: EXCEPTION :: "+ exception);
		}
		return list;
	}
	
	@Override
	public LoginDetails selectUserById(LoginDetails loginDetails) {
		LoginDetails loginDetail = new LoginDetails();
		String userRole=(String)httpSession.getAttribute(ApplicationConstants.USERROLE);
		String sqlQuery = null;
		
		try {
			if(CommonUtils.stringNotEmpty(userRole) && userRole.equals("A")) { //Only Admin can create/delete user
				if (CommonUtils.stringNotEmpty(loginDetails.getId())) {
					sqlQuery="SELECT user_logon_id, password, role, comment from login_detail where id="+loginDetails.getId().trim();
					List<Map<String,Object>> rows = jdbcTemplate.queryForList(sqlQuery);
					for(Map<String,Object> rs : rows) {
						loginDetail.setUserName(rs.get("user_logon_id")==null?"":rs.get("user_logon_id").toString());
						loginDetail.setPassword(rs.get("password")==null?"":rs.get("password").toString());						
						loginDetail.setRole(rs.get("role")==null?"":rs.get("role").toString());
						loginDetail.setComment(rs.get("comment")==null?"":rs.get("comment").toString());
					}
				}
			}
		} catch (Exception exception) { 
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class selectUserById() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class selectUserById() :: EXCEPTION :: "+ exception);
		}
		return loginDetail;
	}

	@Override
	public void setCaseForAnalysis(CaseVo caseVo) {
		String user=(String)httpSession.getAttribute(ApplicationConstants.LOGINUSERID);
		String userRole=(String)httpSession.getAttribute(ApplicationConstants.USERROLE);
		String sqlQuery = null;
		Object[] obj=null;
		
		try {
			if(!userRole.toLowerCase().equals("a")) {
				sqlQuery= " update tbl_case set isAnalysis=0 where login_id=?  " ;
				obj=new Object[]{user};
				jdbcTemplate.update(sqlQuery,obj);

				sqlQuery= " update tbl_case set isAnalysis=1 where login_id=?  and id=? " ;
				obj=new Object[]{user,caseVo.getCaseId()};
				jdbcTemplate.update(sqlQuery,obj);
			}
		} catch (Exception exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class setCaseForAnalysis() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class setCaseForAnalysis() :: EXCEPTION :: "+ exception);
		} 
	}

	@Override
	public ArrayList<CaseVo> getCaseForAnalysis() {
		String user=(String)httpSession.getAttribute(ApplicationConstants.LOGINUSERID);
		String userRole=(String)httpSession.getAttribute(ApplicationConstants.USERROLE);
		ArrayList<CaseVo> lst=new ArrayList<CaseVo>();
		String  sqlQuery = null;
		String subQuery="";
		try {
			if(!userRole.toLowerCase().equals("a"))	{
				sqlQuery= " select case_name,id,case_type  "+subQuery+" from tbl_case  where isAnalysis=1 and tbl_case.case_type='A'  and login_id='"+user+"' " ;
				List<Map<String,Object>> rows = jdbcTemplate.queryForList(sqlQuery);

				if(rows.size()==0) {
					sqlQuery= " select case_name,id,case_type  "+subQuery+" from tbl_case where  login_id='"+user+"' and  tbl_case.case_type='A' order by date_of_creation desc limit 1 " ;
					List<Map<String,Object>> rows2 = jdbcTemplate.queryForList(sqlQuery);
					for(Map<String,Object> rs : rows2){
						CaseVo inCaseVo=new CaseVo();
						inCaseVo.setCaseId(rs.get("id")==null?"":rs.get("id").toString());
						inCaseVo.setCaseName(rs.get("case_name")==null?"":rs.get("case_name").toString());
						inCaseVo.setCaseType(rs.get("case_type")==null?"":rs.get("case_type").toString());
						inCaseVo.setEntityIdLst(rs.get("entity")==null?"":rs.get("entity").toString());
						lst.add(inCaseVo);

						//Mark selcted Case as analysis
						sqlQuery= " update tbl_case set isAnalysis=1 where login_id='"+user+"'  and id='"+rs.get("id").toString()+"' " ;
						jdbcTemplate.update(sqlQuery);
					}
				} else {
					for(Map<String,Object> rs : rows){
						CaseVo inCaseVo=new CaseVo();
						inCaseVo.setCaseId(rs.get("id")==null?"":rs.get("id").toString());
						inCaseVo.setCaseName(rs.get("case_name")==null?"":rs.get("case_name").toString());
						inCaseVo.setCaseType(rs.get("case_type")==null?"":rs.get("case_type").toString());
						inCaseVo.setEntityIdLst(rs.get("entity")==null?"":rs.get("entity").toString());
						lst.add(inCaseVo);
					}
				}
			} else { // IF User is admin
				sqlQuery= " select case_name,id,case_type "+subQuery+" from tbl_case where tbl_case.case_type='A'  " ;
				sqlQuery+=" order by date_of_creation desc limit 1";
				List<Map<String,Object>> rows = jdbcTemplate.queryForList(sqlQuery);
				for(Map<String,Object> rs : rows){
					CaseVo inCaseVo=new CaseVo();
					inCaseVo.setCaseId(rs.get("id")==null?"":rs.get("id").toString());
					inCaseVo.setCaseName(rs.get("case_name")==null?"":rs.get("case_name").toString());
					inCaseVo.setCaseType(rs.get("case_type")==null?"":rs.get("case_type").toString());
					inCaseVo.setEntityIdLst(rs.get("entity")==null?"":rs.get("entity").toString());
					lst.add(inCaseVo);
				}
			}
		} catch (Exception exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class getCaseForAnalysis() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class getCaseForAnalysis() :: EXCEPTION :: "+ exception);
		}
		return lst;
	}

	@Override
	public int setTwProfileEntity(EntityVo entityVo) {
		int entityId=0;
		String sqlQuery = null;
		Object[] obj=null;
		
		try	{
			int countId=jdbcTemplate.queryForObject("select count(*) from  tbl_entity where entity_type='p' and entity_source_type='Tw' and entity_id=? ",new Object[]{entityVo.getEntitySocialId()}, Integer.class);
			if(countId==0) {
				sqlQuery= " insert ignore into tbl_entity(entity_name,entity_id,entity_type,entity_source_type,entity_url,date_of_creation,activation_flag,entity_img,tw_id) values(?,?,?,?,?,?,?,?,?)" ;
				obj=new Object[]{CommonUtils.removeSpaceFromTxt(entityVo.getEntityName().trim()),entityVo.getEntitySocialId().trim(),"p",
						"Tw",entityVo.getEntitySocialId().trim(),CommonUtils.getSqlCurrentDateTime(),'0',entityVo.getEntityImg().trim(),entityVo.getTwId()};
				jdbcTemplate.update(sqlQuery,obj);
			}
			entityId=jdbcTemplate.queryForObject("select id from  tbl_entity where entity_type='p' and entity_source_type='Tw' and entity_id=? ",new Object[]{entityVo.getEntitySocialId()}, Integer.class);
		} catch(Exception exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class setTwProfileEntity() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class setTwProfileEntity() :: EXCEPTION :: "+ exception);
		} 
		return entityId;
	}

	
	@Override
	public String activateDeActivateEntity(EntityVo entityVo) {
		String staus = null;
		String updateQuery=null;
		String role = (String)httpSession.getAttribute(ApplicationConstants.USERROLE);
		String subQuery= null;	

		try {
			if(CommonUtils.stringNotEmpty(entityVo.getFilter())) {
				subQuery+=" and tbl_entity.entity_source_type in("+TwitterConstant.splitCommonValues(entityVo.getFilter())+")";						
			}
			
			//Entity Status Filter
			if(entityVo.getEntityStats() != null && !entityVo.getEntityStats().isEmpty()) {
				subQuery+=" and tbl_entity.activation_flag = "+entityVo.getEntityStats();
			}
			
			// Entity Type Filter // Entity, Profile, Location
			if(entityVo.getEntityType() != null && !entityVo.getEntityType().isEmpty()) {
				subQuery+=" and tbl_entity.entity_type = '"+entityVo.getEntityType()+"' ";
			}
			
			// Facebook Profile Page and Group filter
			if(entityVo.getFbType() != null && !entityVo.getFbType().isEmpty()) {
				subQuery+=" AND tbl_entity.entity_type='P' AND tbl_entity.entity_source_type='Fb' AND tbl_entity.fbtype = '"+entityVo.getFbType()+"' ";
			}

			// Profile Country filter
			if(entityVo.getCountryCode() != null && !entityVo.getCountryCode().isEmpty()) {
				subQuery+=" and tbl_entity.profileCountryCode = '"+entityVo.getCountryCode()+"' ";
			}
			
			// Profile Category filter
			if(entityVo.getProfileCategoryId() != null && !entityVo.getProfileCategoryId().isEmpty()) {				
				subQuery=" SELECT * FROM (SELECT tbl_entity.id FROM tbl_entity "
					   + " INNER JOIN tbl_entity_profile_catagory "
					   + " ON tbl_entity.id=tbl_entity_profile_catagory.tbl_entity_id "
					   + " WHERE tbl_entity_profile_catagory.profile_catagory_id='"+entityVo.getProfileCategoryId()+"' "+subQuery +" ) AS tbl";
				subQuery = " AND tbl_entity.id in ("+subQuery+") ";				
			}
			
			if(role.equals("A")) {
				switch(entityVo.getActType()) {
				case "si": //single
					updateQuery = " update tbl_entity set activation_flag='"+entityVo.getActivationFlag()+"' where id='"+entityVo.getId()+"' ";
					jdbcTemplate.update(updateQuery);
					staus = "done";
					break;

				case "sel": //selected
					if(entityVo.getPro().equals("0")) {//Propecy filter
						updateQuery = " update tbl_entity set activation_flag='"+entityVo.getActivationFlag()+"' where id in("+entityVo.getId()+") ";
						jdbcTemplate.update(updateQuery);
					} else if(entityVo.getPro().equals("1")) {
						updateQuery = " update tbl_entity set pro_flag='"+entityVo.getActivationFlag()+"' where id in("+entityVo.getId()+") ";
						jdbcTemplate.update(updateQuery);
					}
					staus = "done";
					break;

				case "all": //all
					if(entityVo.getPro().equals("0")) { //Propecy filter
						updateQuery = " update tbl_entity set activation_flag='"+entityVo.getActivationFlag()+"' WHERE 1=1 "+subQuery+" ";
						jdbcTemplate.update(updateQuery);
					} else if(entityVo.getPro().equals("1")){
						updateQuery = " update tbl_entity set pro_flag='"+entityVo.getActivationFlag()+"' WHERE 1=1 "+subQuery+" ";
						jdbcTemplate.update(updateQuery);
					}
					staus = "done";
					break;

				default:
					break;
				}
			} else {
				staus = "noPermission";
			}
		} catch(Exception exception) {
			staus="error";
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class activateDeActivateEntity() :: EXCEPTION :: SQL :: "+ subQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class activateDeActivateEntity() :: EXCEPTION :: "+ exception);
		} 
		return staus; 
	}


	@Override
	public ArrayList<LoginDetails> createFbUser(LoginDetails loginDetails) {
		ArrayList<LoginDetails> list=new ArrayList<LoginDetails>();
		String activeFlag="1=1";
		String sqlQuery = null;
		
		if(loginDetails.getAvatarStatus().equals("active")) {
			activeFlag="isActive='1'";
		}
		
		try	{
			sqlQuery=" SELECT id ,user_name, password, COALESCE(DATE_FORMAT((created_time),'%b %d,%Y %r'),'') as created_time, "
					   + " isActive, account_type "
					   + " FROM tbl_crawl_avatar "
					   + " WHERE "+activeFlag+" ";
			
			if(CommonUtils.stringNotEmpty(loginDetails.getMode()) && loginDetails.getMode().trim().equals("map")) {
				sqlQuery+=" AND account_type='p'";
			}

			if(CommonUtils.stringNotEmpty(loginDetails.getKeyword())) {
				sqlQuery+=" AND user_name like '%"+loginDetails.getKeyword().trim()+"%' " ;
			}

			if(CommonUtils.stringNotEmpty(loginDetails.getFilter())) {
				if(loginDetails.getFilter().trim().equals("act")) {
					sqlQuery+=" AND isActive=1 " ;
				} else if(loginDetails.getFilter().equals("deact"))	{
					sqlQuery+=" AND isActive=0 " ;
				}
			}

			List<Map<String,Object>> rows = jdbcTemplate.queryForList(sqlQuery);
			for(Map<String,Object> rs : rows) {
				LoginDetails loginDetailsObj=new LoginDetails();
				loginDetailsObj.setId(rs.get("id")==null?"":rs.get("id").toString());
				loginDetailsObj.setUserName(rs.get("user_name")==null?"":rs.get("user_name").toString());
				loginDetailsObj.setDateOfCreation(rs.get("created_time")==null?"":rs.get("created_time").toString());
				loginDetailsObj.setIsActive(rs.get("isActive")==null?"":rs.get("isActive").toString());
				loginDetailsObj.setRole(rs.get("account_type")==null?"":rs.get("account_type").toString());
				list.add(loginDetailsObj);
			}
		} catch(Exception exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class activateDeActivateEntity() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class activateDeActivateEntity() :: EXCEPTION :: "+ exception);
		}
		return list;
	}

	
	@Override
	public ArrayList<LoginDetails> createFbUserProf(LoginDetails loginDetails) {
		ArrayList<LoginDetails> lst=new ArrayList<LoginDetails>();
		String sqlQuery= null;
		
		try	{
			sqlQuery="	SELECT distinct fb_crawl_sele_profile_status.user_id,"
					+ " fb_crawl_sele_profile_status.user_name,"
					+ " COALESCE(DATE_FORMAT((fb_crawl_sele_profile_status.last_date_of_updation),'%b %d,%Y %r'),'') as  last_date_of_updation,"
					+ " COALESCE(DATE_FORMAT((tbl_entity.date_of_creation),'%b %d,%Y %r'),'') AS date_of_insertion, "
					+ " tbl_entity.activation_flag,"
					+ " (SELECT COUNT(*) FROM fb_account_profile_map WHERE fb_account_profile_map.profile_id=fb_crawl_sele_profile_status.user_id) AS mappedCount, "
					+ " (SELECT GROUP_CONCAT( fb_account_profile_map.account_id) FROM fb_account_profile_map WHERE fb_account_profile_map.profile_id=fb_crawl_sele_profile_status.user_id) AS mappedAvatar "
					+ " FROM fb_crawl_sele_profile_status INNER JOIN tbl_entity ON tbl_entity.id=fb_crawl_sele_profile_status.entity_id " ;

			if(CommonUtils.stringNotEmpty(loginDetails.getId1().trim())) {
				sqlQuery+=" inner join fb_account_profile_map on fb_crawl_sele_profile_status.user_id=fb_account_profile_map.profile_id ";
				sqlQuery+=" AND fb_account_profile_map.account_id='"+loginDetails.getId1().trim()+"' ";
			}

			if (CommonUtils.stringNotEmpty(loginDetails.getKeyword().trim())) {
				sqlQuery+=" AND fb_crawl_sele_profile_status.user_name like '%"+loginDetails.getKeyword().trim()+"%' " ;
			}

			//Activate Status
			switch(loginDetails.getFilter().trim()) {
			case "1":
				sqlQuery+=" AND tbl_entity.activation_flag=1 " ;
				break;
			case "0":
				sqlQuery+=" AND tbl_entity.activation_flag=0 " ;
				break;
			}

			//Crawl Filter
			switch(loginDetails.getCrawlFilter().trim()) {
			case "1":
				sqlQuery+=" AND  fb_crawl_sele_profile_status.last_date_of_updation != '0000-00-00 00:00:00'" ;
				break;
			case "0":
				sqlQuery+=" AND  fb_crawl_sele_profile_status.last_date_of_updation = '0000-00-00 00:00:00'" ;
				break;
			}

			//Mapped Filter
			switch(loginDetails.getMappedFilter().trim()) {
			case "1":
				sqlQuery+=" AND (SELECT COUNT(*) FROM fb_account_profile_map WHERE fb_account_profile_map.profile_id=fb_crawl_sele_profile_status.user_id)>0  " ;
				break;
			case "0":
				sqlQuery+=" AND (SELECT COUNT(*) FROM fb_account_profile_map WHERE fb_account_profile_map.profile_id=fb_crawl_sele_profile_status.user_id)=0  " ;
				break;
			}
			
			//Type Filter
			switch(loginDetails.getTypeFilter().trim())	{
			case "u":
				sqlQuery+=" AND tbl_entity.fbtype=1 " ;
				break;
				
			case "p":
				sqlQuery+=" AND tbl_entity.fbtype=0 " ;
				break;
				
			case "g":
				sqlQuery+=" AND tbl_entity.fbtype=2 " ;
				break;
			}

			switch(loginDetails.getSort().trim()) {
			case "dd":
				sqlQuery+=" ORDER BY fb_crawl_sele_profile_status.last_date_of_updation DESC ";
				break;
				
			case "da":
				sqlQuery+=" ORDER BY fb_crawl_sele_profile_status.last_date_of_updation ASC ";
				break;
				
			case "na":
				sqlQuery+=" ORDER BY fb_crawl_sele_profile_status.user_name ASC ";
				break;
				
			case "nd":
				sqlQuery+=" ORDER BY fb_crawl_sele_profile_status.user_name DESC ";
				break;

			case "aa":
				sqlQuery+=" ORDER BY tbl_entity.date_of_creation ASC ";
				break;
				
			case "ad":
				sqlQuery+=" ORDER BY tbl_entity.date_of_creation DESC ";
				break;
			}

			List<Map<String,Object>> rows = jdbcTemplate.queryForList(sqlQuery);
			
			for(Map<String,Object> rs : rows) {
				LoginDetails loginDetailsObj=new LoginDetails();
				loginDetailsObj.setId(rs.get("user_id")==null?"":rs.get("user_id").toString());
				loginDetailsObj.setUserName(rs.get("user_name")==null?"":rs.get("user_name").toString());
				loginDetailsObj.setDateOfUpdation(rs.get("last_date_of_updation")==null?"":rs.get("last_date_of_updation").toString());
				loginDetailsObj.setDateOfCreation(rs.get("date_of_insertion")==null?"":rs.get("date_of_insertion").toString());
				loginDetailsObj.setIsActive(rs.get("activation_flag")==null?"":rs.get("activation_flag").toString());
				loginDetailsObj.setCrawlFilter(rs.get("mappedAvatar")==null?"":rs.get("mappedAvatar").toString());
				loginDetailsObj.setMappedFilter(rs.get("mappedCount")==null?"0":rs.get("mappedCount").toString());
				lst.add(loginDetailsObj);
			}
		} catch(Exception exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class activateDeActivateEntity() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class activateDeActivateEntity() :: EXCEPTION :: "+ exception);
		}
		return lst;
	}

	@Override
	public void actDeactivate(CaseVo caseVo) {
		String sqlQuery = null;
		try {
			if(caseVo.getKey1().trim().equals("1")) {
				sqlQuery=" UPDATE tbl_entity set activation_flag='"+caseVo.getKey1()+"' where entity_id='"+caseVo.getKey2()+"'";
				jdbcTemplate.execute(sqlQuery);
			} else if(caseVo.getKey1().trim().equals("0")) {
				sqlQuery=" UPDATE tbl_entity set activation_flag='"+caseVo.getKey1()+"' where entity_id='"+caseVo.getKey2()+"'";
				jdbcTemplate.execute(sqlQuery);
			}
		} catch(Exception exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class actDeactivate() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class actDeactivate() :: EXCEPTION :: "+ exception);			
		} 
	}

	@Override
	public ArrayList<LoginDetails> selectFbUserById(LoginDetails loginDetails) {
		ArrayList<LoginDetails> lst=new ArrayList<LoginDetails>();
		String sqlQuery = null;
		try	{
			if (CommonUtils.stringNotEmpty(loginDetails.getId())) {
				sqlQuery="	SELECT id,user_name,user_pass,account_type from fb_user_account where id="+loginDetails.getId().trim();
				List<Map<String,Object>> rows = jdbcTemplate.queryForList(sqlQuery);
				for(Map<String,Object> rs : rows) {
					LoginDetails loginDetailsObj=new LoginDetails();
					loginDetailsObj.setId(rs.get("id")==null?"":rs.get("id").toString());
					loginDetailsObj.setUserName(rs.get("user_name")==null?"":rs.get("user_name").toString());
					loginDetailsObj.setPassword(rs.get("user_pass")==null?"":rs.get("user_pass").toString());
					loginDetailsObj.setRole(rs.get("account_type")==null?"":rs.get("account_type").toString());
					lst.add(loginDetailsObj);
				}
			}
		} catch(Exception exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class selectFbUserById() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class selectFbUserById() :: EXCEPTION :: "+ exception);	
		}
		return lst;
	}

	@Override
	public void mapFbProfileToAccount(LoginDetails loginDetails) {
		String sqlQuery = null;
		try {
			if(loginDetails.getMode().trim().toLowerCase().equals("map")) {
				ArrayList<String> lstAccount=loginDetails.getLst1();
				ArrayList<String> lstProfile=loginDetails.getLst2();
				
				if(lstAccount.size()>0 && lstProfile.size()>0) {
					for (String account : lstAccount) {
						for (String profile : lstProfile) {
							sqlQuery ="Delete from fb_account_profile_map where profile_id=?";
							jdbcTemplate.update(sqlQuery, new Object[]{profile});
							
							sqlQuery="Insert ignore into fb_account_profile_map(account_id,profile_id) values(?,?)";
							jdbcTemplate.update(sqlQuery, new Object[]{account,profile});
						}
					}
				}
			} else if(loginDetails.getMode().trim().toLowerCase().equals("remove")) {
				sqlQuery =" delete from fb_account_profile_map WHERE account_id=? and profile_id=? ";
				jdbcTemplate.update(sqlQuery, new Object[]{loginDetails.getId1(),loginDetails.getId2()});
			}
		} catch(Exception exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class mapFbProfileToAccount() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class mapFbProfileToAccount() :: EXCEPTION :: "+ exception);
		}
	}

	@Override 
	public void apiUrl(CaseVo caseVo) {
		String user = (String)httpSession.getAttribute(ApplicationConstants.LOGINUSERID);
		String sqlQuery=""; 
		
		if(caseVo.getCaseId().trim().equals("twtrapiid")) {
			if(caseVo.getId().equals("")) {
				sqlQuery=" INSERT ignore into api_keys(consumer_key, consumer_secret, access_token, "
					+ " access_token_secret, type, sourceType, loginId) "
					+ " values(?,?,?,?,?,?,?)";
				
				Object[] obj=new Object[]{caseVo.getKey1().trim(), caseVo.getKey2().trim(), caseVo.getKey3().trim(), caseVo.getKey4().trim(), caseVo.getType().trim(), caseVo.getKey5().trim(), user};
				jdbcTemplate.update(sqlQuery,obj);
			} else {
				sqlQuery=" UPDATE api_keys set consumer_key='"+caseVo.getKey1()+"', consumer_secret='"+caseVo.getKey2()+"', access_token='"+caseVo.getKey3()+"', access_token_secret='"+caseVo.getKey4()+"', type='"+caseVo.getType()+"' where id='"+caseVo.getId()+"' ";
				jdbcTemplate.update(sqlQuery);
			}
		}
		
		if(caseVo.getCaseId().trim().equals("fbapiid")) {
			if(caseVo.getId().equals("")) {
				sqlQuery =" insert ignore into fb_api_test(Client_Id,Client_Secret) values(?,?)";
				Object[]	obj=new Object[]{caseVo.getKey1().trim(),caseVo.getKey2().trim()};
				jdbcTemplate.update(sqlQuery,obj);
			} else {
				sqlQuery=" update  fb_api_test set Client_Id='"+caseVo.getKey1()+"',Client_Secret='"+caseVo.getKey2()+"' where id='"+caseVo.getId()+"' ";
				jdbcTemplate.update(sqlQuery);
			}
		}
		
		if(caseVo.getCaseId().trim().equals("ytapiid")) {
			if(caseVo.getId().equals("")) {
				sqlQuery=" insert ignore into yt_api_test(token) values(?)";
				Object[]	obj=new Object[]{caseVo.getKey1().trim()};
				jdbcTemplate.update(sqlQuery,obj);
			} else {
				sqlQuery =" update  yt_api_test set token='"+caseVo.getKey1()+"' where id='"+caseVo.getId()+"' ";
				jdbcTemplate.update(sqlQuery);
			}
		}
		
		if(caseVo.getCaseId().trim().equals("webapiid")){
			if(caseVo.getId().equals("")) {
				sqlQuery=" insert ignore into web_api_keys(consumer_key,sourceType) values(?,?)";
				Object[]	obj=new Object[]{caseVo.getKey1().trim(),caseVo.getKey2().trim()};
				jdbcTemplate.update(sqlQuery,obj);
			} else {
				sqlQuery=" update  web_api_keys set consumer_key='"+caseVo.getKey1()+"',sourceType='"+caseVo.getKey2()+"' where id='"+caseVo.getId()+"' ";
				jdbcTemplate.update(sqlQuery);
			}
		}
	}

	@Override
	public ArrayList<CaseVo> apiSelectUrl(CaseVo caseVo) {
		ArrayList<CaseVo> lst=new ArrayList<CaseVo>();
		String sqlQuery = null;
		try {
			if(caseVo.getCaseId().trim().equals("twtrapiid")) {
				sqlQuery ="SELECT * from api_keys";
				List<Map<String,Object>> rows = jdbcTemplate.queryForList(sqlQuery);
				for(Map<String,Object> rs : rows) {
					CaseVo caseVoObj=new CaseVo();
					caseVoObj.setId(rs.get("id")==null?"":rs.get("id").toString());
					caseVoObj.setKey1(rs.get("consumer_key")==null?"":rs.get("consumer_key").toString());
					caseVoObj.setKey2(rs.get("consumer_secret")==null?"":rs.get("consumer_secret").toString());
					caseVoObj.setKey3(rs.get("access_token")==null?"":rs.get("access_token").toString());
					caseVoObj.setKey4(rs.get("access_token_secret")==null?"":rs.get("access_token_secret").toString());
					caseVoObj.setType(rs.get("type")==null?"":rs.get("type").toString());
					lst.add(caseVoObj);
				}
			}
			
			if(caseVo.getCaseId().trim().equals("fbapiid"))	{
				sqlQuery="SELECT * from fb_api_test";
				List<Map<String,Object>> rows = jdbcTemplate.queryForList(sqlQuery);
				for(Map<String,Object> rs : rows) {
					CaseVo caseVoObj=new CaseVo();
					caseVoObj.setId(rs.get("id")==null?"":rs.get("id").toString());
					caseVoObj.setKey1(rs.get("Client_Id")==null?"":rs.get("Client_Id").toString());
					caseVoObj.setKey2(rs.get("Client_Secret")==null?"":rs.get("Client_Secret").toString());
					lst.add(caseVoObj);
				}
			}
			
			if(caseVo.getCaseId().trim().equals("ytapiid"))	{
				sqlQuery ="SELECT * from yt_api_test";
				List<Map<String,Object>> rows = jdbcTemplate.queryForList(sqlQuery);
				for(Map<String,Object> rs : rows) {
					CaseVo caseVoObj=new CaseVo();
					caseVoObj.setId(rs.get("id")==null?"":rs.get("id").toString());
					caseVoObj.setKey1(rs.get("token")==null?"":rs.get("token").toString());
					lst.add(caseVoObj);
				}
			}
			
			if(caseVo.getCaseId().trim().equals("webapiid")) {
				sqlQuery ="SELECT * from web_api_keys";
				List<Map<String,Object>> rows = jdbcTemplate.queryForList(sqlQuery);
				for(Map<String,Object> rs : rows) {
					CaseVo caseVoObj=new CaseVo();
					caseVoObj.setId(rs.get("id")==null?"":rs.get("id").toString());
					caseVoObj.setKey2(rs.get("sourceType")==null?"":rs.get("sourceType").toString());
					caseVoObj.setKey1(rs.get("consumer_key")==null?"":rs.get("consumer_key").toString());
					lst.add(caseVoObj);
				}
			}
		} catch(Exception exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class apiSelectUrl() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class apiSelectUrl() :: EXCEPTION :: "+ exception);
		} 
		return lst;
	}

	@Override
	public ArrayList<CaseVo> apiDltUrl(CaseVo caseVo) {
		ArrayList<CaseVo> lst=new ArrayList<CaseVo>();
		String sqlQuery=null;
		try	{
			if(caseVo.getCaseId().trim().equals("twtrapiid")) {
				sqlQuery= " delete from api_keys where id= '"+caseVo.getId()+"' " ;
				jdbcTemplate.update(sqlQuery);
			} else if(caseVo.getCaseId().trim().equals("fbapiid")) {
				sqlQuery= " delete from fb_api_test where id='"+caseVo.getId()+"' " ;
				jdbcTemplate.update(sqlQuery);
			} else if(caseVo.getCaseId().trim().equals("ytapiid")) {
				sqlQuery= " delete from yt_api_test where id='"+caseVo.getId()+"' " ;
				jdbcTemplate.update(sqlQuery); 
			} else if(caseVo.getCaseId().trim().equals("webapiid")) {
				sqlQuery= " delete  from web_api_keys where id='"+caseVo.getId()+"' " ;
				jdbcTemplate.update(sqlQuery); 
			}
		} catch(Exception exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class apiDltUrl() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class apiDltUrl() :: EXCEPTION :: "+ exception);
		} 
		return lst;	
	}

	@Override
	public ArrayList<LoginDetails> slctAccountFb(LoginDetails loginDetails) {
		ArrayList<LoginDetails> lst=new ArrayList<LoginDetails>();
		String sqlQuery=null;
		try {
			sqlQuery="	SELECT * FROM fb_user_account where 1=1";
			if(CommonUtils.stringNotEmpty(loginDetails.getUserName().trim())){
				sqlQuery+=" and  user_name like'%"+loginDetails.getUserName().trim()+"%'";
			}
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(sqlQuery);
			for(Map<String,Object> rs : rows) {
				LoginDetails loginDetailsObj=new LoginDetails();
				loginDetailsObj.setId(rs.get("id")==null?"":rs.get("id").toString());
				loginDetailsObj.setUserName(rs.get("user_name")==null?"":rs.get("user_name").toString());
				loginDetailsObj.setDateOfCreation(rs.get("created_time")==null?"":rs.get("created_time").toString());
				loginDetailsObj.setCnt(rs.get("user_pass")==null?"":rs.get("user_pass").toString());
				loginDetailsObj.setIsActive(rs.get("isActive")==null?"":rs.get("isActive").toString());
				lst.add(loginDetailsObj);
			}
		} catch(Exception exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class slctAccountFb() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class slctAccountFb() :: EXCEPTION :: "+ exception);
		}
		return lst; 
	}
	
	@Override
	public ArrayList<LoginDetails> innsightUserLoginLimit(LoginDetails loginDetails) {
		ArrayList<LoginDetails> list=new ArrayList<LoginDetails>();
		String sqlQuery = null;
		try {
			sqlQuery = " SELECT * FROM login_concurrent_user_info WHERE product='innsight' ";
			List<Map<String, Object>> rows = jdbcTemplate.queryForList(sqlQuery);
			for(Map<String, Object> rs : rows) {
				LoginDetails login = new LoginDetails();								
				login.setCurrentConnection((Integer)rs.get("current_connections"));
				login.setMaximumConnection((Integer)rs.get("maximum_connections"));
				login.setInnsightUserLimitFlag(rs.get("innsightUserLimitFlag")==null?"no":rs.get("innsightUserLimitFlag").toString());				
				list.add(login);			
			}
		} catch(Exception exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class innsightUserLoginLimit() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class innsightUserLoginLimit() :: EXCEPTION :: "+ exception);
		}
		return list;
	}

	@Override
	public ArrayList<CaseVo> getUserAccessTemplate(CaseVo caseVo) {
		ArrayList<CaseVo> list=new ArrayList<CaseVo>();
		String sqlQuery = null;
		try	{
			sqlQuery = " SELECT * FROM tbl_authorization_template ";
			List<Map<String, Object>> rows = jdbcTemplate.queryForList(sqlQuery);
			for(Map<String, Object> rs : rows){
				CaseVo template = new CaseVo();								
				template.setCaseId(rs.get("id")==null?"no":rs.get("id").toString());	
				template.setKey1(rs.get("template_name")==null?"no":rs.get("template_name").toString());				
    			list.add(template);			
			}
		} catch(Exception exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class getUserAccessTemplate() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class getUserAccessTemplate() :: EXCEPTION :: "+ exception);
		}
		return list;
	}
	
	@Override
	public boolean editMaxInnsightUserLoginConnection(LoginDetails loginDetails) {
		boolean result=false;
		String sqlQuery = null;
		try {
			sqlQuery = " UPDATE login_concurrent_user_info "
					     + " SET maximum_connections="+loginDetails.getMaximumConnection()+" "
					     + " WHERE product='innsight' ";
		    jdbcTemplate.update(sqlQuery);
		    result=true;
		} catch(Exception exception) {
			result=false;
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class editMaxInnsightUserLoginConnection() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class editMaxInnsightUserLoginConnection() :: EXCEPTION :: "+ exception);
		}
		return result;
	}
	
	@Override
	public void insertManageCrawler(ManageCrawlerVo manageCrawlerVo) {
		try	{
			if(manageCrawlerVo.getId().equals("")){
				String sqlQuery=" INSERT ignore into tbl_manage_crawler(job_name,seed_url,depth,domain_regex,start_date,end_date,use_proxy,has_recrawling,recrawling_day,recrawling_hour,recrawling_minute,recrawling_second,recrawling_frequency,recrawling_interval,max_restart_try,restart_interval)values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
				KeyHolder keyHolder = new GeneratedKeyHolder();
				jdbcTemplate.update(new PreparedStatementCreator() {
					public PreparedStatement createPreparedStatement(Connection connection) throws SQLException {
						PreparedStatement ps = connection.prepareStatement(sqlQuery,Statement.RETURN_GENERATED_KEYS);
						ps.setString(1, manageCrawlerVo.getJobName().trim());
						ps.setString(2, manageCrawlerVo.getSeedUrl().trim());
						ps.setString(3, manageCrawlerVo.getDepth().trim());
						ps.setString(4, manageCrawlerVo.getDomainRegex().trim());
						ps.setString(5, manageCrawlerVo.getStartDate().trim());
						ps.setString(6, manageCrawlerVo.getEndDate().trim());
						ps.setString(7, manageCrawlerVo.getUseProxy().trim());
						ps.setString(8, manageCrawlerVo.getHasRecrawling().trim());
						
						if(manageCrawlerVo.getHasRecrawling().trim().equals("1")){
							ps.setString(9, manageCrawlerVo.getDay().trim());
							ps.setString(10, manageCrawlerVo.getRecrawlingHour().trim());
							ps.setString(11, manageCrawlerVo.getRecrawlingMinute().trim());
							ps.setString(12, manageCrawlerVo.getRecrawlingSecond().trim());
							ps.setString(13, manageCrawlerVo.getRecrawlingFrequency().trim());
							ps.setString(14, manageCrawlerVo.getRecrawlingInterval().trim());
						} else {
							ps.setString(9, "0");
							ps.setString(10, "0");
							ps.setString(11, "0");
							ps.setString(12, "0");
							ps.setString(13, "0");
							ps.setString(14, "0");
						}
						ps.setString(15, manageCrawlerVo.getMaxRestartTry().trim());
						ps.setString(16, manageCrawlerVo.getRestartInterval().trim());
						return ps;
					}
				}, keyHolder);
				
				int crawlerAutogenertdId= keyHolder.getKey().intValue();
				if(manageCrawlerVo.getUseProxy().trim().equals("1")) {
					String[] popp=  manageCrawlerVo.getProxyArray();
					for(int i = 0; i < popp.length; i++) {
						String	query2=" insert ignore into tbl_crawler_proxy_mapping(proxy_id,crawler_id) values(?,?)";
						jdbcTemplate.update(query2, new Object[] {popp[i], String.valueOf(crawlerAutogenertdId)});
					}
				}
			} else {
				try	{
					String query=" update  tbl_manage_crawler set depth='"+manageCrawlerVo.getDepth().trim()+"',domain_regex='"+manageCrawlerVo.getDomainRegex().trim()+"',"
							+ "start_date='"+manageCrawlerVo.getStartDate().trim()+"',end_date='"+manageCrawlerVo.getEndDate().trim()+"',use_proxy='"+manageCrawlerVo.getUseProxy().trim()+"',has_recrawling='"+
							manageCrawlerVo.getHasRecrawling().trim()+"',";
					if(manageCrawlerVo.getHasRecrawling().trim().equals("1")) {
						query+= "recrawling_day='"+manageCrawlerVo.getDay().trim()+"',"+ "recrawling_hour='"+
								manageCrawlerVo.getRecrawlingHour().trim()+"',recrawling_minute='"+manageCrawlerVo.getRecrawlingMinute().trim()+"',"
								+ "recrawling_second='"+manageCrawlerVo.getRecrawlingSecond().trim()+"',recrawling_frequency='"+
								manageCrawlerVo.getRecrawlingFrequency().trim()+"',recrawling_interval='"+manageCrawlerVo.getRecrawlingInterval().trim()+"',";
					} else {
						query+= "recrawling_day='0',recrawling_hour='0',recrawling_minute='0',recrawling_second='0',recrawling_frequency='0',"+ "recrawling_interval='0',";
						}
					query+= "max_restart_try='"+manageCrawlerVo.getMaxRestartTry().trim()+"',restart_interval='"+manageCrawlerVo.getRestartInterval().trim()+"' where id='"+manageCrawlerVo.getId()+"'";
					jdbcTemplate.update(query);
				} catch(Exception exception) {
					logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class insertManageCrawler() :: EXCEPTION :: "+ exception);
				}

				String  queryf="delete from tbl_crawler_proxy_mapping where crawler_id = '"+manageCrawlerVo.getId()+"'";
				jdbcTemplate.update(queryf);

				if(manageCrawlerVo.getUseProxy().trim().equals("1")){
					String[] popp=  manageCrawlerVo.getProxyArray();
					for(int i = 0; i < popp.length; i++) {
						String	query2=" insert ignore into tbl_crawler_proxy_mapping(proxy_id,crawler_id) values(?,?)";
						jdbcTemplate.update(query2, new Object[] {popp[i],manageCrawlerVo.getId()});
					}
				}
			}
		} catch(Exception exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class insertManageCrawler() :: EXCEPTION :: "+ exception);
		}
	}

	@Override
	public ArrayList<ManageCrawlerVo> getManageCrawler(ManageCrawlerVo manageCrawlerVo) {
		ArrayList<ManageCrawlerVo> lst=new ArrayList<ManageCrawlerVo>();
		String  sqlQuery=null;
		
		try	{
			if(manageCrawlerVo.getId().equals("")){
				sqlQuery="	SELECT * FROM tbl_manage_crawler where  domain_regex like '%"+manageCrawlerVo.getJobName()+"%' ORDER BY id DESC ";
				List<Map<String,Object>> rows = jdbcTemplate.queryForList(sqlQuery);
				for(Map<String,Object> rs : rows) {
					ManageCrawlerVo manageCrawlerObj=new ManageCrawlerVo();
					manageCrawlerObj.setDepth(rs.get("depth")==null?"0":rs.get("depth").toString());
					manageCrawlerObj.setJobName(rs.get("job_name")==null?"0":rs.get("job_name").toString());
					manageCrawlerObj.setStartDate(rs.get("start_date")==null?"0":rs.get("start_date").toString());
					manageCrawlerObj.setEndDate(rs.get("end_date")==null?"0":rs.get("end_date").toString());
					manageCrawlerObj.setSeedUrl(rs.get("seed_url")==null?"":rs.get("seed_url").toString());
					manageCrawlerObj.setId((rs.get("id").toString()));
					lst.add(manageCrawlerObj);
				}
			} else {
				sqlQuery=" SELECT * FROM tbl_manage_crawler where id ='"+manageCrawlerVo.getId()+"' ORDER BY id DESC ";
				List<Map<String,Object>> rows = jdbcTemplate.queryForList(sqlQuery);
				
				for(Map<String,Object> rs : rows) {
					ManageCrawlerVo manageCrawlerObj=new ManageCrawlerVo();
					manageCrawlerObj.setDepth(rs.get("depth")==null?"0":rs.get("depth").toString());
					manageCrawlerObj.setJobName(rs.get("job_name")==null?"0":rs.get("job_name").toString());
					manageCrawlerObj.setDomainRegex(rs.get("domain_regex")==null?"0":rs.get("domain_regex").toString());
					manageCrawlerObj.setStartDate(rs.get("start_date")==null?"0":rs.get("start_date").toString());
					manageCrawlerObj.setEndDate(rs.get("end_date")==null?"0":rs.get("end_date").toString());
					manageCrawlerObj.setSeedUrl(rs.get("seed_url")==null?"":rs.get("seed_url").toString());
					manageCrawlerObj.setRecrawlingDay(rs.get("recrawling_day")==null?"0":rs.get("recrawling_day").toString());
					manageCrawlerObj.setUseProxy(rs.get("use_proxy")==null?"0":rs.get("use_proxy").toString());
					manageCrawlerObj.setHasRecrawling(rs.get("has_recrawling")==null?"0":rs.get("has_recrawling").toString());
					manageCrawlerObj.setRecrawlingHour(rs.get("recrawling_hour")==null?"0":rs.get("recrawling_hour").toString());
					manageCrawlerObj.setRecrawlingMinute(rs.get("recrawling_minute")==null?"0":rs.get("recrawling_minute").toString());
					manageCrawlerObj.setRecrawlingSecond(rs.get("recrawling_second")==null?"0":rs.get("recrawling_second").toString());
					manageCrawlerObj.setRecrawlingInterval(rs.get("recrawling_interval")==null?"0":rs.get("recrawling_interval").toString());
					manageCrawlerObj.setRecrawlingFrequency(rs.get("recrawling_frequency")==null?"0":rs.get("recrawling_frequency").toString());
					manageCrawlerObj.setMaxRestartTry(rs.get("max_restart_try")==null?"0":rs.get("max_restart_try").toString());
					manageCrawlerObj.setRestartInterval(rs.get("restart_interval")==null?"0":rs.get("restart_interval").toString());
					manageCrawlerObj.setId((rs.get("id").toString()));
					lst.add(manageCrawlerObj);
				}
			}
		} catch(Exception exception)	{
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class getManageCrawler() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class getManageCrawler() :: EXCEPTION :: "+ exception);
		}
		return lst; 
	}

	@Override
	public void deleteManageCrawler(ManageCrawlerVo manageCrawlerVo){
		String  sqlQuery=null;
		try {
			sqlQuery="	DELETE from tbl_manage_crawler where id=?";
			Object[] obj=new Object[]{manageCrawlerVo.getId()};
			jdbcTemplate.update(sqlQuery,obj);
		}
		catch(Exception exception)	{
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class deleteManageCrawler() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class deleteManageCrawler() :: EXCEPTION :: "+ exception);
		}
	}

	@Override
	public ArrayList<CrawlerSourceVo> getCrawlerSources(ManageCrawlerVo manageCrawlerVo) {
		ArrayList<CrawlerSourceVo> lst=new ArrayList<CrawlerSourceVo>();
		//String query = null;
		try 
		{
			
			/*			query="	SELECT * FROM tbl_crawler_source ";
			System.out.println("getManageCrawler=="+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs : rows){
				CrawlerSourceVo manageCrawlerObj=new CrawlerSourceVo();
				manageCrawlerObj.setHostName(rs.get("source")==null?"":rs.get("source").toString());
				lst.add(manageCrawlerObj);
			}
			String subQuery="";
			int size=100;
			query="{\n"+
					"\"size\": 0,\n" +
					subQuery+
					",\"aggs\":\n"+
					"{\n"+
					"\"termagg\":{\n"+
					"\"terms\":{\n"+
					"\"field\":\"host\"\n,"+
					"\"size\":\""+size+"\"\n"+

					"}\n"+
					"}\n"+
					"}\n"+
					"}\n";
			System.out.println("*****getManageCrawler()*****"+query);
			try {
				Search search = new Search.Builder(query)
				.addIndex(TwitterConstant.getDbname())
				.addType("doc")
				.build();
				SearchResult result = client.execute(search);
				TermsAggregation terms = result.getAggregations().getTermsAggregation("termagg");
				List<Entry>  entry=  terms.getBuckets();
				for (Entry entry2 : entry) {
					CrawlerSourceVo manageCrawlerObj=new CrawlerSourceVo();
					manageCrawlerObj.setHostName(entry2.getKey());
					lst.add(manageCrawlerObj);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			 */
			
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		}
		return lst; 
	}
	
	@Override
	public LinkedHashMap<String, String> setFilter(SaveFilterVo saveFilterVo) {
		LinkedHashMap<String, String> lnkMap=new LinkedHashMap<>();
		try {
			TwitterInnDaoImpl twitterimpl=new TwitterInnDaoImpl();
			TweeterActionVo tweeterActionVo=saveFilterVo.getTweeterActionVo();
			String filterQuery = twitterimpl.rtnFilterQuery(tweeterActionVo, -1);
			
			String user=(String)httpSession.getAttribute(ApplicationConstants.LOGINUSERID);
			String snapShotQuery=" INSERT ignore into tbl_save_filter(search_name, case_id, login_id, global_search, date_search,"
					+ " advance_search, hashtag_include, hashtag_exclude, user_include, user_exclude, mention_include,"
					+ " mention_exclude, org_include, org_exclude, link_include, link_exclude, map_include,"
					+ " map_exclude, img_include, img_exclude, video_include, video_exclude, place_include,"
					+ " place_exclude, person_include, person_exclude, doe,"
					+ " description, date_sorting, sentiment_filter, classification_filter, emotion_filter, datefrom, dateto, has_news_feed, news_rss_country_filter,"
					+ " has_social_media, social_media_filter, has_dark_web, dark_web_filter, has_custom_crawler, bool_oper, news_feed_country_specific, lang_include, lang_exclude,"
					+ " odsProfile_include, odsProfile_exclude, odsPost_include, odsPost_exclude, ocrPost_include, ocrPost_exclude, retweetUser_include, retweetUser_exclude, "
					+ " user_location_include, user_location_exclude, threat_matrix_filter, user_status_filter, domain_include, domain_exclude, "
					+ " theme_include, theme_exclude, article_location_include, article_location_exclude, author_location_include, author_location_exclude, "
					+ " location_name, latitude, longitude, radius_in_km, analysis_type, calender_include, calender_exclude, has_website, has_ftp, es_query, keywordIds, "
					+ " threat_classification_filter )"
					+ " values(?,?,?,?,?,?,?,?,?,?,"
					+ " ?,?,?,?,?,?,?,?,?,?,"
					+ " ?,?,?,?,?,?,?,?,?,?,"
					+ " ?,?,?,?,?,?,?,?,?,?,"
					+ " ?,?,?,?,?,?,?,?,?,?,"
					+ " ?,?,?,?,?,?,?,?,?,?,"
					+ " ?,?,?,?,?,?,?,?,?,?,"
					+ " ?,?,?,?,?,?,?)";

			if(saveFilterVo.getMode().equals("addAnalysis")) {
				String query="INSERT ignore into tbl_case(case_name, date_of_creation, login_id, case_type)values(?,?,?,?)";
				KeyHolder keyHolder = new GeneratedKeyHolder();
				jdbcTemplate.update(new PreparedStatementCreator() {
					public PreparedStatement createPreparedStatement(Connection connection) throws SQLException {
						PreparedStatement ps = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
						ps.setString(1, saveFilterVo.getSearchName().trim());
						ps.setString(2, CommonUtils.getSqlCurrentDateTime());
						ps.setString(3, user);
						ps.setString(4, "A");
						return ps;
					}
				}, keyHolder);

				if(keyHolder.getKey() != null) {
                	int caseId= keyHolder.getKey().intValue();
    				lnkMap.put("caseId", Integer.toString(caseId));
    				 				
    				if(caseId>0) {
    					keyHolder = new GeneratedKeyHolder();
    					jdbcTemplate.update(new PreparedStatementCreator() {
    						public PreparedStatement createPreparedStatement( Connection connection) throws SQLException {
    							PreparedStatement ps = connection.prepareStatement(snapShotQuery,Statement.RETURN_GENERATED_KEYS);
    							ps.setString(1, saveFilterVo.getSnapshotName().trim());
    							ps.setInt(2, caseId);
    							ps.setString(3, user);
    							ps.setString(4, saveFilterVo.getGlobalSearch().trim());
    							ps.setString(5, saveFilterVo.getDateSearch().trim());
    							ps.setString(6, saveFilterVo.getAdvanceSearch().trim());
    							ps.setString(7, saveFilterVo.getHashtagInclude().trim());
    							ps.setString(8, saveFilterVo.getHashtagExclude().trim());
    							ps.setString(9, saveFilterVo.getUserInclude().trim());
    							ps.setString(10, saveFilterVo.getUserExclude().trim());
    							ps.setString(11, saveFilterVo.getMentionInclude().trim());
    							ps.setString(12, saveFilterVo.getMentionExclude().trim());
    							ps.setString(13, saveFilterVo.getOrgInclude().trim());
    							ps.setString(14, saveFilterVo.getOrgExclude().trim());
    							ps.setString(15, saveFilterVo.getLinkInclude().trim());
    							ps.setString(16, saveFilterVo.getLinkExclude().trim());
    							
    							if(saveFilterVo.getMapInclude().equals("")){
    								ps.setString(17, saveFilterVo.getMapInclude());
    							} else {
    								ps.setString(17, JsonFormat.getJsonFormat(saveFilterVo.getMapInclude()));
    							}
    							ps.setString(18, saveFilterVo.getMapExclude());
    							ps.setString(19, saveFilterVo.getImgInclude().trim());
    							ps.setString(20, saveFilterVo.getImgExclude().trim());
    							ps.setString(21, saveFilterVo.getVideoInclude().trim());
    							ps.setString(22, saveFilterVo.getVideoExclude().trim());
    							ps.setString(23, saveFilterVo.getPlaceInclude().trim());
    							ps.setString(24, saveFilterVo.getPlaceExclude().trim());
    							ps.setString(25, saveFilterVo.getPrsnInclude().trim());
    							ps.setString(26, saveFilterVo.getPrsnExclude().trim());
    							ps.setString(27, CommonUtils.getSqlCurrentDateTime());
    							ps.setString(28,saveFilterVo.getDescription().trim());
    							ps.setString(29, saveFilterVo.getDateSorting().trim());
    							ps.setString(30, saveFilterVo.getSentimentFilter().trim());
    							ps.setString(31, saveFilterVo.getClassificationFilter());
    							ps.setString(32, saveFilterVo.getEmotionFilter().trim());
    							ps.setString(33, saveFilterVo.getDateFrom().trim());
    							ps.setString(34, saveFilterVo.getDateTo().trim());
    							ps.setString(35, saveFilterVo.getHasNewsFeed());
    							ps.setString(36, saveFilterVo.getNewsRssCountryFilter());
    							ps.setString(37, saveFilterVo.getHasSocialMedia());
    							ps.setString(38, saveFilterVo.getSocialMediaFilter().trim());
    							ps.setString(39, saveFilterVo.getHasDarkWeb());
    							ps.setString(40, saveFilterVo.getDarkwebFilter().trim());   							
    							ps.setString(41, saveFilterVo.getHasCustomCrawler());
    							ps.setString(42, saveFilterVo.getBoolOper());
    							ps.setString(43, saveFilterVo.getNewsFeedCountrySpecific());   							
    							ps.setString(44, saveFilterVo.getLangInclude().trim());
    							ps.setString(45, saveFilterVo.getLangExclude().trim());   							
    							ps.setString(46, saveFilterVo.getOdsProfileInclude().trim());
    							ps.setString(47, saveFilterVo.getOdsProfileExclude().trim());
    							ps.setString(48, saveFilterVo.getOdsPostInclude().trim());
    							ps.setString(49, saveFilterVo.getOdsPostExclude().trim());   							
    							ps.setString(50, saveFilterVo.getOcrPostInclude().trim());
    							ps.setString(51, saveFilterVo.getOcrPostExclude().trim());    							   							
       							ps.setString(52, saveFilterVo.getRetweetUserInclude().trim());
    							ps.setString(53, saveFilterVo.getRetweetUserExclude().trim());  							    							
    							if(saveFilterVo.getMapUserInclude().equals("")) {
    								ps.setString(54, saveFilterVo.getMapUserInclude());
    							} else {
    								ps.setString(54, JsonFormat.getJsonFormat(saveFilterVo.getMapUserInclude()));
    							}
    							ps.setString(55, saveFilterVo.getMapUserExclude().trim());   							
    							ps.setString(56, saveFilterVo.getThreatMatrixFilter().trim());
    							ps.setString(57, saveFilterVo.getUserStatusFilter().trim());   							
    							ps.setString(58, saveFilterVo.getDomainInclude().trim());
    							ps.setString(59, saveFilterVo.getDomainExclude().trim()); 							
    							ps.setString(60, saveFilterVo.getThemeInclude().trim());
    							ps.setString(61, saveFilterVo.getThemeExclude().trim());
    							ps.setString(62, saveFilterVo.getArticleLocationInclude().trim());
    							ps.setString(63, saveFilterVo.getArticleLocationExclude().trim());
    							ps.setString(64, saveFilterVo.getAuthorLocationInclude().trim());
    							ps.setString(65, saveFilterVo.getAuthorLocationExclude().trim());    							
    							ps.setString(66, saveFilterVo.getLocationName().trim());
    							ps.setString(67, saveFilterVo.getLatitude().trim());
    							ps.setString(68, saveFilterVo.getLongitude().trim());
    							ps.setString(69, saveFilterVo.getRadiusInKM().trim());
    							ps.setString(70, saveFilterVo.getAnalysisType().trim());
    							ps.setString(71, saveFilterVo.getCalenderInclude().trim());
    							ps.setString(72, saveFilterVo.getCalenderExclude().trim());
    							ps.setString(73, saveFilterVo.getHasWebsite().trim());
    							ps.setString(74, saveFilterVo.getHasFTP().trim());
    							ps.setString(75, filterQuery.trim());
    							ps.setString(76, "");
    							ps.setString(77, saveFilterVo.getThreatClassificationFilter().trim());
    							return ps;
    						}
    					}, keyHolder);

    					int snapShotId= keyHolder.getKey().intValue();
    					lnkMap.put("snapshotId", Integer.toString(snapShotId));
    					
    					addProfileToAnalysis(saveFilterVo.getLstEntityVos(), snapShotId);
    					addNewsSourceToAnalysis(saveFilterVo.getNewsSourceList(), snapShotId);
    					addNewsWebsiteToAnalysis(saveFilterVo.getNewsWebsiteList(), snapShotId);
    					addNewsFTPToAnalysis(saveFilterVo.getNewsFTPList(), snapShotId);
    					
    					//To add User Logs
    					String userLog = "Add New Analysis, SnapshotName: "+saveFilterVo.getSnapshotName()+ ", Global Search"+saveFilterVo.getGlobalSearch()+ ", Advance Search"+saveFilterVo.getAdvanceSearch();
    					commonUtils.insertUserActivityLogs(userLog);
    				}
                }				
			} else if(saveFilterVo.getMode().equals("addsnapshot"))	{
				int caseId= saveFilterVo.getCaseId();
				lnkMap.put("caseId", Integer.toString(caseId));
				System.out.println("CaseId::"+caseId);
				
				if(caseId>0) {
					GeneratedKeyHolder keyHolder = new GeneratedKeyHolder();
					jdbcTemplate.update(new PreparedStatementCreator() {
						public PreparedStatement createPreparedStatement(Connection connection) throws SQLException {
							PreparedStatement ps = connection.prepareStatement(snapShotQuery, Statement.RETURN_GENERATED_KEYS);
							
							ps.setString(1, saveFilterVo.getSnapshotName().trim());
							ps.setInt(2, caseId);
							ps.setString(3, user);
							ps.setString(4, saveFilterVo.getGlobalSearch().trim());
							ps.setString(5, saveFilterVo.getDateSearch().trim());
							ps.setString(6, saveFilterVo.getAdvanceSearch().trim());
							ps.setString(7, saveFilterVo.getHashtagInclude().trim());
							ps.setString(8, saveFilterVo.getHashtagExclude().trim());
							ps.setString(9, saveFilterVo.getUserInclude().trim());
							ps.setString(10, saveFilterVo.getUserExclude().trim());
							ps.setString(11, saveFilterVo.getMentionInclude().trim());
							ps.setString(12, saveFilterVo.getMentionExclude().trim());
							ps.setString(13, saveFilterVo.getOrgInclude().trim());
							ps.setString(14, saveFilterVo.getOrgExclude().trim());
							ps.setString(15, saveFilterVo.getLinkInclude().trim());
							ps.setString(16, saveFilterVo.getLinkExclude().trim());
							if(saveFilterVo.getMapInclude().equals("")) {
								ps.setString(17, saveFilterVo.getMapInclude());
							} else {
								ps.setString(17, JsonFormat.getJsonFormat(saveFilterVo.getMapInclude()));
							}
							ps.setString(18, saveFilterVo.getMapExclude());
							ps.setString(19, saveFilterVo.getImgInclude().trim());
							ps.setString(20, saveFilterVo.getImgExclude().trim());
							ps.setString(21, saveFilterVo.getVideoInclude().trim());
							ps.setString(22, saveFilterVo.getVideoExclude().trim());
							ps.setString(23, saveFilterVo.getPlaceInclude().trim());
							ps.setString(24, saveFilterVo.getPlaceExclude().trim());
							ps.setString(25, saveFilterVo.getPrsnInclude().trim());
							ps.setString(26, saveFilterVo.getPrsnExclude().trim());
							ps.setString(27, CommonUtils.getSqlCurrentDateTime());
							ps.setString(28, saveFilterVo.getDescription().trim());
							ps.setString(29, saveFilterVo.getDateSorting().trim());
							ps.setString(30, saveFilterVo.getSentimentFilter().trim());
							ps.setString(31, saveFilterVo.getClassificationFilter());
							ps.setString(32, saveFilterVo.getEmotionFilter().trim());
							ps.setString(33, saveFilterVo.getDateFrom().trim());
							ps.setString(34, saveFilterVo.getDateTo().trim());
							ps.setString(35, saveFilterVo.getHasNewsFeed());
							ps.setString(36, saveFilterVo.getNewsRssCountryFilter());
							ps.setString(37, saveFilterVo.getHasSocialMedia());
							ps.setString(38, saveFilterVo.getSocialMediaFilter().trim());
							ps.setString(39, saveFilterVo.getHasDarkWeb());
							ps.setString(40, saveFilterVo.getDarkwebFilter().trim());							
							ps.setString(41, saveFilterVo.getHasCustomCrawler());
							ps.setString(42, saveFilterVo.getBoolOper());
							ps.setString(43, saveFilterVo.getNewsFeedCountrySpecific());							
							ps.setString(44, saveFilterVo.getLangInclude().trim());
							ps.setString(45, saveFilterVo.getLangExclude().trim());							
							ps.setString(46, saveFilterVo.getOdsProfileInclude().trim());
							ps.setString(47, saveFilterVo.getOdsProfileExclude().trim());
							ps.setString(48, saveFilterVo.getOdsPostInclude().trim());
							ps.setString(49, saveFilterVo.getOdsPostExclude().trim());
							ps.setString(50, saveFilterVo.getOcrPostInclude().trim());
							ps.setString(51, saveFilterVo.getOcrPostExclude().trim());
   							ps.setString(52, saveFilterVo.getRetweetUserInclude().trim());
							ps.setString(53, saveFilterVo.getRetweetUserExclude().trim());							
							if(saveFilterVo.getMapUserInclude().equals("")) {
								ps.setString(54, saveFilterVo.getMapUserInclude());
							} else {
								ps.setString(54, JsonFormat.getJsonFormat(saveFilterVo.getMapUserInclude()));
							}
							ps.setString(55, saveFilterVo.getMapUserExclude());							
							ps.setString(56, saveFilterVo.getThreatMatrixFilter().trim());
							ps.setString(57, saveFilterVo.getUserStatusFilter().trim());							
							ps.setString(58, saveFilterVo.getDomainInclude().trim());
							ps.setString(59, saveFilterVo.getDomainExclude().trim()); 							
							ps.setString(60, saveFilterVo.getThemeInclude().trim());
							ps.setString(61, saveFilterVo.getThemeExclude().trim());
							ps.setString(62, saveFilterVo.getArticleLocationInclude().trim());
							ps.setString(63, saveFilterVo.getArticleLocationExclude().trim());
							ps.setString(64, saveFilterVo.getAuthorLocationInclude().trim());
							ps.setString(65, saveFilterVo.getAuthorLocationExclude().trim());
							ps.setString(66, saveFilterVo.getLocationName().trim());
							ps.setString(67, saveFilterVo.getLatitude().trim());
							ps.setString(68, saveFilterVo.getLongitude().trim());
							ps.setString(69, saveFilterVo.getRadiusInKM().trim());
							ps.setString(70, saveFilterVo.getAnalysisType().trim());
							ps.setString(71, saveFilterVo.getCalenderInclude().trim());
							ps.setString(72, saveFilterVo.getCalenderExclude().trim());
							ps.setString(73, saveFilterVo.getHasWebsite().trim());
							ps.setString(74, saveFilterVo.getHasFTP().trim());
							ps.setString(75, filterQuery.trim());
							ps.setString(76, "");
							ps.setString(77, saveFilterVo.getThreatClassificationFilter().trim());
							return ps;
						}
					}, keyHolder);

					int snapShotId= keyHolder.getKey().intValue();
					lnkMap.put("snapshotId", Integer.toString(snapShotId));					
					
					addProfileToAnalysis(saveFilterVo.getLstEntityVos(), snapShotId);
					addNewsSourceToAnalysis(saveFilterVo.getNewsSourceList(), snapShotId);
					addNewsWebsiteToAnalysis(saveFilterVo.getNewsWebsiteList(), snapShotId);
					addNewsFTPToAnalysis(saveFilterVo.getNewsFTPList(), snapShotId);
					
					//To add User Logs
					String userLog = "Add Snapshot, SnapshotName: "+saveFilterVo.getSnapshotName()+ ", Global Search"+saveFilterVo.getGlobalSearch()+ ", Advance Search"+saveFilterVo.getAdvanceSearch();
					commonUtils.insertUserActivityLogs(userLog);
				}
			} else if(saveFilterVo.getMode().equals("overwritesnapshot")) {
				int caseId= saveFilterVo.getCaseId();
				lnkMap.put("caseId", Integer.toString(caseId));
				
				if(caseId>0 && saveFilterVo.getSnapShotId()>0) {
					String query="delete from tbl_save_filter where case_id='"+caseId+"' and id='"+saveFilterVo.getSnapShotId()+"'";
					jdbcTemplate.update(query);

					GeneratedKeyHolder keyHolder = new GeneratedKeyHolder();
					jdbcTemplate.update(new PreparedStatementCreator() {
						public PreparedStatement createPreparedStatement(Connection connection) throws SQLException {
							PreparedStatement ps = connection.prepareStatement(snapShotQuery, Statement.RETURN_GENERATED_KEYS);
							
							ps.setString(1, saveFilterVo.getSnapshotName().trim());
							ps.setInt(2, caseId);
							ps.setString(3, user);					
							ps.setString(4, saveFilterVo.getGlobalSearch().trim());
							ps.setString(5, saveFilterVo.getDateSearch().trim());
							ps.setString(6, saveFilterVo.getAdvanceSearch().trim());
							ps.setString(7, saveFilterVo.getHashtagInclude().trim());
							ps.setString(8, saveFilterVo.getHashtagExclude().trim());
							ps.setString(9, saveFilterVo.getUserInclude().trim());
							ps.setString(10, saveFilterVo.getUserExclude().trim());
							ps.setString(11, saveFilterVo.getMentionInclude().trim());
							ps.setString(12, saveFilterVo.getMentionExclude().trim());
							ps.setString(13, saveFilterVo.getOrgInclude().trim());
							ps.setString(14, saveFilterVo.getOrgExclude().trim());
							ps.setString(15, saveFilterVo.getLinkInclude().trim());
							ps.setString(16, saveFilterVo.getLinkExclude().trim());
							if(saveFilterVo.getMapInclude().equals("")) {
								ps.setString(17, saveFilterVo.getMapInclude());
							} else {
								ps.setString(17, JsonFormat.getJsonFormat(saveFilterVo.getMapInclude()));
							}
							ps.setString(18, saveFilterVo.getMapExclude());
							ps.setString(19, saveFilterVo.getImgInclude().trim());
							ps.setString(20, saveFilterVo.getImgExclude().trim());
							ps.setString(21, saveFilterVo.getVideoInclude().trim());
							ps.setString(22, saveFilterVo.getVideoExclude().trim());
							ps.setString(23, saveFilterVo.getPlaceInclude().trim());
							ps.setString(24, saveFilterVo.getPlaceExclude().trim());
							ps.setString(25, saveFilterVo.getPrsnInclude().trim());
							ps.setString(26, saveFilterVo.getPrsnExclude().trim());
							ps.setString(27, CommonUtils.getSqlCurrentDateTime());
							ps.setString(28, saveFilterVo.getDescription().trim());
							ps.setString(29, saveFilterVo.getDateSorting().trim());
							ps.setString(30, saveFilterVo.getSentimentFilter().trim());
							ps.setString(31, saveFilterVo.getClassificationFilter());
							ps.setString(32, saveFilterVo.getEmotionFilter().trim());
							ps.setString(33, saveFilterVo.getDateFrom().trim());
							ps.setString(34, saveFilterVo.getDateTo().trim());
							ps.setString(35, saveFilterVo.getHasNewsFeed());
							ps.setString(36, saveFilterVo.getNewsRssCountryFilter());
							ps.setString(37, saveFilterVo.getHasSocialMedia());
							ps.setString(38, saveFilterVo.getSocialMediaFilter().trim());
							ps.setString(39, saveFilterVo.getHasDarkWeb());
							ps.setString(40, saveFilterVo.getDarkwebFilter().trim());							
							ps.setString(41, saveFilterVo.getHasCustomCrawler());
							ps.setString(42, saveFilterVo.getBoolOper());
							ps.setString(43, saveFilterVo.getNewsFeedCountrySpecific());							
							ps.setString(44, saveFilterVo.getLangInclude().trim());
							ps.setString(45, saveFilterVo.getLangExclude().trim());							
							ps.setString(46, saveFilterVo.getOdsProfileInclude().trim());
							ps.setString(47, saveFilterVo.getOdsProfileExclude().trim());
							ps.setString(48, saveFilterVo.getOdsPostInclude().trim());
							ps.setString(49, saveFilterVo.getOdsPostExclude().trim());
							ps.setString(50, saveFilterVo.getOcrPostInclude().trim());
							ps.setString(51, saveFilterVo.getOcrPostExclude().trim());
   							ps.setString(52, saveFilterVo.getRetweetUserInclude().trim());
							ps.setString(53, saveFilterVo.getRetweetUserExclude().trim());							
							if(saveFilterVo.getMapUserInclude().equals("")) {
								ps.setString(54, saveFilterVo.getMapUserInclude());
							} else {
								ps.setString(54, JsonFormat.getJsonFormat(saveFilterVo.getMapUserInclude()));
							}
							ps.setString(55, saveFilterVo.getMapUserExclude().trim());							
							ps.setString(56, saveFilterVo.getThreatMatrixFilter().trim());
							ps.setString(57, saveFilterVo.getUserStatusFilter().trim());							
							ps.setString(58, saveFilterVo.getDomainInclude().trim());
							ps.setString(59, saveFilterVo.getDomainExclude().trim()); 							
							ps.setString(60, saveFilterVo.getThemeInclude().trim());
							ps.setString(61, saveFilterVo.getThemeExclude().trim());
							ps.setString(62, saveFilterVo.getArticleLocationInclude().trim());
							ps.setString(63, saveFilterVo.getArticleLocationExclude().trim());
							ps.setString(64, saveFilterVo.getAuthorLocationInclude().trim());
							ps.setString(65, saveFilterVo.getAuthorLocationExclude().trim());
							ps.setString(66, saveFilterVo.getLocationName().trim());
							ps.setString(67, saveFilterVo.getLatitude().trim().trim());
							ps.setString(68, saveFilterVo.getLongitude().trim());
							ps.setString(69, saveFilterVo.getRadiusInKM().trim());
							ps.setString(70, saveFilterVo.getAnalysisType().trim());
							ps.setString(71, saveFilterVo.getCalenderInclude().trim());
							ps.setString(72, saveFilterVo.getCalenderExclude().trim());
							ps.setString(73, saveFilterVo.getHasWebsite().trim());
							ps.setString(74, saveFilterVo.getHasFTP().trim());
							ps.setString(75, filterQuery.trim());
							ps.setString(76, "");
							ps.setString(77, saveFilterVo.getThreatClassificationFilter().trim());
							return ps;
						}
					}, keyHolder);
					
					int snapShotId= keyHolder.getKey().intValue();
					lnkMap.put("snapshotId", Integer.toString(snapShotId));
					query="delete from tbl_case_profile where snapshot_id='"+saveFilterVo.getSnapShotId()+"'";
					jdbcTemplate.update(query);
					addProfileToAnalysis(saveFilterVo.getLstEntityVos(), snapShotId);
				
					query="delete from tbl_case_news_source where snapshot_id='"+saveFilterVo.getSnapShotId()+"'";
					jdbcTemplate.update(query);
					
					addNewsSourceToAnalysis(saveFilterVo.getNewsSourceList(), snapShotId);
					addNewsWebsiteToAnalysis(saveFilterVo.getNewsWebsiteList(), snapShotId);
					addNewsFTPToAnalysis(saveFilterVo.getNewsFTPList(), snapShotId);
					
					//To add User Logs
					String userLog = "Overwrite Snapshot, SnapshotName: "+saveFilterVo.getSnapshotName()+ ", Global Search"+saveFilterVo.getGlobalSearch()+ ", Advance Search"+saveFilterVo.getAdvanceSearch();
					commonUtils.insertUserActivityLogs(userLog);
				}
			}
		} catch(Exception ex) {
			ex.printStackTrace();
		}
		return lnkMap;
	}		
	
	@Override
	public boolean saveFilterForTrackTwKeyword(SaveFilterVo saveFilterVo)
	{
		boolean actionFlag=false;
		try 
		{
			String user=(String)httpSession.getAttribute(ApplicationConstants.LOGINUSERID);
			System.out.println("Track TW Keyword Mode: "+saveFilterVo.getMode());
			
			String snapShotQuery=" INSERT ignore into tbl_save_filter(search_name, case_id, login_id, global_search, date_search,"
					+ " advance_search, hashtag_include, hashtag_exclude, user_include, user_exclude, mention_include,"
					+ " mention_exclude, org_include, org_exclude, link_include, link_exclude, map_include,"
					+ " map_exclude, img_include, img_exclude, video_include, video_exclude, place_include,"
					+ " place_exclude, person_include, person_exclude, doe,"
					+ " description, date_sorting, sentiment_filter, classification_filter, emotion_filter, datefrom, dateto, has_news_feed, news_rss_country_filter,"
					+ " has_social_media, social_media_filter, has_dark_web, dark_web_filter, has_custom_crawler, bool_oper, news_feed_country_specific, lang_include, lang_exclude,"
					+ " odsProfile_include, odsProfile_exclude, odsPost_include, odsPost_exclude, ocrPost_include, ocrPost_exclude, retweetUser_include, retweetUser_exclude, "
					+ " user_location_include, user_location_exclude, threat_matrix_filter, user_status_filter, domain_include, domain_exclude, "
					+ " theme_include, theme_exclude, article_location_include, article_location_exclude, author_location_include, author_location_exclude, "
					+ " analysis_type, trackTwKeyword, location_name, latitude, longitude, radius_in_km)"
					+ " values(?,?,?,?,?,?,?,?,?,?,"
					+ " ?,?,?,?,?,?,?,?,?,?,"
					+ " ?,?,?,?,?,?,?,?,?,?,"
					+ " ?,?,?,?,?,?,?,?,?,?,"
					+ " ?,?,?,?,?,?,?,?,?,?,"
					+ " ?,?,?,?,?,?,?,?,?,?,"
					+ " ?,?,?,?,?,?,?,?,?,?,"
					+ " ?)";
			
			String query="INSERT ignore into tbl_case(case_name, date_of_creation, login_id, case_type, analysis_type)values(?,?,?,?,?)";
			System.out.println("Create Case==: "+query);
			
			KeyHolder keyHolder = new GeneratedKeyHolder();
			jdbcTemplate.update(new PreparedStatementCreator() {
				public PreparedStatement createPreparedStatement(
						Connection connection) throws SQLException {
					PreparedStatement ps = connection.prepareStatement(query,
							Statement.RETURN_GENERATED_KEYS);
					ps.setString(1, saveFilterVo.getSearchName().trim());
					ps.setString(2, CommonUtils.getSqlCurrentDateTime());
					ps.setString(3, user);
					ps.setString(4, "A");
					ps.setString(5, "trackTwKeyword");
					return ps;
				}
			}, keyHolder);
            System.out.println("keyHolder:=========== "+keyHolder);               
            System.out.println("keyHolder.getKey():== "+keyHolder.getKey());
            
            if(keyHolder.getKey() != null) 
            {
            	int caseId= keyHolder.getKey().intValue();
				System.out.println("caseId: "+caseId);
				System.out.println("Case Inserted Successfully with Id: "+caseId);
				System.out.println("Query::"+snapShotQuery);
				 				
				if(caseId>0) 
				{
					keyHolder = new GeneratedKeyHolder();
					jdbcTemplate.update(new PreparedStatementCreator() {
						public PreparedStatement createPreparedStatement(
								Connection connection) throws SQLException {
							PreparedStatement ps = connection.prepareStatement(snapShotQuery,
									Statement.RETURN_GENERATED_KEYS);
							ps.setString(1, saveFilterVo.getSnapshotName().trim());
							ps.setInt(2, caseId);
							ps.setString(3, user);
							ps.setString(4, saveFilterVo.getGlobalSearch().trim());
							ps.setString(5, saveFilterVo.getDateSearch().trim());
							ps.setString(6, saveFilterVo.getAdvanceSearch().trim());
							ps.setString(7, saveFilterVo.getHashtagInclude().trim());
							ps.setString(8, saveFilterVo.getHashtagExclude().trim());
							ps.setString(9, saveFilterVo.getUserInclude().trim());
							ps.setString(10, saveFilterVo.getUserExclude().trim());
							ps.setString(11, saveFilterVo.getMentionInclude().trim());
							ps.setString(12, saveFilterVo.getMentionExclude().trim());
							ps.setString(13, saveFilterVo.getOrgInclude().trim());
							ps.setString(14, saveFilterVo.getOrgExclude().trim());
							ps.setString(15, saveFilterVo.getLinkInclude().trim());
							ps.setString(16, saveFilterVo.getLinkExclude().trim());
							ps.setString(17, saveFilterVo.getMapInclude());
							ps.setString(18, saveFilterVo.getMapExclude());
							ps.setString(19, saveFilterVo.getImgInclude().trim());
							ps.setString(20, saveFilterVo.getImgExclude().trim());
							ps.setString(21, saveFilterVo.getVideoInclude().trim());
							ps.setString(22, saveFilterVo.getVideoExclude().trim());
							ps.setString(23, saveFilterVo.getPlaceInclude().trim());
							ps.setString(24, saveFilterVo.getPlaceExclude().trim());
							ps.setString(25, saveFilterVo.getPrsnInclude().trim());
							ps.setString(26, saveFilterVo.getPrsnExclude().trim());
							ps.setString(27, CommonUtils.getSqlCurrentDateTime());
							ps.setString(28, saveFilterVo.getDescription().trim());
							ps.setString(29, saveFilterVo.getDateSorting().trim());
							ps.setString(30, saveFilterVo.getSentimentFilter().trim());
							ps.setString(31, saveFilterVo.getClassificationFilter());
							ps.setString(32, saveFilterVo.getEmotionFilter().trim());
							ps.setString(33, saveFilterVo.getDateFrom().trim());
							ps.setString(34, saveFilterVo.getDateTo().trim());
							ps.setString(35, saveFilterVo.getHasNewsFeed());
							ps.setString(36, saveFilterVo.getNewsRssCountryFilter());
							ps.setString(37, saveFilterVo.getHasSocialMedia());
							ps.setString(38, saveFilterVo.getSocialMediaFilter().trim());
							ps.setString(39, saveFilterVo.getHasDarkWeb());
							ps.setString(40, saveFilterVo.getDarkwebFilter().trim());   							
							ps.setString(41, saveFilterVo.getHasCustomCrawler());
							ps.setString(42, saveFilterVo.getBoolOper());
							ps.setString(43, saveFilterVo.getNewsFeedCountrySpecific());   							
							ps.setString(44, saveFilterVo.getLangInclude().trim());
							ps.setString(45, saveFilterVo.getLangExclude().trim());   							
							ps.setString(46, saveFilterVo.getOdsProfileInclude().trim());
							ps.setString(47, saveFilterVo.getOdsProfileExclude().trim());
							ps.setString(48, saveFilterVo.getOdsPostInclude().trim());
							ps.setString(49, saveFilterVo.getOdsPostExclude().trim());   							
							ps.setString(50, saveFilterVo.getOcrPostInclude().trim());
							ps.setString(51, saveFilterVo.getOcrPostExclude().trim());    							   							
   							ps.setString(52, saveFilterVo.getRetweetUserInclude().trim());
							ps.setString(53, saveFilterVo.getRetweetUserExclude().trim()); 
							ps.setString(54, saveFilterVo.getMapUserInclude().trim());
							ps.setString(55, saveFilterVo.getMapUserExclude().trim());   							
							ps.setString(56, saveFilterVo.getThreatMatrixFilter().trim());
							ps.setString(57, saveFilterVo.getUserStatusFilter().trim());   							
							ps.setString(58, saveFilterVo.getDomainInclude().trim());
							ps.setString(59, saveFilterVo.getDomainExclude().trim()); 							
							ps.setString(60, saveFilterVo.getThemeInclude().trim());
							ps.setString(61, saveFilterVo.getThemeExclude().trim());
							ps.setString(62, saveFilterVo.getArticleLocationInclude().trim());
							ps.setString(63, saveFilterVo.getArticleLocationExclude().trim());
							ps.setString(64, saveFilterVo.getAuthorLocationInclude().trim());
							ps.setString(65, saveFilterVo.getAuthorLocationExclude().trim()); 							
							ps.setString(66, saveFilterVo.getAnalysisType().trim());
							ps.setString(67, saveFilterVo.getTrackTwKeyword().trim());
							ps.setString(68, saveFilterVo.getLocationName().trim());
							ps.setString(69, saveFilterVo.getLatitude().trim());
							ps.setString(70, saveFilterVo.getLongitude().trim());
							ps.setString(71, saveFilterVo.getRadiusInKM().trim());														
							return ps;
						}
					}, keyHolder);
					int snapShotId= keyHolder.getKey().intValue();
					System.out.println("snapShotId:"+snapShotId);
					
					//To add User Logs
					String userLog = "Add New Analysis: Track TW Keyword, SnapshotName: "+saveFilterVo.getSnapshotName();
					commonUtils.insertUserActivityLogs(userLog);
					actionFlag=true;
				}
            }									
		} 
		catch(Exception ex) 
		{
			actionFlag=false;
			ex.printStackTrace();
		}
		return actionFlag;
	}
	
	
	@Override
	public ArrayList<SaveFilterVo> getSnapshotsById(SaveFilterVo saveFilterVo) {
		ArrayList<SaveFilterVo> saveFilterVoList = new ArrayList<SaveFilterVo>();		
		try {
			String query = "Select * from tbl_save_filter where case_id = "+saveFilterVo.getCaseId();
			System.out.println("Query : "+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs : rows) {
				SaveFilterVo caseVoObj=new SaveFilterVo();
				caseVoObj.setSearchName(rs.get("search_name")==null?"":rs.get("search_name").toString());
				caseVoObj.setId(rs.get("id")==null?0:(int) (rs.get("id")));
				saveFilterVoList.add(caseVoObj);			
			}		
			System.out.println("List size : "+saveFilterVoList.size());
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return saveFilterVoList;
	}
	
	
	@Override
	public boolean deleteSnapshot(SaveFilterVo saveFilterVo) 
	{
		boolean status = false;
		try 
		{
			System.out.println("snapShotId:"+saveFilterVo.getSnapShotId());
			String query="delete from tbl_case_profile where snapshot_id='"+saveFilterVo.getSnapShotId()+"'";
			System.out.println(query);
			jdbcTemplate.update(query);
			
			query="delete from tbl_case_news_source where snapshot_id='"+saveFilterVo.getSnapShotId()+"'";
			System.out.println(query);
			jdbcTemplate.update(query);

			query="delete from tbl_case_whatsup_group where snapshot_id='"+saveFilterVo.getSnapShotId()+"'";
			System.out.println(query);
			jdbcTemplate.update(query);
						
			if(saveFilterVo.getLoginId() > 1) 
			{
				query="delete from tbl_save_filter where id='"+saveFilterVo.getSnapShotId()+"'";
				System.out.println("delete snapshot:::"+query);
				jdbcTemplate.update(query);
				status = true;
			} 
			else if(saveFilterVo.getLoginId() == 1) 
			{
				query="delete from tbl_save_filter where id='"+saveFilterVo.getSnapShotId()+"'";
				System.out.println("delete snapshot:::"+query);
				jdbcTemplate.update(query);
				
				query="delete from tbl_case where id='"+saveFilterVo.getCaseId()+"'";
				System.out.println("delete case:::"+query);
				jdbcTemplate.update(query);
				status = true;
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return false;		
	}


	@Override
	public ArrayList<SaveFilterVo> getSaveFilter(SaveFilterVo saveFilterVo) 
	{
		ArrayList<SaveFilterVo> list = new ArrayList<SaveFilterVo>();
		try 
		{
			String query=" SELECT *, COALESCE(DATE_FORMAT((doe),'%b %d,%Y %r'),'') as doe1 "
					   + " FROM tbl_save_filter "
					   + " WHERE tbl_save_filter.id='"+saveFilterVo.getCaseId()+"'";
			System.out.println("getSaveFilter: "+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			
			for(Map<String, Object> rs : rows)
			{
				SaveFilterVo caseVoObj=new SaveFilterVo();
				caseVoObj.setId(Integer.parseInt(rs.get("id")==null?"":rs.get("id").toString()));
				caseVoObj.setSearchName(rs.get("search_name")==null?"":rs.get("search_name").toString());
				caseVoObj.setCaseId(Integer.parseInt(rs.get("case_id")==null?"":rs.get("case_id").toString()));
				caseVoObj.setLoginId(Integer.parseInt(rs.get("login_id")==null?"":rs.get("login_id").toString()));
				caseVoObj.setGlobalSearch(rs.get("global_search")==null?"":rs.get("global_search").toString());
				caseVoObj.setDateSearch(rs.get("date_search")==null?"":rs.get("date_search").toString());
				caseVoObj.setAdvanceSearch(rs.get("advance_search")==null?"":rs.get("advance_search").toString());				
				caseVoObj.setHashtagInclude(rs.get("hashtag_include")==null?"":rs.get("hashtag_include").toString());
				caseVoObj.setHashtagExclude(rs.get("hashtag_exclude")==null?"":rs.get("hashtag_exclude").toString());
				caseVoObj.setMentionInclude(rs.get("mention_include")==null?"":rs.get("mention_include").toString());
				caseVoObj.setMentionExclude(rs.get("mention_exclude")==null?"":rs.get("mention_exclude").toString());
				caseVoObj.setUserInclude(rs.get("user_include")==null?"":rs.get("user_include").toString());
				caseVoObj.setUserExclude(rs.get("user_exclude")==null?"":rs.get("user_exclude").toString());
				caseVoObj.setPrsnInclude(rs.get("person_include")==null?"":rs.get("person_include").toString());
				caseVoObj.setPrsnExclude(rs.get("person_exclude")==null?"":rs.get("person_exclude").toString());
				caseVoObj.setPlaceInclude(rs.get("place_include")==null?"":rs.get("place_include").toString());
				caseVoObj.setPlaceExclude(rs.get("place_exclude")==null?"":rs.get("place_exclude").toString());
				caseVoObj.setOrgInclude(rs.get("org_include")==null?"":rs.get("org_include").toString());
				caseVoObj.setOrgExclude(rs.get("org_exclude")==null?"":rs.get("org_exclude").toString());
				caseVoObj.setThemeInclude(rs.get("theme_include")==null?"":rs.get("theme_include").toString());
				caseVoObj.setThemeExclude(rs.get("theme_exclude")==null?"":rs.get("theme_exclude").toString());
				caseVoObj.setCalenderInclude(rs.get("calender_include")==null?"":rs.get("calender_include").toString());
				caseVoObj.setCalenderExclude(rs.get("calender_exclude")==null?"":rs.get("calender_exclude").toString());
				caseVoObj.setArticleLocationInclude(rs.get("article_location_include")==null?"":rs.get("article_location_include").toString());
				caseVoObj.setArticleLocationExclude(rs.get("article_location_exclude")==null?"":rs.get("article_location_exclude").toString());
				caseVoObj.setAuthorLocationInclude(rs.get("author_location_include")==null?"":rs.get("author_location_include").toString());
				caseVoObj.setAuthorLocationExclude(rs.get("author_location_exclude")==null?"":rs.get("author_location_exclude").toString());
				caseVoObj.setImgInclude(rs.get("img_include")==null?"":rs.get("img_include").toString());
				caseVoObj.setImgExclude(rs.get("img_exclude")==null?"":rs.get("img_exclude").toString());
				caseVoObj.setVideoInclude(rs.get("video_include")==null?"":rs.get("video_include").toString());
				caseVoObj.setVideoExclude(rs.get("video_exclude")==null?"":rs.get("video_exclude").toString());			
				caseVoObj.setLinkInclude(rs.get("link_include")==null?"":rs.get("link_include").toString());
				caseVoObj.setLinkExclude(rs.get("link_exclude")==null?"":rs.get("link_exclude").toString());
				caseVoObj.setDomainInclude(rs.get("domain_include")==null?"":rs.get("domain_include").toString());
				caseVoObj.setDomainExclude(rs.get("domain_exclude")==null?"":rs.get("domain_exclude").toString());
				caseVoObj.setLangExclude(rs.get("lang_exclude")==null?"":rs.get("lang_exclude").toString());
				caseVoObj.setLangInclude(rs.get("lang_include")==null?"":rs.get("lang_include").toString());
				caseVoObj.setSentimentFilter(rs.get("sentiment_filter")==null?"":rs.get("sentiment_filter").toString());
				caseVoObj.setClassificationFilter(rs.get("classification_filter")==null?"":rs.get("classification_filter").toString());
				caseVoObj.setThreatClassificationFilter(rs.get("threat_classification_filter")==null?"":rs.get("threat_classification_filter").toString());
				caseVoObj.setEmotionFilter(rs.get("emotion_filter")==null?"":rs.get("emotion_filter").toString());
				caseVoObj.setDoe(rs.get("doe1")==null?"":rs.get("doe1").toString());
				caseVoObj.setDescription(rs.get("description")==null?"":rs.get("description").toString());
				caseVoObj.setDateSorting(rs.get("date_sorting")==null?"":rs.get("date_sorting").toString());
				caseVoObj.setDateFrom(rs.get("datefrom")==null?"":rs.get("datefrom").toString());
				caseVoObj.setDateTo(rs.get("dateto")==null?"":rs.get("dateto").toString());				
				caseVoObj.setHasNewsFeed(rs.get("has_news_feed")==null?"":rs.get("has_news_feed").toString());
				caseVoObj.setHasWebsite(rs.get("has_website")==null?"":rs.get("has_website").toString());
				caseVoObj.setHasFTP(rs.get("has_ftp")==null?"":rs.get("has_ftp").toString());
				caseVoObj.setNewsRssCountryFilter(rs.get("news_rss_country_filter")==null?"":rs.get("news_rss_country_filter").toString());				
				caseVoObj.setHasSocialMedia(rs.get("has_social_media")==null?"":rs.get("has_social_media").toString());				
				caseVoObj.setSocialMediaFilter(rs.get("social_media_filter")==null?"":rs.get("social_media_filter").toString());				
				caseVoObj.setHasDarkWeb(rs.get("has_dark_web")==null?"":rs.get("has_dark_web").toString());
				caseVoObj.setDarkwebFilter(rs.get("dark_web_filter")==null?"":rs.get("dark_web_filter").toString());				
				caseVoObj.setHasCustomCrawler(rs.get("has_custom_crawler")==null?"":rs.get("has_custom_crawler").toString());				
				caseVoObj.setBoolOper(rs.get("bool_oper")==null?"":rs.get("bool_oper").toString());
				caseVoObj.setLstEntityVos(getProfileBySnapshots(saveFilterVo.getCaseId()));
				caseVoObj.setNewsFeedCountrySpecific(rs.get("news_feed_country_specific")==null?"":rs.get("news_feed_country_specific").toString());
				caseVoObj.setNewsSourceList(getNewsSourceBySnapshots(saveFilterVo.getCaseId()));
				caseVoObj.setNewsWebsiteList(getNewsWebsiteBySnapshots(saveFilterVo.getCaseId()));
				caseVoObj.setNewsFTPList(getNewsFTPBySnapshots(saveFilterVo.getCaseId()));
				caseVoObj.setOdsProfileInclude(rs.get("odsProfile_include")==null?"":rs.get("odsProfile_include").toString());
				caseVoObj.setOdsProfileExclude(rs.get("odsProfile_exclude")==null?"":rs.get("odsProfile_exclude").toString());
				caseVoObj.setOdsPostInclude(rs.get("odsPost_include")==null?"":rs.get("odsPost_include").toString());
				caseVoObj.setOdsPostExclude(rs.get("odsPost_exclude")==null?"":rs.get("odsPost_exclude").toString());			
				caseVoObj.setOcrPostInclude(rs.get("ocrPost_include")==null?"":rs.get("ocrPost_include").toString());
				caseVoObj.setOcrPostExclude(rs.get("ocrPost_exclude")==null?"":rs.get("ocrPost_exclude").toString());							
				caseVoObj.setRetweetUserInclude(rs.get("retweetUser_include")==null?"":rs.get("retweetUser_include").toString());
				caseVoObj.setRetweetUserExclude(rs.get("retweetUser_exclude")==null?"":rs.get("retweetUser_exclude").toString());
				caseVoObj.setMapInclude(rs.get("map_include")==null?"":rs.get("map_include").toString());
				caseVoObj.setMapExclude(rs.get("map_exclude")==null?"":rs.get("map_exclude").toString());
				caseVoObj.setMapUserInclude(rs.get("user_location_include")==null?"":rs.get("user_location_include").toString());
				caseVoObj.setMapUserExclude(rs.get("user_location_exclude")==null?"":rs.get("user_location_exclude").toString());
				caseVoObj.setThreatMatrixFilter(rs.get("threat_matrix_filter")==null?"":rs.get("threat_matrix_filter").toString());
				caseVoObj.setUserStatusFilter(rs.get("user_status_filter")==null?"":rs.get("user_status_filter").toString());
				caseVoObj.setWhatsGroupList(getWhtasAppSourceBySnapshots(saveFilterVo.getCaseId()));				
				caseVoObj.setLocationName(rs.get("location_name")==null?"":rs.get("location_name").toString());
				caseVoObj.setLatitude(rs.get("latitude")==null?"":rs.get("latitude").toString());
				caseVoObj.setLongitude(rs.get("longitude")==null?"":rs.get("longitude").toString());
				caseVoObj.setRadiusInKM(rs.get("radius_in_km")==null?"":rs.get("radius_in_km").toString());
				caseVoObj.setAnalysisType(rs.get("analysis_type")==null?"":rs.get("analysis_type").toString());
				caseVoObj.setEsQuery(rs.get("es_query")==null?"":rs.get("es_query").toString());
				caseVoObj.setKeywordIds(rs.get("keywordIds")==null?"":rs.get("keywordIds").toString());
				
				list.add(caseVoObj);
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		} 
		return list;
	}

	
	public ArrayList<EntityVo> getProfileBySnapshots(int snapshotId)
	{
		ArrayList<EntityVo> lstEntity=new ArrayList<>();
		String query=" SELECT entity_name, entity_id, entity_type, entity_source_type, entity_url, "
				   + " entity_img, tw_id, fbType, varifiedUserFlag "
				   + " FROM tbl_case_profile "
				   + " WHERE snapshot_id='"+snapshotId+"'";
		System.out.println("SnapShotProfile::: "+query);
		
		List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
		for(Map<String,Object> rs : rows)
		{
			EntityVo entityVo=new EntityVo();
			entityVo.setEntityName(rs.get("entity_name")==null?"":rs.get("entity_name").toString().trim());
			entityVo.setEntitySocialId(rs.get("entity_id")==null?"":rs.get("entity_id").toString().trim());
			entityVo.setEntityType(rs.get("entity_type")==null?"":rs.get("entity_type").toString().trim());
			entityVo.setTwId(rs.get("tw_id")==null?"":rs.get("tw_id").toString().trim());
			entityVo.setEntitySourceType(rs.get("entity_source_type")==null?"":rs.get("entity_source_type").toString().trim());
			entityVo.setEntityUrl(rs.get("entity_url")==null?"":rs.get("entity_url").toString().trim());
			entityVo.setEntityStats("0");
			entityVo.setEntityImg(rs.get("entity_img")==null?"":rs.get("entity_img").toString().trim());
			entityVo.setFbType(rs.get("fbType")==null?"":rs.get("fbType").toString().trim());
			entityVo.setVarifiedUserFlag(rs.get("varifiedUserFlag")==null?"":rs.get("varifiedUserFlag").toString().trim());
			lstEntity.add(entityVo);
		}
		return lstEntity;
	}
	
	
	public ArrayList<String> getNewsSourceBySnapshots(int snapshotId)
	{
		ArrayList<String> lstEntity=new ArrayList<>();
		String query="Select news_source  from tbl_case_news_source where snapshot_id='"+snapshotId+"'";
		System.out.println("getNewsSourceBySnapshots::: "+query);
		List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
		for(Map<String,Object> rs : rows)
		{
			lstEntity.add(rs.get("news_source")==null?"":rs.get("news_source").toString().trim());
		}
		return lstEntity;
	}

	public ArrayList<String> getNewsWebsiteBySnapshots(int snapshotId)
	{
		ArrayList<String> lstEntity=new ArrayList<>();
		String query="Select news_website from tbl_case_news_website where snapshot_id='"+snapshotId+"'";
		System.out.println("getNewsWebsiteBySnapshots::: "+query);
		List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
		
		for(Map<String,Object> rs : rows)
		{
			lstEntity.add(rs.get("news_website")==null?"":rs.get("news_website").toString().trim());
		}
		return lstEntity;
	}
	
	public ArrayList<String> getNewsFTPBySnapshots(int snapshotId)
	{
		ArrayList<String> lstEntity=new ArrayList<>();
		String query="Select news_ftp from tbl_case_news_ftp where snapshot_id='"+snapshotId+"'";
		System.out.println("getNewsFTPBySnapshots::: "+query);
		List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
		
		for(Map<String,Object> rs : rows)
		{
			lstEntity.add(rs.get("news_ftp")==null?"":rs.get("news_ftp").toString().trim());
		}
		return lstEntity;
	}
	
	public ArrayList<String> getWhtasAppSourceBySnapshots(int snapshotId)
	{
		ArrayList<String> lstEntity=new ArrayList<>();
		String query="Select * from tbl_case_whatsup_group where snapshot_id='"+snapshotId+"'";
		System.out.println("getWhtasAppSourceBySnapshots::: "+query);
		List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
		for(Map<String,Object> rs : rows)
		{
			String groupName=rs.get("group_name").toString().trim();
			String groupId=rs.get("group_id").toString().trim();
			String sourceType=rs.get("source_type").toString().trim();
			lstEntity.add(groupName+"&&&&&&"+groupId+"&&&&&&"+sourceType);
		}
		return lstEntity;
	}

	

	@Override
	public void deleteSaveFilter(SaveFilterVo saveFilterVo) 
	{
		String query=null;
		try 
		{
			query="delete from tbl_save_filter where id='"+saveFilterVo.getId()+"'";
			System.out.println("deleteSearchCrawler== "+query);
			jdbcTemplate.update(query);			
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
	}

	
	@Override
	public ArrayList<SaveFilterVo> getFilterValues(SaveFilterVo saveFilterVo) 
	{
		ArrayList<SaveFilterVo> list=new ArrayList<SaveFilterVo>();
		try 
		{
			String query="SELECT tbl_save_filter.id, tbl_save_filter.case_id, tbl_save_filter.search_name, "+
					"tbl_save_filter.login_id, tbl_save_filter.global_search, tbl_save_filter.date_search, tbl_save_filter.advance_search, "+
					"tbl_save_filter.hashtag_include, tbl_save_filter.hashtag_exclude, tbl_save_filter.user_include, tbl_save_filter.user_exclude, "+
					"tbl_save_filter.mention_include, tbl_save_filter.mention_exclude, tbl_save_filter.org_include, tbl_save_filter.org_exclude, "+
					"tbl_save_filter.link_include, tbl_save_filter.link_exclude, tbl_save_filter.map_include, tbl_save_filter.map_exclude, "+
					"tbl_save_filter.img_include, tbl_save_filter.img_exclude, tbl_save_filter.video_include, tbl_save_filter.video_exclude, "+
					"tbl_save_filter.place_include, tbl_save_filter.place_exclude, tbl_save_filter.person_include, tbl_save_filter.person_exclude, doe, "
				  + " lang_include, lang_exclude, user_location_include, user_location_exclude, location_name, latitude, longitude, radius_in_km, es_query, keywordIds "+
					"FROM tbl_save_filter "+
					"WHERE tbl_save_filter.id='"+saveFilterVo.getId()+"'";	
			
			System.out.println("get search Filter Values======= "+query);			
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);		
			for(Map<String,Object> rs : rows)
			{
				SaveFilterVo caseVoObj=new SaveFilterVo();
				caseVoObj.setId(Integer.parseInt(rs.get("id")==null?"":rs.get("id").toString()));
				caseVoObj.setSearchName(rs.get("search_name")==null?"":rs.get("search_name").toString());
				caseVoObj.setCaseId(Integer.parseInt(rs.get("case_id")==null?"":rs.get("case_id").toString()));
				caseVoObj.setLoginId(Integer.parseInt(rs.get("login_id")==null?"":rs.get("login_id").toString()));
				caseVoObj.setGlobalSearch(rs.get("global_search")==null?"":rs.get("global_search").toString());
				caseVoObj.setDateSearch(rs.get("date_search")==null?"":rs.get("date_search").toString());
				caseVoObj.setAdvanceSearch(rs.get("advance_search")==null?"":rs.get("advance_search").toString());
				caseVoObj.setHashtagInclude(rs.get("hashtag_include")==null?"":rs.get("hashtag_include").toString());
				caseVoObj.setHashtagExclude(rs.get("hashtag_exclude")==null?"":rs.get("hashtag_exclude").toString());
				caseVoObj.setUserInclude(rs.get("user_include")==null?"":rs.get("user_include").toString());
				caseVoObj.setUserExclude(rs.get("user_exclude")==null?"":rs.get("user_exclude").toString());
				caseVoObj.setMentionInclude(rs.get("mention_include")==null?"":rs.get("mention_include").toString());
				caseVoObj.setMentionExclude(rs.get("mention_exclude")==null?"":rs.get("mention_exclude").toString());
				caseVoObj.setOrgInclude(rs.get("org_include")==null?"":rs.get("org_include").toString());
				caseVoObj.setOrgExclude(rs.get("org_exclude")==null?"":rs.get("org_exclude").toString());
				caseVoObj.setLinkInclude(rs.get("link_include")==null?"":rs.get("link_include").toString());
				caseVoObj.setLinkExclude(rs.get("link_exclude")==null?"":rs.get("link_exclude").toString());				
				caseVoObj.setImgInclude(rs.get("img_include")==null?"":rs.get("img_include").toString());
				caseVoObj.setImgExclude(rs.get("img_exclude")==null?"":rs.get("img_exclude").toString());
				caseVoObj.setVideoInclude(rs.get("video_include")==null?"":rs.get("video_include").toString());
				caseVoObj.setVideoExclude(rs.get("video_exclude")==null?"":rs.get("video_exclude").toString());
				caseVoObj.setPlaceInclude(rs.get("place_include")==null?"":rs.get("place_include").toString());
				caseVoObj.setPlaceExclude(rs.get("place_exclude")==null?"":rs.get("place_exclude").toString());
				caseVoObj.setPrsnInclude(rs.get("person_include")==null?"":rs.get("person_include").toString());
				caseVoObj.setPrsnExclude(rs.get("person_exclude")==null?"":rs.get("person_exclude").toString());
				caseVoObj.setDoe(rs.get("doe")==null?"":rs.get("doe").toString());				
				caseVoObj.setLangExclude(rs.get("lang_exclude")==null?"":rs.get("lang_exclude").toString());
				caseVoObj.setLangInclude(rs.get("lang_include")==null?"":rs.get("lang_include").toString());						
				caseVoObj.setMapInclude(rs.get("map_include")==null?"":rs.get("map_include").toString());
				caseVoObj.setMapExclude(rs.get("map_exclude")==null?"":rs.get("map_exclude").toString());
				caseVoObj.setMapUserInclude(rs.get("user_location_include")==null?"":rs.get("user_location_include").toString());
				caseVoObj.setMapUserExclude(rs.get("user_location_exclude")==null?"":rs.get("user_location_exclude").toString());
				caseVoObj.setLocationName(rs.get("location_name")==null?"":rs.get("location_name").toString());
				caseVoObj.setLatitude(rs.get("latitude")==null?"":rs.get("latitude").toString());
				caseVoObj.setLongitude(rs.get("longitude")==null?"":rs.get("longitude").toString());
				caseVoObj.setRadiusInKM(rs.get("radius_in_km")==null?"":rs.get("radius_in_km").toString());
				caseVoObj.setEsQuery(rs.get("es_query")==null?"":rs.get("es_query").toString());
				caseVoObj.setKeywordIds(rs.get("keywordIds")==null?"":rs.get("keywordIds").toString());
				
				list.add(caseVoObj);
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		} 
		return list;
	}

	
	@Override
	public void accountinsrt(AccountAliasVo accountAliasVo) 
	{
		try 
		{
			String query1=" insert ignore into tbl_profile(profile_name,photo,cover_photo,age,sex,address) values(?,?,?,?,?,?)";
			String query2=" insert ignore into tbl_profile_alias(profile_name,photo,cover_photo,age,sex,address) values(?,?,?,?,?,?)";
			String query3=" insert ignore into tbl_profile_contact(profile_name,photo,cover_photo,age,sex,address) values(?,?,?,?,?,?)";
			String query4=" insert ignore into tbl_profile_social_account(profile_name,photo,cover_photo,age,sex,address) values(?,?,?,?,?,?)";
			Object[] obj=new Object[]{accountAliasVo.getProflName().trim(),accountAliasVo.getPhoto().trim(),accountAliasVo.getCoverPhoto().trim(),accountAliasVo.getAge().trim(),accountAliasVo.getSex().trim(),accountAliasVo.getAddress().trim()};
			jdbcTemplate.update(query1, obj);
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
	}

	
	@Override
	public ArrayList<EntityVo> entitySelectByFilter(CaseVo caseVo)
	{
		String user=(String)httpSession.getAttribute(ApplicationConstants.LOGIN_USER);
		ArrayList<EntityVo> lst=new ArrayList<EntityVo>();
		try 
		{
			String	query="	SELECT distinct TRIM(tbl_entity.entity_name) as entity_name,tbl_entity.entity_id,tbl_entity.id"
					+ " ,tbl_entity.id,tw_id "+
					" FROM tbl_entity ";
			//+ " INNER JOIN  tbl_login_entity  ON  tbl_login_entity.entity_id=tbl_entity.id ";
			String subQuery="";
			if(!caseVo.getCaseId().trim().equals("0"))
			{
				query+=" INNER JOIN tbl_case_entity  ON tbl_case_entity.entity_id=tbl_entity.id ";
				subQuery=" and tbl_case_entity.case_id='"+caseVo.getCaseId()+"'  ";
			}
			query+=" where tbl_entity.entity_source_type='"+caseVo.getCaseType()+"' and tbl_entity.entity_type='"+caseVo.getActType()+"'";

			if(caseVo.getCaseType().equals("fb"))
			{
				query+=" and tbl_entity.fbtype='"+caseVo.getType()+"'";
			}


			if(caseVo.getCaseName() !=null && caseVo.getCaseName().length()>0)
			{
				query+=" and  tbl_entity.entity_name like'%"+caseVo.getCaseName()+"%'";	
			}

			query+=subQuery;

			System.out.println("entitySelectByFilter==="+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs : rows){
				EntityVo entityVo=new EntityVo();
				entityVo.setEntityName(rs.get("entity_name")==null?"":rs.get("entity_name").toString().trim());
				entityVo.setEntitySocialId(rs.get("entity_id")==null?"":rs.get("entity_id").toString().trim());
				entityVo.setId(rs.get("id")==null?"":rs.get("id").toString().trim());
				entityVo.setTwId(rs.get("tw_id")==null?"":rs.get("tw_id").toString().trim());
				lst.add(entityVo);
			}
			if(log.isInfoEnabled())
			{
				log.info("User Name------>"+user+"    method=========entitySelectAll()  "+"sql============"+query);
			}

		}catch (Exception e) {
			e.printStackTrace();
		} 
		return lst;
	}

	@Override
	public ArrayList<CaseVo> selectAllCase(CaseVo caseVo) {
		String user=(String)httpSession.getAttribute(ApplicationConstants.LOGIN_USER);

		ArrayList<CaseVo> lst=new ArrayList<CaseVo>();
		//JdbcTemplate jdbcTemplate=new JdbcTemplate(dataSource);
		String userId=(String)httpSession.getAttribute(ApplicationConstants.LOGINUSERID);
		String userRole=(String)httpSession.getAttribute(ApplicationConstants.USERROLE);
		try {
			String  query=null;
			Object[] obj=null;
			//Select All Cases	
			String subQuery=",'' as entity "; //(SELECT GROUP_CONCAT(tbl_case_entity.entity_id) FROM tbl_case_entity WHERE tbl_case_entity.case_id=tbl_case.id) AS entity";
			{
				String userId1=userId;
				if(CommonUtils.stringNotEmpty(caseVo.getUid()))
				{
					userId1=caseVo.getUid().trim();
				}

				query="select case_name,id,(select count(entity_id) from tbl_case_entity where case_id=tbl_case.id) as entityCount,cast(mark as char(2)) as mark , "
						+ "  COALESCE(DATE_FORMAT((date_of_creation),'%b %d,%Y %r'),'') as dateOfCreation,case_type   "+subQuery
						+ " from tbl_case  where ";

				//Select Case of Particular user By Admin
				if(!userId1.equals(userId))
				{
					query+= "  login_id="+userId1+" and ";
				}

				//Case Of Particular User
				if(userRole.toLowerCase().equals("u"))
				{
					query+= "  login_id="+userId+" and ";
				}

				query+= " case_name like ?";
				if(CommonUtils.stringNotEmpty(caseVo.getFilter()))  //if filter is aplly 
				{
					query+=" and case_type in("+TwitterConstant.splitCommonValues(caseVo.getFilter())+")";
				}

				if(CommonUtils.stringNotEmpty(caseVo.getNotFilter()))  //if not filter is aplly 
				{
					query+=" and case_type not in("+TwitterConstant.splitCommonValues(caseVo.getNotFilter())+")";
				}


				if(CommonUtils.stringNotEmpty(caseVo.getMark()))  // FILTER MARKED CASE
				{
					query+=" and mark='"+caseVo.getMark()+"' ";
				}
				query+=" order by ";
				switch(caseVo.getSort().toLowerCase())
				{
				case "da": // date_of_creation asc
					query+=" date_of_creation asc ";
					break;
				case "dd": // date_of_creation desc
					query+=" date_of_creation desc   ";
					break;
				case "na": // name asc
					query+="  case_name asc ";
					break;
				case "nd": // name desc
					query+="  case_name desc ";
					break;
				case "ena":  // entity count asc
					query+=" entityCount asc";
					break;
				case "end":  // entity count desc
					query+=" entityCount desc";
					break;
				}
				System.out.println("Select All Cases=="+query);
				obj=new Object[]{"%"+caseVo.getCaseName()+"%"};
				List<Map<String,Object>> rows = jdbcTemplate.queryForList(query,obj);
				for(Map<String,Object> rs : rows){
					CaseVo inCaseVo=new CaseVo();
					inCaseVo.setCaseId(rs.get("id")==null?"":rs.get("id").toString());
					inCaseVo.setCaseName(rs.get("case_name")==null?"":rs.get("case_name").toString());
					inCaseVo.setNoOfEntity(rs.get("entityCount")==null?"":rs.get("entityCount").toString());
					inCaseVo.setDateOfCreation(rs.get("dateOfCreation")==null?"":rs.get("dateOfCreation").toString());
					inCaseVo.setCaseType(rs.get("case_type")==null?"":rs.get("case_type").toString());
					inCaseVo.setMark(rs.get("mark")==null?"":rs.get("mark").toString());
					inCaseVo.setEntityIdLst(rs.get("entity")==null?"":rs.get("entity").toString());
					lst.add(inCaseVo);
				}
			}
			if(log.isInfoEnabled())
			{
				log.info("User Name------>"+user+"    method=========selectCase()  "+"sql============"+query);
			}

		}catch (Exception e) {
			e.printStackTrace();
			log.error("---------caseCrud----------",e);
		} 
		return lst;
	}

	@Override
	public ArrayList<EntityVo> getEntityNameIdFromCase(CaseVo caseVo) 
	{
		ArrayList<EntityVo> lst=new ArrayList<>();
		try 
		{
			String query="SELECT id, search_name FROM tbl_save_filter WHERE case_id='"+caseVo.getCaseId()+"' order by id desc";
			System.out.println("getAllSnapshots of case:: "+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			if(rows.size() > 0) 
			{
				for(Map<String,Object> rs : rows)
				{
					EntityVo entityVo=new EntityVo();
					entityVo.setEntityName(rs.get("search_name")==null?"":rs.get("search_name").toString());
					entityVo.setId(rs.get("id")==null?"":rs.get("id").toString());
					entityVo.setCaseId(caseVo.getCaseId());
					lst.add(entityVo);
				}
			}

			/* if(caseVo.getCaseType().toLowerCase().equals("e") || caseVo.getCaseType().toLowerCase().equals("a"))
			{
				StringBuilder str=new StringBuilder();
				str.append("SELECT ");
				str.append("DISTINCT tbl_entity.entity_name ");
				str.append("FROM tbl_entity ");
				str.append("INNER JOIN  ");
				str.append("tbl_case_entity ON tbl_entity.id=tbl_case_entity.entity_id "); 
				str.append("INNER JOIN  tbl_case ON ");
				str.append("tbl_case_entity.case_id = tbl_case.id ");
				str.append("AND tbl_entity.entity_type='k' ");
				str.append("AND tbl_case.id='"+caseVo.getCaseId()+"'");
				System.out.println("getKeywordEntityNameIdFromCase:: "+str.toString());
				List<Map<String,Object>> rows = jdbcTemplate.queryForList(str.toString());
				if(rows.size()>0)
				{
					for(Map<String,Object> rs : rows){
						EntityVo entityVo=new EntityVo();
						entityVo.setEntityName(rs.get("entity_name")==null?"":rs.get("entity_name").toString());
						entityVo.setEntityType("k");
						lst.add(entityVo);
					}
				}
			}

			if(caseVo.getCaseType().toLowerCase().equals("p") || caseVo.getCaseType().toLowerCase().equals("a"))
			{
				StringBuilder str=new StringBuilder();
				str.append("SELECT ");
				str.append("DISTINCT tbl_entity.entity_id, tbl_entity.entity_source_type ");
				str.append("FROM tbl_entity ");
				str.append("INNER JOIN  ");
				str.append("tbl_case_entity ON tbl_entity.id=tbl_case_entity.entity_id "); 
				str.append("INNER JOIN  tbl_case ON ");
				str.append("tbl_case_entity.case_id = tbl_case.id ");
				str.append("AND tbl_entity.entity_type='p' ");
				str.append("AND tbl_case.id='"+caseVo.getCaseId()+"' ");
				System.out.println("getPrfoileEntityNameIdFromCase:: "+str.toString());

				List<Map<String,Object>> rows = jdbcTemplate.queryForList(str.toString());
				if(rows.size()>0)
				{
					for(Map<String,Object> rs : rows){
						EntityVo entityVo=new EntityVo();
						entityVo.setEntityName(rs.get("entity_id")==null?"":rs.get("entity_id").toString());
						entityVo.setEntitySourceType(rs.get("entity_source_type").toString());
						entityVo.setEntityType("p");
						lst.add(entityVo);
					}
				}
			}

			if(caseVo.getCaseType().toLowerCase().equals("l") || caseVo.getCaseType().toLowerCase().equals("a"))
			{
				StringBuilder str=new StringBuilder();
				str.append("SELECT ");
				str.append("DISTINCT tbl_entity.entity_id ");
				str.append("FROM tbl_entity ");
				str.append("INNER JOIN  ");
				str.append("tbl_case_entity ON tbl_entity.id=tbl_case_entity.entity_id "); 
				str.append("INNER JOIN  tbl_case ON ");
				str.append("tbl_case_entity.case_id = tbl_case.id ");
				str.append("AND tbl_entity.entity_type='l' ");
				str.append("AND tbl_case.id='"+caseVo.getCaseId()+"' ");
				System.out.println("getLocationEntityNameIdFromCase:: "+str.toString());

				List<Map<String,Object>> rows = jdbcTemplate.queryForList(str.toString());
				if(rows.size()>0)
				{
					for(Map<String,Object> rs : rows){
						EntityVo entityVo=new EntityVo();
						entityVo.setEntityName(rs.get("entity_id")==null?"":rs.get("entity_id").toString());
						entityVo.setEntityType("l");
						lst.add(entityVo);
					}
				}
			}
			 */		
		} 
		catch(Exception e)
		{
			e.printStackTrace();
		} 
		return lst;
	}

	@Override
	public ArrayList<CaseVo> getProxyAvatar(CaseVo caseVo) 
	{
		ArrayList<CaseVo> lst=new ArrayList<CaseVo>();
		try 
		{
			String query=" SELECT id, proxy_ip, port, country, country_code "
				   	   + " FROM tbl_crawl_proxy "
				   	   + " WHERE proxy_ip like '%"+caseVo.getCaseName()+"%' ORDER BY id DESC ";
			System.out.println("getProxyAvatar: "+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			
			for(Map<String,Object> rs : rows)
			{
				CaseVo caseVoObj=new CaseVo();
				caseVoObj.setId(rs.get("id")==null?"":rs.get("id").toString());
				caseVoObj.setKey1(rs.get("proxy_ip")==null?"":rs.get("proxy_ip").toString());
				caseVoObj.setKey2(rs.get("port")==null?"":rs.get("port").toString());
				caseVoObj.setKey3(rs.get("country")==null?"":rs.get("country").toString());
				caseVoObj.setKey4(rs.get("country_code")==null?"":rs.get("country_code").toString());
				lst.add(caseVoObj);
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		} 
		return lst;
	}

	@Override
	public void addProxyAvatar(CaseVo caseVo) 
	{
		String query="";
		try 
		{
			if(caseVo.getId().equals(""))
			{
				query=" INSERT ignore into tbl_crawl_proxy(proxy_ip,port,country,country_code) values(?,?,?,?)";
				System.out.println("Proxy Insert: "+query);
				Object[] obj=new Object[]{caseVo.getKey1().trim(),
						caseVo.getKey2().trim(),
						caseVo.getKey3().trim(),
						caseVo.getKey4().trim()};
				jdbcTemplate.update(query,obj);
			}
			else 
			{
				query=" UPDATE tbl_crawl_proxy set proxy_ip='"+caseVo.getKey1()+"', port='"+caseVo.getKey2()+"', country='"+caseVo.getKey3()+"', country_code='"+caseVo.getKey4()+"' "
					+ " WHERE id='"+caseVo.getId()+"' ";
				System.out.println("Proxy UPdate Query: "+query);
				jdbcTemplate.update(query);
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}

	@Override
	public ArrayList<CaseVo> dltProxyIP(CaseVo caseVo) 
	{
		ArrayList<CaseVo> list=new ArrayList<CaseVo>();
		try 
		{
			String query=null;
			query= " DELETE from tbl_crawl_proxy "
				 + " WHERE id= '"+caseVo.getId()+"' " ;
			System.out.println("Delete Proxy: "+query);
			jdbcTemplate.update(query);
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		} 
		return list;	
	}

	@Override
	public ArrayList<CaseVo> getProxyCountry(CaseVo caseVo) 
	{
		ArrayList<CaseVo> list=new ArrayList<CaseVo>();
		try 
		{
			String query=" SELECT DISTINCT country, code "
					   + " FROM countrycodes "
					   + " ORDER BY country";
			System.out.println("getProxyCountry ::"+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs : rows)
			{
				CaseVo caseVoObj=new CaseVo();
				caseVoObj.setId(rs.get("id")==null?"":rs.get("id").toString());
				caseVoObj.setKey1(rs.get("country")==null?"":rs.get("country").toString());
				caseVoObj.setKey2(rs.get("code")==null?"":rs.get("code").toString());
				list.add(caseVoObj);
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		} 
		return list;
	}


	//*********USER PROFILR VIEW REPORT****************************************************************//
	@Override
	public boolean addUserProfileBasicInformations(UserProfileBasicInformationVo basicInformationVo) throws FileNotFoundException {  
		int statusUpdate=1;
		String type = "P";
		String userName =(String)httpSession.getAttribute(ApplicationConstants.LOGINUSERID);		

		try {		
			String insertQuery = "insert into tbl_profile(first_name, last_name, profile_photo_id, profile_cover_photo_id, permanent_address, "   
					+ "local_address, father_name, mother_name, dob, gender, nationality, martial_status, addahar_card, "
					+ "pan_card, passport_no, description, classification, login_id) "
					+ " values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ";
			System.out.println("addUserProfileBasicInformations insertQuery: "+insertQuery);
			KeyHolder holder = new GeneratedKeyHolder();

			jdbcTemplate.update(new PreparedStatementCreator() {           
				@Override
				public PreparedStatement createPreparedStatement(Connection connection) throws SQLException {
					PreparedStatement ps = connection.prepareStatement(insertQuery, Statement.RETURN_GENERATED_KEYS);
					ps.setString(1, basicInformationVo.getFirstName().trim());
					ps.setString(2, basicInformationVo.getLastName().trim());
					ps.setInt(3, basicInformationVo.getProfilePhotoId());
					ps.setInt(4, basicInformationVo.getProfileCoverPhotoId());					   
					ps.setString(5, basicInformationVo.getPermanentAddress().trim());
					ps.setString(6, basicInformationVo.getLocalAddress().trim());
					ps.setString(7, basicInformationVo.getFatherName().trim());
					ps.setString(8, basicInformationVo.getMotherName().trim());					 
					ps.setString(9, basicInformationVo.getDob());					
					ps.setString(10, basicInformationVo.getGender().trim());
					ps.setString(11, basicInformationVo.getNationality().trim());
					ps.setString(12, basicInformationVo.getMartialStatus().trim());
					ps.setString(13, basicInformationVo.getAddaharCard().trim());
					ps.setString(14, basicInformationVo.getPanCard().trim());
					ps.setString(15, basicInformationVo.getPassportNo().trim());
					ps.setString(16, basicInformationVo.getDescription().trim());
					ps.setString(17, basicInformationVo.getClassification().trim());
					ps.setInt(18, Integer.parseInt(userName));										
					return ps;  
				}   
			}, holder);   

			int tblprofileId = holder.getKey().intValue();

			//TO ADDING ALIAS INFO.
			String[] aliasArray = basicInformationVo.getAlias().split(",");		 
			for(int i = 0; i < aliasArray.length; i++) 
			{
				String aliasInsertQuery = "insert ignore into tbl_profile_alias(profile_id, alias)"
						+ " values(?,?) ";
				System.out.println("aliasInsertQuery: "+aliasInsertQuery);
				jdbcTemplate.update(aliasInsertQuery, new Object[] {
						tblprofileId, 
						aliasArray[i].trim()
				});				
			} 

			//TO ADDING ALIAS IN tbl_ner_alias TABLE.
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");  
			Date date = new Date();  
			String strDate = formatter.format(date);
			System.out.println(strDate);

			for(int i = 0; i < aliasArray.length; i++) 
			{
				String nerAliasInsertQuery = "insert ignore into tbl_ner_alias(firstName, lastName, alias, type, date_of_insertion, login_id, target_id)"
						+ " values(?,?,?,?,?,?,?) ";
				System.out.println("nerAliasInsertQuery: "+nerAliasInsertQuery);
				jdbcTemplate.update(nerAliasInsertQuery, new Object[] {
						basicInformationVo.getFirstName().trim(), 
						basicInformationVo.getLastName().trim(),					
						aliasArray[i].trim(),
						type,
						strDate,
						userName,
						tblprofileId
				});				
			} 

			//TO SET PROFILE ID IN SESSION.			    
			httpSession.setAttribute("profileId", tblprofileId);		

			//UPDATE THE STATUS=1 FIELD OF tbl_profile_user_photo TABLE
			String updateQuery = "UPDATE tbl_profile_user_photo SET status="+statusUpdate+", profile_id="+tblprofileId+" "
					+ "WHERE id="+basicInformationVo.getProfilePhotoId()+" or id="+basicInformationVo.getProfileCoverPhotoId()+" ";		
			jdbcTemplate.update(updateQuery);
			System.out.println("updateQuery: "+updateQuery);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println(e.getMessage());
		}				 		 		 
		return true;	
	}
	
	@Override
	public boolean addUsersProfilePhotoForUpload(MultipartFile file) {
		
		String UPLOAD_DIRECTORY = TwitterConstant.getPersonProfile();
		
		String fileName = "";
		long fileUploadTime = new Date().getTime();
		String fileExtension = getFileExtension(convert(file));  
		
		try {
			ServletContext context = httpSession.getServletContext();
			
			fileName = UPLOAD_DIRECTORY+File.separator+fileUploadTime+fileExtension;
			System.out.println("File : "+fileName);
			
		    byte[] bytes = file.getBytes();
		    BufferedOutputStream stream =new BufferedOutputStream(new FileOutputStream(new File(fileName)));
		    stream.write(bytes);
		    stream.flush();
		    stream.close();
			
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		
		String photoType = "profilePhoto";
		String insertQuery = "Insert into tbl_profile_user_photo(photo_path, photo_type, status, profile_id) values(?,?,?,?) ";
		System.out.println("addUsersProfilePhotoForUpload insertQuery: "+insertQuery);
		
		KeyHolder holder = new GeneratedKeyHolder();
		final String finalFileName = fileUploadTime+fileExtension;
		try {
			jdbcTemplate.update(new PreparedStatementCreator() {
				@Override
				public PreparedStatement createPreparedStatement(Connection connection) throws SQLException {
					PreparedStatement ps = connection.prepareStatement(insertQuery, Statement.RETURN_GENERATED_KEYS);
					ps.setString(1, finalFileName);
					ps.setString(2, photoType);
					ps.setInt(3, 0);
					ps.setInt(4, 0);
					return ps;
				}   
			}, holder);  

			int profileUserPhotoId = holder.getKey().intValue();
			//TO SET PROFILE USER PHOTO ID IN SESSION.			    
			httpSession.setAttribute("userProfilePhoto", profileUserPhotoId);
			
		} catch(Exception ex) {
			ex.printStackTrace();
			System.out.println(ex.getMessage());
		}
		
		return true;
	}
	
	@Override
	public boolean addSuspectPhotoForUpload(MultipartFile file, String profileId) {
		String UPLOAD_DIRECTORY = TwitterConstant.getSuspectPhotos();
		
		String fileName = "";
		//long fileUploadTime = new Date().getTime();
		UUID uuid = UUID.randomUUID();
		String fileExtension = getFileExtension(convert(file));
		
		try {
			ServletContext context = httpSession.getServletContext();
			
			fileName = UPLOAD_DIRECTORY+File.separator+uuid+fileExtension;
			System.out.println("File : "+fileName);
			
		    byte[] bytes = file.getBytes();
		    BufferedOutputStream stream =new BufferedOutputStream(new FileOutputStream(new File(fileName)));
		    stream.write(bytes);
		    stream.flush();
		    stream.close();
			
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		
		//String photoType = "profilePhoto";
		String insertQuery = "insert into tbl_suspect_profile_photo(profile_id, uuid, status, inserted_date, updated_date) values(?,?,?,?,?) ";
		System.out.println("addSuspectPhotoForUpload insertQuery: "+insertQuery);

		KeyHolder holder = new GeneratedKeyHolder();
		final String finalFileName = uuid+fileExtension;
		try {
			jdbcTemplate.update(new PreparedStatementCreator() {
				@Override
				public PreparedStatement createPreparedStatement(Connection connection) throws SQLException {
					PreparedStatement ps = connection.prepareStatement(insertQuery, Statement.RETURN_GENERATED_KEYS);					  
					ps.setString(1, profileId);
					ps.setString(2, finalFileName);
					ps.setString(3, "0");		
					ps.setString(4, CommonUtils.getSqlCurrentDateTime());
					ps.setString(5, CommonUtils.getSqlCurrentDateTime());
					return ps;  
				}   
			}, holder);  

			int suspectPhotoId = holder.getKey().intValue();
			//TO SET PROFILE USER PHOTO ID IN SESSION.
			//httpSession.setAttribute("suspectPhotos", suspectPhotoId);
			
		} catch(Exception ex) {
			ex.printStackTrace();
			System.out.println(ex.getMessage());
		}
		
		return true;
	}
	
	private static String getFileExtension(File file) {
        String extension = ""; 
        try {
            if (file != null && file.exists()) {
                String name = file.getName();
                extension = name.substring(name.lastIndexOf("."));
            }
        } catch (Exception e) {
            extension = "";
        } 
        return extension; 
    }
	
	public File convert(MultipartFile file) {  		
		File convFile = new File(file.getOriginalFilename());		
		try {	    
		    convFile.createNewFile(); 
		    FileOutputStream fos = new FileOutputStream(convFile); 
		    fos.write(file.getBytes());
		    fos.close(); 
		}catch(Exception e) {
			e.printStackTrace();
		}
	    return convFile;
	}
	
	@Override
	public boolean addUsersProfileCoverPhotoForUpload(MultipartFile file) {
		
		String UPLOAD_DIRECTORY = TwitterConstant.getPersonProfile();
		
		String fileName = "";
		long fileUploadTime = new Date().getTime();
		String fileExtension = getFileExtension(convert(file));  
		
		try {
			ServletContext context = httpSession.getServletContext();
			
			fileName = UPLOAD_DIRECTORY+File.separator+fileUploadTime+fileExtension;
			System.out.println("File : "+fileName);
			
		    byte[] bytes = file.getBytes();
		    BufferedOutputStream stream =new BufferedOutputStream(new FileOutputStream(new File(fileName)));
		    stream.write(bytes);
		    stream.flush();
		    stream.close();
			
		}catch(Exception ex) {
			ex.printStackTrace();
		}
			
		String photoType = "coverPhoto";			      
		String insertQuery = "insert into tbl_profile_user_photo(photo_path, photo_type, status, profile_id) values(?,?,?,?) ";	
		System.out.println("addUsersProfileCoverPhotoForUpload insertQuery: "+insertQuery);
		
		final String finalFileName = fileUploadTime+fileExtension;
		KeyHolder holder = new GeneratedKeyHolder();
		try {
			jdbcTemplate.update(new PreparedStatementCreator() {           
			@Override
			public PreparedStatement createPreparedStatement(Connection connection) throws SQLException
			{
				PreparedStatement ps = connection.prepareStatement(insertQuery, Statement.RETURN_GENERATED_KEYS);
				ps.setString(1, finalFileName);
				ps.setString(2, photoType);
				ps.setInt(3, 0);
				ps.setInt(4, 0);
				return ps;
				}
			}, holder);

			int profileUserCoverPhotoId = holder.getKey().intValue();
			//TO SET PROFILE USER COVER PHOTO ID IN SESSION.			    
			httpSession.setAttribute("userProfileCoverPhoto", profileUserCoverPhotoId);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			System.out.println(ex.getMessage());
		}		 		 		 
		return true;
	}
		
	@Override
	public boolean addUserProfileAlias(UserProfileAliasVo aliasVo) 
	{
		int result=0;
		try
		{
			String insertQuery = "insert ignore into tbl_profile_alias(profile_id, alias) "
					+ " values(?,?) ";
			System.out.println("addUserProfileAlias insertQuery: "+insertQuery);
			result = jdbcTemplate.update(insertQuery, new Object[] {
					aliasVo.getProfileId(),
					aliasVo.getAlias().trim()
			});			
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		if(result>0)
		{
			return true;
		}			 
		else 
		{
			return false;
		}
	}

	@Override
	public boolean addUserProfileContact(UserProfileContactVo contactVo) 
	{
		int result=0;
		try
		{
			String insertQuery = "insert into tbl_profile_contact(profile_id, contact, contact_type, contact_primary) "
					+ " values(?,?,?,?) ";
			System.out.println("addUserProfileContact insertQuery: "+insertQuery);
			result = jdbcTemplate.update(insertQuery, new Object[] {
					contactVo.getProfileId(), 
					contactVo.getContact().trim(), 
					contactVo.getContactType().trim(), 
					contactVo.getContactPrimary().trim()
			});
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		if(result>0)
		{
			return true;
		}			 
		else 
		{
			return false;
		}
	}


	@Override
	public boolean addUserProfileSocialAccount(UserProfileSocialAccountVo socialAccountVo)
	{
		int result=0;
		try
		{
			String insertQuery = "insert into tbl_profile_social_account(profile_id, entity_name, "
					+ "entity_id, entity_source_type, entity_url, entity_img, tw_id) "
					+ " values(?,?,?,?,?,?,?) ";
			System.out.println("addUserProfileSocialAccount insertQuery: "+insertQuery);

			result = jdbcTemplate.update(insertQuery, new Object[] {
					socialAccountVo.getProfileId(), 
					socialAccountVo.getEntityName().trim(), 
					socialAccountVo.getEntitySocialId().trim(), 
					socialAccountVo.getEntitySourceType().trim(), 
					socialAccountVo.getEntityUrl().trim(), 
					socialAccountVo.getEntityImg().trim(),
					socialAccountVo.getTwId().trim()
			});	
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		if(result>0)
		{
			return true;
		}			 
		else 
		{
			return false;
		}	
	}


	@Override
	public boolean addUserProfileAssociatedFriends(UserProfileAssociatedFriendsVo associatedFriendsVo)
	{
		int result=0;
		try
		{
			String insertQuery = "insert into tbl_profile_associated_friends(id, profile_id, friend_user_id, "
					+ "user_name, user_screen_name, classification, friend_photo, social_media_type) "
					+ " values(?,?,?,?,?,?,?,?) ";
			System.out.println("addUserProfileAssociatedFriends insertQuery: "+insertQuery);

			result = jdbcTemplate.update(insertQuery, new Object[] {
					associatedFriendsVo.getProfileId(), 
					associatedFriendsVo.getProfileId(),
					associatedFriendsVo.getFriendUserId(), 
					associatedFriendsVo.getUserName(), 
					associatedFriendsVo.getUserScreenName(), 
					associatedFriendsVo.getClassification(),
					associatedFriendsVo.getFriendPhoto(), 
					associatedFriendsVo.getSocialMediaType()
			});
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}	
		if(result>0)
		{
			return true;
		}			 
		else 
		{
			return false;
		}			
	}


	@Override
	public boolean addUserProfileAssociatedHandles(UserProfileAssociatedHandlesVo associatedHandlesVo) 
	{
		int result=0;
		try
		{
			String insertQuery = "insert into tbl_profile_associated_handles(id, profile_id, user_id, "
					+ "user_name, user_screen_name, classification, photo, social_media_type) values(?,?,?,?,?,?,?,?) ";
			System.out.println("addUserProfileAssociatedHandles insertQuery: "+insertQuery);
			result = jdbcTemplate.update(insertQuery, new Object[] {
					associatedHandlesVo.getProfileId(), 
					associatedHandlesVo.getProfileId(),
					associatedHandlesVo.getUserId(), 
					associatedHandlesVo.getUserName(), 
					associatedHandlesVo.getUserScreenName(), 
					associatedHandlesVo.getClassification(),
					associatedHandlesVo.getPhoto(), 
					associatedHandlesVo.getSocialMediaType()
			});
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		if(result>0)
		{
			return true;
		}			 
		else 
		{
			return false;
		}			
	}


	@Override
	public boolean addUserProfileAssociatedEvents(UserProfileAssociatedEventsVo associatedEventsVo) 
	{
		int result=0;
		try
		{
			String insertQuery = "insert into tbl_profile_associated_event(profile_id, event_name, "
					+ "event_date, event_type, sentiment_of_event) "
					+ " values(?,?,?,?,?) ";
			System.out.println("addUserProfileAssociatedEvents insertQuery: "+insertQuery);

			result = jdbcTemplate.update(insertQuery, new Object[] {
					associatedEventsVo.getProfileId(), 
					associatedEventsVo.getEventName(), 
					CommonUtils.string2Date(associatedEventsVo.getEventDate()),
					associatedEventsVo.getEventType(), 
					associatedEventsVo.getSentimentOfEvent()				
			});
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		if(result>0)
		{
			return true;
		}			 
		else 
		{
			return false;
		}	
	}


	@Override
	public boolean addUserProfileAssociatedLocations(UserProfileAssociatedLocationsVo associatedLocationsVo) 
	{
		int result=0;
		try
		{
			String insertQuery = "insert into tbl_profile_associated_location(id, profile_id, location_name, "
					+ "frequency, sentiment_of_location) "
					+ " values(?,?,?,?,?) ";
			System.out.println("addUserProfileAssociatedLocations insertQuery: "+insertQuery);
			result = jdbcTemplate.update(insertQuery, new Object[] {
					associatedLocationsVo.getProfileId(), 
					associatedLocationsVo.getProfileId(),
					associatedLocationsVo.getLocationName(), 
					associatedLocationsVo.getFrequency(), 
					associatedLocationsVo.getSentimentOfLocation()
			});
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		if(result>0)
		{
			return true;
		}			 
		else 
		{
			return false;
		}		
	}


	@Override
	public boolean addUserProfileAssociatedOrganizations(UserProfileAssociatedOrganizationsVo associatedOrganizationsVo) 
	{
		int result=0;
		try
		{
			String insertQuery = "insert into tbl_profile_associated_organization(id, profile_id, organization_name, "
					+ "frequency, org_category) "
					+ " values(?,?,?,?,?) ";
			System.out.println("addUserProfileAssociatedOrganizations insertQuery: "+insertQuery);

			result = jdbcTemplate.update(insertQuery, new Object[] {
					associatedOrganizationsVo.getProfileId(), 
					associatedOrganizationsVo.getProfileId(),
					associatedOrganizationsVo.getOrganizationName(), 
					associatedOrganizationsVo.getFrequency(), 
					associatedOrganizationsVo.getOrganizationCategory()
			});
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		if(result>0)
		{
			return true;
		}			 
		else 
		{
			return false;
		}		
	}


	@Override
	public void addSrcUserAvatar(CaseVo caseVo) 
	{ 
		String query="";
		if(caseVo.getId().equals(""))
		{
			query=" INSERT ignore into tbl_crawl_avatar(first_name, last_name, email, phone, sex, dob, country, country_code, user_name, password, source, created_time) values(?,?,?,?,?,?,?,?,?,?,?,now())";
			System.out.println("Add Avatar:::"+query);
			Object[] obj=new Object[]{
					caseVo.getKey1().trim(),
					caseVo.getKey2().trim(),
					caseVo.getKey3().trim(),
					caseVo.getKey4().trim(),
					caseVo.getKey5().trim(),
					caseVo.getKey6().trim(),
					caseVo.getKey7().trim(),
					caseVo.getKey8().trim(),
					caseVo.getKey9().trim(),
					caseVo.getKey10().trim(),
					caseVo.getKey11().trim()};
			System.out.println("Add Avatar :: "+query);
			jdbcTemplate.update(query, obj);
		}
		else 
		{
			    query=" UPDATE tbl_crawl_avatar set first_name='"+caseVo.getKey1().trim()+"', last_name='"+caseVo.getKey2().trim()+"', email='"+caseVo.getKey3().trim()+"', "
					+ " phone='"+caseVo.getKey4().trim()+"', sex='"+caseVo.getKey5().trim()+"', dob='"+caseVo.getKey6().trim()+"', country='"+caseVo.getKey7().trim()+"', "
					+ " country_code='"+caseVo.getKey8().trim()+"', user_name='"+caseVo.getKey9().trim()+"', password='"+caseVo.getKey10().trim()+"', "
					+ " source='"+caseVo.getKey11().trim()+"' "
					+ " WHERE id="+caseVo.getId()+" ";
			System.out.println("Update Avatar :: "+query);
			jdbcTemplate.update(query);
		}
	}

	@Override
	public String addSrcUserCentralAvatar(CaseVo caseVo) 
	{
		String userName = (String) httpSession.getAttribute(ApplicationConstants.LOGIN_USER);
		String userId = (String) httpSession.getAttribute(ApplicationConstants.LOGINUSERID);
		String globalClientId = TwitterConstant.getGlobalClientId();
		System.out.println("userName: "+userName);
		System.out.println("userId: "+userId);
		System.out.println("globalClientId: "+globalClientId);
		String result="success";
		String restServiceResult="";
		
		try 
		{
			/*String query=" INSERT ignore into tbl_crawl_avatar(first_name, last_name, email, phone, "
					   + " dob, sex, country, country_code, source, user_name, password, created_time, "
					   + " global_client_id, avatar_created_by) "
					   + " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";*/
			String query=" INSERT ignore into tbl_crawl_avatar(first_name, last_name, email, phone, "
					   + " dob, sex, country, country_code, source, user_name, password, created_time, "
					   + " global_client_id, avatar_created_by) "
					   + " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			KeyHolder keyHolder = new GeneratedKeyHolder();
			jdbcTemplate.update(new PreparedStatementCreator() {
				public PreparedStatement createPreparedStatement(
						Connection connection) throws SQLException {
					PreparedStatement ps = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
					ps.setString(1, caseVo.getKey1().trim());
					ps.setString(2, caseVo.getKey2().trim());
					ps.setString(3, caseVo.getKey3().trim());
					ps.setString(4, caseVo.getKey4().trim());
					ps.setString(5, caseVo.getKey5().trim());
					ps.setString(6, caseVo.getKey6().trim());
					ps.setString(7, caseVo.getKey7().trim());
					ps.setString(8, caseVo.getKey8().trim());
					ps.setString(9, caseVo.getKey9().trim());
					ps.setString(10, caseVo.getKey10().trim());
					ps.setString(11, caseVo.getKey11().trim());
					ps.setString(12, CommonUtils.getSqlCurrentDateTime());
					ps.setString(13, globalClientId);
					ps.setString(14, userName.trim());
					return ps;
				}
			}, keyHolder);
			System.out.println("Add Central Avatar::: "+query);
			
			if(keyHolder.getKey()==null) {
				System.out.println("AutoIncreament key is null.");
				result="failure";
				return result;
			}
			int autoIncId = keyHolder.getKey().intValue();
			System.out.println("Auto Incremented Id is::: "+autoIncId);
			if(autoIncId==0) {
				System.out.println("autoIncId is 0");
				result="failure";
				return result;
			}
			
			caseVo.setAutoIncKeyId(String.valueOf(autoIncId));
			String avatarCatId = caseVo.getKey12();		
			System.out.println("avatarCatId: "+avatarCatId);
			Object[] obj=null;
			if(avatarCatId !=null) {
				String[] cat = avatarCatId.split(",");
				for(int i=0; i<cat.length; i++) {
					if(!cat[i].equals("")) {
						String insertQuery = " INSERT IGNORE INTO tbl_avatar_category(avatar_id, avatar_category, global_client_id) "
								+ " VALUES(?,?,?) ";
						obj=new Object[]{autoIncId, cat[i], globalClientId};
						jdbcTemplate.update(insertQuery, obj);
						System.out.println("Add Avatar category insertQuery: "+insertQuery);
						result="success";
					}																		
				}		
			}
			if(result.equals("success"))
			{
				caseVo.setUserId(userId);
				caseVo.setUserName(userName);
				caseVo.setGlobalClientId(globalClientId);
				caseVo.setDateOfCreation(CommonUtils.getSqlCurrentDateTime());
				caseVo.setAccountType("p");
				caseVo.setIsActive("1");
				caseVo.setSyncStatus("1");
				caseVo.setAddedFrom("client");
				restServiceResult = synchronizeAvatarToCentralCrawlerServer(caseVo);
			}						
		} catch(Exception ex) {
			restServiceResult="failure";
			ex.printStackTrace();
		}
		return restServiceResult;
	}
	
	public String synchronizeAvatarToCentralCrawlerServer(CaseVo caseVo)
	{
		String status="failure";
		try
		{					
			String postURL = TwitterConstant.getCentralCrawlingServerURL()+"avatar/syncSingleAvatarFromClient";
			System.out.println("postURL: "+postURL);				
			CentralAvatarVo centralAvatarVo = new CentralAvatarVo();
			centralAvatarVo.setFirstName(caseVo.getKey1());
			centralAvatarVo.setLastName(caseVo.getKey2());			
			centralAvatarVo.setEmail(caseVo.getKey3());	
			centralAvatarVo.setPhone(caseVo.getKey4());
			centralAvatarVo.setBirthDay(caseVo.getKey5());
			centralAvatarVo.setGender(caseVo.getKey6());
			centralAvatarVo.setCountry(caseVo.getKey7());
			centralAvatarVo.setCountryCode(caseVo.getKey8());
			centralAvatarVo.setSource(caseVo.getKey9());
			centralAvatarVo.setUserName(caseVo.getKey10());
			centralAvatarVo.setPassword(caseVo.getKey11());
			centralAvatarVo.setAvatarCategory(caseVo.getKey12());
			centralAvatarVo.setClientUserName(caseVo.getUserName());
			centralAvatarVo.setClientUserId(caseVo.getUserId());
			centralAvatarVo.setGlobalClientId(caseVo.getGlobalClientId());
			centralAvatarVo.setIsActive(caseVo.getIsActive());
			centralAvatarVo.setAccountType(caseVo.getAccountType());
			centralAvatarVo.setAvatarCreatedTime(caseVo.getDateOfCreation());
			centralAvatarVo.setAvatarAddedFrom(caseVo.getAddedFrom());
			centralAvatarVo.setSynchStatus(caseVo.getSyncStatus());
		
			try {
				String responseStr = HttpUtil.sendPostRequestForSynchronizeCentralAvatarDetails(postURL, gson.toJson(centralAvatarVo)); //throws Exception
				status="success";
				System.out.println("responseStr: "+responseStr);	
				if(responseStr.equals("success")) {
					String query = " UPDATE tbl_crawl_avatar "
							     + " SET synch_status='1' "
							     + " WHERE id= "+caseVo.getAutoIncKeyId()+" ";
					jdbcTemplate.update(query);
					System.out.println("Update SyncStatus query: "+query);
				}
			} catch(Exception ex) {
				status="failure";
				ex.printStackTrace();
			}
		} catch(Exception ex) {
			ex.printStackTrace();
		}
		return status;	
	}
	
	
	
	@Override
	public ArrayList<CaseVo> getSourcesAvatar(CaseVo caseVo)
	{
		ArrayList<CaseVo> list=new ArrayList<CaseVo>();
		try 
		{
			String query=" SELECT id ,first_name, last_name, email, phone, sex, dob, country, "
					   + " country_code, user_name, password, source, isActive, "
					   + " COALESCE(DATE_FORMAT((tbl_crawl_avatar.account_block_date),'%b %d,%Y %r'),'') as account_block_date "
					   + " FROM tbl_crawl_avatar "
					   + " WHERE first_name like '%"+caseVo.getCaseName()+"%' ORDER BY id DESC";
			System.out.println("getSourcesAvatar:::"+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			
			for(Map<String, Object> rs : rows) {
				CaseVo caseVoObj=new CaseVo();
				caseVoObj.setId(rs.get("id")==null?"":rs.get("id").toString());
				caseVoObj.setKey1(rs.get("first_name")==null?"":rs.get("first_name").toString());
				caseVoObj.setKey2(rs.get("last_name")==null?"":rs.get("last_name").toString());
				caseVoObj.setKey3(rs.get("email")==null?"":rs.get("email").toString());
				caseVoObj.setKey4(rs.get("phone")==null?"":rs.get("phone").toString());
				caseVoObj.setKey5(rs.get("sex")==null?"":rs.get("sex").toString());
				caseVoObj.setKey6(rs.get("dob")==null?"":rs.get("dob").toString());
				caseVoObj.setKey7(rs.get("country")==null?"":rs.get("country").toString());
				caseVoObj.setKey8(rs.get("country_code")==null?"":rs.get("country_code").toString());
				caseVoObj.setKey9(rs.get("user_name")==null?"":rs.get("user_name").toString());
				caseVoObj.setKey10(rs.get("password")==null?"":rs.get("password").toString());
				caseVoObj.setUser(rs.get("source")==null?"":rs.get("source").toString());
				caseVoObj.setActive(rs.get("isActive")==null?"":rs.get("isActive").toString());
				caseVoObj.setBlockDate(rs.get("account_block_date")==null?"":rs.get("account_block_date").toString());
				list.add(caseVoObj);
			}
		} catch(Exception ex) {
			ex.printStackTrace();
		} 
		return list;
	}

	@Override
	public ArrayList<CaseVo> getSourcesCentralAvatar(CaseVo caseVo) 
	{
		ArrayList<CaseVo> list=new ArrayList<CaseVo>();
		try 
		{
			String query="SELECT ca.id, first_name, last_name, email, phone, sex, dob, country,"
					   + " country_code, user_name, `password`, source, isActive, created_time,"
					   + " ca.global_client_id, avatar_added_from, synch_status, avatar_created_by,"
					   + " COALESCE(DATE_FORMAT((ca.account_block_date),'%b %d,%Y %r'),'') as account_block_date,"
					   + " GROUP_CONCAT(ac.avatar_category) AS category"
					   + " FROM tbl_crawl_avatar ca"
					   + " INNER JOIN tbl_avatar_category ac"
					   + " ON ac.avatar_id = ca.id"
					   + " WHERE first_name like '%"+caseVo.getCaseName()+"%'"
					   + " GROUP BY avatar_id ORDER BY id DESC";
			System.out.println("getSourcesCentralAvatar: "+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			
			for(Map<String, Object> rs : rows) 
			{
				CaseVo caseVoObj=new CaseVo();
				caseVoObj.setId(rs.get("id")==null?"":rs.get("id").toString());
				caseVoObj.setKey1(rs.get("first_name")==null?"":rs.get("first_name").toString());
				caseVoObj.setKey2(rs.get("last_name")==null?"":rs.get("last_name").toString());
				caseVoObj.setKey3(rs.get("email")==null?"":rs.get("email").toString());
				caseVoObj.setKey4(rs.get("phone")==null?"":rs.get("phone").toString());
				caseVoObj.setKey5(rs.get("sex")==null?"":rs.get("sex").toString());
				caseVoObj.setKey6(rs.get("dob")==null?"":rs.get("dob").toString());
				caseVoObj.setKey7(rs.get("country")==null?"":rs.get("country").toString());
				caseVoObj.setKey8(rs.get("country_code")==null?"":rs.get("country_code").toString());
				caseVoObj.setKey9(rs.get("source")==null?"":rs.get("source").toString());
				caseVoObj.setKey10(rs.get("user_name")==null?"":rs.get("user_name").toString());
				caseVoObj.setKey11(rs.get("password")==null?"":rs.get("password").toString());
				caseVoObj.setKey12(rs.get("category")==null?"":rs.get("category").toString());
				caseVoObj.setActive(rs.get("isActive")==null?"":rs.get("isActive").toString());
				caseVoObj.setBlockDate(rs.get("account_block_date")==null?"":rs.get("account_block_date").toString());
				caseVoObj.setGlobalClientId(rs.get("global_client_id")==null?"":rs.get("global_client_id").toString());
				caseVoObj.setType(rs.get("avatar_added_from")==null?"":rs.get("avatar_added_from").toString());
				caseVoObj.setSyncStatus(rs.get("synch_status")==null?"":rs.get("synch_status").toString());
				caseVoObj.setUserName(rs.get("avatar_created_by")==null?"":rs.get("avatar_created_by").toString());
				list.add(caseVoObj);
			}
		} 
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return list;
	}
	
	@Override
	public ArrayList<CentralAvatarVo> getAvatarToSyncCentralCrawlerServer(CentralAvatarVo centralAvatarVo)
	{
		ArrayList<CentralAvatarVo> list=new ArrayList<CentralAvatarVo>();
		String result="success";
		try
		{
			String query=" SELECT tca.id AS avatarId , first_name, last_name, email, phone, sex, dob, country, "
					   + " country_code, user_name, password, source, isActive, account_type, "
					   + " created_time, tca.global_client_id AS globalClientId, avatar_added_from, synch_status, "
					   + " avatar_created_by, "
					   + " COALESCE(DATE_FORMAT((tca.account_block_date),'%b %d,%Y %r'),'') as account_block_date, "
					   + " GROUP_CONCAT(tac.avatar_category) AS category"
					   + " FROM tbl_crawl_avatar AS  tca"
					   + " INNER JOIN tbl_avatar_category AS tac "
					   + " ON tac.avatar_id = tca.id"
					   + " WHERE synch_status='0' "
					   + " GROUP BY tac.avatar_id ";
			System.out.println("getAvatarToSyncCentralCrawlerServer query: "+query);
			
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);			
			for(Map<String, Object> rs : rows) 
			{
				CentralAvatarVo avatarVo=new CentralAvatarVo();
				avatarVo.setAvatarId(rs.get("avatarId")==null?"":rs.get("avatarId").toString());
				avatarVo.setFirstName(rs.get("first_name")==null?"":rs.get("first_name").toString());
				avatarVo.setLastName(rs.get("last_name")==null?"":rs.get("last_name").toString());
				avatarVo.setEmail(rs.get("email")==null?"":rs.get("email").toString());
				avatarVo.setPhone(rs.get("phone")==null?"":rs.get("phone").toString());
				avatarVo.setBirthDay(rs.get("dob")==null?"":rs.get("dob").toString());				
				avatarVo.setGender(rs.get("sex")==null?"":rs.get("sex").toString());
				avatarVo.setCountry(rs.get("country")==null?"":rs.get("country").toString());
				avatarVo.setCountryCode(rs.get("country_code")==null?"":rs.get("country_code").toString());
				avatarVo.setSource(rs.get("source")==null?"":rs.get("source").toString());			
				avatarVo.setUserName(rs.get("user_name")==null?"":rs.get("user_name").toString());
				avatarVo.setPassword(rs.get("password")==null?"":rs.get("password").toString());
				avatarVo.setAvatarCategory(rs.get("category")==null?"":rs.get("category").toString());
				avatarVo.setIsActive(rs.get("isActive")==null?"":rs.get("isActive").toString());
				avatarVo.setAccountType(rs.get("account_type")==null?"":rs.get("account_type").toString());
				avatarVo.setAvatarBlockedDateTime(rs.get("account_block_date")==null?"":rs.get("account_block_date").toString());
				avatarVo.setAvatarCreatedTime(rs.get("created_time")==null?"":rs.get("created_time").toString());
				avatarVo.setGlobalClientId(rs.get("globalClientId")==null?"":rs.get("globalClientId").toString());
				avatarVo.setAvatarAddedFrom(rs.get("avatar_added_from")==null?"":rs.get("avatar_added_from").toString());
				//avatarVo.setSynchStatus(rs.get("synch_status")==null?"":rs.get("synch_status").toString());
				avatarVo.setSynchStatus("1");
				avatarVo.setClientUserName(rs.get("avatar_created_by")==null?"":rs.get("avatar_created_by").toString());
				list.add(avatarVo);
					
				String postURL = TwitterConstant.getCentralCrawlingServerURL()+"avatar/syncSingleAvatarFromClient";
				System.out.println("postURL: "+postURL);
				
				String responseStr = HttpUtil.sendPostRequestForSynchronizeCentralAvatarDetails(postURL, gson.toJson(avatarVo)); 
				result="success";
				System.out.println("responseStr: "+responseStr);	
				
				if(responseStr.equals("success"))
				{
					String updateQuery = " UPDATE tbl_crawl_avatar "
							     + " SET synch_status='1' "
							     + " WHERE id= "+avatarVo.getAvatarId()+" ";
					jdbcTemplate.update(updateQuery);
					System.out.println("Update SyncStatus query: "+updateQuery);
				}				
			}
			System.out.println("list============== "+list);
			System.out.println("list.size()======= "+list.size());
			
			//TO HIT ON RESTSERVICE TO SERVER
			String postURL = TwitterConstant.getCentralCrawlingServerURL()+"avatar/syncAvatarFromServer";
			System.out.println("postURL: "+postURL);
			
			CentralAvatarVo avatarVo=new CentralAvatarVo();
			avatarVo.setGlobalClientId(TwitterConstant.getGlobalClientId());
			String responseStr = HttpUtil.sendPostRequestForSynchronizeCentralAvatarDetails(postURL, gson.toJson(avatarVo)); 
			result="success";
			System.out.println("responseStr: "+responseStr);
			
			//Json parse
			JSONParser parser = new JSONParser();
			JSONArray jsonArray = (JSONArray) parser.parse(responseStr);
			ArrayList<CentralAvatarVo> centralAvatarVos = new ArrayList<CentralAvatarVo>();
			for(Object obj : jsonArray)
			{
				if(obj instanceof org.json.simple.JSONObject) {
					org.json.simple.JSONObject jsonObject = (org.json.simple.JSONObject)obj;
					CentralAvatarVo centralAvatarVo2 = new CentralAvatarVo();
					centralAvatarVo2.setAvatarId(jsonObject.get("avatarId")==null?"":jsonObject.get("avatarId").toString());
					centralAvatarVo2.setFirstName(jsonObject.get("firstName")==null?"":jsonObject.get("firstName").toString());
					centralAvatarVo2.setLastName(jsonObject.get("lastName")==null?"":jsonObject.get("lastName").toString());
					centralAvatarVo2.setEmail(jsonObject.get("email")==null?"":jsonObject.get("email").toString());
					centralAvatarVo2.setPhone(jsonObject.get("phone")==null?"":jsonObject.get("phone").toString());
					centralAvatarVo2.setBirthDay(jsonObject.get("birthDay")==null?"":jsonObject.get("birthDay").toString());
					centralAvatarVo2.setGender(jsonObject.get("gender")==null?"":jsonObject.get("gender").toString());
					centralAvatarVo2.setCountry(jsonObject.get("country")==null?"":jsonObject.get("country").toString());
					centralAvatarVo2.setCountryCode(jsonObject.get("countryCode")==null?"":jsonObject.get("countryCode").toString());
					centralAvatarVo2.setSource(jsonObject.get("source")==null?"":jsonObject.get("source").toString());
					centralAvatarVo2.setUserName(jsonObject.get("userName")==null?"":jsonObject.get("userName").toString());
					centralAvatarVo2.setPassword(jsonObject.get("password")==null?"":jsonObject.get("password").toString());
					centralAvatarVo2.setIsActive(jsonObject.get("isActive")==null?"":jsonObject.get("isActive").toString());
					centralAvatarVo2.setAccountType(jsonObject.get("accountType")==null?"":jsonObject.get("accountType").toString());
					centralAvatarVo2.setAvatarCreatedTime(jsonObject.get("avatarCreatedTime")==null?"":jsonObject.get("avatarCreatedTime").toString());
					centralAvatarVo2.setAvatarBlockedDateTime(jsonObject.get("avatarBlockedDateTime")==null?"":jsonObject.get("avatarBlockedDateTime").toString());
					centralAvatarVo2.setAvatarCategory(jsonObject.get("avatarCategory")==null?"":jsonObject.get("avatarCategory").toString());
					centralAvatarVo2.setClientUserName(jsonObject.get("clientUserName")==null?"":jsonObject.get("clientUserName").toString());
					centralAvatarVo2.setGlobalClientId(jsonObject.get("globalClientId")==null?"":jsonObject.get("globalClientId").toString());
					centralAvatarVo2.setAvatarAddedFrom(jsonObject.get("avatarAddedFrom")==null?"":jsonObject.get("avatarAddedFrom").toString());
					centralAvatarVo2.setSynchStatus("1");										
					centralAvatarVos.add(centralAvatarVo2);
				}
			}	
			
			System.out.println("centralAvatarVos: "+centralAvatarVos);
			System.out.println("centralAvatarVos.size(): "+centralAvatarVos.size());
			
			Iterator<CentralAvatarVo> iterator = centralAvatarVos.iterator();
			while(iterator.hasNext()) 
			{
				CentralAvatarVo avatarVo2 = iterator.next();				
				String insertQuery=" INSERT ignore into tbl_crawl_avatar(first_name, last_name, email, phone, dob, sex, "
				         + " country, country_code, source, user_name, password, isActive, account_type, created_time, "
				         + " account_block_date, global_client_id, avatar_added_from, synch_status, avatar_created_by) "
				         + " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		        KeyHolder keyHolder = new GeneratedKeyHolder();
		        jdbcTemplate.update(new PreparedStatementCreator() {
			    public PreparedStatement createPreparedStatement(Connection connection) throws SQLException {
			    	
			    	PreparedStatement ps = connection.prepareStatement(insertQuery, Statement.RETURN_GENERATED_KEYS);
					ps.setString(1, avatarVo2.getFirstName());
					ps.setString(2, avatarVo2.getLastName());
					ps.setString(3, avatarVo2.getEmail());
					ps.setString(4, avatarVo2.getPhone());
					ps.setString(5, avatarVo2.getBirthDay());
					ps.setString(6, avatarVo2.getGender());
					ps.setString(7, avatarVo2.getCountry());
					ps.setString(8, avatarVo2.getCountryCode());
					ps.setString(9, avatarVo2.getSource());
					ps.setString(10, avatarVo2.getUserName());
					ps.setString(11, avatarVo2.getPassword());
					ps.setString(12, avatarVo2.getIsActive());
					ps.setString(13, avatarVo2.getAccountType());
					ps.setString(14, avatarVo2.getAvatarCreatedTime());			
					ps.setString(15, avatarVo2.getAvatarBlockedDateTime());
					ps.setString(16, avatarVo2.getGlobalClientId());
					ps.setString(17, avatarVo2.getAvatarAddedFrom());
					ps.setString(18, avatarVo2.getSynchStatus());
					ps.setString(19, avatarVo2.getClientUserName());
					return ps;										
			      }
				}, keyHolder);
				System.out.println("insertQuery: "+insertQuery);
		        
				if(keyHolder.getKey()==null)
				{
					System.out.println("AutoIncreament key is null.");
					result="failure";
				}
				int autoIncId = keyHolder.getKey().intValue();
				System.out.println("Auto Incremented Id is:: "+autoIncId);
				if(autoIncId==0)
				{
					System.out.println("autoIncId is 0");
					result="failure";
				}
								
				String avatarCatId = avatarVo2.getAvatarCategory();		
				System.out.println("avatarCatId: "+avatarCatId);
				Object[] obj=null;
				if(avatarCatId !=null)
				{
					String[] cat = avatarCatId.split(",");
					for(int i=0; i<cat.length; i++)
					{
						if(!cat[i].equals(""))
						{
							String insertQuery1 = " INSERT IGNORE INTO tbl_avatar_category(avatar_id, avatar_category, global_client_id) "
									+ " VALUES(?,?,?) ";
							obj=new Object[]{autoIncId, cat[i], avatarVo2.getGlobalClientId()};
							jdbcTemplate.update(insertQuery1, obj);
							System.out.println("Add Avatar category insertQuery: "+insertQuery1);
							result="success";
						}																		
					}		
				}
				
				String centralAvatarId = avatarVo2.getAvatarId();
				System.out.println("centralAvatarId: "+centralAvatarId);
				if(result.equals("success")) {
					//TO HIT ON RESTSERVICE TO SERVER
					String updatePostURL = TwitterConstant.getCentralCrawlingServerURL()+"avatar/syncAvatarUpdateSyncStatusToServer";
					System.out.println("postURL: "+postURL);
					
					CentralAvatarVo centralAvatarVo1=new CentralAvatarVo();
					centralAvatarVo1.setAvatarId(centralAvatarId);
					centralAvatarVo1.setGlobalClientId(TwitterConstant.getGlobalClientId());
					String finalResponse = HttpUtil.sendPostRequestForSynchronizeCentralAvatarDetails(updatePostURL, gson.toJson(centralAvatarVo1)); 
					result="success";
					System.out.println("finalResponse: "+finalResponse);	
				}				
			}					
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return list;
	}	
	
	@Override
	public ArrayList<CaseVo> dltSrcAvatar(CaseVo caseVo)
	{
		ArrayList<CaseVo> list=new ArrayList<CaseVo>();
		
		try 
		{
			String query= "DELETE m.* FROM fb_account_profile_map m INNER JOIN tbl_crawl_avatar ON tbl_crawl_avatar.user_name=m.account_id WHERE tbl_crawl_avatar.id= '"+caseVo.getId()+"' " ;
			System.out.println("Delete From fb_account_profile_map: "+query);
			jdbcTemplate.update(query);

			query= "DELETE from tbl_crawl_avatar WHERE id= '"+caseVo.getId()+"' ";
			System.out.println("Delete tbl_crawl_avatar: "+query);
			jdbcTemplate.update(query);
			
			query="DELETE from tbl_avatar_category WHERE avatar_id= '"+caseVo.getId()+"' ";
			System.out.println("Delete tbl_avatar_category: "+query);
			jdbcTemplate.update(query);
			
		} 
		catch(Exception ex) 
		{
			ex.printStackTrace();
		} 
		return list;	
	}
	
	@Override
	public boolean dltSrcCentralAvatar(CaseVo caseVo)
	{
		boolean status = false;
		try 
		{
			String query= "DELETE m.* FROM fb_account_profile_map m INNER JOIN tbl_crawl_avatar ON tbl_crawl_avatar.user_name=m.account_id WHERE tbl_crawl_avatar.id= '"+caseVo.getId()+"' " ;
			System.out.println("Delete From fb_account_profile_map: "+query);
			jdbcTemplate.update(query);

			/*query= "DELETE from tbl_crawl_avatar WHERE id= '"+caseVo.getId()+"' ";
			System.out.println("Delete tbl_crawl_avatar: "+query);
			jdbcTemplate.update(query);*/
			
			query= "Update tbl_crawl_avatar set action='delete', synch_status='0' WHERE id= '"+caseVo.getId()+"' ";
			System.out.println("Update Delete tbl_crawl_avatar: "+query);
			jdbcTemplate.update(query);
			
			query="DELETE from tbl_avatar_category WHERE avatar_id= '"+caseVo.getId()+"' ";
			System.out.println("Delete tbl_avatar_category: "+query);
			jdbcTemplate.update(query);
			
			// Delete record corresponding to id on cloud server
			//TO HIT ON RESTSERVICE TO SERVER
			String postURL = TwitterConstant.getCentralCrawlingServerURL()+"avatar/deleteAvatarToCloudServer";
			System.out.println("postURL: "+postURL);
			
			CentralAvatarVo centralAvatarVo=new CentralAvatarVo();
			centralAvatarVo.setGlobalClientId(caseVo.getGlobalClientId());
			centralAvatarVo.setUserName(caseVo.getUserName());
			centralAvatarVo.setSource(caseVo.getSourceType());
			
			centralAvatarVo.setGlobalClientId(TwitterConstant.getGlobalClientId());
			String finalResponse = HttpUtil.sendPostRequestForSynchronizeCentralAvatarDetails(postURL, gson.toJson(centralAvatarVo));
			System.out.println("finalResponse: "+finalResponse);
			
			if(finalResponse.equals("true")) 
			{
				String updateQuery = "UPDATE tbl_crawl_avatar SET synch_status='1' WHERE id= "+caseVo.getId()+" ";
				System.out.println("Update SyncStatus query: "+updateQuery);
				jdbcTemplate.update(updateQuery);
			}			
			status = true;			
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		} 
		return status;	
	}
	
	
	
	//Central Crawling
	@Override
	public ArrayList<CentralAvatarVo> getActiveAvatarForCentralCrawling(CentralAvatarVo centralAvatarVo) 
	{
		ArrayList<CentralAvatarVo> list=new ArrayList<CentralAvatarVo>();
		try 
		{
			String query=" SELECT id, user_name, password "
					   + " FROM tbl_crawl_avatar "
					   + " WHERE isActive='1' AND account_type='p' "
					   + " ORDER BY id DESC ";
			System.out.println("getActiveAvatarForCentralCrawling: "+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);			
			for(Map<String, Object> rs : rows) 
			{
				CentralAvatarVo avatarVo=new CentralAvatarVo();
				avatarVo.setAvatarId(rs.get("id")==null?"":rs.get("id").toString());
				avatarVo.setUserName(rs.get("user_name")==null?"":rs.get("user_name").toString());
				avatarVo.setPassword(rs.get("password")==null?"":rs.get("password").toString());
				list.add(avatarVo);
			}
		} 
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return list;
	}
	
	
	@Override
	public String addDataCollectionJobsCnf(CaseVo caseVo) 
	{
		String userName = (String) httpSession.getAttribute(ApplicationConstants.LOGIN_USER);
		String userId = (String) httpSession.getAttribute(ApplicationConstants.LOGINUSERID);
		String globalClientId = TwitterConstant.getGlobalClientId();
		System.out.println("userName: "+userName);
		System.out.println("userId: "+userId);
		System.out.println("globalClientId: "+globalClientId);
		String result="success";
		
		try 
		{
			String query=" INSERT ignore into cca_crawling_job_registration(entity_name, entity_url, source_type, "
					   + " entity_type, priority, avatar_category, avatar_user_name, creation_date, created_by, "
					   + " crawling_level, migration_status, action, global_client_id) "
					   + " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)";
			
			KeyHolder keyHolder = new GeneratedKeyHolder();
			jdbcTemplate.update(new PreparedStatementCreator() {
				public PreparedStatement createPreparedStatement(
						Connection connection) throws SQLException {
					PreparedStatement ps = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
					ps.setString(1, caseVo.getKey1().trim());
					ps.setString(2, caseVo.getKey2().trim());
					ps.setString(3, caseVo.getKey3().trim());
					ps.setString(4, caseVo.getKey4().trim());
					ps.setString(5, caseVo.getKey5().trim());
					ps.setString(6, caseVo.getKey6().trim());
					ps.setString(7, caseVo.getKey7().trim());				
					ps.setString(8, CommonUtils.getSqlCurrentDateTime());					
					ps.setString(9, userName);
					ps.setString(10, caseVo.getKey8().trim());
					ps.setString(11, "0");
					ps.setString(12, "add");
					ps.setString(13, globalClientId);
					return ps;
				}
			}, keyHolder);
			
			System.out.println("Add Central Avatar::: "+query);			
			Object[] obj=null;
			if(keyHolder.getKey() !=null)
			{
				int autoIncId = keyHolder.getKey().intValue();
				System.out.println("Auto Incremented Id is::: "+autoIncId);
				if(autoIncId > 0)
				{
					System.out.println("profile===== "+caseVo.getKey10().trim());
					System.out.println("page======== "+caseVo.getKey11().trim());
					System.out.println("group======= "+caseVo.getKey12().trim());
					
					if(caseVo.getKey3().trim().equals("profile"))
					{
						
						String insertProfileQuery = " INSERT ignore into cca_fb_profile_data_to_crawl(entity_id, about, friends, "
								                  + " posts, photos, videos, checkins, groups, events, posts_like_users)"
								                  + " values(?,?,?,?,?,?,?,?,?,?) ";
						System.out.println("insertProfileQuery: "+insertProfileQuery);
						jdbcTemplate.update(insertProfileQuery, new Object[] {
								autoIncId, 
						});
					}
					else if(caseVo.getKey3().trim().equals("page"))
					{
						
					}
					else if(caseVo.getKey3().trim().equals("group"))
					{
						
					}	
				}
				else
				{
					System.out.println("autoIncId is 0");
					result="failure";
					return result;
				}			
			}
			else
			{
				System.out.println("AutoIncreament key is null.");
				result="failure";
				return result;
			}		
		} 
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return result;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	//SELECT
	@Override
	public ArrayList<UserProfileBasicInformationVo> getUserProfileBasicInformationsDetails(UserProfileBasicInformationVo basicInformationVo) 
	{
		ArrayList<UserProfileBasicInformationVo> userList = new ArrayList<UserProfileBasicInformationVo>();
		try 
		{
			String selectQuery = " SELECT id, first_name, last_name, profile_photo_id, profile_cover_photo_id, "
					+ " (SELECT photo_path FROM tbl_profile_user_photo WHERE tbl_profile_user_photo.id=tbl_profile.profile_photo_id) AS profilePhoto, "
					+ " (SELECT photo_path FROM tbl_profile_user_photo WHERE tbl_profile_user_photo.id=tbl_profile.profile_cover_photo_id) AS coverPhoto, "
					+ " permanent_address, local_address, "
					+ " father_name, mother_name, dob, gender, nationality, martial_status, addahar_card, "
					+ " pan_card, passport_no, description, classification, (SELECT GROUP_CONCAT(alias) FROM tbl_profile_alias WHERE tbl_profile_alias.profile_id=tbl_profile.id) as alias "
					+ " FROM tbl_profile "
					+ " WHERE first_name like '%"+basicInformationVo.getSearchStr()+"%' or last_name like '%"+basicInformationVo.getSearchStr()+"%' ORDER BY id DESC ";
			System.out.println("getUserProfileBasicInformationsDetails selectQuery: "+selectQuery);

			List<Map<String, Object>> rows = jdbcTemplate.queryForList(selectQuery);
			
			for(Map<String, Object> rs : rows) 
			{
				UserProfileBasicInformationVo user = new UserProfileBasicInformationVo();
				user.setProfileId((Integer)(rs.get("id")));
				user.setFirstName((String)(rs.get("first_name")));
				user.setLastName((String)(rs.get("last_name")));
				user.setProfilePhotoId((Integer)(rs.get("profile_photo_id")));
				user.setProfileCoverPhotoId((Integer)(rs.get("profile_cover_photo_id")));
				
				if(rs.get("profilePhoto")!=null) 
				{
					String path = TwitterConstant.getPersonProfile();
					String finalPath = path.substring(path.indexOf("ROOT")+4);
					user.setProfilePhoto(finalPath+"/"+(String)rs.get("profilePhoto"));
				} 
				else 
				{
					user.setProfilePhoto(null);
				}
				if(rs.get("coverPhoto")!=null) 
				{
					String path = TwitterConstant.getPersonProfile();
					String finalPath = path.substring(path.indexOf("ROOT")+4);
					user.setCoverPhoto(finalPath+"/"+(String)rs.get("coverPhoto"));
				}
				else
				{
					user.setCoverPhoto(null);
				}
				
				user.setPermanentAddress((String)(rs.get("permanent_address")));
				user.setLocalAddress((String)(rs.get("local_address")));
				user.setFatherName((String)(rs.get("father_name")));
				user.setMotherName((String)(rs.get("mother_name")));
				user.setDob((String)(rs.get("dob")));
				user.setGender((String)(rs.get("gender")));
				user.setNationality((String)(rs.get("nationality")));
				user.setMartialStatus((String)(rs.get("martial_status")));
				user.setAddaharCard((String)(rs.get("addahar_card")));
				user.setPanCard((String)(rs.get("pan_card")));
				user.setPassportNo((String)(rs.get("passport_no")));
				user.setDescription((String)(rs.get("description")));
				user.setClassification((String)(rs.get("classification")));
				user.setAlias(rs.get("alias")==null?"":rs.get("alias").toString());
				userList.add(user);	
			}			
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return userList;
	}
	
	@Override
	public ArrayList<UserProfileBasicInformationVo> getTargetCurrentAddedUserProfileBasicInfo(UserProfileBasicInformationVo basicInformationVo)
	{
		ArrayList<UserProfileBasicInformationVo> userList = new ArrayList<UserProfileBasicInformationVo>();
		try 
		{
			String selectQuery = " SELECT id, first_name, last_name, profile_photo_id, profile_cover_photo_id, "
					+ " (SELECT photo_path FROM tbl_profile_user_photo WHERE tbl_profile_user_photo.id=tbl_profile.profile_photo_id) AS profilePhoto, "
					+ " (SELECT photo_path FROM tbl_profile_user_photo WHERE tbl_profile_user_photo.id=tbl_profile.profile_cover_photo_id) AS coverPhoto, "
					+ " permanent_address, local_address, "
					+ " father_name, mother_name, dob, gender, nationality, martial_status, addahar_card, "
					+ " pan_card, passport_no, description, classification, (SELECT GROUP_CONCAT(alias) FROM tbl_profile_alias WHERE tbl_profile_alias.profile_id=tbl_profile.id) as alias "
					+ " FROM tbl_profile "
					+ " ORDER BY id DESC LIMIT 1 ";
			System.out.println("getTargetCurrentAddedUserProfileBasicInfo selectQuery: "+selectQuery);

			List<Map<String, Object>> rows = jdbcTemplate.queryForList(selectQuery);
			for(Map<String, Object> rs : rows) 
			{
				UserProfileBasicInformationVo user = new UserProfileBasicInformationVo();				
				user.setProfileId((Integer)(rs.get("id")));
				user.setFirstName((String)(rs.get("first_name")));
				user.setLastName((String)(rs.get("last_name")));
				user.setProfilePhotoId((Integer)(rs.get("profile_photo_id")));
				user.setProfileCoverPhotoId((Integer)(rs.get("profile_cover_photo_id")));			

				if(rs.get("profilePhoto")!=null) 
				{
					String path = TwitterConstant.getPersonProfile();
					String finalPath = path.substring(path.indexOf("ROOT")+4);
					user.setProfilePhoto(finalPath+"/"+(String)rs.get("profilePhoto"));
				} 
				else 
				{
					user.setProfilePhoto(null);
				}	

				if(rs.get("coverPhoto")!=null) 
				{
					String path = TwitterConstant.getPersonProfile();
					String finalPath = path.substring(path.indexOf("ROOT")+4);
					user.setCoverPhoto(finalPath+"/"+(String)rs.get("coverPhoto"));
				} 
				else 
				{
					user.setCoverPhoto(null);
				}

				user.setPermanentAddress((String)(rs.get("permanent_address")));
				user.setLocalAddress((String)(rs.get("local_address")));
				user.setFatherName((String)(rs.get("father_name")));
				user.setMotherName((String)(rs.get("mother_name")));
				user.setDob((String)(rs.get("dob")));
				user.setGender((String)(rs.get("gender")));
				user.setNationality((String)(rs.get("nationality")));
				user.setMartialStatus((String)(rs.get("martial_status")));
				user.setAddaharCard((String)(rs.get("addahar_card")));
				user.setPanCard((String)(rs.get("pan_card")));
				user.setPassportNo((String)(rs.get("passport_no")));
				user.setDescription((String)(rs.get("description")));
				user.setClassification((String)(rs.get("classification")));
				user.setAlias(rs.get("alias")==null?"":rs.get("alias").toString());			
				userList.add(user);
			}			
		} 
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return userList;
	}

	
	@Override
	public ArrayList<UserProfileAliasVo> getUserProfileAliasDetails(UserProfileAliasVo aliasVo) 
	{
		ArrayList<UserProfileAliasVo> aliasList = new ArrayList<UserProfileAliasVo>();
		try 
		{
			String selectQuery = "SELECT alias "
					+ "FROM tbl_profile_alias "
					+ "WHERE profile_id="+aliasVo.getProfileId()+" ";
			System.out.println("getUserProfileAliasDetails selectQuery: "+selectQuery);

			List<Map<String, Object>> rows = jdbcTemplate.queryForList(selectQuery);
			for(Map<String, Object> row : rows)
			{
				UserProfileAliasVo alias = new UserProfileAliasVo();
				alias.setAlias(row.get("alias")==null?"":row.get("alias").toString());
				aliasList.add(alias);
			}
		} 
		catch(DataAccessException e) 
		{			
			e.printStackTrace();
		}		
		return aliasList;
	}

	@Override
	public ArrayList<UserProfileContactVo> getUserProfileContactDetails(UserProfileContactVo contactVo) 
	{
		ArrayList<UserProfileContactVo> contactList = null;
		try
		{
			String selectQuery = "SELECT id, contact, contact_type, contact_primary "
					+ "FROM tbl_profile_contact "
					+ "WHERE profile_id="+contactVo.getProfileId()+" ORDER BY id DESC";
			System.out.println("selectQuery: "+selectQuery);

			contactList = new ArrayList<UserProfileContactVo>();
			List<Map<String, Object>> rows = jdbcTemplate.queryForList(selectQuery);
			for(Map<String, Object> row : rows)
			{
				UserProfileContactVo contact = new UserProfileContactVo();
				contact.setContactId((Integer)(row.get("id")));
				contact.setContact((String)(row.get("contact")));
				contact.setContactType((String)(row.get("contact_type")));
				contact.setContactPrimary((String)(row.get("contact_primary")));
				contactList.add(contact);
			}									
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return contactList;
	}


	@Override
	public ArrayList<UserProfileContactVo> getTargetProfileContactDetailsForEdit(UserProfileContactVo contactVo) 
	{
		ArrayList<UserProfileContactVo> contactList = new ArrayList<UserProfileContactVo>();
		try
		{
			String selectQuery = "SELECT id, contact, contact_type, contact_primary "
					+ "FROM tbl_profile_contact "
					+ "WHERE profile_id="+contactVo.getProfileId()+" ORDER BY id DESC";
			System.out.println("getTargetProfileContactDetailsForEdit selectQuery: "+selectQuery);

			List<Map<String, Object>> rows = jdbcTemplate.queryForList(selectQuery);
			for(Map<String, Object> row : rows)
			{
				UserProfileContactVo contact = new UserProfileContactVo();
				contact.setContactId((Integer)(row.get("id")));
				contact.setContact((String)(row.get("contact")));
				contact.setContactType((String)(row.get("contact_type")));
				contact.setContactPrimary((String)(row.get("contact_primary")));
				contactList.add(contact);
			}									
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return contactList;
	}

	@Override
	public ArrayList<UserProfileSocialAccountVo> getUserProfileSocialAccountDetails(UserProfileSocialAccountVo socialAccountVo) 
	{
		ArrayList<UserProfileSocialAccountVo> accountList = new ArrayList<UserProfileSocialAccountVo>();

		try
		{
			String selectQuery = "SELECT id, profile_id, entity_name, entity_id, entity_source_type, entity_url, entity_img, tw_id "
					+ "FROM tbl_profile_social_account "
					+ "WHERE profile_id="+socialAccountVo.getProfileId()+" ORDER BY id DESC";
			System.out.println("getUserProfileSocialAccountDetails selectQuery: "+selectQuery);				

			List<Map<String, Object>> rows = jdbcTemplate.queryForList(selectQuery);				
			for(Map<String, Object> row : rows)
			{
				UserProfileSocialAccountVo account = new UserProfileSocialAccountVo();
				account.setAccountId((Integer)(row.get("id")));
				account.setProfileId((Integer)(row.get("profile_id")));
				account.setEntityName((String)(row.get("entity_name")));			
				account.setEntitySocialId((String)(row.get("entity_id")));
				account.setEntitySourceType((String)(row.get("entity_source_type")));	
				account.setEntityUrl((String)(row.get("entity_url")));
				account.setEntityImg((String)(row.get("entity_img")));
				account.setTwId((String)(row.get("tw_id")));
				accountList.add(account);
			}				
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}				
		return accountList;
	}


	@Override
	public ArrayList<UserProfileAssociatedFriendsVo> getUserProfileAssociatedFriendsDetails(UserProfileAssociatedFriendsVo associatedFriendsVo) 
	{

		return null;
	}

	@Override
	public ArrayList<UserProfileAssociatedHandlesVo> getUserProfileAssociatedHandlesDetails(UserProfileAssociatedHandlesVo associatedHandlesVo) 
	{

		return null;
	}


	@Override
	public ArrayList<UserProfileAssociatedEventsVo> getUserProfileAssociatedEventsDetails(UserProfileAssociatedEventsVo associatedEventsVo) 
	{

		ArrayList<UserProfileAssociatedEventsVo> eventList = new ArrayList<UserProfileAssociatedEventsVo>();
		try
		{
			String selectQuery = "SELECT id, event_name, event_date, event_type, sentiment_of_event "
					+ "FROM tbl_profile_associated_event "
					+ "WHERE profile_id="+associatedEventsVo.getProfileId()+" ORDER BY id DESC";
			System.out.println("getUserProfileAssociatedEventsDetails selectQuery: "+selectQuery);				

			List<Map<String, Object>> rows = jdbcTemplate.queryForList(selectQuery);
			for(Map<String, Object> row : rows)
			{
				UserProfileAssociatedEventsVo event = new UserProfileAssociatedEventsVo();
				event.setEventId((Integer)(row.get("id")));
				event.setEventName((String)(row.get("event_name")));			
				event.setEventDate((String)CommonUtils.object2String(row.get("event_date")));
				event.setEventType((String)(row.get("event_type")));	
				event.setSentimentOfEvent((String)(row.get("sentiment_of_event")));			
				eventList.add(event);
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}						
		return eventList;
	}

	@Override
	public ArrayList<UserProfileAssociatedLocationsVo> getUserProfileAssociatedLocationsDetails(UserProfileAssociatedLocationsVo associatedLocationsVo) 
	{

		return null;
	}

	@Override
	public ArrayList<UserProfileAssociatedOrganizationsVo> getUserProfileAssociatedOrganizationsDetails(UserProfileAssociatedOrganizationsVo associatedOrganizationsVo) 
	{
		return null;
	}



	//DELETE
	@Override
	public ArrayList<UserProfileBasicInformationVo> deleteUserProfileBasicInformations(UserProfileBasicInformationVo basicInformationVo) 
	{
		String type = "P";
		ArrayList<UserProfileBasicInformationVo> list = new ArrayList<UserProfileBasicInformationVo>();
		TransactionDefinition def = new DefaultTransactionDefinition();
		TransactionStatus status = transactionManager.getTransaction(def);

		try
		{			
			String deleteQuery1= "DELETE FROM tbl_profile WHERE id = '"+basicInformationVo.getProfileId()+"' " ;
			String deleteQuery2= "DELETE FROM tbl_profile_alias WHERE profile_id = '"+basicInformationVo.getProfileId()+"' " ;
			String deleteQuery3= "DELETE FROM tbl_profile_contact WHERE profile_id = '"+basicInformationVo.getProfileId()+"' " ;
			String deleteQuery4= "DELETE FROM tbl_profile_social_account WHERE profile_id = '"+basicInformationVo.getProfileId()+"' " ;
			String deleteQuery5= "DELETE FROM tbl_profile_associated_event WHERE profile_id = '"+basicInformationVo.getProfileId()+"' " ;
			String deleteQuery6= "DELETE FROM tbl_profile_user_photo WHERE profile_id = '"+basicInformationVo.getProfileId()+"' " ;
			String deleteQuery7= "DELETE FROM tbl_ner_alias WHERE target_id = '"+basicInformationVo.getProfileId()+"' AND type='"+type+"' " ;
			
			//################# Delete profile and cover photo Start ###############################################
			
			String[] photosPath = new String[2];
			String query = "Select photo_path from tbl_profile_user_photo WHERE profile_id = '"+basicInformationVo.getProfileId()+"' ";
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			int i=0;
			for(Map<String,Object> rs : rows)
			{
				photosPath[i] = TwitterConstant.getPersonProfile()+"/"+(rs.get("photo_path")==null?"":rs.get("photo_path").toString());
				i++;			
			}
			if(photosPath[0] != null) 
			{
				File profilePhoto = new File(photosPath[0]);
	    		if(profilePhoto.delete())
	    		{
	    			System.out.println(profilePhoto.getName() + " is deleted!");
	    		}
	    		else
	    		{
	    			System.out.println("Profile Photo Delete operation is failed.");
	    		}
			}
    		
			if(photosPath[1] != null)
			{
	    		File coverPhoto = new File(photosPath[1]);        	
	    		if(coverPhoto.delete())
	    		{
	    			System.out.println(coverPhoto.getName() + " is deleted!");
	    		}
	    		else
	    		{
	    			System.out.println("Cover Photo Delete operation is failed.");
	    		}
			}
			
			//################# Delete profile and cover photo End ###############################################

			System.out.println("Delete query1: "+deleteQuery1);
			System.out.println("Delete query2: "+deleteQuery2);
			System.out.println("Delete query3: "+deleteQuery3);
			System.out.println("Delete query4: "+deleteQuery4);
			System.out.println("Delete query5: "+deleteQuery5);
			System.out.println("Delete query6: "+deleteQuery6);
			System.out.println("Delete query7: "+deleteQuery7);

			jdbcTemplate.update(deleteQuery1);
			jdbcTemplate.update(deleteQuery2);
			jdbcTemplate.update(deleteQuery3);
			jdbcTemplate.update(deleteQuery4);
			jdbcTemplate.update(deleteQuery5);
			jdbcTemplate.update(deleteQuery6);
			jdbcTemplate.update(deleteQuery7);
			transactionManager.commit(status);
		
		}
		catch(Exception ex) 
		{
			transactionManager.rollback(status);
			ex.printStackTrace();
		}
		return list;
	}

	@Override
	public ArrayList<UserProfileAliasVo> deleteUserProfileAlias(UserProfileAliasVo aliasVo) 
	{		
		ArrayList<UserProfileAliasVo> list = new ArrayList<UserProfileAliasVo>();
		try
		{			
			String deleteQuery= "DELETE FROM tbl_profile_alias WHERE id = '"+aliasVo.getProfileId()+"' " ;
			System.out.println("deleteUserProfileAlias query: "+deleteQuery);
			jdbcTemplate.update(deleteQuery);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		} 
		return list;	
	}

	@Override
	public ArrayList<UserProfileContactVo> deleteUserProfileContact(UserProfileContactVo contactVo) 
	{		
		ArrayList<UserProfileContactVo> list = new ArrayList<UserProfileContactVo>();
		try
		{			
			String deleteQuery= "DELETE FROM tbl_profile_contact WHERE id = '"+contactVo.getContactId()+"' " ;
			System.out.println("deleteUserProfileContact query: "+deleteQuery);
			jdbcTemplate.update(deleteQuery);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		} 
		return list;
	}

	@Override
	public ArrayList<UserProfileSocialAccountVo> deleteUserProfileSocialAccount(UserProfileSocialAccountVo socialAccountVo) 
	{
		ArrayList<UserProfileSocialAccountVo> list = new ArrayList<UserProfileSocialAccountVo>();
		try
		{			
			String deleteQuery= "DELETE FROM tbl_profile_social_account WHERE id = '"+socialAccountVo.getAccountId()+"' " ;
			System.out.println("deleteUserProfileSocialAccount query: "+deleteQuery);
			jdbcTemplate.update(deleteQuery);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		} 
		return list;
	}

	@Override
	public ArrayList<UserProfileAssociatedFriendsVo> deleteUserProfileAssociatedFriends(UserProfileAssociatedFriendsVo associatedFriendsVo) 
	{
		ArrayList<UserProfileAssociatedFriendsVo> list = new ArrayList<UserProfileAssociatedFriendsVo>();
		try
		{			
			String deleteQuery= "DELETE FROM tbl_profile_associated_friends WHERE id = '"+associatedFriendsVo.getFriendsId()+"' " ;
			System.out.println("deleteUserProfileAssociatedFriends query: "+deleteQuery);
			jdbcTemplate.update(deleteQuery);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		} 
		return list;
	}

	@Override
	public ArrayList<UserProfileAssociatedHandlesVo> deleteUserProfileAssociatedHandles(UserProfileAssociatedHandlesVo associatedHandlesVo) 
	{
		ArrayList<UserProfileAssociatedHandlesVo> list = new ArrayList<UserProfileAssociatedHandlesVo>();
		try
		{			
			String deleteQuery= "DELETE FROM tbl_profile_associated_handles WHERE id = '"+associatedHandlesVo.getHandlesId()+"' " ;
			System.out.println("deleteUserProfileAssociatedHandles query: "+deleteQuery);
			jdbcTemplate.update(deleteQuery);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		} 
		return list;
	}

	@Override
	public ArrayList<UserProfileAssociatedEventsVo> deleteUserProfileAssociatedEvents(UserProfileAssociatedEventsVo associatedEventsVo) 
	{
		ArrayList<UserProfileAssociatedEventsVo> list = new ArrayList<UserProfileAssociatedEventsVo>();
		try
		{			
			String deleteQuery= "DELETE FROM tbl_profile_associated_event WHERE id = '"+associatedEventsVo.getEventId()+"' " ;
			System.out.println("deleteUserProfileAssociatedEvents query: "+deleteQuery);
			jdbcTemplate.update(deleteQuery);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		} 
		return list;
	}

	@Override
	public ArrayList<UserProfileAssociatedLocationsVo> deleteUserProfileAssociatedLocations(UserProfileAssociatedLocationsVo associatedLocationsVo) 
	{
		ArrayList<UserProfileAssociatedLocationsVo> list = new ArrayList<UserProfileAssociatedLocationsVo>();
		try
		{			
			String deleteQuery= "DELETE FROM tbl_profile_associated_location WHERE id = '"+associatedLocationsVo.getLocationId()+"' " ;
			System.out.println("deleteUserProfileAssociatedLocations query: "+deleteQuery);
			jdbcTemplate.update(deleteQuery);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		} 
		return list;
	}

	@Override
	public ArrayList<UserProfileAssociatedOrganizationsVo> deleteUserProfileAssociatedOrganizations(UserProfileAssociatedOrganizationsVo associatedOrganizationsVo)
	{
		ArrayList<UserProfileAssociatedOrganizationsVo> list = new ArrayList<UserProfileAssociatedOrganizationsVo>();
		try
		{			
			String deleteQuery= "DELETE FROM tbl_profile_associated_organization WHERE id = '"+associatedOrganizationsVo.getOrganizationId()+"' " ;
			System.out.println("deleteUserProfileAssociatedOrganizations query: "+deleteQuery);
			jdbcTemplate.update(deleteQuery);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		} 
		return list;
	}


	//UPDATE  UPDATE  UPDATE  UPDATE  UPDATE  UPDATE
	@Override
	public boolean editUserProfileBasicInformations(UserProfileBasicInformationVo basicInformationVo)
	{
		String updateQuery = "";	
		String deleteQuery = "";
		String coverPhotoId = "coverPhoto";
		String profilePhotoId = "profilePhoto";
		int statusUpdate = 1;
		int result=0;
		String type = "P";
		String userName =(String)httpSession.getAttribute(ApplicationConstants.LOGINUSERID);

		TransactionDefinition def = new DefaultTransactionDefinition();
		TransactionStatus status = transactionManager.getTransaction(def);

		try
		{
			if(basicInformationVo.getProfilePhotoId() != 0 && basicInformationVo.getProfileCoverPhotoId() != 0)
			{
				updateQuery = "UPDATE tbl_profile SET first_name='"+basicInformationVo.getFirstName()+"', last_name='"+basicInformationVo.getLastName()+"', "
						+ "profile_photo_id='"+basicInformationVo.getProfilePhotoId()+"', profile_cover_photo_id='"+basicInformationVo.getProfileCoverPhotoId()+"', "
						+ "permanent_address='"+basicInformationVo.getPermanentAddress()+"', "
						+ "local_address='"+basicInformationVo.getLocalAddress()+"', father_name='"+basicInformationVo.getFatherName()+"', "
						+ "mother_name='"+basicInformationVo.getMotherName()+"', dob='"+basicInformationVo.getDob()+"', "
						+ "gender='"+basicInformationVo.getGender()+"', nationality='"+basicInformationVo.getNationality()+"', "
						+ "martial_status='"+basicInformationVo.getMartialStatus()+"', addahar_card='"+basicInformationVo.getAddaharCard()+"', "
						+ "pan_card='"+basicInformationVo.getPanCard()+"', passport_no='"+basicInformationVo.getPassportNo()+"', "
						+ "description='"+basicInformationVo.getDescription()+"', classification='"+basicInformationVo.getClassification()+"' "
						+ "WHERE id='"+basicInformationVo.getProfileId()+"' ";

				deleteQuery = "DELETE FROM tbl_profile_user_photo WHERE profile_id = '"+basicInformationVo.getProfileId()+"' " ; 
				jdbcTemplate.update(deleteQuery);
			}
			else if(basicInformationVo.getProfilePhotoId() == 0 && basicInformationVo.getProfileCoverPhotoId() != 0)
			{
				updateQuery = "UPDATE tbl_profile SET first_name='"+basicInformationVo.getFirstName()+"', last_name='"+basicInformationVo.getLastName()+"', "
						+ "profile_cover_photo_id='"+basicInformationVo.getProfileCoverPhotoId()+"', "
						+ "permanent_address='"+basicInformationVo.getPermanentAddress()+"', "
						+ "local_address='"+basicInformationVo.getLocalAddress()+"', father_name='"+basicInformationVo.getFatherName()+"', "
						+ "mother_name='"+basicInformationVo.getMotherName()+"', dob='"+basicInformationVo.getDob()+"', "
						+ "gender='"+basicInformationVo.getGender()+"', nationality='"+basicInformationVo.getNationality()+"', "
						+ "martial_status='"+basicInformationVo.getMartialStatus()+"', addahar_card='"+basicInformationVo.getAddaharCard()+"', "
						+ "pan_card='"+basicInformationVo.getPanCard()+"', passport_no='"+basicInformationVo.getPassportNo()+"', "
						+ "description='"+basicInformationVo.getDescription()+"', classification='"+basicInformationVo.getClassification()+"' "
						+ "WHERE id='"+basicInformationVo.getProfileId()+"' ";

				deleteQuery = "DELETE FROM tbl_profile_user_photo WHERE profile_id = '"+basicInformationVo.getProfileId()+"' AND photo_type = '"+coverPhotoId+"' " ; 
				jdbcTemplate.update(deleteQuery);
			}
			else if(basicInformationVo.getProfilePhotoId() != 0 && basicInformationVo.getProfileCoverPhotoId() == 0)
			{
				updateQuery = "UPDATE tbl_profile SET first_name='"+basicInformationVo.getFirstName()+"', last_name='"+basicInformationVo.getLastName()+"', "
						+ "profile_photo_id='"+basicInformationVo.getProfilePhotoId()+"',  "
						+ "permanent_address='"+basicInformationVo.getPermanentAddress()+"', "
						+ "local_address='"+basicInformationVo.getLocalAddress()+"', father_name='"+basicInformationVo.getFatherName()+"', "
						+ "mother_name='"+basicInformationVo.getMotherName()+"', dob='"+basicInformationVo.getDob()+"', "
						+ "gender='"+basicInformationVo.getGender()+"', nationality='"+basicInformationVo.getNationality()+"', "
						+ "martial_status='"+basicInformationVo.getMartialStatus()+"', addahar_card='"+basicInformationVo.getAddaharCard()+"', "
						+ "pan_card='"+basicInformationVo.getPanCard()+"', passport_no='"+basicInformationVo.getPassportNo()+"', "
						+ "description='"+basicInformationVo.getDescription()+"', classification='"+basicInformationVo.getClassification()+"' "
						+ "WHERE id='"+basicInformationVo.getProfileId()+"' ";

				deleteQuery = "DELETE FROM tbl_profile_user_photo WHERE profile_id = '"+basicInformationVo.getProfileId()+"' AND photo_type = '"+profilePhotoId+"' " ; 
				jdbcTemplate.update(deleteQuery);
			}
			else if(basicInformationVo.getProfilePhotoId() == 0 && basicInformationVo.getProfileCoverPhotoId() == 0)
			{

				updateQuery = "UPDATE tbl_profile SET first_name='"+basicInformationVo.getFirstName()+"', last_name='"+basicInformationVo.getLastName()+"', "
						+ "permanent_address='"+basicInformationVo.getPermanentAddress()+"', "
						+ "local_address='"+basicInformationVo.getLocalAddress()+"', father_name='"+basicInformationVo.getFatherName()+"', "
						+ "mother_name='"+basicInformationVo.getMotherName()+"', dob='"+basicInformationVo.getDob()+"', "
						+ "gender='"+basicInformationVo.getGender()+"', nationality='"+basicInformationVo.getNationality()+"', "
						+ "martial_status='"+basicInformationVo.getMartialStatus()+"', addahar_card='"+basicInformationVo.getAddaharCard()+"', "
						+ "pan_card='"+basicInformationVo.getPanCard()+"', passport_no='"+basicInformationVo.getPassportNo()+"', "
						+ "description='"+basicInformationVo.getDescription()+"', classification='"+basicInformationVo.getClassification()+"' "
						+ "WHERE id='"+basicInformationVo.getProfileId()+"' ";
			}

			System.out.println("editUserProfileBasicInformations updateQuery: "+updateQuery);
			result = jdbcTemplate.update(updateQuery);

			//DELETE ALIAS TABLE CONTENT.
			String deleteQuery1= "DELETE FROM tbl_profile_alias WHERE profile_id = '"+basicInformationVo.getProfileId()+"' " ;
			System.out.println("deleteQuery1: "+deleteQuery1);
			jdbcTemplate.update(deleteQuery1);

			//INSERT ALIAS TABLE CONTENT.
			String[] arr = basicInformationVo.getAlias().split(",");		 
			for(int i = 0; i < arr.length; i++) 
			{
				String aliasInsertQuery = "insert ignore into tbl_profile_alias(profile_id, alias)"
						+ " values(?,?) ";
				System.out.println("aliasInsertQuery: "+aliasInsertQuery);
				jdbcTemplate.update(aliasInsertQuery, new Object[] {
						basicInformationVo.getProfileId(), 
						arr[i].trim()
				});				  
			}

			//DELETE ALIAS TABLE CONTENT IN tbl_ner_alias TABLE.
			String deleteQuery2= "DELETE FROM tbl_ner_alias WHERE firstName = '"+basicInformationVo.getFirstName()+"' AND lastName = '"+basicInformationVo.getLastName()+"' AND type='"+type+"' " ;
			System.out.println("deleteQuery2: "+deleteQuery2);
			jdbcTemplate.update(deleteQuery2);

			//TO ADDING ALIAS IN tbl_ner_alias TABLE.
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");  
			Date date = new Date();  
			String strDate = formatter.format(date);
			System.out.println(strDate);

			for(int i = 0; i < arr.length; i++) 
			{
				String nerAliasInsertQuery = "insert ignore into tbl_ner_alias(firstName, lastName, alias, type, date_of_insertion, login_id, target_id)"
						+ " values(?,?,?,?,?,?,?) ";
				System.out.println("nerAliasInsertQuery: "+nerAliasInsertQuery);
				jdbcTemplate.update(nerAliasInsertQuery, new Object[] {
						basicInformationVo.getFirstName().trim(), 
						basicInformationVo.getLastName().trim(),					
						arr[i].trim(),
						type,
						strDate,
						userName,
						basicInformationVo.getProfileId()
				});				
			} 

			//UPDATE THE STATUS=1 FIELD OF tbl_profile_user_photo TABLE
			String updateQuery1 = "UPDATE tbl_profile_user_photo SET status="+statusUpdate+", profile_id="+basicInformationVo.getProfileId()+" "
					+ "WHERE id="+basicInformationVo.getProfilePhotoId()+" OR id="+basicInformationVo.getProfileCoverPhotoId()+" ";		
			jdbcTemplate.update(updateQuery1);
			System.out.println("updateQuery1: "+updateQuery1);	
			transactionManager.commit(status);	
		}
		catch(Exception ex)
		{
			transactionManager.rollback(status);
			ex.printStackTrace();			
		}
		if(result>0)
		{
			return true;
		}			 
		else 
		{
			return false;
		}					
	}

	@Override
	public boolean editUserProfileAlias(UserProfileAliasVo aliasVo)
	{
		int result=0;
		try
		{
			if(!httpSession.getAttribute("profileId").equals(null))
			{
				Integer userProfileId = Integer.parseInt(httpSession.getAttribute("profileId").toString());
				String updateQuery = "UPDATE tbl_profile_alias SET alias='"+aliasVo.getAlias()+"', profile_id="+userProfileId+" "                 
						+ "WHERE id='"+aliasVo.getAliasId()+"' ";
				System.out.println("editUserProfileAlias updateQuery: "+updateQuery);
				result = jdbcTemplate.update(updateQuery);
			}
			else
			{
				System.out.println("Please select the user profile");
			}			
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}		 
		if(result>0)
		{
			return true;
		}			 
		else 
		{
			return false;
		}
	}

	@Override
	public boolean editUserProfileContact(UserProfileContactVo contactVo)
	{
		int result=0;
		try
		{
			String updateQuery = "UPDATE tbl_profile_contact SET contact='"+contactVo.getContact()+"', contact_type='"+contactVo.getContactType()+"', contact_primary='"+contactVo.getContactPrimary()+"' "
					+ "WHERE id='"+contactVo.getContactId()+"' ";
			System.out.println("editUserProfileContact updateQuery: "+updateQuery);
			result = jdbcTemplate.update(updateQuery);			
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}		 
		if(result>0)
		{
			return true;
		}			 
		else 
		{
			return false;
		}	 
	}

	@Override
	public boolean editUserProfileSocialAccount(UserProfileSocialAccountVo socialAccountVo) 
	{
		int result=0;
		try
		{
			String updateQuery = "UPDATE tbl_profile_social_account SET entity_name='"+socialAccountVo.getEntityName()+"', entity_id='"+socialAccountVo.getEntitySocialId()+"', entity_source_type='"+socialAccountVo.getEntitySourceType()+"', entity_url='"+socialAccountVo.getEntityUrl()+"', entity_img='"+socialAccountVo.getEntityImg()+"', tw_id='"+socialAccountVo.getTwId()+"' "
					+ "WHERE id='"+socialAccountVo.getAccountId()+"' ";
			System.out.println("editUserProfileSocialAccount updateQuery: "+updateQuery);
			result = jdbcTemplate.update(updateQuery);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}		 
		if(result>0)
		{
			return true;
		}			 
		else 
		{
			return false;
		}
	}

	@Override
	public boolean editUserProfileAssociatedFriends(UserProfileAssociatedFriendsVo associatedFriendsVo) 
	{
		int result=0;
		try
		{
			String updateQuery = "UPDATE tbl_profile_associated_friends SET friend_user_id='"+associatedFriendsVo.getFriendUserId()+"', user_name='"+associatedFriendsVo.getUserName()+"', user_screen_name='"+associatedFriendsVo.getUserScreenName()+"', classification='"+associatedFriendsVo.getClassification()+"', friend_photo='"+associatedFriendsVo.getFriendPhoto()+"', social_media_type='"+associatedFriendsVo.getSocialMediaType()+"' "      
					+ "WHERE id="+associatedFriendsVo.getFriendsId()+" ";
			System.out.println("editUserProfileAssociatedFriends updateQuery: "+updateQuery);
			result = jdbcTemplate.update(updateQuery);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}		 
		if(result>0)
		{
			return true;
		}			 
		else 
		{
			return false;
		}
	}

	@Override
	public boolean editUserProfileAssociatedHandles(UserProfileAssociatedHandlesVo associatedHandlesVo) 
	{
		int result=0;
		try
		{
			String updateQuery = "UPDATE tbl_profile_associated_handles SET user_id='"+associatedHandlesVo.getUserId()+"', user_name='"+associatedHandlesVo.getUserName()+"', user_screen_name='"+associatedHandlesVo.getUserScreenName()+"', classification='"+associatedHandlesVo.getClassification()+"', photo='"+associatedHandlesVo.getPhoto()+"', social_media_type='"+associatedHandlesVo.getSocialMediaType()+"' "      
					+ "WHERE id="+associatedHandlesVo.getHandlesId()+" ";
			System.out.println("editUserProfileAssociatedHandles updateQuery: "+updateQuery);
			result = jdbcTemplate.update(updateQuery);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}		 
		if(result>0)
		{
			return true;
		}			 
		else 
		{
			return false;
		}
	}

	@Override
	public boolean editUserProfileAssociatedEvents(UserProfileAssociatedEventsVo associatedEventsVo)
	{
		int result=0;
		try
		{
			String updateQuery = "UPDATE tbl_profile_associated_event SET event_name='"+associatedEventsVo.getEventName()+"', event_date= '"+CommonUtils.string2Date(associatedEventsVo.getEventDate())+"', event_type='"+associatedEventsVo.getEventType()+"', sentiment_of_event='"+associatedEventsVo.getSentimentOfEvent()+"' "
					+ "WHERE id='"+associatedEventsVo.getEventId()+"' ";
			System.out.println("updateQuery: "+updateQuery);
			result = jdbcTemplate.update(updateQuery);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}		 
		if(result>0)
		{
			return true;
		}			 
		else 
		{
			return false;
		}
	}

	@Override
	public boolean editUserProfileAssociatedLocations(UserProfileAssociatedLocationsVo associatedLocationsVo) 
	{
		int result=0;
		try
		{
			String updateQuery = "UPDATE tbl_profile_associated_location SET location_name='"+associatedLocationsVo.getLocationName()+"', frequency='"+associatedLocationsVo.getFrequency()+"', sentiment_of_location='"+associatedLocationsVo.getSentimentOfLocation()+"' "      
					+ "WHERE id="+associatedLocationsVo.getLocationId()+" ";
			System.out.println("updateQuery: "+updateQuery);
			result = jdbcTemplate.update(updateQuery);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}		 
		if(result>0)
		{
			return true;
		}			 
		else 
		{
			return false;
		}
	}

	@Override
	public boolean editUserProfileAssociatedOrganizations(UserProfileAssociatedOrganizationsVo associatedOrganizationsVo)
	{
		int result=0;
		try
		{
			String updateQuery = "UPDATE tbl_profile_associated_organization SET organization_name='"+associatedOrganizationsVo.getOrganizationName()+"', frequency='"+associatedOrganizationsVo.getFrequency()+"', org_category='"+associatedOrganizationsVo.getOrganizationCategory()+"' "      
					+ "WHERE id="+associatedOrganizationsVo.getOrganizationId()+" ";
			System.out.println("editUserProfileAssociatedOrganizations updateQuery: "+updateQuery);
			result = jdbcTemplate.update(updateQuery);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}		 
		if(result>0)
		{
			return true;
		}			 
		else 
		{
			return false;
		}
	}

	@Override
	public ArrayList<UserProfilePhotoVo> getUserProfilePhoto(UserProfilePhotoVo photoVo)
	{
		ArrayList<UserProfilePhotoVo> photoList = new ArrayList<UserProfilePhotoVo>();
		try 
		{
			if(!httpSession.getAttribute("userProfilePhoto").equals(null))
			{
				Integer userPhoto = Integer.parseInt(httpSession.getAttribute("userProfilePhoto").toString());
				String selectQuery = " SELECT id, photo_path FROM tbl_profile_user_photo WHERE id = "+userPhoto+" ";
				System.out.println("getUserProfilePhoto selectQuery: "+selectQuery);
				List<Map<String, Object>> rows = jdbcTemplate.queryForList(selectQuery);
				for(Map<String, Object> rs : rows) 
				{
					UserProfilePhotoVo photo = new UserProfilePhotoVo();
					photo.setPhotoId((Integer)rs.get("id"));
					if(rs.get("photo_path")!=null) 
					{
						String path = TwitterConstant.getPersonProfile();
						String finalPath = path.substring(path.indexOf("ROOT")+4);
						photo.setPhotoPath(finalPath+"/"+(String)rs.get("photo_path"));
					} 
					else 
					{
						photo.setPhotoPath(null);
					}	
					photoList.add(photo);			
				}
			}
			else
			{
				System.out.println("Please upload user profile photo.");
			}
		} 
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return photoList;
	}
	
	@Override
	public ArrayList<UserProfilePhotoVo> getUserProfileCoverPhoto(UserProfilePhotoVo photoVo)
	{
		ArrayList<UserProfilePhotoVo> photoList = new ArrayList<UserProfilePhotoVo>();
		try 
		{
			if(!httpSession.getAttribute("userProfileCoverPhoto").equals(null)) 
			{
				Integer userCoverPhoto = Integer.parseInt(httpSession.getAttribute("userProfileCoverPhoto").toString());
				String selectQuery = " SELECT id, photo_path FROM tbl_profile_user_photo WHERE id = "+userCoverPhoto+" ";
				System.out.println("getUserProfileCoverPhoto selectQuery: "+selectQuery);
				List<Map<String, Object>> rows = jdbcTemplate.queryForList(selectQuery);
				for(Map<String, Object> rs : rows) 
				{
					UserProfilePhotoVo photo = new UserProfilePhotoVo();
					photo.setPhotoId((Integer)rs.get("id"));
					if(rs.get("photo_path")!=null) 
					{
						String path = TwitterConstant.getPersonProfile();
						String finalPath = path.substring(path.indexOf("ROOT")+4);
						photo.setPhotoPath(finalPath+"/"+(String)rs.get("photo_path"));
					} 
					else 
					{
						photo.setPhotoPath(null);
					}	
					photoList.add(photo);
				}
			} 
			else 
			{
				System.out.println("Please upload user profile cover photo.");
			}
		} 
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return photoList;
	}

	@Override
	public void saveSocialAccountToTargetView(CaseVo caseVo)  
	{		
		Integer profileId = Integer.parseInt(httpSession.getAttribute("profileId").toString());
		System.out.println("profileId: "+profileId);

		String user=(String)httpSession.getAttribute(ApplicationConstants.LOGIN_USER);
		String userId=(String)httpSession.getAttribute(ApplicationConstants.LOGINUSERID);
		try 
		{
			String query = null;
			Object[] obj = null;
			System.out.println("Mode==="+caseVo.getActType().toLowerCase().trim());

			if(caseVo.getActType().toLowerCase().trim().equals("new"))
			{
				//int profileId=Integer.parseInt(caseVo.getCaseId());
				System.out.println("profileId: "+profileId);
				//caseId=profileId
				System.out.println("Created Entity Start");

				for(EntityVo entityVo : caseVo.getLstEntityVos())
				{
					if(CommonUtils.stringNotEmpty(entityVo.getEntityName()))
					{
						boolean isFlag=true;
						//check for existing entity
						if((entityVo.getEntityType().toLowerCase().equals("p") || entityVo.getEntityType().toLowerCase().equals("l")) && (entityVo.getEntitySourceType().toLowerCase().equals("tw") 
								|| entityVo.getEntitySourceType().toLowerCase().equals("fb") || entityVo.getEntitySourceType().toLowerCase().equals("insta") 
								|| entityVo.getEntitySourceType().toLowerCase().equals("yt")
								|| entityVo.getEntitySourceType().toLowerCase().equals("gp") || entityVo.getEntitySourceType().toLowerCase().equals("dm")
								|| entityVo.getEntitySourceType().toLowerCase().equals("gb") || entityVo.getEntitySourceType().toLowerCase().equals("tm")
								))
						{
							System.out.println(" Check Exiting Profile Entity Of "+entityVo.getEntitySourceType().toLowerCase());
							int countId=jdbcTemplate.queryForObject("select count(*) from  tbl_entity where  entity_type=? and entity_source_type=? and entity_id=?",new Object[]{entityVo.getEntityType().trim(),entityVo.getEntitySourceType().trim(),entityVo.getEntitySocialId().trim()}, Integer.class);
							if(countId>0)
							{
								isFlag=false;
								System.out.println("Entity Is Existed");
							}
						}

						query= " insert ignore into tbl_entity(entity_name, entity_id, entity_stats, entity_type, entity_source_type, entity_url, date_of_creation, entity_img, tw_id, fbtype, yttype) values(?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY update activation_flag=1 " ;
						obj=new Object[]{CommonUtils.removeSpaceFromTxt(entityVo.getEntityName().trim()),entityVo.getEntitySocialId().trim(),entityVo.getEntityStats().trim(),entityVo.getEntityType().trim(),
								entityVo.getEntitySourceType().trim(),entityVo.getEntityUrl().trim(),CommonUtils.getSqlCurrentDateTime(),entityVo.getEntityImg().trim(),entityVo.getTwId(),
								entityVo.getFbType().trim(),entityVo.getYtType().trim()
						};
						jdbcTemplate.update(query,obj);

						System.out.println("query: "+query);
						System.out.println("entity_name="+CommonUtils.removeSpaceFromTxt(entityVo.getEntityName().trim()));
						System.out.println("entity_id="+entityVo.getEntitySocialId().trim());
						System.out.println("entity_type="+entityVo.getEntityType().trim());
						System.out.println("entity_source_type="+entityVo.getEntitySourceType().trim());
						System.out.println("entity_url="+entityVo.getEntityUrl().trim());
						System.out.println("date_of_creation="+CommonUtils.getSqlCurrentDateTime());
						System.out.println("entity_img="+entityVo.getEntityImg().trim());
						System.out.println("tw_id="+entityVo.getTwId());

						String tweetUserId1="";
						if(profileId>0)
						{
							System.out.println(" Insert Data Into Case_entity");
							String entityIdFb="0";
							String entityIdFbPageName="";
							String ytType="0", fbType="0";

							int entityId=0;
							List<Map<String, Object>> rows = jdbcTemplate.queryForList("select id,entity_id,tw_id,entity_name,ytType,fbType from tbl_entity where entity_name=? and entity_type=? and entity_source_type=?",new Object[]{CommonUtils.removeSpaceFromTxt(entityVo.getEntityName().trim()),entityVo.getEntityType().trim(),entityVo.getEntitySourceType().trim()});

							for(Map<String, Object> rs :rows)
							{
								entityId=Integer.parseInt(rs.get("id").toString());
								tweetUserId1=rs.get("tw_id")==null?"":rs.get("tw_id").toString();
								entityIdFb=(rs.get("entity_id")==null?"":rs.get("entity_id").toString());
								entityIdFbPageName=(rs.get("entity_name")==null?"":rs.get("entity_name").toString());
								ytType=rs.get("ytType")==null?"0":rs.get("ytType").toString();
								fbType=rs.get("fbType")==null?"0":rs.get("fbType").toString();
							}

							System.out.println("entityId="+entityId);
							System.out.println("tweetUserId1="+tweetUserId1);
							System.out.println("entityIdFb="+entityIdFb);
							System.out.println("entityId="+entityId);
							System.out.println("entityIdFbPageName="+entityIdFbPageName);
							System.out.println("ytType="+ytType);
							System.out.println("fbType="+fbType);

							//case_entity
							if(profileId>0)
							{
								query="insert ignore into tbl_profile_social_account(profile_id, entityId) values(?,?)";
								obj=new Object[]{profileId, entityId};
								jdbcTemplate.update(query, obj);

								System.out.println("INSERT query for table tbl_profile_social_account:======> "+query);
								System.out.println("profileId=="+profileId);
								System.out.println("entityId=="+entityId);
							}

							//Insert into twitter_extract_data for Follower,Following,Last 3200 tweets
							if(entityVo.getEntityType().toLowerCase().equals("p") && entityVo.getEntitySourceType().toLowerCase().equals("tw"))
							{  
								System.out.println("Insert Into Twitter Extract ");
								if(isFlag)
								{
									query="insert ignore into twitter_extract_data(userId, type) values(?,?)";
									obj=new Object[]{tweetUserId1, "FW"};
									jdbcTemplate.update(query, obj);
									System.out.println(query);
									System.out.println("tweetUserId1="+tweetUserId1);
									System.out.println("FW");

									query="insert ignore into twitter_extract_data(userId, type) values(?,?)";
									obj=new Object[]{tweetUserId1, "FO"};
									jdbcTemplate.update(query, obj);
									System.out.println(query);
									System.out.println("tweetUserId1="+tweetUserId1);
									System.out.println("FO");

									query="insert ignore into twitter_extract_data(userId, type) values(?,?)";
									obj=new Object[]{tweetUserId1, "TW"};
									jdbcTemplate.update(query, obj);
									System.out.println(query);
									System.out.println("tweetUserId1="+tweetUserId1);
									System.out.println("TW");

									query="insert ignore into twitter_extract_data(userId, type) values(?,?)";
									obj=new Object[]{tweetUserId1, "FAV"};
									jdbcTemplate.update(query, obj);
									System.out.println(query);
									System.out.println("tweetUserId1="+tweetUserId1);
									System.out.println("FAV");
								}
							}

							//Insert into fb_crawl_status
							else if(entityVo.getEntityType().toLowerCase().equals("p") && entityVo.getEntitySourceType().toLowerCase().equals("fb") )
							{
								System.out.println("Insert INTO fb_crawl_status");
								if(isFlag)
								{
									if(entityVo.getFbType().equals("0"))
									{
										query="insert ignore into fb_crawl_status(page_id,work_type,page_date,page_name)values(?,?,?,?)";
										obj=new Object[]{entityIdFb,"info",TwitterConstant.GetFbPageToCrawleDate(),entityIdFbPageName};
										jdbcTemplate.update(query, obj);

										query="insert ignore into fb_crawl_status(page_id,work_type,page_date,page_name)values(?,?,?,?)";
										obj=new Object[]{entityIdFb,"insight",TwitterConstant.GetFbPageToCrawleDate(),entityIdFbPageName};
										jdbcTemplate.update(query, obj);

										query="insert ignore into fb_crawl_status(page_id,work_type,page_date,page_name)values(?,?,?,?)";
										obj=new Object[]{entityIdFb,"like",TwitterConstant.GetFbPageToCrawleDate(),entityIdFbPageName};
										jdbcTemplate.update(query, obj);

										query="insert ignore into fb_crawl_status(page_id,work_type,page_date,page_name)values(?,?,?,?)";
										obj=new Object[]{entityIdFb,"post",TwitterConstant.GetFbPageToCrawleDate(),entityIdFbPageName};
										jdbcTemplate.update(query, obj);
									}
									else
									{
										query="insert ignore into fb_crawl_sele_profile_status(entity_id,user_id,user_name)values(?,?,?)";
										obj=new Object[]{entityId, entityIdFb, entityIdFbPageName};
										jdbcTemplate.update(query, obj);
									}

									System.out.println(query);
									System.out.println("entityId=="+entityId);
									System.out.println("entityIdFb=="+entityIdFb);
									System.out.println("page Crawl Date=="+TwitterConstant.GetFbPageToCrawleDate());
									System.out.println("entityIdFbPageName=="+entityIdFbPageName);
								}
							}

							//Insert into insta_crawl_status
							else if(entityVo.getEntitySourceType().toLowerCase().equals("insta"))
							{
								System.out.println(" Insert Into insta_crawl_status");
								if(isFlag)
								{
									System.out.println("entity TYpe=="+entityVo.getEntityType().toLowerCase());
									switch(entityVo.getEntityType().toLowerCase())
									{																				
									case "p":
										query="insert ignore into insta_crawl_status(entity_id,profile_id,type,work_type,page_date)values(?,?,?,?,?)";
										obj=new Object[]{entityId,entityIdFb,"p","post",TwitterConstant.GetInstaToCrawleDate()};
										jdbcTemplate.update(query,obj);
										System.out.println("post");

										query="insert ignore into insta_crawl_status(entity_id,profile_id,type,work_type,page_date)values(?,?,?,?,?)";
										obj=new Object[]{entityId,entityIdFb,"p","fo",TwitterConstant.GetInstaToCrawleDate()};
										jdbcTemplate.update(query,obj);
										System.out.println("fo");

										query="insert ignore into insta_crawl_status(entity_id,profile_id,type,work_type,page_date)values(?,?,?,?,?)";
										obj=new Object[]{entityId,entityIdFb,"p","fw",TwitterConstant.GetInstaToCrawleDate()};
										jdbcTemplate.update(query,obj);
										System.out.println("fw");

										System.out.println(query);
										System.out.println("entityId="+entityId);
										System.out.println("ProfileId="+entityIdFb);
										System.out.println("twitterConstant.GetInstaToCrawleDate()="+TwitterConstant.GetInstaToCrawleDate());
										break;
									default:
										break;
									}
								}
							}

							//Insert into Yt_crawl_status
							else if(entityVo.getEntitySourceType().toLowerCase().equals("yt"))
							{
								if(isFlag)
								{
									System.out.println("entity TYpe=="+entityVo.getEntityType().toLowerCase());
									query="insert ignore into yt_crawl_status(entity_id,page_date,before_date,after_date)values(?,?,?,?)";
									System.out.println("YouTube before Date:: "+twitterConstant.getYoutubeBeforeDateYYYYMMDD());
									System.out.println("YouTube after Date:: "+twitterConstant.getYouTubeAfterDateYYYYMMDD());

									obj=new Object[]{entityId,twitterConstant.GetInstaToCrawleDate(),twitterConstant.getYoutubeBeforeDateYYYYMMDD(),twitterConstant.getYouTubeAfterDateYYYYMMDD()};
									jdbcTemplate.update(query, obj);
									System.out.println(query);
								}
							}

							//Insert into gp_crawl_status
							else if(entityVo.getEntitySourceType().toLowerCase().equals("gp"))
							{
								if(isFlag)
								{
									query="insert ignore into gp_crawl_status(entity_id,page_date)values(?,?)";
									obj=new Object[]{entityId,twitterConstant.GetGpToCrawleDate()};
									jdbcTemplate.update(query, obj);
									System.out.println(query);
								}
							}

							//Insert into dm_crawl_status
							else if(entityVo.getEntitySourceType().toLowerCase().equals("dm"))
							{
								if(isFlag)
								{
									query="insert ignore into dm_crawl_status(entity_id,page_date)values(?,?)";
									obj=new Object[]{entityId,twitterConstant.GetGpToCrawleDate()};
									jdbcTemplate.update(query, obj);
									System.out.println(query);
								}
							}

							//Insert into gb_crawl_status
							else if(entityVo.getEntitySourceType().toLowerCase().equals("gb") && entityVo.getEntityType().toLowerCase().equals("p"))
							{
								if(isFlag)
								{
									query="insert ignore into gb_crawl_status(entity_id)values(?)";
									obj=new Object[]{entityId};
									jdbcTemplate.update(query, obj);
									System.out.println(query);
								}
							}

							//Insert into tm_crawl_status
							else if(entityVo.getEntitySourceType().toLowerCase().equals("tm"))
							{
								if(isFlag)
								{
									query="insert ignore into tm_crawl_status(entity_id)values(?)";
									obj=new Object[]{entityId};
									jdbcTemplate.update(query, obj);
									System.out.println(query);
								}
							}
						}
					}
					System.out.println(CommonUtils.removeSpaceFromTxt(entityVo.getEntityName().trim()) +" Inserted Successfully");
				}
			}				
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		} 		
	}


	@Override
	public void saveSocialMediaAccountToTargetProfileView(CaseVo caseVo) 
	{		
		TransactionDefinition def = new DefaultTransactionDefinition();
		TransactionStatus status = transactionManager.getTransaction(def);

		try 
		{
			Object[] obj = null;
			System.out.println("Mode==="+caseVo.getActType().toLowerCase().trim());

			System.out.println("Created Entity Start");				
			int id= caseVo.getTargetProfileId();
			System.out.println("id: "+id);

			String deleteQuery = "DELETE FROM tbl_profile_social_account WHERE profile_id ="+caseVo.getTargetProfileId()+" ";
			jdbcTemplate.update(deleteQuery);
			System.out.println("deleteQuery: "+deleteQuery);

			for(EntityVo entityVo : caseVo.getLstEntityVos())
			{
				if(CommonUtils.stringNotEmpty(entityVo.getEntityName()))
				{

					String query= "insert ignore into tbl_profile_social_account(profile_id, entity_name, entity_id, entity_source_type, entity_url, entity_img, tw_id) values(?,?,?,?,?,?,?)" ;
					obj=new Object[]{
							caseVo.getTargetProfileId(), CommonUtils.removeSpaceFromTxt(entityVo.getEntityName().trim()), entityVo.getEntitySocialId().trim(),
							entityVo.getEntitySourceType().trim(), entityVo.getEntityUrl().trim(), entityVo.getEntityImg().trim(), entityVo.getTwId()						
					};
					jdbcTemplate.update(query, obj);												

					System.out.println("query: "+query);
					System.out.println("entity_name="+CommonUtils.removeSpaceFromTxt(entityVo.getEntityName().trim()));
					System.out.println("entity_id="+entityVo.getEntitySocialId().trim());
					System.out.println("entity_source_type="+entityVo.getEntitySourceType().trim());
					System.out.println("entity_url="+entityVo.getEntityUrl().trim());
					System.out.println("entity_img="+entityVo.getEntityImg().trim());
					System.out.println("tw_id="+entityVo.getTwId());					
				}
				System.out.println(CommonUtils.removeSpaceFromTxt(entityVo.getEntityName().trim()) +" Inserted Successfully");
			}				
			transactionManager.commit(status);						
		}
		catch(Exception ex) 
		{
			transactionManager.rollback(status);
			ex.printStackTrace();
		} 		
	}

	@Override
	public ArrayList<UserProfileBasicInformationVo> getTargetProfileBasicInformationsDetailsReport(UserProfileBasicInformationVo basicInformationVo) {
		ArrayList<UserProfileBasicInformationVo> userList = new ArrayList<UserProfileBasicInformationVo>();
		try {
			String selectQuery = "SELECT id, first_name, last_name, profile_photo_id, profile_cover_photo_id, "
					+ "permanent_address, local_address, father_name, mother_name, dob, gender, nationality, "
					+ "martial_status, addahar_card, pan_card, passport_no, description, classification, "
					+ "(SELECT GROUP_CONCAT(alias) FROM tbl_profile_alias WHERE tbl_profile_alias.profile_id=tbl_profile.id) AS alias "
					+ "FROM tbl_profile "
					+ "WHERE id="+basicInformationVo.getProfileId()+" ";

			System.out.println("selectQuery: "+selectQuery);			

			List<Map<String, Object>> rows = jdbcTemplate.queryForList(selectQuery);
			for(Map<String, Object> rs : rows) {
				UserProfileBasicInformationVo user = new UserProfileBasicInformationVo();				
				user.setProfileId((Integer)(rs.get("id")));
				user.setFirstName((String)(rs.get("first_name")));
				user.setLastName((String)(rs.get("last_name")));	
				user.setProfilePhotoId((Integer)(rs.get("profile_photo_id")));
				user.setProfileCoverPhotoId((Integer)(rs.get("profile_cover_photo_id")));										
				user.setPermanentAddress((String)(rs.get("permanent_address")));
				user.setLocalAddress((String)(rs.get("local_address")));
				user.setFatherName((String)(rs.get("father_name")));
				user.setMotherName((String)(rs.get("mother_name")));
				user.setDob((String)(rs.get("dob")));
				user.setGender((String)(rs.get("gender")));
				user.setNationality((String)(rs.get("nationality")));
				user.setMartialStatus((String)(rs.get("martial_status")));
				user.setAddaharCard((String)(rs.get("addahar_card")));
				user.setPanCard((String)(rs.get("pan_card")));
				user.setPassportNo((String)(rs.get("passport_no")));
				user.setDescription((String)(rs.get("description")));
				user.setClassification((String)(rs.get("classification")));
				user.setAlias(rs.get("alias")==null?"":rs.get("alias").toString());			
				userList.add(user);			
			}			
		} catch(Exception ex) {
			ex.printStackTrace();
		}		
		return userList;	
	}

	@Override
	public ArrayList<UserProfilePhotoVo> getTargetProfileCoverPhotoReport(UserProfilePhotoVo photoVo) {		
		ArrayList<UserProfilePhotoVo> photoList = new ArrayList<UserProfilePhotoVo>();
		try {
			String selectQuery = " SELECT id, photo_path FROM tbl_profile_user_photo "
					+ " WHERE id = "+photoVo.getPhotoId()+" ";
			System.out.println("getTargetProfileCoverPhotoReport selectQuery: "+selectQuery);		        		        
			List<Map<String, Object>> rows = jdbcTemplate.queryForList(selectQuery);
			for(Map<String, Object> rs : rows) {
				UserProfilePhotoVo photo = new UserProfilePhotoVo();					
				photo.setPhotoId((Integer)rs.get("id"));
				
				if(rs.get("photo_path")!=null) {
					String path = TwitterConstant.getPersonProfile();
					String finalPath = path.substring(path.indexOf("ROOT")+4);
					photo.setPhotoPath(finalPath+"/"+(String)rs.get("photo_path"));
				} else {
					photo.setPhotoPath(null);
				}	
				photoList.add(photo);	
			}
		} catch(Exception ex) {
			ex.printStackTrace();
		}
		return photoList;
	}

	@Override
	public ArrayList<UserProfilePhotoVo> getTargetProfilePhotoReport(UserProfilePhotoVo photoVo) {		
		ArrayList<UserProfilePhotoVo> photoList = new ArrayList<UserProfilePhotoVo>();
		try {
			String selectQuery = " SELECT id, photo_path FROM tbl_profile_user_photo WHERE id = "+photoVo.getPhotoId()+" ";
			System.out.println("getTargetProfilePhotoReport selectQuery: "+selectQuery);
			List<Map<String, Object>> rows = jdbcTemplate.queryForList(selectQuery);
			for(Map<String, Object> rs : rows) {
				UserProfilePhotoVo photo = new UserProfilePhotoVo();				
				photo.setPhotoId((Integer)rs.get("id"));
				
				if(rs.get("photo_path")!=null) {
					String path = TwitterConstant.getPersonProfile();
					String finalPath = path.substring(path.indexOf("ROOT")+4);
					photo.setPhotoPath(finalPath+"/"+(String)rs.get("photo_path"));
				} else {
					photo.setPhotoPath(null);
				}	
				photoList.add(photo);			
			}
		} catch(Exception ex) {
			ex.printStackTrace();
		}
		return photoList;
	}

	@Override
	public ArrayList<UserProfileContactVo> getTargetProfileContactDetailsReport(UserProfileContactVo contactVo) 
	{
		ArrayList<UserProfileContactVo> contactList = null;
		try
		{
			String selectQuery="";

			selectQuery = "SELECT id, contact, contact_type, contact_primary "
					+ "FROM tbl_profile_contact "
					+ "WHERE profile_id="+contactVo.getProfileId()+" ORDER BY id DESC";
			System.out.println("selectQuery: "+selectQuery);
			contactList = new ArrayList<UserProfileContactVo>();
			List<Map<String, Object>> rows = jdbcTemplate.queryForList(selectQuery);

			for(Map<String, Object> row : rows)
			{
				UserProfileContactVo contact = new UserProfileContactVo();
				contact.setContactId((Integer)(row.get("id")));
				contact.setContact((String)(row.get("contact")));
				contact.setContactType((String)(row.get("contact_type")));
				contact.setContactPrimary((String)(row.get("contact_primary")));
				contactList.add(contact);
			}									
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return contactList;
	}


	@Override
	public ArrayList<CaseVo> getMappedProxy(CaseVo caseVo)
	{
		ArrayList<CaseVo> lst=new ArrayList<CaseVo>();
		try {
			String query="	SELECT id,proxy_ip,port,country,country_code from tbl_crawl_proxy where  country_code = '"+caseVo.getId()+"'";
			System.out.println("Country Proxy Mapped Query: "+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs : rows){
				CaseVo caseVoObj=new CaseVo();
				caseVoObj.setId(rs.get("id")==null?"":rs.get("id").toString());
				caseVoObj.setKey1(rs.get("proxy_ip")==null?"":rs.get("proxy_ip").toString());
				caseVoObj.setKey2(rs.get("port")==null?"":rs.get("port").toString());
				caseVoObj.setKey3(rs.get("country")==null?"":rs.get("country").toString());
				caseVoObj.setKey4(rs.get("country_code")==null?"":rs.get("country_code").toString());
				lst.add(caseVoObj);
			}
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		} 
		return lst;
	}

	@Override
	public ArrayList<CaseVo> getMappedProxyByCntry(CaseVo caseVo) {
		ArrayList<CaseVo> lst=new ArrayList<CaseVo>();
		try {
			String	query="	SELECT * FROM tbl_crawl_proxy WHERE tbl_crawl_proxy.id IN ("+
					"SELECT tbl_crawler_proxy_mapping.proxy_id FROM tbl_crawler_proxy_mapping WHERE tbl_crawler_proxy_mapping.crawler_id = '"+caseVo.getId()+"')";
			System.out.println("getManageCrawler=="+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs : rows){
				CaseVo caseVoObj=new CaseVo();
				caseVoObj.setId(rs.get("id")==null?"":rs.get("id").toString());
				caseVoObj.setKey1(rs.get("proxy_ip")==null?"":rs.get("proxy_ip").toString());
				caseVoObj.setKey2(rs.get("port")==null?"":rs.get("port").toString());
				caseVoObj.setKey3(rs.get("country")==null?"":rs.get("country").toString());
				caseVoObj.setKey4(rs.get("country_code")==null?"":rs.get("country_code").toString());
				caseVoObj.setId((rs.get("id").toString()));
				lst.add(caseVoObj);
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return lst; 

	}

	@Override
	public ArrayList<CaseVo> getMenuCountry(CaseVo caseVo) 
	{
		ArrayList<CaseVo> lst=new ArrayList<CaseVo>();
		try {
			String query="SELECT DISTINCT country,Country_Code FROM article_source WHERE Country_Code IS NOT NULL"; 
			System.out.println("getMenuCountry ::"+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs : rows){
				CaseVo caseVoObj=new CaseVo();
				//caseVoObj.setId(rs.get("id")==null?"":rs.get("id").toString());
				caseVoObj.setKey1(rs.get("country")==null?"":rs.get("country").toString());
				caseVoObj.setKey2(rs.get("Country_Code")==null?"":rs.get("Country_Code").toString());
				lst.add(caseVoObj);
			}
		}catch (Exception e) {
			e.printStackTrace();
		} 
		return lst;
	}

	@Override
	public ArrayList<CaseVo> getCountryRssMap(CaseVo caseVo) 
	{
		ArrayList<CaseVo> lst=new ArrayList<CaseVo>();
		try 
		{
			String query="SELECT art_source,art_source_rss FROM article_source WHERE country IN  ("+caseVo.getCaseName()+")";
			System.out.println("getCountryRssMap ::"+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs : rows)
			{
				CaseVo caseVoObj=new CaseVo();
				//caseVoObj.setId(rs.get("id")==null?"":rs.get("id").toString());
				caseVoObj.setKey1(rs.get("art_source")==null?"":rs.get("art_source").toString());
				caseVoObj.setKey2(rs.get("art_source_rss")==null?"":rs.get("art_source_rss").toString());
				lst.add(caseVoObj);
			}
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		}
		return lst;
	}

	@Override
	public void addUserAlerts(CaseVo caseVo) 
	{
		String user=(String)httpSession.getAttribute(ApplicationConstants.LOGINUSERID);
		if(caseVo.getId().equals(""))
		{
			String	query=" insert ignore into "
					+ "tbl_alert(alert_name, keyword, mail_to, mail_cc, mail_bcc, mobile_no, alert_via_m, alert_via_e, notification, activation_flag,"
					+ " login_id, alert_created_at, frequency, count_limit, sentiment, user, alert_type, case_id, snapshot_id, threat_classification) "
					+ " values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
			System.out.println("addUserAlerts=="+query);
			KeyHolder keyHolder = new GeneratedKeyHolder();
			jdbcTemplate.update(new PreparedStatementCreator() {
				public PreparedStatement createPreparedStatement(Connection connection) throws SQLException {
					PreparedStatement ps = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
					ps.setString(1, caseVo.getKey1().trim());
					ps.setString(2, caseVo.getKey2()==null?"":caseVo.getKey2().trim());
					ps.setString(3, caseVo.getKey7().trim());
					ps.setString(4, caseVo.getKey8().trim());
					ps.setString(5, caseVo.getKey9().trim());
					ps.setString(6, caseVo.getKey10().trim());
					ps.setString(7, caseVo.getKey5().trim());
					ps.setString(8, caseVo.getKey6().trim());
					ps.setString(9, caseVo.getKey11().trim());
					//ps.setString(10, caseVo.getKey3().trim());
					ps.setString(10, caseVo.getKey4().trim());
					ps.setString(11, user);
					ps.setString(12, CommonUtils.getSqlCurrentDateTime());
					ps.setString(13, caseVo.getFrequency().trim());
					ps.setString(14, caseVo.getCountLimit().trim());
					ps.setString(15, caseVo.getSentiment().trim());
					ps.setString(16, caseVo.getUser().trim());
					ps.setString(17, caseVo.getAccountType().trim());
					ps.setInt(18, (caseVo.getCaseId()==null || caseVo.getCaseId()=="")?0:Integer.parseInt(caseVo.getCaseId().trim()));
					ps.setInt(19, (caseVo.getUserId()==null || caseVo.getUserId()=="")?0:Integer.parseInt(caseVo.getUserId().trim()));
					ps.setString(20, caseVo.getThreatScore().trim());
					
					return ps;
				}
			}, keyHolder);
			System.out.println("add alert: "+query);
			int crawlerAutogenertdId=keyHolder.getKey().intValue();
			
			ArrayList<ArrayList<String>> alertDay=caseVo.getAlertDay();
			for(ArrayList<String> dayList : alertDay) 
			{
				String query2=" insert ignore into tbl_alert_interval(alert_id, day, hour, minutes) values(?, ?, ?, ?)";
				System.out.println("add alert interval   "+query2);
				jdbcTemplate.update(query2, new Object[] {crawlerAutogenertdId,dayList.get(0),dayList.get(1),dayList.get(2)});
			}
		}
		else 
		{
			System.out.println("start Update");
			String keyword = caseVo.getKey2()==null?"":caseVo.getKey2().trim();
			int caseId = caseVo.getCaseId()==null?0:Integer.parseInt(caseVo.getCaseId().trim());
			int snapshotId = caseVo.getUserId()==null?0:Integer.parseInt(caseVo.getUserId().trim());
			String sentiment = caseVo.getSentiment().trim().length()==0?"0":caseVo.getSentiment().trim();
			String threatClassification = caseVo.getThreatScore().trim();
					
			String query=" update tbl_alert set keyword='"+keyword+"',"
					+ " mail_to='"+caseVo.getKey7().trim()+"', mail_cc='"+caseVo.getKey8().trim()+"', mail_bcc='"+caseVo.getKey9().trim()+"',"
					+ " mobile_no='"+caseVo.getKey10().trim()+"', alert_via_m='"+caseVo.getKey5().trim()+"', alert_via_e='"+caseVo.getKey6().trim()+"',"
					+ " notification='"+caseVo.getKey11().trim()+"', frequency='"+caseVo.getFrequency().trim()+"', count_limit='"+caseVo.getCountLimit().trim()+"',"
					+ " sentiment='"+sentiment+"', threat_classification='"+threatClassification+"', user='"+caseVo.getUser().trim()+"', alert_type='"+caseVo.getAccountType().trim()+"',"
					+ " case_id="+caseId+", snapshot_id="+snapshotId+"  where id='"+caseVo.getId()+"'";
			System.out.println("update alert : "+query);
			jdbcTemplate.update(query);
			
			query="delete from tbl_alert_interval where alert_id = '"+caseVo.getId()+"'";
			System.out.println("delete interval=="+query);
			jdbcTemplate.update(query);

			ArrayList<ArrayList<String>> alertDay=caseVo.getAlertDay();
			for(ArrayList<String> dayList : alertDay) 
			{
				String query2=" insert ignore into tbl_alert_interval(alert_id,day,hour,minutes) values(?,?,?,?)";
				System.out.println("add alert interval::"+query2);
				jdbcTemplate.update(query2, new Object[] {caseVo.getId(),dayList.get(0),dayList.get(1),dayList.get(2)});
			}
		}
	}

	@Override
	public ArrayList<CaseVo> getAlertByUsers(CaseVo caseVo) 
	{
		String userName =(String)httpSession.getAttribute(ApplicationConstants.LOGINUSERID);
		String userRole =(String)httpSession.getAttribute(ApplicationConstants.USERROLE);
		ArrayList<CaseVo> lst=new ArrayList<CaseVo>();
		try 
		{
			String subQuery="";
			String sortQuery="";
			if(!userRole.toLowerCase().equals("a"))
			{
				subQuery+=" and tbl_alert.login_id='"+userName+"'";
			}

			switch(caseVo.getActType())
			{
			case "1":
				subQuery+=" and tbl_alert.activation_flag='1'";
				break;
			case "0":
				subQuery+=" and tbl_alert.activation_flag='0'";
				break;
			}

			switch(caseVo.getEntitySortStatus())
			{
			case "dd":
				sortQuery=" order by id DESC ";
				break;
			case "da":
				sortQuery=" order by tbl_alert.alert_created_at ASC ";
				break;
			case "na":
				sortQuery=" order by tbl_alert.alert_name ASC ";
				break;
			case "nd":
				sortQuery=" order by tbl_alert.alert_name DESC ";
				break;
			case "ada": //alert sent date asc
				sortQuery=" order by alert_date ASC ";
				break;
			case "add": //alert sent date desc
				sortQuery=" order by alert_date DESC ";
				break;
			}
			String query=" SELECT tbl_alert.id,tbl_alert.alert_name,tbl_alert.keyword,tbl_alert.activation_flag,login_detail.user_logon_id,"
					+ " COALESCE(DATE_FORMAT((tbl_alert.alert_created_at),'%b %d,%Y %r'),'') AS alert_created_at, "
					+ "  COALESCE(DATE_FORMAT((SELECT MAX(alert_date_time) FROM tbl_alert_result WHERE main_alert_id=tbl_alert.id),'%b %d,%Y %r'),'') AS alert_date  "
					+ " FROM tbl_alert"
					+ " INNER JOIN login_detail ON login_detail.id=tbl_alert.login_id "
					+ " where  (tbl_alert.alert_name like '%"+caseVo.getCaseName()+"%' or tbl_alert.keyword like '%"+caseVo.getCaseName()+"%')"
					+subQuery + sortQuery ;
			System.out.println("Get User Alerts Query :: "+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs : rows){
				CaseVo caseVoObj=new CaseVo();
				caseVoObj.setId(rs.get("id")==null?"":rs.get("id").toString());
				caseVoObj.setKey1(rs.get("alert_name")==null?"":rs.get("alert_name").toString());
				caseVoObj.setKey2(rs.get("keyword")==null?"":rs.get("keyword").toString());
				caseVoObj.setKey3(rs.get("alert_created_at")==null?"":rs.get("alert_created_at").toString());
				caseVoObj.setKey4(rs.get("user_logon_id")==null?"":rs.get("user_logon_id").toString());
				caseVoObj.setKey5(rs.get("alert_date")==null?"":rs.get("alert_date").toString());
				caseVoObj.setKey6(rs.get("activation_flag")==null?"":rs.get("activation_flag").toString());
				lst.add(caseVoObj);
			}
		}catch (Exception e) {
			e.printStackTrace();
		} 
		return lst;
	}

	@Override
	public ArrayList<CaseVo> dltUserAlerts(CaseVo caseVo) {
		ArrayList<CaseVo> lst=new ArrayList<CaseVo>();
		TransactionDefinition def = new DefaultTransactionDefinition();
		TransactionStatus status = transactionManager.getTransaction(def);
		String query="";
		try 
		{
			query= " DELETE tbl_alert_result.* FROM tbl_alert_result "
					+ " INNER JOIN tbl_alert_interval ON tbl_alert_result.alert_id = tbl_alert_interval.id "
					+ " INNER JOIN tbl_alert ON tbl_alert.id = tbl_alert_interval.alert_id  "
					+ " where tbl_alert.id= '"+caseVo.getId()+"' " ;
			System.out.println("Delete tbl_alert_result:: "+query);
			jdbcTemplate.update(query);

			query= " delete from tbl_alert where id= '"+caseVo.getId()+"' " ;
			System.out.println("Delete tbl_alert :: "+query);
			jdbcTemplate.update(query);

			query= " delete from tbl_alert_interval where alert_id= '"+caseVo.getId()+"' " ;
			System.out.println("Delete tbl_alert_interval:: "+query);
			jdbcTemplate.update(query);

			transactionManager.commit(status);	
		}
		catch (Exception e) 
		{
			transactionManager.rollback(status);
			e.printStackTrace();
		} 
		return lst;	
	}

	@Override
	public void actDactAlertValue(CaseVo caseVo)
	{
		try
		{
			String	query= "update tbl_alert set activation_flag='"+caseVo.getEntityId()+"' where id='"+caseVo.getId()+"'" ;
			System.out.println("actDactAlertValue: "+query);
			jdbcTemplate.update(query);
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		} 
	}

	@Override
	public ArrayList<CaseVo> getAlertByUsersId(CaseVo caseVo) 
	{
		ArrayList<CaseVo> lst=new ArrayList<CaseVo>();
		try 
		{
			String query="	SELECT id, alert_name, keyword, mail_to, mail_cc, mail_bcc, mobile_no, alert_via_m, alert_via_e, notification, activation_flag,"
					+ " login_id, frequency, count_limit, sentiment, user, alert_type, case_id, snapshot_id from tbl_alert where  id = '"+caseVo.getId()+"'";
			System.out.println("Query: "+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs : rows)
			{
				CaseVo caseVoObj=new CaseVo();
				caseVoObj.setId(rs.get("id")==null?"":rs.get("id").toString());
				caseVoObj.setKey1(rs.get("alert_name")==null?"":rs.get("alert_name").toString());
				caseVoObj.setKey2(rs.get("keyword")==null?"":rs.get("keyword").toString());
				caseVoObj.setKey3(rs.get("mail_to")==null?"":rs.get("mail_to").toString());
				caseVoObj.setKey4(rs.get("mail_cc")==null?"":rs.get("mail_cc").toString());
				caseVoObj.setKey5(rs.get("mail_bcc")==null?"":rs.get("mail_bcc").toString());
				caseVoObj.setKey6(rs.get("alert_via_m")==null?"":rs.get("alert_via_m").toString());
				caseVoObj.setKey7(rs.get("alert_via_e")==null?"":rs.get("alert_via_e").toString());
				caseVoObj.setKey8(rs.get("activation_flag")==null?"":rs.get("activation_flag").toString());
				//caseVoObj.setKey9(rs.get("alert_send_time")==null?"":rs.get("alert_send_time").toString());
				caseVoObj.setKey10(rs.get("mobile_no")==null?"":rs.get("mobile_no").toString());
				caseVoObj.setKey11(rs.get("notification")==null?"":rs.get("notification").toString());
				caseVoObj.setFrequency(rs.get("frequency")==null?"":rs.get("frequency").toString());
				caseVoObj.setCountLimit(rs.get("count_limit")==null?"":rs.get("count_limit").toString());
				caseVoObj.setSentiment(rs.get("sentiment")==null?"":rs.get("sentiment").toString());
				caseVoObj.setUser(rs.get("user")==null?"":rs.get("user").toString());
				caseVoObj.setAccountType(rs.get("alert_type")==null?"":rs.get("alert_type").toString());
				caseVoObj.setUserId(rs.get("case_id")==null?"":rs.get("case_id").toString());
				caseVoObj.setCaseId(rs.get("snapshot_id")==null?"":rs.get("snapshot_id").toString());
				lst.add(caseVoObj);
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		} 
		return lst;
	}


	@Override
	public boolean addOrganizationViewBasicInformationDetails(OrganizationBasicInformationVo orgBasicInfo) 
	{
		int statusUpdate=1;
		String userName =(String)httpSession.getAttribute(ApplicationConstants.LOGINUSERID);		
		String type = "O";
		TransactionDefinition def = new DefaultTransactionDefinition();
		TransactionStatus status = transactionManager.getTransaction(def);

		try 
		{		
			String insertQuery = "INSERT INTO tbl_organization_view(organization_name, primary_headquarter, leader_name, date_of_creation, "
					+ "primary_location, primary_phone_no, primary_email_id, primary_twitter_id, primary_facebook_id, "
					+ "bank_account_no, user_description, login_id, org_profile_photo_id, org_cover_photo_id) "
					+ " values(?,?,?,?,?,?,?,?,?,?,?,?,?,?) ";
			System.out.println("addOrganizationViewBasicInformationDetails insertQuery: "+insertQuery);
			KeyHolder holder = new GeneratedKeyHolder();

			jdbcTemplate.update(new PreparedStatementCreator() {           
				@Override
				public PreparedStatement createPreparedStatement(Connection connection) throws SQLException
				{
					PreparedStatement ps = connection.prepareStatement(insertQuery, Statement.RETURN_GENERATED_KEYS);
					ps.setString(1, orgBasicInfo.getOrganizationName().trim());
					ps.setString(2, orgBasicInfo.getPrimaryHeadquarter().trim());										
					ps.setString(3, orgBasicInfo.getLeaderName().trim());
					ps.setString(4, orgBasicInfo.getDateOfCreation().trim());
					ps.setString(5, orgBasicInfo.getPrimaryLocation().trim());					   
					ps.setLong(6, orgBasicInfo.getPrimaryPhoneNo());
					ps.setString(7, orgBasicInfo.getPrimaryEmailId().trim());
					ps.setString(8, orgBasicInfo.getPrimaryTwitterId().trim());
					ps.setString(9, orgBasicInfo.getPrimaryFacebookId().trim());					 					   				
					ps.setLong(10, orgBasicInfo.getBankAccountNo());
					ps.setString(11, orgBasicInfo.getUserDescription().trim());
					ps.setInt(12, Integer.parseInt(userName));
					ps.setInt(13, orgBasicInfo.getProfilePhotoId());
					ps.setInt(14, orgBasicInfo.getProfileCoverPhotoId());					  				   										
					return ps;  
				}   
			}, holder);   

			int tblOrgViewId = holder.getKey().intValue();

			//TO ADDING ORG ALIAS INFO.
			String[] aliasArray = orgBasicInfo.getOrgAlias().split(",");		 
			for(int i = 0; i < aliasArray.length; i++) 
			{
				String aliasInsertQuery = "insert ignore into tbl_org_alias(org_id, org_alias)"
						+ " values(?,?) ";
				System.out.println("aliasInsertQuery: "+aliasInsertQuery);
				jdbcTemplate.update(aliasInsertQuery, new Object[] {
						tblOrgViewId, 
						aliasArray[i].trim()
				});				
			} 

			//TO ADDING ALIAS IN tbl_ner_alias TABLE.
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");  
			Date date = new Date();  
			String strDate = formatter.format(date);
			System.out.println(strDate);

			for(int i = 0; i < aliasArray.length; i++) 
			{
				String nerAliasInsertQuery = "insert ignore into tbl_ner_alias(firstName, lastName, alias, type, date_of_insertion, login_id, target_id)"
						+ " values(?,?,?,?,?,?,?) ";
				System.out.println("nerAliasInsertQuery: "+nerAliasInsertQuery);
				jdbcTemplate.update(nerAliasInsertQuery, new Object[] {
						orgBasicInfo.getOrganizationName().trim(), 
						"",					
						aliasArray[i].trim(),
						type,
						strDate,
						userName,
						tblOrgViewId
				});				
			} 

			//TO SET ORG ID IN SESSION.			    
			httpSession.setAttribute("orgId", tblOrgViewId);			   

			//UPDATE THE STATUS=1 FIELD OF tbl_organization_photo TABLE
			String updateQuery = "UPDATE tbl_organization_photo SET status="+statusUpdate+", org_id="+tblOrgViewId+" "
					+ "WHERE id="+orgBasicInfo.getProfilePhotoId()+" or id="+orgBasicInfo.getProfileCoverPhotoId()+" ";		
			jdbcTemplate.update(updateQuery);
			System.out.println("updateQuery: "+updateQuery);
			transactionManager.commit(status);
		}
		catch(Exception e)
		{
			transactionManager.rollback(status);
			e.printStackTrace();
			System.out.println(e.getMessage());
		}				 		 		 
		return true;
	}


	@Override
	public ArrayList<OrganizationBasicInformationVo> getTargetOrganizationBasicInformationsDetails(OrganizationBasicInformationVo orgBasicInfo) {
		ArrayList<OrganizationBasicInformationVo> orgList = new ArrayList<OrganizationBasicInformationVo>();
		try {
			String selectQuery = "SELECT id, organization_name, primary_headquarter, leader_name, date_of_creation, primary_location, "   
					+ " (SELECT photo_path FROM tbl_organization_photo WHERE tbl_organization_photo.id=tbl_organization_view.org_profile_photo_id) AS profilePhoto, "
					+ " (SELECT photo_path FROM tbl_organization_photo WHERE tbl_organization_photo.id=tbl_organization_view.org_cover_photo_id) AS coverPhoto, "
					+ " primary_phone_no, primary_email_id, primary_twitter_id, primary_facebook_id, bank_account_no, "
					+ " user_description, login_id, org_profile_photo_id, org_cover_photo_id, "
					+ " (SELECT GROUP_CONCAT(org_alias) FROM tbl_org_alias WHERE tbl_org_alias.org_id=tbl_organization_view.id) AS orgAlias "
					+ " FROM tbl_organization_view "
					+ " WHERE organization_name like '%"+orgBasicInfo.getSearchOrgStr()+"%' ORDER BY id DESC ";
			System.out.println("getTargetOrganizationBasicInformationsDetails selectQuery: "+selectQuery);			
			List<Map<String, Object>> rows = jdbcTemplate.queryForList(selectQuery);

			for(Map<String, Object> rs : rows) {
				OrganizationBasicInformationVo org = new OrganizationBasicInformationVo();
				org.setOrganizationId((Integer)(rs.get("id")));
				org.setOrganizationName((String)(rs.get("organization_name")));
				org.setPrimaryHeadquarter((String)(rs.get("primary_headquarter")));	
				org.setLeaderName((String)(rs.get("leader_name")));
				org.setDateOfCreation((String)(rs.get("date_of_creation")));
				org.setPrimaryLocation((String)(rs.get("primary_location")));							

				String path = TwitterConstant.getPersonProfile();
				if(rs.get("profilePhoto")!=null) {					
					String finalPath = path.substring(path.indexOf("ROOT")+4);
					org.setOrgProfilePhotoId(finalPath+"/"+(String)rs.get("profilePhoto"));				
				} else {
					org.setOrgProfilePhotoId(null);
				}	

				if(rs.get("coverPhoto")!=null) {
					String finalPath = path.substring(path.indexOf("ROOT")+4);
					org.setOrgCoverPhotoId(finalPath+"/"+(String)rs.get("coverPhoto"));
				} else {
					org.setOrgCoverPhotoId(null);
				}
				org.setPrimaryPhoneNo((Long)(rs.get("primary_phone_no")));
				org.setPrimaryEmailId((String)(rs.get("primary_email_id")));
				org.setPrimaryTwitterId((String)(rs.get("primary_twitter_id")));
				org.setPrimaryFacebookId((String)(rs.get("primary_facebook_id")));				
				org.setBankAccountNo((Long)(rs.get("bank_account_no")));
				org.setUserDescription((String)(rs.get("user_description")));
				org.setProfilePhotoId((Integer)(rs.get("org_profile_photo_id")));
				org.setProfileCoverPhotoId((Integer)(rs.get("org_cover_photo_id")));
				org.setOrgAlias(rs.get("orgAlias")==null?"":rs.get("orgAlias").toString());					
				orgList.add(org);			
			}			
		} catch(Exception ex) {
			ex.printStackTrace();
		}		
		return orgList;
	}


	@Override
	public ArrayList<OrganizationBasicInformationVo> getTargetOrganizationBasicInformationsForEdit(OrganizationBasicInformationVo orgBasicInfo) {
		ArrayList<OrganizationBasicInformationVo> orgList = new ArrayList<OrganizationBasicInformationVo>();
		try {
			String selectQuery = "SELECT id, organization_name, primary_headquarter, leader_name, date_of_creation, primary_location, "   
					+ " (SELECT photo_path FROM tbl_organization_photo WHERE tbl_organization_photo.id=tbl_organization_view.org_profile_photo_id) AS profilePhoto, "
					+ " (SELECT photo_path FROM tbl_organization_photo WHERE tbl_organization_photo.id=tbl_organization_view.org_cover_photo_id) AS coverPhoto, "
					+ " primary_phone_no, primary_email_id, primary_twitter_id, primary_facebook_id, bank_account_no, "
					+ " user_description, login_id, org_profile_photo_id, org_cover_photo_id, "
					+ " (SELECT GROUP_CONCAT(org_alias) FROM tbl_org_alias WHERE tbl_org_alias.org_id=tbl_organization_view.id) AS orgAlias "
					+ " FROM tbl_organization_view "
					+ " WHERE id = "+orgBasicInfo.getOrganizationId()+" ";
			System.out.println("getTargetOrganizationBasicInformationsForEdit selectQuery: "+selectQuery);			

			List<Map<String, Object>> rows = jdbcTemplate.queryForList(selectQuery);
			for(Map<String, Object> rs : rows) {
				OrganizationBasicInformationVo org = new OrganizationBasicInformationVo();				
				org.setOrganizationId((Integer)(rs.get("id")));
				org.setOrganizationName((String)(rs.get("organization_name")));
				org.setPrimaryHeadquarter((String)(rs.get("primary_headquarter")));	
				org.setLeaderName((String)(rs.get("leader_name")));
				org.setDateOfCreation((String)(rs.get("date_of_creation")));
				org.setPrimaryLocation((String)(rs.get("primary_location")));							

				if(rs.get("profilePhoto")!=null) {
					String path = TwitterConstant.getPersonProfile();
					String finalPath = path.substring(path.indexOf("ROOT")+4);
					org.setOrgProfilePhotoId(finalPath+"/"+(String)rs.get("profilePhoto"));				
				} else {
					org.setOrgProfilePhotoId(null);
				}

				if(rs.get("coverPhoto")!=null) {
					String path = TwitterConstant.getPersonProfile();
					String finalPath = path.substring(path.indexOf("ROOT")+4);
					org.setOrgCoverPhotoId(finalPath+"/"+(String)rs.get("coverPhoto"));
				} else {
					org.setOrgCoverPhotoId(null);
				}

				org.setPrimaryPhoneNo((Long)(rs.get("primary_phone_no")));
				org.setPrimaryEmailId((String)(rs.get("primary_email_id")));
				org.setPrimaryTwitterId((String)(rs.get("primary_twitter_id")));
				org.setPrimaryFacebookId((String)(rs.get("primary_facebook_id")));				
				org.setBankAccountNo((Long)(rs.get("bank_account_no")));
				org.setUserDescription((String)(rs.get("user_description")));
				org.setProfilePhotoId((Integer)(rs.get("org_profile_photo_id")));
				org.setProfileCoverPhotoId((Integer)(rs.get("org_cover_photo_id")));
				org.setOrgAlias(rs.get("orgAlias")==null?"":rs.get("orgAlias").toString());					
				orgList.add(org);			
			}			
		} catch(Exception ex) {
			ex.printStackTrace();
		}
		return orgList;
	}

	@Override
	public ArrayList<OrganizationBasicInformationVo> deleteTargetOrganizationBasicInformations(OrganizationBasicInformationVo orgBasicInfo) 
	{
		String type = "O";
		ArrayList<OrganizationBasicInformationVo> orgList = new ArrayList<OrganizationBasicInformationVo>();
		TransactionDefinition def = new DefaultTransactionDefinition();
		TransactionStatus status = transactionManager.getTransaction(def);

		try
		{			
			String deleteQuery1= "DELETE FROM tbl_organization_view WHERE id = '"+orgBasicInfo.getOrganizationId()+"' " ;
			String deleteQuery2= "DELETE FROM tbl_org_alias WHERE org_id = '"+orgBasicInfo.getOrganizationId()+"' " ;
			String deleteQuery3= "DELETE FROM tbl_organization_photo WHERE org_id = '"+orgBasicInfo.getOrganizationId()+"' " ;
			String deleteQuery4= "DELETE FROM tbl_organization_photo WHERE org_id = 0 " ;
			String deleteQuery5= "DELETE FROM tbl_organization_photo WHERE status = 0 " ;
			String deleteQuery6= "DELETE FROM tbl_ner_alias WHERE target_id = '"+orgBasicInfo.getOrganizationId()+"' AND type='"+type+"' " ;

			//################# Delete profile and cover photo Start ###############################################
			
			String[] photosPath = new String[2];
			String query = "Select photo_path FROM tbl_organization_photo WHERE org_id = '"+orgBasicInfo.getOrganizationId()+"' " ;
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			int i=0;
			for(Map<String,Object> rs : rows){
				
				photosPath[i] = TwitterConstant.getPersonProfile()+"/"+(rs.get("photo_path")==null?"":rs.get("photo_path").toString());
				i++;
				
			}
			
			File profilePhoto = new File(photosPath[0]);
    		if(profilePhoto.delete()){
    			System.out.println(profilePhoto.getName() + " is deleted!");
    		}else{
    			System.out.println("Delete operation is failed.");
    		}
    		
    		File coverPhoto = new File(photosPath[1]);        	
    		if(coverPhoto.delete()){
    			System.out.println(coverPhoto.getName() + " is deleted!");
    		}else{
    			System.out.println("Delete operation is failed.");
    		}
			
			//################# Delete profile and cover photo End ###############################################
			
			System.out.println("Delete query1: "+deleteQuery1);
			System.out.println("Delete query2: "+deleteQuery2);
			System.out.println("Delete query3: "+deleteQuery3);
			System.out.println("Delete query4: "+deleteQuery4);
			System.out.println("Delete query5: "+deleteQuery5);
			System.out.println("Delete query6: "+deleteQuery6);

			jdbcTemplate.update(deleteQuery1);
			jdbcTemplate.update(deleteQuery2);	
			jdbcTemplate.update(deleteQuery3);
			jdbcTemplate.update(deleteQuery4);
			jdbcTemplate.update(deleteQuery5);
			jdbcTemplate.update(deleteQuery6);
			transactionManager.commit(status);
		}
		catch(Exception ex)
		{
			transactionManager.rollback(status);
			ex.printStackTrace();
		} 
		return orgList;
	}

	@Override
	public boolean addOrganizationProfilePhotoForUpload(MultipartFile file) {
		
		String UPLOAD_DIRECTORY = TwitterConstant.getPersonProfile();
		String fileName = "";
		long fileUploadTime = new Date().getTime();
		String fileExtension = getFileExtension(convert(file));
		
		try {
			ServletContext context = httpSession.getServletContext();
			
			fileName = UPLOAD_DIRECTORY+File.separator+fileUploadTime+fileExtension;
			System.out.println("File : "+fileName);
			
		    byte[] bytes = file.getBytes();
		    BufferedOutputStream stream =new BufferedOutputStream(new FileOutputStream(new File(fileName)));
		    stream.write(bytes);
		    stream.flush();
		    stream.close();
			
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		
		String photoType = "profilePhoto";
		String insertQuery = "insert into tbl_organization_photo(photo_path, photo_type, status, org_id) values(?,?,?,?) ";
		System.out.println("addOrganizationProfilePhotoForUpload insertQuery: "+insertQuery);
		
		KeyHolder holder = new GeneratedKeyHolder();
		final String finalFileName = fileUploadTime+fileExtension;
		
		try {			
			
			jdbcTemplate.update(new PreparedStatementCreator() {           
				@Override
				public PreparedStatement createPreparedStatement(Connection connection) throws SQLException
				{
					PreparedStatement ps = connection.prepareStatement(insertQuery, Statement.RETURN_GENERATED_KEYS);					  
					ps.setString(1, finalFileName);
					ps.setString(2, photoType);	
					ps.setInt(3, 0);		
					ps.setInt(4, 0);
					return ps;
				}
			}, holder);

			int orgProfilePhotoId = holder.getKey().intValue();
			//TO SET PROFILE USER PHOTO ID IN SESSION.			    
			httpSession.setAttribute("orgProfilePhoto", orgProfilePhotoId);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			System.out.println(ex.getMessage());
		}		 		 		 
		return true;
	}

	@Override
	public boolean addOrganizationProfileCoverPhotoForUpload(MultipartFile file) {
		
		String UPLOAD_DIRECTORY = TwitterConstant.getPersonProfile();
		
		String fileName = "";
		long fileUploadTime = new Date().getTime();
		String fileExtension = getFileExtension(convert(file));
		
		try {
			ServletContext context = httpSession.getServletContext();
			
			fileName = UPLOAD_DIRECTORY+File.separator+fileUploadTime+fileExtension;
			System.out.println("File : "+fileName);
			
		    byte[] bytes = file.getBytes();
		    BufferedOutputStream stream =new BufferedOutputStream(new FileOutputStream(new File(fileName)));
		    stream.write(bytes);
		    stream.flush();
		    stream.close();
			
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		
		String photoType = "coverPhoto";
		String insertQuery = "insert into tbl_organization_photo(photo_path, photo_type, status, org_id) values(?,?,?,?) ";	
		System.out.println("addOrganizationProfileCoverPhotoForUpload insertQuery: "+insertQuery);
		KeyHolder holder = new GeneratedKeyHolder();
		final String finalFileName = fileUploadTime+fileExtension;
		
		try {			
			jdbcTemplate.update(new PreparedStatementCreator() {           
				@Override
				public PreparedStatement createPreparedStatement(Connection connection) throws SQLException
				{
					PreparedStatement ps = connection.prepareStatement(insertQuery, Statement.RETURN_GENERATED_KEYS);					  
					ps.setString(1, finalFileName);
					ps.setString(2, photoType);	
					ps.setInt(3, 0);		
					ps.setInt(4, 0);	
					return ps;  
				}   
			}, holder);  

			int orgCoverPhotoId = holder.getKey().intValue();
			//TO SET PROFILE USER PHOTO ID IN SESSION.			    
			httpSession.setAttribute("orgCoverPhoto", orgCoverPhotoId);
		} catch(Exception ex) {
			ex.printStackTrace();
			System.out.println(ex.getMessage());
		} 
		return true;
	}

	@Override
	public ArrayList<OrganizationPhotoVo> getOrganizationCoverPhoto(OrganizationPhotoVo photoVo) {
		ArrayList<OrganizationPhotoVo> photoList = new ArrayList<OrganizationPhotoVo>();
		try {
			if(!httpSession.getAttribute("orgCoverPhoto").equals(null)) {
				Integer orgCoverPhoto = Integer.parseInt(httpSession.getAttribute("orgCoverPhoto").toString());				
				String selectQuery = " SELECT id, photo_path FROM tbl_organization_photo WHERE id = "+orgCoverPhoto+" ";
				System.out.println("getOrganizationCoverPhoto selectQuery: "+selectQuery);
				List<Map<String, Object>> rows = jdbcTemplate.queryForList(selectQuery);
				for(Map<String, Object> rs : rows) {
					OrganizationPhotoVo photo = new OrganizationPhotoVo();
					photo.setPhotoId((Integer)rs.get("id"));
					
					if(rs.get("photo_path")!=null) {
						String path = TwitterConstant.getPersonProfile();
						String finalPath = path.substring(path.indexOf("ROOT")+4);
						photo.setPhotoPath(finalPath+"/"+(String)rs.get("photo_path"));
					} else {
						photo.setPhotoPath(null);
					}	
					photoList.add(photo);
				}
			} else {
				System.out.println("Please upload organization cover photo.");
			}
		} catch(Exception ex) {
			ex.printStackTrace();
		}
		return photoList;
	}

	@Override
	public ArrayList<OrganizationPhotoVo> getOrganizationProfilePhoto(OrganizationPhotoVo photoVo) {
		ArrayList<OrganizationPhotoVo> photoList = new ArrayList<OrganizationPhotoVo>();
		try {
			if(!httpSession.getAttribute("orgProfilePhoto").equals(null)) {
				Integer orgProfilePhoto = Integer.parseInt(httpSession.getAttribute("orgProfilePhoto").toString());				
				String selectQuery = " SELECT id, photo_path FROM tbl_organization_photo WHERE id = "+orgProfilePhoto+" ";
				System.out.println("getOrganizationProfilePhoto selectQuery: "+selectQuery);		        		        
				List<Map<String, Object>> rows = jdbcTemplate.queryForList(selectQuery);
				for(Map<String, Object> rs : rows) {
					OrganizationPhotoVo photo = new OrganizationPhotoVo();					
					photo.setPhotoId((Integer)rs.get("id"));
					
					if(rs.get("photo_path")!=null) {
						String path = TwitterConstant.getPersonProfile();
						String finalPath = path.substring(path.indexOf("ROOT")+4);
						photo.setPhotoPath(finalPath+"/"+(String)rs.get("photo_path"));
					} else {
						photo.setPhotoPath(null);
					}	
					photoList.add(photo);	
				}
			} else {
				System.out.println("Please upload organization profile photo.");
			}
		} catch(Exception ex) {
			ex.printStackTrace();
		}
		return photoList;
	}

	@Override
	public boolean editOrganizationBasicInformationsDetails(OrganizationBasicInformationVo orgBasicInfo)
	{
		String userName =(String)httpSession.getAttribute(ApplicationConstants.LOGINUSERID);
		String updateQuery = "";	
		String deleteQuery = "";
		String coverPhotoId = "coverPhoto";
		String profilePhotoId = "profilePhoto";
		int statusUpdate = 1;
		int result=0;
		String type = "O";

		try
		{		    
			if(orgBasicInfo.getProfilePhotoId() != 0 && orgBasicInfo.getProfileCoverPhotoId() != 0)
			{
				updateQuery = "UPDATE tbl_organization_view SET organization_name='"+orgBasicInfo.getOrganizationName()+"', primary_headquarter='"+orgBasicInfo.getPrimaryHeadquarter()+"', "
						+ "leader_name='"+orgBasicInfo.getLeaderName()+"', date_of_creation='"+orgBasicInfo.getDateOfCreation()+"', "
						+ "primary_location='"+orgBasicInfo.getPrimaryLocation()+"', "
						+ "primary_phone_no='"+orgBasicInfo.getPrimaryPhoneNo()+"', primary_email_id='"+orgBasicInfo.getPrimaryEmailId()+"', "
						+ "primary_twitter_id='"+orgBasicInfo.getPrimaryTwitterId()+"', primary_facebook_id='"+orgBasicInfo.getPrimaryFacebookId()+"', "
						+ "bank_account_no='"+orgBasicInfo.getBankAccountNo()+"', user_description='"+orgBasicInfo.getUserDescription()+"', "
						+ "org_profile_photo_id='"+orgBasicInfo.getProfilePhotoId()+"', org_cover_photo_id='"+orgBasicInfo.getProfileCoverPhotoId()+"' "
						+ "WHERE id='"+orgBasicInfo.getOrganizationId()+"' ";

				deleteQuery = "DELETE FROM tbl_organization_photo WHERE org_id = '"+orgBasicInfo.getOrganizationId()+"' " ; 
				jdbcTemplate.update(deleteQuery);
			}
			else if(orgBasicInfo.getProfilePhotoId() == 0 && orgBasicInfo.getProfileCoverPhotoId() != 0)
			{
				updateQuery = "UPDATE tbl_organization_view SET organization_name='"+orgBasicInfo.getOrganizationName()+"', primary_headquarter='"+orgBasicInfo.getPrimaryHeadquarter()+"', "
						+ "leader_name='"+orgBasicInfo.getLeaderName()+"', date_of_creation='"+orgBasicInfo.getDateOfCreation()+"', "
						+ "primary_location='"+orgBasicInfo.getPrimaryLocation()+"', "
						+ "primary_phone_no='"+orgBasicInfo.getPrimaryPhoneNo()+"', primary_email_id='"+orgBasicInfo.getPrimaryEmailId()+"', "
						+ "primary_twitter_id='"+orgBasicInfo.getPrimaryTwitterId()+"', primary_facebook_id='"+orgBasicInfo.getPrimaryFacebookId()+"', "
						+ "bank_account_no='"+orgBasicInfo.getBankAccountNo()+"', user_description='"+orgBasicInfo.getUserDescription()+"', "
						+ "org_cover_photo_id='"+orgBasicInfo.getProfileCoverPhotoId()+"' "
						+ "WHERE id='"+orgBasicInfo.getOrganizationId()+"' ";

				deleteQuery = "DELETE FROM tbl_organization_photo WHERE org_id = '"+orgBasicInfo.getOrganizationId()+"' AND photo_type = '"+coverPhotoId+"' " ; 
				jdbcTemplate.update(deleteQuery);
			}
			else if(orgBasicInfo.getProfilePhotoId() != 0 && orgBasicInfo.getProfileCoverPhotoId() == 0)
			{
				updateQuery = "UPDATE tbl_organization_view SET organization_name='"+orgBasicInfo.getOrganizationName()+"', primary_headquarter='"+orgBasicInfo.getPrimaryHeadquarter()+"', "
						+ "leader_name='"+orgBasicInfo.getLeaderName()+"', date_of_creation='"+orgBasicInfo.getDateOfCreation()+"', "
						+ "primary_location='"+orgBasicInfo.getPrimaryLocation()+"', "
						+ "primary_phone_no='"+orgBasicInfo.getPrimaryPhoneNo()+"', primary_email_id='"+orgBasicInfo.getPrimaryEmailId()+"', "
						+ "primary_twitter_id='"+orgBasicInfo.getPrimaryTwitterId()+"', primary_facebook_id='"+orgBasicInfo.getPrimaryFacebookId()+"', "
						+ "bank_account_no='"+orgBasicInfo.getBankAccountNo()+"', user_description='"+orgBasicInfo.getUserDescription()+"', "
						+ "org_profile_photo_id='"+orgBasicInfo.getProfilePhotoId()+"'  "
						+ "WHERE id='"+orgBasicInfo.getOrganizationId()+"' ";

				deleteQuery = "DELETE FROM tbl_organization_photo WHERE org_id = '"+orgBasicInfo.getOrganizationId()+"' AND photo_type = '"+profilePhotoId+"' " ; 
				jdbcTemplate.update(deleteQuery);
			}
			else if(orgBasicInfo.getProfilePhotoId() == 0 && orgBasicInfo.getProfileCoverPhotoId() == 0)
			{
				updateQuery = "UPDATE tbl_organization_view SET organization_name='"+orgBasicInfo.getOrganizationName()+"', primary_headquarter='"+orgBasicInfo.getPrimaryHeadquarter()+"', "
						+ "leader_name='"+orgBasicInfo.getLeaderName()+"', date_of_creation='"+orgBasicInfo.getDateOfCreation()+"', "
						+ "primary_location='"+orgBasicInfo.getPrimaryLocation()+"', "
						+ "primary_phone_no='"+orgBasicInfo.getPrimaryPhoneNo()+"', primary_email_id='"+orgBasicInfo.getPrimaryEmailId()+"', "
						+ "primary_twitter_id='"+orgBasicInfo.getPrimaryTwitterId()+"', primary_facebook_id='"+orgBasicInfo.getPrimaryFacebookId()+"', "
						+ "bank_account_no='"+orgBasicInfo.getBankAccountNo()+"', user_description='"+orgBasicInfo.getUserDescription()+"'  "
						+ "WHERE id='"+orgBasicInfo.getOrganizationId()+"' ";
			}

			System.out.println("editOrganizationBasicInformationsDetails updateQuery: "+updateQuery);
			result = jdbcTemplate.update(updateQuery);

			//DELETE ALIAS TABLE CONTENT.
			String deleteQuery1= "DELETE FROM tbl_org_alias WHERE org_id = '"+orgBasicInfo.getOrganizationId()+"' " ;
			System.out.println("Delete query: "+deleteQuery1);
			jdbcTemplate.update(deleteQuery1);

			//INSERT ALIAS TABLE CONTENT.
			String[] arr = orgBasicInfo.getOrgAlias().split(",");		 
			for(int i = 0; i < arr.length; i++) 
			{
				String aliasInsertQuery = "insert ignore into tbl_org_alias(org_id, org_alias)"
						+ " values(?,?) ";
				System.out.println("aliasInsertQuery: "+aliasInsertQuery);
				jdbcTemplate.update(aliasInsertQuery, new Object[] {
						orgBasicInfo.getOrganizationId(), 
						arr[i].trim()
				});				  
			}	

			//DELETE ALIAS TABLE CONTENT IN tbl_ner_alias TABLE.
			String deleteQuery2= "DELETE FROM tbl_ner_alias WHERE firstName = '"+orgBasicInfo.getOrganizationName()+"' AND type='"+type+"' " ;
			System.out.println("deleteQuery2: "+deleteQuery2);
			jdbcTemplate.update(deleteQuery2);

			//TO ADDING ALIAS IN tbl_ner_alias TABLE.
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");  
			Date date = new Date();  
			String strDate = formatter.format(date);
			System.out.println(strDate);

			for(int i = 0; i < arr.length; i++) 
			{
				String nerAliasInsertQuery = "insert ignore into tbl_ner_alias(firstName, lastName, alias, type, date_of_insertion, login_id, target_id)"
						+ " values(?,?,?,?,?,?,?) ";
				System.out.println("nerAliasInsertQuery: "+nerAliasInsertQuery);
				jdbcTemplate.update(nerAliasInsertQuery, new Object[] {
						orgBasicInfo.getOrganizationName().trim(), 
						"",					
						arr[i].trim(),
						type,
						strDate,
						userName,
						orgBasicInfo.getOrganizationId()
				});				
			} 

			//UPDATE THE STATUS=1 FIELD OF tbl_organization_photo TABLE
			String updateQuery1 = "UPDATE tbl_organization_photo SET status="+statusUpdate+", org_id="+orgBasicInfo.getOrganizationId()+" "
					+ "WHERE id="+orgBasicInfo.getProfilePhotoId()+" or id="+orgBasicInfo.getProfileCoverPhotoId()+" ";		
			jdbcTemplate.update(updateQuery1);
			System.out.println("updateQuery1: "+updateQuery1);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();			
		}
		if(result>0)
		{
			return true;
		}			 
		else 
		{
			return false;
		}			
	}


	@Override
	public ArrayList<OrganizationBasicInformationVo> getTargetOrganizationBasicInformationsDetailsReport(OrganizationBasicInformationVo orgInfoVo) {
		ArrayList<OrganizationBasicInformationVo> orgList = new ArrayList<OrganizationBasicInformationVo>();
		try {
			String selectQuery = "SELECT id, organization_name, primary_headquarter, leader_name, date_of_creation, primary_location, "   
					+ " (SELECT photo_path FROM tbl_organization_photo WHERE tbl_organization_photo.id=tbl_organization_view.org_profile_photo_id) AS profilePhoto, "
					+ " (SELECT photo_path FROM tbl_organization_photo WHERE tbl_organization_photo.id=tbl_organization_view.org_cover_photo_id) AS coverPhoto, "
					+ " primary_phone_no, primary_email_id, primary_twitter_id, primary_facebook_id, bank_account_no, "
					+ " user_description, login_id, org_profile_photo_id, org_cover_photo_id, "
					+ " (SELECT GROUP_CONCAT(org_alias) FROM tbl_org_alias WHERE tbl_org_alias.org_id=tbl_organization_view.id) AS orgAlias "
					+ " FROM tbl_organization_view "
					+ " WHERE id = "+orgInfoVo.getOrganizationId()+" ";
			System.out.println("selectQuery: "+selectQuery);

			List<Map<String, Object>> rows = jdbcTemplate.queryForList(selectQuery);
			for(Map<String, Object> rs : rows) {
				OrganizationBasicInformationVo org = new OrganizationBasicInformationVo();				
				org.setOrganizationId((Integer)(rs.get("id")));
				org.setOrganizationName((String)(rs.get("organization_name")));
				org.setPrimaryHeadquarter((String)(rs.get("primary_headquarter")));	
				org.setLeaderName((String)(rs.get("leader_name")));
				org.setDateOfCreation((String)(rs.get("date_of_creation")));
				org.setPrimaryLocation((String)(rs.get("primary_location")));											
				if(rs.get("profilePhoto")!=null) {
					String path = TwitterConstant.getPersonProfile();
					String finalPath = path.substring(path.indexOf("ROOT")+4);
					org.setOrgProfilePhotoId(finalPath+"/"+(String)rs.get("profilePhoto"));				
				} else {
					org.setOrgProfilePhotoId(null);
				}	

				if(rs.get("coverPhoto")!=null) {
					String path = TwitterConstant.getPersonProfile();
					String finalPath = path.substring(path.indexOf("ROOT")+4);
					org.setOrgCoverPhotoId(finalPath+"/"+(String)rs.get("coverPhoto"));
				} else {
					org.setOrgCoverPhotoId(null);
				}				
				org.setPrimaryPhoneNo((Long)(rs.get("primary_phone_no")));
				org.setPrimaryEmailId((String)(rs.get("primary_email_id")));
				org.setPrimaryTwitterId((String)(rs.get("primary_twitter_id")));
				org.setPrimaryFacebookId((String)(rs.get("primary_facebook_id")));				
				org.setBankAccountNo((Long)(rs.get("bank_account_no")));
				org.setUserDescription((String)(rs.get("user_description")));
				org.setProfilePhotoId((Integer)(rs.get("org_profile_photo_id")));
				org.setProfileCoverPhotoId((Integer)(rs.get("org_cover_photo_id")));
				org.setOrgAlias(rs.get("orgAlias")==null?"":rs.get("orgAlias").toString());					
				orgList.add(org);			
			}			
		} catch(Exception ex) {
			ex.printStackTrace();
		}
		return orgList;
	}

	@Override
	public ArrayList<OrganizationPhotoVo> getTargetOrganizationCoverPhotoReport(OrganizationPhotoVo photoVo) {
		ArrayList<OrganizationPhotoVo> photoList = new ArrayList<OrganizationPhotoVo>();
		try {
			String selectQuery = " SELECT id, photo_path FROM tbl_organization_photo WHERE id = "+photoVo.getPhotoId()+" ";
			System.out.println("getTargetOrganizationCoverPhotoReport selectQuery: "+selectQuery);		        		        
			List<Map<String, Object>> rows = jdbcTemplate.queryForList(selectQuery);
			for(Map<String, Object> rs : rows) {
				OrganizationPhotoVo photo = new OrganizationPhotoVo();					
				photo.setPhotoId((Integer)rs.get("id"));
				
				if(rs.get("photo_path")!=null) {
					String path = TwitterConstant.getPersonProfile();
					String finalPath = path.substring(path.indexOf("ROOT")+4);
					photo.setPhotoPath(finalPath+"/"+(String)rs.get("photo_path"));
				} else {
					photo.setPhotoPath(null);
				}	
				photoList.add(photo);	
			}		
		} catch(Exception ex) {
			ex.printStackTrace();
		}
		return photoList;
	}

	@Override
	public ArrayList<OrganizationPhotoVo> getTargetOrganizationProfilePhotoReport(OrganizationPhotoVo photoVo) {
		ArrayList<OrganizationPhotoVo> photoList = new ArrayList<OrganizationPhotoVo>();
		TransactionDefinition def = new DefaultTransactionDefinition();
		TransactionStatus status = transactionManager.getTransaction(def);

		try {
			String selectQuery = " SELECT id, photo_path FROM tbl_organization_photo "
					+ " WHERE id = "+photoVo.getPhotoId()+" ";
			System.out.println("getTargetOrganizationProfilePhotoReport selectQuery: "+selectQuery);		        		        
			List<Map<String, Object>> rows = jdbcTemplate.queryForList(selectQuery);
			for(Map<String, Object> rs : rows) {
				OrganizationPhotoVo photo = new OrganizationPhotoVo();					
				photo.setPhotoId((Integer)rs.get("id"));
				
				if(rs.get("photo_path")!=null) {
					String path = TwitterConstant.getPersonProfile();
					String finalPath = path.substring(path.indexOf("ROOT")+4);
					photo.setPhotoPath(finalPath+"/"+(String)rs.get("photo_path"));
				} else {
					photo.setPhotoPath(null);
				}			
				photoList.add(photo);	
			}
			transactionManager.commit(status);
		} catch(Exception ex) {
			transactionManager.rollback(status);
			ex.printStackTrace();
		}
		return photoList;
	}

	@Override
	public ArrayList<UserProfileBasicInformationVo> getTargetProfileBasicInformationsForEdit(UserProfileBasicInformationVo basicInformationVo) {
		ArrayList<UserProfileBasicInformationVo> userList = new ArrayList<UserProfileBasicInformationVo>();
		TransactionDefinition def = new DefaultTransactionDefinition();
		TransactionStatus status = transactionManager.getTransaction(def);

		try {
			String selectQuery = " SELECT id, first_name, last_name, profile_photo_id, profile_cover_photo_id, "
					+ " (SELECT photo_path FROM tbl_profile_user_photo WHERE tbl_profile_user_photo.id=tbl_profile.profile_photo_id) AS profilePhoto, "
					+ " (SELECT photo_path FROM tbl_profile_user_photo WHERE tbl_profile_user_photo.id=tbl_profile.profile_cover_photo_id) AS coverPhoto, "
					+ " permanent_address, local_address, "
					+ " father_name, mother_name, dob, gender, nationality, martial_status, addahar_card, "
					+ " pan_card, passport_no, description, classification, (SELECT GROUP_CONCAT(alias) FROM tbl_profile_alias WHERE tbl_profile_alias.profile_id=tbl_profile.id) as alias "
					+ " FROM tbl_profile "
					+ " WHERE id="+basicInformationVo.getProfileId()+" ";
			System.out.println("getTargetProfileBasicInformationsForEdit selectQuery: "+selectQuery);			

			List<Map<String, Object>> rows = jdbcTemplate.queryForList(selectQuery);
			for(Map<String, Object> rs : rows) {
				UserProfileBasicInformationVo user = new UserProfileBasicInformationVo();				
				user.setProfileId((Integer)(rs.get("id")));
				user.setFirstName((String)(rs.get("first_name")));
				user.setLastName((String)(rs.get("last_name")));	
				user.setProfilePhotoId((Integer)(rs.get("profile_photo_id")));
				user.setProfileCoverPhotoId((Integer)(rs.get("profile_cover_photo_id")));			

				if(rs.get("profilePhoto")!=null) {
					String path = TwitterConstant.getPersonProfile();
					String finalPath = path.substring(path.indexOf("ROOT")+4);
					user.setProfilePhoto(finalPath+"/"+(String)rs.get("profilePhoto"));				
				} else {
					user.setProfilePhoto(null);
				}	

				if(rs.get("coverPhoto")!=null) {
					String path = TwitterConstant.getPersonProfile();
					String finalPath = path.substring(path.indexOf("ROOT")+4);
					user.setCoverPhoto(finalPath+"/"+(String)rs.get("coverPhoto"));
				} else {
					user.setCoverPhoto(null);
				}

				user.setPermanentAddress((String)(rs.get("permanent_address")));
				user.setLocalAddress((String)(rs.get("local_address")));
				user.setFatherName((String)(rs.get("father_name")));
				user.setMotherName((String)(rs.get("mother_name")));
				user.setDob((String)(rs.get("dob")));
				user.setGender((String)(rs.get("gender")));
				user.setNationality((String)(rs.get("nationality")));
				user.setMartialStatus((String)(rs.get("martial_status")));
				user.setAddaharCard((String)(rs.get("addahar_card")));
				user.setPanCard((String)(rs.get("pan_card")));
				user.setPassportNo((String)(rs.get("passport_no")));
				user.setDescription((String)(rs.get("description")));
				user.setClassification((String)(rs.get("classification")));
				user.setAlias(rs.get("alias")==null?"":rs.get("alias").toString());
				userList.add(user);			
			}	
			transactionManager.commit(status);
		} catch(Exception ex) {
			transactionManager.rollback(status);
			ex.printStackTrace();
		}		
		return userList;
	}

	
	public void addProfileToAnalysis(ArrayList<EntityVo> entityIds, int caseId) 
	{
		try 
		{
			for(EntityVo entityVo : entityIds) 
			{
				System.out.println("snapshot_id::"+caseId +"\n"+
						"entityName::"+entityVo.getEntityName() +"\n"+
						"entityId::"+entityVo.getEntitySocialId().trim() +"\n"+
						"entityType::"+entityVo.getEntityType().trim() +"\n"+
						"entitySource_type::"+entityVo.getEntitySourceType().trim() +"\n"+
						"entityUrl::"+entityVo.getEntityUrl().trim() +"\n"+
						"entitytImg::"+entityVo.getEntityImg().trim() +"\n"+
						"twId::"+entityVo.getTwId() +"\n"+
						"varifiedUserFlag::"+entityVo.getVarifiedUserFlag() +"\n"+
						"fbType::"+entityVo.getFbType() +"\n"
						);

				String query="INSERT ignore into tbl_case_profile(snapshot_id, entity_name, entity_id, entity_type, entity_source_type, entity_url, entity_img, tw_id, fbType, varifiedUserFlag)"
						+ " values(?,?,?,?,?,?,?,?,?,?) ";
				Object[] obj=new Object[]{caseId, 
						entityVo.getEntityName(), 
						entityVo.getEntitySocialId().trim(), 
						entityVo.getEntityType().trim(), 
						entityVo.getEntitySourceType().trim(),
						entityVo.getEntityUrl().trim(), 
						entityVo.getEntityImg(), 
						entityVo.getTwId(),
						entityVo.getFbType(),
						entityVo.getVarifiedUserFlag()
						};
				jdbcTemplate.update(query, obj);
			}
		} 
		catch(Exception ex) 
		{
			ex.printStackTrace();
		} 
	}

	
	public void addNewsSourceToAnalysis(ArrayList<String> entityIds, int caseId) 
	{
		try 
		{
			for(String string : entityIds)
			{
				System.out.println("snapshot_id::"+caseId +" :News Source Name::"+ string);
				String query="insert ignore into tbl_case_news_source(snapshot_id, news_source)"
						+ " values(?,?) ";
				Object[] obj=new Object[]{caseId,string.trim()};
				jdbcTemplate.update(query,obj);
			}
		} 
		catch(Exception e) 
		{
			e.printStackTrace();
		} 
	}
	
	public void addNewsWebsiteToAnalysis(ArrayList<String> entityIds, int caseId) 
	{
		System.out.println("entityIds:----- "+entityIds);
		System.out.println("caseId:-------- "+caseId);
		
		try 
		{
			for(String website : entityIds)
			{
				System.out.println("snapshot_id::"+caseId +" :News Website Name::"+ website);
				String query="insert ignore into tbl_case_news_website(snapshot_id, news_website)"
						+ " values(?,?) ";
				Object[] obj=new Object[]{caseId, website.trim()};
				jdbcTemplate.update(query, obj);
			}
		} 
		catch(Exception ex) 
		{
			ex.printStackTrace();
		} 
	}
	
	public void addNewsFTPToAnalysis(ArrayList<String> entityIds, int caseId) 
	{
		try 
		{
			for(String ftp : entityIds)
			{
				System.out.println("snapshot_id::"+caseId +" :News Website Name::"+ ftp);
				String query="insert ignore into tbl_case_news_ftp(snapshot_id, news_ftp)"
						+ " values(?,?) ";
				Object[] obj=new Object[]{caseId, ftp.trim()};
				jdbcTemplate.update(query, obj);
			}
		} 
		catch(Exception ex) 
		{
			ex.printStackTrace();
		} 
	}

	
	@Override
	public ArrayList<CaseVo> getAlertWorkDaysById(CaseVo caseVo)
	{
		ArrayList<CaseVo> lst=new ArrayList<CaseVo>();
		try 
		{
			String query="	SELECT day,hour,minutes from tbl_alert_interval where  alert_id = '"+caseVo.getId()+"'";
			System.out.println("getAlertWorkDaysById :  "+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			
			for(Map<String,Object> rs : rows)
			{
				CaseVo caseVoObj=new CaseVo();
				caseVoObj.setId(rs.get("id")==null?"":rs.get("id").toString());
				caseVoObj.setKey1(rs.get("day")==null?"":rs.get("day").toString());
				caseVoObj.setKey2(rs.get("hour")==null?"":rs.get("hour").toString());
				caseVoObj.setKey3(rs.get("minutes")==null?"":rs.get("minutes").toString());
				lst.add(caseVoObj);
			}
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		} 
		return lst;
	}

	
	@Override
	public ArrayList<CaseVo> getAlertDetails(CaseVo caseVo) 
	{
		ArrayList<CaseVo> lst=new ArrayList<CaseVo>();
		String user=(String)httpSession.getAttribute(ApplicationConstants.LOGINUSERID);
		String userRole=(String)httpSession.getAttribute(ApplicationConstants.USERROLE);
		try 
		{
			String subQuery="";
			if(!userRole.equals("a"))
			{
				subQuery+=" and tbl_alert.login_id='"+user+"'";	
			}

			String query="SELECT tbl_alert.alert_name, tbl_alert.keyword, tbl_alert.sentiment, tbl_alert_result.no_of_posts, "
					+ " tbl_alert_result.alert_from_date, tbl_alert_result.alert_to_date, tbl_alert_result.id, tbl_alert_result.read_status, "
					+ " tbl_alert.case_id, tbl_alert.snapshot_id, tbl_alert.alert_type, tbl_alert.threat_classification "
					+ " FROM tbl_alert_result "
					+ " INNER JOIN tbl_alert_interval"
					+ " ON tbl_alert_result.alert_id=tbl_alert_interval.id "
					+ " INNER JOIN tbl_alert "
					+ " ON tbl_alert.id=tbl_alert_interval.alert_id "
					+ " WHERE tbl_alert_result.read_status='unread'" + subQuery;
			
			System.out.println("Alert Details :  "+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			
			for(Map<String,Object> rs : rows)
			{
				CaseVo caseVoObj=new CaseVo();
				caseVoObj.setId(rs.get("id")==null?"":rs.get("id").toString());
				caseVoObj.setKey1(rs.get("alert_name")==null?"":rs.get("alert_name").toString());
				caseVoObj.setKey2(rs.get("no_of_posts")==null?"":rs.get("no_of_posts").toString());
				caseVoObj.setKey3(CommonUtils.convertUnixTimeToDateDisplayFormat(Long.parseLong(rs.get("alert_from_date").toString())));
				caseVoObj.setKey4(rs.get("read_status")==null?"":rs.get("read_status").toString());
				caseVoObj.setKey5(CommonUtils.convertUnixTimeToDateDisplayFormat(Long.parseLong(rs.get("alert_to_date").toString())));
				caseVoObj.setKey6(rs.get("keyword")==null?"":rs.get("keyword").toString());
				caseVoObj.setKey7(rs.get("sentiment")==null?"":rs.get("sentiment").toString());
				caseVoObj.setKey9(rs.get("threat_classification")==null?"":rs.get("threat_classification").toString());
				caseVoObj.setKey8("alert");
				caseVoObj.setCaseId(rs.get("case_id")==null?"":rs.get("case_id").toString());
				caseVoObj.setSnapShortId(rs.get("snapshot_id")==null?"":rs.get("snapshot_id").toString());
				caseVoObj.setAlertType(rs.get("alert_type")==null?"":rs.get("alert_type").toString());
				caseVoObj.setDateFrom(rs.get("alert_from_date")==null?"":rs.get("alert_from_date").toString());
				caseVoObj.setDateTo(rs.get("alert_to_date")==null?"":rs.get("alert_to_date").toString());
				lst.add(caseVoObj);
			}
			
			
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		} 
		return lst;
	}

	
	@Override
	public ArrayList<CaseVo> getAlertCounts(CaseVo caseVo) 
	{
		int alertCount=0;
		
		ArrayList<CaseVo> lst=new ArrayList<CaseVo>();
		String user=(String)httpSession.getAttribute(ApplicationConstants.LOGINUSERID);
		try 
		{
			String query="SELECT COUNT(tbl_alert_result.id) AS COUNT "+
					"FROM tbl_alert_result INNER JOIN tbl_alert_interval ON tbl_alert_result.alert_id=tbl_alert_interval.id "+
					"INNER JOIN tbl_alert ON tbl_alert.id=tbl_alert_interval.alert_id "+
					"WHERE tbl_alert_result.read_status='unread'  "+
					"AND tbl_alert.login_id='"+user+"'";
			//System.out.println("Alert counts :  "+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			
			for(Map<String,Object> rs : rows)
			{
				alertCount= Integer.parseInt(rs.get("COUNT")==null?"0":rs.get("COUNT").toString())  ;
			}

		
			CaseVo caseVoObj=new CaseVo();
			caseVoObj.setKey1(Integer.toString(alertCount));
			lst.add(caseVoObj);
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		} 
		return lst;
	}

	
	@Override
	public void updateAlertReadStatus(CaseVo caseVo) 
	{
		try 
		{
			String query= "update tbl_alert_result set read_status='read'" ;
			System.out.println("updateAlertReadValues : "+query);
			jdbcTemplate.update(query);

		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		} 
	}

	
	@Override
	public void updateAlertStatusRead(CaseVo caseVo) 
	{
		try
		{
			if(caseVo.getKey8().equals("alert"))
			{
				String query= "update tbl_alert_result set read_status='read' where id = '"+caseVo.getId()+"'";
				System.out.println("make Alert Status Read : "+query);
				jdbcTemplate.update(query);
			}
			
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		} 
	}

	
	@Override
	public ArrayList<CaseVo> getAlertByStatusType(CaseVo caseVo) 
	{
		ArrayList<CaseVo> lst=new ArrayList<CaseVo>();
		String user=(String)httpSession.getAttribute(ApplicationConstants.LOGINUSERID);
		try 
		{
			String query="SELECT tbl_alert.alert_name,tbl_alert.keyword,tbl_alert.sentiment,tbl_alert_result.no_of_posts,tbl_alert_result.alert_from_date,tbl_alert_result.alert_to_date,tbl_alert_result.id,tbl_alert_result.read_status "+
					"FROM tbl_alert_result INNER JOIN tbl_alert_interval ON tbl_alert_result.alert_id=tbl_alert_interval.id "+
					"INNER JOIN tbl_alert ON tbl_alert.id=tbl_alert_interval.alert_id WHERE tbl_alert.login_id='"+user+"'";
			if(caseVo.getCaseName().equals("read"))
			{
				query+=" and tbl_alert_result.read_status='read' ";
			}
			else if(caseVo.getCaseName().equals("unread"))
			{
				query+=" and tbl_alert_result.read_status='unread' ";
			}
			System.out.println("Alert Details : "+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs : rows)
			{
				CaseVo caseVoObj=new CaseVo();
				caseVoObj.setId(rs.get("id")==null?"":rs.get("id").toString());
				caseVoObj.setKey1(rs.get("alert_name")==null?"":rs.get("alert_name").toString());
				caseVoObj.setKey2(rs.get("no_of_posts")==null?"":rs.get("no_of_posts").toString());
				caseVoObj.setKey3(CommonUtils.convertUnixTimeToDateDisplayFormat(Long.parseLong(rs.get("alert_from_date").toString())));
				caseVoObj.setKey4(rs.get("read_status")==null?"":rs.get("read_status").toString());
				caseVoObj.setKey5(CommonUtils.convertUnixTimeToDateDisplayFormat(Long.parseLong(rs.get("alert_to_date").toString())));
				caseVoObj.setKey6(rs.get("keyword")==null?"":rs.get("keyword").toString());
				caseVoObj.setKey7(rs.get("sentiment")==null?"":rs.get("sentiment").toString());
				caseVoObj.setKey8("alert");
				lst.add(caseVoObj);
			}
			
			
            
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		} 
		return lst;
	}

	@Override
	public ArrayList<CaseVo> setViewbyAlertId(CaseVo caseVo) 
	{
		ArrayList<CaseVo> lst=new ArrayList<CaseVo>();
		try 
		{
			String query=" SELECT tbl_alert.alert_name, tbl_alert.keyword,tbl_alert.user,tbl_alert.sentiment, "
					+ " tbl_alert_result.alert_from_date,tbl_alert_result.alert_to_date, tbl_alert.threat_classification "
					+ " FROM tbl_alert "+
					" INNER JOIN tbl_alert_interval ON tbl_alert.id=tbl_alert_interval.alert_id "
					+ " INNER JOIN tbl_alert_result ON tbl_alert_result.alert_id=tbl_alert_interval.id  "+
					"  WHERE tbl_alert_result.id='"+caseVo.getId()+"'";
			System.out.println("SetViewbyAlertId : "+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs : rows)
			{
				CaseVo caseVoObj=new CaseVo();
				caseVoObj.setKey1(rs.get("keyword")==null?"":rs.get("keyword").toString());
				caseVoObj.setKey2(rs.get("user")==null?"":rs.get("user").toString());
				caseVoObj.setKey3(rs.get("sentiment")==null?"":rs.get("sentiment").toString());
				caseVoObj.setKey7(rs.get("threat_classification")==null?"":rs.get("threat_classification").toString());
				caseVoObj.setKey4(rs.get("alert_from_date")==null?"":rs.get("alert_from_date").toString());
				caseVoObj.setKey5(rs.get("alert_to_date")==null?"":rs.get("alert_to_date").toString());
				caseVoObj.setKey6(rs.get("alert_name")==null?"":rs.get("alert_name").toString());

				lst.add(caseVoObj);
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		} 
		return lst;
	}

	@Override
	public int getTargetUserProfileSocialAccountSize(UserProfileSocialAccountVo accountVo) 
	{
		int count = 0;
		try
		{			
			Number number = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM tbl_profile_social_account WHERE profile_id=? ", new Object[]{ accountVo.getProfileId() }, Integer.class);
		    return (number != null ? number.intValue() : 0);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return count;
	}

	@Override
	public ArrayList<EntityVo> getTargetProfileRelatedSocialMediaAccountsDetails(EntityVo entityVo) 
	{

		ArrayList<EntityVo> entityList = new ArrayList<EntityVo>();
		try
		{
			String selectQuery = "SELECT id, profile_id, entity_name, entity_id, entity_source_type, tw_id, entity_url, entity_img "
					+ "FROM tbl_profile_social_account "
					+ "WHERE profile_id="+entityVo.getTargetProfileId()+" ";
			System.out.println("selectQuery: "+selectQuery);

			List<Map<String, Object>> rows = jdbcTemplate.queryForList(selectQuery);
			for(Map<String, Object> row : rows)
			{
				EntityVo entity = new EntityVo();
				entity.setSocialAccountId((Integer)(row.get("id")));
				entity.setTargetProfileId((Integer)(row.get("profile_id")));
				entity.setEntityName((String)(row.get("entity_name")==null?"":row.get("entity_name").toString()));
				entity.setEntitySocialId((String)(row.get("entity_id")==null?"":row.get("entity_id").toString()));
				entity.setEntitySourceType((String)(row.get("entity_source_type")==null?"":row.get("entity_source_type").toString()));
				entity.setTwId( String.valueOf((row.get("tw_id")==null?"":row.get("tw_id").toString())));
				entity.setEntityUrl((String)(row.get("entity_url")==null?"":row.get("entity_url").toString()));
				entity.setEntityImg((String)(row.get("entity_img")==null?"":row.get("entity_img").toString()));
				entityList.add(entity);
			}									
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return entityList;
	}

	@Override
	public void saveSocialMediaAccountToTargetOrganizationView(CaseVo caseVo)
	{	
		TransactionDefinition def = new DefaultTransactionDefinition();
		TransactionStatus status = transactionManager.getTransaction(def);

		try 
		{
			Object[] obj = null;

			int id= caseVo.getTargetOrganizationId();
			System.out.println("Organization id: "+id);

			String deleteQuery = "DELETE FROM tbl_organization_social_account WHERE profile_id ="+caseVo.getTargetOrganizationId()+" ";
			jdbcTemplate.update(deleteQuery);
			System.out.println("deleteQuery: "+deleteQuery);

			for(EntityVo entityVo : caseVo.getLstEntityVos())
			{
				if(CommonUtils.stringNotEmpty(entityVo.getEntityName()))
				{

					String query= "INSERT INTO tbl_organization_social_account(profile_id, entity_name, entity_id, entity_source_type, entity_url, entity_img, tw_id) VALUES(?,?,?,?,?,?,?)" ;
					obj=new Object[]{
							caseVo.getTargetOrganizationId(), CommonUtils.removeSpaceFromTxt(entityVo.getEntityName().trim()), entityVo.getEntitySocialId().trim(),
							entityVo.getEntitySourceType().trim(), entityVo.getEntityUrl().trim(), entityVo.getEntityImg().trim(), entityVo.getTwId()						
					};
					jdbcTemplate.update(query, obj);												

					System.out.println("query: "+query);
					System.out.println("entity_name="+CommonUtils.removeSpaceFromTxt(entityVo.getEntityName().trim()));
					System.out.println("entity_id="+entityVo.getEntitySocialId().trim());
					System.out.println("entity_source_type="+entityVo.getEntitySourceType().trim());
					System.out.println("entity_url="+entityVo.getEntityUrl().trim());
					System.out.println("entity_img="+entityVo.getEntityImg().trim());
					System.out.println("tw_id="+entityVo.getTwId());
				}
				System.out.println(CommonUtils.removeSpaceFromTxt(entityVo.getEntityName().trim()) +" Inserted Successfully");
			}
			transactionManager.commit(status);			
		}
		catch (Exception e) 
		{
			transactionManager.rollback(status);
			e.printStackTrace();
		} 
	}

	@Override
	public ArrayList<EntityVo> getTargetOrganizationRelatedSocialMediaAccountsDetails(EntityVo entityVo) 
	{
		ArrayList<EntityVo> entityList = new ArrayList<EntityVo>();
		try
		{
			String selectQuery = "SELECT id, profile_id, entity_name, entity_id, entity_source_type, tw_id, entity_url, entity_img "
					+ "FROM tbl_organization_social_account "
					+ "WHERE profile_id="+entityVo.getTargetOrganizationId()+" ";
			System.out.println("selectQuery: "+selectQuery);

			List<Map<String, Object>> rows = jdbcTemplate.queryForList(selectQuery);
			for(Map<String, Object> row : rows)
			{
				EntityVo entity = new EntityVo();
				entity.setSocialAccountId((Integer)(row.get("id")));
				entity.setTargetOrganizationId((Integer)(row.get("profile_id")));
				entity.setEntityName((String)(row.get("entity_name")==null?"":row.get("entity_name").toString()));
				entity.setEntitySocialId((String)(row.get("entity_id")==null?"":row.get("entity_id").toString()));
				entity.setEntitySourceType((String)(row.get("entity_source_type")==null?"":row.get("entity_source_type").toString()));
				entity.setTwId( String.valueOf((row.get("tw_id")==null?"":row.get("tw_id").toString())));
				entity.setEntityUrl((String)(row.get("entity_url")==null?"":row.get("entity_url").toString()));
				entity.setEntityImg((String)(row.get("entity_img")==null?"":row.get("entity_img").toString()));
				entityList.add(entity);
			}									
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return entityList;
	}

	@Override
	public ArrayList<OrganizationBasicInformationVo> getCurrentAddedTargetOrganizationBasicInfo(OrganizationBasicInformationVo basicInformationVo)
	{
		ArrayList<OrganizationBasicInformationVo> orgList = new ArrayList<OrganizationBasicInformationVo>();
		try
		{
			String selectQuery = "SELECT id, organization_name, primary_headquarter, leader_name, date_of_creation, primary_location, "   
					+ " (SELECT photo_path FROM tbl_organization_photo WHERE tbl_organization_photo.id=tbl_organization_view.org_profile_photo_id) AS profilePhoto, "
					+ " (SELECT photo_path FROM tbl_organization_photo WHERE tbl_organization_photo.id=tbl_organization_view.org_cover_photo_id) AS coverPhoto, "
					+ " primary_phone_no, primary_email_id, primary_twitter_id, primary_facebook_id, bank_account_no, "
					+ " user_description, login_id, org_profile_photo_id, org_cover_photo_id, "
					+ " (SELECT GROUP_CONCAT(org_alias) FROM tbl_org_alias WHERE tbl_org_alias.org_id=tbl_organization_view.id) AS orgAlias "
					+ " FROM tbl_organization_view "
					+ " ORDER BY id DESC LIMIT 1 ";
			System.out.println("selectQuery: "+selectQuery);			

			List<Map<String, Object>> rows = jdbcTemplate.queryForList(selectQuery);
			for(Map<String, Object> rs : rows)
			{
				OrganizationBasicInformationVo org = new OrganizationBasicInformationVo();				
				org.setOrganizationId((Integer)(rs.get("id")));
				org.setOrganizationName((String)(rs.get("organization_name")));
				org.setPrimaryHeadquarter((String)(rs.get("primary_headquarter")));	
				org.setLeaderName((String)(rs.get("leader_name")));
				org.setDateOfCreation((String)(rs.get("date_of_creation")));
				org.setPrimaryLocation((String)(rs.get("primary_location")));	
				
				if(rs.get("profilePhoto")!=null)
				{
					String path = TwitterConstant.getPersonProfile();
					String finalPath = path.substring(path.indexOf("ROOT")+4);
					org.setOrgProfilePhotoId(finalPath+"/"+(String)rs.get("profilePhoto"));				
				}
				else 
				{
					org.setOrgProfilePhotoId(null);
				}	

				if(rs.get("coverPhoto")!=null) 
				{
					String path = TwitterConstant.getPersonProfile();
					String finalPath = path.substring(path.indexOf("ROOT")+4);
					org.setOrgCoverPhotoId(finalPath+"/"+(String)rs.get("coverPhoto"));
				} 
				else 
				{
					org.setOrgCoverPhotoId(null);
				}
				
				org.setPrimaryPhoneNo((Long)(rs.get("primary_phone_no")));
				org.setPrimaryEmailId((String)(rs.get("primary_email_id")));
				org.setPrimaryTwitterId((String)(rs.get("primary_twitter_id")));
				org.setPrimaryFacebookId((String)(rs.get("primary_facebook_id")));				
				org.setBankAccountNo((Long)(rs.get("bank_account_no")));
				org.setUserDescription((String)(rs.get("user_description")));
				org.setProfilePhotoId((Integer)(rs.get("org_profile_photo_id")));
				org.setProfileCoverPhotoId((Integer)(rs.get("org_cover_photo_id")));
				org.setOrgAlias(rs.get("orgAlias")==null?"":rs.get("orgAlias").toString());						
				orgList.add(org);			
			}
		} 
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}		
		return orgList;
	}

	@Override
	public void addTargetOrganizationContact(OrganizationContactVo contactVo) 
	{
		TransactionDefinition def = new DefaultTransactionDefinition();
		TransactionStatus status = transactionManager.getTransaction(def);

		try 
		{
			String query = "INSERT INTO tbl_organization_contact(org_id, contact, contact_type, contact_primary) VALUES(?,?,?,?)" ;
			Object[] obj = new Object[]{
					contactVo.getOrgId(), 
					contactVo.getContact(),
					contactVo.getContactType(), 
					contactVo.getContactPrimary() };
			jdbcTemplate.update(query, obj);
			System.out.println("insert query: "+query);
			transactionManager.commit(status);								
		}
		catch(Exception ex) 
		{
			transactionManager.rollback(status);
			ex.printStackTrace();
		} 
	}

	@Override
	public void editTargetOrganizationContact(OrganizationContactVo contactVo) 
	{
		TransactionDefinition def = new DefaultTransactionDefinition();
		TransactionStatus status = transactionManager.getTransaction(def);		
		try 
		{		
			String query = "UPDATE tbl_organization_contact set contact = '"+contactVo.getContact()+"', "
					+ " contact_type = '"+contactVo.getContactType()+"', contact_primary = '"+contactVo.getContactPrimary()+"'"
					+ " WHERE id = "+contactVo.getContactId()+" " ;
			jdbcTemplate.update(query);
			System.out.println("update query: "+query);
			transactionManager.commit(status);								
		}
		catch(Exception e) 
		{
			transactionManager.rollback(status);
			e.printStackTrace();
		}
	}

	@Override
	public void deleteTargetOrganizationContact(OrganizationContactVo contactVo) 
	{
		TransactionDefinition def = new DefaultTransactionDefinition();
		TransactionStatus status = transactionManager.getTransaction(def);		
		try 
		{		
			String deleteQuery = "DELETE FROM tbl_organization_contact WHERE id = "+contactVo.getContactId()+" ";
			jdbcTemplate.update(deleteQuery);
			System.out.println("deleteQuery: "+deleteQuery);
			transactionManager.commit(status);								
		}
		catch(Exception ex) 
		{
			transactionManager.rollback(status);
			ex.printStackTrace();
		}
	}

	@Override
	public ArrayList<OrganizationContactVo> getTargetOrganizationContactList(OrganizationContactVo contactVo) 
	{
		ArrayList<OrganizationContactVo> contactList = new ArrayList<OrganizationContactVo>();
		try
		{
			String selectQuery = "SELECT id, org_id, contact, contact_type, contact_primary "
					+ " FROM tbl_organization_contact "
					+ " WHERE org_id = "+contactVo.getOrgId()+" ORDER BY id DESC ";
			System.out.println("selectQuery: "+selectQuery);			

			List<Map<String, Object>> rows = jdbcTemplate.queryForList(selectQuery);
			for(Map<String, Object> rs : rows)
			{
				OrganizationContactVo org = new OrganizationContactVo();	

				org.setContactId((Integer)(rs.get("id")));
				org.setOrgId((Integer)(rs.get("org_id")));
				org.setContact((String)(rs.get("contact")));	
				org.setContactType((String)(rs.get("contact_type")));
				org.setContactPrimary((String)(rs.get("contact_primary")));																	
				contactList.add(org);			
			}			
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}		
		return contactList;
	}




	//SEARCH ANALYSIS PROFILE FROM SYSTEM:=================================
	@Override
	public ArrayList<EntityVo> searchTwitterUserFromSystems(EntityVo twUser) 
	{
		ArrayList<EntityVo> entityList = new ArrayList<EntityVo>();
		String countryFilter="";
		String catagoryFilter="";
		if(twUser.getProfileCountryId() != "")
		{
			countryFilter = " AND profile_country ='"+twUser.getProfileCountryId()+"' ";
		}
		if(twUser.getProfileCategoryId() != "")
		{
			catagoryFilter = " AND profile_category ='"+twUser.getProfileCategoryId()+"' ";
		}
				
		try
		{						
			/*String selectQuery = "SELECT entity.id, entity.entity_name, entity.entity_id, entity.entity_url, "
					+ " entity.entity_img, entity.entity_source_type, entity.tw_id, entity.varifiedUserFlag "
					+ " FROM tbl_entity AS entity"
					+ joinFilter
					+ " WHERE entity_type='p' AND entity_source_type='tw' "
					+ " AND (entity_name LIKE '%"+twUser.getSearchText()+"%' OR entity_id LIKE '%"+twUser.getSearchText()+"%') "+countryFilter+"  "+catagoryFilter+" ";
			*/
			String selectQuery = " SELECT DISTINCT profile_name, row_number, profile_user_name, profile_id, "
					+ " profile_url, profile_image_url, source, varifiedUserFlag "
					+ " FROM collection_profile "
					+ " WHERE profile_type='profile' AND source='twitter' "
					+ " AND (profile_name LIKE '%"+twUser.getSearchText()+"%' "
						  + " OR profile_user_name LIKE '%"+twUser.getSearchText()+"%' "
						  + " OR profile_id LIKE '%"+twUser.getSearchText()+"%')"
					+ " "+countryFilter+"  "+catagoryFilter+" ";
			
			System.out.println("Twitter profile selectQuery: "+selectQuery);
			List<Map<String, Object>> rows = jdbcTemplate.queryForList(selectQuery);
			System.out.println("Twitter profile count : "+rows.size());
			for(Map<String, Object> row : rows)
			{
				EntityVo entity = new EntityVo();
				entity.setId(row.get("row_number")==null?"":row.get("row_number").toString());
				entity.setEntityName((String)(row.get("profile_name")==null?"":row.get("profile_name").toString()));
				entity.setEntitySocialId((String)(row.get("profile_user_name")==null?"":row.get("profile_user_name").toString()));
				entity.setEntityUrl((String)(row.get("profile_url")==null?"":row.get("profile_url").toString()));
				entity.setEntityImg((String)(row.get("profile_image_url")==null?"":row.get("profile_image_url").toString()));
				entity.setEntitySourceType((String)(row.get("source")==null?"":row.get("source").toString()));
				entity.setTwId((String)(row.get("profile_id")==null?"":row.get("profile_id").toString()));		
				entity.setVarifiedUserFlag((String)(row.get("varifiedUserFlag")==null?"":row.get("varifiedUserFlag").toString()));
				entityList.add(entity);
			}									
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return entityList;
	}


	@Override
	public ArrayList<EntityVo> searchFbPageFromSystems(EntityVo fbPage)
	{
		ArrayList<EntityVo> entityList = new ArrayList<EntityVo>();
		String countryFilter = "";
		String catagoryFilter = "";
		if(fbPage.getProfileCountryId() != "")
		{
			countryFilter = " AND profile_country ='"+fbPage.getProfileCountryId()+"' ";
		}
		if(fbPage.getProfileCategoryId() != "")
		{
			catagoryFilter = " AND profile_category ='"+fbPage.getProfileCategoryId()+"' ";
		}		
		
		try 
		{			
			/*String selectQuery = "SELECT entity.id, entity_name, entity_id, entity_url, entity_img, entity_source_type, tw_id, fbtype "
					+ " FROM tbl_entity AS entity"
					+ joinFilter 
					+ " WHERE entity_type='p' AND entity_source_type='Fb' AND fbtype='0' "
					+ " AND (entity_name LIKE '%"+fbPage.getSearchText()+"%' OR entity_id LIKE '%"+fbPage.getSearchText()+"%') "+countryFilter+" "+catagoryFilter+" ";*/
			
			String selectQuery = " SELECT DISTINCT profile_name, row_number, profile_user_name, profile_id, "
					+ " profile_url, profile_image_url, source, varifiedUserFlag "
					+ " FROM collection_profile "
					+ " WHERE profile_type='page' AND source='facebook' "
					+ " AND (profile_name LIKE '%"+fbPage.getSearchText()+"%' "
						  + " OR profile_user_name LIKE '%"+fbPage.getSearchText()+"%' "
						  + " OR profile_id LIKE '%"+fbPage.getSearchText()+"%')"
					+ " "+countryFilter+"  "+catagoryFilter+" ";
			
			System.out.println("Facebook page selectQuery: "+selectQuery);
			List<Map<String, Object>> rows = jdbcTemplate.queryForList(selectQuery);
			System.out.println("Facebook page count : "+rows.size());
			for(Map<String, Object> row : rows) 
			{
				EntityVo entity = new EntityVo();
				entity.setId(row.get("row_number")==null?"":row.get("row_number").toString());
				entity.setEntityName((String)(row.get("profile_name")==null?"":row.get("profile_name").toString()));
				entity.setEntityScreenName((String)(row.get("profile_user_name")==null?"":row.get("profile_user_name").toString()));
				entity.setEntityUrl((String)(row.get("profile_url")==null?"":row.get("profile_url").toString()));
				entity.setEntityImg((String)(row.get("profile_image_url")==null?"":row.get("profile_image_url").toString()));
				entity.setEntitySourceType((String)(row.get("source")==null?"":row.get("source").toString()));
				entity.setEntitySocialId((String)(row.get("profile_id")==null?"":row.get("profile_id").toString()));		
				entity.setVarifiedUserFlag((String)(row.get("varifiedUserFlag")==null?"":row.get("varifiedUserFlag").toString()));
				entity.setFbType("0");
				entityList.add(entity);
			}									
		} 
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return entityList;
	}
	
	@Override
	public ArrayList<EntityVo> searchFbGroupFromSystems(EntityVo fbGroup) 
	{
		ArrayList<EntityVo> entityList = new ArrayList<EntityVo>();
		String countryFilter = "";
		String catagoryFilter = "";
		if(fbGroup.getProfileCountryId() != "")
		{
			countryFilter = " AND profile_country ='"+fbGroup.getProfileCountryId()+"' ";
		}
		if(fbGroup.getProfileCategoryId() != "")
		{
			catagoryFilter = " AND profile_category ='"+fbGroup.getProfileCategoryId()+"' ";
		}
		
		try 
		{
			/*String selectQuery = "SELECT entity.id, entity.entity_name, entity.entity_id, entity.entity_url, entity.entity_img, entity.entity_source_type, entity.tw_id, entity.fbtype "
					+ " FROM tbl_entity AS entity"
					+ joinFilter
					+ " WHERE entity_type='p' AND entity_source_type='Fb' AND fbtype='2' "
					+ " AND (entity_name LIKE '%"+fbGroup.getSearchText()+"%' OR entity_id LIKE '%"+fbGroup.getSearchText()+"%') "+countryFilter+" "+catagoryFilter+"";
			*/
			
			String selectQuery = " SELECT DISTINCT profile_name, row_number, profile_user_name, profile_id, "
					+ " profile_url, profile_image_url, source, varifiedUserFlag "
					+ " FROM collection_profile "
					+ " WHERE profile_type='group' AND source='facebook' "
					+ " AND (profile_name LIKE '%"+fbGroup.getSearchText()+"%' "
						  + " OR profile_user_name LIKE '%"+fbGroup.getSearchText()+"%' "
						  + " OR profile_id LIKE '%"+fbGroup.getSearchText()+"%')"
					+ " "+countryFilter+"  "+catagoryFilter+" ";
			
			System.out.println("Facebook group selectQuery: "+selectQuery);
			List<Map<String, Object>> rows = jdbcTemplate.queryForList(selectQuery);
			System.out.println("Facebook group count : "+rows.size());
			for(Map<String, Object> row : rows) 
			{
				EntityVo entity = new EntityVo();
				entity.setId(row.get("row_number")==null?"":row.get("row_number").toString());
				entity.setEntityName((String)(row.get("profile_name")==null?"":row.get("profile_name").toString()));
				entity.setEntityScreenName((String)(row.get("profile_user_name")==null?"":row.get("profile_user_name").toString()));
				entity.setEntityUrl((String)(row.get("profile_url")==null?"":row.get("profile_url").toString()));
				entity.setEntityImg((String)(row.get("profile_image_url")==null?"":row.get("profile_image_url").toString()));
				entity.setEntitySourceType((String)(row.get("source")==null?"":row.get("source").toString()));
				entity.setEntitySocialId((String)(row.get("profile_id")==null?"":row.get("profile_id").toString()));		
				entity.setVarifiedUserFlag((String)(row.get("varifiedUserFlag")==null?"":row.get("varifiedUserFlag").toString()));
				entity.setFbType("2");
				entityList.add(entity);
			}									
		} 
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return entityList;
	}
	
	@Override
	public ArrayList<EntityVo> searchFbProfileFromSystems(EntityVo fbProfile)
	{
		ArrayList<EntityVo> entityList = new ArrayList<EntityVo>();
		String countryFilter = "";
		String catagoryFilter = "";
		if(fbProfile.getProfileCountryId() != "")
		{
			countryFilter = " AND profile_country ='"+fbProfile.getProfileCountryId()+"' ";
		}
		if(fbProfile.getProfileCategoryId() != "")
		{
			catagoryFilter = " AND profile_category ='"+fbProfile.getProfileCategoryId()+"' ";
		}
		
		try
		{
			/*String selectQuery = "SELECT entity.id, entity.entity_name, entity.entity_id, entity.entity_url, entity.entity_img, entity.entity_source_type, entity.tw_id, entity.fbtype "
					+ " FROM tbl_entity AS entity"
					+ joinFilter
					+ " WHERE entity_type='p' AND entity_source_type='Fb' AND fbtype='1' "
			        + " AND (entity_name LIKE '%"+fbProfile.getSearchText()+"%' OR entity_id LIKE '%"+fbProfile.getSearchText()+"%' OR fb_user_profile_url LIKE '%"+fbProfile.getSearchText()+"%') "+countryFilter+"  "+catagoryFilter+" ";
			*/
			String selectQuery = " SELECT DISTINCT profile_name, row_number, profile_user_name, profile_id, "
					+ " profile_url, profile_image_url, source, varifiedUserFlag "
					+ " FROM collection_profile "
					+ " WHERE profile_type='profile' AND source='facebook' "
					+ " AND (profile_name LIKE '%"+fbProfile.getSearchText()+"%' "
						  + " OR profile_user_name LIKE '%"+fbProfile.getSearchText()+"%' "
						  + " OR profile_id LIKE '%"+fbProfile.getSearchText()+"%')"
					+ " "+countryFilter+"  "+catagoryFilter+" ";
			
			System.out.println("Facebook profile selectQuery: "+selectQuery);			
			List<Map<String, Object>> rows = jdbcTemplate.queryForList(selectQuery);
			System.out.println("Facebook profile count : "+rows.size());
			for(Map<String, Object> row : rows) 
			{				
				EntityVo entity = new EntityVo();
				entity.setId(row.get("row_number")==null?"":row.get("row_number").toString());
				entity.setEntityName((String)(row.get("profile_name")==null?"":row.get("profile_name").toString()));
				entity.setEntityScreenName((String)(row.get("profile_user_name")==null?"":row.get("profile_user_name").toString()));
				entity.setEntityUrl((String)(row.get("profile_url")==null?"":row.get("profile_url").toString()));
				entity.setEntityImg((String)(row.get("profile_image_url")==null?"":row.get("profile_image_url").toString()));
				entity.setEntitySourceType((String)(row.get("source")==null?"":row.get("source").toString()));
				entity.setEntitySocialId((String)(row.get("profile_id")==null?"":row.get("profile_id").toString()));		
				entity.setVarifiedUserFlag((String)(row.get("varifiedUserFlag")==null?"":row.get("varifiedUserFlag").toString()));
				entity.setFbType("1");
				entityList.add(entity);				
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return entityList;
	}

	@Override
	public ArrayList<EntityVo> searchInstaUserFromSystems(EntityVo instaUser) 
	{
		ArrayList<EntityVo> entityList = new ArrayList<EntityVo>();
		String countryFilter = "";
		String catagoryFilter = "";
		if(instaUser.getProfileCountryId() != "")
		{
			countryFilter = " AND profile_country ='"+instaUser.getProfileCountryId()+"' ";
		}
		if(instaUser.getProfileCategoryId() != "")
		{
			catagoryFilter = " AND profile_category ='"+instaUser.getProfileCategoryId()+"' ";
		}
		
		try
		{
			/*String selectQuery = "SELECT entity.id, entity.entity_name, entity.entity_id, entity.entity_url, entity.entity_img, entity.entity_source_type, entity.tw_id "
					+ " FROM tbl_entity AS entity"
					+ joinFilter
					+ " WHERE entity_type='p' AND entity_source_type='Insta' "
					+ " AND (entity_name LIKE '%"+instaUser.getSearchText()+"%' OR entity_id LIKE '%"+instaUser.getSearchText()+"%') "+countryFilter+"  "+catagoryFilter+" ";
			*/
			String selectQuery = " SELECT DISTINCT profile_name, row_number, profile_user_name, profile_id, "
					+ " profile_url, profile_image_url, source, varifiedUserFlag "
					+ " FROM collection_profile "
					+ " WHERE profile_type='profile' AND source='instagram' "
					+ " AND (profile_name LIKE '%"+instaUser.getSearchText()+"%' "
						  + " OR profile_user_name LIKE '%"+instaUser.getSearchText()+"%' "
						  + " OR profile_id LIKE '%"+instaUser.getSearchText()+"%')"
					+ " "+countryFilter+"  "+catagoryFilter+" ";
			
			System.out.println("Instragram profile selectQuery: "+selectQuery);
			List<Map<String, Object>> rows = jdbcTemplate.queryForList(selectQuery);
			System.out.println("Instragram profile count : "+rows.size());
			for(Map<String, Object> row : rows)
			{
				EntityVo entity = new EntityVo();
				entity.setId(row.get("row_number")==null?"":row.get("row_number").toString());
				entity.setEntityName((String)(row.get("profile_name")==null?"":row.get("profile_name").toString()));
				entity.setEntityScreenName((String)(row.get("profile_user_name")==null?"":row.get("profile_user_name").toString()));
				entity.setEntityUrl((String)(row.get("profile_url")==null?"":row.get("profile_url").toString()));
				entity.setEntityImg((String)(row.get("profile_image_url")==null?"":row.get("profile_image_url").toString()));
				entity.setEntitySourceType((String)(row.get("source")==null?"":row.get("source").toString()));
				entity.setEntitySocialId((String)(row.get("profile_id")==null?"":row.get("profile_id").toString()));		
				entity.setVarifiedUserFlag((String)(row.get("varifiedUserFlag")==null?"":row.get("varifiedUserFlag").toString()));
				entityList.add(entity);
			}									
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return entityList;
	}


	@Override
	public ArrayList<EntityVo> searchYoutubeChannleFromSystems(EntityVo ytUser) 
	{
		ArrayList<EntityVo> entityList = new ArrayList<EntityVo>();
		String countryFilter = "";
		String catagoryFilter = "";
		if(ytUser.getProfileCountryId() != "")
		{
			countryFilter = " AND profile_country ='"+ytUser.getProfileCountryId()+"' ";
		}
		if(ytUser.getProfileCategoryId() != "")
		{
			catagoryFilter = " AND profile_category ='"+ytUser.getProfileCategoryId()+"' ";
		}
		
		try
		{
			/*String selectQuery = "SELECT entity.id, entity.entity_name, entity.entity_id, entity.entity_url, entity.entity_img, entity.entity_source_type, entity.tw_id, entity.yttype "
					+ " FROM tbl_entity AS entity"
					+ joinFilter
					+ " WHERE entity_type='p' AND entity_source_type='Yt' "
					+ " AND (entity_name LIKE '%"+ytUser.getSearchText()+"%' OR entity_id LIKE '%"+ytUser.getSearchText()+"%') "+countryFilter+"  "+catagoryFilter+" ";
           */
			String selectQuery = " SELECT DISTINCT profile_name, row_number, profile_user_name, profile_id, "
					+ " profile_url, profile_image_url, source, varifiedUserFlag "
					+ " FROM collection_profile "
					+ " WHERE profile_type='profile' AND source='youtube' "
					+ " AND (profile_name LIKE '%"+ytUser.getSearchText()+"%' "
						  + " OR profile_user_name LIKE '%"+ytUser.getSearchText()+"%' "
						  + " OR profile_id LIKE '%"+ytUser.getSearchText()+"%')"
					+ " "+countryFilter+"  "+catagoryFilter+" ";
			
			System.out.println("Youtube profile selectQuery: "+selectQuery);
			List<Map<String, Object>> rows = jdbcTemplate.queryForList(selectQuery);
			System.out.println("Youtube profile count : "+rows.size());
			for(Map<String, Object> row : rows)
			{
				EntityVo entity = new EntityVo();
				entity.setId(row.get("row_number")==null?"":row.get("row_number").toString());
				entity.setEntityName((String)(row.get("profile_name")==null?"":row.get("profile_name").toString()));
				entity.setEntityScreenName((String)(row.get("profile_user_name")==null?"":row.get("profile_user_name").toString()));
				entity.setEntityUrl((String)(row.get("profile_url")==null?"":row.get("profile_url").toString()));
				entity.setEntityImg((String)(row.get("profile_image_url")==null?"":row.get("profile_image_url").toString()));
				entity.setEntitySourceType((String)(row.get("source")==null?"":row.get("source").toString()));
				entity.setEntitySocialId((String)(row.get("profile_id")==null?"":row.get("profile_id").toString()));		
				entity.setVarifiedUserFlag((String)(row.get("varifiedUserFlag")==null?"":row.get("varifiedUserFlag").toString()));
				entityList.add(entity);
			}									
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return entityList;
	}


	@Override
	public ArrayList<EntityVo> searchGbUsersFromSystems(EntityVo gbUser) 
	{
		ArrayList<EntityVo> entityList = new ArrayList<EntityVo>();
		String countryFilter = "";
		String catagoryFilter = "";
		if(gbUser.getProfileCountryId() != "")
		{
			countryFilter = " AND profile_country ='"+gbUser.getProfileCountryId()+"' ";
		}
		if(gbUser.getProfileCategoryId() != "")
		{
			catagoryFilter = " AND profile_category ='"+gbUser.getProfileCategoryId()+"' ";
		}
		
		try
		{
			/*String selectQuery = "SELECT entity.id, entity.entity_name, entity.entity_id, entity.entity_url, entity.entity_img, entity.entity_source_type, entity.tw_id "
					+ " FROM tbl_entity AS entity"
					+ joinFilter
					+ " WHERE entity_type='p' AND entity_source_type='Gb' "
					+ " AND (entity_name LIKE '%"+gbUser.getSearchText()+"%' OR entity_id LIKE '%"+gbUser.getSearchText()+"%') "+countryFilter+"  "+catagoryFilter+" ";
            */
			String selectQuery = " SELECT DISTINCT profile_name, row_number, profile_user_name, profile_id, "
					+ " profile_url, profile_image_url, source, varifiedUserFlag "
					+ " FROM collection_profile "
					+ " WHERE profile_type='profile' AND source='blogger' "
					+ " AND (profile_name LIKE '%"+gbUser.getSearchText()+"%' "
						  + " OR profile_user_name LIKE '%"+gbUser.getSearchText()+"%' "
						  + " OR profile_id LIKE '%"+gbUser.getSearchText()+"%')"
					+ " "+countryFilter+"  "+catagoryFilter+" ";
			
			System.out.println("Google blogg profile selectQuery: "+selectQuery);
			List<Map<String, Object>> rows = jdbcTemplate.queryForList(selectQuery);
			System.out.println("Google blogg profile count : "+rows.size());
			for(Map<String, Object> row : rows)
			{
				EntityVo entity = new EntityVo();
				entity.setId(row.get("row_number")==null?"":row.get("row_number").toString());
				entity.setEntityName((String)(row.get("profile_name")==null?"":row.get("profile_name").toString()));
				entity.setEntityScreenName((String)(row.get("profile_user_name")==null?"":row.get("profile_user_name").toString()));
				entity.setEntityUrl((String)(row.get("profile_url")==null?"":row.get("profile_url").toString()));
				entity.setEntityImg((String)(row.get("profile_image_url")==null?"":row.get("profile_image_url").toString()));
				entity.setEntitySourceType((String)(row.get("source")==null?"":row.get("source").toString()));
				entity.setEntitySocialId((String)(row.get("profile_id")==null?"":row.get("profile_id").toString()));		
				entity.setVarifiedUserFlag((String)(row.get("varifiedUserFlag")==null?"":row.get("varifiedUserFlag").toString()));
				entityList.add(entity);
			}									
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return entityList;
	}

	
	

	@Override
	public ArrayList<EntityVo> searchTmUsersFromSystems(EntityVo tmUser) 
	{
		ArrayList<EntityVo> entityList = new ArrayList<EntityVo>();
		String countryFilter = "";
		String catagoryFilter = "";
		if(tmUser.getProfileCountryId() != "")
		{
			countryFilter = " AND profile_country ='"+tmUser.getProfileCountryId()+"' ";
		}
		if(tmUser.getProfileCategoryId() != "")
		{
			catagoryFilter = " AND profile_category ='"+tmUser.getProfileCategoryId()+"' ";
		}
		
		try
		{
			/*String selectQuery = "SELECT entity.id, entity.entity_name, entity.entity_id, entity.entity_url, entity.entity_img, entity.entity_source_type, entity.tw_id "
					+ " FROM tbl_entity AS entity"
					+ joinFilter
					+ " WHERE entity_type='p' AND entity_source_type='Tm' "
					+ " AND  (entity_name LIKE '%"+tmUser.getSearchText()+"%' OR entity_id LIKE '%"+tmUser.getSearchText()+"%') "+countryFilter+"  "+catagoryFilter+" ";
            */
			String selectQuery = " SELECT DISTINCT profile_name, row_number, profile_user_name, profile_id, "
					+ " profile_url, profile_image_url, source, varifiedUserFlag "
					+ " FROM collection_profile "
					+ " WHERE profile_type='profile' AND source='tumblr' "
					+ " AND (profile_name LIKE '%"+tmUser.getSearchText()+"%' "
						  + " OR profile_user_name LIKE '%"+tmUser.getSearchText()+"%' "
						  + " OR profile_id LIKE '%"+tmUser.getSearchText()+"%')"
					+ " "+countryFilter+"  "+catagoryFilter+" ";
			
			System.out.println("Tumblr profile selectQuery: "+selectQuery);
			List<Map<String, Object>> rows = jdbcTemplate.queryForList(selectQuery);
			System.out.println("Tumblr profile count : "+rows.size());
			for(Map<String, Object> row : rows)
			{
				EntityVo entity = new EntityVo();
				entity.setId(row.get("row_number")==null?"":row.get("row_number").toString());
				entity.setEntityName((String)(row.get("profile_name")==null?"":row.get("profile_name").toString()));
				entity.setEntityScreenName((String)(row.get("profile_user_name")==null?"":row.get("profile_user_name").toString()));
				entity.setEntityUrl((String)(row.get("profile_url")==null?"":row.get("profile_url").toString()));
				entity.setEntityImg((String)(row.get("profile_image_url")==null?"":row.get("profile_image_url").toString()));
				entity.setEntitySourceType((String)(row.get("source")==null?"":row.get("source").toString()));
				entity.setEntitySocialId((String)(row.get("profile_id")==null?"":row.get("profile_id").toString()));		
				entity.setVarifiedUserFlag((String)(row.get("varifiedUserFlag")==null?"":row.get("varifiedUserFlag").toString()));
				entityList.add(entity);
			}									
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return entityList;
	}


	@Override
	public ArrayList<EntityVo> searchDMUserFromSystems(EntityVo dmUser) 
	{
		ArrayList<EntityVo> entityList = new ArrayList<EntityVo>();
		String countryFilter = "";
		String catagoryFilter = "";
		if(dmUser.getProfileCountryId() != "")
		{
			countryFilter = " AND profile_country ='"+dmUser.getProfileCountryId()+"' ";
		}
		if(dmUser.getProfileCategoryId() != "")
		{
			catagoryFilter = " AND profile_category ='"+dmUser.getProfileCategoryId()+"' ";
		}
		
		try
		{
			/*String selectQuery = "SELECT entity.id, entity.entity_name, entity.entity_id, entity.entity_url, entity.entity_img, entity.entity_source_type, entity.tw_id "
					+ " FROM tbl_entity AS entity"
					+ joinFilter
					+ " WHERE entity_type='p' AND entity_source_type='Dm' "
					+ " AND (entity_name LIKE '%"+dmUser.getSearchText()+"%' OR entity_id LIKE '%"+dmUser.getSearchText()+"%') "+countryFilter+"  "+catagoryFilter+" ";
			*/
			String selectQuery = " SELECT DISTINCT profile_name, row_number, profile_user_name, profile_id, "
					+ " profile_url, profile_image_url, source, varifiedUserFlag "
					+ " FROM collection_profile "
					+ " WHERE profile_type='profile' AND source='dailymotion' "
					+ " AND (profile_name LIKE '%"+dmUser.getSearchText()+"%' "
						  + " OR profile_user_name LIKE '%"+dmUser.getSearchText()+"%' "
						  + " OR profile_id LIKE '%"+dmUser.getSearchText()+"%')"
					+ " "+countryFilter+"  "+catagoryFilter+" ";
			
			System.out.println("Dailymotion profile selectQuery: "+selectQuery);
			List<Map<String, Object>> rows = jdbcTemplate.queryForList(selectQuery);
			System.out.println("Dailymotion profile count : "+rows.size());
			for(Map<String, Object> row : rows)
			{
				EntityVo entity = new EntityVo();
				entity.setId(row.get("row_number")==null?"":row.get("row_number").toString());
				entity.setEntityName((String)(row.get("profile_name")==null?"":row.get("profile_name").toString()));
				entity.setEntityScreenName((String)(row.get("profile_user_name")==null?"":row.get("profile_user_name").toString()));
				entity.setEntityUrl((String)(row.get("profile_url")==null?"":row.get("profile_url").toString()));
				entity.setEntityImg((String)(row.get("profile_image_url")==null?"":row.get("profile_image_url").toString()));
				entity.setEntitySourceType((String)(row.get("source")==null?"":row.get("source").toString()));
				entity.setEntitySocialId((String)(row.get("profile_id")==null?"":row.get("profile_id").toString()));		
				entity.setVarifiedUserFlag((String)(row.get("varifiedUserFlag")==null?"":row.get("varifiedUserFlag").toString()));
				entityList.add(entity);
			}									
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return entityList;
	}
	
	
	@Override
	public ArrayList<EntityVo> searchRedditUsersFromSystems(EntityVo redditUser) 
	{
		ArrayList<EntityVo> entityList = new ArrayList<EntityVo>();
		String countryFilter = "";
		String catagoryFilter = "";
		if(redditUser.getProfileCountryId() != "")
		{
			countryFilter = " AND profile_country ='"+redditUser.getProfileCountryId()+"' ";
		}
		if(redditUser.getProfileCategoryId() != "")
		{
			catagoryFilter = " AND profile_category ='"+redditUser.getProfileCategoryId()+"' ";
		}
		
		try
		{
			String selectQuery = " SELECT DISTINCT profile_name, row_number, profile_user_name, profile_id, "
					+ " profile_url, profile_image_url, source, varifiedUserFlag "
					+ " FROM collection_profile "
					+ " WHERE source='reddit' "
					+ " AND (profile_name LIKE '%"+redditUser.getSearchText()+"%' "
						  + " OR profile_user_name LIKE '%"+redditUser.getSearchText()+"%' "
						  + " OR profile_id LIKE '%"+redditUser.getSearchText()+"%')"
					+ " "+countryFilter+"  "+catagoryFilter+" ";
			
			System.out.println("Reddit profile selectQuery: "+selectQuery);
			List<Map<String, Object>> rows = jdbcTemplate.queryForList(selectQuery);
			System.out.println("Reddit profile count : "+rows.size());
			for(Map<String, Object> row : rows)
			{
				EntityVo entity = new EntityVo();
				entity.setId(row.get("row_number")==null?"":row.get("row_number").toString());
				entity.setEntityName((String)(row.get("profile_name")==null?"":row.get("profile_name").toString()));
				entity.setEntityScreenName((String)(row.get("profile_user_name")==null?"":row.get("profile_user_name").toString()));
				entity.setEntityUrl((String)(row.get("profile_url")==null?"":row.get("profile_url").toString()));
				entity.setEntityImg((String)(row.get("profile_image_url")==null?"":row.get("profile_image_url").toString()));
				entity.setEntitySourceType((String)(row.get("source")==null?"":row.get("source").toString()));
				entity.setEntitySocialId((String)(row.get("profile_id")==null?"":row.get("profile_id").toString()));		
				entity.setVarifiedUserFlag((String)(row.get("varifiedUserFlag")==null?"":row.get("varifiedUserFlag").toString()));
				entityList.add(entity);
			}									
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return entityList;
	}

	@Override
	public ArrayList<EntityVo> searchFlickrUsersFromSystems(EntityVo flickrUser)
	{
		ArrayList<EntityVo> entityList = new ArrayList<EntityVo>();
		String countryFilter = "";
		String catagoryFilter = "";
		if(flickrUser.getProfileCountryId() != "")
		{
			countryFilter = " AND profile_country ='"+flickrUser.getProfileCountryId()+"' ";
		}
		if(flickrUser.getProfileCategoryId() != "")
		{
			catagoryFilter = " AND profile_category ='"+flickrUser.getProfileCategoryId()+"' ";
		}
		
		try
		{
			String selectQuery = " SELECT DISTINCT profile_name, row_number, profile_user_name, profile_id, "
					+ " profile_url, profile_image_url, source, varifiedUserFlag "
					+ " FROM collection_profile "
					+ " WHERE source='flickr' "
					+ " AND (profile_name LIKE '%"+flickrUser.getSearchText()+"%' "
						  + " OR profile_user_name LIKE '%"+flickrUser.getSearchText()+"%' "
						  + " OR profile_id LIKE '%"+flickrUser.getSearchText()+"%')"
					+ " "+countryFilter+"  "+catagoryFilter+" ";
			
			System.out.println("Flickr profile selectQuery: "+selectQuery);
			List<Map<String, Object>> rows = jdbcTemplate.queryForList(selectQuery);
			System.out.println("Flickr profile count : "+rows.size());
			for(Map<String, Object> row : rows)
			{
				EntityVo entity = new EntityVo();
				entity.setId(row.get("row_number")==null?"":row.get("row_number").toString());
				entity.setEntityName((String)(row.get("profile_name")==null?"":row.get("profile_name").toString()));
				entity.setEntityScreenName((String)(row.get("profile_user_name")==null?"":row.get("profile_user_name").toString()));
				entity.setEntityUrl((String)(row.get("profile_url")==null?"":row.get("profile_url").toString()));
				entity.setEntityImg((String)(row.get("profile_image_url")==null?"":row.get("profile_image_url").toString()));
				entity.setEntitySourceType((String)(row.get("source")==null?"":row.get("source").toString()));
				entity.setEntitySocialId((String)(row.get("profile_id")==null?"":row.get("profile_id").toString()));		
				entity.setVarifiedUserFlag((String)(row.get("varifiedUserFlag")==null?"":row.get("varifiedUserFlag").toString()));
				entityList.add(entity);
			}									
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return entityList;
	}

	@Override
	public ArrayList<EntityVo> searchLinkedinUsersFromSystems(EntityVo linkedinUser) 
	{
		ArrayList<EntityVo> entityList = new ArrayList<EntityVo>();
		String countryFilter = "";
		String catagoryFilter = "";
		if(linkedinUser.getProfileCountryId() != "")
		{
			countryFilter = " AND profile_country ='"+linkedinUser.getProfileCountryId()+"' ";
		}
		if(linkedinUser.getProfileCategoryId() != "")
		{
			catagoryFilter = " AND profile_category ='"+linkedinUser.getProfileCategoryId()+"' ";
		}
		
		try
		{
			String selectQuery = " SELECT DISTINCT profile_name, row_number, profile_user_name, profile_id, "
					+ " profile_url, profile_image_url, source, varifiedUserFlag "
					+ " FROM collection_profile "
					+ " WHERE profile_type='profile' AND source='linkedin' "
					+ " AND (profile_name LIKE '%"+linkedinUser.getSearchText()+"%' "
						  + " OR profile_user_name LIKE '%"+linkedinUser.getSearchText()+"%' "
						  + " OR profile_id LIKE '%"+linkedinUser.getSearchText()+"%')"
					+ " "+countryFilter+"  "+catagoryFilter+" ";
			
			System.out.println("Linkedin profile selectQuery: "+selectQuery);
			List<Map<String, Object>> rows = jdbcTemplate.queryForList(selectQuery);
			System.out.println("Linkedin profile count : "+rows.size());
			for(Map<String, Object> row : rows)
			{
				EntityVo entity = new EntityVo();
				entity.setId(row.get("row_number")==null?"":row.get("row_number").toString());
				entity.setEntityName((String)(row.get("profile_name")==null?"":row.get("profile_name").toString()));
				entity.setEntityScreenName((String)(row.get("profile_user_name")==null?"":row.get("profile_user_name").toString()));
				entity.setEntityUrl((String)(row.get("profile_url")==null?"":row.get("profile_url").toString()));
				entity.setEntityImg((String)(row.get("profile_image_url")==null?"":row.get("profile_image_url").toString()));
				entity.setEntitySourceType((String)(row.get("source")==null?"":row.get("source").toString()));
				entity.setEntitySocialId((String)(row.get("profile_id")==null?"":row.get("profile_id").toString()));		
				entity.setVarifiedUserFlag((String)(row.get("varifiedUserFlag")==null?"":row.get("varifiedUserFlag").toString()));
				entityList.add(entity);
			}									
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return entityList;
	}
	


	@Override
	public ArrayList<CaseVo> getCountryState(CaseVo caseVo) 
	{
		ArrayList<CaseVo> list=new ArrayList<CaseVo>();
		try 
		{
			String query=" SELECT * from country_state";
			System.out.println("get Country States ::"+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs : rows)
			{
				CaseVo caseVoObj=new CaseVo();
				caseVoObj.setId(rs.get("id")==null?"":rs.get("id").toString());
				caseVoObj.setKey1(rs.get("country_id")==null?"":rs.get("country_id").toString());
				caseVoObj.setKey2(rs.get("state_name")==null?"":rs.get("state_name").toString());
				list.add(caseVoObj);
			}
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		} 
		return list;
	}

	@Override
	public ArrayList<CaseVo> getStateCity(CaseVo caseVo) 
	{
		ArrayList<CaseVo> lst=new ArrayList<CaseVo>();
		try 
		{
			String query="	SELECT * from state_city";
			System.out.println("get State Cities ::"+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs : rows)
			{
				CaseVo caseVoObj=new CaseVo();
				caseVoObj.setId(rs.get("id")==null?"":rs.get("id").toString());
				caseVoObj.setKey1(rs.get("state_id")==null?"":rs.get("state_id").toString());
				caseVoObj.setKey2(rs.get("city_name")==null?"":rs.get("city_name").toString());
				lst.add(caseVoObj);
			}
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		} 
		return lst;
	}

	@Override
	public void actDeactivateAvatar(CaseVo caseVo) 
	{
		try 
		{
			String query=" UPDATE tbl_crawl_avatar set isActive='"+caseVo.getId()+"' "
					   + " WHERE id='"+caseVo.getCaseId()+"'";
			System.out.println("Update Fb Avatar ActDeactivate Status == "+query);
			jdbcTemplate.execute(query);
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		} 
	}

	@Override
	public void addAlias(CaseVo caseVo) 
	{
		String user=(String)httpSession.getAttribute(ApplicationConstants.LOGINUSERID);
		String query="";
		if(caseVo.getActType().equals("add"))
		{
			query=" insert ignore into tbl_ner_alias(firstName,lastName,alias,type,date_of_insertion,login_id) values(?,?,?,?,now(),?)";
			System.out.println("Add Alias :::"+query);
			Object[] obj=new Object[]{CommonUtils.removeSpaceFromTxt(caseVo.getKey1().trim()),CommonUtils.removeSpaceFromTxt(caseVo.getKey2().trim()),CommonUtils.removeSpaceFromTxt(caseVo.getKey3().trim()),caseVo.getKey4().trim(),user};
			jdbcTemplate.update(query,obj);
		}
		else if(caseVo.getActType().equals("edit")) 
		{
			query=" update  tbl_ner_alias set first_name='"+caseVo.getKey1().trim()+"',last_name='"+caseVo.getKey2().trim()+"',alias='"+caseVo.getKey3().trim()+"',"
					+ "type='"+caseVo.getKey4().trim()+"' where id='"+caseVo.getId()+"'";
			System.out.println("Update Add Alias ::"+query);
			jdbcTemplate.update(query);
		}
		else if(caseVo.getActType().equals("delete")) 
		{
			query=" delete from tbl_ner_alias where id='"+caseVo.getId()+"'";
			System.out.println("delete Add Alias ::"+query);
			jdbcTemplate.update(query);
		}
	}


	public ArrayList<CaseVo> getNerAlias(CaseVo caseVo)
	{
		ArrayList<CaseVo> lst=new ArrayList<CaseVo>();
		try 
		{
			String subQuery="";
			String user=(String)httpSession.getAttribute(ApplicationConstants.LOGINUSERID);
			String role=(String)httpSession.getAttribute(ApplicationConstants.USERROLE);
			if(!role.toLowerCase().equals("a"))
			{
				subQuery+=" and login_id='"+user+"'";
			}			
			if(!caseVo.getKey1().trim().isEmpty())
			{
				subQuery+=" and (firstName like '%"+caseVo.getKey1().trim()+"%' or lastName like '%"+caseVo.getKey1().trim()+"%' or alias like '%"+caseVo.getKey1().trim()+"%') ";
			}
			switch(caseVo.getKey2()) 
			{
			case "p":
				subQuery+=" and type='P'";
				break;
			case "l":
				subQuery+=" and type='L'";
				break;
			case "o":
				subQuery+=" and type='O'";
				break;
			}
			String query=" SELECT tbl_ner_alias.id,firstName,lastName,alias,type,COALESCE(DATE_FORMAT((tbl_ner_alias.date_of_insertion),'%b %d,%Y %r'),'') as  date_of_insertion,login_detail.user_logon_id from tbl_ner_alias"
					+ " inner join login_detail on login_detail.id=tbl_ner_alias.login_id  "
					+ " where 1=1 "+subQuery +" limit "+caseVo.getRowNum()+",50";
			System.out.println("getNerAlias ::"+query);

			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs : rows)
			{
				CaseVo caseVoObj=new CaseVo();
				caseVoObj.setId(rs.get("id")==null?"":rs.get("id").toString());
				caseVoObj.setKey1(rs.get("firstName")==null?"":rs.get("firstName").toString());
				caseVoObj.setKey2(rs.get("lastName")==null?"":rs.get("lastName").toString());
				caseVoObj.setKey3(rs.get("alias")==null?"":rs.get("alias").toString());
				caseVoObj.setKey4(rs.get("type")==null?"":rs.get("type").toString());
				caseVoObj.setKey5(rs.get("date_of_insertion")==null?"":rs.get("date_of_insertion").toString());
				caseVoObj.setKey6(rs.get("user_logon_id")==null?"":rs.get("user_logon_id").toString());
				lst.add(caseVoObj);
			}
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		} 
		return lst;
	}

	@Override
	public ArrayList<CaseVo> getAllDistinctAliasEntity(CaseVo caseVo) 
	{
		ArrayList<CaseVo> lst=new ArrayList<CaseVo>();
		try 
		{
			String subQuery="";
			switch (caseVo.getKey2().toLowerCase())
			{
			case "p":
				subQuery+=" and type='P'";
				break;
			case "l":
				subQuery+=" and type='L'";
				break;
			case "o":
				subQuery+=" and type='O'";
				break;
			}
			String query=" SELECT distinct firstName,lastName from tbl_ner_alias "
					+ " where 1=1 "+subQuery;
			System.out.println("getAllDistinctAliasEntity ::"+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);

			for(Map<String, Object> rs : rows)
			{
				CaseVo caseVoObj=new CaseVo();
				caseVoObj.setKey1(rs.get("firstName")==null?"":rs.get("firstName").toString());
				caseVoObj.setKey2(rs.get("lastName")==null?"":rs.get("lastName").toString());
				lst.add(caseVoObj);
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		} 
		return lst;
	}

	@Override
	public void addAliasIgnore(CaseVo caseVo) 
	{
		String user=(String)httpSession.getAttribute(ApplicationConstants.LOGINUSERID);
		String query="";
		if(caseVo.getActType().equals("add")) 
		{
			query=" insert ignore into tbl_ner_ignore(keyword, type, date_of_insertion, login_id) values(?, ?, now(), ?)";
			System.out.println("addAliasIgnore query ::: "+query);
			Object[] obj=new Object[]{CommonUtils.removeSpaceFromTxt(caseVo.getKey1().trim()),caseVo.getKey2().trim(),user};
			jdbcTemplate.update(query,obj);
		} 
		else if(caseVo.getActType().equals("edit"))
		{
			query=" update tbl_ner_ignore set keyword='"+caseVo.getKey1().trim()+"',type='"+caseVo.getKey2().trim()+"' where id='"+caseVo.getId()+"'";
			System.out.println("Update addAliasIgnore ::"+query);
			jdbcTemplate.update(query);
		}
		if(caseVo.getActType().equals("delete")) 
		{
			query=" delete from tbl_ner_ignore where id='"+caseVo.getId()+"'";
			System.out.println("delete addAliasIgnore ::"+query);
			jdbcTemplate.update(query);
		}
	}

	@Override
	public ArrayList<CaseVo> getAliasIgnore(CaseVo caseVo) 
	{
		ArrayList<CaseVo> lst=new ArrayList<CaseVo>();
		try
		{
			String subQuery="";
			String user=(String)httpSession.getAttribute(ApplicationConstants.LOGINUSERID);
			String role=(String)httpSession.getAttribute(ApplicationConstants.USERROLE);
			if(!role.toLowerCase().equals("a"))
			{
				subQuery+=" and login_id='"+user+"'";
			}

			if(!caseVo.getKey1().trim().isEmpty())
			{
				subQuery+=" and keyword like '%"+caseVo.getKey1().trim()+"%'";
			}
			switch (caseVo.getKey2().toLowerCase()) 
			{
			case "p":
				subQuery+=" and type='P'";
				break;
			case "l":
				subQuery+=" and type='L'";
				break;
			case "o":
				subQuery+=" and type='O'";
				break;
			case "t":
				subQuery+=" and type='T'";
				break;
			}
			String query="	SELECT tbl_ner_ignore.id,keyword,type,COALESCE(DATE_FORMAT((tbl_ner_ignore.date_of_insertion),'%b %d,%Y %r'),'') as  date_of_insertion,login_detail.user_logon_id from tbl_ner_ignore"
					+ " inner join login_detail on login_detail.id=tbl_ner_ignore.login_id  "
					+ " where 1=1 "+subQuery +" limit "+caseVo.getRowNum()+",50";
			System.out.println("getAliasIgnore ::"+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);

			for(Map<String,Object> rs : rows)
			{
				CaseVo caseVoObj=new CaseVo();
				caseVoObj.setId(rs.get("id")==null?"":rs.get("id").toString());
				caseVoObj.setKey1(rs.get("keyword")==null?"":rs.get("keyword").toString());
				caseVoObj.setKey2(rs.get("type")==null?"":rs.get("type").toString());
				caseVoObj.setKey3(rs.get("user_logon_id")==null?"":rs.get("user_logon_id").toString());
				caseVoObj.setKey4(rs.get("date_of_insertion")==null?"":rs.get("date_of_insertion").toString());
				lst.add(caseVoObj);
			}
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		} 
		return lst;
	}

	@Override
	public void addAliasReplace(CaseVo caseVo) 
	{
		try 
		{
			String user=(String)httpSession.getAttribute(ApplicationConstants.LOGINUSERID);
			String query="";
			if(caseVo.getActType().equals("add"))
			{
				query="INSERT ignore into tbl_ner_replace(keyword, fromNer, toNer, date_of_insertion, login_id) values(?, ?, ?, now(), ?)";
				System.out.println("addAliasReplace ::: "+query);
				Object[] obj=new Object[]{CommonUtils.removeSpaceFromTxt(caseVo.getKey1().trim()), caseVo.getKey2().trim(), caseVo.getKey3().trim(), user};
				jdbcTemplate.update(query, obj);
			} 
			else if(caseVo.getActType().equals("add"))
			{
				query=" update tbl_ner_replace set keyword='"+caseVo.getKey1().trim()+"', fromNer='"+caseVo.getKey2().trim()+"', toNer='"+caseVo.getKey3().trim()+"' where id='"+caseVo.getId()+"'";
				System.out.println("Update addAliasReplace ::"+query);
				jdbcTemplate.update(query);
			} 
			else if(caseVo.getActType().equals("delete"))
			{
				query=" delete from  tbl_ner_replace  where id='"+caseVo.getId()+"'";
				System.out.println("delete addAliasReplace ::"+query);
				jdbcTemplate.update(query);
			}
		} 
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
	}

	@Override
	public ArrayList<CaseVo> getAliasReplace(CaseVo caseVo) 
	{
		ArrayList<CaseVo> lst=new ArrayList<CaseVo>();
		try 
		{
			String subQuery="";
			String user=(String)httpSession.getAttribute(ApplicationConstants.LOGINUSERID);
			String role=(String)httpSession.getAttribute(ApplicationConstants.USERROLE);
			if(!role.toLowerCase().equals("a")) {
				subQuery+=" and login_id='"+user+"'";
			}

			if(!caseVo.getKey1().trim().isEmpty()) {
				subQuery+=" and keyword like '%"+caseVo.getKey1().trim()+"%'";
			}
			switch(caseVo.getKey2()) {
			case "p":
				subQuery+=" and fromNer='P'";
				break;
			case "l":
				subQuery+=" and fromNer='L'";
				break;
			case "o":
				subQuery+=" and fromNer='O'";
				break;
			}

			switch(caseVo.getKey3()) {
			case "p":
				subQuery+=" and toNer='P'";
				break;
			case "l":
				subQuery+=" and toNer='L'";
				break;
			case "o":
				subQuery+=" and toNer='O'";
				break;
			}

			String query=" SELECT tbl_ner_replace.id, keyword, fromNer, toNer, COALESCE(DATE_FORMAT((tbl_ner_replace.date_of_insertion),'%b %d,%Y %r'),'') as date_of_insertion, login_detail.user_logon_id from tbl_ner_replace"
					+ " inner join login_detail on login_detail.id=tbl_ner_replace.login_id  "
					+ " where 1=1 "+subQuery +" limit "+caseVo.getRowNum()+",50";
			System.out.println("getAliasReplace ::"+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);

			for(Map<String,Object> rs : rows)
			{
				CaseVo caseVoObj=new CaseVo();
				caseVoObj.setId(rs.get("id")==null?"":rs.get("id").toString());
				caseVoObj.setKey1(rs.get("keyword")==null?"":rs.get("keyword").toString());
				caseVoObj.setKey2(rs.get("fromNer")==null?"":rs.get("fromNer").toString());
				caseVoObj.setKey5(rs.get("toNer")==null?"":rs.get("toNer").toString());
				caseVoObj.setKey3(rs.get("user_logon_id")==null?"":rs.get("user_logon_id").toString());
				caseVoObj.setKey4(rs.get("date_of_insertion")==null?"":rs.get("date_of_insertion").toString());
				lst.add(caseVoObj);
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return lst;
	}

	@Override
	public void addFbUserToSearch(CaseVo caseVo) 
	{
		try
		{
			String user=(String)httpSession.getAttribute(ApplicationConstants.LOGINUSERID);
			String query=" INSERT ignore into tbl_fb_profile_search(profileUrl, avatarId, date_of_insert, "
					   + " url_type, loginId, fbProfileCategory, fbProfileCountryCode, fbDelta) "
					   + " values(?, ?, now(), ?, ?, ?, ?, ?)";
			System.out.println("addFbUserToSearch : "+query);
			
			Object[] obj=new Object[]{caseVo.getKey1().trim(),
					caseVo.getKey2().trim(),
					caseVo.getKey3().trim(),
					user,
					caseVo.getKey4().trim(),
					caseVo.getKey5().trim(),
					caseVo.getKey6().trim()};
			jdbcTemplate.update(query, obj);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}		
	}

	@Override
	public ArrayList<CaseVo> getFbUserAfterSearch(CaseVo caseVo)
	{		
		ArrayList<CaseVo> list=new ArrayList<CaseVo>();
		try 
		{
			String subQuery="";
			String user=(String)httpSession.getAttribute(ApplicationConstants.LOGINUSERID);
			String role=(String)httpSession.getAttribute(ApplicationConstants.USERROLE);

			if(!role.toLowerCase().equals("a"))
			{
				//subQuery+=" and login_detail.id='"+user+"'";
			}

			if(!caseVo.getKey1().trim().isEmpty())
			{
				subQuery+=" and (tbl_fb_profile_search.profileUrl like '%"+caseVo.getKey1().trim()+"%')";
			}

			switch(caseVo.getKey2().trim())
			{
			case "0":
				subQuery+=" and tbl_fb_profile_search.search_status='0' ";
				break;
				
			case "1":
				subQuery+=" and tbl_fb_profile_search.search_status='1' ";
				break;
				
			case "2":
				subQuery+=" and tbl_fb_profile_search.search_status='2' ";
				break;
				
			default:
				break;
			}

			//Avatar Filter
			if(!caseVo.getKey3().trim().isEmpty())
			{
				subQuery+=" and (tbl_fb_profile_search.avatarId ='"+caseVo.getKey3()+"') ";
			}

			//Show Hide Filter
			if(caseVo.getKey4().trim().equals("0"))
			{
				subQuery+=" and tbl_fb_profile_search.addToCrawler='0' ";
			}
			else if(caseVo.getKey4().trim().equals("1"))
			{
				subQuery+=" and tbl_fb_profile_search.addToCrawler='1' ";
			}
			else
			{ }
			
			if(!caseVo.getKey6().trim().equals("all"))
			{
				subQuery+=" and tbl_fb_profile_search.url_type='"+caseVo.getKey6()+"' ";
			}
			
			//Sort Filter
			if(caseVo.getKey5().trim().equals("an"))
			{
				subQuery+=" ORDER BY tbl_fb_profile_search.date_of_insert DESC ";
			}
			else if(caseVo.getKey5().trim().equals("ao"))
			{
				subQuery+=" ORDER BY tbl_fb_profile_search.date_of_insert ASC ";
			}

			String query=" SELECT tbl_fb_profile_search.id, tbl_fb_profile_search.profileUrl, tbl_crawl_avatar.user_name as avatarName, "
					+ " COALESCE(DATE_FORMAT((tbl_fb_profile_search.date_of_insert),'%b %d,%Y %r'),'') AS  date_of_insertion, "
					+ " tbl_fb_profile_search.search_status, login_detail.user_logon_id, tbl_fb_profile_search.addToCrawler "
					+ " FROM tbl_fb_profile_search "
					+ " INNER JOIN tbl_crawl_avatar ON tbl_crawl_avatar.id=tbl_fb_profile_search.avatarId"
					+ " INNER JOIN login_detail ON login_detail.id=tbl_fb_profile_search.loginId  "
					+ " WHERE 1=1 "+subQuery +" LIMIT "+caseVo.getRowNum()+", 50";

			System.out.println("getFbUserAfterSearch : "+query);

			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for(Map<String,Object> rs : rows)
			{
				CaseVo caseVoObj=new CaseVo();
				caseVoObj.setId(rs.get("id")==null?"":rs.get("id").toString());
				caseVoObj.setKey1(rs.get("profileUrl")==null?"":rs.get("profileUrl").toString());
				caseVoObj.setKey2(rs.get("avatarName")==null?"":rs.get("avatarName").toString());
				caseVoObj.setKey3(rs.get("date_of_insertion")==null?"":rs.get("date_of_insertion").toString());
				caseVoObj.setKey4(rs.get("search_status")==null?"":rs.get("search_status").toString());
				caseVoObj.setKey9(rs.get("user_logon_id")==null?"":rs.get("user_logon_id").toString());
				caseVoObj.setKey10(rs.get("addToCrawler")==null?"":rs.get("addToCrawler").toString());
				list.add(caseVoObj);
			}
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		} 
		return list;
	}


	@Override
	public ArrayList<CaseVo> getFbUserListAfterSearch(CaseVo caseVo)
	{
		ArrayList<CaseVo> lst=new ArrayList<CaseVo>();
		try 
		{
			String subQuery="";
			if(caseVo.getId()!=null && !caseVo.getId().trim().isEmpty()) 
			{
				subQuery+=" and searchId='"+caseVo.getId()+"'";
			}

			if(caseVo.getKey1()!=null && !caseVo.getKey1().trim().isEmpty()) 
			{
				subQuery+=" and ( user_name like'%"+caseVo.getKey1()+"%' or tbl_fb_profile_search.profileUrl like'%"+caseVo.getKey1()+"%')";
			}

			String query=" SELECT tbl_fb_profile_search_result.id, tbl_fb_profile_search_result.searchId,"
					+ " COALESCE(DATE_FORMAT((date_of_search),'%b %d,%Y %r'),'') AS  date_of_search ,"
					+ " tbl_fb_profile_search_result.user_name, tbl_fb_profile_search_result.user_id, tbl_fb_profile_search_result.img, tbl_fb_profile_search_result.user_url, tbl_fb_profile_search_result.user_type,"
					+ " tbl_entity.entity_id,tbl_crawl_avatar.user_name as avatarId, tbl_entity.fb_delta as fbDelta"
					+ " from tbl_fb_profile_search_result"
					+ " INNER JOIN tbl_fb_profile_search ON tbl_fb_profile_search.id=tbl_fb_profile_search_result.searchId"
					+ " INNER JOIN tbl_crawl_avatar ON tbl_crawl_avatar.id=tbl_fb_profile_search.avatarId "
					+ " LEFT OUTER JOIN tbl_entity ON tbl_fb_profile_search_result.user_id= tbl_entity.entity_id "
					+ " where 1=1 " +subQuery;
			System.out.println("getFbUserListAfterSearch : "+query);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);

			for(Map<String, Object> rs : rows) 
			{
				CaseVo caseVoObj=new CaseVo();
				caseVoObj.setId(rs.get("id")==null?"":rs.get("id").toString());
				caseVoObj.setKey4(rs.get("searchId")==null?"":rs.get("searchId").toString());
				caseVoObj.setKey5(rs.get("date_of_search")==null?"":rs.get("date_of_search").toString());
				caseVoObj.setKey6(rs.get("user_name")==null?"":rs.get("user_name").toString());
				caseVoObj.setKey7(rs.get("user_id")==null?"":rs.get("user_id").toString());
				caseVoObj.setKey8(rs.get("img")==null?"":rs.get("img").toString());
				caseVoObj.setKey9(rs.get("user_url")==null?"":rs.get("user_url").toString());
				caseVoObj.setKey10(rs.get("user_type")==null?"":rs.get("user_type").toString());
				caseVoObj.setKey11(rs.get("entity_id")==null?"":rs.get("entity_id").toString());
				caseVoObj.setKey2(rs.get("avatarId")==null?"":rs.get("avatarId").toString());
				caseVoObj.setKey1(rs.get("fbDelta")==null?"":rs.get("fbDelta").toString());
				lst.add(caseVoObj);
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		} 
		return lst;
	}

	@Override
	public void deleteFbUserToSearch(CaseVo caseVo) 
	{
		try
		{
			String query=" delete from tbl_fb_profile_search where id=? " ;
			System.out.println("deleteFbUserToSearch :::"+query + caseVo.getId().trim());
			Object[] obj=new Object[]{caseVo.getId().trim()};
			jdbcTemplate.update(query,obj);

			query=" delete from tbl_fb_profile_search_result where searchId=? " ;
			System.out.println("deleteFbUserToSearch :::"+query + caseVo.getId().trim());
			obj=new Object[]{caseVo.getId().trim()};
			jdbcTemplate.update(query,obj);
		}
		catch(Exception ex) 
		{
			ex.printStackTrace();
		} 
	}


	@Override
	public void addFacebookProfileToCrawl(CaseVo caseVo) 
	{
		TransactionDefinition def = new DefaultTransactionDefinition();
		TransactionStatus status = transactionManager.getTransaction(def);
		 
		 try 
		 {
			 String query= " INSERT ignore into tbl_entity(entity_name, entity_id, entity_type, entity_source_type,"
					     + " entity_url, date_of_creation, entity_img, fbtype, fb_user_profile_url, fb_delta) values(?,?,?,?,?,?,?,?,?,?)" ;
			 
					  System.out.println("addFacebookProfileToCrawl query: "+query);
					  KeyHolder keyHolder = new GeneratedKeyHolder();
					  jdbcTemplate.update(new PreparedStatementCreator(){
					  public PreparedStatement createPreparedStatement(Connection connection) throws SQLException {
						    PreparedStatement ps = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
						    ps.setString(1, CommonUtils.removeSpaceFromTxt(caseVo.getKey1().trim()));
						    ps.setString(2, caseVo.getKey2().trim());
						    ps.setString(3, "P");
						    ps.setString(4, "fb");
						    ps.setString(5, caseVo.getKey3().trim());
						    ps.setString(6, CommonUtils.getSqlCurrentDateTime());
						    ps.setString(7, caseVo.getKey4().trim());
						    ps.setString(8, caseVo.getKey5().trim());
						    ps.setString(9, caseVo.getKey8().trim());
						    ps.setString(10, caseVo.getKey10().trim());
						    return ps;
					   }
					  }, keyHolder);

					   int crawlerAutogenertdId= keyHolder.getKey().intValue();
					   String fbType = caseVo.getKey5().trim();
					   System.out.println("fbType: "+fbType);
					  
					   String query1=" INSERT ignore into fb_crawl_sele_profile_status(entity_id, user_name, user_id)values(?,?,?)";
					   System.out.println(query1);   
					   Object[] obj=new Object[]{crawlerAutogenertdId, CommonUtils.removeSpaceFromTxt(caseVo.getKey1().trim()),caseVo.getKey2().trim()};
					   jdbcTemplate.update(query1,obj);

					   query1=" INSERT ignore into fb_account_profile_map(profile_id, account_id) values(?,?)";
					   System.out.println(query1);
					   obj=new Object[]{caseVo.getKey2().trim(), caseVo.getKey6().trim()};
					   jdbcTemplate.update(query1, obj);

					   //To Add entry of fb_user_id in fb_crawl_sele_profile_image_status table.
					   String fbUserId = caseVo.getKey2().trim();
					   String fbUserName=CommonUtils.removeSpaceFromTxt(caseVo.getKey1().trim());
					   String query3 = " INSERT IGNORE INTO fb_crawl_sele_profile_image_status(fb_user_id, fb_user_name, fbType) VALUES(?,?,?)";
					   System.out.println(query3);
					   obj=new Object[]{fbUserId, fbUserName, fbType};
					   jdbcTemplate.update(query3, obj);
					   
					   //To Add entry of fb_user_id in fb_crawl_sele_profile_image_FRS_status table.					   
					   String query4 = " INSERT IGNORE INTO fb_crawl_sele_profile_image_FRS_status(fb_user_id, fb_user_name, fbType) VALUES(?,?,?)";
					   System.out.println(query4);
					   obj=new Object[]{fbUserId, fbUserName, fbType};
					   jdbcTemplate.update(query4, obj);
					   
					   String query5 = " INSERT IGNORE INTO fb_crawl_sele_profile_image_download_data_status(fb_user_id, fb_user_name, fbType) VALUES(?,?,?)";
					   System.out.println(query5);
					   obj=new Object[]{fbUserId, fbUserName, fbType};
					   jdbcTemplate.update(query5, obj);
					  
					   transactionManager.commit(status);
					   System.out.println("entity_id: "+caseVo.getKey2().trim());
					   System.out.println("entity_name: "+CommonUtils.removeSpaceFromTxt(caseVo.getKey1().trim()));   
		 } 
		 catch(Exception ex) 
		 {
			 transactionManager.rollback(status);
			 ex.printStackTrace();
		 } 
	}

	@Override
	public void hideAndUpdareFbUserAddToCrawlerFlag(CaseVo caseVo) 
	{
		try 
		{
			String query=" UPDATE tbl_fb_profile_search SET addToCrawler='1' WHERE id='"+caseVo.getId().trim()+"' ";
			System.out.println("hideAndUpdareFbUserAddToCrawlerFlag : "+query);
			jdbcTemplate.update(query);
		} 
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
	}

	@Override
	public void showAndUpdareFbUserAddToCrawlerFlag(CaseVo caseVo)
	{
		try 
		{
			String query=" UPDATE tbl_fb_profile_search SET addToCrawler='0' WHERE id='"+caseVo.getId().trim()+"' ";
			System.out.println("showAndUpdareFbUserAddToCrawlerFlag : "+query);
			jdbcTemplate.update(query);
		} 
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
	}


    @Override
	public void entityCurd(CaseVo caseVo) 
    {		
		Object[] obj=null;
				
		try 
		{
			for(EntityVo entityVo : caseVo.getLstEntityVos())
			{							    
				try 
				{
				    if(entityVo.getEntitySourceType().trim().equals("Tg"))
				    {
				    	entityVo.setEntitySocialId(TwitterConstant.convertStringToMd5(entityVo.getEntitySocialId().toLowerCase().trim()));
				    }
				    
				    String queryMain= " INSERT ignore into tbl_entity(entity_name, entity_id, entity_stats, "
				    		         +" entity_type, entity_source_type, entity_url, date_of_creation, entity_img, "
				    		         +" tw_id, varifiedUserFlag, fbtype, yttype, twtype, profileCountryCode) "
				    		         +" values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)  "
				                     +" ON DUPLICATE KEY update activation_flag=1 " ;

				    System.out.println("Insert query========"+queryMain);
					System.out.println("entity_name========="+CommonUtils.removeSpaceFromTxt(entityVo.getEntityName().trim()));
					System.out.println("entitySocialId======"+entityVo.getEntitySocialId().trim());
					System.out.println("entity_type========="+entityVo.getEntityType().trim());
					System.out.println("entity_source_type=="+entityVo.getEntitySourceType().trim());
					System.out.println("entity_url=========="+entityVo.getEntityUrl().trim());
					System.out.println("date_of_creation===="+CommonUtils.getSqlCurrentDateTime());
					System.out.println("entity_img=========="+entityVo.getEntityImg().trim());
					System.out.println("tw_id==============="+entityVo.getTwId());
					System.out.println("varifiedUserFlag===="+entityVo.getVarifiedUserFlag());
					System.out.println("fbtype=============="+entityVo.getFbType());
					System.out.println("twtype=============="+entityVo.getTwType());
					System.out.println("yttype=============="+entityVo.getYtType());				
					System.out.println("profileCountryCode=="+entityVo.getProfileCountryId());
					
					KeyHolder keyHolder = new GeneratedKeyHolder();
					jdbcTemplate.update(new PreparedStatementCreator(){
						public PreparedStatement createPreparedStatement(Connection connection) throws SQLException 
						{
							PreparedStatement ps = connection.prepareStatement(queryMain, Statement.RETURN_GENERATED_KEYS);
							ps.setString(1, CommonUtils.removeSpaceFromTxt(entityVo.getEntityName().trim()));
							ps.setString(2, entityVo.getEntitySocialId().trim());							
							ps.setString(3, entityVo.getEntityStats().trim());
							ps.setString(4, entityVo.getEntityType().trim());
							ps.setString(5, entityVo.getEntitySourceType().trim());
							ps.setString(6, entityVo.getEntityUrl().trim());
							ps.setString(7, CommonUtils.getSqlCurrentDateTime());
							ps.setString(8, entityVo.getEntityImg().trim());
							ps.setString(9, entityVo.getTwId());
							ps.setString(10, entityVo.getVarifiedUserFlag().trim());
							ps.setString(11, entityVo.getFbType().trim());
							ps.setString(12, entityVo.getYtType().trim());
							ps.setString(13, entityVo.getTwType().trim());
							ps.setString(14, entityVo.getProfileCountryId());
							return ps;
						}
					}, keyHolder);					
					System.out.println("keyHolder.getKey()== "+keyHolder.getKey());
					
					if(keyHolder.getKey()==null)
					{
						System.out.println("AutoIncreament Key is Null so go for next element");
						continue;
					}
					int autoIncId = keyHolder.getKey().intValue();
					
					//For Insert User Logs
					String userLog="";
					if(entityVo.getEntityType().equals("K"))
					{
						userLog = "Add Keyword For Track: Keyword: "+entityVo.getEntityName()+ ", Source Type: "+entityVo.getEntitySourceType();
					}
					else if(entityVo.getEntityType().equals("P"))
					{
						userLog = "Add Profile For Track: User name: "+entityVo.getEntityName()+ ", User Id: "+entityVo.getEntitySocialId()+ ", Source Type: "+entityVo.getEntitySourceType();
					}
					else
					{
						userLog = "Add Location For Track: Location name: "+entityVo.getEntityName()+ ", Lat Long: "+entityVo.getEntitySocialId()+ ", Source Type: "+entityVo.getEntitySourceType();
					}			    			
					commonUtils.insertUserActivityLogs(userLog);

					System.out.println("Auto Incremented Id is::: "+autoIncId);
					if(autoIncId==0)
					{
						System.out.println("autoIncId is 0");
						continue;
					}
					
					String tweetUserId1="";
					String entityIdFb="0";
					String entityIdFbPageName="";
					String ytType="0", fbType="0";
					String entityUrl="";
					int entityId=0;
					
					if(autoIncId>0)
					{
						List<Map<String,Object>> rows = jdbcTemplate.queryForList("SELECT id, entity_id, tw_id, entity_name, ytType, fbType, entity_url from tbl_entity where id=?", new Object[]{autoIncId});
						for(Map<String,Object> rs :rows)
						{
							entityId=Integer.parseInt(rs.get("id").toString());
							tweetUserId1=rs.get("tw_id")==null?"":rs.get("tw_id").toString();
							entityIdFb=(rs.get("entity_id")==null?"":rs.get("entity_id").toString());
							entityIdFbPageName=(rs.get("entity_name")==null?"":rs.get("entity_name").toString());
							ytType=rs.get("ytType")==null?"0":rs.get("ytType").toString();
							fbType=rs.get("fbType")==null?"0":rs.get("fbType").toString();
							entityUrl=rs.get("entity_url")==null?"":rs.get("entity_url").toString();
						}

						System.out.println("entityId==========="+entityId);
						System.out.println("tweetUserId1======="+tweetUserId1);
						System.out.println("entityIdFb========="+entityIdFb);					
						System.out.println("entityIdFbPageName="+entityIdFbPageName);
						System.out.println("ytType============="+ytType);
						System.out.println("fbType============="+fbType);
						System.out.println("entityUrl=========="+entityUrl);
					}
					
					//Profile
					String catId = entityVo.getProfileCategoryId();		
					System.out.println("catId: "+catId);
					
					if(catId !=null)
					{
						String[] cat = catId.split(",");
						for(int i=0; i<cat.length; i++)
						{
							if(!cat[i].equals(""))
							{
								String insertQuery = " INSERT IGNORE INTO tbl_entity_profile_catagory(tbl_entity_id, profile_catagory_id) VALUES(?,?) ";
								obj=new Object[]{entityId, cat[i]};
								jdbcTemplate.update(insertQuery, obj);
								System.out.println("insertQuery: "+insertQuery);
							}																		
						}									
					}
					
					switch(entityVo.getEntitySourceType().trim().toLowerCase())
					{
					//Twitter
					case "tw":
						switch(entityVo.getEntityType().trim().toLowerCase())
						{
						case "p":
						    String query="INSERT ignore into twitter_extract_data(userId, type)values(?,?)";
							obj=new Object[]{tweetUserId1, "FW"};
							jdbcTemplate.update(query, obj);
							System.out.println("Twitter FW query: "+query);
							System.out.println("tweetUserId1="+tweetUserId1);
							System.out.println("FW");

							query="INSERT ignore into twitter_extract_data(userId, type)values(?,?)";
							obj=new Object[]{tweetUserId1, "FO"};
							jdbcTemplate.update(query, obj);
							System.out.println("Twitter FO query: "+query);
							System.out.println("tweetUserId1="+tweetUserId1);
							System.out.println("FO");

							query="INSERT ignore into twitter_extract_data(userId, type)values(?,?)";
							obj=new Object[]{tweetUserId1, "TW"};
							jdbcTemplate.update(query, obj);
							System.out.println("Twitter TW query: "+query);
							System.out.println("tweetUserId1="+tweetUserId1);
							System.out.println("TW");

							query="INSERT ignore into twitter_extract_data(userId, type)values(?,?)";
							obj=new Object[]{tweetUserId1, "FAV"};
							jdbcTemplate.update(query, obj);
							System.out.println("Twitter FAV query: "+query);
							System.out.println("tweetUserId1="+tweetUserId1);
							System.out.println("FAV");
							
							query="INSERT ignore into tw_profile_image_status(tw_user_id, tw_user_name, tw_user_screen_name) values(?,?,?)";
							obj=new Object[]{tweetUserId1, entityIdFbPageName, entityIdFb};
							jdbcTemplate.update(query, obj);
							System.out.println("tw_profile_image_status query: "+query);
							break;
						}
						break;
						
					//Facebook	
					case "fb":
						switch(entityVo.getEntityType().trim().toLowerCase())
						{
						case "k":
						    String query="INSERT ignore into fb_crawl_status_event(entity_id)values(?)";
							obj=new Object[]{entityId};
							jdbcTemplate.update(query, obj);

							System.out.println("Facebook keyword add:"+query);
							System.out.println("entityId: "+entityId);
							break;
						}
						break;

					//InstaGram
					case "insta":
						switch(entityVo.getEntityType().trim().toLowerCase())
						{
						case "p":
						    String query="INSERT ignore into insta_crawl_status(entity_id, profile_id, type, work_type, page_date)values(?,?,?,?,?)";
							obj=new Object[]{entityId, entityIdFb, "p", "post", TwitterConstant.GetInstaToCrawleDate()};
							jdbcTemplate.update(query, obj);
							System.out.println("post");

							query="INSERT ignore into insta_crawl_status(entity_id, profile_id, type, work_type, page_date)values(?,?,?,?,?)";
							obj=new Object[]{entityId, entityIdFb, "p", "fo", TwitterConstant.GetInstaToCrawleDate()};
							jdbcTemplate.update(query, obj);
							System.out.println("fo");

							query="INSERT ignore into insta_crawl_status(entity_id, profile_id, type, work_type, page_date)values(?,?,?,?,?)";
							obj=new Object[]{entityId, entityIdFb ,"p", "fw", TwitterConstant.GetInstaToCrawleDate()};
							jdbcTemplate.update(query, obj);
							System.out.println("fw");

							System.out.println("INSTA profile add:"+query);
							System.out.println("entityId="+entityId);
							System.out.println("ProfileId="+entityIdFb);
							break;
							
						case "k":
							query="INSERT ignore into insta_crawl_status(entity_id,profile_id,type,work_type,page_date)values(?,?,?,?,?)";
							obj=new Object[]{entityId, entityIdFbPageName, "k", "keyword", TwitterConstant.GetInstaToCrawleDate()};
							jdbcTemplate.update(query, obj);
							
							System.out.println("INSTA keyword add:"+query);
							System.out.println("entityId="+entityId);
							System.out.println("entityIdFbPageName="+entityIdFbPageName);
							break;
						}
						break;
						
					//Youtube
					case "yt":
						System.out.println("entity type=="+entityVo.getEntityType().toLowerCase());
					    String query="INSERT ignore into yt_crawl_status(entity_id, page_date, before_date, after_date)values(?,?,?,?)";
						System.out.println("YouTube before Date:: "+TwitterConstant.getYoutubeBeforeDateYYYYMMDD());
						System.out.println("YouTube after Date:: "+TwitterConstant.getYouTubeAfterDateYYYYMMDD());

						obj=new Object[]{entityId, TwitterConstant.GetInstaToCrawleDate(), TwitterConstant.getYoutubeBeforeDateYYYYMMDD(),TwitterConstant.getYouTubeAfterDateYYYYMMDD()};
						jdbcTemplate.update(query, obj);
						System.out.println("YOUTUBE add:"+query);
						break;

		
					//Google Blog
					case "gb":
						switch(entityVo.getEntityType().trim().toLowerCase())
						{
						case "p":
							query="INSERT ignore into gb_crawl_status(entity_id)values(?)";
							obj=new Object[]{entityId};
							jdbcTemplate.update(query,obj);
							System.out.println(query);
							break;
						}
						break;
											
						
					//Daily Motion
					case "dm":
						query="INSERT ignore into dm_crawl_status(entity_id, page_date)values(?,?)";
						obj=new Object[]{entityId, TwitterConstant.GetGpToCrawleDate()};
						jdbcTemplate.update(query, obj);
						System.out.println("Daily Motion query: "+query);
						break;

					//Rss Feed
					case "wb":
						switch(entityVo.getEntityType().trim().toLowerCase())
						{
						case "k":
							query="INSERT ignore into web_rss_crawl_status(entity_id,last_date_of_updation)values(?,?)";
							obj=new Object[]{entityId, TwitterConstant.GetNewsToCrawleDate()};
							jdbcTemplate.update(query,obj);
							System.out.println("Rss Feed query: "+query);
							break;
						}
						break;
										
					//WordPress
					case "wp":
						switch(entityVo.getEntityType().trim().toLowerCase())
						{
						case "k":
							query="INSERT ignore into wp_crawl_status(entity_id)values(?)";
							obj=new Object[]{entityId};
							jdbcTemplate.update(query,obj);
							System.out.println("WordPress query: "+query);
			                break;
						}
						break;
					
					//Google News
					case "google":
						switch(entityVo.getEntityType().trim().toLowerCase())
						{
						case "k":
							query="INSERT ignore into web_crawl_status(entity_id,last_date_of_updation)values(?,?)";
							obj=new Object[]{entityId, TwitterConstant.getSqlCurrentDateTime()};
							jdbcTemplate.update(query,obj);
							System.out.println(query);
			                break;
						}
						break;
					
					//Tumblr
					case "tm":
						query="INSERT ignore into tm_crawl_status(entity_id)values(?)";
						obj=new Object[]{entityId};
						jdbcTemplate.update(query,obj);
						System.out.println("Tumblr query: "+query);
						break;
					
					}		
		            //transactionManager.commit(status);
				} 
				catch(Exception ex)
				{
					ex.printStackTrace();
				}
			}					
		}
		catch(Exception ex) 
		{
			//transactionManager.rollback(status);
			ex.printStackTrace();
		} 
	}


	@Override
	public String deleteEntityInnsight(CaseVo caseVo) 
	{
		String result = "";
		TransactionDefinition def = new DefaultTransactionDefinition();
		TransactionStatus status = transactionManager.getTransaction(def);		
		try 
		{	
			String entityId = caseVo.getId().trim();
			//String entitySource = caseVo.getKey1().trim();
			//String entityType = caseVo.getKey2().trim();
			
			String selectQuery = " SELECT id, entity_name, entity_id, entity_type, entity_source_type, tw_id, fbtype, yttype, dmtype  "
					           + " FROM tbl_entity "
					           + " WHERE id="+entityId+" ";
			
			System.out.println("selectQuery: "+selectQuery);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(selectQuery);

			String tweetUserId="";
			String entitySocialId="";
			String entitySocialName="";
			String entityType="";
			String entitySourceType="";
			int entityTblId=0;
			
			for(Map<String,Object> rs : rows) 
			{			
				entityTblId=Integer.parseInt(rs.get("id").toString());
				tweetUserId=rs.get("tw_id")==null?"":rs.get("tw_id").toString();
				entitySocialId=(rs.get("entity_id")==null?"":rs.get("entity_id").toString());
				entitySocialName=(rs.get("entity_name")==null?"":rs.get("entity_name").toString());
				entityType=rs.get("entity_type")==null?"":rs.get("entity_type").toString();
				entitySourceType=rs.get("entity_source_type")==null?"":rs.get("entity_source_type").toString();								
			}
			
			System.out.println("entityTblId: "+entityTblId);
			System.out.println("entitySocialId: "+entitySocialId);
			System.out.println("entitySocialName: "+entitySocialName);
			System.out.println("tweetUserId: "+tweetUserId);
			System.out.println("entityType: "+entityType);
			System.out.println("entitySourceType: "+entitySourceType);
						
			String deleteQuery = "DELETE FROM tbl_entity WHERE id = "+entityId+" ";
			jdbcTemplate.update(deleteQuery);
			System.out.println("deleteQuery: "+deleteQuery);
			
			switch(entitySourceType.trim().toLowerCase()) 
			{
			   //Twitter
			   case "tw":	
				   if(entityType.equals("P")) 
				   {
					   deleteQuery = "DELETE FROM twitter_extract_data WHERE userId="+tweetUserId+" ";
					   jdbcTemplate.update(deleteQuery);
					   System.out.println("deleteQuery TW Profile: "+deleteQuery);					   
				   } 
				   else if(entityType.equals("L"))  {					   
				   } 
				   else if(entityType.equals("K")) {					   
				   }
			   break;
			   
			   //Facebook
			   case "fb":
				   if(entityType.equals("P"))
				   {
					   deleteQuery = "DELETE FROM fb_crawl_sele_profile_status WHERE entity_id="+entityId+" ";
					   jdbcTemplate.update(deleteQuery);
					   System.out.println("deleteQuery1 FB Profile: "+deleteQuery);
					   
					   deleteQuery = "DELETE FROM fb_crawl_sele_profile_image_status WHERE fb_user_id="+entitySocialId+" ";
					   jdbcTemplate.update(deleteQuery);
					   System.out.println("deleteQuery2 FB Profile: "+deleteQuery);
					   
					   deleteQuery = "DELETE FROM fb_crawl_sele_profile_image_FRS_status WHERE fb_user_id="+entitySocialId+" ";
					   jdbcTemplate.update(deleteQuery);
					   System.out.println("deleteQuery3 FB Profile: "+deleteQuery);
					   
					   deleteQuery = "DELETE FROM fb_crawl_sele_profile_image_download_data_status WHERE fb_user_id="+entitySocialId+" ";
					   jdbcTemplate.update(deleteQuery);
					   System.out.println("deleteQuery4 FB Profile: "+deleteQuery);
					   					   
					   deleteQuery = "DELETE FROM fb_account_profile_map WHERE profile_id="+entitySocialId+" ";
					   jdbcTemplate.update(deleteQuery);
					   System.out.println("deleteQuery5 FB Profile: "+deleteQuery);					   					   					   
				   } 
				   else if(entityType.equals("K"))
				   {
					   deleteQuery = "DELETE FROM fb_crawl_status_event WHERE entity_id="+entityId+" ";
					   jdbcTemplate.update(deleteQuery);
					   System.out.println("deleteQuery FB Keyword: "+deleteQuery);
				   }
			   break;
				
			   //Youtube
			   case "yt":
				   deleteQuery = "DELETE FROM yt_crawl_status WHERE entity_id="+entityId+" ";
				   jdbcTemplate.update(deleteQuery);
				   System.out.println("deleteQuery Youtube: "+deleteQuery);
			   break;
				
			 //Google News
			   case "google":
				   deleteQuery = "DELETE FROM web_crawl_status WHERE entity_id="+entityId+" ";
				   jdbcTemplate.update(deleteQuery);
				   System.out.println("deleteQuery Google News: "+deleteQuery);				  
			   break;
				
			   //Instagram
			   case "insta":
				   if(entityType.equals("P"))
				   {
					   deleteQuery = "DELETE FROM insta_crawl_status WHERE entity_id="+entityId+" ";
					   jdbcTemplate.update(deleteQuery);
					   System.out.println("deleteQuery Insta Profile: "+deleteQuery);
				   }
				   else if(entityType.equals("K"))
				   {
					   deleteQuery = "DELETE FROM insta_crawl_status WHERE entity_id="+entityId+" ";
					   jdbcTemplate.update(deleteQuery);
					   System.out.println("deleteQuery Insta Keyword: "+deleteQuery);
				   }
			   break;
			   
			   //Rss Feed   
			   case "wb":
				   if(entityType.equals("K"))
				   {
					   deleteQuery = "DELETE FROM web_rss_crawl_status WHERE entity_id="+entityId+" ";
					   jdbcTemplate.update(deleteQuery);
					   System.out.println("deleteQuery Web Rss: "+deleteQuery);
				   }				   
			   break;
				 
			   //Word Press 
			   case "wp":
				   if(entityType.equals("K"))
				   {
					   deleteQuery = "DELETE FROM wp_crawl_status WHERE entity_id="+entityId+" ";
					   jdbcTemplate.update(deleteQuery);
					   System.out.println("deleteQuery Web Rss: "+deleteQuery);
				   }
			   break;
				  
			
			   //Google Blog
			   case "gb":
				   if(entityType.equals("P"))
				   {
					   deleteQuery = "DELETE FROM gb_crawl_status WHERE entity_id="+entityId+" ";
					   jdbcTemplate.update(deleteQuery);
					   System.out.println("deleteQuery Google Blogs: "+deleteQuery);
				   }
			   break;
				
			   //Tumblr 
			   case "tm":
				   deleteQuery = "DELETE FROM tm_crawl_status WHERE entity_id="+entityId+" ";
				   jdbcTemplate.update(deleteQuery);
				   System.out.println("deleteQuery Web Rss: "+deleteQuery);
			   break;
			   			
				
			   //Daily Motion 
			   case "dm":
				   deleteQuery = "DELETE FROM dm_crawl_status WHERE entity_id="+entityId+" ";
				   jdbcTemplate.update(deleteQuery);
				   System.out.println("deleteQuery Daily Motion: "+deleteQuery);
			   break;
			   
			  		   			
			}
			result="success";
			transactionManager.commit(status);
		}
		catch(Exception ex) 
		{
			result="error";
			transactionManager.rollback(status);
			ex.printStackTrace();
		}
		return result;
	}

	
	@Override
	public String deleteMultipleEntityInnsight(CaseVo caseVo) 
	{
		String result = "";
		//TransactionDefinition def = new DefaultTransactionDefinition();
		//TransactionStatus status = transactionManager.getTransaction(def);	
		
		try 
		{	
			String id = caseVo.getId().trim();
			String [] entId = id.split(",");
			for(int i=0; i<entId.length; i++)
			{
				String entityId=entId[i];	
				System.out.println("entityId: "+entityId);
				String selectQuery = " SELECT id, entity_name, entity_id, entity_type, entity_source_type, tw_id, fbtype, yttype, dmtype "
				                   + " FROM tbl_entity "
				                   + " WHERE id="+entityId+" ";
				
				System.out.println("selectQuery: "+selectQuery);
				List<Map<String, Object>> rows = jdbcTemplate.queryForList(selectQuery);

				String tweetUserId="";
				String entitySocialId="";
				String entitySocialName="";
				String entityType="";
				String entitySourceType="";
				int entityTblId=0;				
				for(Map<String, Object> rs : rows) 
				{			
					entityTblId=Integer.parseInt(rs.get("id").toString());
					tweetUserId=rs.get("tw_id")==null?"":rs.get("tw_id").toString();
					entitySocialId=(rs.get("entity_id")==null?"":rs.get("entity_id").toString());
					entitySocialName=(rs.get("entity_name")==null?"":rs.get("entity_name").toString());
					entityType=rs.get("entity_type")==null?"":rs.get("entity_type").toString();
					entitySourceType=rs.get("entity_source_type")==null?"":rs.get("entity_source_type").toString();								
				}
				
				System.out.println("entityTblId: "+entityTblId);
				System.out.println("entitySocialId: "+entitySocialId);
				System.out.println("entitySocialName: "+entitySocialName);
				System.out.println("tweetUserId: "+tweetUserId);
				System.out.println("entityType: "+entityType);
				System.out.println("entitySourceType: "+entitySourceType);
							
				String deleteQuery = "DELETE FROM tbl_entity WHERE id = "+entityId+" ";
				jdbcTemplate.update(deleteQuery);
				System.out.println("deleteQuery: "+deleteQuery);
								
				switch(entitySourceType.trim().toLowerCase()) 
				{
				   //Twitter
				   case "tw":	
					   if(entityType.equals("P")) 
					   {
						   deleteQuery = "DELETE FROM twitter_extract_data WHERE userId="+tweetUserId+" ";
						   jdbcTemplate.update(deleteQuery);
						   System.out.println("deleteQuery TW Profile: "+deleteQuery);
						   System.out.println("------------------------------------------------------");
					   } 
					   else if(entityType.equals("L"))  {					   
					   } 
					   else if(entityType.equals("K")) {					   
					   }
				   break;
				   
				   //Facebook
				   case "fb":
					   if(entityType.equals("P"))
					   {
						   deleteQuery = "DELETE FROM fb_crawl_sele_profile_status WHERE entity_id="+entityId+" ";
						   jdbcTemplate.update(deleteQuery);
						   System.out.println("deleteQuery1 FB Profile: "+deleteQuery);
						   
						   deleteQuery = "DELETE FROM fb_crawl_sele_profile_image_status WHERE fb_user_id="+entitySocialId+" ";
						   jdbcTemplate.update(deleteQuery);
						   System.out.println("deleteQuery2 FB Profile: "+deleteQuery);
						   
						   deleteQuery = "DELETE FROM fb_crawl_sele_profile_image_FRS_status WHERE fb_user_id="+entitySocialId+" ";
						   jdbcTemplate.update(deleteQuery);
						   System.out.println("deleteQuery3 FB Profile: "+deleteQuery);
						   
						   deleteQuery = "DELETE FROM fb_crawl_sele_profile_image_download_data_status WHERE fb_user_id="+entitySocialId+" ";
						   jdbcTemplate.update(deleteQuery);
						   System.out.println("deleteQuery4 FB Profile: "+deleteQuery);
						   					   
						   deleteQuery = "DELETE FROM fb_account_profile_map WHERE profile_id="+entitySocialId+" ";
						   jdbcTemplate.update(deleteQuery);
						   System.out.println("deleteQuery5 FB Profile: "+deleteQuery);	
						   System.out.println("------------------------------------------------------");
						   
					   } 
					   else if(entityType.equals("K"))
					   {
						   deleteQuery = "DELETE FROM fb_crawl_status_event WHERE entity_id="+entityId+" ";
						   jdbcTemplate.update(deleteQuery);
						   System.out.println("deleteQuery FB Keyword: "+deleteQuery);
						   System.out.println("------------------------------------------------------");
					   }
				   break;
					
				   //Youtube
				   case "yt":
					   deleteQuery = "DELETE FROM yt_crawl_status WHERE entity_id="+entityId+" ";
					   jdbcTemplate.update(deleteQuery);
					   System.out.println("deleteQuery Youtube: "+deleteQuery);
					   System.out.println("------------------------------------------------------");
				   break;
				   
					
				 //Google News
				   case "google":
					   deleteQuery = "DELETE FROM web_crawl_status WHERE entity_id="+entityId+" ";
					   jdbcTemplate.update(deleteQuery);
					   System.out.println("deleteQuery Google News: "+deleteQuery);				  
				   break;
					
				   //Instagram
				   case "insta":
					   if(entityType.equals("P"))
					   {
						   deleteQuery = "DELETE FROM insta_crawl_status WHERE entity_id="+entityId+" ";
						   jdbcTemplate.update(deleteQuery);
						   System.out.println("deleteQuery Insta Profile: "+deleteQuery);
						   System.out.println("------------------------------------------------------");
					   }
					   else if(entityType.equals("K"))
					   {
						   deleteQuery = "DELETE FROM insta_crawl_status WHERE entity_id="+entityId+" ";
						   jdbcTemplate.update(deleteQuery);
						   System.out.println("deleteQuery Insta Keyword: "+deleteQuery);
						   System.out.println("------------------------------------------------------");
					   }
				   break;
				   
				   //Rss Feed   
				   case "wb":
					   if(entityType.equals("K"))
					   {
						   deleteQuery = "DELETE FROM web_rss_crawl_status WHERE entity_id="+entityId+" ";
						   jdbcTemplate.update(deleteQuery);
						   System.out.println("deleteQuery Web Rss: "+deleteQuery);
					   }				   
				   break;
					 
				   //Word Press 
				   case "wp":
					   if(entityType.equals("K"))
					   {
						   deleteQuery = "DELETE FROM wp_crawl_status WHERE entity_id="+entityId+" ";
						   jdbcTemplate.update(deleteQuery);
						   System.out.println("deleteQuery Wordpress: "+deleteQuery);
						   System.out.println("------------------------------------------------------");
					   }
				   break;
				
					
				   //Google Blog
				   case "gb":
					   if(entityType.equals("P"))
					   {
						   deleteQuery = "DELETE FROM gb_crawl_status WHERE entity_id="+entityId+" ";
						   jdbcTemplate.update(deleteQuery);
						   System.out.println("deleteQuery Google Blogs: "+deleteQuery);
					   }
				   break;
					
				   //Tumblr 
				   case "tm":
					   deleteQuery = "DELETE FROM tm_crawl_status WHERE entity_id="+entityId+" ";
					   jdbcTemplate.update(deleteQuery);
					   System.out.println("deleteQuery Tumblr: "+deleteQuery);
					   System.out.println("------------------------------------------------------");
				   break;
					
				   //Daily Motion 
				   case "dm":
					   deleteQuery = "DELETE FROM dm_crawl_status WHERE entity_id="+entityId+" ";
					   jdbcTemplate.update(deleteQuery);
					   System.out.println("deleteQuery Daily Motion: "+deleteQuery);
					   System.out.println("------------------------------------------------------");
				   break;
				   
				   			   			
				}
				result="success";
				//transactionManager.commit(status);
			}						
		}
		catch(Exception ex) 
		{
			result="error";
			ex.printStackTrace();
		}
		return result;
	}
	
	
	@Override
	public void addProfileCategory(CaseVo caseVo) 
	{
		try 
		{
			String query=" insert ignore into tbl_profile_catagory(profileCatagory)values(?)";
			System.out.println("addProfileCategory query: "+query);
			Object[] obj=new Object[]{
					caseVo.getKey1().trim()};
			jdbcTemplate.update(query, obj);
		} 
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}

	@Override
	public ArrayList<CaseVo> getCategory(CaseVo caseVo) {
		ArrayList<CaseVo> list=new ArrayList<CaseVo>();
		try {
			String selectQuery = " SELECT id, profileCatagory FROM tbl_profile_catagory ORDER BY id ASC ";
			System.out.println("selectQuery: "+selectQuery);			
			List<Map<String, Object>> rows = jdbcTemplate.queryForList(selectQuery);

			for(Map<String, Object> rs : rows)
			{
				CaseVo category = new CaseVo();								
				category.setCategoryId((Integer)(rs.get("id")));
				category.setCategoryName(rs.get("profileCatagory")==null?"":rs.get("profileCatagory").toString());			
				list.add(category);			
			}
		} 
		catch(Exception ex) 
		{
			ex.printStackTrace();
		}
		return list;
	}

	
	@Override
	public ArrayList<CaseVo> getCollectionCategory(CaseVo caseVo) {
		ArrayList<CaseVo> list=new ArrayList<CaseVo>();
		String sqlQuery = null;
		try {
			sqlQuery = " SELECT row_number, category FROM collection_category ORDER BY row_number ASC ";
			List<Map<String, Object>> rows = jdbcTemplate.queryForList(sqlQuery);

			for(Map<String, Object> rs : rows) {
				CaseVo category = new CaseVo();								
				category.setCategoryId((Integer)(rs.get("row_number")));
				category.setCategoryName(rs.get("category")==null?"":rs.get("category").toString());			
				list.add(category);			
			}
		} catch(Exception exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class getCollectionCategory() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class getCollectionCategory() :: EXCEPTION :: "+ exception);
		}
		return list;
	}
	
	@Override
	public ArrayList<CaseVo> getProfileCategoryDetaisInfo(CaseVo caseVo) {
		ArrayList<CaseVo> list=new ArrayList<CaseVo>();
		String sqlQuery = null;
		try {
			sqlQuery  = " SELECT tbl_profile_catagory.id, tbl_profile_catagory.profileCatagory, "
				           + " (SELECT COUNT(*) FROM  tbl_entity_profile_catagory "
				           + " WHERE tbl_entity_profile_catagory.profile_catagory_id=tbl_profile_catagory.id "
				           + " )AS profileCount "
				           + " FROM tbl_profile_catagory "
				           + " WHERE profileCatagory LIKE '%"+caseVo.getKey1()+"%' ORDER BY id ASC ";
		
			List<Map<String, Object>> rows = jdbcTemplate.queryForList(sqlQuery);
			for(Map<String, Object> rs : rows) {
				CaseVo category = new CaseVo();								
				category.setCategoryId((Integer)(rs.get("id")));
				category.setCategoryName(rs.get("profileCatagory")==null?"":rs.get("profileCatagory").toString());			
				category.setProfileMapCount((Long)rs.get("profileCount"));
				list.add(category);			
			}
		} catch(Exception exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class getProfileCategoryDetaisInfo() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class getProfileCategoryDetaisInfo() :: EXCEPTION :: "+ exception);
		}
		return list;
	}

	@Override
	public void editProfileCategory(CaseVo caseVo) {
		String sqlQuery = null;
		try  {
			sqlQuery =" UPDATE tbl_profile_catagory SET profileCatagory='"+caseVo.getCategoryName()+"' WHERE id="+caseVo.getCategoryId()+" ";
			jdbcTemplate.update(sqlQuery);
		} catch(Exception exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class editProfileCategory() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class editProfileCategory() :: EXCEPTION :: "+ exception);
		}
	}

	@Override
	public void deleteProfileCategory(CaseVo caseVo) {
		String sqlQuery = null;
		try {
			sqlQuery = "DELETE FROM tbl_profile_catagory WHERE id="+caseVo.getCategoryId()+" ";
			jdbcTemplate.update(sqlQuery);
		} catch(Exception exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class deleteProfileCategory() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class deleteProfileCategory() :: EXCEPTION :: "+ exception);
		}
	}

	@Override
	public ArrayList<CaseVo> totalProfileCategoryCount(CaseVo caseVo) {
		ArrayList<CaseVo> list=new ArrayList<CaseVo>();
		String sqlQuery = null;
		try {
			sqlQuery = " SELECT COUNT(*) AS profileCount FROM tbl_profile_catagory ";
			List<Map<String, Object>> rows = jdbcTemplate.queryForList(sqlQuery);
			for(Map<String, Object> rs : rows) {
				CaseVo category = new CaseVo();								
				category.setProfileMapCount((Long)rs.get("profileCount"));
				list.add(category);			
			}
		} catch(Exception exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class totalProfileCategoryCount() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class totalProfileCategoryCount() :: EXCEPTION :: "+ exception);
		}
		return list;
	}
	
	@Override
	public ArrayList<EntityVo> getProfileDetailsForEdit(CaseVo caseVo) {
		ArrayList<EntityVo> list = new ArrayList<EntityVo>();
		String sqlQuery = null;
		try {
			sqlQuery = " SELECT entity_name, entity_id, entity_source_type, entity_img, entity_img_local, "
					           + " GROUP_CONCAT(tbl_entity_profile_catagory.profile_catagory_id SEPARATOR ',') AS profileCatId, "
					           + " profileCountryCode, fb_delta "
					           + " FROM tbl_entity "
					           + " INNER JOIN tbl_entity_profile_catagory "
					           + " ON tbl_entity.id=tbl_entity_profile_catagory.tbl_entity_id "
					           + " WHERE tbl_entity.id = "+caseVo.getKey1()+" ";
			
			List<Map<String, Object>> rows = jdbcTemplate.queryForList(sqlQuery);
			for(Map<String, Object> rs : rows) {
				EntityVo entityVo = new EntityVo();								
				entityVo.setEntityName(rs.get("entity_name")==null?"":rs.get("entity_name").toString());
				entityVo.setEntitySocialId(rs.get("entity_id")==null?"":rs.get("entity_id").toString());
				entityVo.setEntitySourceType(rs.get("entity_source_type")==null?"":rs.get("entity_source_type").toString());
				entityVo.setEntityImg(rs.get("entity_img")==null?"":rs.get("entity_img").toString());
				entityVo.setEntityLocalImg(rs.get("entity_img_local")==null?"":rs.get("entity_img_local").toString());
				entityVo.setEntityStats(rs.get("profileCatId")==null?"":rs.get("profileCatId").toString());
				entityVo.setProfileCountryId(rs.get("profileCountryCode")==null?"":rs.get("profileCountryCode").toString());
				entityVo.setFbDelta(rs.get("fb_delta")==null?473040000:Integer.parseInt(rs.get("fb_delta").toString()));				
				list.add(entityVo);			
			}			
		} catch(Exception exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class getProfileDetailsForEdit() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class getProfileDetailsForEdit() :: EXCEPTION :: "+ exception);
		}
		return list;
	}

	@Override
	public void editProCategoryMap(EntityVo entityVo) {
		TransactionDefinition def = new DefaultTransactionDefinition();
		TransactionStatus status = transactionManager.getTransaction(def);
		String sqlQuery = null;
		Object[] obj=null;
		try {
			String entityId =entityVo.getId();
			sqlQuery =" DELETE FROM tbl_entity_profile_catagory WHERE tbl_entity_id='"+entityId+"' ";
			jdbcTemplate.update(sqlQuery);
			
			String catId = entityVo.getProfileCategoryId();					
			if(catId != "" && catId != null) {
				String[] cat = catId.split(",");
				for(int i=0; i<cat.length; i++) {
					if(!cat[i].equals("")) {
						String insertQuery = " INSERT IGNORE INTO tbl_entity_profile_catagory(tbl_entity_id, profile_catagory_id) VALUES(?,?) ";
						obj=new Object[]{entityId, cat[i]};
						jdbcTemplate.update(insertQuery, obj);
					}																		
				}
			}
			transactionManager.commit(status);
		} catch(Exception exception) {
			transactionManager.rollback(status);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class editProCategoryMap() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class editProCategoryMap() :: EXCEPTION :: "+ exception);
		}
	}
	
	@Override
	public void editProfileCountryCode(EntityVo entityVo) {		
		String sqlQuery = null;
		try {
			sqlQuery = "UPDATE tbl_entity SET fb_delta='"+entityVo.getFbDelta()+"', profileCountryCode= '"+entityVo.getProfileCountryId()+"' WHERE id="+entityVo.getId()+" AND entity_type='P' ";
			jdbcTemplate.update(sqlQuery);
		} catch(Exception exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class editProfileCountryCode() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class editProfileCountryCode() :: EXCEPTION :: "+ exception);
		}
	}
	
	//#################################################### Report #######################################################################
	
	public ArrayList<UserProfileBasicInformationVo> getTargetUserProfileBasicInfo(UserProfileBasicInformationVo basicInformationVo) {
		ArrayList<UserProfileBasicInformationVo> userList = new ArrayList<UserProfileBasicInformationVo>();
		String sqlQuery = null;
		try {
			sqlQuery = " SELECT id, first_name, last_name, profile_photo_id, profile_cover_photo_id, "
					+ " (SELECT photo_path FROM tbl_profile_user_photo WHERE tbl_profile_user_photo.id=tbl_profile.profile_photo_id) AS profilePhoto, "
					+ " (SELECT photo_path FROM tbl_profile_user_photo WHERE tbl_profile_user_photo.id=tbl_profile.profile_cover_photo_id) AS coverPhoto, "
					+ " permanent_address, local_address, "
					+ " father_name, mother_name, dob, gender, nationality, martial_status, addahar_card, "
					+ " pan_card, passport_no, description, classification, (SELECT GROUP_CONCAT(alias) FROM tbl_profile_alias WHERE tbl_profile_alias.profile_id=tbl_profile.id) as alias "
					+ " FROM tbl_profile where id = '"+basicInformationVo.getProfileId()+"'";
			
			List<Map<String, Object>> rows = jdbcTemplate.queryForList(sqlQuery);
			for(Map<String, Object> rs : rows) {
				UserProfileBasicInformationVo user = new UserProfileBasicInformationVo();
				user.setProfileId((Integer)(rs.get("id")));
				user.setFirstName((String)(rs.get("first_name")));
				user.setLastName((String)(rs.get("last_name")));
				user.setProfilePhotoId((Integer)(rs.get("profile_photo_id")));
				user.setProfileCoverPhotoId((Integer)(rs.get("profile_cover_photo_id")));			

				if(rs.get("profilePhoto")!=null) {
					String path = TwitterConstant.getPersonProfile();
					String finalPath = path.substring(path.indexOf("ROOT")+4);
					user.setProfilePhoto(finalPath+"/"+(String)rs.get("profilePhoto"));
				} else {
					user.setProfilePhoto(null);
				}	

				if(rs.get("coverPhoto")!=null) {
					String path = TwitterConstant.getPersonProfile();
					String finalPath = path.substring(path.indexOf("ROOT")+4);
					user.setCoverPhoto(finalPath+"/"+(String)rs.get("coverPhoto"));
				} else {
					user.setCoverPhoto(null);
				}

				user.setPermanentAddress((String)(rs.get("permanent_address")));
				user.setLocalAddress((String)(rs.get("local_address")));
				user.setFatherName((String)(rs.get("father_name")));
				user.setMotherName((String)(rs.get("mother_name")));
				user.setDob((String)(rs.get("dob")));
				user.setGender((String)(rs.get("gender")));
				user.setNationality((String)(rs.get("nationality")));
				user.setMartialStatus((String)(rs.get("martial_status")));
				user.setAddaharCard((String)(rs.get("addahar_card")));
				user.setPanCard((String)(rs.get("pan_card")));
				user.setPassportNo((String)(rs.get("passport_no")));
				user.setDescription((String)(rs.get("description")));
				user.setClassification((String)(rs.get("classification")));
				user.setAlias(rs.get("alias")==null?"":rs.get("alias").toString());
				userList.add(user);
			}			
		} catch(Exception exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class getTargetUserProfileBasicInfo() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class getTargetUserProfileBasicInfo() :: EXCEPTION :: "+ exception);
		}
		
		return userList;
	}

	@Override
	public ArrayList<CaseVo> checkFbProAddedValue(CaseVo caseVo) {
		ArrayList<CaseVo> lst=new ArrayList<CaseVo>();
		String sqlQuery = null;
		try {
			sqlQuery ="SELECT * FROM tbl_fb_profile_search WHERE profileUrl ='"+caseVo.getKey1()+"'";
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(sqlQuery);
			for(Map<String,Object> rs : rows) {
				CaseVo caseVoObj=new CaseVo();
				caseVoObj.setKey1(rs.get("profileUrl")==null?"":rs.get("profileUrl").toString());
				lst.add(caseVoObj);
			}
		} catch (Exception exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class checkFbProAddedValue() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class checkFbProAddedValue() :: EXCEPTION :: "+ exception);
		} 
		return lst;
	}

	@Override
	public ArrayList<ProfileFinderResult> srchFbProfileByMobileEmail(EntityVo fbPage) {
		ArrayList<ProfileFinderResult> profileFinderResultList = new ArrayList<ProfileFinderResult>();
		String sqlQuery = null;
		try {
			sqlQuery = "Select * from tbl_profile_finder_result where keyword = '"+fbPage.getSearchText()+"' and country_code='"+fbPage.getCountryCode()+"'";
			List<Map<String, Object>> rows = jdbcTemplate.queryForList(sqlQuery);
			for(Map<String, Object> row : rows) {
				ProfileFinderResult profileFinderResult = new ProfileFinderResult();
				profileFinderResult.setId(row.get("id")==null?0:Integer.parseInt(row.get("id").toString()));
				profileFinderResult.setKeyword(row.get("keyword")==null?"":row.get("keyword").toString());
				profileFinderResult.setProfileName(row.get("profile_name")==null?"":row.get("profile_name").toString());
				profileFinderResult.setProfileId(row.get("profile_id")==null?"":row.get("profile_id").toString());
				profileFinderResult.setImage(row.get("image")==null?"":row.get("image").toString());
				profileFinderResult.setSourceType(row.get("source_type")==null?"":row.get("source_type").toString());
				profileFinderResult.setNewProfile(row.get("new_profile")==null?0:Integer.parseInt(row.get("new_profile").toString()));
				profileFinderResult.setResultDate(row.get("result_date")==null?"":row.get("result_date").toString());
				profileFinderResult.setProfileHandler(row.get("profile_handler")==null?"":row.get("profile_handler").toString());
				profileFinderResult.setDescription(row.get("description")==null?"":row.get("description").toString());
				profileFinderResult.setJobProfile(row.get("job_profile")==null?"":row.get("job_profile").toString());
				profileFinderResult.setProfileLocation(row.get("profile_location")==null?"":row.get("profile_location").toString());
				profileFinderResultList.add(profileFinderResult);
			}
		} catch(Exception exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class srchFbProfileByMobileEmail() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class srchFbProfileByMobileEmail() :: EXCEPTION :: "+ exception);
		}
		return profileFinderResultList;
	}

	@Override
	public void saveFbUserMobileEmail(CaseVo caseVo) {
		String sqlQuery = null;
		try {
			if(caseVo.getId().equals("0")){
				sqlQuery =" insert ignore into tbl_profile_finder(keyword, country_code, type, source_type, search_status, insertion_date) values(?,?,?,'skype','0',now())";
				Object[] obj=new Object[]{caseVo.getKeyword().trim(), caseVo.getCountryCode(), caseVo.getCaseType()};
				jdbcTemplate.update(sqlQuery, obj);
				
				sqlQuery="insert ignore into tbl_profile_finder(keyword, country_code, type, source_type, search_status, insertion_date) values(?,?,?,'truecaller','0',now())";
				obj=new Object[]{caseVo.getKeyword().trim(), caseVo.getCountryCode(), caseVo.getCaseType()};
				jdbcTemplate.update(sqlQuery, obj);
				
				sqlQuery="insert ignore into tbl_profile_finder(keyword, country_code, type, source_type, search_status, insertion_date) values(?,?,?,'facebook','0',now())";
				obj=new Object[]{caseVo.getKeyword().trim(), caseVo.getCountryCode(), caseVo.getCaseType()};
				jdbcTemplate.update(sqlQuery, obj);
			} else {
				sqlQuery ="update tbl_profile_finder set search_status='0', country_code='"+caseVo.getCountryCode()+"' where keyword='"+caseVo.getKeyword().trim()+"'";
				jdbcTemplate.execute(sqlQuery);
			}
		} catch(DataAccessException exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class saveFbUserMobileEmail() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class saveFbUserMobileEmail() :: EXCEPTION :: "+ exception);
		}
	}

	@Override
	public void mobileEmailDelete(CaseVo caseVo) {
		String sqlQuery = null;
		try {
			sqlQuery = "Delete from tbl_profile_finder_result where id= '"+caseVo.getId()+"'";
			jdbcTemplate.update(sqlQuery);
		}catch (Exception exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class getFinderNewResults() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class getFinderNewResults() :: EXCEPTION :: "+ exception);
		} 
	}

	@Override
	public ArrayList<ProfileFinderResult> getFinderNewResults() {
		ArrayList<ProfileFinderResult> profileFinderResults = new ArrayList<ProfileFinderResult>();
		String sqlQuery = null;
		try {
			sqlQuery = "SELECT * from tbl_profile_finder_result where new_profile='1'";
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(sqlQuery);
			for(Map<String,Object> rs : rows){
				ProfileFinderResult profileFinderResult = new ProfileFinderResult();
				profileFinderResult.setKeyword(rs.get("keyword")==null?"":rs.get("keyword").toString());
				profileFinderResult.setProfileName(rs.get("profile_name")==null?"":rs.get("profile_name").toString());
				profileFinderResult.setProfileId(rs.get("profile_id")==null?"":rs.get("profile_id").toString());
				profileFinderResult.setImage(rs.get("image")==null?"":rs.get("image").toString());
				profileFinderResult.setSourceType(rs.get("source_type")==null?"":rs.get("source_type").toString());
				profileFinderResults.add(profileFinderResult);
			}
		} catch (Exception exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class getFinderNewResults() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class getFinderNewResults() :: EXCEPTION :: "+ exception);
		}
		return profileFinderResults;
	}


	@Override
	public void updateFinderNewResultStatus() {
		String sqlQuery = null;
		try {
			sqlQuery ="update tbl_profile_finder_result set new_profile='0'";
			jdbcTemplate.execute(sqlQuery);
		} catch(Exception exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class updateFinderNewResultStatus() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class updateFinderNewResultStatus() :: EXCEPTION :: "+ exception);
		}
	}

	@Override
	public boolean entityNewCurd(CaseVo caseVo) {
		boolean isInserted = false;
    	TransactionDefinition def = new DefaultTransactionDefinition();
		TransactionStatus status = transactionManager.getTransaction(def);
		try	{
			for(EntityVo entityVo : caseVo.getLstEntityVos()) {				
				String queryMain= " INSERT ignore into tbl_entity(entity_name, entity_id, entity_type, "
						        + " entity_source_type, entity_url, date_of_creation, entity_img, twtype, "
						        + " latitude, longitude, radius, place_name) "
						        + " values(?,?,?,?,?,?,?,?,?,?,?,?) "
						        + " ON DUPLICATE KEY update activation_flag=1";
				
				KeyHolder keyHolder = new GeneratedKeyHolder();
				jdbcTemplate.update(new PreparedStatementCreator() {
					public PreparedStatement createPreparedStatement(Connection connection) throws SQLException {
						PreparedStatement ps = connection.prepareStatement(queryMain, Statement.RETURN_GENERATED_KEYS);
						ps.setString(1, CommonUtils.removeSpaceFromTxt(entityVo.getEntityName().trim()));
						ps.setString(2, entityVo.getEntitySocialId().trim());
						ps.setString(3, entityVo.getEntityType().trim());
						ps.setString(4, entityVo.getEntitySourceType().trim());
						ps.setString(5, entityVo.getEntityUrl().trim());
						ps.setString(6, CommonUtils.getSqlCurrentDateTime());
						ps.setString(7, entityVo.getEntityImg().trim());
						ps.setString(8, entityVo.getTwType().trim());
						ps.setString(9, entityVo.getLatitude());
						ps.setString(10, entityVo.getLongitude());
						ps.setString(11, entityVo.getRadius());
						ps.setString(12, entityVo.getPlaceName());
						return ps;
					}
				}, keyHolder);
				
				if(keyHolder != null && keyHolder.getKey() != null) {
					int autoIncId = keyHolder.getKey().intValue();
					String userLog = "Track Twitter Keyword With Location, Keyword: "+entityVo.getEntityName()+ ", Latitude: "+entityVo.getLatitude()+ ", Longitude: "+entityVo.getLongitude()+ ", Radius: "+entityVo.getRadius();						
					commonUtils.insertUserActivityLogs(userLog);
					
					if(autoIncId > 0) {
						isInserted = true;
					}
				} else {
					logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class entityNewCurd() :: Duplicate Record Not Inserted.");
				}
			}
			transactionManager.commit(status);
		} catch(Exception exception) {
			transactionManager.rollback(status);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class entityNewCurd() :: EXCEPTION :: "+ exception);
		}
		return isInserted;		
	}
	
	@Override
	public ArrayList<UserProfilePhotoVo> getImagesForProfileId(UserProfilePhotoVo userProfilePhotoVo) {
		ArrayList<UserProfilePhotoVo> userProfilePhotoVoList = new ArrayList<UserProfilePhotoVo>();
		String sqlQuery = null;
		try {
			sqlQuery = "select * from tbl_suspect_profile_photo where profile_id = "+userProfilePhotoVo.getProfileId();
			List<Map<String, Object>> rows = jdbcTemplate.queryForList(sqlQuery);
			for(Map<String, Object> row : rows) {
				UserProfilePhotoVo userProfilePhotoVo1 = new UserProfilePhotoVo();
				userProfilePhotoVo1.setPhotoId(Integer.parseInt(row.get("id").toString()));
				userProfilePhotoVo1.setPhotoPath(TwitterConstant.getSuspectPhotosRender()+row.get("uuid").toString());
				userProfilePhotoVoList.add(userProfilePhotoVo1);
			}
		} catch(Exception exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class getImagesForProfileId() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class getImagesForProfileId() :: EXCEPTION :: "+ exception);
		}		
		return userProfilePhotoVoList;
	}

	@SuppressWarnings("unused")
	@Override
	public boolean deleteSuspectPhoto(UserProfilePhotoVo userProfilePhotoVo) {
		boolean status = false;
		String  sqlQuery = null;
		if(userProfilePhotoVo.getPhotoId() != 0) {
			try {
				sqlQuery = "select * from tbl_suspect_profile_photo where id = "+userProfilePhotoVo.getPhotoId();
				Map<String, Object> row = jdbcTemplate.queryForList(sqlQuery).get(0);
				if(row.get("id")!=null) {
					File file = new File(TwitterConstant.getSuspectPhotos()+"/"+row.get("uuid").toString());
				}
			}
			catch(Exception exception) {
				logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class deleteSuspectPhoto() :: EXCEPTION :: "+ exception);
			}
			
			try {
				sqlQuery=" delete from tbl_suspect_profile_photo where id=?";
				Object[] obj=new Object[]{userProfilePhotoVo.getPhotoId()};
				jdbcTemplate.update(sqlQuery, obj);
				status = true;
			} catch (Exception exception) {
				logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class deleteSuspectPhoto() :: EXCEPTION :: "+ exception);
			}
		} else {
			try {
				sqlQuery = "select * from tbl_suspect_profile_photo where profile_id = "+userProfilePhotoVo.getProfileId();
				List<Map<String, Object>> rows = jdbcTemplate.queryForList(sqlQuery);
				for(Map<String, Object> row : rows)	{
					File file = new File(TwitterConstant.getSuspectPhotos()+"/"+row.get("uuid").toString());
				}
			} catch(Exception exception) {
				logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class deleteSuspectPhoto() :: EXCEPTION :: "+ exception);
			}
			
			try {
				sqlQuery ="	delete from tbl_suspect_profile_photo where profile_id=?";
				Object[] obj=new Object[]{userProfilePhotoVo.getProfileId()};
				jdbcTemplate.update(sqlQuery, obj);
				status = true;
			} 
			catch (Exception exception) {
				logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class deleteSuspectPhoto() :: EXCEPTION :: SQL :: "+ sqlQuery);
				logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class deleteSuspectPhoto() :: EXCEPTION :: "+ exception);
			}
		}
		return status;
	}
	
	
	/************************get All Login_detail Users  ***************************/
	@Override
	public ArrayList<CaseVo> getAllLoginUsers(CaseVo caseVo) {
		ArrayList<CaseVo> lst=new ArrayList<CaseVo>();
		String sqlQuery = null;
		try {
			sqlQuery = "select * from login_detail ORDER BY user_logon_id ASC";
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(sqlQuery);
			for(Map<String,Object> rs : rows) {
				CaseVo caseVoObj=new CaseVo();
				caseVoObj.setId(rs.get("id")==null?"":rs.get("id").toString());
				caseVoObj.setKey1(rs.get("user_logon_id")==null?"":rs.get("user_logon_id").toString());
				lst.add(caseVoObj);
			}
		} catch (DataAccessException exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class getAllLoginUsers() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class getAllLoginUsers() :: EXCEPTION :: "+ exception);
		}
		return lst;
	}

	/************************get User Logs from Es  ***************************/
	@SuppressWarnings("deprecation")
	@Override
	public ArrayList<CaseVo> getUserLogsEs(CaseVo caseVo) {
		ArrayList<CaseVo> list=new ArrayList<CaseVo>();
		try {
			String subquery="";
			String sortfilter="";
			String userFilter="";
			String dateFilter="";
			Long dateFrom=0L, dateTo=0L;
			
			String docCount=caseVo.getNoTweet();
			dateFrom=TwitterConstant.convertDateToTimeStamp(caseVo.getDateFrom());
			dateTo=TwitterConstant.convertDateToTimeStamp(caseVo.getDateTo());
			
			dateFilter=	",{\n"+
					"\"range\": {\n"+
					"\"logDate\": {\n"+
					"\"gte\": "+dateFrom+",\n"+
					"\"lte\": "+dateTo+"\n"+
					"}\n"+
					"}\n"+ 
					"}\n";
			
			if(caseVo.getSort().equals("newest")){
				sortfilter="desc";
			} else {
				sortfilter="asc";
			}
			
			if(caseVo.getKeyword()!=null && !caseVo.getKeyword().equals("")) {
				subquery=",{\n"+
						 "\"query_string\": {\n"+
						 "\"default_field\":\"activity\"\n,"+
						 "\"query\": \""+caseVo.getKeyword()+"\"\n"+
						 "}\n"+
						 "}\n";
			}
			
			if(caseVo.getId()!=null && !caseVo.getId().equals("")) {
				userFilter=" ,{\n"+
						 "\"term\": {\n"+
						 "\"loginId\":" +caseVo.getId()+"\n"+
						 " }\n"+
						 " }\n";
			}
			
			String userQuery = "{\n"+
					 "\"size\": \""+docCount+"\",\n"+
					 "\"query\": {\n"+
					 "\"bool\": {\n"+
					 "\"must\": [\n"+
					 "{}"+
					 
					 dateFilter+
					 subquery+
					 userFilter+
					 
					 "  ]\n"+
					 " }\n"+
					 "},\n"+
					 "\"sort\": [\n"+
					 "{\n"+
					 "\"logDate\": {\n"+
					 "\"order\": \""+sortfilter+"\"\n"+
					 " }\n"+
					 "}\n"+
					 " ]\n"+
					 "}";
			
			Search search = new Search.Builder(userQuery).addIndex("innsight_log").addType("log").build();
			
			SearchResult result = client.execute(search);
			List<Innsight_Log> testLst = result.getSourceAsObjectList(Innsight_Log.class);
			for(Innsight_Log innsight_Log : testLst) {
				CaseVo caseVo1=new CaseVo();
				caseVo1.setId(innsight_Log.getLoginId());
				caseVo1.setInsertedDate(CommonUtils.convertUnixTimeToDateDisplayFormat(innsight_Log.getLogDate()));
				caseVo1.setLogText(innsight_Log.getActivity());
				caseVo1.setUser(innsight_Log.getLoginUserName());
				list.add(caseVo1);
			}
		} catch(DataAccessException | IOException exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class updateProfileFinderMobileDeviceHealthStatus() :: EXCEPTION :: "+ exception);
		}
		return list;
	}

	@Override
	public boolean updateProfileFinderMobileDeviceHealthStatus() {
		boolean status = false;
		String sqlQuery = null;
		try {
			sqlQuery = "Select * from tbl_profile_finder_device";
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(sqlQuery);
			
			for(Map<String,Object> rs : rows) {
				long updatedTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(rs.get("updated_date").toString()).getTime();
				long currentTime = new Date().getTime();
				int DiffInMinutes = (int) ((currentTime - updatedTime) / (60 * 1000) % 60);
				if(DiffInMinutes < 5) {
					status = true;
				}
			}
		} catch (Exception exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class updateProfileFinderMobileDeviceHealthStatus() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class updateProfileFinderMobileDeviceHealthStatus() :: EXCEPTION :: "+ exception);
		}
		return status;
	}

	@Override
	public boolean checkLoginUserAccount(LoginDetails loginDetails) {
		boolean result=false;
		String sqlQuery = null;
		try	{
			sqlQuery = "SELECT * FROM login_detail WHERE user_logon_id='"+loginDetails.getUserName()+"' ";
			if(loginDetails.getFilter() != null && loginDetails.getFilter().equals("1")) {
				result = jdbcTemplate.queryForList(sqlQuery).size() == 0 ? false : true;
			} else {
				result = jdbcTemplate.queryForList(sqlQuery).size() == 1 ? false : true;
			}
		} catch(Exception exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class checkLoginUserAccount() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class checkLoginUserAccount() :: EXCEPTION :: "+ exception);
		}
		return result;
	}

	@Override
	public CaseVo searchLatLonFromES(CaseVo caseVo) {
		try {
			String location = caseVo.getCaseName();
			location = location.replaceAll("[-()?:!.;{}@~#$%^&*/+\"\\\\]", " ");
			location = location.toLowerCase().trim();
			location = location.replace("[", " ").replace("]", " ").replace("\n", " ").replace("\t", " ");
		
			if(location != null && location.length() > 0) {
				String query = "{\r\n" + 
						" \"size\": 1,\r\n" + 
						"  \"query\": {\r\n" + 
						"    \"query_string\": {\r\n" + 
						"      \"default_field\": \"display_name\",\r\n" + 
						"      \"query\": \""+location+"\"\r\n" + 
						//"      \"minimum_should_match\": 2\r\n" + 
						"    }\r\n" + 
						"  }\r\n" + 
						"}";
				Search search = new Search.Builder(query).addIndex("location_db").addType("location_data_collection").build();
				SearchResult result = client.execute(search);
				String response =  result.getSourceAsString();
				
				if(response != null && response.length() > 0) {
					JSONObject jsonObject = new JSONObject(response);
					String lat = jsonObject.getString("lat");
					String lon = jsonObject.getString("lon");
					String displayName = jsonObject.getString("display_name");
					caseVo.setKey1(lat);
					caseVo.setKey2(lon);
					caseVo.setKey3(displayName);					
				}
			} else {
				logger.error(CommonUtils.getCurrentTime()+" Location is not valid or empty.");
			}					
		}
		catch(Exception exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class searchLatLonFromES() :: EXCEPTION :: "+ exception);
		}
		return caseVo;
	}

	@Override
	public boolean checkUserCreationLimit(CaseVo caseVo) {
		boolean result=false;
		String sqlQuery = null;
		try {
			sqlQuery = "SELECT * FROM login_detail";   // WHERE created_by='"+caseVo.getId()+"' and role = 'U'";
			result = Integer.parseInt(TwitterConstant.getUserCreationLimit()) > jdbcTemplate.queryForList(sqlQuery).size() ? true : false;
		} 
		catch(Exception exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class checkUserCreationLimit() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class checkUserCreationLimit() :: EXCEPTION :: "+ exception);
		}
		return result;
	}

	@Override
	public ArrayList<String> blacklistKeywords() {
		ArrayList<String> blacklistKeywords = new ArrayList<String>();
		String sqlQuery = null;
		try {
			sqlQuery = "SELECT * FROM tbl_wordcloud";
			List<Map<String, Object>> rows = jdbcTemplate.queryForList(sqlQuery);
			for(Map<String, Object> row : rows)	{
				blacklistKeywords.add(row.get("keyword")==null?"":row.get("keyword").toString());
			}			
		}
		catch(Exception exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class blacklistKeywords() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class blacklistKeywords() :: EXCEPTION :: "+ exception);
		}
		return blacklistKeywords;
	}

	@Override
	public boolean saveNerToWordCloud(CaseVo caseVo){		
		boolean status = false;
		String sqlQuery = null;
		try {
			sqlQuery="INSERT ignore into tbl_wordcloud(keyword) values(?)";
			Object[] obj=new Object[]{caseVo.getKey1().trim()};
			jdbcTemplate.update(sqlQuery, obj);
			status = true;
		}
		catch(Exception exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class saveNerToWordCloud() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class saveNerToWordCloud() :: EXCEPTION :: "+ exception);
		}		
		return status;
	}

	@Override
	public HashMap<String, ArrayList<String>> nerIgnoreKeywords() {
		HashMap<String, ArrayList<String>> nerIgnoreKeywords = new HashMap<String, ArrayList<String>>();
		String sqlQuery = null;
		try {
			sqlQuery = "SELECT * FROM tbl_ner_ignore";
			List<Map<String, Object>> rows = jdbcTemplate.queryForList(sqlQuery);
			
			ArrayList<String> persons = new ArrayList<String>();
			ArrayList<String> places = new ArrayList<String>();
			ArrayList<String> organizations = new ArrayList<String>();
			ArrayList<String> themes = new ArrayList<String>();
			
			for(Map<String, Object> row : rows)	{
				String type = row.get("type")==null?"":row.get("type").toString();
				if(type.length() > 0 && type.equalsIgnoreCase("P"))	{
					persons.add(row.get("keyword")==null?"":row.get("keyword").toString());
				} else if(type.length() > 0 && type.equalsIgnoreCase("L")) {
					places.add(row.get("keyword")==null?"":row.get("keyword").toString());
				} else if(type.length() > 0 && type.equalsIgnoreCase("O")) {
					organizations.add(row.get("keyword")==null?"":row.get("keyword").toString());
				} else if(type.length() > 0 && type.equalsIgnoreCase("T")) {
					themes.add(row.get("keyword")==null?"":row.get("keyword").toString());
				}
			}
			
			nerIgnoreKeywords.put("persons", persons);
			nerIgnoreKeywords.put("places", places);
			nerIgnoreKeywords.put("organizations", organizations);
			nerIgnoreKeywords.put("themes", themes);
		} catch(Exception exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class nerIgnoreKeywords() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class nerIgnoreKeywords() :: EXCEPTION :: "+ exception);
		}
		return nerIgnoreKeywords;
	}

	@Override
	public ArrayList<CaseVo> getODSObjectData(CaseVo caseVo) {
		ArrayList<CaseVo> list=new ArrayList<CaseVo>();
		String sqlQuery = null;
		try {
			sqlQuery = " SELECT id, object, object_name "
					         + " FROM tbl_ods_objects "
					         + " ORDER BY  object asc ";
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(sqlQuery);
			for(Map<String,Object> rs : rows){
				CaseVo caseVoObj=new CaseVo();
				caseVoObj.setId(rs.get("id")==null?"":rs.get("id").toString());
				caseVoObj.setKey1(rs.get("object")==null?"":rs.get("object").toString());
				caseVoObj.setKey2(rs.get("object_name")==null?"":rs.get("object_name").toString());
				list.add(caseVoObj);
			}
		} 
		catch(DataAccessException exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class getODSObjectData() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class getODSObjectData() :: EXCEPTION :: "+ exception);
		}
		return list;
	}

	@Override
	public ArrayList<CaseVo> getAnalysisSnapDetails(CaseVo caseVo) {
		ArrayList<CaseVo> list=new ArrayList<CaseVo>();
		String sqlQuery = null;
		try {
			sqlQuery = " SELECT snap.id, snap.search_name, snap.doe, ana.case_name, login.user_logon_id "
					         + " FROM tbl_save_filter AS snap "
					         + " INNER JOIN tbl_case AS ana "
					         + " ON ana.id=snap.case_id"
					         + " INNER JOIN login_detail AS login "
					         + " ON login.id=snap.login_id "
					         + " ORDER BY snap.id DESC ";
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(sqlQuery);
			for(Map<String,Object> rs : rows) {
				CaseVo caseVoObj=new CaseVo();
				caseVoObj.setId(rs.get("id")==null?"":rs.get("id").toString());
				caseVoObj.setKey1(rs.get("case_name")==null?"":rs.get("case_name").toString());
				caseVoObj.setKey2(rs.get("search_name")==null?"":rs.get("search_name").toString());
				caseVoObj.setKey3(rs.get("doe")==null?"":rs.get("doe").toString());
				caseVoObj.setKey4(rs.get("user_logon_id")==null?"":rs.get("user_logon_id").toString());
				list.add(caseVoObj);
			}
		} 
		catch(DataAccessException exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class getAnalysisSnapDetails() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class getAnalysisSnapDetails() :: EXCEPTION :: "+ exception);
		}
		return list;
	}
	
	@Override
	public ArrayList<CaseVo> getAnalysisSnapDetailsById(CaseVo caseVo) {
		ArrayList<CaseVo> list=new ArrayList<CaseVo>();
		String sqlQuery = null;
		try {
			sqlQuery = " SELECT snap.id, snap.search_name, snap.doe, ana.case_name, login.user_logon_id, snap.case_id "
					         + " FROM tbl_save_filter AS snap "
					         + " INNER JOIN tbl_case AS ana "
					         + " ON ana.id=snap.case_id"
					         + " INNER JOIN login_detail AS login "
					         + " ON login.id=snap.login_id "
					         + " WHERE snap.id='"+caseVo.getId()+"' ";
			
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(sqlQuery);
			for(Map<String,Object> rs : rows) {
				CaseVo caseVoObj=new CaseVo();
				caseVoObj.setId(rs.get("id")==null?"":rs.get("id").toString());
				caseVoObj.setKey1(rs.get("case_name")==null?"":rs.get("case_name").toString());
				caseVoObj.setKey2(rs.get("search_name")==null?"":rs.get("search_name").toString());
				caseVoObj.setKey3(rs.get("doe")==null?"":rs.get("doe").toString());
				caseVoObj.setKey4(rs.get("user_logon_id")==null?"":rs.get("user_logon_id").toString());
				caseVoObj.setKey5(rs.get("case_id")==null?"":rs.get("case_id").toString());
				list.add(caseVoObj);
			}
		} 
		catch(DataAccessException exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class getAnalysisSnapDetailsById() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class getAnalysisSnapDetailsById() :: EXCEPTION :: "+ exception);
		}
		return list;
	}
	
	@Override
	public boolean deleteAnalysisSnap(CaseVo caseVo) {
		boolean status = false;
		String sqlQuery = null; 
		try {
			sqlQuery="DELETE FROM tbl_save_filter WHERE id=?";
			Object[] obj=new Object[]{caseVo.getKey1()};
			jdbcTemplate.update(sqlQuery, obj);
			status = true;
		} 
		catch(Exception exception)	{
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class deleteAnalysisSnap() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class deleteAnalysisSnap() :: EXCEPTION :: "+ exception);
		}
		return status;
	}

	@Override
	public boolean editAnalysisSnapDetailsById(CaseVo caseVo) {
		boolean status = false;
		String sqlQuery = null; 
		try {
			sqlQuery ="UPDATE tbl_case SET case_name='"+caseVo.getKey3().trim()+"' WHERE id=?";
			Object[] obj=new Object[]{caseVo.getKey1().trim()};
			jdbcTemplate.update(sqlQuery, obj);
			
			sqlQuery="UPDATE tbl_save_filter SET search_name='"+caseVo.getKey4().trim()+"' WHERE id=?";
			obj=new Object[]{caseVo.getKey2().trim()};
			jdbcTemplate.update(sqlQuery, obj);
			status = true;
		} 
		catch(Exception exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class editAnalysisSnapDetailsById() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class editAnalysisSnapDetailsById() :: EXCEPTION :: "+ exception);
		}
		return status;
	}

	@Override
	public ArrayList<CaseVo> getThreatKeyword(CaseVo caseVo) {
		ArrayList<CaseVo> list=new ArrayList<CaseVo>();
		String sqlQuery = " SELECT id, threat_name, name FROM tbl_threat ORDER BY id ASC";
		try {
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(sqlQuery);
			for(Map<String,Object> rs : rows) {
				CaseVo caseVoObj=new CaseVo();
				caseVoObj.setId(rs.get("id")==null?"":rs.get("id").toString());
				caseVoObj.setKeyword(rs.get("threat_name")==null?"":rs.get("threat_name").toString());
				caseVoObj.setThreatScore(rs.get("name")==null?"":rs.get("name").toString());
				list.add(caseVoObj);
			}
		} catch(DataAccessException exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class getThreatScoreKeyword() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class getThreatScoreKeyword() :: EXCEPTION :: "+ exception);
		}
		return list;
	} 
	
	@Override
	public ArrayList<CaseVo> getThreatScoreKeyword(CaseVo caseVo) 	{
		ArrayList<CaseVo> list=new ArrayList<CaseVo>();
		String sqlQuery = null;
		try {
			sqlQuery = " SELECT id, keyword, threat_score FROM tbl_threat_score "
					         + " WHERE threat_score='"+caseVo.getThreatScore()+"' "
					         + " AND status='y' "
					         + " ORDER BY id DESC LIMIT 100 ";
			
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(sqlQuery);
			for(Map<String,Object> rs : rows) {
				CaseVo caseVoObj=new CaseVo();
				caseVoObj.setId(rs.get("id")==null?"":rs.get("id").toString());
				caseVoObj.setKeyword(rs.get("keyword")==null?"":rs.get("keyword").toString());
				caseVoObj.setThreatScore(rs.get("threat_score")==null?"":rs.get("threat_score").toString());
				list.add(caseVoObj);
			}
		} catch(DataAccessException exception)	{
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class getThreatScoreKeyword() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class getThreatScoreKeyword() :: EXCEPTION :: "+ exception);
		}
		return list;
	}

	@Override
	public boolean addThreatScoreKeyword(CaseVo caseVo) {
		boolean status = false;
		String user=(String)httpSession.getAttribute(ApplicationConstants.LOGINUSERID);
		String sqlQuery = null;
		try {
			String keywordArry[]=caseVo.getKeyword().trim().split(",");
			for(String keyword : keywordArry) {
				sqlQuery ="INSERT ignore into tbl_threat_score(keyword, threat_score, insert_date, author) values(?, ?, ?, ?)";
				Object[] obj=new Object[]{keyword.trim(), 
						caseVo.getThreatScore().trim(), 
						CommonUtils.getSqlCurrentDateTime(),
						user};
				jdbcTemplate.update(sqlQuery, obj);
				status = true;
				
				//update tbl_threat_status
				sqlQuery="UPDATE tbl_threat_status SET threat_status_flag='yes' WHERE id=? ";
				obj=new Object[]{"1"};
				jdbcTemplate.update(sqlQuery, obj);
				status = true;
			}
		}
		catch(Exception exception) {
			status = false;
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class addThreatScoreKeyword() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class addThreatScoreKeyword() :: EXCEPTION :: "+ exception);
		}		
		return status;
	}

	@Override
	public boolean deleteThreatScoreKeyword(CaseVo caseVo) {
		boolean status = false;
		String sqlQuery = null;
		try  {
			sqlQuery="UPDATE tbl_threat_score SET status='n' WHERE id=? ";
			Object[] obj=new Object[]{caseVo.getId()};
			jdbcTemplate.update(sqlQuery, obj);
			status = true;
		} catch(Exception exception) {
			status = false;
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class deleteThreatScoreKeyword() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class deleteThreatScoreKeyword() :: EXCEPTION :: "+ exception);
		}
		return status;
	}

	@Override
	public boolean getThreatScoreFlag(CaseVo caseVo) {
		boolean status = false;
		String sqlQuery = null;
		try {
			String csvWrittingFlag=TwitterConstant.getThreatClassificationFlag().trim();
			if(csvWrittingFlag.equalsIgnoreCase("no")) {
				status = false;
				return status;
			} else if(csvWrittingFlag.equalsIgnoreCase("yes")) {
				sqlQuery = " SELECT threat_status_flag FROM tbl_threat_status ";		        
				List<Map<String,Object>> rows = jdbcTemplate.queryForList(sqlQuery);
				
				for(Map<String,Object> rs : rows) {
					CaseVo caseVoObj=new CaseVo();
					caseVoObj.setThreatScore(rs.get("threat_status_flag")==null?"":rs.get("threat_status_flag").toString());
					
					if(caseVoObj.getThreatScore().equals("yes")) {
						status = true;
					} else if(caseVoObj.getThreatScore().equals("no")) {
						status = false;
					}
				}
			}
		} catch(DataAccessException exception) {
			status = false;
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class getThreatScoreFlag() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class getThreatScoreFlag() :: EXCEPTION :: "+ exception);
		}
		return status;
	}

	@SuppressWarnings("deprecation")
	@Override
	public boolean writeThreatKeywordInSentimentService(CaseVo caseVo) {
		ArrayList<CaseVo> list=new ArrayList<CaseVo>();
		boolean status = false;
		String sqlQuery = " SELECT id, keyword, threat_score FROM tbl_threat_score WHERE status='y' ";
		
		try {
			//Instantiating the CSVWriter class
			String fileName=TwitterConstant.getThreatKeywordUrl().trim();
		    CSVWriter writer = new CSVWriter(new FileWriter(fileName));
	
	        List<Map<String,Object>> rows = jdbcTemplate.queryForList(sqlQuery);
	        for(Map<String,Object> rs : rows) {
	    	    CaseVo caseVoObj=new CaseVo();
	   		    caseVoObj.setId(rs.get("id")==null?"":rs.get("id").toString());
	   		    caseVoObj.setKeyword(rs.get("keyword")==null?"":rs.get("keyword").toString());
	   		    caseVoObj.setThreatScore(rs.get("threat_score")==null?"":rs.get("threat_score").toString());
	   		    list.add(caseVoObj);
	   		    
	   		    //Writing data to a csv file
	   		    String line1[] = {caseVoObj.getKeyword(), caseVoObj.getThreatScore()};
	   		    writer.writeNext(line1); 
	        }
	        writer.flush();
	        status = true;
	    
		   //update tbl_threat_status
	        sqlQuery ="UPDATE tbl_threat_status SET threat_status_flag='no' WHERE id=? ";
			Object[] obj=new Object[]{"1"};
			jdbcTemplate.update(sqlQuery, obj);
			status = true;
		} catch(Exception exception) {
			status = false;
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class writeThreatKeywordInSentimentService() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class writeThreatKeywordInSentimentService() :: EXCEPTION :: "+ exception);
		}
		return status;
	}

	@Override
	public ArrayList<CaseVo> getAnalysisDetailsByUser(CaseVo caseVo) {
		String user=(String)httpSession.getAttribute(ApplicationConstants.LOGINUSERID);
		ArrayList<CaseVo> list=new ArrayList<CaseVo>();
		String sqlQuery = null;
		try {
			sqlQuery = " SELECT id, case_name, login_id"
					         + " FROM tbl_case "
					         + " WHERE login_id= '"+user+"' "
					         + " ORDER BY id DESC";
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(sqlQuery);
			for(Map<String,Object> rs : rows){
				CaseVo caseVoObj=new CaseVo();
				caseVoObj.setCaseId(rs.get("id")==null?"":rs.get("id").toString());
				caseVoObj.setCaseName(rs.get("case_name")==null?"":rs.get("case_name").toString());
				caseVoObj.setKey1(rs.get("login_id")==null?"":rs.get("login_id").toString());
				list.add(caseVoObj);
			}
		} catch(DataAccessException exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class getAnalysisDetailsByUser() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class getAnalysisDetailsByUser() :: EXCEPTION :: "+ exception);
		}
		return list;
	}

	@Override
	public ArrayList<CaseVo> getSnapshortDetailsByUser(CaseVo caseVo) {
		String user=(String)httpSession.getAttribute(ApplicationConstants.LOGINUSERID);
		String caseId=caseVo.getCaseId();
		ArrayList<CaseVo> list=new ArrayList<CaseVo>();
		String sqlQuery = null;
		
		try {
			sqlQuery = " SELECT id, search_name FROM tbl_save_filter "
					         + " WHERE login_id= '"+user+"' AND case_id= '"+caseId+"' "
					         + " ORDER BY id DESC";
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(sqlQuery);
			
			for(Map<String,Object> rs : rows){
				CaseVo caseVoObj=new CaseVo();
				caseVoObj.setSnapShortId(rs.get("id")==null?"":rs.get("id").toString());
				caseVoObj.setCaseName(rs.get("search_name")==null?"":rs.get("search_name").toString());
				list.add(caseVoObj);
			}
		} catch(DataAccessException exception) {
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class getSnapshortDetailsByUser() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class getSnapshortDetailsByUser() :: EXCEPTION :: "+ exception);
		}
		return list;
	}

	@Override
	public boolean addExportReportInfo(CaseVo caseVo) 
	{
		boolean status = false;
		String userName=(String)httpSession.getAttribute(ApplicationConstants.LOGIN_USER);
		String sqlQuery= null;
		try	
		{
			sqlQuery="INSERT ignore into tbl_nextcloud_report(report_name, description, author) values(?, ?, ?)";
			Object[] obj=new Object[]{caseVo.getKey1().trim(), 
					caseVo.getKey2().trim(),
					userName};
			jdbcTemplate.update(sqlQuery, obj);
			status = true;
			
			
			/*
			
			//download xml and json file
			Date today = new Date();
			Calendar cal = Calendar.getInstance();
			cal.setTime(today);
			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
		    String strToday = formatter.format(today);
		    
			String year = Integer.toString(cal.get(Calendar.YEAR));
			String month  = Integer.toString((cal.get(Calendar.MONTH))+1);
			String dates = Integer.toString(cal.get(Calendar.DATE));
			String hr= Integer.toString(cal.get(Calendar.HOUR_OF_DAY));
			String min= Integer.toString(cal.get(Calendar.MINUTE));
			String sec= Integer.toString(cal.get(Calendar.SECOND));
			
			System.out.println("year: "+year);
			System.out.println("month: "+month);
			System.out.println("dates: "+dates);
			System.out.println("hr: "+hr);
			System.out.println("min: "+min);
			System.out.println("sec: "+sec);
			
			String filesFormat=year+month+dates+hr+min+sec;
			String mainFolder=filesFormat+"_"+"InnsightReport";
			System.out.println("filesFormat: "+filesFormat);
			System.out.println("mainFolder: "+mainFolder);
			String rptPathUrl = TwitterConstant.getExportReportFolderPath().trim();
			File file = new File(rptPathUrl+mainFolder);
	        if(!file.exists()) 
	        {
	            if(file.mkdir()) 
	            {
	                System.out.println("Directory is created!");
	            } 
	            else 
	            {
	                System.out.println("Failed to create directory!");
	            }
	        }
	        File file1 = new File(rptPathUrl+mainFolder+"/"+filesFormat+"_innsight.json");
			//File file2 = new File(rptPathUrl+mainFolder+"/"+filesFormat+"_innsight.xml");
			
			HashMap<String,Object> jsonMap = new HashMap<String,Object>();
			HashMap<String,String> historyMap = new HashMap<String,String>();
			HashMap<String,String> attachmentMap = new HashMap<String,String>();
			HashMap<String,String> assessmentMap = new HashMap<String,String>();
			HashMap<String,String> ProcInfoMap = new HashMap<String,String>();
			
			historyMap.put("Event", null);
			attachmentMap.put("Item", filesFormat+"_Innsight.pdf");
			assessmentMap.put("para", null);
			ProcInfoMap.put("person", null);
			ProcInfoMap.put("organization", null);
			ProcInfoMap.put("location", null);
			ProcInfoMap.put("mobile", null);
			ProcInfoMap.put("telephone", null);
			ProcInfoMap.put("email", null);
			ProcInfoMap.put("accountName", null);
			ProcInfoMap.put("postPlace", null);
			ProcInfoMap.put("ip", null);
			ProcInfoMap.put("sentiment", null);
			
			jsonMap.put("UID", null);
			jsonMap.put("Created", null);
			jsonMap.put("PIN", null);
			jsonMap.put("To", null);
			jsonMap.put("Platform", "Innsight");
			jsonMap.put("Link", null);
			jsonMap.put("Subject", caseVo.getKey2());
			jsonMap.put("SecClass", null);
			jsonMap.put("From", "Open Source");
			jsonMap.put("SummaryText", null);
			jsonMap.put("Section", null);
			jsonMap.put("CC", null);
			jsonMap.put("Area", null);
			jsonMap.put("Language", "English");
			jsonMap.put("URI", null);
			jsonMap.put("ToolName", "Innsight");
			jsonMap.put("TransFreq", null);
			jsonMap.put("Receiver", null);
			jsonMap.put("Order", null);
			jsonMap.put("Class", null);
			jsonMap.put("SourceUID", null);
			jsonMap.put("DocType", "pdf");
			jsonMap.put("OIC", "Autometic Generated Report");
			jsonMap.put("DateTime", strToday);
			jsonMap.put("PostTime", strToday);
			
			jsonMap.put("History", historyMap);
			jsonMap.put("HTMLFormat", null);
			jsonMap.put("JSONFormat", null);
			jsonMap.put("DXLFormat", null);
			jsonMap.put("Attachment", attachmentMap);
			jsonMap.put("SourceText", null);
			jsonMap.put("Assessment", assessmentMap);
			jsonMap.put("ProcInfo", ProcInfoMap);
			
			OutputStream os1 = null;
			OutputStream os2 = null;
			
			try 
			{
				os1 = new FileOutputStream(file1);
	            os1.write(gson.toJson(jsonMap).getBytes());
	            
	           // os2 = new FileOutputStream(file2);
	           // os2.write(gson.toJson(jsonData2).getBytes());
			} 
			catch(Exception ex) 
			{
				ex.printStackTrace();
			}
			finally
	        {
	            try 
	            {
	                os1.close();
	                //os2.close();
	            } 
	            catch(IOException ex) 
	            {
	                ex.printStackTrace();
	            }
	        }
	        
			System.out.println("Zipping the directory...");
	        try 
	        {
	        	String sourceFile = rptPathUrl+mainFolder;
		        FileOutputStream fos = new FileOutputStream(rptPathUrl+mainFolder+".zip");
		        ZipOutputStream zipOut = new ZipOutputStream(fos);
		        File fileToZip = new File(sourceFile);
		 
		        zipReportFile(fileToZip, fileToZip.getName(), zipOut);
		        zipOut.close();
		        fos.close();
	        }
	        catch(Exception ex) 
	        {
	        	ex.printStackTrace();
	        }
			System.out.println("Start Downloading...");
			
			File downloadFile = new File(rptPathUrl+mainFolder+".zip");
			if(downloadFile.exists()) 
			{
	            response.setContentType("application/pdf");
	            response.addHeader("Content-Disposition", "attachment; filename="+fbType+"_"+fbUserId+".zip");
	            try 
	            {
	                Files.copy(downloadFile, response.getOutputStream());
	                response.getOutputStream().flush();
	                System.out.println("Finish");
	            }
	            catch(IOException ex) 
	            {
	                ex.printStackTrace();
	            }
	        }
			*/
			
		} catch(Exception exception) {
			status = false;
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class addExportReportInfo() :: EXCEPTION :: SQL :: "+ sqlQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class addExportReportInfo() :: EXCEPTION :: "+ exception);
		}		
		return status;
	}

	
	private static void zipReportFile(File fileToZip, String fileName, ZipOutputStream zipOut) throws IOException 
	{
        if(fileToZip.isHidden()) 
        {
            return;
        }
        if(fileToZip.isDirectory()) 
        {
            if (fileName.endsWith("/")) 
            {
                zipOut.putNextEntry(new ZipEntry(fileName));
                zipOut.closeEntry();
            } 
            else 
            {
                zipOut.putNextEntry(new ZipEntry(fileName + "/"));
                zipOut.closeEntry();
            }
            File[] children = fileToZip.listFiles();
            for(File childFile : children) 
            {
            	zipReportFile(childFile, fileName + "/" + childFile.getName(), zipOut);
            }
            return;
        }
        FileInputStream fis = new FileInputStream(fileToZip);
        ZipEntry zipEntry = new ZipEntry(fileName);
        zipOut.putNextEntry(zipEntry);
        byte[] bytes = new byte[1024];
        int length;
        while ((length = fis.read(bytes)) >= 0)
        {
            zipOut.write(bytes, 0, length);
        }
        fis.close();
    }
	
	
	@Override
	public ArrayList<CaseVo> getExportReportDetails(CaseVo caseVo) 
	{
		ArrayList<CaseVo> list=new ArrayList<CaseVo>();
		String serachText=caseVo.getKey1();
		String userId=caseVo.getKey2();
		
		String subQuery="";
		String selectQuery="";
		if(!serachText.equals("")) 
		{
			subQuery+=" AND keyword LIKE '%"+serachText+"%' ";
		}
		if(!userId.equals("")) 
		{
			subQuery+=" AND author='"+userId+"' ";
		}
		
		try 
		{
			selectQuery = " SELECT id, report_name, description, author, xml_file_name, json_file_name, "
					         + " pdf_file_name, report_folder, status, ts "
					         + " FROM tbl_nextcloud_report "
					         + " WHERE 1=1 "+subQuery+" "
					         + " ORDER BY id DESC";
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(selectQuery);
			
			for(Map<String,Object> rs : rows) 
			{
				CaseVo caseVoObj=new CaseVo();
				caseVoObj.setId(rs.get("id")==null?"":rs.get("id").toString());
				caseVoObj.setKey1(rs.get("report_name")==null?"":rs.get("report_name").toString());
				caseVoObj.setKey2(rs.get("description")==null?"":rs.get("description").toString());
				caseVoObj.setKey3(rs.get("author")==null?"":rs.get("author").toString());
				caseVoObj.setKey4(rs.get("ts")==null?"":rs.get("ts").toString());
				caseVoObj.setKey5(rs.get("xml_file_name")==null?"":rs.get("xml_file_name").toString());
				caseVoObj.setKey6(rs.get("json_file_name")==null?"":rs.get("json_file_name").toString());
				caseVoObj.setKey7(rs.get("pdf_file_name")==null?"":rs.get("pdf_file_name").toString());
				caseVoObj.setKey8(rs.get("report_folder")==null?"":rs.get("report_folder").toString());
				caseVoObj.setKey9(rs.get("status")==null?"":rs.get("status").toString());
				
				list.add(caseVoObj);
			}
		} catch(DataAccessException exception)	{
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class getExportReportDetails() :: EXCEPTION :: SQL :: "+ selectQuery);
			logger.error(CommonUtils.getCurrentTime()+ " Inside CaseInnDaoImpl Class getExportReportDetails() :: EXCEPTION :: "+ exception);
		}
		return list;
	}

	
}