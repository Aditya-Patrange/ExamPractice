package com.cdac.sudarshan.discover.dto;

import com.cdac.sudarshan.discover.model.BaseEntity;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@RequiredArgsConstructor
public class DiscoverSubSourceDto extends BaseEntity {

    private String discoverSubSource;


}
