package com.cdac.sudarshan.discover.model;

import java.util.List;

public interface WordTokenizer {
	
	List<String> tokenize(String sentence);

}
