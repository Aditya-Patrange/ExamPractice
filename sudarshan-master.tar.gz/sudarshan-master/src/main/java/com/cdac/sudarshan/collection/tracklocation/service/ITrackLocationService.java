package com.cdac.sudarshan.collection.tracklocation.service;

import java.util.HashMap;

import org.springframework.http.ResponseEntity;

public interface ITrackLocationService {
	public ResponseEntity<?> trackLocation(HashMap<String, Object> data);
}
