package com.cdac.sudarshan.discover.model;

import java.io.Serializable;

public class TweetHashTagsTblVo  implements  Serializable{
	private static final long serialVersionUID = 1L;
	String hashTag,TweetId;

	public String getHashTag() {
		return hashTag;
	}

	public void setHashTag(String hashTag) {
		this.hashTag = hashTag;
	}

	public String getTweetId() {
		return TweetId;
	}

	public void setTweetId(String tweetId) {
		TweetId = tweetId;
	}
}
