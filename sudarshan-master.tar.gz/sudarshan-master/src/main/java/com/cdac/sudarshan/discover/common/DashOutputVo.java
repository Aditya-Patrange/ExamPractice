package com.cdac.sudarshan.discover.common;

public class DashOutputVo {

	private String oneDay_total_count,entity_type,total_count,date_of_insertion;
	private String psentiment_count;
	private String nesentiment_count;
	private String nusentiment_count;
	private String avg_sentiment;
	private String type,word;
	private String code,count,tagValue,username,media,userid,user_profile_img;
	private String created_at,text,user_id,user_name,retweet_count,favourite_count,user_img,user_follower,user_friend,user_tweet,user_full_name;
	private String  thumbnails_medium_url ;
	private String  like_count ;
	private String  comment_count;
	private	String  title;
	private	String  publishedAt;
	private	String  channel_title;
	private	String  standard_resolution;
	private	String  subtitle,source;
	private String dislike_count,favorite_count,view_count,channelId,videoUrl;
	
	
	
	
	
	public String getVideoUrl() {
		return videoUrl;
	}

	public void setVideoUrl(String videoUrl) {
		this.videoUrl = videoUrl;
	}

	public String getChannelId() {
		return channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	public String getDislike_count() {
		return dislike_count;
	}

	public void setDislike_count(String dislike_count) {
		this.dislike_count = dislike_count;
	}

	public String getFavorite_count() {
		return favorite_count;
	}

	public void setFavorite_count(String favorite_count) {
		this.favorite_count = favorite_count;
	}

	public String getView_count() {
		return view_count;
	}

	public void setView_count(String view_count) {
		this.view_count = view_count;
	}

	public String getSubtitle() {
		return subtitle;
	}

	public void setSubtitle(String subtitle) {
		this.subtitle = subtitle;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getStandard_resolution() {
		return standard_resolution;
	}

	public void setStandard_resolution(String standard_resolution) {
		this.standard_resolution = standard_resolution;
	}

	public String getPublishedAt() {
		return publishedAt;
	}

	public void setPublishedAt(String publishedAt) {
		this.publishedAt = publishedAt;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}


	public String getThumbnails_medium_url() {
		return thumbnails_medium_url;
	}

	public void setThumbnails_medium_url(String thumbnails_medium_url) {
		this.thumbnails_medium_url = thumbnails_medium_url;
	}



	public String getChannel_title() {
		return channel_title;
	}

	public void setChannel_title(String channel_title) {
		this.channel_title = channel_title;
	}

	
	public String getLike_count() {
		return like_count;
	}

	public void setLike_count(String like_count) {
		this.like_count = like_count;
	}

	
	public String getComment_count() {
		return comment_count;
	}

	public void setComment_count(String comment_count) {
		this.comment_count = comment_count;
	}

	public String getCreated_at() {
		return created_at;
	}

	public void setCreated_at(String created_at) {
		this.created_at = created_at;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getUser_id() {
		return user_id;
	}

	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	public String getRetweet_count() {
		return retweet_count;
	}

	public void setRetweet_count(String retweet_count) {
		this.retweet_count = retweet_count;
	}

	public String getFavourite_count() {
		return favourite_count;
	}

	public void setFavourite_count(String favourite_count) {
		this.favourite_count = favourite_count;
	}

	public String getUser_img() {
		return user_img;
	}

	public void setUser_img(String user_img) {
		this.user_img = user_img;
	}

	public String getUser_follower() {
		return user_follower;
	}

	public void setUser_follower(String user_follower) {
		this.user_follower = user_follower;
	}

	public String getUser_friend() {
		return user_friend;
	}

	public void setUser_friend(String user_friend) {
		this.user_friend = user_friend;
	}

	public String getUser_tweet() {
		return user_tweet;
	}

	public void setUser_tweet(String user_tweet) {
		this.user_tweet = user_tweet;
	}

	public String getUser_full_name() {
		return user_full_name;
	}

	public void setUser_full_name(String user_full_name) {
		this.user_full_name = user_full_name;
	}

	public String getUser_profile_img() {
		return user_profile_img;
	}

	public void setUser_profile_img(String user_profile_img) {
		this.user_profile_img = user_profile_img;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getMedia() {
		return media;
	}

	public void setMedia(String media) {
		this.media = media;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getTagValue() {
		return tagValue;
	}

	public void setTagValue(String tagValue) {
		this.tagValue = tagValue;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getCount() {
		return count;
	}

	public void setCount(String count) {
		this.count = count;
	}

	public String getWord() {
		return word;
	}

	public void setWord(String word) {
		this.word = word;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getAvg_sentiment() {
		return avg_sentiment;
	}

	public void setAvg_sentiment(String avg_sentiment) {
		this.avg_sentiment = avg_sentiment;
	}

	public String getPsentiment_count() {
		return psentiment_count;
	}

	public void setPsentiment_count(String psentiment_count) {
		this.psentiment_count = psentiment_count;
	}

	public String getNesentiment_count() {
		return nesentiment_count;
	}

	public void setNesentiment_count(String nesentiment_count) {
		this.nesentiment_count = nesentiment_count;
	}

	public String getNusentiment_count() {
		return nusentiment_count;
	}

	public void setNusentiment_count(String nusentiment_count) {
		this.nusentiment_count = nusentiment_count;
	}

	public String getOneDay_total_count() {
		return oneDay_total_count;
	}

	public void setOneDay_total_count(String oneDay_total_count) {
		this.oneDay_total_count = oneDay_total_count;
	}

	public String getEntity_type() {
		return entity_type;
	}

	public void setEntity_type(String entity_type) {
		this.entity_type = entity_type;
	}

	public String getTotal_count() {
		return total_count;
	}

	public void setTotal_count(String total_count) {
		this.total_count = total_count;
	}

	public String getDate_of_insertion() {
		return date_of_insertion;
	}

	public void setDate_of_insertion(String date_of_insertion) {
		this.date_of_insertion = date_of_insertion;
	}
	
	
}
