package com.cdac.sudarshan.discover.model;

public class UserProfileConnectionExportVo 
{
	private static final long serialVersionUID = 1L;
	private String fbUserId;
    private String fbUserName;
    private String fbUserImage;
    private String connectionType;
    private String fbUserFriendId;
    private String fbUserFriendName;
    private String fbUserFriendImage;
    private String fbUserFriendProfession;
    
	public String getFbUserId() {
		return fbUserId;
	}
	public void setFbUserId(String fbUserId) {
		this.fbUserId = fbUserId;
	}
	public String getFbUserName() {
		return fbUserName;
	}
	public void setFbUserName(String fbUserName) {
		this.fbUserName = fbUserName;
	}
	public String getFbUserImage() {
		return fbUserImage;
	}
	public void setFbUserImage(String fbUserImage) {
		this.fbUserImage = fbUserImage;
	}
	public String getConnectionType() {
		return connectionType;
	}
	public void setConnectionType(String connectionType) {
		this.connectionType = connectionType;
	}
	public String getFbUserFriendId() {
		return fbUserFriendId;
	}
	public void setFbUserFriendId(String fbUserFriendId) {
		this.fbUserFriendId = fbUserFriendId;
	}
	public String getFbUserFriendName() {
		return fbUserFriendName;
	}
	public void setFbUserFriendName(String fbUserFriendName) {
		this.fbUserFriendName = fbUserFriendName;
	}
	public String getFbUserFriendImage() {
		return fbUserFriendImage;
	}
	public void setFbUserFriendImage(String fbUserFriendImage) {
		this.fbUserFriendImage = fbUserFriendImage;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public String getFbUserFriendProfession() {
		return fbUserFriendProfession;
	}
	public void setFbUserFriendProfession(String fbUserFriendProfession) {
		this.fbUserFriendProfession = fbUserFriendProfession;
	}
	@Override
	public String toString() {
		return "UserProfileConnectionExportVo [fbUserId=" + fbUserId + ", fbUserName=" + fbUserName + ", fbUserImage="
				+ fbUserImage + ", connectionType=" + connectionType + ", fbUserFriendId=" + fbUserFriendId
				+ ", fbUserFriendName=" + fbUserFriendName + ", fbUserFriendImage=" + fbUserFriendImage
				+ ", fbUserFriendProfession=" + fbUserFriendProfession + "]";
	}
}
