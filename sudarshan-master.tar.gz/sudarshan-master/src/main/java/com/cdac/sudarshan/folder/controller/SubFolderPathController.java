package com.cdac.sudarshan.folder.controller;

import com.cdac.sudarshan.folder.model.SubFolderName;
import com.cdac.sudarshan.folder.model.SubFolderPaths;
import com.cdac.sudarshan.folder.service.ISubFolderPathsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StreamUtils;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@CrossOrigin("*")
@RestController
@RequestMapping(value = "/subfolderpath", produces = "application/json")
public class SubFolderPathController {

	@Autowired
	private ISubFolderPathsService subFolderPathsService;

	@PostMapping("/save")
	public ResponseEntity<?> addSubFolderToRootFolderPath(@RequestBody HashMap<String, String> map) {

		List<SubFolderPaths> subFolderPaths = subFolderPathsService.addSubFolderToRootFolder(map.get("path"));

		List<Object> list = new ArrayList<>();

		int size = 0;
		size = subFolderPaths.size() - 1;
		for (SubFolderPaths s : subFolderPaths) {
			SubFolderName subFolderName = new SubFolderName();
			SubFolderPaths sbf = (SubFolderPaths) subFolderPaths.get(size);
			subFolderName.setSubFolderName(s.getSubFolderPath());
			list.add(sbf);
			size--;
		}

		return ResponseEntity.ok(list);
	}

	@PostMapping("/subFolderList")
	public ResponseEntity<?> getAllSubFolderByRootFolder(@RequestBody Map<String, String> map) {
		return ResponseEntity.ok(subFolderPathsService.getAllSubFolderOfRootFolder(map.get("rootFolderName")));
	}

	@PostMapping("/")
	public ResponseEntity<?> getSubFolderOfParentFolder(@RequestBody Map<String, String> map) {
		return ResponseEntity.ok(subFolderPathsService.getSubFolderOfParentFolder(map.get("rootFolderName")));
	}

	@PostMapping("/geturlandsource")
	public ResponseEntity<?> getUrlAndSourceFromEs(@RequestBody Map<String, Object> data) {
		return ResponseEntity.ok(subFolderPathsService.getUrlAndSourceFromEs(data));

	}

	/**
	 * This API return media source like image, videos
	 * @param data
	 * @return
	 */
	@PostMapping("/mediaSourceData")
	public ResponseEntity<?> getMediaSourceData(@RequestBody Map<String, Object> data) throws IOException {
		return ResponseEntity.ok(subFolderPathsService.getMediaSourceData(data));

	}

//	@GetMapping("/images/{imgName}")
//	public void serveImage(@PathVariable("imgName") String imgName, HttpServletResponse response) throws IOException {
//		String path = "/home/ajay/Downloads";
//		InputStream resource = getResource(path, imgName);
//		response.setContentType(MediaType.IMAGE_JPEG_VALUE);
//		StreamUtils.copy(resource, response.getOutputStream());
//	}

	@PostMapping("/images")
	public void serveImage(@RequestBody Map<String, Object> data, HttpServletResponse response) throws IOException {
		InputStream resource = getResource((String) data.get("filePath"));
		response.setContentType(MediaType.IMAGE_JPEG_VALUE);
		StreamUtils.copy(resource, response.getOutputStream());
	}


//	public InputStream getResource(String path, String fileName) throws FileNotFoundException {
//		String fullPath = path + File.separator+fileName;
//		InputStream i = new FileInputStream(fullPath);
//		return i;
//	}

	public InputStream getResource(String path) throws FileNotFoundException {
		InputStream i = new FileInputStream(path);
		return i;
	}

	@PatchMapping("/renameSubFolder")
	public ResponseEntity<?> renameSubFolder(@RequestBody Map<String,String> map){
		return subFolderPathsService.renameSubFolder(map);
	}

}
