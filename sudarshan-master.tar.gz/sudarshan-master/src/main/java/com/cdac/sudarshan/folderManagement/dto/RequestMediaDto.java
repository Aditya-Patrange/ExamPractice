package com.cdac.sudarshan.folderManagement.dto;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class RequestMediaDto {

    private String mediaId; // articleID
    private String tag;
    private String source;
    private String link;
    private String mediaName;
    private String folderId;
    private Integer status;
    private Long userId;
    private Integer downloadStatus;
    private String resourcePath;
    private String videoUrl;
    private String folderDataType;


}
