package com.cdac.sudarshan.speech.service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;

import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

public interface ISpeechService {

	ResponseEntity<?> getTranscribeEnglish(MultipartFile file);

	ResponseEntity<?> getTranscribeHindi(MultipartFile file);

	ResponseEntity<?> getKWSAdvanceSearchEnglish(MultipartFile file);

	ResponseEntity<?> getKWSAdvanceSearchHindi(MultipartFile file);

	ResponseEntity<?> getLIDLanguage(MultipartFile file);

	ResponseEntity<?> getTranscribeTest(MultipartFile file) throws NoSuchAlgorithmException, KeyStoreException,
			CertificateException, FileNotFoundException, IOException, KeyManagementException;

}
