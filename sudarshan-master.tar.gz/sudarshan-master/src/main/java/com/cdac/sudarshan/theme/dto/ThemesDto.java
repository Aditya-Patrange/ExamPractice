package com.cdac.sudarshan.theme.dto;

import com.cdac.sudarshan.theme.model.SubTheme;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class ThemesDto {

    private Long id;
    private String themePath;
    private List<SubTheme> subThemes = new ArrayList<>();
    private LocalDateTime creationDate;
    private LocalDateTime lastUpdatedDate;

}
