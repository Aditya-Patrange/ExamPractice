package com.cdac.sudarshan.entityprofiles.service;

import org.springframework.http.ResponseEntity;

import com.cdac.sudarshan.entityprofiles.dto.EntityProfileDto;

public interface IEntityProfileService {
	
	public ResponseEntity<?> createEntityProfile(EntityProfileDto entityProfileDto);
	
	public ResponseEntity<?>getAllEntityProfile();
}
