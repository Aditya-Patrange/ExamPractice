package com.cdac.sudarshan.dto;

import java.util.ArrayList;
import java.util.List;

import com.cdac.sudarshan.folder.dto.RootFolderDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DTO {

	
	List<RootFolderDto> dtos = new ArrayList();
}
