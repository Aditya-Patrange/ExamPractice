package com.cdac.sudarshan.discover.model;

import java.io.Serializable;

public class Articel_Ner implements Serializable 
{
	private static final long serialVersionUID = 1L;
	private String keyword;
	private int count;
	private int nerSentiment=9;
	public String getKeyword() {
		return keyword;
	}
	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public float getNerSentiment() {
		return nerSentiment;
	}
	public void setNerSentiment(int nerSentiment) {
		this.nerSentiment = nerSentiment;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "Articel_Ner [keyword=" + keyword + ", count=" + count + ", nerSentiment=" + nerSentiment + "]";
	}
}
