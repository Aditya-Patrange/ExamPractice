package com.cdac.sudarshan.discover.model;

import java.io.Serializable;
import java.util.ArrayList;

public class Article_Telegram implements Serializable
{
	private static final long serialVersionUID = 1L;
	private String mediaType;          // media type : audio,image,video
    private String mediaPath;          // GroupName_primarykey_url(without photos folder)
    private String mediaThumbnail;     // For video
	private String mediaCaption; 
	private String msgType;            // message type: ’0’=text, ’1’=image, ’2’=audio, ’3’=video, '4'=doc, '5'=location, '6'=sticker
	private String msgReceiverType;    // msgReceiverType '0' = channel, '1' =  Group
	private String message; 
	private String msgTimeStamp; 	
	private String msgSender;
	private String msgReceiver;
	private String groupChannelName; 
	private String groupChannelId;
	private String location;
	private String locationUrl;
	private String document;
	private String mediaLength;
	private ArrayList<String> linkUrl; 
	
	public ArrayList<String> getLinkUrl() {
		return linkUrl;
	}
	public void setLinkUrl(ArrayList<String> linkUrl) {
		this.linkUrl = linkUrl;
	}
	public String getMediaLength() {
		return mediaLength;
	}
	public void setMediaLength(String mediaLength) {
		this.mediaLength = mediaLength;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getLocationUrl() {
		return locationUrl;
	}
	public void setLocationUrl(String locationUrl) {
		this.locationUrl = locationUrl;
	}
	public String getDocument() {
		return document;
	}
	public void setDocument(String document) {
		this.document = document;
	}
	public String getMediaThumbnail() {
		return mediaThumbnail;
	}
	public void setMediaThumbnail(String mediaThumbnail) {
		this.mediaThumbnail = mediaThumbnail;
	}
	public String getMediaType() {
		return mediaType;
	}
	public void setMediaType(String mediaType) {
		this.mediaType = mediaType;
	}
	public String getMediaPath() {
		return mediaPath;
	}
	public void setMediaPath(String mediaPath) {
		this.mediaPath = mediaPath;
	}
	public String getMediaCaption() {
		return mediaCaption;
	}
	public void setMediaCaption(String mediaCaption) {
		this.mediaCaption = mediaCaption;
	}
	public String getMsgType() {
		return msgType;
	}
	public void setMsgType(String msgType) {
		this.msgType = msgType;
	}
	public String getMsgReceiverType() {
		return msgReceiverType;
	}
	public void setMsgReceiverType(String msgReceiverType) {
		this.msgReceiverType = msgReceiverType;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getMsgTimeStamp() {
		return msgTimeStamp;
	}
	public void setMsgTimeStamp(String msgTimeStamp) {
		this.msgTimeStamp = msgTimeStamp;
	}
	public String getMsgSender() {
		return msgSender;
	}
	public void setMsgSender(String msgSender) {
		this.msgSender = msgSender;
	}
	public String getMsgReceiver() {
		return msgReceiver;
	}
	public void setMsgReceiver(String msgReceiver) {
		this.msgReceiver = msgReceiver;
	}
	public String getGroupChannelName() {
		return groupChannelName;
	}
	public void setGroupChannelName(String groupChannelName) {
		this.groupChannelName = groupChannelName;
	}
	public String getGroupChannelId() {
		return groupChannelId;
	}
	public void setGroupChannelId(String groupChannelId) {
		this.groupChannelId = groupChannelId;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "Article_Telegram [mediaType=" + mediaType + ", mediaPath=" + mediaPath + ", mediaThumbnail="
				+ mediaThumbnail + ", mediaCaption=" + mediaCaption + ", msgType=" + msgType + ", msgReceiverType="
				+ msgReceiverType + ", message=" + message + ", msgTimeStamp=" + msgTimeStamp + ", msgSender="
				+ msgSender + ", msgReceiver=" + msgReceiver + ", groupChannelName=" + groupChannelName
				+ ", groupChannelId=" + groupChannelId + ", location=" + location + ", locationUrl=" + locationUrl
				+ ", document=" + document + ", mediaLength=" + mediaLength + ", linkUrl=" + linkUrl + "]";
	}
}
