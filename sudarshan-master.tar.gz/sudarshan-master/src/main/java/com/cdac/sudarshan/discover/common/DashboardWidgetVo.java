package com.cdac.sudarshan.discover.common;

public class DashboardWidgetVo 
{
	private long dashboardWidgetId;
	private long dashboardId;
	private long widgetId;
	private int widgetX;
	private int widgetY;
	private String widgetName;
	private String widgetDescription;
	private String widgetCategory;
	private String widgetImagePath;
	private String widgetCode;
	private int widgetWidth;
	private int widgetHeight;
	private String dashboardName;
	private int dashboardIsPublic;
	
	public long getDashboardWidgetId() {
		return dashboardWidgetId;
	}
	public void setDashboardWidgetId(long dashboardWidgetId) {
		this.dashboardWidgetId = dashboardWidgetId;
	}
	public long getDashboardId() {
		return dashboardId;
	}
	public void setDashboardId(long dashboardId) {
		this.dashboardId = dashboardId;
	}
	public long getWidgetId() {
		return widgetId;
	}
	public void setWidgetId(long widgetId) {
		this.widgetId = widgetId;
	}
	public int getWidgetX() {
		return widgetX;
	}
	public void setWidgetX(int widgetX) {
		this.widgetX = widgetX;
	}
	public int getWidgetY() {
		return widgetY;
	}
	public void setWidgetY(int widgetY) {
		this.widgetY = widgetY;
	}
	public String getWidgetName() {
		return widgetName;
	}
	public void setWidgetName(String widgetName) {
		this.widgetName = widgetName;
	}
	public String getWidgetDescription() {
		return widgetDescription;
	}
	public void setWidgetDescription(String widgetDescription) {
		this.widgetDescription = widgetDescription;
	}
	public String getWidgetCategory() {
		return widgetCategory;
	}
	public void setWidgetCategory(String widgetCategory) {
		this.widgetCategory = widgetCategory;
	}
	public String getWidgetImagePath() {
		return widgetImagePath;
	}
	public void setWidgetImagePath(String widgetImagePath) {
		this.widgetImagePath = widgetImagePath;
	}
	public String getWidgetCode() {
		return widgetCode;
	}
	public void setWidgetCode(String widgetCode) {
		this.widgetCode = widgetCode;
	}
	public int getWidgetWidth() {
		return widgetWidth;
	}
	public void setWidgetWidth(int widgetWidth) {
		this.widgetWidth = widgetWidth;
	}
	public int getWidgetHeight() {
		return widgetHeight;
	}
	public void setWidgetHeight(int widgetHeight) {
		this.widgetHeight = widgetHeight;
	}
	public String getDashboardName() {
		return dashboardName;
	}
	public void setDashboardName(String dashboardName) {
		this.dashboardName = dashboardName;
	}
	public int getDashboardIsPublic() {
		return dashboardIsPublic;
	}
	public void setDashboardIsPublic(int dashboardIsPublic) {
		this.dashboardIsPublic = dashboardIsPublic;
	}
	@Override
	public String toString() {
		return "DashboardWidgetVo [dashboardWidgetId=" + dashboardWidgetId + ", dashboardId=" + dashboardId
				+ ", widgetId=" + widgetId + ", widgetX=" + widgetX + ", widgetY=" + widgetY + ", widgetName="
				+ widgetName + ", widgetDescription=" + widgetDescription + ", widgetCategory=" + widgetCategory
				+ ", widgetImagePath=" + widgetImagePath + ", widgetCode=" + widgetCode + ", widgetWidth=" + widgetWidth
				+ ", widgetHeight=" + widgetHeight + ", dashboardName=" + dashboardName + ", dashboardIsPublic="
				+ dashboardIsPublic + ", getDashboardWidgetId()=" + getDashboardWidgetId() + ", getDashboardId()="
				+ getDashboardId() + ", getWidgetId()=" + getWidgetId() + ", getWidgetX()=" + getWidgetX()
				+ ", getWidgetY()=" + getWidgetY() + ", getWidgetName()=" + getWidgetName()
				+ ", getWidgetDescription()=" + getWidgetDescription() + ", getWidgetCategory()=" + getWidgetCategory()
				+ ", getWidgetImagePath()=" + getWidgetImagePath() + ", getWidgetCode()=" + getWidgetCode()
				+ ", getWidgetWidth()=" + getWidgetWidth() + ", getWidgetHeight()=" + getWidgetHeight()
				+ ", getDashboardName()=" + getDashboardName() + ", getDashboardIsPublic()=" + getDashboardIsPublic()
				+ ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString()
				+ "]";
	}

	@Override
    public boolean equals(Object object)
    {
        if (object != null && object instanceof DashboardWidgetVo)
        {
        	DashboardWidgetVo dvo = (DashboardWidgetVo)object;
        	if(this.dashboardId==dvo.dashboardId && this.widgetId==dvo.widgetId)
        	{
        		return true;
        	}
        	else
        	{
        		return false;
        	}
        }
        return false;
    }
	
}