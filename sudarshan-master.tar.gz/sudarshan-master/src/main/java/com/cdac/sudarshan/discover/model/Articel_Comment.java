package com.cdac.sudarshan.discover.model;

import java.io.Serializable;

public class Articel_Comment implements Serializable 
{
	private static final long serialVersionUID = 1L;
	private String articleCommentUserId;
	private String articleCommentUserName;
	private String articleCommentText;
	private String articleCommentUserNameImg;
	private String articleCommentId;
	private long articleCommentCreatedTime;
	
	public String getArticleCommentUserId() {
		return articleCommentUserId;
	}
	public void setArticleCommentUserId(String articleCommentUserId) {
		this.articleCommentUserId = articleCommentUserId;
	}
	public String getArticleCommentUserName() {
		return articleCommentUserName;
	}
	public void setArticleCommentUserName(String articleCommentUserName) {
		this.articleCommentUserName = articleCommentUserName;
	}
	public String getArticleCommentText() {
		return articleCommentText;
	}
	public void setArticleCommentText(String articleCommentText) {
		this.articleCommentText = articleCommentText;
	}
	public long getArticleCommentCreatedTime() {
		return articleCommentCreatedTime;
	}
	public void setArticleCommentCreatedTime(long articleCommentCreatedTime) {
		this.articleCommentCreatedTime = articleCommentCreatedTime;
	}
	public String getArticleCommentUserNameImg() {
		return articleCommentUserNameImg;
	}
	public void setArticleCommentUserNameImg(String articleCommentUserNameImg) {
		this.articleCommentUserNameImg = articleCommentUserNameImg;
	}
	public String getArticleCommentId() {
		return articleCommentId;
	}
	public void setArticleCommentId(String articleCommentId) {
		this.articleCommentId = articleCommentId;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "Articel_Comment [articleCommentUserId=" + articleCommentUserId + ", articleCommentUserName="
				+ articleCommentUserName + ", articleCommentText=" + articleCommentText + ", articleCommentUserNameImg="
				+ articleCommentUserNameImg + ", articleCommentCreatedTime=" + articleCommentCreatedTime
				+ ", articleCommentId=" + articleCommentId + "]";
	}
	
}
