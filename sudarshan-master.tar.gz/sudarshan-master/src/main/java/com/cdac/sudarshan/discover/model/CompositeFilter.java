package com.cdac.sudarshan.discover.model;

import java.util.List;

/**
 * Created by kenny
 */
public class CompositeFilter extends Filter {

    private final List<Filter> filters;

    public CompositeFilter(final List<Filter> filters) {
        this.filters = filters;
    }

    public boolean apply(final String word) {
//        for(Filter filter : filters) {
//            if(!filter.apply(word)) { return false; }
//        }
        return true;
    }

}
