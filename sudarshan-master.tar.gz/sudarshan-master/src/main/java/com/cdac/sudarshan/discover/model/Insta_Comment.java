package com.cdac.sudarshan.discover.model;

import java.io.Serializable;

public class Insta_Comment implements Serializable 
{
	private static final long serialVersionUID = 1L;
	private String instaCommentText;
	private String instaCommentUserId;
	private String instaCommentId;
	private String instaCommentUserName;
	private String instaCommentUserImg;
	private String instaCommentCreatedAt;

	public String getInstaCommentCreatedAt() {
		return instaCommentCreatedAt;
	}

	public void setInstaCommentCreatedAt(String instaCommentCreatedAt) {
		this.instaCommentCreatedAt = instaCommentCreatedAt;
	}

	public String getInstaCommentId() {
		return instaCommentId;
	}

	public void setInstaCommentId(String instaCommentId) {
		this.instaCommentId = instaCommentId;
	}

	public String getInstaCommentUserName() {
		return instaCommentUserName;
	}

	public void setInstaCommentUserName(String instaCommentUserName) {
		this.instaCommentUserName = instaCommentUserName;
	}

	public String getInstaCommentUserImg() {
		return instaCommentUserImg;
	}

	public void setInstaCommentUserImg(String instaCommentUserImg) {
		this.instaCommentUserImg = instaCommentUserImg;
	}

	public String getInstaCommentText() {
		return instaCommentText;
	}

	public void setInstaCommentText(String instaCommentText) {
		this.instaCommentText = instaCommentText;
	}

	public String getInstaCommentUserId() {
		return instaCommentUserId;
	}
	public void setInstaCommentUserId(String instaCommentUserId) {
		this.instaCommentUserId = instaCommentUserId;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "Insta_Comment [instaCommentText=" + instaCommentText + ", instaCommentUserId=" + instaCommentUserId
				+ ", instaCommentId=" + instaCommentId + ", instaCommentUserName=" + instaCommentUserName
				+ ", instaCommentUserImg=" + instaCommentUserImg + ", instaCommentCreatedAt=" + instaCommentCreatedAt
				+ "]";
	}
}
